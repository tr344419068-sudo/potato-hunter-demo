import { defineConfig } from "vite";

const isGitHubPagesBuild = process.env.GITHUB_ACTIONS === "true";

export default defineConfig({
  base: isGitHubPagesBuild ? "/potato-hunter-demo/" : "/",
  server: {
    port: 5173,
  },
  build: {
    target: "es2020",
  },
});
