# Potato Hunter Assets

Greybox art drops live here. Keep filenames aligned with `src/configs/assets.json`.

Missing images are allowed during prototype work; the game falls back to shape-based placeholders.

## Generated energy halo

`vfx/halo-v1/halo-energy-generated-v1.png` is a 512×512 white-alpha energy ring prepared from the user's authorized internal AI generation site. The original output was RGB on a black backdrop, not true transparency. Local emitted-light alpha preparation and color neutralization preserve its generated fine strands and bloom, allowing per-skill runtime tints. The versioned directory separates generated art from the CC0 importer-owned root files.

Original image, exact prompts, source, processing scripts and verification: `../../artifacts/generated-2026-11-18-halo-sample/`. Runtime uses the ring as a transient expanding additive layer beneath characters, not a static object attached to the hero. Follow the internal generation site's usage terms; AI provenance is not a substitute for commercial rights review.

## User-provided poison halo

`vfx/halo-user-v1/poison-halo.png` preserves the green/cyan strands and bubbles from the user's supplied RGB image. The original contained a painted grey checkerboard; local approximate emitted-light extraction prepares real RGBA, not a new AI generation or lossless recovery of absent alpha. It replaces only poison imagery, with the generic halo as fallback. Archived source, hashes, script, unit/runtime tests and live module captures are in `../../artifacts/user-poison-halo-2026-11-18/`.

## User-provided ketchup halo and current follow behavior

`vfx/halo-user-v1/ketchup-halo.png` is the user's red liquid ring, with source RGBA/alpha preserved and only a Lanczos resize to512×512. It is not regenerated or color-neutralized. Source, hashes, deterministic import report and browser evidence: `../../artifacts/user-ketchup-halo-2026-11-18/`.

Both skill wave centers, imagery and mote origins now follow the current hero every render update; visual radius immediately matches the current aura profile. Expansion/rotation/fade ages are independent of movement. User poison stays additive green/cyan; user ketchup uses normal red blending with0.65peak alpha beneath characters. Missing user artwork falls back to the per-skill-tinted generic ring, then to code outlines if the generic image is also unavailable. Earlier poison captures document the superseded world-origin-snapshot behavior, not the current follow implementation.
