# Potato Hunter Assets

Greybox art drops live here. Keep filenames aligned with `src/configs/assets.json`.

Missing images are allowed during prototype work; the game falls back to shape-based placeholders.

## Generated energy halo

`vfx/halo-v1/halo-energy-generated-v1.png` is a 512×512 white-alpha energy ring prepared from the user's authorized internal AI generation site. The original output was RGB on a black backdrop, not true transparency. Local emitted-light alpha preparation and color neutralization preserve its generated fine strands and bloom, allowing per-skill runtime tints. The versioned directory separates generated art from the CC0 importer-owned root files.

Original image, exact prompts, source, processing scripts and verification: `../../artifacts/generated-2026-11-18-halo-sample/`. Runtime uses the ring as a transient expanding additive layer beneath characters, not a static object attached to the hero. Follow the internal generation site's usage terms; AI provenance is not a substitute for commercial rights review.

## User-provided poison halo

`vfx/halo-user-v1/poison-halo.png` preserves the green/cyan strands and bubbles from the user's supplied RGB image. The original contained a painted grey checkerboard; local approximate emitted-light extraction prepares real RGBA, not a new AI generation or lossless recovery of absent alpha. It replaces only poison imagery, with the generic halo as fallback. Archived source, hashes, script, unit/runtime tests and live module captures are in `../../artifacts/user-poison-halo-2026-11-18/`.

## User-provided ketchup halo and current follow behavior

`vfx/halo-user-v1/ketchup-halo.png` is the user's red liquid ring, with source RGBA/alpha preserved and only a Lanczos resize to512×512. It is not regenerated or color-neutralized. Source, hashes, deterministic import report and browser evidence: `../../artifacts/user-ketchup-halo-2026-11-18/`.

Both skill wave centers, imagery and mote origins now follow the current hero every render update; visual radius immediately matches the current aura profile. Expansion/rotation/fade ages are independent of movement. User poison stays additive green/cyan; user ketchup uses normal red blending with0.65peak alpha beneath characters. Missing user artwork falls back to the per-skill-tinted generic ring, then to code outlines if the generic image is also unavailable. Earlier poison captures document the superseded world-origin-snapshot behavior, not the current follow implementation.

## Archived Pepper weapon pilot

The experimental held weapons (`weapons/pepper-*-shengong-v1.png`) and support arm are retained as references but are not loaded. Both skills use the original `icons/skills/fries_storm.png` icon and the hero uses both authored arms. See `docs/pepper-weapon-art-provenance.md` for the pilot source and conversion details.

The old `weapons/pepper-*.svg` silhouettes are also inactive. The active `projectiles/pepper-*.svg` are small original hand-authored VFX layers, not generated images. They still use the existing particle textures and rapid-launch audio.

## Spatial skill icons

`icons/skills/starch-spikes-sg-v1.png` and `icons/skills/roast-turret-sg-v1.png` are 192×192 transparent 神工 renders. Each is shared by its base card, its evolution card and the matching battlefield sprite; the evolution frame and ground cues differentiate the upgraded forms. `src/systems/SpatialSkillView.ts` reads deployment state and layers the images above their contact shadows. See `docs/spatial-skill-art-provenance.md` for source and export details.

## Brackeys combat effects

`vfx/brackeys-boss-v1/` ships five imported flipbook atlases and one muzzle mask from the Brackeys VFX Bundle. The pinned upstream [project and CC0 license](https://github.com/Brackeys/vfx-in-godot/blob/23b58f272b828b0a894ed7ef72fbf9033ee9d177/README.md#license) and per-file provenance are recorded in [`sources.json`](vfx/brackeys-boss-v1/sources.json). Only repacked frames are served: `python3 scripts/import-brackeys-boss-vfx.py /path/to/pinned/checkout` reproduces them with Pillow and WebP support. The rendered smoke source is arranged as 5×5 despite its `8x8` filename. The custom Tomato and Poison circles are unchanged.

## Enemy skill flipbooks and sourcing order

`vfx/cethiel-enemy-v1/` uses Cethiel's OpenGameArt [Weapon Slash Effect](https://opengameart.org/content/weapon-slash-effect) and [Earth Impact - Magic Effect](https://opengameart.org/content/earth-impact-magic-effect), each marked CC0 on its author page. The four WebP sheets are selected, proportionally resized PNG frames; the impact debris is recolored orange and icy blue. [`sources.json`](vfx/cethiel-enemy-v1/sources.json) records exact inputs, license, palettes and SHA-256 hashes. To reproduce, fetch the two `archive` URLs to `slash.zip` and `earth.zip`, then run `python3 scripts/import-enemy-flipbooks.py /path/to/archives` (Pillow with WebP support).

For new VFX, look in this order: ParticleFX Studio → OpenGameArt → Kenney → CraftPix → itch.io → Unity Asset Store (including Jean Moreno's Cartoon FX Remaster Free). Inspect the actual frames and per-item terms before selecting anything. This is a Phaser web build: only ship textures that can be publicly served in the playable build, store credit and license evidence alongside each version, and ship only the needed compressed frames. Do not copy Unity prefab/source packages into `public/` or assume a free download or export button grants redistribution rights. The imported art supplies the visible effect; code handles placement, timing and hit boundaries.

`enemies/meadow-v1/shield-guard.webp` is a 192×192 WebP resize of the existing `bestiary/v3/shield_guard.png`, preserving the full alpha canvas and foot pivot. The battle loader can now include the lightweight texture without fetching the large bestiary portrait early.

The six other `enemies/meadow-v1/*.webp` battle sprites are 192×192 alpha-preserving exports from the matching v3/v4 portraits. The original bestiary images remain on-demand. The seven transparent `projectiles/hostile-v1/` shots are recolored composites of the existing CC0 `glow`, `trace`, `flame`, and `crystal` masks; see `vfx/sources.json` for the original artist, files, and license. Fire and contact accents reuse the imported Brackeys masks. Re-export both groups with `node scripts/export-hostile-battle-art.mjs`. No new AI-generated images were added in this pass.

`vfx/ranged-v1/` contains the amber Hot Oil Flask cutout from Pavel Kutejnikov's OpenGameArt Potion Bottle pack (CC0), and a separately cropped project fork for Long Skewer's shot and card. [`sources.json`](vfx/ranged-v1/sources.json) records the base art and exact outputs. Hot Oil's impact and sustained ground fire sample the existing Brackeys flipbooks rather than shipping another flame sheet.
