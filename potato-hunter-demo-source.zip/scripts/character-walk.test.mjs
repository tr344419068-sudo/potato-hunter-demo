import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
import { readFileSync } from "node:fs";

const root = fileURLToPath(new URL("../", import.meta.url));
const loadModel = () => import("../src/systems/CharacterWalkModel.ts").catch(() => undefined);

async function loadRuntime() {
  const output = await build({ stdin: { contents: `
    export { RenderSystem } from "./src/systems/RenderSystem.ts";
    export { SpriteJuiceSystem } from "./src/systems/SpriteJuiceSystem.ts";
    export { AutoAttackSystem } from "./src/systems/AutoAttackSystem.ts";
    export { GameScene } from "./src/scenes/GameScene.ts";
    export { HERO_RIG } from "./src/systems/AuthoredHeroModel.ts";
    export { World } from "./src/entities/World.ts";
    export { createPlayer } from "./src/entities/factories.ts";
    export { EventBus } from "./src/managers/EventBus.ts";
  `, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Scene:class{}, Events: { EventEmitter }, Scenes: { Events: { SHUTDOWN: "shutdown" } }, Display:{Color:{HexStringToColor:value=>({color:parseInt(value.slice(1),16)})}}, Utils:{Array:{Shuffle:values=>values}}, Math: { Clamp: (x,a,b)=>Math.min(b,Math.max(a,x)), Between:(a,b)=>a, FloatBetween:(a,b)=>a } };', resolveDir: root }));
  }}] });
  return import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`);
}

function displayScene(webgl = true) {
  const objects = [], shutdown = [];
  const chain = (kind, args = []) => {
    const object = { kind, destroyed: false, vertices: [] };
    if(kind==='image')object.texture=args[2];
    if (kind === "mesh") for (let index = 0; index < args[4].length; index += 2) object.vertices.push({ x: args[4][index], y: args[4][index+1], u: args[5][index], v: args[5][index+1], color: 0xffffff });
    const proxy = new Proxy(object, { get(target, key) {
      if (key in target) return target[key];
      return (...values) => { if (key === "destroy") target.destroyed = true; if (key === "setPosition") [target.x, target.y] = values;if(key==='setRotation')target.rotation=values[0]; if(key==='setScale')[target.scaleX,target.scaleY]=values; return proxy; };
    }});
    objects.push(proxy); return proxy;
  };
  return { objects, shutdown, sys: { renderer: { gl: webgl ? {} : null } }, textures: { exists: () => true }, events: { once(_event, callback) { shutdown.push(callback); } }, add: new Proxy({}, { get(_owner, kind) { return (...args) => chain(kind, args); } }) };
}

test("calibrated locomotion independently steps both boots and counter-swings both hands", async () => {
  const model = await loadModel();
  assert.ok(model?.getCharacterWalkRig && model?.deformCharacterPoint, "articulated walking model missing");
  for (const id of ["char_potato_hunter", "enemy_tomato_angry", "enemy_fries_soldier", "enemy_onion_cry", "enemy_corn_mold"]) {
    const rig = model.getCharacterWalkRig(id);
    assert.ok(rig, `${id} lacks calibrated shoulders/hips`);
    const pose = model.getCharacterWalkPose(Math.PI / 2, 160, 1, 0, 0);
    const opposite = model.getCharacterWalkPose(Math.PI * 1.5, 160, 1, 0, 0);
    const left = model.deformCharacterPoint(rig.leftFoot.x, rig.leftFoot.y, rig, pose);
    const right = model.deformCharacterPoint(rig.rightFoot.x, rig.rightFoot.y, rig, pose);
    const leftNext = model.deformCharacterPoint(rig.leftFoot.x, rig.leftFoot.y, rig, opposite);
    const rightNext = model.deformCharacterPoint(rig.rightFoot.x, rig.rightFoot.y, rig, opposite);
    assert.ok((left.x - rig.leftFoot.x) * (right.x - rig.rightFoot.x) < 0, "boots move together instead of alternating");
    assert.ok(Math.abs(left.x - leftNext.x) > 0.04 && Math.abs(right.x - rightNext.x) > 0.04);
    const hand = model.deformCharacterPoint(rig.leftHand.x, rig.leftHand.y, rig, pose);
    const otherHand = model.deformCharacterPoint(rig.rightHand.x, rig.rightHand.y, rig, pose);
    assert.ok(Math.hypot(hand.x - rig.leftHand.x, hand.y - rig.leftHand.y) > 0.01, "weapon arm remains rigid");
    assert.ok(Math.hypot(otherHand.x - rig.rightHand.x, otherHand.y - rig.rightHand.y) > 0.01, "free arm remains rigid");
    assert.ok((hand.x - rig.leftHand.x) * (left.x - rig.leftFoot.x) < 0, "left hand swings with its leg, not counter to it");
    assert.ok((otherHand.x - rig.rightHand.x) * (right.x - rig.rightFoot.x) < 0, "right hand swings with its leg, not counter to it");
    assert.ok(Math.abs(pose.bodyY) < 0.006, "whole body still hops");
  }
});

test("idle stops limb locomotion and phase scales with real travel rather than a shared bouncing clock", async () => {
  const model = await loadModel();
  assert.ok(model?.advanceWalkPhase && model?.getCharacterWalkPose, "distance-based stride model missing");
  const stopped = model.advanceWalkPhase(0.2, 0, 84);
  assert.equal(stopped, 0.2);
  const slow = model.advanceWalkPhase(0.2, 4, 84);
  const fast = model.advanceWalkPhase(0.2, 8, 84);
  assert.ok(Math.abs((fast - 0.2) / (slow - 0.2) - 2) < 1e-8);
  const rig = model.getCharacterWalkRig("char_potato_hunter");
  const idle = model.getCharacterWalkPose(2, 0, 0, 0, 0);
  for (const point of [rig.leftFoot, rig.rightFoot, rig.leftHand, rig.rightHand]) {
    const actual = model.deformCharacterPoint(point.x, point.y, rig, idle);
    assert.ok(Math.abs(actual.x - point.x) < 1e-9 && Math.abs(actual.y - point.y) < 1e-9);
  }
  assert.equal(model.getCharacterWalkRig("boss_fryer_machine"), undefined);
  assert.equal(model.getCharacterWalkRig("enemy_soda_slime"), undefined);
});

test("UV skinning is finite, bounded and does not invert the textured grid under walking or attacks", async () => {
  const model = await loadModel();
  assert.ok(model?.getCharacterWalkRig, "skinning model missing");
  for (const id of ["char_potato_hunter", "enemy_tomato_angry", "enemy_fries_soldier", "enemy_onion_cry", "enemy_corn_mold"]) {
    const rig = model.getCharacterWalkRig(id);
    for (let frame = 0; frame < 24; frame++) {
      const pose = model.getCharacterWalkPose(frame * Math.PI / 12, 240, 0.7, 0.7, frame / 24);
      const points = Array.from({ length: 17 * 17 }, (_, index) => model.deformCharacterPoint((index % 17) / 16, Math.floor(index / 17) / 16, rig, pose));
      for (let row = 0; row < 16; row++) for (let col = 0; col < 16; col++) {
        const [a, b, c] = [points[row * 17 + col], points[row * 17 + col + 1], points[(row + 1) * 17 + col]];
        const cross = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
        assert.ok(cross > 0, `${id} folds at${row}/${col}/${frame}`);
        assert.ok(Number.isFinite(a.x) && Number.isFinite(a.y));
        assert.ok(Math.abs(a.x - col / 16) < 0.16 && Math.abs(a.y - row / 16) < 0.16);
      }
    }
  }
});

test("actual character mesh owns bounded UV vertices, preserves tint/alpha/mirror and cleans removed actors", async () => {
  const model = await loadModel();
  assert.ok(model?.getCharacterWalkRig, "renderer model missing");
  const output = await build({ stdin: { contents: 'export { CharacterMeshView } from "./src/systems/CharacterMeshView.ts";', resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false, external: ["phaser"] });
  const { CharacterMeshView } = await import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`);
  const created = [];
  const scene = { sys: { renderer: { gl: {} } }, events: { once() {} }, add: { mesh(x,y,texture,frame,vertices,uvs) {
    const object = { x,y,texture, vertices: vertices.reduce((items, value, index) => { if (index % 2 === 0) items.push({ x: value, y: vertices[index + 1], u: uvs[index], v: uvs[index + 1], color: 0xffffff }); return items; }, []), destroyed: false };
    const proxy = new Proxy(object, { get(target,key) { if (key in target) return target[key]; return (...args) => { if (key === "destroy") target.destroyed = true; if (key === "setPosition") [target.x,target.y] = args; if (key === "setScale") [target.scaleX,target.scaleY] = args; if (key === "setAlpha") target.alpha = args[0]; return proxy; }; }});
    created.push(proxy); return proxy;
  } } };
  const view = new CharacterMeshView(scene);
  const data = { entityId: 1, assetId: "char_potato_hunter", textureKey: "asset:char_potato_hunter", x: 0, y: 0, worldX: 0, worldY: 0, visualSize: 84, pivot: { x:0.5, y:0.65 }, scaleX: 1, scaleY: 1, rotation: 0, tint: undefined, alpha: 1, deltaMs: 16 };
  assert.equal(view.draw(data), true);
  const mesh = created[0];
  assert.ok(mesh.vertices.length >= 600 && mesh.vertices.length <= 3000);
  const before = mesh.vertices.map(vertex => [vertex.x, vertex.y]);
  view.draw({ ...data, x: 4, worldX: 4, scaleX: -1, alpha: 0.4, tint: 0x69e8ff });
  assert.equal(mesh.alpha, 0.4); assert.equal(mesh.scaleX, -1);
  assert.ok(mesh.vertices.every(vertex => vertex.color === 0x69e8ff));
  assert.ok(mesh.vertices.some((vertex,index) => vertex.x !== before[index][0] || vertex.y !== before[index][1]));
  assert.ok(mesh.vertices.every(vertex => vertex.u >= 0 && vertex.u <= 1 && vertex.v >= 0 && vertex.v <= 1));
  view.prune(new Set()); assert.ok(mesh.destroyed);
  view.draw(data); view.destroy(); assert.ok(created[1].destroyed);
});

test("both actual mesh triangles stay positive at full attack for every walking direction", async () => {
  const model = await loadModel();
  for (const id of ["char_potato_hunter", "enemy_tomato_angry", "enemy_fries_soldier", "enemy_onion_cry", "enemy_corn_mold"]) {
    const rig = model.getCharacterWalkRig(id);
    const gridX = id === "char_potato_hunter" ? 20 : 12, gridY = id === "char_potato_hunter" ? 20 : 14;
    for (let direction = 0; direction < 8; direction++) for (let frame = 0; frame < 24; frame++) {
      const angle = direction * Math.PI / 4;
      const pose = model.getCharacterWalkPose(frame * Math.PI / 12, 240, Math.cos(angle), Math.sin(angle), 1);
      const points = Array.from({ length: (gridX + 1) * (gridY + 1) }, (_, index) => model.deformCharacterPoint((index % (gridX+1)) / gridX, Math.floor(index / (gridX+1)) / gridY, rig, pose));
      for (let row = 0; row < gridY; row++) for (let col = 0; col < gridX; col++) {
        const [a,b,c,d] = [points[row*(gridX+1)+col],points[row*(gridX+1)+col+1],points[(row+1)*(gridX+1)+col],points[(row+1)*(gridX+1)+col+1]];
        for (const [p,q,r] of [[a,b,c],[b,d,c]]) assert.ok((q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x)>0, `${id} mesh folds at${row}/${col}/${frame}/${direction}`);
      }
    }
  }
});

test("production mesh projects creation, gait and size changes in the same scene-update frame", async () => {
  const require = createRequire(import.meta.url);
  const GenerateVerts = require("phaser/src/geom/mesh/GenerateVerts.js");
  const Matrix4 = require("phaser/src/math/Matrix4.js"), Vector3 = require("phaser/src/math/Vector3.js");
  const source = readFileSync(require.resolve("phaser/src/gameobjects/mesh/Mesh.js"), "utf8").replace(/\r/g, "");
  const method = source.match(/preUpdate: (function \(\)[\s\S]*?)\n    },\n/);
  assert.ok(method, "installed primary Phaser projection method missing");
  const realPreUpdate = new Function(`return (${method[1]}\n})`)();
  const output = await build({ stdin: { contents: 'export { CharacterMeshView } from "./src/systems/CharacterMeshView.ts";', resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false, external: ["phaser"] });
  const { CharacterMeshView } = await import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`);
  const automatic = new Set(); let mesh;
  const scene = { sys: { renderer: { gl: {} }, updateList: { remove(actor) { automatic.delete(actor); } } }, events: { once() {} }, add: { mesh(x,y,key,frame,vertices,uvs) {
    mesh = { ...GenerateVerts(vertices, uvs), totalRendered: 0, totalFrame: 0, dirtyCache: Array(12).fill(0), viewMatrix: new Matrix4(), viewPosition: new Vector3(), transformMatrix: new Matrix4(), modelRotation: new Vector3(), modelPosition: new Vector3(), modelScale: new Vector3(1,1,1), projectionMatrix: new Matrix4(), preUpdate: realPreUpdate, depthSort() {},
      setSize(width,height) { this.width=width; this.height=height; return this; }, setOrtho(x,y) { this.projectionMatrix.ortho(-x,x,-y,y,-1000,1000); this.dirtyCache[10]=1; },
    };
    const proxy = new Proxy(mesh, { get(target, property) { if (property in target) return target[property]; return () => proxy; } });
    automatic.add(proxy); return proxy;
  } } };
  const view = new CharacterMeshView(scene);
  const data = { entityId: 1, assetId: "char_potato_hunter", textureKey: "hero", x: 0, y: 0, worldX: 0, worldY: 0, visualSize: 84, pivot: { x:.5,y:.65 }, scaleX: 1,scaleY: 1,rotation: 0,alpha: 1,deltaMs: 16 };
  view.draw(data);
  assert.ok(mesh.vertices.some(vertex => Math.abs(vertex.vx)>30), "created mesh is invisible until next preUpdate");
  assert.equal(automatic.size, 0, "owned mesh is still automatically projected before Scene.update");
  view.draw({ ...data, worldX: 4, visualSize: 100 });
  for (const vertex of mesh.vertices) {
    assert.ok(Math.abs(vertex.vx - vertex.x * 100) < 1e-7, "gait or size projects one frame late");
    assert.ok(Math.abs(vertex.vy + vertex.y * 100) < 1e-7, "vertical geometry projects one frame late");
  }
});

test("missing authored parts retain the animated mesh and Canvas fallbacks for original hero art", async () => {
  const { RenderSystem, World, createPlayer } = await loadRuntime();
  for (const webgl of [true, false]) {
    const scene = displayScene(webgl), world = new World();
    scene.textures.exists=key=>!key.startsWith('asset:hero_part_');
    const playerId = createPlayer(world, 0, 0, 210, 100, 100, "char_potato_hunter");
    const runtime = { scene, world, playerId, skillManager: { getAuraProfiles: () => [] }, stats: { elapsedMs: 0 } };
    const render = new RenderSystem(scene, scene.add.graphics());
    render.update(16, runtime);
    const actor = scene.objects.find(object => object.kind === (webgl ? "mesh" : "image"));
    assert.ok(actor, webgl ? "rigged hero still uses a static image" : "Canvas hero disappears");
    if (webgl) {
      const vertices = actor.vertices.map(point => [point.x, point.y]);
      world.components.transforms.get(playerId).x += 4;
      render.update(16, runtime);
      assert.ok(actor.vertices.some((point, index) => point.x !== vertices[index][0] || point.y !== vertices[index][1]), "physical movement did not articulate limbs");
      const stationary = actor.vertices.map(point => [point.x, point.y]);
      render.update(16, runtime);
      const idle = actor.vertices.map(point => [point.x, point.y]);
      render.update(16, runtime);
      assert.deepEqual(actor.vertices.map(point => [point.x, point.y]), idle, "stationary legs keep walking");
      assert.notDeepEqual(stationary, idle);
    }
    world.destroyEntity(playerId); render.update(16, runtime);
    assert.ok(actor.destroyed, "removed hero leaves renderer resource behind");
    scene.shutdown.forEach(callback => callback());
  }
});

test('complete K1 sheets replace the old body with one image, keep its foot point, and react to actual HP loss', async () => {
  const { RenderSystem, World, createPlayer } = await loadRuntime();
  const scene = displayScene(false), world = new World();
  const playerId = createPlayer(world, 100, 200, 210, 100, 100, 'char_potato_hunter');
  const runtime = { scene, world, playerId, skillManager: { getAuraProfiles: () => [] }, stats: { elapsedMs: 0 } };
  scene.textures.getFrame = (key, frame) => key.startsWith('asset:hero_k1_') ? { name: String(frame) } : null;
  const images = [], originalAdd = scene.add;
  scene.add = new Proxy({}, { get(_, key) { return key === 'image' ? (x, y, texture, frame) => {
    const image = {
      x, y, texture: { key: texture }, frame: { name: String(frame) },
      setOrigin() { return this; }, setDepth() { return this; }, setDisplaySize() { return this; }, setFlipX() { return this; }, setAlpha() { return this; },
      setTexture(key, frame) { this.texture = { key }; return this.setFrame(frame); },
      setFrame(frame) { this.frame.name = String(frame); return this; },
      setPosition(x, y) { this.x = x; this.y = y; return this; }, destroy() { this.destroyed = true; },
    };
    images.push(image); return image;
  } : originalAdd[key]; }});
  const render = new RenderSystem(scene, scene.add.graphics()), shadows = [];
  render.drawCharacterShadow = (x, y, _size, kind) => { if (kind === 'hero') shadows.push({x, y}); };
  render.update(16, runtime);
  assert.equal(images.length, 1);
  const hero = images[0];
  assert.equal(hero.texture.key, 'asset:hero_k1_idle');
  assert.deepEqual(shadows.at(-1), {x: hero.x, y: hero.y});
  world.components.health.get(playerId).current = 75;
  render.update(16, runtime);
  assert.equal(hero.texture.key, 'asset:hero_k1_hit');
  world.components.health.get(playerId).current = 0;
  render.update(16, runtime);
  assert.equal(hero.texture.key, 'asset:hero_k1_down');
  world.destroyEntity(playerId);
  render.update(16, runtime);
  assert.equal(hero.destroyed, true);
});

test('K1 keeps a telegraphed blade release visible when another weapon fires in the same step', async () => {
  const { SpriteJuiceSystem, World, createPlayer, EventBus } = await loadRuntime();
  const scene = displayScene(false), world = new World();
  const playerId = createPlayer(world, 0, 0, 210, 100, 100, 'char_potato_hunter');
  const juice = new SpriteJuiceSystem(scene), runtime = { scene, world, playerId };
  const blade = { world, playerId, skillId: 'peeler_blade', directionX: -1, directionY: 0, remainingMs: 55 };
  const shot = { ...blade, skillId: 'pepper_gatling', directionX: 1 };
  const release = () => world.components.spriteJuices.get(playerId).heroRelease;
  try {
    EventBus.emit('weapon:windup', blade);
    juice.update(16, runtime);
    EventBus.emit('weapon:fired', blade);
    EventBus.emit('weapon:fired', shot);
    juice.update(16, runtime);
    assert.equal(release().action, 'slash');
    const first = release().sequence;
    EventBus.emit('weapon:fired', { ...shot, directionX: 0, heroFacingX: -1 });
    juice.update(16, runtime);
    assert.equal(release().action, 'shoot');
    assert.equal(release().directionX, -1);
    assert.ok(release().sequence > first);
  } finally { juice.destroy(); }
});
test('production articulated hero walks on Canvas/WebGL and shadows stay at grounded feet instead of following whole-sprite squash',async()=>{
 const {RenderSystem,World,createPlayer}=await loadRuntime();for(const webgl of [true,false]){
  const scene=displayScene(webgl),world=new World(),playerId=createPlayer(world,0,0,210,100,100,'char_potato_hunter');
  const runtime={scene,world,playerId,skillManager:{getAuraProfiles:()=>[]},stats:{elapsedMs:0}},render=new RenderSystem(scene,scene.add.graphics()),shadows=[];
  const draw=render.drawCharacterShadow.bind(render);render.drawCharacterShadow=(...args)=>{shadows.push(args);return draw(...args)};
  render.update(16,runtime);const parts=scene.objects.filter(o=>o.kind==='image');assert.equal(parts.length,7);const pose=parts.map(p=>[p.x,p.y,p.rotation]);
  world.components.transforms.get(playerId).x+=4;render.update(16,runtime);assert.notDeepEqual(parts.map(p=>[p.x,p.y,p.rotation]),pose);
  const ground=shadows.at(-1).slice(0,2);world.components.spriteJuices.set(playerId,{offsetX:3,offsetY:-4,scaleX:.6,scaleY:.8,rotation:.7,facingX:1,shadowScaleX:2,shadowScaleY:2,shadowAlpha:.2});render.update(16,runtime);
  assert.deepEqual(shadows.at(-1).slice(0,2),ground);const frozen=parts.map(p=>[p.x,p.y,p.rotation]);render.update(0,runtime);assert.deepEqual(parts.map(p=>[p.x,p.y,p.rotation]),frozen);
  world.destroyEntity(playerId);render.update(16,runtime);assert.ok(parts.every(p=>p.destroyed));
 }
});

test('actual articulated boots plant in world space during physical horizontal travel', async () => {
  const { RenderSystem, World, createPlayer, HERO_RIG } = await loadRuntime();
  for (const direction of [1, -1]) for (const webgl of [true, false]) {
    const scene = displayScene(webgl), world = new World();
    const playerId = createPlayer(world, 0, 0, 210, 100, 100, 'char_potato_hunter');
    const runtime = { scene, world, playerId, skillManager: { getAuraProfiles: () => [] }, stats: { elapsedMs: 0 } };
    const render = new RenderSystem(scene, scene.add.graphics());
    world.components.spriteJuices.set(playerId, { facingX: direction });
    render.update(16, runtime);
    const boots = ['left_boot', 'right_boot'].map(id => scene.objects.find(object => object.texture === `asset:hero_part_${id}`));
    const foot = (image, id) => {
      const bone = HERO_RIG[id], localX = (bone.end.x - bone.joint.x) * image.scaleX, localY = (bone.end.y - bone.joint.y) * image.scaleY;
      return { x: image.x + localX * Math.cos(image.rotation) - localY * Math.sin(image.rotation), y: image.y + localX * Math.sin(image.rotation) + localY * Math.cos(image.rotation) };
    };
    let previous = boots.map((image, index) => foot(image, index ? 'right_boot' : 'left_boot'));
    let lockedFrames = 0;
    for (let frame = 0; frame < 70; frame++) {
      world.components.transforms.get(playerId).x += direction * 210 * .016;
      render.update(16, runtime);
      const current = boots.map((image, index) => foot(image, index ? 'right_boot' : 'left_boot'));
      if (current.some((point, index) => Math.hypot(point.x - previous[index].x, point.y - previous[index].y) < .05)) lockedFrames++;
      assert.ok(current.every(point => Number.isFinite(point.x) && Number.isFinite(point.y)));
      previous = current;
    }
    assert.ok(lockedFrames >= 12, `actual stance boots skate with the body (${lockedFrames} anchored frames, direction ${direction})`);
  }
});

test('vertical and diagonal physical movement retain measurable stance without stretched or detached limbs', async () => {
  const { RenderSystem, World, createPlayer, HERO_RIG } = await loadRuntime();
  for (const angle of [Math.PI / 2, -Math.PI / 2, Math.PI / 4, Math.PI * .75]) {
    const scene = displayScene(), world = new World(), playerId = createPlayer(world, 0, 0, 210, 100, 100, 'char_potato_hunter');
    const runtime = { scene, world, playerId, skillManager: { getAuraProfiles: () => [] }, stats: { elapsedMs: 0 } }, render = new RenderSystem(scene, scene.add.graphics());
    const facing = Math.cos(angle) < -.1 ? -1 : 1;
    world.components.spriteJuices.set(playerId, { facingX: facing }); render.update(16, runtime);
    const endpoint = id => {
      const image = scene.objects.find(object => object.texture === `asset:hero_part_${id}`), bone = HERO_RIG[id];
      const localX = (bone.end.x - bone.joint.x) * image.scaleX, localY = (bone.end.y - bone.joint.y) * image.scaleY;
      return { x: image.x + localX * Math.cos(image.rotation) - localY * Math.sin(image.rotation), y: image.y + localX * Math.sin(image.rotation) + localY * Math.cos(image.rotation) };
    };
    let previous = ['left_boot', 'right_boot'].map(endpoint), lockedFrames = 0;
    for (let frame = 0; frame < 80; frame++) {
      const position = world.components.transforms.get(playerId); position.x += Math.cos(angle) * 210 * .016; position.y += Math.sin(angle) * 210 * .016;
      render.update(16, runtime);
      const current = ['left_boot', 'right_boot'].map(endpoint);
      if (current.some((point, index) => Math.hypot(point.x - previous[index].x, point.y - previous[index].y) < .05)) lockedFrames++;
      assert.ok(current.every((point, index) => Math.hypot(point.x - previous[index].x, point.y - previous[index].y) < 8), `foot teleports at ${angle}, frame ${frame}: ${current.map((point,index)=>Math.hypot(point.x-previous[index].x,point.y-previous[index].y)).join(', ')}`);
      for (const side of ['left', 'right']) {
        const knee = endpoint(`${side}_thigh`), boot = scene.objects.find(object => object.texture === `asset:hero_part_${side}_boot`);
        assert.ok(Math.hypot(knee.x - boot.x, knee.y - boot.y) < 1e-6, 'boot detached from its knee');
        assert.ok(Math.abs(Math.abs(boot.scaleX) - 84 / 256) < 1e-8 && Math.abs(boot.scaleY - 84 / 256) < 1e-8, 'stance is faked by stretching source limbs');
      }
      previous = current;
    }
    assert.ok(lockedFrames >= 8, `stance lock is unobservable at normal frame rate (${lockedFrames} frames, direction ${angle})`);
    const frozen = scene.objects.filter(object => object.kind === 'image').map(object => [object.x, object.y, object.rotation]);
    render.update(0, runtime);
    assert.deepEqual(scene.objects.filter(object => object.kind === 'image').map(object => [object.x, object.y, object.rotation]), frozen);
  }
});

test('changing facing during a stride reassigns grounded boots without a distant foot pop', async () => {
  const { RenderSystem, World, createPlayer, HERO_RIG } = await loadRuntime();
  const scene = displayScene(), world = new World(), playerId = createPlayer(world, 0, 0, 210, 100, 100, 'char_potato_hunter');
  const runtime = { scene, world, playerId, skillManager: { getAuraProfiles: () => [] }, stats: { elapsedMs: 0 } }, render = new RenderSystem(scene, scene.add.graphics());
  const feet = () => ['left_boot', 'right_boot'].map(id => {
    const image = scene.objects.find(object => object.texture === `asset:hero_part_${id}`), bone = HERO_RIG[id];
    const localX = (bone.end.x - bone.joint.x) * image.scaleX, localY = (bone.end.y - bone.joint.y) * image.scaleY;
    return { x: image.x + localX * Math.cos(image.rotation) - localY * Math.sin(image.rotation), y: image.y + localX * Math.sin(image.rotation) + localY * Math.cos(image.rotation) };
  });
  render.update(16, runtime);
  for (let frame = 0; frame < 45; frame++) {
    const previous = feet(), direction = frame < 20 ? 1 : -1;
    world.components.transforms.get(playerId).x += direction * 210 * .016;
    world.components.spriteJuices.set(playerId, { facingX: direction }); render.update(16, runtime);
    assert.ok(feet().every(point => previous.some(last => Math.hypot(point.x - last.x, point.y - last.y) < 8)), `turn creates a distant boot at frame ${frame}`);
  }
});

test('stopping physical movement settles a lifted boot onto the ground instead of freezing it in midair', async () => {
  const { RenderSystem, World, createPlayer, HERO_RIG } = await loadRuntime();
  const scene = displayScene(), world = new World(), playerId = createPlayer(world, 0, 0, 210, 100, 100, 'char_potato_hunter');
  const runtime = { scene, world, playerId, skillManager: { getAuraProfiles: () => [] }, stats: { elapsedMs: 0 } }, render = new RenderSystem(scene, scene.add.graphics());
  render.update(16, runtime);
  for (let frame = 0; frame < 20; frame++) { world.components.transforms.get(playerId).x += 210 * .016; render.update(16, runtime); }
  for (let frame = 0; frame < 10; frame++) render.update(16, runtime);
  for (const id of ['left_boot', 'right_boot']) {
    const image = scene.objects.find(object => object.texture === `asset:hero_part_${id}`), bone = HERO_RIG[id];
    const heelY = image.y + Math.sin(image.rotation) * (bone.end.x - bone.joint.x) * image.scaleX + Math.cos(image.rotation) * (bone.end.y - bone.joint.y) * image.scaleY;
    assert.ok(Math.abs(heelY - (241 / 256 - .65) * 84) < .1, 'idle boot remains suspended at its last swing pose');
  }
});

test('real projectile releases coincide with rendered authored contact, including rapid multiweapon fire', async () => {
  const { RenderSystem, SpriteJuiceSystem, AutoAttackSystem, World, createPlayer, EventBus } = await loadRuntime();
  const weapon = (skillId, cooldownMs) => ({ skillId, name: skillId, color: 0xffffff, tags: [], cooldownMs, damage: 1, projectileSpeed: 300, projectileCount: 1, pierce: 0, lifetimeMs: 1000, size: 5, spread: 0, effects: [], critChance: 0, critMultiplier: 1, vfxKind: 'kinetic' });
  for (const profiles of [[weapon('slow', 320)], [weapon('rapid', 48), weapon('other', 80), weapon('third', 144)]]) {
    const scene = displayScene(), world = new World(), playerId = createPlayer(world, 0, 0, 210, 100, 100, 'char_potato_hunter');
    const monsterId = world.createEntity();
    world.components.transforms.set(monsterId, { x: 100, y: 0, radius: 10 });
    world.components.health.set(monsterId, { current: 100, max: 100 });
    world.components.monsters.set(monsterId, { behavior: 'chaser' });
    const runtime = { scene, world, playerId, skillManager: { getLevel: () => 0, getWeaponProfiles: () => profiles, getAuraProfiles: () => [] }, stats: { elapsedMs: 0 } };
    const juice = new SpriteJuiceSystem(scene), attack = new AutoAttackSystem(), render = new RenderSystem(scene, scene.add.graphics());
    let time = 0, previousRotation = 0;
    const releases = [], contacts = [], visibleContacts = [], windups = [], recoilAngles = [], releasesBySkill = new Map();
    const fired = payload => { releases.push(time); const times = releasesBySkill.get(payload.skillId) ?? []; times.push(time); releasesBySkill.set(payload.skillId, times); assert.ok(world.components.projectiles.size > 0, 'event does not describe a real projectile release'); };
    EventBus.on('weapon:fired', fired);
    try {
      for (let frame = 0; frame < 65; frame++) {
        time += 16; attack.update(16, runtime); juice.update(16, runtime); render.update(16, runtime);
        const rotation = scene.objects.find(object => object.texture === 'asset:hero_part_left_arm').rotation;
        if (rotation < -.15) windups.push(time);
        if (rotation >= .29) visibleContacts.push(time);
        if (releases.includes(time)) recoilAngles.push(rotation);
        if (rotation >= .29 && previousRotation < .29) contacts.push(time);
        previousRotation = rotation;
      }
      assert.ok(visibleContacts.length >= 3, 'rapid-fire never visibly reaches authored contact');
      assert.ok(Math.abs(contacts[0] - releases[0]) <= 40, `first contact is ${contacts[0] - releases[0]}ms after the actual projectile release`);
      for (const contact of contacts) assert.ok(releases.some(release => Math.abs(release - contact) <= 40), `rendered contact at ${contact}ms has no projectile release within one simulation slice`);
      const missedReleases = releases.filter(release => !visibleContacts.some(contact => contact >= release && contact - release <= 40));
      assert.deepEqual(missedReleases, [], 'real releases are silently dropped by presentation');
      if (profiles.length === 1) {
        assert.deepEqual(releases, [16, 336, 656, 976], 'animation changes numerical fire latency or cooldown');
        assert.ok(windups.some(windup => windup > releases[0] && windup < releases[1]), 'subsequent fire has no rendered pre-release windup');
      }
      else {
        assert.equal(releases.length, 43); assert.equal(world.components.projectiles.size, 43);
        for (const profile of profiles) assert.deepEqual(releasesBySkill.get(profile.skillId), Array.from({ length: Math.floor((1040 - 16) / profile.cooldownMs) + 1 }, (_, index) => 16 + index * profile.cooldownMs), 'per-shot presentation changes cadence');
        assert.ok(Math.max(...recoilAngles) - Math.min(...recoilAngles) > .01, 'rapid aiming pose has no per-shot recoil');
        assert.ok([...world.components.projectiles.values()].every(projectile => projectile.damage === 1), 'presentation changes damage');
      }
      world.components.health.get(monsterId).current = 0;
      for (let frame = 0; frame < 20; frame++) { attack.update(16, runtime); juice.update(16, runtime); render.update(16, runtime); }
      const arm = scene.objects.find(object => object.texture === 'asset:hero_part_left_arm'), body = scene.objects.find(object => object.texture === 'asset:hero_part_body');
      assert.equal(world.components.spriteJuices.get(playerId).attackProgress, 1);
      assert.ok(Math.abs(arm.rotation - body.rotation) < .005, 'firing stops but sustained strike never fully recovers');
    } finally { EventBus.off('weapon:fired', fired); juice.destroy(); }
  }
});

test('production GameScene preserves a frame-visible release contact across 80ms and 250ms simulation catch-up', async () => {
  const { GameScene, AutoAttackSystem, SpriteJuiceSystem, RenderSystem, createPlayer, EventBus } = await loadRuntime();
  for (const deltaMs of [80, 250]) {
    const display = displayScene(), game = new GameScene(); Object.assign(game, display);
    game.cameras = { main: { width: 1280, height: 720 } };
    game.playerId = createPlayer(game.world, 0, 0, 210, 100, 100, 'char_potato_hunter');
    const targetId = game.world.createEntity();
    game.world.components.transforms.set(targetId, { x: 100, y: 0, radius: 10 });
    game.world.components.health.set(targetId, { current: 100, max: 100 }); game.world.components.monsters.set(targetId, { behavior: 'chaser' });
    const weapon = { skillId: 'slow-frame', name: 'slow-frame', color: 0xffffff, tags: [], cooldownMs: 320, damage: 1, projectileSpeed: 300, projectileCount: 1, pierce: 0, lifetimeMs: 1000, size: 5, spread: 0, effects: [], critChance: 0, critMultiplier: 1, vfxKind: 'kinetic' };
    game.skillManager.getWeaponProfiles = () => [weapon];
    const juice = new SpriteJuiceSystem(game); game.systems = [new AutoAttackSystem(), juice];
    game.renderSystem = new RenderSystem(game, game.add.graphics());
    game.renderSystem.update(0, game.createRuntime());
    const releases = [], fired = () => releases.push(game.stats.elapsedMs); EventBus.on('weapon:fired', fired);
    try {
      game.update(0, deltaMs);
      const arm = display.objects.find(object => object.texture === 'asset:hero_part_left_arm');
      assert.deepEqual(releases, [40], 'presentation latch changes first numerical fire time');
      assert.equal(game.world.components.projectiles.size, 1);
      assert.ok(arm.rotation >= .29, `${deltaMs}ms first screen frame consumed contact invisibly (rotation ${arm.rotation})`);
      const firstRotation = arm.rotation;
      game.update(0, 16);
      assert.notEqual(arm.rotation, firstRotation, 'already-rendered release keeps relatching instead of recovering');
      game.paused = true; const paused = arm.rotation; game.update(0, 250); assert.equal(arm.rotation, paused);
    } finally { EventBus.off('weapon:fired', fired); juice.destroy(); }
  }
});

test('production 250ms frames coalesce rapid loadout releases into a visible latest-shot recoil without replaying stale pulses', async () => {
  const { GameScene, AutoAttackSystem, SpriteJuiceSystem, RenderSystem, createPlayer, EventBus } = await loadRuntime();
  const display = displayScene(), game = new GameScene(); Object.assign(game, display);
  game.cameras = { main: { width: 1280, height: 720 } }; game.playerId = createPlayer(game.world, 0, 0, 210, 100, 100, 'char_potato_hunter');
  const targetId = game.world.createEntity(); game.world.components.transforms.set(targetId, { x: 100, y: 0, radius: 10 });
  game.world.components.health.set(targetId, { current: 100, max: 100 }); game.world.components.monsters.set(targetId, { behavior: 'chaser' });
  const profiles = [48, 80, 144].map(cooldownMs => ({ skillId: `rapid-${cooldownMs}`, name: 'rapid', color: 0xffffff, tags: [], cooldownMs, damage: 1, projectileSpeed: 300, projectileCount: 1, pierce: 0, lifetimeMs: 1000, size: 5, spread: 0, effects: [], critChance: 0, critMultiplier: 1, vfxKind: 'kinetic' }));
  game.skillManager.getWeaponProfiles = () => profiles;
  const juice = new SpriteJuiceSystem(game); game.systems = [new AutoAttackSystem(), juice]; game.renderSystem = new RenderSystem(game, game.add.graphics());
  game.renderSystem.update(0, game.createRuntime());
  const releases = [], fired = payload => releases.push([payload.skillId, game.stats.elapsedMs]); EventBus.on('weapon:fired', fired);
  try {
    game.update(0, 250);
    assert.deepEqual(releases, [['rapid-48',40],['rapid-80',40],['rapid-144',40],['rapid-48',120],['rapid-80',120],['rapid-48',200],['rapid-80',200],['rapid-144',200],['rapid-48',250]]);
    assert.equal(game.world.components.projectiles.size, 9);
    assert.equal(game.world.components.spriteJuices.get(game.playerId).weaponReleaseSequence, 9);
    const arm = display.objects.find(object => object.texture === 'asset:hero_part_left_arm'); assert.ok(arm.rotation >= .29);
    game.world.components.health.get(targetId).current = 0;
    game.update(0, 250); game.update(0, 16);
    const body = display.objects.find(object => object.texture === 'asset:hero_part_body'); assert.ok(Math.abs(arm.rotation-body.rotation)<.005, 'a displayed coalesced release remains latched forever');
    assert.equal(game.world.components.projectiles.size, 9);
  } finally { EventBus.off('weapon:fired', fired); juice.destroy(); }
});

test('weapon releases overlap hit and dash bodies without silently consuming their arm contact', async () => {
  const { AutoAttackSystem, SpriteJuiceSystem, RenderSystem, World, createPlayer } = await loadRuntime();
  for (const overlap of ['hit', 'dash']) {
    const scene = displayScene(), world = new World(), playerId = createPlayer(world, 0, 0, 210, 100, 100, 'char_potato_hunter'), targetId = world.createEntity();
    world.components.transforms.set(targetId, { x: 100, y: 0, radius: 10 });
    world.components.health.set(targetId, { current: 100, max: 100 }); world.components.monsters.set(targetId, { behavior: 'chaser' });
    const weapon = { skillId: 'overlap', name: 'overlap', color: 0xffffff, tags: [], cooldownMs: 320, damage: 1, projectileSpeed: 300, projectileCount: 1, pierce: 0, lifetimeMs: 1000, size: 5, spread: 0, effects: [], critChance: 0, critMultiplier: 1, vfxKind: 'kinetic' };
    const runtime = { scene, world, playerId, skillManager: { getLevel: () => 0, getWeaponProfiles: () => [weapon], getAuraProfiles: () => [] }, stats: { elapsedMs: 0 } };
    const attack = new AutoAttackSystem(), juice = new SpriteJuiceSystem(scene), render = new RenderSystem(scene, scene.add.graphics());
    try {
      for (let frame = 0; frame < 23; frame++) {
        if (frame === 19) {
          if (overlap === 'hit') world.components.hitFlashes.set(playerId, { remainingMs: 180, totalMs: 180 });
          else world.components.players.get(playerId).dashRemainingMs = 180;
        }
        attack.update(16, runtime); juice.update(16, runtime); render.update(16, runtime);
        if (frame === 20) {
          const arm = scene.objects.find(object => object.texture === 'asset:hero_part_left_arm'), body = scene.objects.find(object => object.texture === 'asset:hero_part_body');
          assert.ok(arm.rotation - body.rotation >= .29, `${overlap} consumed the 336ms release without independent arm contact`);
          assert.ok(Math.abs(body.rotation) > .005, `${overlap} body was replaced by a plain attack pose`);
        }
      }
      assert.equal(world.components.projectiles.size, 2);
    } finally { juice.destroy(); }
  }
});

test('authored contact and windup listeners reset safely for a fresh runtime owner', async () => {
  const { SpriteJuiceSystem, AutoAttackSystem, World, createPlayer, EventBus } = await loadRuntime();
  const scene = displayScene(), juice = new SpriteJuiceSystem(scene), attack = new AutoAttackSystem();
  const before = EventBus.listenerCount('weapon:windup');
  try {
    for (let restart = 0; restart < 3; restart++) {
      const world = new World(), playerId = createPlayer(world, 0, 0, 210, 100, 100, 'char_potato_hunter'), targetId = world.createEntity();
      world.components.transforms.set(targetId, { x: 100, y: 0, radius: 10 });
      world.components.health.set(targetId, { current: 100, max: 100 }); world.components.monsters.set(targetId, { behavior: 'chaser' });
      const weapon = { skillId: 'restart', name: 'restart', color: 0xffffff, tags: [], cooldownMs: 320, damage: 1, projectileSpeed: 300, projectileCount: 1, pierce: 0, lifetimeMs: 1000, size: 5, spread: 0, effects: [], critChance: 0, critMultiplier: 1, vfxKind: 'kinetic' };
      const runtime = { scene, world, playerId, skillManager: { getLevel: () => 0, getWeaponProfiles: () => [weapon] } };
      attack.update(16, runtime); juice.update(16, runtime);
      assert.equal(world.components.projectiles.size, 1);
      assert.ok(Math.abs(world.components.spriteJuices.get(playerId).attackProgress - .52) < 1e-8, 'first release is dropped or left in stale recovery after restart');
    }
  } finally { juice.destroy(); }
  assert.equal(EventBus.listenerCount('weapon:windup'), before - 1, 'windup observer leaks after scene cleanup');
});

test('a target lost during anticipation cannot fabricate authored weapon contact', async () => {
  const { SpriteJuiceSystem, AutoAttackSystem, RenderSystem, World, createPlayer } = await loadRuntime();
  const scene = displayScene(), world = new World(), playerId = createPlayer(world, 0, 0, 210, 100, 100, 'char_potato_hunter'), targetId = world.createEntity();
  world.components.transforms.set(targetId, { x: 100, y: 0, radius: 10 });
  world.components.health.set(targetId, { current: 100, max: 100 }); world.components.monsters.set(targetId, { behavior: 'chaser' });
  const weapon = { skillId: 'lost-target', name: 'lost-target', color: 0xffffff, tags: [], cooldownMs: 320, damage: 1, projectileSpeed: 300, projectileCount: 1, pierce: 0, lifetimeMs: 1000, size: 5, spread: 0, effects: [], critChance: 0, critMultiplier: 1, vfxKind: 'kinetic' };
  const runtime = { scene, world, playerId, skillManager: { getLevel: () => 0, getWeaponProfiles: () => [weapon], getAuraProfiles: () => [] }, stats: { elapsedMs: 0 } };
  const juice = new SpriteJuiceSystem(scene), attack = new AutoAttackSystem(), render = new RenderSystem(scene, scene.add.graphics());
  try {
    for (let frame = 0; frame < 42; frame++) {
      if (frame === 16) world.components.health.get(targetId).current = 0;
      attack.update(16, runtime); juice.update(16, runtime); render.update(16, runtime);
      if (frame >= 16) assert.ok(scene.objects.find(object => object.texture === 'asset:hero_part_left_arm').rotation < .29, 'canceled anticipation invents contact without a real release');
    }
    assert.equal(world.components.projectiles.size, 1);
    assert.equal(world.components.spriteJuices.get(playerId).attackProgress, 1, 'canceled anticipation holds the arm forever');
  } finally { juice.destroy(); }
});

test("production juice keeps humanoids planted and rapid attacks cannot repeatedly restart anticipation", async () => {
  const { SpriteJuiceSystem, World, createPlayer, EventBus } = await loadRuntime();
  const scene = displayScene(), world = new World();
  const playerId = createPlayer(world, 0, 0, 210, 100, 100, "char_potato_hunter");
  world.components.velocities.set(playerId, { x: 210, y: 0 });
  const monsterId = world.createEntity();
  world.components.transforms.set(monsterId, { x: 80, y: 80, radius: 20 });
  world.components.velocities.set(monsterId, { x: 110, y: 0 });
  world.components.renders.set(monsterId, { assetId: "enemy_fries_soldier", size: 52 });
  world.components.monsters.set(monsterId, { behavior: "chaser", isBoss: false });
  const runtime = { scene, world, playerId };
  const system = new SpriteJuiceSystem(scene);
  try {
    for (let frame = 0; frame < 12; frame++) {
      EventBus.emit("weapon:fired", { directionX: 1, directionY: 0 });
      system.update(24, runtime);
      const monster = world.components.spriteJuices.get(monsterId);
      const hero = world.components.spriteJuices.get(playerId);
      assert.ok(Math.abs(monster.offsetY) <= 0.7, "humanoid monster still hops");
      assert.ok(Math.abs(hero.offsetY) < 1.5 && Math.abs(hero.offsetX) < 2.2, "whole hero recoils instead of independent arm attack");
    }
    assert.ok(system.playerAttack.remainingMs < 200, "every rapid projectile resets anticipation");
    world.components.velocities.set(monsterId, { x: -110, y: 0 }); system.update(16, runtime);
    assert.equal(world.components.spriteJuices.get(monsterId).facingX, -1);
    for (const velocity of [{ x: 0, y: 0 }, { x: 0, y: -110 }]) {
      world.components.velocities.set(monsterId, velocity); system.update(16, runtime);
      assert.equal(world.components.spriteJuices.get(monsterId).facingX, -1, "enemy snaps facing when stopping or walking vertically");
    }
  } finally { system.destroy(); }
});
