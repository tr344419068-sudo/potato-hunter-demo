import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { displayScene } from "./ui-runtime-helpers.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
export { CombatVfxSystem } from "./src/systems/CombatVfxSystem.ts";
export { EventBus } from "./src/managers/EventBus.ts";
export { World } from "./src/entities/World.ts";
export { EntityPools } from "./src/managers/EntityPools.ts";
export { FeedbackSystem } from "./src/systems/FeedbackSystem.ts";
export { CombatParticleEmitter } from "./src/systems/CombatParticleEmitter.ts";
export { default as PhaserGameObject } from "./node_modules/phaser/src/gameobjects/GameObject.js";
export { default as PhaserDisplayList } from "./node_modules/phaser/src/gameobjects/DisplayList.js";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false, plugins: [{ name: "headless-particles", setup(context) {
  context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless-particles" }));
  context.onResolve({ filter: /^\.\.\/\.\.\/device$/ }, () => ({ path: "device", namespace: "headless-device" }));
  context.onLoad({ filter: /.*/, namespace: "headless-device" }, () => ({ contents: 'module.exports = { features: { stableSort: true } };' }));
  context.onLoad({ filter: /.*/, namespace: "headless-particles" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Scenes: { Events: { SHUTDOWN: "shutdown" } }, BlendModes: { ADD: 1 }, Math: { Clamp: (value,min,max)=>Math.min(max,Math.max(min,value)), Between: (min,max)=>(min+max)/2, FloatBetween: (min,max)=>(min+max)/2 } };', resolveDir: root }));
}}] }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

function textureManager() {
  const textures = new Map(); const created = []; const removed = [];
  return { textures, created, removed, exists: key => textures.has(key), remove: key => { removed.push(key); textures.delete(key); }, createCanvas: (key, width, height) => {
    const commands = []; const gradients = [];
    const context = new Proxy({}, { get(owner, property) {
      if (property in owner) return owner[property];
      if (/^create.*Gradient$/.test(property)) return (...args) => { const gradient = { kind: property, args, stops: [], addColorStop(offset, color) { this.stops.push({ offset, color }); } }; gradients.push(gradient); return gradient; };
      return (...args) => commands.push([property, ...args]);
    }, set(owner, property, value) { commands.push([property, value]); owner[property] = value; return true; } });
    const texture = { key, width, height, commands, gradients, refreshed: 0, getContext: () => context, refresh() { this.refreshed++; return this; } };
    created.push(texture); textures.set(key, texture); return texture;
  } };
}

async function fixture(width = 1280, height = 720, sharedTextures) {
  const api = await modules; api.EventBus.removeAllListeners(); const display = displayScene(width, height);
  display.scene.textures = sharedTextures ?? textureManager();
  display.scene.cameras.main.worldView = { x: 0, y: 0, width, height };
  return { ...api, ...display, textures: display.scene.textures };
}

const particleImages = objects => objects.filter(object => object.kind === "image" && String(object.texture).startsWith("combat-particle:"));
const activeImages = objects => particleImages(objects).filter(object => object.active && object.visible && !object.destroyed);

test("persisted reduced-effects mode quiets decorative trails and ordinary bursts but preserves critical/reaction readability", async () => {
 const { CombatVfxSystem, CombatParticleEmitter, EventBus, World, scene, objects } = await fixture();
 const emitter = new CombatParticleEmitter(scene); emitter.setReducedEffects(true);
 assert.equal(emitter.emit({x:200,y:200,kind:'fire',phase:'trail'}),0);
 assert.equal(emitter.emit({x:200,y:200,kind:'fire',phase:'impact',count:12}),6);
 assert.equal(emitter.emit({x:200,y:200,kind:'fire',phase:'impact',count:12,critical:true}),12);
 emitter.destroy();const system=new CombatVfxSystem(scene);EventBus.emit('presentation:preferences',{reducedEffects:true});
 const world=new World(),id=world.createEntity();world.components.projectiles.set(id,{vfxKind:'fire'});world.components.transforms.set(id,{x:200,y:200});world.components.velocities.set(id,{x:400,y:0});system.update(16,{world,stats:{elapsedMs:0}});assert.equal(activeImages(objects).length,0);
 EventBus.emit('combat:reaction',{x:200,y:200,radius:80,kind:'shatter',label:'碎冰',primaryColor:0x99eeff,secondaryColor:0xffffff,affectedTargets:3});assert.ok(activeImages(objects).length>0);
 system.destroy();assert.equal(EventBus.listenerCount('presentation:preferences'),0);
});

function attachActualPhaserLifecycle(scene, PhaserGameObject, PhaserDisplayList) {
  scene.sys = { events: scene.events, queueDepthSort: () => scene.sys.displayList?.queueDepthSort(), updateList: { remove() {} } };
  const displayList = new PhaserDisplayList(scene); scene.sys.displayList = displayList;
  const originalAdd = scene.add;
  scene.add = new Proxy({}, { get(_owner, kind) { return (...args) => {
    const object = originalAdd[kind](...args);
    Object.assign(object, { scene, displayList: null, parentContainer: null, preDestroy: null, preUpdate: null, postPipelines: null, preFX: null, postFX: null, input: null, body: null, data: null, ignoreDestroy: false });
    object.removeFromDisplayList = PhaserGameObject.prototype.removeFromDisplayList;
    object.removeFromUpdateList = PhaserGameObject.prototype.removeFromUpdateList;
    object.destroy = function(fromScene) { PhaserGameObject.prototype.destroy.call(this, fromScene); this.destroyed = true; };
    displayList.add(object);
    return object;
  }; }});
  scene.events.emit("start");
  return displayList;
}

test("real weapon events produce generated sprite particles with white core, family glow, and direction", async () => {
  const { CombatVfxSystem, EventBus, scene, objects, textures } = await fixture(); const system = new CombatVfxSystem(scene);
  const payload = Object.freeze({ x: 240, y: 240, directionX: 1, directionY: 0, color: 0xffaa22, size: 12, projectileCount: 1, vfxKind: "fire" });
  EventBus.emit("weapon:fired", payload);
  assert.ok(activeImages(objects).length >= 2, "muzzle still draws only Graphics circles/rings");
  const ribbon = activeImages(objects).find(image => image.texture.endsWith(":ribbon")); assert.ok(ribbon);
  assert.equal(ribbon.rotation, 0); assert.ok(ribbon.width > ribbon.height * 2);
  assert.ok(textures.created.some(texture => texture.gradients.some(gradient => gradient.stops.some(stop => /255,\s*255,\s*255/.test(stop.color)))));
  assert.ok(textures.created.some(texture => texture.commands.some(command => command[0] === "shadowBlur" && command[1] >= 6)));
  assert.ok(activeImages(objects).every(image => image.blendMode === 1 && image.depth > 2 && image.depth < 4));
  assert.equal(scene.cameras.main.shakes, 0); assert.equal(scene.cameras.main.flashes, 0); system.destroy();
});

test("every family draws distinct debris and heavy/critical events remain finite", async () => {
  const { CombatParticleEmitter, scene, textures, objects } = await fixture(); assert.equal(typeof CombatParticleEmitter, "function", "runtime sprite emitter missing");
  const emitter = new CombatParticleEmitter(scene);
  const kinds = ["peeler", "fire", "frost", "lightning", "poison", "explosion"];
  for (const kind of kinds) {
    const emitted = emitter.emit({ x: 250, y: 250, kind, phase: "impact", directionX: 1, directionY: 0 });
    assert.ok(emitted >= 3 && emitted <= 18); emitter.update(1200);
  }
  const debris = textures.created.filter(texture => texture.key.endsWith(":debris")); assert.equal(debris.length, kinds.length);
  assert.equal(new Set(debris.map(texture => JSON.stringify(texture.commands))).size, kinds.length);
  const normal = emitter.emit({ x: 250, y: 250, kind: "fire", phase: "impact" }); emitter.update(1200);
  const critical = emitter.emit({ x: 250, y: 250, kind: "fire", phase: "impact", critical: true, count: 100000 });
  assert.ok(critical > normal && critical <= 18); emitter.update(1200); assert.equal(activeImages(objects).length, 0); emitter.destroy();
});

test("global caps preserve high-priority space and compact resizing retires excess sprites", async () => {
  const { CombatParticleEmitter, scene, objects } = await fixture(); assert.equal(typeof CombatParticleEmitter, "function");
  const emitter = new CombatParticleEmitter(scene);
  for (let burst = 0; burst < 100; burst++) emitter.emit({ x: 250, y: 250, kind: "fire", phase: "trail", count: 100000 });
  const trails = activeImages(objects).length; assert.ok(trails > 0 && trails < 180);
  const heavy = emitter.emit({ x: 250, y: 250, kind: "explosion", phase: "reaction", count: 100000 }); assert.ok(heavy >= 12 && heavy <= 18);
  for (let burst = 0; burst < 100; burst++) emitter.emit({ x: 250, y: 250, kind: "explosion", phase: "reaction", count: 100000 });
  assert.equal(activeImages(objects).length, 180); assert.equal(emitter.activeCount, 180);
  scene.scale.width = 390; emitter.update(0); assert.equal(activeImages(objects).length, 100);
  emitter.update(1200); assert.equal(emitter.activeCount, 0); assert.equal(activeImages(objects).length, 0);
  emitter.destroy();
});

test("offscreen events allocate nothing and expiry reuses a bounded pool", async () => {
  const { CombatParticleEmitter, scene, objects, textures } = await fixture(390, 844); assert.equal(typeof CombatParticleEmitter, "function");
  const emitter = new CombatParticleEmitter(scene);
  assert.equal(emitter.emit({ x: 10000, y: 10000, kind: "fire", phase: "reaction" }), 0); assert.equal(textures.created.length, 0);
  emitter.emit({ x: 150, y: 250, kind: "frost", phase: "impact" }); const allocated = particleImages(objects).length;
  emitter.update(1000); assert.equal(activeImages(objects).length, 0);
  emitter.emit({ x: 150, y: 250, kind: "frost", phase: "impact" }); assert.equal(particleImages(objects).length, allocated);
  assert.ok(textures.created.every(texture => texture.refreshed === 1)); emitter.destroy();
});

test("texture leases survive another emitter and shutdown removes particles and generated textures", async () => {
  const { CombatParticleEmitter, scene, objects, textures } = await fixture(); assert.equal(typeof CombatParticleEmitter, "function");
  const first = new CombatParticleEmitter(scene); const secondDisplay = displayScene(); secondDisplay.scene.textures = textures;
  const second = new CombatParticleEmitter(secondDisplay.scene);
  first.emit({ x: 200, y: 200, kind: "fire", phase: "impact" }); const keys = [...textures.textures.keys()];
  second.emit({ x: 200, y: 200, kind: "fire", phase: "impact" }); assert.equal(textures.created.length, keys.length);
  first.destroy(); assert.ok(particleImages(objects).every(image => image.destroyed)); assert.ok(keys.every(key => textures.exists(key)));
  secondDisplay.scene.events.emit("shutdown"); assert.equal(second.activeCount, 0); assert.equal(textures.textures.size, 0);
  assert.ok(particleImages(secondDisplay.objects).every(image => image.destroyed));
  assert.equal(second.emit({ x: 200, y: 200, kind: "fire", phase: "impact" }), 0); second.destroy();
});

test("production VFX emits trails, aura, impacts and reactions then clears all sprite state on shutdown", async () => {
  const { CombatVfxSystem, EventBus, World, scene, objects, textures } = await fixture(); const system = new CombatVfxSystem(scene); const world = new World();
  const id = world.createEntity(); world.components.projectiles.set(id, { vfxKind: "lightning" }); world.components.transforms.set(id, { x: 250, y: 250, radius: 4 }); world.components.velocities.set(id, { x: 0, y: 600 });
  const runtime = { world, stats: { elapsedMs: 0 } }; system.update(16, runtime);
  assert.ok(activeImages(objects).some(image => image.texture.includes(":lightning:ribbon") && Math.abs(image.rotation - Math.PI / 2) < 0.001));
  EventBus.emit("aura:pulse", Object.freeze({ x: 250, y: 250, radius: 64, color: 0x66ff55, vfxKind: "poison" }));
  EventBus.emit("weapon:impact", Object.freeze({ x: 250, y: 250, radius: 42, color: 0xffaa22, vfxKind: "frost", directionX: 1, directionY: 0, critical: true }));
  EventBus.emit("combat:reaction", Object.freeze({ x: 250, y: 250, radius: 90, kind: "superconduct", label: "超导", primaryColor: 0x99eeff, secondaryColor: 0xffffff, affectedTargets: 6 }));
  assert.ok(activeImages(objects).some(image => image.texture.includes(":poison:"))); assert.ok(activeImages(objects).some(image => image.texture.includes(":frost:")));
  const residue = objects.find(object => object.kind === "graphics" && object.calls.some(call => call[0] === "setPosition" && call[1] === 250 && call[2] > 250));
  assert.ok(residue && residue.depth < 2, "ground residue occludes the actors");
  assert.equal(scene.cameras.main.shakes, 0); assert.equal(scene.cameras.main.flashes, 0);
  world.components.projectiles.clear(); system.update(1200, runtime); assert.equal(activeImages(objects).length, 0);
  scene.events.emit("shutdown"); assert.equal(EventBus.listenerCount("weapon:fired"), 0); assert.equal(EventBus.listenerCount("combat:reaction"), 0);
  assert.ok(particleImages(objects).every(image => image.destroyed)); assert.equal(textures.textures.size, 0);
});

test("production trail scheduling shares a finite burst budget and still expires sprites at saturation", async () => {
  const { CombatVfxSystem, EventBus, World, scene, objects } = await fixture(); const system = new CombatVfxSystem(scene); const world = new World();
  for (let index = 0; index < 90; index++) { const id = world.createEntity(); world.components.projectiles.set(id, { vfxKind: "lightning" }); world.components.transforms.set(id, { x: 60 + index * 6, y: 240, radius: 4 }); world.components.velocities.set(id, { x: 0, y: 600 }); }
  const runtime = { world, stats: { elapsedMs: 0 } };
  system.update(16, runtime); const firstFrame = particleImages(objects); assert.ok(firstFrame.length > 0 && firstFrame.length <= 48);
  for (let frame = 0; frame < 12; frame++) system.update(46, runtime);
  assert.ok(particleImages(objects).some(image => image.x > 500), "late projectiles never receive a trail");
  world.components.projectiles.clear();
  for (let burst = 0; burst < 12; burst++) EventBus.emit("combat:reaction", { x: 250, y: 250, radius: 90, kind: "superconduct", label: "超导", primaryColor: 0x99eeff, secondaryColor: 0xffffff, affectedTargets: 6 });
  assert.equal(activeImages(objects).length, 180); system.trailTimerMs = 10000;
  system.update(1200, runtime); assert.equal(activeImages(objects).length, 0, "early return at the trail cap skipped lifetime ticking"); system.destroy();
});

test("manual VFX destroy releases owned accents and transients without clearing another system's pool use", async () => {
  const { CombatVfxSystem, EventBus, EntityPools, scene, objects, tweens, killed } = await fixture();
  const unrelated = EntityPools.acquireGraphics(scene);
  const system = new CombatVfxSystem(scene);
  EventBus.emit("weapon:impact", { x: 240, y: 240, radius: 42, color: 0xffaa22, vfxKind: "fire" });
  EventBus.emit("combat:reaction", { x: 250, y: 250, radius: 90, kind: "superconduct", label: "超导", primaryColor: 0x99eeff, secondaryColor: 0xffffff, affectedTargets: 6 });
  EventBus.emit("hero:dash", { x: 250, y: 250, directionX: 1, directionY: 0, size: 48 });
  scene.textures.textures.set("asset:hero-test", {});
  EventBus.emit("hero:dash", { x: 250, y: 250, directionX: 1, directionY: 0, size: 48, assetId: "hero-test" });
  const ownedGraphics = objects.filter(object => object.kind === "graphics" && object !== unrelated);
  const transients = objects.filter(object => ["text", "circle"].includes(object.kind) || object.kind === "image" && !String(object.texture).startsWith("combat-particle:"));
  assert.ok(ownedGraphics.length >= 4 && transients.length >= 4);
  system.destroy(); system.destroy();
  assert.ok(ownedGraphics.every(object => !object.active && !object.visible), "owned Graphics stayed visible after manual destroy");
  assert.ok(transients.every(object => object.destroyed), "owned reaction label/dash afterimage survived destroy");
  assert.ok([...ownedGraphics, ...transients].every(object => killed.includes(object)), "owned tweens were not canceled");
  assert.ok(unrelated.active && unrelated.visible && !killed.includes(unrelated));
  assert.equal(scene.events.listenerCount("shutdown"), 0);
  const borrowed = EntityPools.acquireGraphics(scene); borrowed.setVisible(false);
  for (const tween of tweens) { tween.onStart?.(); tween.onComplete?.(); }
  assert.ok(borrowed.active && !borrowed.visible, "stale tween callbacks modified a pooled accent borrowed by another system");
  assert.equal(system.activeParticles, 0); assert.equal(system.activeAccents, 0);
  const count = objects.length; EventBus.emit("hero:dash", { x: 250, y: 250, directionX: 1, directionY: 0, size: 48 });
  assert.equal(objects.length, count);
  EntityPools.releaseGraphics(scene, borrowed); EntityPools.releaseGraphics(scene, unrelated);
});

test("invalid optional numeric particle hints never introduce nonfinite display state", async () => {
  const { CombatParticleEmitter, scene, objects } = await fixture(); const emitter = new CombatParticleEmitter(scene);
  assert.equal(emitter.emit({ x: 240, y: 240, kind: "fire", phase: "impact", radius: NaN, directionX: Infinity, directionY: -Infinity }), 12);
  assert.equal(activeImages(objects).length, 12);
  assert.ok(activeImages(objects).every(image => [image.x, image.y, image.width, image.height, image.rotation, image.alpha].every(Number.isFinite)), "invalid radius/direction propagated into initial particle state");
  emitter.update(16);
  assert.equal(activeImages(objects).length, 12);
  assert.ok(activeImages(objects).every(image => [image.x, image.y, image.width, image.height, image.rotation, image.alpha].every(Number.isFinite)), "invalid radius/direction propagated into particle position or dimensions");
  assert.equal(emitter.emit({ x: 240, y: 240, kind: "fire", phase: "impact", count: NaN }), 0);
  emitter.destroy();
});

test("actual Phaser DisplayList shutdown before Feedback and VFX never repools destroyed Graphics on restart", async () => {
  const { CombatVfxSystem, FeedbackSystem, EventBus, PhaserGameObject, PhaserDisplayList, scene, objects } = await fixture();
  const displayList = attachActualPhaserLifecycle(scene, PhaserGameObject, PhaserDisplayList);
  new FeedbackSystem(scene); new CombatVfxSystem(scene);
  const payload = { x: 240, y: 240, radius: 42, color: 0xffaa22, vfxKind: "fire" };
  EventBus.emit("weapon:impact", payload);
  const firstGraphics = objects.filter(object => object.kind === "graphics");
  assert.equal(firstGraphics.length, 3);
  assert.ok(firstGraphics.every(object => object.scene === scene && displayList.exists(object)));
  scene.events.emit("shutdown");
  assert.ok(firstGraphics.every(object => !object.scene && !object.displayList && object.destroyed));
  assert.equal(displayList.getChildren().length, 0);
  scene.events.emit("start"); new FeedbackSystem(scene); new CombatVfxSystem(scene);
  EventBus.emit("weapon:impact", payload);
  const restartedGraphics = objects.filter(object => object.kind === "graphics" && !firstGraphics.includes(object));
  assert.equal(restartedGraphics.length, 3, "restart reacquired destroyed Graphics rather than allocating live display objects");
  assert.ok(restartedGraphics.every(object => object.scene === scene && displayList.exists(object) && !object.destroyed));
  assert.ok(firstGraphics.every(object => !object.active && !object.visible && !object.scene));
  scene.events.emit("shutdown");
});

for (const width of [1280, 390]) {
  test(`ordinary impacts and auras leave complete critical and reaction particle bursts at ${width}px`, async () => {
    const { CombatParticleEmitter, scene, objects } = await fixture(width, width < 700 ? 844 : 720);
    const emitter = new CombatParticleEmitter(scene);
    for (let index = 0; index < 100; index++) {
      emitter.emit({ x: 240, y: 240, kind: "fire", phase: "impact" });
      emitter.emit({ x: 240, y: 240, kind: "poison", phase: "aura" });
    }
    const ordinary = emitter.activeCount;
    const critical = emitter.emit({ x: 240, y: 240, kind: "fire", phase: "impact", critical: true });
    assert.equal(critical, 15, `ordinary impacts consumed the critical reserve at ${width}px`);
    const reaction = emitter.emit({ x: 240, y: 240, kind: "lightning", phase: "reaction" });
    assert.equal(reaction, 18, `ordinary impacts consumed the reaction reserve at ${width}px`);
    assert.equal(activeImages(objects).length, ordinary + critical + reaction);
    assert.ok(emitter.activeCount <= (width < 700 ? 100 : 180));
    emitter.destroy();
  });
}

test("desktop ordinary particles shrink to the compact ordinary ceiling and preserve complete new heavy bursts", async () => {
  const { CombatParticleEmitter, scene, objects } = await fixture(); const emitter = new CombatParticleEmitter(scene);
  for (let index = 0; index < 100; index++) emitter.emit({ x: 200, y: 200, kind: "fire", phase: "impact" });
  assert.equal(emitter.activeCount, 144);
  scene.scale.width = 390; emitter.update(0);
  assert.equal(emitter.activeCount, 64, "compact shrink retained ordinary particles inside the heavy reserve");
  assert.equal(emitter.emit({ x: 200, y: 200, kind: "fire", phase: "impact", critical: true }), 15);
  assert.equal(emitter.emit({ x: 200, y: 200, kind: "lightning", phase: "reaction" }), 18);
  assert.equal(activeImages(objects).length, 97); assert.ok(emitter.activeCount <= 100);
  emitter.destroy();
});

test("compact shrink retires ordinary particles before older heavy particles and retains their bounded lifetime", async () => {
  const { CombatParticleEmitter, scene, objects } = await fixture(); const emitter = new CombatParticleEmitter(scene);
  emitter.emit({ x: 200, y: 200, kind: "fire", phase: "impact", critical: true });
  emitter.emit({ x: 200, y: 200, kind: "lightning", phase: "reaction" });
  const retainedHeavy = [...activeImages(objects)]; assert.equal(retainedHeavy.length, 33);
  for (let index = 0; index < 100; index++) emitter.emit({ x: 200, y: 200, kind: "poison", phase: "impact" });
  assert.equal(emitter.activeCount, 144);
  scene.scale.width = 390; emitter.update(0);
  assert.ok(retainedHeavy.every(image => image.active && image.visible && !image.destroyed), "compact shrink retired older heavy effects before ordinary effects");
  assert.equal(activeImages(objects).filter(image => !retainedHeavy.includes(image)).length, 64);
  assert.equal(emitter.activeCount, 97); assert.ok(emitter.activeCount <= 100);
  emitter.update(1200); assert.equal(emitter.activeCount, 0);
  emitter.destroy();
});

for (const width of [1280, 390]) {
  test(`production reactions remain legible after ordinary accent saturation and keep heavy labels bounded at ${width}px`, async () => {
    const { CombatVfxSystem, EventBus, scene, objects, tweens } = await fixture(width, width < 700 ? 844 : 720);
    const system = new CombatVfxSystem(scene);
    const impact = { x: 240, y: 240, radius: 42, color: 0xffaa22, vfxKind: "fire" };
    for (let index = 0; index < 100; index++) EventBus.emit("weapon:impact", impact);
    const ordinaryAccents = system.activeAccents;
    const reaction = { x: 240, y: 240, radius: 90, kind: "superconduct", label: "超导", primaryColor: 0x99eeff, secondaryColor: 0xffffff, affectedTargets: 6 };
    EventBus.emit("combat:reaction", reaction);
    const labels = () => objects.filter(object => object.kind === "text" && object.text === "超导" && !object.destroyed);
    assert.equal(labels().length, 1, `ordinary accent saturation dropped the reaction label at ${width}px`);
    assert.ok(activeImages(objects).some(image => image.texture.includes(":lightning:")));
    const beforeCritical = activeImages(objects).length;
    EventBus.emit("weapon:impact", { ...impact, critical: true });
    assert.ok(activeImages(objects).length > beforeCritical, `critical is invisible after normal saturation at ${width}px`);
    assert.equal(system.activeAccents, ordinaryAccents + 2);
    for (let index = 0; index < 100; index++) EventBus.emit("combat:reaction", reaction);
    assert.ok(system.activeAccents <= 36); assert.ok(labels().length <= 4);
    assert.ok(activeImages(objects).length <= (width < 700 ? 100 : 180));
    // Completing the visible ring must not create room for an unbounded queue of longer-lived labels.
    for (const tween of [...tweens]) if (tween.targets.kind === "graphics") tween.onComplete?.();
    for (let index = 0; index < 100; index++) EventBus.emit("combat:reaction", reaction);
    assert.ok(labels().length <= 4, "reaction labels grew beyond their independent lifetime budget");
    assert.equal(scene.cameras.main.shakes, 0); assert.equal(scene.cameras.main.flashes, 0);
    system.destroy();
  });
}
