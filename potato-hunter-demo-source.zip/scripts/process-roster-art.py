"""Reproducible normalization of the nine observed internal-site exports."""
import hashlib
import json
from pathlib import Path
import shutil
import cv2
import numpy as np
from PIL import Image, ImageDraw
from importlib.util import spec_from_file_location, module_from_spec

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / 'artifacts/generated-2026-11-18-roster'
spec = spec_from_file_location('asset_processor', ROOT / 'scripts/process-generated-asset.py')
processor = module_from_spec(spec)
spec.loader.exec_module(processor)
jobs = json.loads((ART / 'generation-jobs.json').read_text())
cuts = json.loads((ART / 'cutouts.json').read_text())
selections = {cut['id']: cut for cut in cuts}
assets = []
for job in jobs['jobs']:
    item = selections[job['id']]
    original_url = job['results'][item['candidate']]
    original = next(a for a in jobs['bundle']['assets'] if a['url'] == original_url)
    original_path = ART / 'originals' / (original['id'] + '.png')
    cutout = ART / 'cutouts' / (job['id'] + '.png')
    cutout.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(item['localPath'], cutout)
    image = Image.open(cutout).convert('RGBA')
    processing = 'Website RemBg alpha preserved; foreground normalized with 7% safe margin.'
    if item.get('localExtraction'):
        rgb = np.asarray(image.convert('RGB'))
        neutral = (np.ptp(rgb.astype(np.int16), axis=2) < 35) & (rgb.min(axis=2) > 140)
        _, labels = cv2.connectedComponents(neutral.astype(np.uint8), connectivity=8)
        border = np.unique(np.concatenate((labels[0], labels[-1], labels[:, 0], labels[:, -1])))
        background = np.isin(labels, border[border != 0])
        alpha = np.where(background, 0, 255).astype(np.uint8)
        image = Image.fromarray(np.dstack((rgb, alpha)), 'RGBA')
        processing = 'Original generated RGB retained. Website RemBg rejected this export; local border-connected neutral checkerboard extraction, preserving enclosed white highlights; 7% safe margin.'
    enemy = job['id'] in ['mushroom_hexer','chili_scatter','pea_sniper','donut_jumper']
    boss = job['id'] == 'burger_tyrant'
    asset_id = ('enemy_' + job['id'] if enemy else 'boss_burger_tyrant' if boss else 'vfx_' + job['id']) + '_v4'
    relative = f"assets/bestiary/v4/{job['id']}.png" if enemy else 'assets/bosses/burger_tyrant/idle-v4.png' if boss else f'assets/vfx/aoe-v4/{asset_id}.png'
    output = ROOT / 'public' / relative
    output.parent.mkdir(parents=True, exist_ok=True)
    final = processor.make_transparent(image, 768 if boss else 512)
    final.save(output, optimize=True)
    assets.append({'id':job['id'], 'assetId':asset_id, 'candidate':item['candidate'], 'sourceUrl':original_url, 'cutoutUrl':item.get('url'), 'originalPath':str(original_path.relative_to(ROOT)), 'cutoutPath':str(cutout.relative_to(ROOT)), 'outputPath':str(output.relative_to(ROOT)), 'processing':processing, 'sha256':hashlib.sha256(output.read_bytes()).hexdigest(), 'alphaBounds':final.getchannel('A').getbbox()})

(ART / 'selection.json').write_text(json.dumps({'date':jobs['date'],'source':jobs['source'],'model':jobs['model'],'assets':assets},ensure_ascii=False,indent=2)+'\n')
montage=Image.new('RGB',(1080,900),(28,46,47))
draw=ImageDraw.Draw(montage)
for index, asset in enumerate(assets):
    image=Image.open(ROOT / asset['outputPath']); image.thumbnail((300,245))
    x=(index%3)*360; y=(index//3)*300
    montage.paste(image,(x+(360-image.width)//2,y+15),image)
    draw.text((x+14,y+272),asset['assetId'],fill=(230,238,224))
montage.save(ART/'selected-art.jpg',quality=92)
print(json.dumps(assets,ensure_ascii=False,indent=2))
