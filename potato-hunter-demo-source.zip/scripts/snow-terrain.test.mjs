import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const modules = build({ stdin: { contents: `
  export { World } from './src/entities/World.ts';
  export { createEnemyProjectile, createMonster, createPlayer } from './src/entities/factories.ts';
  export { MovementSystem } from './src/systems/MovementSystem.ts';
  export { EnemyProjectileSystem } from './src/systems/EnemyProjectileSystem.ts';
  export * from './src/systems/IceTerrain.ts';
  export * from './src/systems/SnowEnemySystem.ts';
  export { MonsterBehaviorSystem } from './src/systems/MonsterBehaviorSystem.ts';
  export { MonsterContactSystem } from './src/systems/MonsterContactSystem.ts';
  export { AoeWarningSystem } from './src/systems/AoeWarningSystem.ts';
  export { getSnowEnemyPose } from './src/systems/SnowEnemyPresentation.ts';
  export { ConfigManager } from './src/managers/ConfigManager.ts';
  export { IceTerrainView } from './src/systems/IceTerrainView.ts';
`, resolveDir: root, loader: 'ts' }, bundle: true, logLevel: 'silent', platform: 'node', format: 'esm', write: false,
  plugins: [{ name: 'headless', setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: 'phaser', namespace: 'headless' }));
    context.onLoad({ filter: /.*/, namespace: 'headless' }, () => ({ contents: 'export default {};', resolveDir: root }));
  }}],
}).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString('base64')}`));

const p = (x, y = 0) => ({ x, y });
const cover = (id, x, y = 0, radius = 20) => ({ id, x, y, radius });

test('a snow keg gives a punishable warning instead of instant contact damage', async () => {
  const f = await modules;
  for (const outcome of ['stay', 'move', 'kill']) {
    const world = new f.World();
    const playerId = f.createPlayer(world, 28, 0, 210, 100, 70);
    const keg = f.createMonster(world, f.ConfigManager.getMonster('snow_keg'), 0, 0);
    const runtime = { world, playerId, campaign: { stage: 'snow' } };
    new f.MonsterBehaviorSystem().update(16, runtime);
    const health = world.components.health.get(playerId);
    assert.equal(health.current, 100);
    const telegraph = [...world.components.aoeWarnings.values()][0];
    assert.equal(telegraph?.sourceId, keg);
    assert.ok(telegraph.remainingMs >= 500);
    new f.MonsterContactSystem().update(16, runtime);
    assert.equal(health.current, 100, 'contact must not steal the armed warning’s damage window');
    if (outcome === 'move') world.components.transforms.get(playerId).x = 240;
    if (outcome === 'kill') world.components.health.get(keg).current = 0;
    const warningSystem = new f.AoeWarningSystem();
    warningSystem.update(16, runtime);
    warningSystem.update(1_000, runtime);
    assert.equal(health.current, outcome === 'stay' ? 82.4 : 100);
    assert.equal(world.isAlive(keg), outcome === 'kill');
    assert.equal(world.components.aoeWarnings.size, 0);
  }
});

test('snow combat artwork follows active shields, locked aim, and the rolling phase', async () => {
  const { getSnowEnemyPose } = await modules;
  const pose = (role, phase, extras = {}) => getSnowEnemyPose({ role, phase, angle: 0, guardHp: 12, durationMs: 520, remainingMs: 320, ...extras }, 1);
  assert.equal(pose('guard', 'guard').assetId, 'enemy_snow_guard_pose');
  assert.equal(pose('guard', 'guard', { guardHp: 0 }).assetId, undefined);
  assert.equal(pose('needle', 'tell').facing, -1);
  assert.equal(pose('needle', 'tell', { angle: Math.PI }).facing, 1);
  assert.ok(Math.abs(pose('roller', 'roll').rotation) > Math.PI / 2);
  assert.equal(pose('roller', 'stagger').assetId, undefined);
  assert.equal(pose('elite', 'roll').assetId, 'enemy_snow_elite_pose');
});

test('exploring the canyon streams static cover without restoring a shattered pillar', async () => {
  const f = await modules;
  const world = new f.World();
  f.setupSnowIceTerrain(world, p(0));
  const first = f.getIceCover(world)[0];
  f.breakIceCover(world, first.id);
  f.updateIceTerrain(16, world, p(2650, -580));
  assert.ok(f.getIceCover(world).some(ice => Math.hypot(ice.x - 2650, ice.y + 580) < 450));
  assert.ok(f.getIceCover(world).length <= 49, 'nearby cover has a bounded working set');
  f.updateIceTerrain(16, world, p(0));
  assert.ok(!f.getIceCover(world).some(ice => ice.id === first.id));
  f.setupDuelIceTerrain(world, p(0), p(240));
  f.updateIceTerrain(16, world, p(400));
  assert.equal(f.getIceCover(world).length, 3, 'roaming cover does not bleed into the duel');
});

test('swept snow cover stops at the first circle entered, including tangential paths', async () => {
  const f = await modules;
  const world = new f.World();
  const first = cover('first', 110, 24), later = cover('later', 180);
  f.setIceCover(world, [later, first]);
  assert.deepEqual(f.hitIceCover(world, p(0), p(220), 4), first);
  assert.deepEqual(f.hitIceCover(world, p(0), p(220)), later);
  assert.deepEqual(f.hitIceCover(world, p(190), p(220)), later);
  assert.equal(f.hitIceCover(world, p(0), p(89)), undefined);
});

test('broken cover stops blocking immediately, emits its own shatter, and resets independently per run', async () => {
  const f = await modules;
  const world = new f.World(), fresh = new f.World();
  const pillar = cover('pillar', 80);
  f.setIceCover(world, [pillar]);
  f.setIceCover(fresh, [pillar]);
  assert.equal(f.breakIceCover(world, 'missing'), false);
  assert.equal(f.breakIceCover(world, 'pillar'), true);
  assert.equal(f.breakIceCover(world, 'pillar'), false);
  assert.deepEqual(f.getIceCoverShatters(world).map(v => v.cover), [pillar]);
  assert.equal(f.hitIceCover(world, p(0), p(120)), undefined);
  assert.deepEqual(f.hitIceCover(fresh, p(0), p(120)), pillar);
  f.clearIceTerrain(world);
  assert.equal(f.getIceCoverShatters(world).length, 0);
  f.setIceCover(world, [pillar]);
  assert.deepEqual(f.hitIceCover(world, p(0), p(120)), pillar);
});

test('duel layout puts a pillar between spawn and the hero while keeping the first walk clear', async () => {
  const f = await modules;
  const world = new f.World();
  f.setupDuelIceTerrain(world, p(1000, -800), p(1000, -560));
  const center = p(1000, -800);
  const pillar = f.hitIceCover(world, p(1000, -560), center);
  assert.ok(pillar);
  assert.ok(Math.hypot(pillar.x - center.x, pillar.y - center.y) > pillar.radius + 32);
  assert.equal(f.getIceCover(world).length, 3);
});

test('an enemy needle hits ice before the hero, while untagged projectiles are unchanged', async () => {
  const f = await modules;
  for (const tagged of [true, false]) {
    const world = new f.World();
    const playerId = f.createPlayer(world, 130, 0, 210, 100, 70);
    const shot = f.createEnemyProjectile(world, 0, 0, 1500, 0, 9);
    if (tagged) f.markIceBlockableProjectile(world, shot);
    f.setIceCover(world, [cover('screen', 75)]);
    const runtime = { world, playerId };
    new f.MovementSystem().update(100, runtime);
    new f.EnemyProjectileSystem().update(100, runtime);
    assert.equal(world.components.health.get(playerId).current, tagged ? 100 : 91);
    assert.equal(world.isAlive(shot), false);
    assert.ok(f.hitIceCover(world, p(0), p(120)), 'a needle does not shatter its cover');
  }
});

test('needle contact with the hero wins when the ice lies farther down the same sweep', async () => {
  const f = await modules;
  const world = new f.World();
  const playerId = f.createPlayer(world, 65, 0, 210, 100, 70);
  const shot = f.createEnemyProjectile(world, 0, 0, 1500, 0, 9);
  f.markIceBlockableProjectile(world, shot);
  f.setIceCover(world, [cover('screen', 125)]);
  const runtime = { world, playerId };
  new f.MovementSystem().update(100, runtime);
  new f.EnemyProjectileSystem().update(100, runtime);
  assert.equal(world.components.health.get(playerId).current, 91);
});

test('ice cover stops ordinary walking at the first intact rock and releases immediately when it breaks', async () => {
  const f = await modules;
  const world = new f.World();
  const playerId = f.createPlayer(world, 0, 0, 210, 100, 70);
  const hero = world.components.transforms.get(playerId);
  f.setIceCover(world, [cover('later', 220), cover('first', 80)]);
  world.components.velocities.set(playerId, { x: 200, y: 0 });
  const move = new f.MovementSystem();
  move.update(400, { world, playerId });
  assert.ok(Math.abs(hero.x - 44) < .1, `expected the near edge, got ${hero.x}`);
  f.breakIceCover(world, 'first');
  move.update(350, { world, playerId });
  assert.ok(hero.x > 110, 'walks through while fragments are still playing');
  assert.equal(f.getIceCoverShatters(world).length, 1);
});

test('a full-speed dash cannot pass through an ice rock even when its endpoint is well beyond it', async () => {
  const f = await modules;
  const world = new f.World();
  const playerId = f.createPlayer(world, 0, 0, 210, 100, 70);
  f.setIceCover(world, [cover('pillar', 45, 0, 13)]);
  const player = world.components.players.get(playerId);
  player.dashRemainingMs = 170;
  world.components.velocities.set(playerId, { x: 720, y: 0 });
  new f.MovementSystem().update(170, { world, playerId });
  const hero = world.components.transforms.get(playerId);
  assert.ok(Math.abs(hero.x - 16) < .1, `dash tunneled to ${hero.x}`);
  assert.equal(player.dashRemainingMs, 170, 'terrain does not rewrite dodge timers');
});

test('glancing movement slides along the ice and the next input can move away freely', async () => {
  const f = await modules;
  const world = new f.World();
  const playerId = f.createPlayer(world, 0, 17, 210, 100, 70);
  f.setIceCover(world, [cover('pillar', 80)]);
  const hero = world.components.transforms.get(playerId);
  const velocity = { x: 200, y: 0 };
  world.components.velocities.set(playerId, velocity);
  const move = new f.MovementSystem();
  move.update(400, { world, playerId });
  assert.ok(hero.x > 50 && hero.x < 78 && hero.y > 25, `expected a slide, got ${hero.x},${hero.y}`);
  const at = hero.x;
  velocity.x = -200;
  move.update(100, { world, playerId });
  assert.ok(Math.abs(hero.x - (at - 20)) < .1, 'no snag when turning away');
});

test('ice collision matches the shallow ground footprint, and a repositioned player can escape overlap', async () => {
  const f = await modules;
  const world = new f.World();
  const playerId = f.createPlayer(world, 0, 80, 210, 100, 70);
  f.setIceCover(world, [cover('pillar', 0)]);
  const hero = world.components.transforms.get(playerId);
  const velocity = { x: 0, y: -220 };
  world.components.velocities.set(playerId, velocity);
  const move = new f.MovementSystem();
  move.update(400, { world, playerId });
  assert.ok(hero.y > 27 && hero.y < 30, `expected the shallow front edge, got ${hero.y}`);
  hero.y = 0;
  move.update(100, { world, playerId });
  assert.ok(hero.y < -28, 'an overlapping actor can move out in the requested direction');
});

function enemy(f, id, heroX = 180) {
  const world = new f.World();
  const playerId = f.createPlayer(world, heroX, 0, 210, 100, 70);
  const monsterId = f.createMonster(world, { id, hp: 100, radius: 16, damage: 10, experienceValue: 1, shape: 'circle', color: 0xffffff }, 0, 0);
  const runtime = { world, playerId, stats: { elapsedMs: 0 } };
  const system = new f.SnowEnemySystem();
  const step = ms => { runtime.stats.elapsedMs += ms; system.update(ms, runtime); };
  return { world, playerId, monsterId, runtime, step };
}

test('needle telegraphs a locked line before releasing a distinct tagged icicle', async () => {
  const f = await modules;
  const e = enemy(f, 'snow_needle', 280);
  e.step(1400);
  assert.equal(e.world.components.enemyProjectiles.size, 0);
  const tell = f.getSnowEnemies(e.world).get(e.monsterId);
  assert.equal(tell.phase, 'tell');
  assert.equal(tell.angle, 0);
  e.world.components.transforms.get(e.playerId).y = 100;
  e.step(tell.remainingMs);
  const [shotId] = e.world.components.enemyProjectiles.keys();
  assert.equal(e.world.components.renders.get(shotId).assetId, 'projectile_snow_needle');
  assert.equal(f.isIceBlockableProjectile(e.world, shotId), true);
  assert.equal(e.world.components.velocities.get(shotId).y, 0);
});

test('roller breaks ice and stops at contact for a punishable stagger', async () => {
  const f = await modules;
  const e = enemy(f, 'snow_roller');
  f.setIceCover(e.world, [cover('stop', 100)]);
  e.step(1400);
  assert.equal(f.getSnowEnemies(e.world).get(e.monsterId).phase, 'tell');
  e.step(f.getSnowEnemies(e.world).get(e.monsterId).remainingMs);
  e.step(240);
  assert.equal(f.getSnowEnemies(e.world).get(e.monsterId).phase, 'stagger');
  assert.ok(Math.abs(e.world.components.transforms.get(e.monsterId).x - 64) < 1e-6);
  assert.equal(e.world.components.health.get(e.playerId).current, 100);
  assert.equal(f.getIceCover(e.world).length, 0);
  const at = e.world.components.transforms.get(e.monsterId).x;
  e.step(150);
  assert.equal(e.world.components.transforms.get(e.monsterId).x, at);
});

test('active roller owns its contact, hits only once and applies no movement lock or status', async () => {
  const f = await modules;
  const e = enemy(f, 'snow_roller');
  const hero = e.world.components.players.get(e.playerId);
  e.step(1400);
  assert.equal(f.ownsSnowEnemyContact(e.world, e.monsterId), true);
  e.step(f.getSnowEnemies(e.world).get(e.monsterId).remainingMs);
  e.step(400);
  assert.equal(e.world.components.health.get(e.playerId).current, 90);
  assert.equal(hero.dashRemainingMs, 0);
  assert.equal(e.world.components.statuses.has(e.playerId), false);
  assert.deepEqual(e.world.components.velocities.get(e.playerId), { x: 0, y: 0 });
  hero.damageCooldownMs = 0;
  e.step(120);
  assert.equal(e.world.components.health.get(e.playerId).current, 90);
  e.step(400);
  assert.equal(f.ownsSnowEnemyContact(e.world, e.monsterId), false);
});

test('explicit snow-enemy reset removes tells and returns guard to ordinary AI', async () => {
  const f = await modules;
  const e = enemy(f, 'snow_guard', 125);
  e.step(1400);
  f.clearSnowEnemies(e.world);
  assert.equal(f.getSnowEnemies(e.world).size, 0);
  assert.equal(e.world.components.monsters.get(e.monsterId).controlledMotion, false);
  assert.equal(e.world.components.monsters.get(e.monsterId).shieldHp, 0);
});

test('guard and elite keep a locked front and open to side attacks', async () => {
  const f = await modules;
  for (const id of ['snow_guard', 'snow_elite']) {
    const e = enemy(f, id, 125);
    const guard = e.world.components.monsters.get(e.monsterId);
    e.step(1400);
    assert.equal(f.getSnowEnemies(e.world).get(e.monsterId).phase, 'guard');
    assert.ok(guard.shieldHp > 0);
    Object.assign(e.world.components.transforms.get(e.playerId), { x: 0, y: -125 });
    e.step(100);
    assert.equal(f.getSnowEnemies(e.world).get(e.monsterId).angle, 0);
    assert.equal(guard.shieldHp, 0);
  }
});

test('damage depletes the directional guard before its ordinary elite affix shield', async () => {
  const f = await modules;
  const e = enemy(f, 'snow_guard', 125);
  const guard = e.world.components.monsters.get(e.monsterId);
  guard.shieldHp = 20;
  e.step(1400);
  assert.equal(guard.shieldHp, 54);
  guard.shieldHp -= 22;
  e.step(25);
  assert.equal(f.getSnowEnemies(e.world).get(e.monsterId).guardHp, 12);
  e.world.components.transforms.get(e.playerId).y = 600;
  e.step(25);
  assert.equal(guard.shieldHp, 20);
});

test('cover view draws grounded terrain without a permanent circle, then replaces it with an expiring shatter', async () => {
  const f = await modules;
  const world = new f.World();
  const images = [];
  const element = () => new Proxy({}, { get(target, key) {
    if (key in target) return target[key];
    return (...args) => {
      target[`last_${key}`] = args;
      return target.self;
    };
  }, set(target, key, value) { target[key] = value; return true; } });
  const freshElement = () => { const item = element(); item.self = item; return item; };
  const graphics = freshElement();
  const view = new f.IceTerrainView({
    textures: { exists: () => true },
    add: { graphics: () => graphics, image(...args) { const item = freshElement(); item.init = args; images.push(item); return item; } },
  });
  f.setIceCover(world, [cover('pillar', 80)]);
  view.draw({ world });
  assert.match(images[0].last_setTexture[0], /snow_ice_cover$/);
  assert.deepEqual(images[0].last_setPosition, [80, 0]);
  assert.equal(Object.hasOwn(graphics, 'last_fillCircle'), false, 'no permanent backdrop');
  assert.equal(Object.hasOwn(graphics, 'last_strokeCircle'), false, 'no permanent outline');
  f.breakIceCover(world, 'pillar');
  view.draw({ world });
  assert.match(images[0].last_setTexture[0], /vfx_snow_ice_shatter$/);
  f.updateIceTerrain(f.ICE_SHATTER_MS, world);
  view.draw({ world });
  assert.deepEqual(images[0].last_setVisible, [false]);
  view.destroy();
  assert.deepEqual(images[0].last_destroy, []);
});
