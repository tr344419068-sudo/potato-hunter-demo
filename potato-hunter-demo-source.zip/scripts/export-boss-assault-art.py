#!/usr/bin/env python3
"""Bake the two original Boss paintings into pose sheets and repack original CC0 VFX."""
import argparse
from hashlib import sha256
import json
from math import cos, sin
from pathlib import Path
import subprocess

from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'public/assets'
REV = '23b58f272b828b0a894ed7ef72fbf9033ee9d177'
POSES = [(-.09, 0, 5), (-.24, -5, 13), (-.43, -8, 21), (-.25, 18, 14),
         (.22, -17, -12), (.55, -34, -22), (.27, -12, -12)]


def smooth(lo, hi, value):
    f = min(1, max(0, (value - lo) / (hi - lo)))
    return f * f * (3 - 2 * f)


def bake(source, anchor, angle, dx, dy):
    # Inverse mesh with a weighted shoulder joint. Feet and face are pinned;
    # the original arm/weapon pixels move together with no duplicate silhouette.
    px, py, inner_x, outer_x, low_y, high_y = anchor

    def sample(x, y):
        influence = (1 - smooth(inner_x, outer_x, x)) * (1 - smooth(low_y, high_y, y))
        a = angle * influence
        u, v = x - px, y - py
        return px + u * cos(a) - v * sin(a) + dx * influence, py + u * sin(a) + v * cos(a) + dy * influence

    span = 24
    mesh = []
    for y in range(0, 768, span):
        for x in range(0, 768, span):
            corners = (sample(x, y), sample(x, y + span), sample(x + span, y + span), sample(x + span, y))
            mesh.append(((x, y, x + span, y + span), tuple(p for pair in corners for p in pair)))
    return source.transform(source.size, Image.Transform.MESH, mesh, Image.Resampling.BICUBIC)


def save_sheet(frames, cell, columns, destination, quality=84):
    atlas = Image.new('RGBA', (columns * cell, ((len(frames) + columns - 1) // columns) * cell))
    for i, frame in enumerate(frames):
        tile = ImageOps.contain(frame, (cell, cell), Image.Resampling.LANCZOS)
        atlas.paste(tile, (i % columns * cell + (cell - tile.width) // 2,
                           i // columns * cell + (cell - tile.height) // 2))
    atlas.save(destination, format='WEBP', quality=quality, alpha_quality=96, method=6)
    return {'file': destination.name, 'dimensions': list(atlas.size), 'frames': len(frames),
            'sha256': sha256(destination.read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('brackeys_checkout', type=Path)
    args = parser.parse_args()
    commit = subprocess.check_output(['git', '-C', args.brackeys_checkout, 'rev-parse', 'HEAD'], text=True).strip()
    if commit != REV:
        parser.error(f'expected Brackeys {REV}, got {commit}')
    folder = ASSETS / 'vfx/boss-assault-v1'
    folder.mkdir(exist_ok=True, parents=True)
    entries = []
    for name, source_path, anchor in (
        ('meadow-swing', 'bosses/burger_tyrant/idle-v4.png', (235, 310, 185, 383, 398, 542)),
        ('desert-swing', 'bosses/desert_sultan/idle-v1.png', (256, 235, 160, 338, 300, 515)),
    ):
        source = Image.open(ASSETS / source_path).convert('RGBA')
        frames = [bake(source, anchor, *pose) for pose in POSES]
        entries.append({'source': f'existing game art: {source_path}',
                        **save_sheet(frames, 256, 4, folder / f'{name}.webp')})

    for name, upstream, selected in (
        ('rush-streaks', 'lightstreaks_6x5.png', range(0, 24, 2)),
        ('strike-sparks', 'star_explosion_6x5.png', range(12)),
    ):
        relative = f'vfx/brackeys_particle_bundle/predrawn/{upstream}'
        original = args.brackeys_checkout / relative
        sheet = Image.open(original).convert('RGBA')
        cw, ch = sheet.width / 6, sheet.height / 5
        frames = [sheet.crop((round(i % 6 * cw), round(i // 6 * ch), round((i % 6 + 1) * cw), round((i // 6 + 1) * ch))) for i in selected]
        entries.append({'upstreamFile': relative, 'upstreamSha256': sha256(original.read_bytes()).hexdigest(),
                        'sourceFrames': list(selected), 'license': 'CC0-1.0',
                        **save_sheet(frames, 128, 6, folder / f'{name}.webp')})

    (folder / 'sources.json').write_text(json.dumps({
        'pack': 'Brackeys VFX Bundle', 'creator': 'Brackeys', 'upstreamCommit': REV,
        'distribution': 'https://brackeysgames.itch.io/brackeys-vfx-bundle',
        'licenseEvidence': f'https://github.com/Brackeys/vfx-in-godot/blob/{REV}/README.md#license',
        'outputs': entries,
    }, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
