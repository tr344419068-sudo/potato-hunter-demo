"""Composite campaign stills from the approved Shengong K1 concept and motion takes."""
import argparse
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFilter


SIZE = 640
RESAMPLE = Image.Resampling.LANCZOS
ROOT = Path(__file__).resolve().parents[1]


def isolated(image):
    # Discard faint compression specks beyond the character's key.
    bounds = image.getchannel('A').point(lambda a: 255 if a >= 96 else 0).getbbox()
    if bounds is None:
        raise ValueError('Empty hero cutout')
    x, y, right, bottom = bounds
    return image.crop((max(0, x - 3), max(0, y - 3), min(image.width, right + 3), min(image.height, bottom + 3)))


def concept(path):
    rgb = np.asarray(Image.open(path).convert('RGB'), dtype=np.float32)
    light_neutral = ((rgb.min(axis=2) >= 224) & (np.ptp(rgb, axis=2) <= 13)).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(light_neutral, 8)
    border = set(np.concatenate((labels[0], labels[-1], labels[:, 0], labels[:, -1])))
    outside = np.zeros(labels.shape, dtype=bool)
    for i in range(1, count):
        if i in border or (stats[i, cv2.CC_STAT_AREA] > 240 and np.median(rgb[labels == i].min(axis=1)) > 240):
            outside |= labels == i
    edge = cv2.dilate(outside.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
    alpha = np.where(outside, 0, np.where(edge, np.clip((249 - rgb.min(axis=2)) / 90, .2, 1), 1))
    rgb = (rgb - (1 - alpha[..., None]) * 249) / np.maximum(.01, alpha[..., None])
    return isolated(Image.fromarray(np.dstack((rgb.clip(0, 255), alpha * 255)).round().astype(np.uint8)))


def video_pose(path, index):
    capture = cv2.VideoCapture(str(path))
    try:
        capture.set(cv2.CAP_PROP_POS_FRAMES, index)
        ok, bgr = capture.read()
        if not ok:
            raise ValueError(f'Cannot read #{index} from {path}')
    finally:
        capture.release()
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB).astype(np.float32)
    red, green, blue = rgb.transpose(2, 0, 1)
    spill = green - np.maximum(red, blue)
    alpha = 1 - np.clip((spill - 24) / 66, 0, 1)
    rgb[:, :, 1] -= np.maximum(spill, 0) * np.clip((spill - 8) / 23, 0, 1)
    return isolated(Image.fromarray(np.dstack((rgb.clip(0, 255), alpha * 255)).round().astype(np.uint8)))


def prop(path, points):
    image = Image.open(path).convert('RGBA')
    mask = Image.new('L', image.size)
    ImageDraw.Draw(mask).polygon(points, fill=255)
    image.putalpha(Image.fromarray(np.minimum(np.asarray(image.getchannel('A')), np.asarray(mask))))
    return isolated(image)


def fit(image, width, height):
    scale = min(width / image.width, height / image.height)
    return image.resize((round(image.width * scale), round(image.height * scale)), RESAMPLE)


def put(canvas, image, cx, bottom, width, height):
    item = fit(image, width, height)
    canvas.alpha_composite(item, (round(cx - item.width / 2), bottom - item.height))


def glow(canvas, box, color, blur):
    layer = Image.new('RGBA', canvas.size)
    ImageDraw.Draw(layer).ellipse(box, fill=color)
    canvas.alpha_composite(layer.filter(ImageFilter.GaussianBlur(blur)))


def main(args):
    ui = ROOT / 'public/assets/ui'
    grass = prop(ui / 'campaign-v3/camp.png', [(32, 602), (736, 602), (736, 703), (32, 703)])
    grass_alpha = np.asarray(grass.getchannel('A')) * np.clip(np.arange(grass.height)[:, None] / 24, 0, 1)
    grass.putalpha(Image.fromarray(grass_alpha.astype(np.uint8)))
    chest = prop(ui / 'campaign-v3/victory.png', [(598, 473), (735, 461), (744, 730), (494, 746),
        (496, 723), (535, 690), (530, 650), (496, 621), (477, 602), (487, 580), (530, 550), (553, 506), (583, 500)])
    heart = isolated(Image.open(ui / 'v2/icons/heart.png').convert('RGBA'))
    scenes = [
        ('camp', concept(args.concept), (134, 189, 158, 85), 332, 550, 557, 541),
        ('victory', video_pose(args.slash, 32), (248, 177, 69, 103), 288, 541, 510, 527),
        ('retry', video_pose(args.down, 38), (107, 175, 231, 87), 322, 545, 530, 485),
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    axis = np.minimum(np.arange(SIZE), np.arange(SIZE)[::-1])
    edge_fade = np.clip((np.minimum(axis[:, None], axis[None, :]) - 1) / 14, 0, 1)
    for name, pose, color, x, floor, width, height in scenes:
        image = Image.new('RGBA', (SIZE, SIZE))
        glow(image, (109, 102, 546, 522), color, 63)
        glow(image, (66, 499, 570, 598), (5, 12, 18, 180), 24)
        if name == 'camp':
            put(image, grass, 320, 593, 600, 105)
        glow(image, (x - 190, floor - 20, x + 190, floor + 25), (5, 10, 18, 135), 16)
        put(image, pose, x, floor, width, height)
        if name == 'victory':
            put(image, chest, 492, 585, 230, 214)
        elif name == 'retry':
            put(image, heart, 112, 578, 97, 97)
        image.putalpha(Image.fromarray(np.rint(np.asarray(image.getchannel('A')) * edge_fade).astype(np.uint8)))
        image.save(args.output / f'{name}.webp', quality=86, method=6)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('concept', type=Path)
    parser.add_argument('slash', type=Path)
    parser.add_argument('down', type=Path)
    parser.add_argument('--output', type=Path, default=ROOT / 'public/assets/ui/campaign-v4')
    main(parser.parse_args())
