import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { parseHTML } from 'linkedom';
import EventEmitter from 'eventemitter3';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
const root=fileURLToPath(new URL('../',import.meta.url));
const api=build({stdin:{contents:`export {CampaignShell} from './src/ui/CampaignShell.ts'; export {ProgressionStore} from './src/progression/ProgressionStore.ts';`,resolveDir:root,loader:'ts'},bundle:true,platform:'node',format:'esm',write:false}).then(r=>import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));
async function fixture(gold = 0, options = {}){const {CampaignShell,ProgressionStore}=await api;const {document,window}=parseHTML('<html><body><div id="game"></div></body></html>');const events=new EventEmitter();const storage={v:null,getItem(){return this.v},setItem(k,v){this.v=v}};storage.v=JSON.stringify({...new ProgressionStore(storage).getProfile(),gold});const store=new ProgressionStore(storage);let unlocked=0;const shell=new CampaignShell(events,store,{document,onUnlockAudio(){unlocked++},...options});events.emit('campaign:ready',{atHome:true});return {document,window,events,store,shell,unlocked:()=>unlocked};}
const click=(f,selector)=>f.document.querySelector(selector).click();
test('Boss practice home and results offer direct start and repeat without progression actions', async () => {
 const f = await fixture(50, {bossTestStage:'desert'});
 try {
  assert.match(f.document.querySelector('.campaign-panel-host').textContent, /沙海堡垒之王/);
  assert.equal(f.document.querySelector('[data-training], [data-stage], [data-loadout]'), null);
  let starts = 0; f.events.on('campaign:start', () => starts++);
  click(f, '[data-action="start"]');
  f.events.emit('campaign:ready',{atHome:false});
  f.events.emit('game:over',{campaign:true, outcome:'victory', stage:'desert', elapsedMs:23_000});
  assert.match(f.document.querySelector('.campaign-panel-host').textContent, /不发放奖励/);
  assert.equal(f.document.querySelector('[data-action="next-stage"], [data-action="result-training"]'), null);
  click(f, '[data-action="retry"]');
  assert.equal(starts, 2);
 } finally { f.shell.destroy(); }
});
test('settlement names the real gap, then opens affordable training without spending gold', async () => {
 const result = {outcome:'defeat', elapsedMs:58000, kills:40, bossKills:0, gold:0};
 const show = async balance => {
   const f = await fixture(balance);
   f.events.emit('campaign:ready', {atHome:false});
   f.events.emit('game:over', {...result, campaign:true, level:5, settlement:{awarded:balance, persisted:true, profile:{gold:balance}}});
   return f;
 };
 const early = await show(12);
 assert.match(early.document.querySelector('.campaign-results').textContent, /还差 8 金币/);
 assert.match(early.document.querySelector('.campaign-results').textContent, /胡椒加特林.*还差 18 金币/);
 early.shell.destroy();
 const f = await show(20);
 f.events.on('campaign:home', () => f.events.emit('campaign:ready', {atHome:true}));
 click(f, '[data-action="result-training"]');
 assert.ok(f.document.querySelector('.campaign-training'));
 assert.equal(f.store.getProfile().gold, 20);
 click(f, '[data-training="health"]');
 assert.equal(f.store.getCampaignProgress().training.health, 1);
 assert.equal(f.store.getProfile().gold, 0);
 f.shell.destroy();
});

test('an affordable new starter is a choice, not a deduction, after defeat', async () => {
 const f = await fixture();
 try {
  const stats={outcome:'defeat',elapsedMs:103000,kills:250,bossKills:1,gold:0};
  const settlement=f.store.settleRun('starter-choice',stats,'meadow');
  const balance=settlement.profile.gold;
  assert.equal(balance,30);
  f.events.emit('campaign:ready',{atHome:false});
  f.events.emit('game:over',{...stats,campaign:true,stage:'meadow',level:6,settlement});
  f.events.on('campaign:home',()=>f.events.emit('campaign:ready',{atHome:true}));
  assert.equal(f.document.querySelector('.campaign-results .primary').dataset.action,'result-loadout');
  click(f,'[data-action="result-loadout"]');
  assert.equal(f.store.getProfile().gold,balance);
  assert.equal(f.store.getProfile().selectedLoadout,'peeler');
  assert.match(f.document.querySelector('.campaign-feedback').textContent,/单体/);
  click(f,'[data-loadout="pepper"]');
  assert.equal(f.store.getProfile().selectedLoadout,'pepper');
  assert.equal(f.store.getProfile().gold,0);
 } finally { f.shell.destroy(); }
});

test('first clear prioritizes a playable next stage over training', async () => {
 const f = await fixture();
 const stats = {outcome:'victory', elapsedMs:196000, kills:200, bossKills:4, gold:20};
 const settlement = f.store.settleRun('first-meadow', stats, 'meadow');
 f.events.emit('campaign:ready', {atHome:false});
 f.events.emit('game:over', {...stats, campaign:true, stage:'meadow', level:8, settlement});
 assert.equal(f.document.querySelector('.campaign-results .primary').dataset.action,'next-stage');
 assert.ok(f.document.querySelector('[data-action="result-loadout"]'));
 let stage;
 f.events.on('campaign:start', () => { stage = f.store.getCampaignProgress().selectedStage; });
 click(f, '[data-action="next-stage"]');
 assert.equal(stage, 'desert');
 f.shell.destroy();
});
test('home explains three-minute finale and combat countdown reaches the final battle', async () => {
 const f = await fixture();
 assert.match(f.document.querySelector('.campaign-brief').textContent, /3 分钟.*终战/);
 f.events.emit('campaign:ready', {atHome:false});
 const status = {phase:'warmup', objective:'积累经验', choosing:false, rerollsRemaining:2};
 f.events.emit('campaign:status', {...status, elapsedMs:0});
 assert.match(f.document.querySelector('.campaign-objective').textContent, /终战 03:00/);
 f.events.emit('campaign:status', {...status, elapsedMs:40});
 assert.match(f.document.querySelector('.campaign-objective').textContent, /终战 03:00/);
 f.events.emit('campaign:status', {...status, elapsedMs:179000});
 assert.match(f.document.querySelector('.campaign-objective').textContent, /终战 00:01/);
 f.events.emit('campaign:status', {...status, phase:'finale', elapsedMs:180000});
 assert.match(f.document.querySelector('.campaign-objective').textContent, /最终战.*击败首领并清场/);
 f.events.emit('campaign:status', {...status, phase:'finale', elapsedMs:181000, finalBossDefeated:true});
 assert.match(f.document.querySelector('.campaign-objective').textContent, /清除剩余怪物/);
 f.shell.destroy();
});
test('settlement explains the first-clear reward and points to permanent training', async () => {
 const f = await fixture();
 f.events.emit('campaign:ready', {atHome: false});
 const stats = {outcome:'victory', elapsedMs:196000, kills:200, bossKills:4, gold:20};
 const settlement = f.store.settleRun('meadow-clear-with-training', stats, 'meadow');
 f.events.emit('game:over', {...stats, campaign:true, stage:'meadow', level:9, settlement});
 const result = f.document.querySelector('.campaign-results').textContent;
 assert.match(result, /青酱草甸/);
 assert.match(result, /首通奖励\s*\+40/);
 assert.match(result, /解锁.*香料沙海/);
 assert.match(result, /训练/);
 assert.doesNotMatch(result, /不增加永久战斗属性/);
 f.shell.destroy();
});
test('stage picker locks desert until meadow is cleared and persists selection', async () => {
 const f = await fixture();
 assert.equal(f.document.querySelector('[data-stage="desert"]').disabled, true);
 f.store.settleRun('stage-clear', {outcome:'victory', elapsedMs:360000, kills:200, bossKills:1, gold:20}, 'meadow');
 f.events.emit('campaign:ready', {atHome: true});
 assert.equal(f.document.querySelector('[data-stage="desert"]').disabled, false);
 click(f, '[data-stage="desert"]');
 assert.equal(f.store.getCampaignProgress().selectedStage, 'desert');
 assert.equal(f.document.querySelector('[data-stage="desert"]').getAttribute('aria-pressed'), 'true');
 f.shell.destroy();
});

test('first-clear home highlights desert and identifies cleared meadow even after selecting it', async () => {
 const f = await fixture();
 f.store.settleRun('first-clear-home', {outcome:'victory',elapsedMs:360000,kills:200,bossKills:1,gold:20}, 'meadow');
 f.events.emit('campaign:ready', {atHome: true});
 assert.match(f.document.querySelector('[data-stage="meadow"] small').textContent, /已通关/);
 assert.equal(f.document.querySelector('[data-stage="desert"]').getAttribute('aria-pressed'), 'true');
 click(f, '[data-stage="meadow"]');
 assert.equal(f.document.querySelector('[data-stage="meadow"]').getAttribute('aria-pressed'), 'true');
 assert.match(f.document.querySelector('[data-stage="meadow"] small').textContent, /已通关/);
 assert.match(f.document.querySelector('[data-stage="meadow"] small').textContent, /已选择/);
 f.shell.destroy();
});
test('camp training displays costs, buys an upgrade and shows saved permanent growth',async()=>{
 const f=await fixture();f.store.settleRun('train-funds',{outcome:'defeat',elapsedMs:20000,kills:3,bossKills:0,gold:20});f.events.emit('campaign:ready',{atHome:true});
 click(f,'[data-action="training"]');assert.match(f.document.body.textContent,/磨刀/);assert.match(f.document.body.textContent,/20/);
 click(f,'[data-training="attack"]');assert.equal(f.store.getCampaignProgress().training.attack,1);assert.equal(f.store.getProfile().gold,11);assert.match(f.document.body.textContent,/Lv\.1/);
 click(f,'[data-action="close-training"]');assert.ok(f.document.querySelector('.campaign-home'));f.shell.destroy();
});
test('home displays the camp hero scene, wallet, all starters and starts on an explicit user gesture',async()=>{const f=await fixture();assert.match(f.document.body.textContent,/土豆远征/);assert.equal(f.document.querySelectorAll('[data-loadout]').length,3);assert.match(f.document.querySelector('.campaign-camp-art img').src,/campaign-v3\/camp.png/);let starts=0;f.events.on('campaign:start',()=>starts++);click(f,'[data-action="start"]');assert.equal(starts,1);assert.equal(f.unlocked(),1);f.shell.destroy();assert.equal(f.document.querySelector('.campaign-shell'),null);});
test('wallet unlocks and selects a new starter without buying permanent stats',async()=>{const f=await fixture();const {profile}=f.store.settleRun('shell-reward',{outcome:'victory',elapsedMs:360000,kills:100,bossKills:4,gold:0});f.events.emit('campaign:ready',{atHome:true});click(f,'[data-loadout="pepper"]');assert.equal(f.store.getProfile().selectedLoadout,'pepper');assert.equal(f.store.getProfile().gold,profile.gold-30);assert.match(f.document.body.textContent,/已选择/);});
test('pause, preferences and backgrounding preserve deliberate pause until resume',async()=>{const f=await fixture();let pause=[];f.events.on('campaign:pause',v=>pause.push(v));f.events.emit('campaign:ready',{atHome:false});click(f,'[data-action="pause"]');assert.deepEqual(pause,[true]);const slider=f.document.querySelector('[name="sfxVolume"]');slider.value='0.2';slider.dispatchEvent(new f.window.Event('input',{bubbles:true}));assert.equal(f.store.getProfile().preferences.sfxVolume,.2);click(f,'[data-action="resume"]');assert.deepEqual(pause,[true,false]);Object.defineProperty(f.document,'hidden',{value:true,configurable:true});f.document.dispatchEvent(new f.window.Event('visibilitychange'));assert.deepEqual(pause,[true,false,true]);Object.defineProperty(f.document,'hidden',{value:false});f.document.dispatchEvent(new f.window.Event('visibilitychange'));assert.equal(pause.length,3);assert.ok(f.document.querySelector('[data-action="resume"]'));});
test('reroll only appears during choosing, has a meaningful remaining count and does not leak listeners',async()=>{const f=await fixture();f.events.emit('campaign:ready',{atHome:false});assert.equal(f.document.querySelector('[data-action="reroll"]').hidden,true);f.events.emit('level:choices',{rerollsRemaining:2});let rerolls=0;f.events.on('upgrade:reroll',()=>rerolls++);click(f,'[data-action="reroll"]');assert.equal(rerolls,1);f.events.emit('campaign:status',{phase:'build',objective:'积累经验',elapsedMs:64000,choosing:true,rerollsRemaining:0});assert.equal(f.document.querySelector('[data-action="reroll"]').disabled,true);f.events.emit('upgrade:closed');assert.equal(f.document.querySelector('[data-action="reroll"]').hidden,true);f.shell.destroy();assert.equal(f.events.listenerCount('campaign:ready'),0);});
test('campaign results display honest persistence, earned gold and retry/home routes',async()=>{const f=await fixture();f.events.emit('campaign:ready',{atHome:false});let retry=0,home=0;f.events.on('campaign:start',()=>retry++);f.events.on('campaign:home',()=>home++);f.events.emit('game:over',{campaign:true,outcome:'defeat',elapsedMs:125000,kills:35,bossKills:1,level:8,gold:12,build:['攻速流'],settlement:{awarded:43,persisted:false,profile:{gold:43}},telemetry:{seed:42,healing:20,damageBySource:{CollisionSystem:120},snapshots:[]}});assert.match(f.document.body.textContent,/再战/);assert.match(f.document.body.textContent,/43/);assert.match(f.document.body.textContent,/未能保存/);click(f,'[data-action="retry"]');assert.equal(retry,1);f.events.emit('game:over',{campaign:true,outcome:'victory',elapsedMs:390000,kills:200,bossKills:4,level:20,gold:22,settlement:{awarded:191,persisted:true,profile:{gold:269}}});assert.match(f.document.body.textContent,/远征胜利/);click(f,'[data-action="home"]');assert.equal(home,1);});
test('pause modal hides combat toolbar so it never overlays the dialog',async()=>{const f=await fixture();f.events.emit('campaign:ready',{atHome:false});click(f,'[data-action="pause"]');assert.equal(f.document.querySelector('.campaign-toolbar').hidden,true);click(f,'[data-action="resume"]');assert.equal(f.document.querySelector('.campaign-toolbar').hidden,false);});

test('automatic choices hide the objective lane until the popup is closed, including pause resume',async()=>{
 const f=await fixture();f.events.emit('campaign:ready',{atHome:false});f.events.emit('level:choices',{rerollsRemaining:2});
 assert.equal(f.document.querySelector('.campaign-toolbar').hidden,true);
 f.events.emit('campaign:paused',true);click(f,'[data-action="resume"]');
 assert.equal(f.document.querySelector('.campaign-toolbar').hidden,true);
 f.events.emit('upgrade:closed');assert.equal(f.document.querySelector('.campaign-toolbar').hidden,false);f.shell.destroy();
});
test('external scene pause notification exposes a resume route and never resumes on its own',async()=>{
 const f=await fixture();f.events.emit('campaign:ready',{atHome:false});let requests=[];f.events.on('campaign:pause',v=>requests.push(v));
 f.events.emit('campaign:paused',true);assert.ok(f.document.querySelector('[data-action="resume"]'));
 assert.equal(f.document.querySelector('.campaign-toolbar').hidden,true);assert.deepEqual(requests,[]);
 click(f,'[data-action="resume"]');assert.deepEqual(requests,[false]);assert.equal(f.document.querySelector('.campaign-toolbar').hidden,false);f.shell.destroy();
});

const bestiaryIds = ['fries_cultist', 'ketchup_slug', 'delivery_box', 'cola_spitter', 'shield_guard', 'onion_flanker', 'corn_bombardier', 'drone_summoner', 'mushroom_hexer', 'chili_scatter', 'pea_sniper', 'donut_jumper', 'desert_cactus', 'desert_scorpion'];
function keyboard(f, key, shiftKey = false) {
 const event = new f.window.Event('keydown', { bubbles: true, cancelable: true });
 Object.defineProperties(event, { key: { value: key }, shiftKey: { value: shiftKey }, repeat: { value: false } });
 f.document.dispatchEvent(event);
 return event;
}
function trackFocus(f) {
 let activeElement = f.document.body;
 Object.defineProperty(f.document, 'activeElement', { configurable: true, get: () => activeElement });
 f.window.HTMLElement.prototype.focus = function () { activeElement = this; };
}
function injectBestiaryAction(f) {
 const action = f.document.createElement('button');
 action.dataset.action = 'bestiary';
 f.document.querySelector('.campaign-shell').append(action);
 action.click();
 action.remove();
}

test('camp bestiary opens fourteen portrait cards without starting or pausing gameplay', async () => {
 const f = await fixture();
 const entrance = f.document.querySelector('[data-action="bestiary"]');
 assert.ok(entrance, 'camp needs a visible bestiary entrance');
 let starts = 0, pauses = 0;
 f.events.on('campaign:start', () => starts++);
 f.events.on('campaign:pause', () => pauses++);
 entrance.click();
 const dialog = f.document.querySelector('.campaign-bestiary');
 assert.equal(dialog.getAttribute('role'), 'dialog');
 assert.equal(dialog.getAttribute('aria-modal'), 'true');
 assert.equal(dialog.querySelector('.campaign-bestiary-scroll').getAttribute('tabindex'), '0');
 assert.equal(dialog.querySelector('.campaign-bestiary-scroll').getAttribute('role'), 'region');
 assert.deepEqual([...dialog.querySelectorAll('[data-monster-id]')].map(card => card.dataset.monsterId), bestiaryIds);
 assert.match(dialog.querySelector('.campaign-eyebrow').textContent, /14 种怪物/);
 for (const card of dialog.querySelectorAll('[data-monster-id]')) {
   const desert = { desert_cactus: '/assets/enemies/desert-v1/cactus.png', desert_scorpion: '/assets/enemies/desert-v1/scorpion.png' };
   assert.equal(card.querySelector('img').getAttribute('src'), desert[card.dataset.monsterId] ?? (bestiaryIds.indexOf(card.dataset.monsterId) >= 8 ? `/assets/bestiary/v4/${card.dataset.monsterId}.png` : `/assets/bestiary/v3/${card.dataset.monsterId}.png`));
   assert.equal(card.querySelector('img').getAttribute('alt'), card.querySelector('h2').textContent);
   assert.ok(card.querySelector('.campaign-bestiary-role').textContent.trim());
   assert.equal(card.querySelectorAll('dd').length, 2);
 }
 assert.equal(starts, 0); assert.equal(pauses, 0); assert.equal(f.unlocked(), 0);
 assert.equal(f.document.querySelector('.campaign-toolbar').hidden, true);
 f.shell.destroy();
});

test('bestiary close and Escape return to camp and restore focus to its entrance', async () => {
 const f = await fixture(); trackFocus(f);
 assert.ok(f.document.querySelector('[data-action="bestiary"]'), 'camp needs a visible bestiary entrance');
 click(f, '[data-action="bestiary"]');
 assert.equal(f.document.activeElement.dataset.action, 'close-bestiary');
 click(f, '[data-action="close-bestiary"]');
 assert.ok(f.document.querySelector('.campaign-home'));
 assert.equal(f.document.activeElement.dataset.action, 'bestiary');
 click(f, '[data-action="bestiary"]');
 assert.equal(keyboard(f, 'Escape').defaultPrevented, true);
 assert.equal(f.document.querySelector('.campaign-bestiary'), null);
 assert.equal(f.document.activeElement.dataset.action, 'bestiary');
 f.shell.destroy();
});

test('bestiary preserves dialog focus trapping and independent camp settings', async () => {
 const f = await fixture(); trackFocus(f);
 assert.ok(f.document.querySelector('[data-action="bestiary"]'), 'camp needs a visible bestiary entrance');
 click(f, '[data-action="bestiary"]');
 const buttons = [...f.document.querySelectorAll('.campaign-bestiary button')];
 buttons[0].focus(); keyboard(f, 'Tab', true);
 assert.equal(f.document.activeElement, buttons.at(-1));
 keyboard(f, 'Tab'); assert.equal(f.document.activeElement, buttons[0]);
 keyboard(f, 'Escape'); click(f, '[data-action="settings"]');
 assert.ok(f.document.querySelector('[name="musicVolume"]'));
 assert.equal(f.document.querySelector('.campaign-bestiary'), null);
 keyboard(f, 'Escape'); assert.ok(f.document.querySelector('.campaign-home'));
 click(f, '[data-action="bestiary"]');
 assert.equal(f.document.querySelector('[name="musicVolume"]'), null);
 f.shell.destroy();
});

test('bestiary cannot open in an active run, choices, pause or results and resets across campaign lifecycle', async () => {
 const f = await fixture();
 assert.ok(f.document.querySelector('[data-action="bestiary"]'));
 click(f, '[data-action="bestiary"]'); f.events.emit('campaign:ready', { atHome: false });
 injectBestiaryAction(f); assert.equal(f.document.querySelector('.campaign-bestiary'), null);
 f.events.emit('level:choices', { rerollsRemaining: 2 });
 injectBestiaryAction(f); assert.equal(f.document.querySelector('.campaign-bestiary'), null);
 assert.equal(f.document.querySelector('[data-action="reroll"]').hidden, false);
 f.events.emit('campaign:paused', true); injectBestiaryAction(f);
 assert.ok(f.document.querySelector('[data-action="resume"]'));
 assert.equal(f.document.querySelector('.campaign-bestiary'), null);
 f.events.emit('game:over', { campaign: true, outcome: 'defeat', elapsedMs: 1000, kills: 1, bossKills: 0, level: 1, gold: 0 });
 injectBestiaryAction(f); assert.ok(f.document.querySelector('.campaign-results'));
 f.events.emit('campaign:ready', { atHome: true });
 assert.ok(f.document.querySelector('.campaign-home'));
 keyboard(f, 'Escape'); assert.ok(f.document.querySelector('.campaign-home'));
 click(f, '[data-action="bestiary"]'); assert.equal(f.document.querySelectorAll('[data-monster-id]').length, 14);
 f.shell.destroy();
});

test('campaign home and result variants place decorative illustrations outside copy and controls', async () => {
 const f = await fixture();
 const campArt = f.document.querySelector('.campaign-camp-art img');
 assert.ok(campArt, 'camp needs a dedicated illustration region');
 assert.equal(campArt.getAttribute('src'), '/assets/ui/campaign-v3/camp.png');
 assert.equal(campArt.getAttribute('alt'), '');
 assert.equal(campArt.parentElement.querySelectorAll('button,h1,p').length, 0);
 assert.equal(f.document.querySelectorAll('.campaign-home-visual img').length, 1, 'the generated scene is the only camp hero illustration');
 for (const [outcome, art] of [['victory', 'victory'], ['defeat', 'retry']]) {
   f.events.emit('campaign:ready', { atHome: false });
   f.events.emit('game:over', { campaign: true, outcome, elapsedMs: 1000, kills: 1, bossKills: 0, level: 1, gold: 0 });
   const resultArt = f.document.querySelector('.campaign-result-art img');
   assert.equal(resultArt.getAttribute('src'), `/assets/ui/campaign-v3/${art}.png`);
   assert.equal(resultArt.getAttribute('alt'), '');
   assert.equal(resultArt.parentElement.querySelectorAll('button,h1,p').length, 0);
   assert.equal(f.document.querySelectorAll('.campaign-results [data-action="retry"], .campaign-results [data-action="home"]').length, 2);
 }
 f.shell.destroy();
});

test('home uses one complete camp scene without a second old hero or controls over the art', async () => {
 const f = await fixture();
 const visual = f.document.querySelector('.campaign-home-visual');
 assert.equal(visual.querySelectorAll('img').length, 1);
 assert.equal(f.document.querySelector('.campaign-home img[src*="idle-v2.png"]'), null);
 assert.equal(visual.querySelectorAll('button').length, 0);
 assert.ok(f.document.querySelector('.campaign-home-footer [data-action="start"]'));
 assert.ok(f.document.querySelector('.campaign-home-footer [data-action="bestiary"]'));
 f.shell.destroy();
});

test('camp and result art use uncropped containment with controlled desktop and compact visible portrait stages', () => {
 const styles = readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
 assert.match(styles, /\.campaign-camp-art\s*\{[^}]*height:\s*min\(400px,\s*56vh\)/s);
 assert.match(styles, /\.campaign-camp-art img\s*\{[^}]*object-fit:\s*contain/s);
 assert.match(styles, /\.campaign-result-art img\s*\{[^}]*object-fit:\s*contain/s);
 assert.match(styles, /@media\s*\(max-width:\s*540px\)\s*\{[\s\S]*?\.campaign-camp-art\s*\{[^}]*height:\s*min\(140px,\s*24vh\)/);
 assert.doesNotMatch(styles, /\.campaign-(?:camp|result)-art img\s*\{[^}]*object-fit:\s*cover/s);
 assert.doesNotMatch(styles, /\.campaign-camp-art\s*\{[^}]*display:\s*none/s);
 assert.match(styles, /\.campaign-overlay\s*\{[^}]*overflow:\s*auto/s);
 assert.match(styles, /\.campaign-home \.campaign-feedback:empty\s*\{[^}]*display:\s*none/s);
});
