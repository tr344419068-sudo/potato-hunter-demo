import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({
  stdin: { contents: `
export { GameScene } from "./src/scenes/GameScene.ts";
export { CampaignDirector } from "./src/campaign/CampaignModel.ts";
export { SkillManager } from "./src/managers/SkillManager.ts";
export { ConfigManager } from "./src/managers/ConfigManager.ts";
export { RewardManager, UPGRADE_REWARD_CHOICES } from "./src/managers/RewardManager.ts";
export { EventBus } from "./src/managers/EventBus.ts";
export { ProjectileCollisionSystem } from "./src/systems/ProjectileCollisionSystem.ts";
export { MonsterBehaviorSystem } from "./src/systems/MonsterBehaviorSystem.ts";
export { DeathSystem } from "./src/systems/DeathSystem.ts";
export { ChapterDirectorSystem } from "./src/systems/ChapterDirectorSystem.ts";
export { MapEventSystem } from "./src/systems/MapEventSystem.ts";
export { SpawnSystem } from "./src/systems/SpawnSystem.ts";
export { createPlayer, createMonster, createProjectile, createMapEvent } from "./src/entities/factories.ts";
`, resolveDir: root, loader: "ts" },
  bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless-seeded-battle", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: `
import EventEmitter from "eventemitter3";
export default {
  Scene: class {}, Events: { EventEmitter },
  Display: { Color: { HexStringToColor: value => ({ color: parseInt(value.slice(1), 16) }) } },
  Utils: { Array: {
    GetRandom: items => items[Math.floor(Math.random() * items.length)],
    Shuffle: items => {
      for (let index = items.length - 1; index > 0; index--) {
        const target = Math.floor(Math.random() * (index + 1));
        [items[index], items[target]] = [items[target], items[index]];
      }
      return items;
    }
  } },
  Math: {
    Clamp: (value, min, max) => Math.min(max, Math.max(min, value)),
    Between: (min, max) => min + Math.floor(Math.random() * (max - min + 1)),
    FloatBetween: (min, max) => min + Math.random() * (max - min)
  }
};`, resolveDir: root }));
  } }],
}).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

async function fixture(seed = 42) {
  const api = await modules;
  api.EventBus.removeAllListeners();
  const scene = new api.GameScene();
  scene.playerId = api.createPlayer(scene.world, 0, 0, 220, 100, 145);
  scene.cameras = { main: { width: 1280, height: 720, shake() {} } };
  scene.scene = { restart() {} };
  scene.campaign = new api.CampaignDirector(seed);
  scene.skillManager = new api.SkillManager({ starterSkillId: "peeler_blade", enforceSlots: true, random: scene.campaign.random.bind(scene.campaign) });
  scene.world.components.health.get(scene.playerId).current = 60;
  const offers = [];
  api.EventBus.on("level:choices", payload => offers.push(payload));
  return { ...api, scene, offers, runtime: scene.createRuntime() };
}

function withGlobalRandom(value, callback) {
  const original = Math.random;
  Math.random = () => value;
  try { return callback(); } finally { Math.random = original; }
}

function monsterAt(fixture, x = 200, y = 0) {
  return fixture.createMonster(fixture.scene.world, fixture.ConfigManager.getMonster("fries_cultist"), x, y);
}

function maximizeSkills(fixture) {
  const random = fixture.scene.skillManager.getRandom();
  fixture.scene.skillManager = new fixture.SkillManager({ random });
  for (const skill of fixture.ConfigManager.skills) {
    for (let level = 0; level < skill.maxLevel; level++) fixture.scene.skillManager.levelUp(skill.id);
  }
  fixture.runtime = fixture.scene.createRuntime();
}

function offerIds(offer) { return offer.choices.map(choice => choice.id); }

test("actual projectile collision uses runtime RNG for critical damage", async () => {
  const current = await fixture();
  const target = monsterAt(current);
  const health = current.scene.world.components.health.get(target);
  const initialHp = health.current;
  current.runtime.random = () => 0;
  current.createProjectile(current.scene.world, 200, 0, 0, 0, "peeler_blade", 10, 0, 1000, 0xffffff, 12, [], 0.5, 2);
  let critical;
  current.EventBus.on("weapon:impact", payload => { critical = payload.critical; });
  withGlobalRandom(0.99, () => new current.ProjectileCollisionSystem().update(16, current.runtime));
  assert.equal(initialHp - health.current, 20);
  assert.equal(critical, true);
});

test("summoner child positions consume runtime RNG", async () => {
  const current = await fixture();
  const summoner = monsterAt(current);
  const monster = current.scene.world.components.monsters.get(summoner);
  monster.behavior = "summoner";
  monster.behaviorTimerMs = 0;
  current.runtime.random = () => 0.25;
  withGlobalRandom(0, () => new current.MonsterBehaviorSystem().update(16, current.runtime));
  const children = [...current.scene.world.components.monsters.keys()].filter(id => id !== summoner);
  assert.equal(children.length, 2);
  for (const child of children) {
    const transform = current.scene.world.components.transforms.get(child);
    assert.ok(Math.abs(transform.x - 200) < 1e-8);
    assert.ok(Math.abs(transform.y - 42) < 1e-8);
  }
});

test("split death affix positions consume runtime RNG", async () => {
  const current = await fixture();
  const target = monsterAt(current);
  Object.assign(current.scene.world.components.monsters.get(target), { isElite: true, eliteAffix: "split" });
  current.scene.world.components.health.get(target).current = 0;
  current.runtime.random = () => 0;
  withGlobalRandom(0.9, () => new current.DeathSystem().update(16, current.runtime));
  const child = [...current.scene.world.components.monsters.keys()][0];
  const transform = current.scene.world.components.transforms.get(child);
  assert.equal(current.scene.world.components.monsters.size, 3);
  assert.equal(transform.x, 234);
  assert.equal(transform.y, 0);
});

test("chapter captain location uses the runtime RNG", async () => {
  const current = await fixture();
  current.runtime.stats.elapsedMs = 24_000;
  current.runtime.random = () => 0.5;
  withGlobalRandom(0, () => new current.ChapterDirectorSystem().update(16, current.runtime));
  const captain = [...current.scene.world.components.monsters.keys()][0];
  const transform = current.scene.world.components.transforms.get(captain);
  assert.ok(Math.abs(transform.x + 430) < 1e-8);
  assert.ok(Math.abs(transform.y) < 1e-8);
});

test("chapter captain difficulty draws from the same run-owned stream", async () => {
  const current = await fixture();
  current.runtime.stats.elapsedMs = 40_000;
  let draws = 0;
  current.runtime.random = () => { draws++; return 0.99; };
  withGlobalRandom(0, () => new current.ChapterDirectorSystem().update(16, current.runtime));
  assert.equal(draws, 2, "captain angle and elite decision must both use the run stream");
});

test("map event placement draws a seeded angle and integer distance", async () => {
  const current = await fixture();
  current.runtime.stats.elapsedMs = 600_000;
  current.runtime.random = () => 0.5;
  withGlobalRandom(0, () => new current.MapEventSystem().update(16, current.runtime));
  assert.ok(current.scene.world.components.mapEvents.size > 0);
  for (const id of current.scene.world.components.mapEvents.keys()) {
    const transform = current.scene.world.components.transforms.get(id);
    assert.ok(Math.abs(transform.x + 270) < 1e-8);
    assert.ok(Math.abs(transform.y) < 1e-8);
  }
});

test("supply reward kind uses seeded randomness and applies actual gold", async () => {
  const current = await fixture();
  current.runtime.random = () => 0.99;
  let reward;
  current.EventBus.on("reward:collected", payload => { reward = payload; });
  withGlobalRandom(0, () => current.RewardManager.applyRandomSupplyReward(current.runtime, 0, 0));
  assert.equal(current.runtime.stats.gold, 35);
  assert.deepEqual(reward, { kind: "gold", value: 35 });
  assert.equal(current.scene.world.components.health.get(current.scene.playerId).current, 60);
});

test("GameScene fallback rewards consume its chooser RNG", async () => {
  const first = await fixture(12);
  const firstChoices = withGlobalRandom(0, () => first.scene.ensureChoiceCount([], 3));
  const second = await fixture(12);
  const secondChoices = withGlobalRandom(0.99, () => second.scene.ensureChoiceCount([], 3));
  assert.deepEqual(firstChoices.map(choice => choice.id), secondChoices.map(choice => choice.id));
});

async function playBattle(seed, globalRandom, cosmeticDraws = 0) {
  const current = await fixture(seed);
  const { scene, runtime } = current;
  const events = { critical: [], rewards: [], chapters: [], offers: [] };
  current.EventBus.on("weapon:impact", payload => events.critical.push(payload.critical));
  current.EventBus.on("reward:collected", payload => events.rewards.push(payload));
  current.EventBus.on("level:chapter", payload => events.chapters.push(payload.id));
  current.EventBus.on("level:choices", payload => events.offers.push({ ids: offerIds(payload), sessionId: payload.sessionId }));
  for (const name of ["fx:sparks", "weapon:impact", "combat:vfx"]) {
    current.EventBus.on(name, () => { for (let index = 0; index < cosmeticDraws; index++) Math.random(); });
  }
  return withGlobalRandom(globalRandom, () => {
    const spawn = new current.SpawnSystem();
    const collision = new current.ProjectileCollisionSystem();
    const chapter = new current.ChapterDirectorSystem();
    const map = new current.MapEventSystem();
    const death = new current.DeathSystem();
    const supply = current.ConfigManager.mapEvents.events.find(event => event.kind === "supply");
    assert.ok(supply);
    for (let step = 0; step < 8; step++) {
      runtime.stats.elapsedMs = 40_000 + step * 1500;
      spawn.update(1500, runtime);
      chapter.update(1500, runtime);
      const target = monsterAt(current, 200 + step * 80, 300);
      const transform = scene.world.components.transforms.get(target);
      scene.world.components.health.get(target).current = 100;
      current.createProjectile(scene.world, transform.x, transform.y, 0, 0, "peeler_blade", 10, 0, 1000, 0xffffff, 12, [], 0.5, 2);
      collision.update(16, runtime);
      current.createMapEvent(scene.world, supply, 0, 0);
      map.update(16, runtime);
    }
    const summoner = monsterAt(current, 500, 400);
    Object.assign(scene.world.components.monsters.get(summoner), { behavior: "summoner", behaviorTimerMs: 0 });
    new current.MonsterBehaviorSystem().update(16, runtime);
    const split = monsterAt(current, 600, 400);
    Object.assign(scene.world.components.monsters.get(split), { isElite: true, eliteAffix: "split" });
    scene.world.components.health.get(split).current = 0;
    death.update(16, runtime);
    scene.requestSkillChoice([]);
    scene.rerollUpgradeChoices();
    const stores = ["transforms", "health", "monsters", "mapEvents", "playerBuffs", "experienceOrbs"];
    const entities = Object.fromEntries(stores.map(name => [name, [...scene.world.components[name].entries()].map(([id, value]) => [id, { ...value }])]));
    return { entities, stats: { ...runtime.stats }, events };
  });
}

test("identical seed and inputs reproduce real entities, HP, crits, supplies, offers and events", async () => {
  const first = await playBattle(42, 0, 0);
  const second = await playBattle(42, 0.99, 9);
  assert.equal(first.events.critical.length, 8);
  assert.equal(first.events.rewards.length, 8);
  assert.equal(first.events.offers.length, 2);
  assert.ok(first.entities.monsters.length > 8);
  assert.deepEqual(second, first);
});

test("a different run seed changes the actual battle report", async () => {
  assert.notDeepEqual(await playBattle(42, 0.5), await playBattle(43, 0.5));
});

test("legacy runtimes without a random callback keep working", async () => {
  const current = await fixture();
  current.runtime.random = undefined;
  current.scene.skillManager = new current.SkillManager();
  const target = monsterAt(current);
  const beforeHp = current.scene.world.components.health.get(target).current;
  current.createProjectile(current.scene.world, 200, 0, 0, 0, "peeler_blade", 10, 0, 1000, 0xffffff, 12, [], 0.5, 2);
  withGlobalRandom(0, () => {
    new current.ProjectileCollisionSystem().update(16, current.runtime);
    current.RewardManager.applyRandomSupplyReward(current.runtime, 0, 0);
    current.runtime.stats.elapsedMs = 40_000;
    new current.ChapterDirectorSystem().update(16, current.runtime);
    new current.MapEventSystem().update(16, current.runtime);
    assert.equal(current.scene.skillManager.getChoices(3).length, 3);
    assert.equal(current.scene.ensureChoiceCount([], 3).length, 3);
  });
  assert.equal(beforeHp - current.scene.world.components.health.get(target).current, 20);
});

test("chooser exclusion replaces all previous offers when enough legal alternatives exist", async () => {
  const current = await fixture();
  const manager = new current.SkillManager({ starterSkillId: "peeler_blade", enforceSlots: true, random: () => 0 });
  const previous = manager.getChoices(3);
  const excluded = new Set(previous.map(choice => choice.id));
  const next = manager.getChoices(3, excluded);
  assert.equal(next.length, 3);
  assert.equal(new Set(next.map(choice => choice.id)).size, 3);
  assert.ok(next.every(choice => !excluded.has(choice.id)));
});

test("three exhausted-skill rewards reroll with at least one meaningful replacement", async () => {
  const current = await fixture();
  maximizeSkills(current);
  current.scene.skillManager = new current.SkillManager({ random: () => 0 });
  maximizeSkills(current);
  current.scene.requestSkillChoice([]);
  const previous = offerIds(current.offers[0]);
  current.scene.rerollUpgradeChoices();
  const next = offerIds(current.offers[1]);
  assert.equal(next.length, 3);
  assert.ok(next.some(id => !previous.includes(id)));
  assert.ok(next.every(id => current.RewardManager.isUpgradeRewardChoice(id)));
});

test("rerolls never bypass active/passive capacity or invent unavailable evolutions", async () => {
  const current = await fixture();
  const manager = current.scene.skillManager;
  for (const skill of current.ConfigManager.skills.filter(skill => skill.category === "active").slice(0, 6)) manager.levelUp(skill.id);
  for (const skill of current.ConfigManager.skills.filter(skill => skill.category === "passive").slice(0, 4)) manager.levelUp(skill.id);
  const previous = new Set(manager.getChoices(3).map(choice => choice.id));
  for (const choice of manager.getChoices(3, previous)) {
    assert.ok(choice.category === "reward" || manager.canLearnSkill(choice.id));
    if (choice.category === "evolution") {
      const evolution = current.ConfigManager.skillEvolutions.find(candidate => candidate.resultSkillId === choice.id);
      assert.ok(evolution.requiredSkills.every(required => manager.getLevel(required.id) >= required.level));
    }
  }
});

test("a legal ready evolution still has priority among nonexcluded choices", async () => {
  const current = await fixture();
  const manager = current.scene.skillManager;
  const evolution = current.ConfigManager.skillEvolutions.find(candidate => candidate.resultSkillId === "pepper_overdrive");
  for (const required of evolution.requiredSkills) {
    while (manager.getLevel(required.id) < required.level) manager.levelUp(required.id);
  }
  const ordinary = manager.getChoices(3).filter(choice => choice.category !== "evolution");
  const next = manager.getChoices(3, new Set(ordinary.map(choice => choice.id)));
  assert.equal(next[0].id, evolution.resultSkillId);
  assert.ok(next.every(choice => !ordinary.some(previous => previous.id === choice.id)));
});

test("real GameScene rerolls create fresh sessions without spending credits or healing", async () => {
  const current = await fixture();
  current.scene.skillManager = new current.SkillManager({ starterSkillId: "peeler_blade", enforceSlots: true, random: () => 0 });
  current.scene.requestSkillChoice([]);
  const first = current.offers[0];
  const initialHp = current.scene.world.components.health.get(current.scene.playerId).current;
  const initialLevel = current.scene.world.components.players.get(current.scene.playerId).level;
  current.scene.rerollUpgradeChoices();
  const second = current.offers[1];
  assert.ok(offerIds(second).every(id => !offerIds(first).includes(id)));
  assert.notEqual(second.sessionId, first.sessionId);
  assert.equal(current.scene.pendingUpgrades, 1);
  assert.equal(current.scene.world.components.health.get(current.scene.playerId).current, initialHp);
  assert.equal(current.scene.world.components.players.get(current.scene.playerId).level, initialLevel);
  current.scene.handleSkillSelected({ skillId: first.choices[0].id, sessionId: first.sessionId });
  assert.equal(current.scene.pendingUpgrades, 1);
  current.scene.rerollUpgradeChoices();
  const third = current.offers[2];
  assert.ok(offerIds(third).some(id => !offerIds(second).includes(id)));
  assert.equal(current.scene.rerollsRemaining, 0);
  current.scene.rerollUpgradeChoices();
  assert.equal(current.offers.length, 3);
  current.scene.handleSkillSelected({ skillId: third.choices[0].id, sessionId: third.sessionId });
  assert.equal(current.scene.pendingUpgrades, 0);
  assert.equal(current.scene.choosingSkill, false);
  const selectedLevel = current.scene.skillManager.getLevel(third.choices[0].id);
  current.scene.handleSkillSelected({ skillId: third.choices[0].id, sessionId: third.sessionId });
  assert.equal(current.scene.skillManager.getLevel(third.choices[0].id), selectedLevel);
});

test("paused GameScene rerolls cannot mutate credits, budget or sessions", async () => {
  const current = await fixture();
  current.scene.requestSkillChoice([]);
  const session = current.scene.upgradeSessionId;
  current.scene.paused = true;
  current.scene.rerollUpgradeChoices();
  assert.equal(current.scene.rerollsRemaining, 2);
  assert.equal(current.scene.pendingUpgrades, 1);
  assert.equal(current.scene.upgradeSessionId, session);
  assert.equal(current.offers.length, 1);
});

test("all exclusions exhausted still return a finite unique legal fallback pool", async () => {
  const current = await fixture();
  maximizeSkills(current);
  const excluded = new Set(current.UPGRADE_REWARD_CHOICES.map(choice => choice.id));
  const choices = current.scene.skillManager.getChoices(20, excluded);
  assert.equal(choices.length, current.UPGRADE_REWARD_CHOICES.length);
  assert.equal(new Set(choices.map(choice => choice.id)).size, choices.length);
  assert.ok(choices.every(choice => current.RewardManager.isUpgradeRewardChoice(choice.id)));
});
