import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const newIds = ["mushroom_hexer", "chili_scatter", "pea_sniper", "donut_jumper"];
const roles = ["hexer", "scatter", "sniper", "jumper"];
const names = ["毒菇术士", "辣椒火枪手", "豌豆狙击手", "甜甜圈跃击者"];
const modules = build({ stdin: { contents: `
  export { World } from "./src/entities/World.ts";
  export * from "./src/entities/factories.ts";
  export { ConfigManager } from "./src/managers/ConfigManager.ts";
  export { SkillManager } from "./src/managers/SkillManager.ts";
  export { WaveManager } from "./src/managers/WaveManager.ts";
  export { MonsterBehaviorSystem } from "./src/systems/MonsterBehaviorSystem.ts";
  export { MonsterAISystem } from "./src/systems/MonsterAISystem.ts";
  export { MovementSystem } from "./src/systems/MovementSystem.ts";
  export { EnemyProjectileSystem } from "./src/systems/EnemyProjectileSystem.ts";
  export { AoeWarningSystem } from "./src/systems/AoeWarningSystem.ts";
  export { MonsterContactSystem } from "./src/systems/MonsterContactSystem.ts";
  export { DeathSystem } from "./src/systems/DeathSystem.ts";
  export { SpawnSystem } from "./src/systems/SpawnSystem.ts";
  export { SpriteJuiceSystem } from "./src/systems/SpriteJuiceSystem.ts";
  export { PlayerStatsSystem } from "./src/systems/PlayerStatsSystem.ts";
  export { RenderSystem } from "./src/systems/RenderSystem.ts";
  export { isPointInChargeWarning } from "./src/systems/MonsterRoleModel.ts";
  export * as juiceModel from "./src/systems/CombatJuiceModel.ts";
  export { BESTIARY_ENTRIES } from "./src/ui/BestiaryModel.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Scenes: { Events: { SHUTDOWN: "shutdown" } }, Math: { Clamp: (value,min,max)=>Math.min(max,Math.max(min,value)), Between: (min,max)=>Math.round((min+max)/2), FloatBetween: (min,max)=>(min+max)/2 } };', resolveDir: root }));
  }}],
}).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

async function fixture(role, playerX = 200) {
  const api = await modules;
  const world = new api.World();
  const playerId = api.createPlayer(world, playerX, 0, 210, 100, 100);
  const runtime = { world, playerId, random: () => 0.5, scene: { cameras: { main: { shake() {} } } }, skillManager: new api.SkillManager(), waveManager: new api.WaveManager(), stats: { elapsedMs: 180000, kills: 0, bossKills: 0, gold: 0 }, campaign: { ownBossCadence: true, spawnMultiplier: 1 } };
  const config = api.ConfigManager.monsters.find(monster => monster.behavior === role) ?? { ...api.ConfigManager.getMonster("corn_bombardier"), behavior: role, damage: role === "sniper" ? 12 : role === "scatter" ? 8 : 10 };
  const id = api.createMonster(world, config, 0, 0);
  world.components.monsters.get(id).behaviorTimerMs = 0;
  return { ...api, world, runtime, id, behavior: new api.MonsterBehaviorSystem(), aoe: new api.AoeWarningSystem(), ai: new api.MonsterAISystem() };
}

function jumpDisplayScene(textured = false) {
  const ellipses = [];
  const circles = [];
  const images = [];
  let fill = { color: 0, alpha: 1 };
  const graphics = new Proxy({}, { get(_owner, property) {
    return (...values) => {
      if (property === "clear") ellipses.length = 0;
      if (property === "clear") circles.length = 0;
      if (property === "fillStyle") fill = { color: values[0], alpha: values[1] ?? 1 };
      if (property === "fillEllipse") ellipses.push({ ...fill, x: values[0], y: values[1], width: values[2], height: values[3] });
      if (property === "fillCircle") circles.push({ ...fill, x: values[0], y: values[1], radius: values[2] });
      return graphics;
    };
  }});
  const scene = { ellipses, images, sys: { renderer: { gl: null } }, events: { once() {} }, textures: { exists: () => textured }, add: new Proxy({}, { get(_owner, kind) {
    return (...args) => {
      if (kind !== "image") return graphics;
      const imageState = { texture: args[2], x: args[0], y: args[1] };
      const image = new Proxy(imageState, { get(owner, property) {
        if (property in owner) return owner[property];
        return (...values) => {
          if (property === "setPosition") [owner.x, owner.y] = values;
          if (property === "setRotation") owner.rotation = values[0];
          if (property === "setTint") owner.tint = values[0];
          if (property === "clearTint") owner.tint = undefined;
          return image;
        };
      }});
      images.push(image); return image;
    };
  } }) };
  return { scene, graphics, ellipses, images, circles };
}

test('hostile rounds draw their registered texture facing velocity and use only a small core if it is missing', async () => {
  const f = await fixture('ranged');
  for (const id of [f.runtime.playerId, f.id]) f.world.components.renders.delete(id);
  f.createEnemyProjectile(f.world, 0, 0, 0, -240, 8, 1800, 'cola');
  f.createEnemyProjectile(f.world, 30, 30, 240, 0, 8, 1800, 'sand');
  const visual = jumpDisplayScene(true); f.runtime.scene = visual.scene;
  const renderer = new f.RenderSystem(visual.scene, visual.graphics);
  renderer.update(16, f.runtime);
  assert.deepEqual(visual.images.map(image => image.texture), ['asset:projectile_hostile_cola', 'asset:projectile_hostile_sand']);
  assert.equal(visual.images[0].rotation, -Math.PI / 2);
  assert.equal(visual.circles.length, 0);
  const missing = jumpDisplayScene(); f.runtime.scene = missing.scene;
  new f.RenderSystem(missing.scene, missing.graphics).update(16, f.runtime);
  assert.ok(missing.circles.length > 0 && missing.circles.every(circle => circle.radius <= 8));
});

test('hostile shots detect crossing the core in one step, but not a near miss or travel after expiry', async () => {
  for (const [y, life, playerSpeed, expected] of [[0, 1800, 0, 92], [24, 1800, 0, 100], [0, 30, 0, 100], [75, 1800, 400, 92]]) {
    const f = await fixture('ranged', 50);
    const shot = f.createEnemyProjectile(f.world, 0, y, 250, 0, 8, life, 'cola');
    f.world.components.velocities.get(f.runtime.playerId).y = playerSpeed;
    new f.MovementSystem().update(400, f.runtime);
    new f.EnemyProjectileSystem().update(400, f.runtime);
    assert.equal(f.world.components.health.get(f.runtime.playerId).current, expected, `y=${y} lifetime=${life} playerSpeed=${playerSpeed}`);
    assert.equal(f.world.components.enemyProjectiles.has(shot), expected === 100);
  }
});

test('when two hostile rounds cross at once, first contact owns the grace window and dash negates both', async () => {
  for (const dash of [false, true]) {
    const f = await fixture('ranged', 50);
    f.createEnemyProjectile(f.world, -20, 0, 250, 0, 14);
    f.createEnemyProjectile(f.world, 12, 0, 250, 0, 8);
    if (dash) f.world.components.players.get(f.runtime.playerId).dashRemainingMs = 80;
    new f.MovementSystem().update(250, f.runtime);
    new f.EnemyProjectileSystem().update(250, f.runtime);
    assert.equal(f.world.components.health.get(f.runtime.playerId).current, dash ? 100 : 92);
    assert.equal(f.world.components.enemyProjectiles.size, 0);
  }
});

test('swept hostile damage samples recovery and dash at contact, regardless of combat step partition', async () => {
  for (const mode of ['damageCooldownMs', 'dashRemainingMs']) {
    for (const steps of [[40], [20, 20]]) {
      const f = await fixture('ranged', 50);
      // Grazing shot touches between 17.7ms and 22.3ms, before protection ends at 30ms.
      f.createEnemyProjectile(f.world, 0, 22.3, 2500, 0, 8);
      const player = f.world.components.players.get(f.runtime.playerId);
      player[mode] = 30;
      for (const step of steps) {
        f.runtime.hostileProtectionAtStepStart = { damageCooldownMs: player.damageCooldownMs, dashRemainingMs: player.dashRemainingMs };
        player[mode] = Math.max(0, player[mode] - step);
        new f.MovementSystem().update(step, f.runtime);
        new f.EnemyProjectileSystem().update(step, f.runtime);
      }
      assert.equal(f.world.components.health.get(f.runtime.playerId).current, 100, `${mode}, ${steps.join('+')}ms`);
      assert.equal(f.world.components.enemyProjectiles.size, 0);
    }
  }
});

test('authored desert scorpion keeps its original colors without changing legacy flanker tint', async () => {
  const f = await fixture('flanker'); const visual = jumpDisplayScene(true); f.runtime.scene = visual.scene;
  f.world.components.renders.delete(f.runtime.playerId);
  const render = f.world.components.renders.get(f.id);
  const renderer = new f.RenderSystem(visual.scene, visual.graphics);
  renderer.update(16, f.runtime);
  assert.equal(visual.images[0].tint, render.color);
  render.assetId = 'enemy_desert_scorpion'; renderer.update(16, f.runtime);
  assert.equal(visual.images[0].tint, undefined);
});

test("four new configured identities preserve all eight existing combat values", async () => {
  const { ConfigManager } = await modules;
  const baseline = JSON.parse(readFileSync(new URL("../artifacts/generated-2026-11-18/monsters-before-art.json", import.meta.url), "utf8"));
  assert.deepEqual(ConfigManager.monsters.slice(12, 14).map(monster => monster.id), ['desert_cactus', 'desert_scorpion']);
  for (const previous of baseline.monsters) {
    const current = ConfigManager.getMonster(previous.id);
    const { assetId: previousArt, ...previousStats } = previous;
    const { assetId: currentArt, ...currentStats } = current;
    assert.deepEqual(currentStats, previousStats);
    assert.equal(currentArt, ["delivery_box", "shield_guard", "drone_summoner"].includes(previous.id) ? `enemy_${previous.id}_v3` : previousArt);
  }
  for (const [index, id] of newIds.entries()) {
    const monster = ConfigManager.monsters.find(candidate => candidate.id === id);
    assert.ok(monster, `${id} is not a real configured spawn`);
    assert.equal(monster.name, names[index]); assert.equal(monster.behavior, roles[index]);
    assert.equal(monster.assetId, `enemy_${id}_v4`);
    assert.ok(monster.hp >= 60 && monster.hp <= 90);
    assert.ok(monster.speed >= 50 && monster.speed <= 80);
    assert.ok(monster.damage >= 8 && monster.damage <= 12);
    assert.ok(monster.experienceValue >= 9 && monster.experienceValue <= 12);
  }
});

test("hexer snapshots a 62-radius warning then creates a short poisonous ground zone", async () => {
  const f = await fixture("hexer");
  f.behavior.update(0, f.runtime);
  const [warningId, warning] = [...f.world.components.aoeWarnings][0] ?? [];
  assert.ok(warning, "hexer has no toxic circle attack");
  assert.equal(f.world.components.transforms.get(warningId).x, 200);
  assert.equal(f.world.components.transforms.get(warningId).radius, 62);
  assert.equal(warning.totalMs, 1000); assert.equal(warning.damage, 6);
  assert.ok(warning.zone, "hexer still duplicates the corn bombardier's one-shot circle");
  assert.equal(warning.zone.remainingMs, 2400); assert.equal(warning.zone.tickIntervalMs, 750);
  assert.equal(warning.zone.tickDamage, 2); assert.equal(warning.zone.ticksRemaining, 3);
  f.aoe.update(0, f.runtime); f.behavior.update(999, f.runtime); f.aoe.update(999, f.runtime);
  assert.equal(f.world.components.health.get(f.runtime.playerId).current, 100);
  f.behavior.update(1, f.runtime); f.aoe.update(1, f.runtime);
  assert.equal(f.world.components.health.get(f.runtime.playerId).current, 94);
  assert.equal(f.world.components.aoeWarnings.size, 1);
  const stats = new f.PlayerStatsSystem();
  for (const expectedHp of [92,90,88]) {
    stats.update(750, f.runtime); f.aoe.update(750, f.runtime);
    assert.equal(f.world.components.health.get(f.runtime.playerId).current, expectedHp);
  }
  f.aoe.update(150, f.runtime); assert.equal(f.world.components.aoeWarnings.size, 0);
  f.aoe.update(5000, f.runtime); assert.equal(f.world.components.health.get(f.runtime.playerId).current, 88);
});

test("hexer poison ticks stop outside the snapshot circle and never replay a long-frame backlog", async () => {
  const fixtureState = await fixture("hexer");
  fixtureState.behavior.update(0, fixtureState.runtime); fixtureState.aoe.update(0, fixtureState.runtime);
  fixtureState.behavior.update(1000, fixtureState.runtime); fixtureState.aoe.update(1000, fixtureState.runtime);
  const player = fixtureState.world.components.transforms.get(fixtureState.runtime.playerId);
  const health = fixtureState.world.components.health.get(fixtureState.runtime.playerId);
  const stats = new fixtureState.PlayerStatsSystem();
  assert.equal(health.current, 94);
  player.x = 400;
  stats.update(750, fixtureState.runtime); fixtureState.aoe.update(750, fixtureState.runtime);
  assert.equal(health.current, 94, "poison followed the player outside the ground zone");
  player.x = 200;
  stats.update(1000, fixtureState.runtime); fixtureState.aoe.update(1000, fixtureState.runtime);
  assert.equal(health.current, 92, "a long frame replayed multiple poison ticks");
  stats.update(10000, fixtureState.runtime); fixtureState.aoe.update(10000, fixtureState.runtime);
  assert.equal(health.current, 92); assert.equal(fixtureState.world.components.aoeWarnings.size, 0);
});

test("poison ticks respect real hostile-hit grace and dashing", async () => {
  const fixtureState = await fixture("hexer");
  fixtureState.behavior.update(0, fixtureState.runtime); fixtureState.aoe.update(0, fixtureState.runtime);
  fixtureState.behavior.update(1000, fixtureState.runtime); fixtureState.aoe.update(1000, fixtureState.runtime);
  const player = fixtureState.world.components.players.get(fixtureState.runtime.playerId);
  const health = fixtureState.world.components.health.get(fixtureState.runtime.playerId);
  assert.equal(health.current, 94);
  player.dashRemainingMs = 1000; player.damageCooldownMs = 0;
  fixtureState.aoe.update(750, fixtureState.runtime); assert.equal(health.current, 94);
  player.dashRemainingMs = 0; player.damageCooldownMs = 1000;
  fixtureState.aoe.update(750, fixtureState.runtime); assert.equal(health.current, 94);
  player.damageCooldownMs = 0;
  fixtureState.aoe.update(750, fixtureState.runtime); assert.equal(health.current, 92);
  fixtureState.aoe.update(150, fixtureState.runtime); assert.equal(fixtureState.world.components.aoeWarnings.size, 0);
});

test("hexer purple warning becomes a green persistent poison zone in the actual renderer", async () => {
  const fixtureState = await fixture("hexer");
  const display = jumpDisplayScene(); fixtureState.runtime.scene = display.scene;
  const renderer = new fixtureState.RenderSystem(display.scene, display.graphics);
  fixtureState.behavior.update(0, fixtureState.runtime); renderer.update(0, fixtureState.runtime);
  assert.ok(display.circles.some(circle => circle.x === 200 && circle.radius === 62 && circle.color === 0x9b5de5), "poison windup has no purple presentation");
  fixtureState.aoe.update(0, fixtureState.runtime); fixtureState.behavior.update(1000, fixtureState.runtime); fixtureState.aoe.update(1000, fixtureState.runtime);
  renderer.update(0, fixtureState.runtime);
  assert.ok(display.circles.some(circle => circle.x === 200 && circle.radius === 62 && circle.color === 0x57cc99), "active poison zone has no green presentation");
  assert.equal(fixtureState.world.components.aoeWarnings.size, 1);
});

test("corn keeps its original one-shot blast and does not inherit poisonous ground zones", async () => {
  const fixtureState = await fixture("bombardier");
  fixtureState.behavior.update(0, fixtureState.runtime);
  const warning = [...fixtureState.world.components.aoeWarnings.values()][0];
  assert.equal(warning.totalMs, 900); assert.equal(warning.damage, 10); assert.equal(warning.zone, undefined);
  fixtureState.aoe.update(0, fixtureState.runtime); fixtureState.aoe.update(900, fixtureState.runtime);
  assert.equal(fixtureState.world.components.health.get(fixtureState.runtime.playerId).current, 90);
  assert.equal(fixtureState.world.components.aoeWarnings.size, 0);
});

test("scatter fires three fixed-gap fan bullets without a long-frame catch-up burst", async () => {
  const f = await fixture("scatter");
  f.behavior.update(60000, f.runtime);
  const bullets = [...f.world.components.enemyProjectiles.keys()];
  assert.equal(bullets.length, 3, "scatter must fire one three-shot fan, not a ranged shot or catch-up burst");
  const angles = bullets.map(id => {
    const velocity = f.world.components.velocities.get(id);
    assert.ok(Math.abs(Math.hypot(velocity.x, velocity.y) - 180) < 1e-6);
    assert.equal(f.world.components.enemyProjectiles.get(id).damage, 8);
    assert.equal(f.world.components.renders.get(id).assetId, 'projectile_hostile_ember');
    return Math.atan2(velocity.y, velocity.x);
  });
  assert.ok(Math.abs(angles[1]) < 1e-6);
  assert.ok(Math.abs(angles[2] - angles[1] - (angles[1] - angles[0])) < 1e-6);
  assert.ok(angles[0] < -0.15 && angles[2] > 0.15);
  f.behavior.update(2999, f.runtime); assert.equal(f.world.components.enemyProjectiles.size, 3);
  f.behavior.update(1, f.runtime); assert.equal(f.world.components.enemyProjectiles.size, 6);
});

test("sniper stops during its line telegraph then fires one locked-aim fast shot", async () => {
  const f = await fixture("sniper", 350);
  f.behavior.update(0, f.runtime);
  const [warningId, warning] = [...f.world.components.aoeWarnings][0] ?? [];
  assert.ok(warning, "sniper has no line telegraph");
  assert.equal(warning.shape, "rectangle"); assert.equal(warning.totalMs, 1000); assert.equal(warning.damage, 0);
  assert.equal(warning.angle, 0); assert.ok(warning.length >= 350);
  f.world.components.transforms.get(f.runtime.playerId).y = 200;
  f.ai.update(16, f.runtime); assert.deepEqual(f.world.components.velocities.get(f.id), { x: 0, y: 0 });
  f.aoe.update(0, f.runtime); f.behavior.update(999, f.runtime); f.aoe.update(999, f.runtime);
  assert.equal(f.world.components.enemyProjectiles.size, 0);
  assert.ok(f.world.components.aoeWarnings.has(warningId));
  f.behavior.update(1, f.runtime);
  const bulletId = [...f.world.components.enemyProjectiles.keys()][0];
  assert.equal(f.world.components.enemyProjectiles.size, 1);
  assert.deepEqual(f.world.components.velocities.get(bulletId), { x: 300, y: 0 });
  assert.equal(f.world.components.enemyProjectiles.get(bulletId).damage, 12);
  assert.equal(f.world.components.renders.get(bulletId).assetId, 'projectile_hostile_sniper');
  assert.equal(f.world.components.aoeWarnings.size, 0);
});

test("sniper line telegraph covers all 660px of bullet travel plus the complete collision envelope", async () => {
  const fixtureState = await fixture("sniper", 350);
  const playerRadius = fixtureState.world.components.transforms.get(fixtureState.runtime.playerId).radius;
  fixtureState.behavior.update(0, fixtureState.runtime);
  const warning = [...fixtureState.world.components.aoeWarnings.values()][0];
  assert.equal(warning.length, 660, "warning still ends 100px before the bullet's travel ends");
  assert.equal(warning.contactPadding, playerRadius + 7);
  assert.equal(warning.width, (playerRadius + 7) * 2);
  fixtureState.behavior.update(1000, fixtureState.runtime);
  const bulletId = [...fixtureState.world.components.enemyProjectiles.keys()][0];
  const lifetime = fixtureState.world.components.lifetimes.get(bulletId).totalMs;
  new fixtureState.MovementSystem().update(lifetime, fixtureState.runtime);
  const bullet = fixtureState.world.components.transforms.get(bulletId);
  assert.equal(bullet.x, 660); assert.equal(bullet.y, 0);
  assert.ok(fixtureState.isPointInChargeWarning(bullet.x + playerRadius + 7, 0, 0, 0, warning));
  assert.ok(fixtureState.isPointInChargeWarning(-playerRadius - 7, 0, 0, 0, warning));
  assert.ok(fixtureState.isPointInChargeWarning(350, playerRadius + 7, 0, 0, warning));
  assert.equal(fixtureState.isPointInChargeWarning(bullet.x + playerRadius + 7 + 0.01, 0, 0, 0, warning), false);
});

test("jumper locks a landing circle, moves finitely to it, then hits once and recovers", async () => {
  const f = await fixture("jumper");
  f.behavior.update(0, f.runtime);
  const [warningId, warning] = [...f.world.components.aoeWarnings][0] ?? [];
  assert.ok(warning, "jumper has no landing circle");
  assert.equal(warning.totalMs, 900); assert.equal(warning.damage, 10); assert.equal(warning.armed, false);
  assert.equal(f.world.components.transforms.get(warningId).x, 200);
  f.ai.update(16, f.runtime); f.behavior.update(899, f.runtime);
  assert.equal(f.world.components.transforms.get(f.id).x, 0);
  f.aoe.update(0, f.runtime); f.behavior.update(1, f.runtime); f.aoe.update(900, f.runtime);
  assert.equal(f.world.components.health.get(f.runtime.playerId).current, 100);
  f.world.components.transforms.get(f.runtime.playerId).x = 220;
  f.behavior.update(200, f.runtime);
  assert.ok(f.world.components.transforms.get(f.id).x > 0 && f.world.components.transforms.get(f.id).x < 200);
  f.ai.update(16, f.runtime); new f.MovementSystem().update(10000, f.runtime);
  assert.ok(f.world.components.transforms.get(f.id).x < 200, "generic movement overrides the leap");
  f.behavior.update(200, f.runtime); f.aoe.update(200, f.runtime);
  assert.equal(f.world.components.transforms.get(f.id).x, 200);
  assert.equal(f.world.components.health.get(f.runtime.playerId).current, 90);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  f.behavior.update(699, f.runtime); f.ai.update(16, f.runtime);
  assert.deepEqual(f.world.components.velocities.get(f.id), { x: 0, y: 0 });
  f.aoe.update(10000, f.runtime); assert.equal(f.world.components.health.get(f.runtime.playerId).current, 90);
  f.behavior.update(1, f.runtime); assert.equal(f.world.components.monsters.get(f.id).controlledMotion, false);
});

test("jumper contact is disabled throughout windup, flight and recovery but returns during walking", async () => {
  const f = await fixture("jumper");
  const contact = new f.MonsterContactSystem();
  const player = f.world.components.transforms.get(f.runtime.playerId);
  const playerState = f.world.components.players.get(f.runtime.playerId);
  const health = f.world.components.health.get(f.runtime.playerId);
  f.behavior.update(0, f.runtime);
  player.x = 0;
  contact.update(0, f.runtime);
  assert.equal(health.current, 100, "windup caused unintended contact damage");
  assert.equal(playerState.damageCooldownMs, 0, "windup contact consumed hit grace");
  f.aoe.update(0, f.runtime); f.behavior.update(900, f.runtime); f.aoe.update(900, f.runtime);
  f.behavior.update(100, f.runtime);
  assert.equal(f.world.components.transforms.get(f.id).x, 50);
  player.x = 50;
  contact.update(0, f.runtime);
  assert.equal(health.current, 100, "flight behaved like a damaging ground charge");
  assert.equal(playerState.damageCooldownMs, 0);
  player.x = 200;
  f.behavior.update(300, f.runtime); f.aoe.update(300, f.runtime); contact.update(0, f.runtime);
  assert.equal(health.current, 90, "landing should cause exactly one circle hit");
  playerState.damageCooldownMs = 0;
  f.behavior.update(699, f.runtime); contact.update(0, f.runtime);
  assert.equal(health.current, 90, "recovery caused unintended contact damage");
  f.behavior.update(1, f.runtime); contact.update(0, f.runtime);
  assert.equal(health.current, 80, "normal walking contact never resumed");
});

test("jumper jumpProgress exists only during its real 400ms flight and clears on landing or death", async () => {
  const fixtureState = await fixture("jumper");
  const monster = fixtureState.world.components.monsters.get(fixtureState.id);
  fixtureState.behavior.update(0, fixtureState.runtime);
  assert.equal(monster.jumpProgress, undefined);
  fixtureState.behavior.update(899, fixtureState.runtime);
  assert.equal(monster.jumpProgress, undefined);
  fixtureState.behavior.update(1, fixtureState.runtime);
  assert.equal(monster.jumpProgress, 0, "flight has no visual progress at takeoff");
  fixtureState.behavior.update(100, fixtureState.runtime); assert.equal(monster.jumpProgress, 0.25);
  fixtureState.behavior.update(100, fixtureState.runtime); assert.equal(monster.jumpProgress, 0.5);
  fixtureState.behavior.update(100, fixtureState.runtime); assert.equal(monster.jumpProgress, 0.75);
  fixtureState.behavior.update(100, fixtureState.runtime); assert.equal(monster.jumpProgress, undefined);
  fixtureState.behavior.update(700, fixtureState.runtime); assert.equal(monster.jumpProgress, undefined);
  const deadState = await fixture("jumper");
  deadState.behavior.update(0, deadState.runtime); deadState.behavior.update(900, deadState.runtime); deadState.behavior.update(200, deadState.runtime);
  assert.equal(deadState.world.components.monsters.get(deadState.id).jumpProgress, 0.5);
  deadState.world.components.health.get(deadState.id).current = 0;
  deadState.behavior.update(0, deadState.runtime);
  assert.equal(deadState.world.components.monsters.get(deadState.id).jumpProgress, undefined);
});

test("actual sprite juice raises the jumper by a 42px sine arc and restores its grounded pose", async () => {
  const fixtureState = await fixture("jumper");
  const { scene } = jumpDisplayScene();
  fixtureState.runtime.scene = scene;
  const juice = new fixtureState.SpriteJuiceSystem(scene);
  try {
    fixtureState.behavior.update(0, fixtureState.runtime); juice.update(0, fixtureState.runtime);
    const grounded = fixtureState.world.components.spriteJuices.get(fixtureState.id);
    assert.equal(grounded.offsetY, 0);
    fixtureState.behavior.update(900, fixtureState.runtime);
    fixtureState.behavior.update(100, fixtureState.runtime); juice.update(0, fixtureState.runtime);
    const rising = fixtureState.world.components.spriteJuices.get(fixtureState.id);
    assert.ok(Math.abs(rising.offsetY + 42 * Math.sin(Math.PI * 0.25)) < 1e-9, "rising pose is still grounded");
    fixtureState.behavior.update(100, fixtureState.runtime); juice.update(0, fixtureState.runtime);
    const apex = fixtureState.world.components.spriteJuices.get(fixtureState.id);
    assert.equal(apex.offsetY, -42);
    assert.ok(apex.shadowScaleX < grounded.shadowScaleX && apex.shadowScaleY < grounded.shadowScaleY);
    assert.ok(apex.shadowAlpha < grounded.shadowAlpha);
    fixtureState.behavior.update(100, fixtureState.runtime); juice.update(0, fixtureState.runtime);
    assert.ok(Math.abs(fixtureState.world.components.spriteJuices.get(fixtureState.id).offsetY - rising.offsetY) < 1e-9);
    fixtureState.behavior.update(100, fixtureState.runtime); juice.update(0, fixtureState.runtime);
    const landed = fixtureState.world.components.spriteJuices.get(fixtureState.id);
    assert.equal(landed.offsetY, 0); assert.equal(landed.shadowScaleX, 1); assert.equal(landed.shadowAlpha, 0.22);
  } finally { juice.destroy(); }
});

test("actual renderer keeps the airborne jumper shadow at its ground footpoint while shrinking and fading it", async () => {
  const fixtureState = await fixture("jumper");
  const display = jumpDisplayScene(); fixtureState.runtime.scene = display.scene;
  fixtureState.world.components.renders.delete(fixtureState.runtime.playerId);
  const juice = new fixtureState.SpriteJuiceSystem(display.scene);
  const renderer = new fixtureState.RenderSystem(display.scene, display.graphics);
  try {
    fixtureState.behavior.update(0, fixtureState.runtime); juice.update(0, fixtureState.runtime); renderer.update(0, fixtureState.runtime);
    const grounded = display.ellipses.find(ellipse => ellipse.color === 0x020805);
    assert.ok(grounded, "actual renderer produced no contact shadow");
    fixtureState.behavior.update(900, fixtureState.runtime); fixtureState.behavior.update(200, fixtureState.runtime);
    juice.update(0, fixtureState.runtime); renderer.update(0, fixtureState.runtime);
    const airborne = display.ellipses.find(ellipse => ellipse.color === 0x020805);
    const bodyColor = fixtureState.world.components.renders.get(fixtureState.id).color;
    const body = display.ellipses.find(ellipse => ellipse.color === bodyColor);
    assert.equal(airborne.x, 100); assert.equal(airborne.y, grounded.y, "shadow moved upward with the sprite");
    assert.equal(body.y, -42, "renderer ignored the flight pose");
    assert.ok(airborne.width < grounded.width && airborne.height < grounded.height);
    assert.ok(airborne.alpha < grounded.alpha, "actual shadow drawing did not fade");
    assert.equal(fixtureState.world.components.transforms.get(fixtureState.id).y, 0, "visual lift altered gameplay coordinates");
  } finally { juice.destroy(); }
});

test("jump pose model is symmetric, bounded and grounded outside its normalized flight", async () => {
  const { juiceModel } = await modules;
  assert.equal(typeof juiceModel.getMonsterJumpPose, "function");
  const grounded = juiceModel.getMonsterJumpPose(0);
  const apex = juiceModel.getMonsterJumpPose(0.5);
  assert.equal(grounded.offsetY, 0); assert.equal(apex.offsetY, -42);
  assert.deepEqual(juiceModel.getMonsterJumpPose(-1), grounded);
  assert.ok(Math.abs(juiceModel.getMonsterJumpPose(2).offsetY) < 1e-9);
  for (const progress of [0,0.1,0.25,0.5,0.75,0.9,1]) {
    const pose = juiceModel.getMonsterJumpPose(progress);
    assert.ok(pose.offsetY >= -42 && pose.offsetY <= 1e-9);
    assert.ok(pose.shadowScaleX >= 0.75 && pose.shadowScaleX <= 1);
    assert.ok(pose.shadowScaleY >= 0.75 && pose.shadowScaleY <= 1);
    assert.ok(pose.shadowAlpha > 0 && pose.shadowAlpha <= 0.22);
    assert.ok(Math.abs(pose.offsetY - juiceModel.getMonsterJumpPose(1 - progress).offsetY) < 1e-9);
  }
});

test("textured jumper image rises while its configured footpoint shadow stays on the ground", async () => {
  const fixtureState = await fixture("jumper");
  const display = jumpDisplayScene(true); fixtureState.runtime.scene = display.scene;
  fixtureState.world.components.renders.delete(fixtureState.runtime.playerId);
  const juice = new fixtureState.SpriteJuiceSystem(display.scene);
  const renderer = new fixtureState.RenderSystem(display.scene, display.graphics);
  try {
    fixtureState.behavior.update(0, fixtureState.runtime); juice.update(0, fixtureState.runtime); renderer.update(0, fixtureState.runtime);
    const grounded = display.ellipses.find(ellipse => ellipse.color === 0x020805);
    fixtureState.behavior.update(900, fixtureState.runtime); fixtureState.behavior.update(200, fixtureState.runtime);
    juice.update(0, fixtureState.runtime); renderer.update(0, fixtureState.runtime);
    const shadow = display.ellipses.find(ellipse => ellipse.color === 0x020805);
    const image = display.images.find(candidate => candidate.texture === "asset:enemy_donut_jumper_v4");
    assert.ok(image, "the real textured render branch was not exercised");
    assert.equal(image.x, 100); assert.equal(image.y, -42);
    assert.ok(Math.abs(shadow.x - grounded.x - 100) < 1e-9);
    assert.equal(shadow.y, grounded.y);
    assert.ok(shadow.width < grounded.width && shadow.alpha < grounded.alpha);
  } finally { juice.destroy(); }
});

test("real DeathSystem removal cancels new pending casts without losing or duplicating kills and experience", async () => {
  for (const role of ["hexer", "sniper", "jumper"]) {
    const f = await fixture(role);
    const experience = f.world.components.monsters.get(f.id).experienceValue;
    const death = new f.DeathSystem();
    f.behavior.update(0, f.runtime);
    assert.equal(f.world.components.aoeWarnings.size, 1);
    f.world.components.health.get(f.id).current = 0;
    death.update(16, f.runtime);
    assert.equal(f.world.components.monsters.has(f.id), false);
    assert.equal(f.runtime.stats.kills, 1); assert.equal(f.runtime.stats.bossKills, 0);
    assert.deepEqual([...f.world.components.experienceOrbs.values()].map(orb => orb.value), [experience]);
    f.behavior.update(60000, f.runtime); f.aoe.update(60000, f.runtime); death.update(16, f.runtime);
    assert.equal(f.world.components.aoeWarnings.size, 0); assert.equal(f.world.components.enemyProjectiles.size, 0);
    assert.equal(f.world.components.health.get(f.runtime.playerId).current, 100);
    assert.equal(f.runtime.stats.kills, 1);
    assert.deepEqual([...f.world.components.experienceOrbs.values()].map(orb => orb.value), [experience]);
  }
});

test("all new roles have finite attack ranges and do not attack distant targets", async () => {
  for (const [index, role] of roles.entries()) {
    const range = [420, 380, 560, 240][index];
    const f = await fixture(role, range + 1); f.behavior.update(60000, f.runtime);
    assert.equal(f.world.components.aoeWarnings.size, 0, `${role} warned outside its range`);
    assert.equal(f.world.components.enemyProjectiles.size, 0, `${role} fired outside its range`);
    assert.equal(f.world.components.monsters.get(f.id).controlledMotion, undefined);
    f.world.components.transforms.get(f.runtime.playerId).x = range;
    f.behavior.update(0, f.runtime);
    assert.equal(role === "scatter" ? f.world.components.enemyProjectiles.size : f.world.components.aoeWarnings.size, role === "scatter" ? 3 : 1, `${role} cannot attack at its documented range`);
  }
});

test("hexer keeps the original warning position when its target leaves the circle", async () => {
  const f = await fixture("hexer"); f.behavior.update(0, f.runtime);
  const warningId = [...f.world.components.aoeWarnings.keys()][0];
  f.world.components.transforms.get(f.runtime.playerId).x = 400;
  f.aoe.update(0, f.runtime); f.behavior.update(1000, f.runtime); f.aoe.update(1000, f.runtime);
  assert.equal(f.world.components.health.get(f.runtime.playerId).current, 100);
  assert.equal(f.world.components.transforms.get(warningId)?.x, 200);
  f.aoe.update(2400, f.runtime);
  assert.equal(f.world.components.aoeWarnings.has(warningId), false);
});

test("each windup advances at most one action stage on a long frame", async () => {
  for (const role of ["hexer", "sniper", "jumper"]) {
    const f = await fixture(role); f.behavior.update(60000, f.runtime);
    assert.equal(f.world.components.aoeWarnings.size, 1);
    assert.equal(f.world.components.enemyProjectiles.size, 0);
    f.aoe.update(0, f.runtime); f.behavior.update(60000, f.runtime); f.aoe.update(60000, f.runtime);
    assert.equal(f.world.components.enemyProjectiles.size, role === "sniper" ? 1 : 0);
    if (role === "jumper") {
      assert.equal(f.world.components.transforms.get(f.id).x, 0);
      assert.equal(f.world.components.health.get(f.runtime.playerId).current, 100);
      f.behavior.update(60000, f.runtime); f.aoe.update(60000, f.runtime);
    }
    assert.equal(f.world.components.health.get(f.runtime.playerId).current, role === "sniper" ? 100 : role === "hexer" ? 94 : 90);
    if (role === "hexer") {
      assert.equal(f.world.components.aoeWarnings.size, 1);
      f.aoe.update(2400, f.runtime);
      assert.equal(f.world.components.health.get(f.runtime.playerId).current, 94);
    }
    assert.equal(f.world.components.aoeWarnings.size, 0);
  }
});

test("dead or removed new casters cancel pending warnings and release owned motion", async () => {
  for (const role of ["hexer", "sniper", "jumper"]) {
    for (const removed of [false, true]) {
      const f = await fixture(role); f.behavior.update(0, f.runtime);
      assert.equal(f.world.components.aoeWarnings.size, 1, `${role} did not begin its cast`);
      if (removed) f.world.destroyEntity(f.id); else f.world.components.health.get(f.id).current = 0;
      f.behavior.update(60000, f.runtime); f.aoe.update(60000, f.runtime);
      assert.equal(f.world.components.aoeWarnings.size, 0); assert.equal(f.world.components.enemyProjectiles.size, 0);
      assert.equal(f.world.components.health.get(f.runtime.playerId).current, 100);
      if (!removed) assert.equal(f.world.components.monsters.get(f.id).controlledMotion, false);
    }
  }
  const f = await fixture("scatter"); f.world.components.health.get(f.id).current = 0;
  f.behavior.update(60000, f.runtime); assert.equal(f.world.components.enemyProjectiles.size, 0);
});

test("new casts obey per-role concurrency and shared warning/projectile budgets", async () => {
  const f = await fixture("hexer");
  for (let index = 0; index < 40; index++) {
    const config = { ...f.ConfigManager.getMonster("corn_bombardier"), behavior: "hexer" };
    const id = f.createMonster(f.world, config, 0, 0); f.world.components.monsters.get(id).behaviorTimerMs = 0;
  }
  f.behavior.update(60000, f.runtime); assert.equal(f.world.components.aoeWarnings.size, 4);
  f.behavior.update(0, f.runtime); assert.equal(f.world.components.aoeWarnings.size, 4, "hexer concurrency budget is missing");
  const g = await fixture("scatter");
  for (let index = 0; index < 71; index++) g.createEnemyProjectile(g.world, 0, 0, 0, 0, 1);
  g.behavior.update(60000, g.runtime); assert.equal(g.world.components.enemyProjectiles.size, 71, "fan partially emitted past the global budget");
  const h = await fixture("sniper");
  for (let index = 0; index < 18; index++) h.createAoeWarning(h.world, 0, 0, 20, 0, 1000);
  h.behavior.update(60000, h.runtime); assert.equal(h.world.components.aoeWarnings.size, 18);
});

test("legacy cola waits at the shared pellet cap and retries one unchanged shot when room opens", async () => {
  const fixtureState = await fixture("ranged");
  const monster = fixtureState.world.components.monsters.get(fixtureState.id);
  for (let index = 0; index < 72; index++) fixtureState.createEnemyProjectile(fixtureState.world, 0, 0, 0, 0, 1);
  fixtureState.behavior.update(60000, fixtureState.runtime);
  assert.equal(fixtureState.world.components.enemyProjectiles.size, 72, "legacy cola exceeded the shared 72-pellet cap");
  assert.ok(monster.behaviorTimerMs <= 0, "blocked shot consumed its cooldown");
  fixtureState.world.destroyEntity([...fixtureState.world.components.enemyProjectiles.keys()][0]);
  fixtureState.behavior.update(0, fixtureState.runtime);
  assert.equal(fixtureState.world.components.enemyProjectiles.size, 72);
  const shot = [...fixtureState.world.components.enemyProjectiles].find(([id]) => fixtureState.world.components.velocities.get(id).x !== 0);
  assert.ok(shot); assert.equal(shot[1].damage, 8);
  assert.deepEqual(fixtureState.world.components.velocities.get(shot[0]), { x: 240, y: 0 });
  assert.equal(fixtureState.world.components.lifetimes.get(shot[0]).totalMs, 1800);
  assert.equal(monster.behaviorTimerMs, 1800);
  fixtureState.world.destroyEntity(shot[0]);
  fixtureState.behavior.update(1799, fixtureState.runtime); assert.equal(fixtureState.world.components.enemyProjectiles.size, 71);
  fixtureState.behavior.update(1, fixtureState.runtime); assert.equal(fixtureState.world.components.enemyProjectiles.size, 72);
});

test("legacy corn waits at the shared warning cap and retains its full snapshot delay when admitted", async () => {
  const fixtureState = await fixture("bombardier");
  const monster = fixtureState.world.components.monsters.get(fixtureState.id);
  for (let index = 0; index < 18; index++) fixtureState.createAoeWarning(fixtureState.world, 0, 0, 20, 0, 1000000);
  fixtureState.behavior.update(60000, fixtureState.runtime);
  assert.equal(fixtureState.world.components.aoeWarnings.size, 18, "legacy corn exceeded the shared 18-warning cap");
  assert.ok(monster.behaviorTimerMs <= 0);
  fixtureState.world.destroyEntity([...fixtureState.world.components.aoeWarnings.keys()][0]);
  fixtureState.behavior.update(0, fixtureState.runtime);
  const [warningId, warning] = [...fixtureState.world.components.aoeWarnings].find(([, candidate]) => candidate.sourceId === fixtureState.id);
  assert.equal(fixtureState.world.components.aoeWarnings.size, 18);
  assert.equal(warning.totalMs, 900); assert.equal(warning.remainingMs, 900); assert.equal(warning.damage, 10);
  assert.equal(fixtureState.world.components.transforms.get(warningId).x, 200);
  assert.equal(monster.behaviorTimerMs, 3200);
  fixtureState.aoe.update(0, fixtureState.runtime); fixtureState.aoe.update(899, fixtureState.runtime);
  assert.equal(fixtureState.world.components.health.get(fixtureState.runtime.playerId).current, 100);
  fixtureState.aoe.update(1, fixtureState.runtime);
  assert.equal(fixtureState.world.components.health.get(fixtureState.runtime.playerId).current, 90);
});

test("legacy flanker cannot start an unsignaled lunge at warning capacity and retries a full windup", async () => {
  const fixtureState = await fixture("flanker");
  const monster = fixtureState.world.components.monsters.get(fixtureState.id);
  for (let index = 0; index < 18; index++) fixtureState.createAoeWarning(fixtureState.world, 0, 0, 20, 0, 1000000);
  fixtureState.behavior.update(60000, fixtureState.runtime);
  assert.equal(fixtureState.world.components.aoeWarnings.size, 18, "legacy flanker exceeded the shared warning cap");
  assert.equal(monster.roleState, undefined); assert.equal(monster.controlledMotion, undefined);
  assert.ok(monster.behaviorTimerMs <= 0);
  fixtureState.world.destroyEntity([...fixtureState.world.components.aoeWarnings.keys()][0]);
  fixtureState.behavior.update(0, fixtureState.runtime);
  assert.equal(fixtureState.world.components.aoeWarnings.size, 18);
  assert.equal(monster.roleState.stage, "windup"); assert.equal(monster.roleState.remainingMs, 800);
  assert.deepEqual(fixtureState.world.components.velocities.get(fixtureState.id), { x: 0, y: 0 });
  fixtureState.behavior.update(799, fixtureState.runtime); fixtureState.ai.update(16, fixtureState.runtime);
  assert.equal(monster.roleState.stage, "windup"); assert.equal(monster.roleState.remainingMs, 1);
  assert.deepEqual(fixtureState.world.components.velocities.get(fixtureState.id), { x: 0, y: 0 });
  fixtureState.behavior.update(1, fixtureState.runtime);
  assert.equal(monster.roleState.stage, "lunge"); assert.equal(monster.roleState.remainingMs, 250);
  assert.deepEqual(fixtureState.world.components.velocities.get(fixtureState.id), { x: 290, y: 0 });
});

test("mixed scatter and legacy cola casts share pellet capacity without partial fans or catch-up bursts", async () => {
  const fixtureState = await fixture("scatter");
  const colaIds = [];
  for (let index = 0; index < 3; index++) {
    const id = fixtureState.createMonster(fixtureState.world, fixtureState.ConfigManager.getMonster("cola_spitter"), 0, 0);
    fixtureState.world.components.monsters.get(id).behaviorTimerMs = 0; colaIds.push(id);
  }
  for (let index = 0; index < 70; index++) fixtureState.createEnemyProjectile(fixtureState.world, 0, 0, 0, 0, 1);
  fixtureState.behavior.update(60000, fixtureState.runtime);
  assert.equal(fixtureState.world.components.enemyProjectiles.size, 72, "mixed producers exceeded the shared cap");
  assert.ok(fixtureState.world.components.monsters.get(fixtureState.id).behaviorTimerMs <= 0, "blocked fan emitted a partial attack");
  assert.equal(fixtureState.world.components.monsters.get(colaIds[0]).behaviorTimerMs, 1800);
  assert.equal(fixtureState.world.components.monsters.get(colaIds[1]).behaviorTimerMs, 1800);
  assert.ok(fixtureState.world.components.monsters.get(colaIds[2]).behaviorTimerMs <= 0);
  for (const id of [...fixtureState.world.components.enemyProjectiles.keys()].slice(0, 3)) fixtureState.world.destroyEntity(id);
  fixtureState.behavior.update(0, fixtureState.runtime);
  assert.equal(fixtureState.world.components.enemyProjectiles.size, 72);
  assert.equal([...fixtureState.world.components.enemyProjectiles.values()].filter(projectile => projectile.damage === 8).length, 5);
  assert.equal(fixtureState.world.components.monsters.get(fixtureState.id).behaviorTimerMs, 3000);
  assert.ok(fixtureState.world.components.monsters.get(colaIds[2]).behaviorTimerMs <= 0);
});

test("mixed pending poison, corn and flanker casts share warning capacity and preserve blocked windups", async () => {
  const fixtureState = await fixture("hexer");
  fixtureState.behavior.update(0, fixtureState.runtime);
  const cornId = fixtureState.createMonster(fixtureState.world, fixtureState.ConfigManager.getMonster("corn_bombardier"), 0, 0);
  const flankerId = fixtureState.createMonster(fixtureState.world, fixtureState.ConfigManager.getMonster("onion_flanker"), 0, 0);
  fixtureState.world.components.monsters.get(cornId).behaviorTimerMs = 0;
  fixtureState.world.components.monsters.get(flankerId).behaviorTimerMs = 0;
  for (let index = 0; index < 17; index++) fixtureState.createAoeWarning(fixtureState.world, 0, 0, 20, 0, 1000000);
  fixtureState.behavior.update(0, fixtureState.runtime);
  assert.equal(fixtureState.world.components.aoeWarnings.size, 18, "mixed warning producers exceeded the shared cap");
  assert.equal(fixtureState.world.components.monsters.get(flankerId).roleState, undefined);
  const dummyId = [...fixtureState.world.components.aoeWarnings].find(([, warning]) => warning.sourceId === undefined)[0];
  fixtureState.world.destroyEntity(dummyId);
  fixtureState.behavior.update(0, fixtureState.runtime);
  assert.equal(fixtureState.world.components.aoeWarnings.size, 18);
  const corn = [...fixtureState.world.components.aoeWarnings.values()].find(warning => warning.sourceId === cornId);
  assert.ok(corn); assert.equal(corn.remainingMs, 900);
  assert.equal(fixtureState.world.components.monsters.get(flankerId).roleState, undefined);
});

test("active poisonous zones occupy the hexer's four-cast concurrency budget until they expire", async () => {
  const fixtureState = await fixture("hexer");
  for (let index = 0; index < 12; index++) {
    const id = fixtureState.createMonster(fixtureState.world, fixtureState.ConfigManager.getMonster("mushroom_hexer"), 0, 0);
    fixtureState.world.components.monsters.get(id).behaviorTimerMs = 0;
  }
  fixtureState.behavior.update(0, fixtureState.runtime); fixtureState.aoe.update(0, fixtureState.runtime);
  fixtureState.behavior.update(1000, fixtureState.runtime); fixtureState.aoe.update(1000, fixtureState.runtime);
  assert.equal(fixtureState.world.components.aoeWarnings.size, 4, "arming poison zones frees cast slots too early");
  assert.ok([...fixtureState.world.components.aoeWarnings.values()].every(warning => warning.zone && warning.triggered), "the four active hazards are not poisonous zones");
  fixtureState.behavior.update(0, fixtureState.runtime); assert.equal(fixtureState.world.components.aoeWarnings.size, 4);
  fixtureState.aoe.update(2400, fixtureState.runtime); assert.equal(fixtureState.world.components.aoeWarnings.size, 0);
  fixtureState.behavior.update(0, fixtureState.runtime); assert.equal(fixtureState.world.components.aoeWarnings.size, 4);
});

test("removed casters do not accumulate cast slots across repeated spawn cycles", async () => {
  for (const role of ["hexer", "sniper", "jumper"]) {
    const f = await fixture(role);
    for (let cycle = 0; cycle < 8; cycle++) {
      f.behavior.update(0, f.runtime);
      assert.equal(f.world.components.aoeWarnings.size, 1, `${role} leaked a cast slot on cycle ${cycle}`);
      for (const id of [...f.world.components.monsters.keys()]) f.world.destroyEntity(id);
      f.behavior.update(0, f.runtime); assert.equal(f.world.components.aoeWarnings.size, 0);
      const config = f.ConfigManager.monsters.find(monster => monster.behavior === role);
      const id = f.createMonster(f.world, config, 0, 0);
      f.world.components.monsters.get(id).behaviorTimerMs = 0;
    }
  }
});

const specialistWeight = (manager, time, id) =>
  manager.getCurrentWave(time).monsterMix.find((entry) => entry.monsterId === id)?.weight ?? 0;

test("meadow teaches charge, strafe, poison, crossfire, leap and snipe on separate beats", async () => {
  const { WaveManager } = await modules;
  const meadow = new WaveManager();
  assert.deepEqual(meadow.getCurrentWave(8_000).monsterMix, [{ monsterId: "fries_cultist", weight: 1 }]);
  const beats = [
    [20_000, 30_000, "delivery_box", .12],
    [32_000, 42_000, "cola_spitter", .09],
    [46_000, 56_000, "mushroom_hexer", .04],
    [72_000, 84_000, "chili_scatter", .04],
    [84_000, 96_000, "donut_jumper", .035],
    [100_000, 110_000, "pea_sniper", .035],
  ];
  for (const [before, after, id, minimum] of beats) {
    assert.equal(specialistWeight(meadow, before, id), 0, `${id} should have its own teaching beat`);
    assert.ok(specialistWeight(meadow, after, id) >= minimum, `${id} should be noticeable at ${after / 1000}s`);
  }
  assert.ok(specialistWeight(meadow, 56_000, "cola_spitter") < specialistWeight(meadow, 42_000, "cola_spitter"),
    "the poison beat replaces some ranged pressure");
});

test("desert foregrounds fan shots then flanks while retaining both specialists", async () => {
  const { WaveManager } = await modules;
  const desert = new WaveManager("desert");
  assert.ok(specialistWeight(desert, 18_000, "desert_cactus") >= .1);
  assert.equal(specialistWeight(desert, 24_000, "desert_scorpion"), 0);
  assert.ok(specialistWeight(desert, 36_000, "desert_scorpion") >= .06);
  for (const time of [48_000, 80_000, 110_000, 175_000]) {
    assert.ok(specialistWeight(desert, time, "desert_cactus") >= .08, `cactus missing at ${time / 1000}s`);
    assert.ok(specialistWeight(desert, time, "desert_scorpion") >= .08, `scorpion missing at ${time / 1000}s`);
    assert.equal(specialistWeight(desert, time, "chili_scatter"), 0, "the cactus owns the fan-shot role");
    assert.equal(specialistWeight(desert, time, "onion_flanker"), 0, "the scorpion owns the flank role");
  }
});

test("early encounter mixes limit simultaneous specialist pressure instead of adding it to fodder", async () => {
  const { WaveManager } = await modules;
  const earlyCastSources = new Set(["delivery_box", "cola_spitter", "mushroom_hexer", "desert_cactus", "desert_scorpion"]);
  for (const stage of ["meadow", "desert"]) {
    const manager = new WaveManager(stage);
    for (let time = 0; time <= 60_000; time += 1000) {
      const { monsterMix } = manager.getCurrentWave(time);
      const castShare = monsterMix.reduce((share, entry) => share + (earlyCastSources.has(entry.monsterId) ? entry.weight : 0), 0);
      assert.ok(castShare <= .30, `${stage} stacks too many specialist spawn slots at ${time / 1000}s`);
      if (stage === "desert") assert.equal(specialistWeight(manager, time, "cola_spitter"), 0, "cactus fan shots replace cola volleys");
    }
  }
});

test("earlier specialist slots reach the actual campaign spawner without adding batch slots", async () => {
  const { WaveManager, SpawnSystem, World, createPlayer, SkillManager } = await modules;
  for (const [stage, time, id] of [
    ["meadow", 30_000, "delivery_box"], ["meadow", 42_000, "cola_spitter"],
    ["meadow", 56_000, "mushroom_hexer"], ["meadow", 84_000, "chili_scatter"],
    ["meadow", 96_000, "donut_jumper"], ["meadow", 110_000, "pea_sniper"],
    ["desert", 18_000, "desert_cactus"], ["desert", 36_000, "desert_scorpion"],
  ]) {
    const manager = new WaveManager(stage);
    const wave = manager.getCurrentWave(time);
    const index = wave.monsterMix.findIndex((entry) => entry.monsterId === id);
    assert.ok(index >= 0, `${id} has no spawn slot at ${time / 1000}s`);
    // Select the midpoint of the specialist's slot once, then select fodder for the remaining slots.
    const roll = wave.monsterMix.slice(0, index).reduce((sum, entry) => sum + entry.weight, 0) + wave.monsterMix[index].weight / 2;
    const world = new World(); const playerId = createPlayer(world, 0, 0, 210, 100, 100);
    let rolls = 0;
    const runtime = { world, playerId, random: () => (rolls++ === 0 ? roll : 0), scene: { scale: { width: 800, height: 600 } }, skillManager: new SkillManager(), waveManager: manager, stats: { elapsedMs: time }, campaign: { stage, ownBossCadence: true, spawnMultiplier: 1 } };
    new SpawnSystem().update(0, runtime);
    assert.equal(world.components.monsters.size, 3);
    assert.equal([...world.components.monsters.values()].filter((monster) => monster.monsterId === id).length, 1);
  }
});

test("immutable bestiary preserves the four original additions and explains their attacks", async () => {
  const { BESTIARY_ENTRIES } = await modules;
  assert.equal(BESTIARY_ENTRIES.length, 14); assert.ok(Object.isFrozen(BESTIARY_ENTRIES));
  assert.deepEqual(BESTIARY_ENTRIES.slice(8, 12).map(entry => entry.id), newIds);
  for (const [index, entry] of BESTIARY_ENTRIES.slice(8, 12).entries()) {
    assert.ok(Object.isFrozen(entry)); assert.equal(entry.name, names[index]); assert.equal(entry.imagePath, `/assets/bestiary/v4/${entry.id}.png`);
    for (const field of ["role", "attack", "counterplay"]) assert.ok(entry[field].trim());
  }
  const [hexer, scatter, sniper, jumper] = BESTIARY_ENTRIES.slice(8, 12);
  assert.match(hexer.attack, /延迟|蓄力/); assert.match(hexer.attack, /毒域|毒伤/);
  assert.match(hexer.attack, /2\.4/); assert.match(hexer.attack, /750/); assert.match(hexer.attack, /三次/);
  assert.match(hexer.counterplay, /紫|绿/); assert.doesNotMatch(hexer.attack, /叠层|永久|追踪毒/);
  assert.match(scatter.attack, /三|3/); assert.match(scatter.counterplay, /间隙|扇/);
  assert.match(sniper.attack, /锁定|预警/); assert.match(sniper.counterplay, /横|侧/);
  assert.match(jumper.attack, /落地|跃/); assert.match(jumper.counterplay, /圆|圈/);
});
