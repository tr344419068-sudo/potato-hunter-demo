import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import { mkdtemp, readFile, readdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import test from "node:test";
import { build } from "esbuild";

const api = build({ stdin: { contents: 'export * from "./src/audio/CombatAudioModel.ts"; export * from "./src/audio/GameAudio.ts";', resolveDir: process.cwd(), loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false, logLevel: "silent" })
  .then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`)).catch(() => ({}));

async function modelApi() {
  const loaded = await api;
  assert.equal(typeof loaded.CombatAudioModel, "function", "pure audio scheduler must exist");
  return loaded;
}

const settle = () => new Promise(resolve => setImmediate(resolve));

function boundary(options = {}) {
  let clock = 0;
  const events = new EventEmitter();
  const context = { state: "suspended", currentTime: 0, resumes: 0, closes: 0,
    async resume() { this.resumes++; if (options.resumeFails) throw new Error("locked"); this.state = "running"; },
    async close() { this.closes++; this.state = "closed"; } };
  const sink = { loads: [], plays: [], music: [], gains: [], stops: 0, destroyed: false,
    async load(asset) { this.loads.push(asset); if (options.loadWait) await options.loadWait; if (options.loadFails) throw new Error("asset unavailable"); return true; },
    playSfx(cue, ended) { const voice = { cue, ended, stopped: false, stop: () => { voice.stopped = true; sink.stops++; ended(); } }; this.plays.push(voice); return voice; },
    playMusic(asset, gain, ended) { const voice = { asset, gain, ended, stop: () => { sink.stops++; ended(); } }; this.music.push(voice); return voice; },
    setMusicGain(gain, duck = false) { this.gains.push({ gain, duck }); },
    setSfxGain(gain) { this.sfxGain = gain; },
    destroy() { this.destroyed = true; } };
  return { events, context, sink, setClock(value) { clock = value; context.currentTime = value; }, options: { createContext: () => context, sink, now: () => clock } };
}

test("audio launch and impact map to separate authored families", async () => {
  const { mapAudioEvent } = await modelApi();
  for (const [vfxKind, family] of [["peeler", "peeler"], ["fire", "fire"], ["frost", "ice"], ["lightning", "lightning"], ["poison", "poison"], ["explosion", "explosion"], ["kinetic", "rapid"]]) {
    const launch = mapAudioEvent("weapon:fired", { vfxKind });
    const impact = mapAudioEvent("weapon:impact", { vfxKind });
    assert.equal(launch[0], `launch-${family}`);
    assert.match(impact[0], /^impact-/);
    assert.notEqual(launch[0], impact[0]);
  }
  assert.deepEqual(mapAudioEvent("combat:projectile", { skillId: "frost_chips" }), ["launch-ice"]);
  assert.deepEqual(mapAudioEvent("combat:damage", { value: 20 }), []);
  assert.deepEqual(mapAudioEvent("combat:damage", { isCrit: true }), ["critical"]);
  assert.deepEqual(mapAudioEvent("combat:damage", { color: "#89cfff" }), ["shield"]);
  assert.deepEqual(mapAudioEvent("combat:vfx", { kind: "ranged_shot" }), []);
  assert.deepEqual(mapAudioEvent("boss:phase", { text: "临时磁吸！" }), []);
  assert.deepEqual(mapAudioEvent("boss:danger", {}), ["boss-danger"]);
});

test("audio cue routing covers gameplay rewards, dash and outcome", async () => {
  const { mapAudioEvent } = await modelApi();
  for (const [event, expected] of [["hero:dash", "dash"], ["player:dash", "dash"], ["player:damaged", "player-hurt"], ["reward:collected", "pickup"], ["level:choices", "upgrade"], ["skill:selected", "upgrade"], ["boss:spawned", "boss-danger"]]) assert.deepEqual(mapAudioEvent(event, {}), [expected]);
  assert.deepEqual(mapAudioEvent("game:over", { outcome: "victory" }), ["victory"]);
  assert.deepEqual(mapAudioEvent("game:over", { outcome: "defeat" }), ["defeat"]);
});

test('the burst, physical skewer and electric skewer do not share the same launch sound', async () => {
  const { mapAudioEvent, AUDIO_ASSETS } = await modelApi();
  const play = skillId => mapAudioEvent('weapon:fired', { skillId, vfxKind: 'kinetic' });
  assert.deepEqual(play('pepper_gatling'), ['launch-rapid']);
  assert.deepEqual(play('skewer_javelin'), ['launch-peeler']);
  assert.deepEqual(play('thunder_skewer'), ['launch-lightning']);
  assert.deepEqual(mapAudioEvent('weapon:impact', { skillId: 'skewer_javelin', material: 'shield' }), ['shield']);
  assert.ok(AUDIO_ASSETS['launch-rapid'].gain >= .11 && AUDIO_ASSETS['launch-rapid'].cooldown >= .09);
});

test("scheduler reserves priority voices and stays within twelve total voices", async () => {
  const { CombatAudioModel, AUDIO_ASSETS } = await modelApi();
  const scheduler = new CombatAudioModel({ musicVolume: 1, sfxVolume: 1 });
  scheduler.setState("combat");
  const ordinary = Object.keys(AUDIO_ASSETS).filter(id => id.startsWith("launch-") || id.startsWith("impact-"));
  let accepted = 0;
  for (const id of ordinary) if (scheduler.admit(id, 0)) accepted++;
  assert.equal(accepted, 8);
  assert.ok(scheduler.admit("boss-danger", 0));
  assert.ok(scheduler.admit("player-hurt", 0));
  assert.ok(scheduler.snapshot(0).activeVoices + 2 <= 12);
  for (let index = 0; index < 500; index++) scheduler.admit(ordinary[index % ordinary.length], index / 1000);
  assert.ok(scheduler.snapshot(0.5).activeVoices <= 10);
});

test("scheduler applies family cooldowns, finite gains and releases voices", async () => {
  const { CombatAudioModel } = await modelApi();
  const scheduler = new CombatAudioModel({ sfxVolume: 1 });
  scheduler.setState("combat");
  const first = scheduler.admit("launch-rapid", 0);
  assert.ok(first);
  assert.equal(scheduler.admit("launch-rapid", 0.01), undefined);
  scheduler.release(first.id);
  assert.ok(scheduler.admit("launch-rapid", 0.12));
  assert.ok(Number.isFinite(first.gain) && first.gain > 0 && first.gain <= 0.5);
  assert.equal(scheduler.snapshot(5).activeVoices, 0);
  assert.equal(scheduler.admit("launch-rapid", Number.NaN), undefined);
});

test("boss danger ducks music and recovers to the bounded preference gain", async () => {
  const { CombatAudioModel } = await modelApi();
  const scheduler = new CombatAudioModel({ musicVolume: 0.8, sfxVolume: 1 });
  scheduler.setState("boss");
  const base = scheduler.musicGain(0);
  scheduler.admit("boss-danger", 1);
  assert.ok(scheduler.musicGain(1.1) < base * 0.4);
  assert.ok(scheduler.musicGain(2.6) > scheduler.musicGain(1.1));
  assert.equal(scheduler.musicGain(5), base);
  assert.ok(base <= 0.3 && Number.isFinite(base));
});

test("mute and reduced effects retain essential cues without non-finite levels", async () => {
  const { CombatAudioModel, normalizeAudioPreferences } = await modelApi();
  const scheduler = new CombatAudioModel({ sfxVolume: 0, musicVolume: 0 });
  scheduler.setState("combat");
  assert.equal(scheduler.admit("boss-danger", 0), undefined);
  assert.equal(scheduler.musicGain(0), 0);
  scheduler.setPreferences({ sfxVolume: 1, reducedEffects: true });
  assert.equal(scheduler.admit("launch-rapid", 1), undefined);
  assert.ok(scheduler.admit("boss-danger", 1));
  assert.ok(scheduler.admit("dash", 1));
  const preferences = normalizeAudioPreferences({ musicVolume: Infinity, sfxVolume: -100, reducedEffects: true });
  assert.ok(Number.isFinite(preferences.musicVolume));
  assert.equal(preferences.sfxVolume, 0);
  scheduler.setState("paused");
  assert.equal(scheduler.admit("launch-fire", 2), undefined);
  assert.equal(scheduler.musicGain(2), 0);
});

test("locked audio never creates a context or queues a combat burst", async () => {
  const { GameAudio } = await modelApi();
  const port = boundary();
  let created = 0;
  const audio = new GameAudio(port.events, { sfxVolume: 1 }, { ...port.options, createContext() { created++; return port.context; } });
  audio.setState("combat");
  for (let index = 0; index < 100; index++) port.events.emit("weapon:fired", { vfxKind: "fire" });
  assert.equal(created, 0);
  assert.equal(port.sink.plays.length, 0);
  assert.equal(audio.getSnapshot().queued, 0);
  await audio.unlock();
  await settle();
  assert.equal(created, 1);
  assert.equal(port.sink.plays.length, 0);
  port.events.emit("weapon:fired", { vfxKind: "fire" });
  assert.equal(port.sink.plays[0].cue.asset.id, "launch-fire");
  audio.destroy();
});

test("unlock resumes on the click and starts music only once loaded", async () => {
  const { GameAudio } = await modelApi();
  const port = boundary();
  const audio = new GameAudio(port.events, { musicVolume: 0.5 }, port.options);
  audio.setState("home");
  await audio.unlock();
  await settle();
  assert.equal(port.context.resumes, 1);
  assert.equal(port.sink.music[0].asset.id, "music-calm");
  await audio.unlock();
  assert.equal(port.context.resumes, 1);
  audio.setState("boss");
  assert.equal(port.sink.music.at(-1).asset.id, "music-boss");
  assert.ok(port.sink.music.length <= 2);
  audio.destroy();
});

test("unavailable contexts and rejected resume or assets stay harmless", async () => {
  const { GameAudio } = await modelApi();
  for (const failure of ["factory", "resume", "load"]) {
    const port = boundary({ resumeFails: failure === "resume", loadFails: failure === "load" });
    const audio = new GameAudio(port.events, {}, failure === "factory" ? { createContext() { throw new Error("unsupported"); } } : port.options);
    await assert.doesNotReject(audio.unlock());
    await settle();
    port.events.emit("boss:spawned");
    assert.equal(port.sink.plays.length, 0);
    audio.destroy();
  }
});

test("an injected sink with failed initialization is destroyed and explicitly unavailable", async () => {
  const { GameAudio } = await modelApi();
  const port = boundary();
  port.sink.setSfxGain = () => { throw new Error("sink initialization unavailable"); };
  const audio = new GameAudio(port.events, {}, port.options);
  await audio.unlock();
  assert.equal(audio.getSnapshot().status, "unavailable");
  assert.equal(port.sink.destroyed, true);
  await audio.unlock();
  assert.equal(port.context.resumes, 1);
  assert.equal(port.sink.loads.length, 0);
  audio.destroy();
  assert.equal(port.context.closes, 1);
});

test("unlock restores ready audio after a transient resume rejection", async () => {
  const { GameAudio, AUDIO_ASSETS } = await modelApi();
  const port = boundary();
  const audio = new GameAudio(port.events, { sfxVolume: 1 }, port.options);
  audio.setState("combat");
  await audio.unlock();
  await settle();
  port.context.state = "suspended";
  const resume = port.context.resume.bind(port.context);
  let rejected = false;
  port.context.resume = async () => {
    if (!rejected) { rejected = true; throw new Error("transient resume failure"); }
    await resume();
  };
  await audio.unlock();
  assert.equal(audio.getSnapshot().status, "locked");
  await audio.unlock();
  assert.equal(audio.getSnapshot().status, "ready");
  assert.equal(port.sink.loads.length, Object.keys(AUDIO_ASSETS).length);
  port.events.emit("weapon:fired", { vfxKind: "fire" });
  assert.equal(port.sink.plays.length, 1);
  audio.destroy();
});

test("destroy during a shared pending unlock never creates a sink or repeats listeners", async () => {
  const { GameAudio, AUDIO_EVENTS } = await modelApi();
  const port = boundary();
  let release;
  port.context.resume = () => new Promise(resolve => { release = () => { port.context.state = "running"; resolve(); }; });
  const audio = new GameAudio(port.events, {}, port.options);
  const pending = audio.unlock();
  assert.equal(audio.unlock(), pending);
  for (const event of AUDIO_EVENTS) assert.equal(port.events.listenerCount(event), 1);
  audio.destroy();
  release();
  await pending;
  assert.equal(audio.getSnapshot().status, "destroyed");
  assert.equal(port.sink.loads.length, 0);
  assert.equal(port.events.eventNames().length, 0);
  assert.equal(port.context.closes, 1);
});

test("loading queues only fresh essential cues in a bounded queue", async () => {
  const { GameAudio } = await modelApi();
  let release;
  const loadWait = new Promise(resolve => { release = resolve; });
  const port = boundary({ loadWait });
  const audio = new GameAudio(port.events, { sfxVolume: 1 }, port.options);
  audio.setState("combat");
  await audio.unlock();
  for (let index = 0; index < 100; index++) {
    port.events.emit("weapon:fired", { vfxKind: "fire" });
    port.events.emit("player:damaged", { value: 1 });
  }
  assert.ok(audio.getSnapshot().queued <= 8);
  assert.equal(port.sink.plays.length, 0);
  port.setClock(2);
  release();
  await settle();
  assert.equal(port.sink.plays.length, 0, "stale danger cues cannot burst after decoding");
  audio.destroy();
});

test("repeated danger during loading refreshes the queued warning timestamp", async () => {
  const { GameAudio } = await modelApi();
  let release;
  const port = boundary({ loadWait: new Promise(resolve => { release = resolve; }) });
  const audio = new GameAudio(port.events, { sfxVolume: 1 }, port.options);
  audio.setState("combat");
  await audio.unlock();
  port.events.emit("boss:danger");
  port.setClock(0.8);
  port.events.emit("boss:danger");
  assert.equal(audio.getSnapshot().queued, 1, "repeated danger must remain deduplicated");
  port.setClock(0.9);
  release();
  await settle();
  assert.equal(port.sink.plays.length, 1, "the latest warning remains fresh when loading completes");
  assert.equal(port.sink.plays[0].cue.asset.id, "boss-danger");
  assert.equal(audio.getSnapshot().queued, 0);
  audio.destroy();
});

test("boundary duck, live mute and destroy stop voices and unsubscribe every hook", async () => {
  const { GameAudio } = await modelApi();
  const port = boundary();
  const audio = new GameAudio(port.events, { musicVolume: 1, sfxVolume: 1 }, port.options);
  audio.setState("combat");
  await audio.unlock();
  await settle();
  port.events.emit("boss:danger");
  assert.ok(port.sink.gains.some(change => change.duck));
  audio.setPreferences({ sfxVolume: 0, musicVolume: 0 });
  assert.equal(port.sink.sfxGain, 0);
  assert.ok(port.sink.stops > 0);
  const played = port.sink.plays.length;
  port.events.emit("hero:dash");
  assert.equal(port.sink.plays.length, played);
  audio.destroy();
  audio.destroy();
  assert.equal(port.events.eventNames().length, 0);
  assert.equal(port.sink.destroyed, true);
  assert.equal(port.context.closes, 1);
});

test("destroy during loading prevents late audio resurrection", async () => {
  const { GameAudio } = await modelApi();
  let release;
  const port = boundary({ loadWait: new Promise(resolve => { release = resolve; }) });
  const audio = new GameAudio(port.events, {}, port.options);
  await audio.unlock();
  audio.destroy();
  release();
  await settle();
  assert.equal(port.sink.music.length, 0);
  assert.equal(port.sink.plays.length, 0);
});

test("boundary releases each expired voice even while a long essential voice is active", async () => {
  const { GameAudio } = await modelApi();
  const port = boundary();
  const audio = new GameAudio(port.events, { sfxVolume: 1 }, port.options);
  audio.setState("combat");
  await audio.unlock();
  await settle();
  port.events.emit("boss:danger");
  for (let frame = 0; frame < 30; frame++) {
    port.setClock(frame * 0.1);
    for (const vfxKind of ["kinetic", "fire", "frost", "lightning", "poison", "peeler", "explosion"]) {
      port.events.emit("weapon:fired", { vfxKind });
      port.events.emit("weapon:impact", { vfxKind });
    }
    assert.ok(port.sink.plays.filter(voice => !voice.stopped).length <= 10, "physical SFX voice count must match scheduler capacity");
  }
  audio.destroy();
});

test("pause and terminal states silence gameplay cues but allow upgrade and outcome UI", async () => {
  const { CombatAudioModel } = await modelApi();
  const scheduler = new CombatAudioModel({ sfxVolume: 1 });
  for (const state of ["paused", "home", "victory", "defeat"]) {
    scheduler.setState(state);
    for (const id of ["boss-danger", "player-hurt", "dash", "critical", "shield", "pickup"]) assert.equal(scheduler.admit(id, 0), undefined, `${state} must silence ${id}`);
    assert.ok(scheduler.admit("upgrade", 0));
  }
});

function nativeContext() {
  const nodes = [];
  const sources = [];
  const parameter = () => ({ value: 1, scheduled: [], cancelScheduledValues(time) { this.scheduled.push(["cancel", time]); }, setValueAtTime(value, time) { this.value = value; this.scheduled.push(["set", value, time]); }, linearRampToValueAtTime(value, time) { this.value = value; this.scheduled.push(["ramp", value, time]); } });
  const node = (extra = {}) => { const value = { disconnected: false, connect() {}, disconnect() { this.disconnected = true; }, ...extra }; nodes.push(value); return value; };
  const context = { state: "suspended", currentTime: 0, destination: {}, closes: 0,
    async resume() { this.state = "running"; }, async close() { this.closes++; this.state = "closed"; },
    createGain() { return node({ gain: parameter() }); },
    createDynamicsCompressor() { return node({ threshold: parameter(), knee: parameter(), ratio: parameter(), attack: parameter(), release: parameter() }); },
    async decodeAudioData() { return { duration: 0.3 }; },
    createBufferSource() { const source = node({ started: false, stopped: false, onended: null, start() { this.started = true; }, stop() { this.stopped = true; this.onended?.(); } }); sources.push(source); return source; } };
  return { context, nodes, sources };
}

for (const stage of ['gain-allocation','parameter','source-connect','gain-connect','start']) test(`native per-voice ${stage} failure rolls back every partial node and later cues recover`, async()=>{
 const {GameAudio}=await modelApi(),native=nativeContext(),events=new EventEmitter();let clock=0;
 const audio=new GameAudio(events,{musicVolume:0,sfxVolume:1},{now:()=>clock,createContext:()=>native.context,fetchAudio:async()=>new ArrayBuffer(44)});
 audio.setState('combat');await audio.unlock();await settle();
 const originalGain=native.context.createGain.bind(native.context),originalSource=native.context.createBufferSource.bind(native.context);let fail=true;
 const faulty=()=>{if(fail){fail=false;throw new Error('voice fault')}};
 native.context.createGain=()=>{if(stage==='gain-allocation'&&fail)faulty();const gain=originalGain();if(stage==='parameter')gain.gain.setValueAtTime=faulty;if(stage==='gain-connect')gain.connect=faulty;return gain;};
 native.context.createBufferSource=()=>{const source=originalSource();if(stage==='source-connect')source.connect=faulty;if(stage==='start')source.start=faulty;return source;};
 events.emit('weapon:fired',{vfxKind:'fire'});
 assert.equal(native.sources.length,1);assert.ok(native.sources[0].disconnected,'failed voice source must roll back immediately');
 assert.ok(native.nodes.slice(3).every(n=>n.disconnected),'all per-voice nodes must roll back');
 native.context.createGain=originalGain;native.context.createBufferSource=originalSource;clock=1000;events.emit('weapon:fired',{vfxKind:'fire'});
 assert.equal(native.sources.length,2);assert.ok(native.sources[1].started,'failure must not consume future polyphony');
 audio.destroy();assert.ok(native.nodes.every(n=>n.disconnected));assert.ok(native.sources[1].stopped);
});

test("native transient SFX gain setup failure cleans the sink and retries on another unlock", async () => {
  const { GameAudio, AUDIO_ASSETS } = await modelApi();
  const native = nativeContext();
  const createGain = native.context.createGain.bind(native.context);
  let gains = 0;
  native.context.createGain = () => {
    const gain = createGain();
    if (++gains === 2) gain.gain.linearRampToValueAtTime = () => { throw new Error("transient gain setup failure"); };
    return gain;
  };
  let fetched = 0;
  const events = new EventEmitter();
  const audio = new GameAudio(events, { musicVolume: 1 }, { createContext: () => native.context, fetchAudio: async () => { fetched++; return new ArrayBuffer(44); } });
  audio.setState("home");
  await audio.unlock();
  assert.equal(audio.getSnapshot().status, "locked");
  assert.equal(fetched, 0);
  assert.ok(native.nodes.every(node => node.disconnected), "failed initialization must disconnect its complete graph");
  await audio.unlock();
  await settle();
  assert.equal(audio.getSnapshot().status, "ready");
  assert.equal(fetched, Object.keys(AUDIO_ASSETS).length);
  assert.equal(native.sources.length, 1, "retry must start one home music voice");
  await audio.unlock();
  assert.equal(fetched, Object.keys(AUDIO_ASSETS).length, "ready unlock must not reload assets");
  audio.destroy();
  assert.ok(native.nodes.every(node => node.disconnected));
  assert.equal(events.eventNames().length, 0);
});

test("native partial graph allocation failure disconnects nodes and retries on another unlock", async () => {
  const { GameAudio, AUDIO_ASSETS } = await modelApi();
  const native = nativeContext();
  const createCompressor = native.context.createDynamicsCompressor.bind(native.context);
  let attempts = 0;
  native.context.createDynamicsCompressor = () => {
    if (++attempts === 1) throw new Error("transient compressor allocation failure");
    return createCompressor();
  };
  let fetched = 0;
  const audio = new GameAudio(new EventEmitter(), {}, { createContext: () => native.context, fetchAudio: async () => { fetched++; return new ArrayBuffer(44); } });
  await audio.unlock();
  assert.equal(audio.getSnapshot().status, "locked");
  assert.equal(native.nodes.length, 2);
  assert.ok(native.nodes.every(node => node.disconnected), "partial gain graph must be rolled back");
  await audio.unlock();
  await settle();
  assert.equal(audio.getSnapshot().status, "ready");
  assert.equal(fetched, Object.keys(AUDIO_ASSETS).length);
  assert.equal(attempts, 2);
  audio.destroy();
  assert.ok(native.nodes.every(node => node.disconnected));
});

test("native total asset failure cleans the sink and retries without duplicate pending loads", async () => {
  const { GameAudio, AUDIO_ASSETS } = await modelApi();
  const native = nativeContext();
  const assetCount = Object.keys(AUDIO_ASSETS).length;
  let fetched = 0;
  const audio = new GameAudio(new EventEmitter(), {}, { createContext: () => native.context, fetchAudio: async () => {
    if (++fetched <= assetCount) throw new Error("transient fetch failure");
    return new ArrayBuffer(44);
  } });
  await audio.unlock();
  await settle();
  assert.equal(audio.getSnapshot().status, "locked");
  assert.equal(audio.getSnapshot().loaded, 0);
  assert.ok(native.nodes.every(node => node.disconnected));
  const pending = audio.unlock();
  assert.equal(audio.unlock(), pending);
  await pending;
  await settle();
  assert.equal(audio.getSnapshot().status, "ready");
  assert.equal(fetched, assetCount * 2);
  audio.destroy();
  assert.ok(native.nodes.every(node => node.disconnected));
});

test("native load deadline releases usable assets and aborts a hanging fetch without late decoding", async () => {
  const { GameAudio, AUDIO_ASSETS } = await modelApi();
  const native = nativeContext();
  const events = new EventEmitter();
  let release;
  let hangingSignal;
  let decoded = 0;
  native.context.decodeAudioData = async () => { decoded++; return { duration: 0.3 }; };
  const audio = new GameAudio(events, { sfxVolume: 1 }, { createContext: () => native.context, loadTimeoutMs: 20, fetchAudio: async (url, signal) => {
    if (url.endsWith("launch-fire.wav")) { hangingSignal = signal; return new Promise(resolve => { release = resolve; }); }
    return new ArrayBuffer(44);
  } });
  audio.setState("combat");
  await audio.unlock();
  await settle();
  assert.equal(audio.getSnapshot().loaded, Object.keys(AUDIO_ASSETS).length - 1);
  await new Promise(resolve => setTimeout(resolve, 50));
  assert.equal(audio.getSnapshot().status, "ready", "one hanging ordinary fetch must not gate usable warnings and music");
  assert.equal(hangingSignal.aborted, true);
  events.emit("boss:danger");
  assert.equal(native.sources.length, 2);
  release(new ArrayBuffer(44));
  await settle();
  assert.equal(decoded, Object.keys(AUDIO_ASSETS).length - 1, "expired fetch must not start a late decode");
  events.emit("weapon:fired", { vfxKind: "fire" });
  assert.equal(native.sources.length, 2);
  assert.equal(audio.getSnapshot().loaded, Object.keys(AUDIO_ASSETS).length - 1);
  audio.destroy();
});

test("native load deadline drops an expired decode instead of republishing a cached asset", async () => {
  const { GameAudio, AUDIO_ASSETS } = await modelApi();
  const native = nativeContext();
  const events = new EventEmitter();
  let release;
  let hangingSignal;
  native.context.decodeAudioData = async data => data.byteLength === 45 ? new Promise(resolve => { release = resolve; }) : { duration: 0.3 };
  const audio = new GameAudio(events, { sfxVolume: 1 }, { createContext: () => native.context, loadTimeoutMs: 20, fetchAudio: async (url, signal) => {
    if (url.endsWith("launch-fire.wav")) { hangingSignal = signal; return new ArrayBuffer(45); }
    return new ArrayBuffer(44);
  } });
  audio.setState("combat");
  await audio.unlock();
  await new Promise(resolve => setTimeout(resolve, 50));
  assert.equal(audio.getSnapshot().status, "ready");
  assert.equal(hangingSignal.aborted, true);
  assert.equal(audio.getSnapshot().loaded, Object.keys(AUDIO_ASSETS).length - 1);
  release({ duration: 0.3 });
  await settle();
  events.emit("weapon:fired", { vfxKind: "fire" });
  assert.equal(native.sources.length, 1, "late decode must not create a playable source");
  assert.equal(audio.getSnapshot().loaded, Object.keys(AUDIO_ASSETS).length - 1);
  audio.destroy();
});

test("native load deadline makes all-expired startup unavailable and allows a fresh unlock retry", async () => {
  const { GameAudio, AUDIO_ASSETS } = await modelApi();
  const native = nativeContext();
  const signals = [];
  let hanging = true;
  let fetched = 0;
  const audio = new GameAudio(new EventEmitter(), {}, { createContext: () => native.context, loadTimeoutMs: 20, fetchAudio: async (_url, signal) => {
    fetched++;
    signals.push(signal);
    return hanging ? new Promise(() => {}) : new ArrayBuffer(44);
  } });
  await audio.unlock();
  await new Promise(resolve => setTimeout(resolve, 50));
  assert.equal(audio.getSnapshot().status, "unavailable");
  assert.equal(audio.getSnapshot().loaded, 0);
  assert.ok(signals.every(signal => signal.aborted));
  assert.ok(native.nodes.every(node => node.disconnected));
  hanging = false;
  await audio.unlock();
  await settle();
  assert.equal(audio.getSnapshot().status, "ready");
  assert.equal(fetched, Object.keys(AUDIO_ASSETS).length * 2);
  audio.destroy();
});

test("native load deadlines clear completed and destroyed timers without late decode resurrection", async testContext => {
  const { GameAudio, AUDIO_ASSETS } = await modelApi();
  const native = nativeContext();
  const timers = new Set();
  const setTimer = globalThis.setTimeout;
  const clearTimer = globalThis.clearTimeout;
  testContext.mock.method(globalThis, "setTimeout", (callback, delay, ...args) => {
    const timer = setTimer(callback, delay, ...args);
    if (delay === 5000) timers.add(timer);
    return timer;
  });
  testContext.mock.method(globalThis, "clearTimeout", timer => { timers.delete(timer); clearTimer(timer); });
  let release;
  let hangingSignal;
  const completedSignals = [];
  native.context.decodeAudioData = async data => data.byteLength === 45 ? new Promise(resolve => { release = resolve; }) : { duration: 0.3 };
  const audio = new GameAudio(new EventEmitter(), {}, { createContext: () => native.context, loadTimeoutMs: 5000, fetchAudio: async (url, signal) => {
    if (url.endsWith("launch-fire.wav")) { hangingSignal = signal; return new ArrayBuffer(45); }
    completedSignals.push(signal);
    return new ArrayBuffer(44);
  } });
  await audio.unlock();
  await settle();
  assert.equal(audio.getSnapshot().loaded, Object.keys(AUDIO_ASSETS).length - 1);
  assert.equal(timers.size, 1, "successful loads must release their deadline timers");
  audio.destroy();
  await settle();
  assert.equal(hangingSignal.aborted, true);
  assert.ok(completedSignals.every(signal => !signal.aborted), "completed loads must release their abort controllers before destroy");
  assert.equal(timers.size, 0, "destroy must settle cancellation and clear the remaining deadline");
  release({ duration: 0.3 });
  await settle();
  assert.equal(audio.getSnapshot().status, "destroyed");
  assert.equal(audio.getSnapshot().loaded, 0);
  assert.equal(native.sources.length, 0);
  assert.ok(native.nodes.every(node => node.disconnected));
});

test("native audio graph schedules finite duck recovery and disconnects every node", async () => {
  const { GameAudio } = await modelApi();
  const native = nativeContext();
  const events = new EventEmitter();
  const audio = new GameAudio(events, { musicVolume: 1, sfxVolume: 1 }, { createContext: () => native.context, fetchAudio: async () => new ArrayBuffer(44) });
  audio.setState("combat");
  await audio.unlock();
  await settle();
  events.emit("weapon:fired", { vfxKind: "fire" });
  events.emit("boss:danger");
  assert.equal(native.sources.length, 3);
  assert.ok(native.sources.every(source => source.started));
  audio.setPreferences({ musicVolume: 0.6 });
  const musicNode = native.nodes[0];
  assert.ok(musicNode.gain.scheduled.every(change => change.slice(1).every(Number.isFinite)));
  assert.equal(musicNode.gain.scheduled.at(-1)[1], 0.15, "a mid-duck volume change must recover to the new base gain");
  audio.destroy();
  assert.ok(native.sources.every(source => source.stopped));
  assert.ok(native.nodes.every(value => value.disconnected));
  assert.equal(native.context.closes, 1);
});

test("game outcomes select stingers and ordinary damage never spams impact audio", async () => {
  const { GameAudio } = await modelApi();
  const port = boundary();
  const audio = new GameAudio(port.events, { sfxVolume: 1 }, port.options);
  audio.setState("combat");
  await audio.unlock();
  await settle();
  for (let index = 0; index < 100; index++) port.events.emit("combat:damage", { value: 20 });
  assert.equal(port.sink.plays.length, 0);
  port.events.emit("game:over", { outcome: "victory" });
  assert.equal(port.sink.plays.at(-1).cue.asset.id, "victory");
  assert.equal(audio.getSnapshot().state, "victory");
  audio.destroy();
});

test("all 26 shipped WAVs match the runtime manifest and original-authoring provenance", async () => {
  const { AUDIO_ASSETS } = await modelApi();
  const destination = join(process.cwd(), "public/assets/audio");
  const provenance = JSON.parse(await readFile(join(destination, "provenance.json"), "utf8"));
  assert.equal(provenance.schemaVersion, 1);
  assert.equal(provenance.seed, 20261118);
  assert.equal(provenance.externalRecordings, false);
  assert.equal(provenance.externalSamples, false);
  assert.equal(provenance.aiGenerated, false);
  assert.equal(provenance.generator, "scripts/generate-game-audio.mjs");
  assert.equal(provenance.command, "node scripts/generate-game-audio.mjs");
  assert.match(provenance.authorship, /project-owned.*explicitly authored note sequences/i);
  assert.match(provenance.synthesis, /seeded noise.*authored percussion/i);
  assert.match(provenance.license, /project-owned original assets/i);
  assert.equal(provenance.assets.length, 26);
  assert.equal(Object.keys(AUDIO_ASSETS).length, 26);
  assert.deepEqual(provenance.assets.map(asset => asset.id).sort(), Object.keys(AUDIO_ASSETS).sort());
  assert.deepEqual((await readdir(destination)).filter(file => file.endsWith(".wav")).sort(), provenance.assets.map(asset => asset.file).sort());
  for (const asset of provenance.assets) {
    const runtime = AUDIO_ASSETS[asset.id];
    assert.equal(runtime.url, `/assets/audio/${asset.file}`);
    assert.equal(runtime.loop, asset.loop);
    assert.equal(asset.format, "PCM16 stereo WAV");
    assert.equal(asset.sampleRate, 24000);
    assert.ok(asset.layers.length >= 2);
    const wav = await readFile(join(destination, asset.file));
    assert.equal(wav.toString("ascii", 0, 4), "RIFF");
    assert.equal(wav.readUInt32LE(4), wav.length - 8);
    assert.equal(wav.toString("ascii", 8, 12), "WAVE");
    assert.equal(wav.readUInt16LE(20), 1);
    assert.equal(wav.readUInt16LE(22), 2);
    assert.equal(wav.readUInt32LE(24), asset.sampleRate);
    assert.equal(wav.readUInt16LE(34), 16);
    assert.equal(wav.readUInt32LE(40), wav.length - 44);
    assert.equal(createHash("sha256").update(wav).digest("hex"), asset.sha256, `${asset.file}: shipped hash must match provenance`);
    const duration = (wav.length - 44) / 4 / asset.sampleRate;
    assert.ok(Math.abs(duration - asset.durationSeconds) <= 1 / asset.sampleRate);
    assert.ok(Math.abs(duration - runtime.duration) <= 1 / asset.sampleRate);
    let peak = 0;
    let energy = 0;
    for (let offset = 44; offset < wav.length; offset += 2) {
      const value = wav.readInt16LE(offset) / 32768;
      peak = Math.max(peak, Math.abs(value));
      energy += value * value;
    }
    assert.ok(peak > 0.1 && peak <= 0.86, `${asset.file}: shipped mastering peak ${peak}`);
    assert.ok(Math.abs(peak - asset.masteredPeak) <= 2 / 32768);
    assert.ok(energy > 1, `${asset.file}: shipped audio must not be silence`);
    assert.ok(Math.abs(Math.sqrt(energy / ((wav.length - 44) / 2)) - asset.rms) <= 2 / 32768);
    if (asset.loop) {
      assert.ok(asset.harmony.length >= 4);
      assert.ok(asset.melody.length >= 16);
      for (const channel of [0, 1]) assert.ok(Math.abs(wav.readInt16LE(44 + channel * 2) - wav.readInt16LE(wav.length - 4 + channel * 2)) / 32768 < 0.08, `${asset.file}: shipped loop seam`);
    }
  }
});

test("original generator produces deterministic multilayer mastered WAVs and truthful provenance", async () => {
  const generator = await import("./generate-game-audio.mjs").catch(() => ({}));
  assert.equal(typeof generator.generateGameAudio, "function", "reproducible original audio generator must exist");
  const destination = await mkdtemp(join(tmpdir(), "potato-audio-test-"));
  const provenance = await generator.generateGameAudio(destination);
  assert.deepEqual(JSON.parse(await readFile(join(process.cwd(), "public/assets/audio/provenance.json"), "utf8")), provenance, "shipped provenance must match the current original generator");
  assert.equal(provenance.externalRecordings, false);
  assert.equal(provenance.aiGenerated, false);
  assert.equal(provenance.generator, "scripts/generate-game-audio.mjs");
  assert.ok(provenance.assets.length >= 24);
  const fileNames = await readdir(destination);
  assert.ok(fileNames.includes("provenance.json"));
  const { AUDIO_ASSETS } = await modelApi();
  assert.equal(provenance.assets.length, Object.keys(AUDIO_ASSETS).length);
  for (const asset of provenance.assets) {
    assert.equal(AUDIO_ASSETS[asset.id].url, `/assets/audio/${asset.file}`);
    assert.ok(Math.abs(AUDIO_ASSETS[asset.id].duration - asset.durationSeconds) <= 1 / 24000);
    const wav = await readFile(join(destination, asset.file));
    assert.equal(wav.toString("ascii", 0, 4), "RIFF");
    assert.equal(wav.toString("ascii", 8, 12), "WAVE");
    assert.equal(wav.readUInt16LE(22), 2);
    assert.equal(wav.readUInt16LE(34), 16);
    assert.equal(createHash("sha256").update(wav).digest("hex"), asset.sha256);
    let peak = 0;
    let energy = 0;
    for (let offset = 44; offset < wav.length; offset += 2) {
      const value = wav.readInt16LE(offset) / 32768;
      assert.ok(Number.isFinite(value));
      peak = Math.max(peak, Math.abs(value));
      energy += value * value;
    }
    assert.ok(peak > 0.1 && peak <= 0.86, `${asset.file}: peak ${peak}`);
    assert.ok(energy > 1, `${asset.file} cannot be silence`);
    assert.ok(asset.layers.length >= 2);
    if (asset.loop) {
      assert.ok(asset.durationSeconds >= 14);
      assert.ok(asset.harmony.length >= 4);
      assert.ok(asset.melody.length >= 16);
      for (const channel of [0, 1]) assert.ok(Math.abs(wav.readInt16LE(44 + channel * 2) - wav.readInt16LE(wav.length - 4 + channel * 2)) / 32768 < 0.08, `${asset.file} loop seam`);
    }
  }
  const before = await readFile(join(destination, "launch-fire.wav"));
  await generator.generateGameAudio(destination);
  assert.deepEqual(await readFile(join(destination, "launch-fire.wav")), before);
});
