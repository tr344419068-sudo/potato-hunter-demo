import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { mkdtempSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { createCanvas, loadImage } from "@napi-rs/canvas";
import { displayScene } from "./ui-runtime-helpers.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const textureKey = "asset:vfx_halo_energy_v1";
const modules = build({ stdin: { contents: `
export * from "./src/systems/AreaVfxModel.ts";
export { AreaVfxView } from "./src/systems/AreaVfxView.ts";
export { CombatVfxSystem } from "./src/systems/CombatVfxSystem.ts";
export { World } from "./src/entities/World.ts";
export { EventBus } from "./src/managers/EventBus.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
plugins: [{ name: "generated-halo-phaser", setup(context) {
  context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "generated-halo-phaser" }));
  context.onLoad({ filter: /.*/, namespace: "generated-halo-phaser" }, () => ({ contents: `import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Scenes: { Events: { SHUTDOWN: "shutdown" } }, BlendModes: { NORMAL: 0, ADD: 1 }, Display: { Color: { HexStringToColor: value=>({color:parseInt(value.slice(1),16)}) } }, Math: { Clamp: (value,min,max)=>Math.min(max,Math.max(min,value)), Between: (min,max)=>(min+max)/2, FloatBetween: (min,max)=>(min+max)/2 } };`, resolveDir: root }));
}}] }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

async function fixture({ count = 1, texture = "real", userTexture = "missing", ketchupTexture = "missing" } = {}) {
  const api = await modules;
  api.EventBus.removeAllListeners();
  const display = displayScene();
  const textures = new Map();
  if (texture !== "missing" && texture !== "stub") {
    textures.set(textureKey, {
      key: texture === "real" || texture === "invalid-frame" ? textureKey : texture,
      getSourceImage: () => ({ complete: true, naturalWidth: 512, naturalHeight: 512, width: 512, height: 512 }),
      get: () => ({ realWidth: texture === "invalid-frame" ? 0 : 512, realHeight: 512 }),
    });
  }
  if (userTexture !== "missing") {
    const userKey = "asset:vfx_poison_halo_user_v1";
    textures.set(userKey, { key: userTexture === "real" ? userKey : userTexture, get: () => ({ realWidth: 512, realHeight: 512 }) });
  }
  if (ketchupTexture !== "missing") {
    const ketchupKey = "asset:vfx_ketchup_halo_user_v1";
    textures.set(ketchupKey, { key: ketchupTexture === "real" ? ketchupKey : ketchupTexture, get: () => ({ realWidth: 512, realHeight: 512 }) });
  }
  let removedTextures = 0;
  if (texture !== "stub") display.scene.textures = {
    exists: key => textures.has(key),
    get: key => textures.get(key),
    remove: key => { removedTextures++; return textures.delete(key); },
  };
  const world = new api.World();
  const playerId = world.createEntity();
  world.components.transforms.set(playerId, { x: 300, y: 250, radius: 20 });
  world.components.players.set(playerId, { level: 5 });
  const profiles = Array.from({ length: count }, (_, index) => ({ skillId: `aura-${index}`, radius: 150 + index, vfxKind: index % 2 ? "ketchup" : "poison", color: 0x80b918 }));
  const runtime = { world, playerId, skillManager: { getAuraProfiles: () => profiles }, stats: { elapsedMs: 0 } };
  return { ...api, ...display, textures, profiles, runtime, view: new api.AreaVfxView(display.scene), removedTextures: () => removedTextures };
}

const images = fixture => fixture.objects.filter(object => object.kind === "image");
const graphics = fixture => fixture.objects.filter(object => object.kind === "graphics");
const state = fixture => fixture.objects.map(object => [object.x, object.y, object.width, object.height, object.scaleX, object.scaleY, object.rotation, object.alpha, object.visible]);

test('a softly glowing persistent field uses the existing hollow light texture, stays under the hero, and follows level growth', async () => {
  const f = await fixture({ count: 2, userTexture: 'real', ketchupTexture: 'real' });
  f.view.update(0, f.runtime);
  for (const [index, profile] of f.profiles.entries()) {
    const glow = f.view.layers.get(`aura-${index}`).fieldGlow;
    assert.ok(glow, 'wide smooth field uses the existing light texture');
    assert.equal(glow.texture, textureKey);
    assert.equal(glow.blendMode, 1);
    assert.ok(glow.visible && glow.alpha >= .35 && glow.alpha <= .8);
    assert.ok(glow.depth < 1);
    assert.equal(glow.width, profile.radius * 2);
  }
  f.profiles[0].radius = 260; f.runtime.world.components.transforms.get(f.runtime.playerId).x = 480; f.view.update(0, f.runtime);
  const glow = f.view.layers.get('aura-0').fieldGlow;
  assert.equal(glow.width, 520); assert.equal(glow.x, 480);
  f.view.setReducedEffects(true); f.view.update(0, f.runtime);
  assert.equal(glow.alpha, 0); assert.equal(glow.visible, false);
  f.view.destroy(); assert.ok(f.objects.every(o => o.destroyed));
});

test("poison uses user supplied green-cyan halo without recoloring it; missing ketchup art uses generic fallback", async () => {
  const f = await fixture({ count: 2, userTexture: "real" });
  f.view.update(135, f.runtime);
  const poison = f.view.layers.get("aura-0"), ketchup = f.view.layers.get("aura-1");
  for (const wave of poison.waves) {
    assert.equal(wave.glow.texture, "asset:vfx_poison_halo_user_v1");
    assert.ok(wave.glow.calls.some(c => c[0] === "setTint" && c[1] === 0xffffff));
  }
  for (const wave of ketchup.waves) assert.equal(wave.glow.texture, textureKey);
  assert.equal(f.objects.length, 22);
  f.view.setReducedEffects(true); f.view.update(0, f.runtime);
  assert.ok(images(f).every(image => !image.visible));
  f.view.destroy(); assert.ok(f.objects.every(o => o.destroyed));
});

test("ketchup selects user red liquid art with authored color and translucent normal blending", async () => {
  const f = await fixture({ count: 2, userTexture: "real", ketchupTexture: "real" });
  f.view.update(135, f.runtime);
  const poison = f.view.layers.get("aura-0"), ketchup = f.view.layers.get("aura-1");
  for (const wave of poison.waves) {
    assert.equal(wave.glow.texture, "asset:vfx_poison_halo_user_v1");
    assert.equal(wave.glow.blendMode, 1);
  }
  for (const [index, wave] of ketchup.waves.entries()) {
    assert.equal(wave.glow.texture, "asset:vfx_ketchup_halo_user_v1");
    assert.ok(wave.glow.calls.some(c => c[0] === "setTint" && c[1] === 0xffffff));
    assert.equal(wave.glow.blendMode, 0, "normal blending keeps sauce red rather than additive yellow");
    assert.equal(wave.glow.alpha, f.getAreaGlowFrame(wave.radius, 135 + index * 450, false).alpha * (.65 / .9));
    assert.ok(wave.glow.alpha <= .65);
    assert.ok(wave.glow.depth < 1);
  }
  assert.equal(f.objects.length, 22);
  f.view.setReducedEffects(true); f.view.update(0, f.runtime);
  assert.ok(images(f).every(image => !image.visible));
  f.view.destroy(); assert.ok(f.objects.every(o => o.destroyed));
  assert.equal(f.removedTextures(), 0);
});

for (const invalid of ["missing", "__MISSING", "__DEFAULT"]) test(`ketchup user art ${invalid} falls back to generic color-tinted glow`, async () => {
  const f = await fixture({ count: 2, ketchupTexture: invalid });
  f.view.update(135, f.runtime);
  for (const wave of f.view.layers.get("aura-1").waves) {
    assert.equal(wave.glow.texture, textureKey);
    assert.equal(wave.glow.blendMode, 1);
    assert.ok(wave.glow.calls.some(c => c[0] === "setTint" && c[1] === f.getAreaVfxSpec("ketchup").primaryColor));
  }
  assert.equal(f.objects.length, 22);
  f.view.destroy();
});

test("ketchup fallback wave palette matches the supplied red sauce", async () => {
  const f = await modules;
  const spec = f.getAreaVfxSpec("ketchup");
  assert.equal(spec.primaryColor, 0xff5646);
  assert.equal(spec.accentColor, 0xff9273);
  assert.equal(spec.edgeColor, 0xfff0b3);
});

test("user ketchup halo is real RGBA with red sauce, white highlights and transparent center", async () => {
  const assets = JSON.parse(await readFile(`${root}src/configs/assets.json`, "utf8"));
  const asset = assets.vfx_ketchup_halo_user_v1;
  assert.ok(asset, "user ketchup asset needs registration");
  assert.equal(asset.path, "assets/vfx/halo-user-v1/ketchup-halo.png");
  assert.equal(asset.width, 512); assert.equal(asset.height, 512);
  const bytes = await readFile(`${root}public/${asset.path}`); assert.equal(bytes[25], 6);
  const image = await loadImage(`${root}public/${asset.path}`);
  const canvas = createCanvas(512, 512), ctx = canvas.getContext("2d"); ctx.drawImage(image, 0, 0);
  const pixels = ctx.getImageData(0, 0, 512, 512).data;
  let red = 0, white = 0, soft = 0;
  for (let i = 0; i < pixels.length; i += 4) {
    const [r, g, b, a] = pixels.subarray(i, i + 4), n = i / 4;
    if (a > 120 && r > g + 80 && r > b + 80) red++;
    if (a > 120 && r > 220 && g > 210 && b > 180) white++;
    if (a > 0 && a < 255) soft++;
    if (Math.hypot(n % 512 - 255.5, Math.floor(n / 512) - 255.5) < 120) assert.equal(a, 0);
  }
  assert.ok(red > 10000); assert.ok(white > 100); assert.ok(soft > 1000);
});

test("true-alpha ketchup source imports repeatably without extraction or recoloring", async () => {
  const temp = mkdtempSync(join(tmpdir(), "ketchup-halo-import-")), output = join(temp, "ketchup-halo.png");
  execFileSync("python3", [join(root, "scripts/process-user-halo.py"), "--source", join(root, "artifacts/user-ketchup-halo-2026-11-18/source-original.png"), "--artifact-dir", temp, "--output", output, "--name", "ketchup"], { cwd: root });
  assert.deepEqual(await readFile(output), await readFile(join(root, "public/assets/vfx/halo-user-v1/ketchup-halo.png")));
  const report = JSON.parse(await readFile(join(temp, "processing.json"), "utf8"));
  assert.equal(report.sourceMode, "RGBA");
  assert.equal(report.processing, "preserved source RGBA; Lanczos resize only");
  assert.equal(report.authorship, "user-supplied image; no AI tool called by agent for this import");
});

test("placeholder user halo falls back to the valid generic glow while keeping a bounded field", async () => {
  const f = await fixture({ userTexture: "__MISSING" });
  f.view.update(135, f.runtime);
  assert.equal(images(f).length, 3);
  assert.ok(images(f).every(image => image.texture === textureKey));
  f.view.destroy();
});

test("user poison halo keeps color, soft alpha and empty center in its versioned asset", async () => {
  const assets = JSON.parse(await readFile(`${root}src/configs/assets.json`, "utf8"));
  const asset = assets.vfx_poison_halo_user_v1;
  assert.ok(asset, "user poison asset needs registration");
  assert.equal(asset.path, "assets/vfx/halo-user-v1/poison-halo.png");
  assert.equal(asset.width, 512); assert.equal(asset.height, 512);
  const image = await loadImage(`${root}public/${asset.path}`);
  const canvas = createCanvas(512, 512), ctx = canvas.getContext("2d"); ctx.drawImage(image, 0, 0);
  const pixels = ctx.getImageData(0, 0, 512, 512).data;
  let green = 0, cyan = 0;
  for (let i = 0; i < pixels.length; i += 4) {
    const [r, g, b, a] = pixels.subarray(i, i + 4), n = i / 4;
    if (a > 80 && g > r + 40 && g > b + 25) green++;
    if (a > 80 && b > r + 40 && b > g - 30) cyan++;
    if (Math.hypot(n % 512 - 256, Math.floor(n / 512) - 256) < 90) assert.equal(a, 0);
  }
  assert.ok(green > 1000); assert.ok(cyan > 500);
});

test("user image extraction tests and archived source regenerate the identical runtime image", async () => {
  execFileSync("python3", [join(root, "scripts/process-user-halo.test.py")], { cwd: root });
  const temp = mkdtempSync(join(tmpdir(), "user-halo-import-"));
  const output = join(temp, "poison-halo.png");
  execFileSync("python3", [join(root, "scripts/process-user-halo.py"), "--source", join(root, "artifacts/user-poison-halo-2026-11-18/source-original.png"), "--artifact-dir", temp, "--output", output], { cwd: root });
  assert.deepEqual(await readFile(output), await readFile(join(root, "public/assets/vfx/halo-user-v1/poison-halo.png")));
});

test("shared generated halo asset is registered as a single versioned 512px image", async () => {
  const assets = JSON.parse(await readFile(`${root}src/configs/assets.json`, "utf8"));
  const asset = assets.vfx_halo_energy_v1;
  assert.ok(asset, "generated halo asset must be registered");
  assert.equal(asset.type, "vfx");
  assert.equal(asset.path, "assets/vfx/halo-v1/halo-energy-generated-v1.png");
  assert.equal(asset.width, 512);
  assert.equal(asset.height, 512);
  assert.equal(asset.frameCount, undefined);
});

test("generated halo is genuine RGBA with emitted-light alpha and an empty center", async () => {
  const path = `${root}public/assets/vfx/halo-v1/halo-energy-generated-v1.png`;
  const bytes = await readFile(path);
  assert.equal(bytes[25], 6, "PNG color type must be RGBA");
  const image = await loadImage(path);
  assert.equal(image.width, 512);
  assert.equal(image.height, 512);
  const canvas = createCanvas(512, 512), context = canvas.getContext("2d");
  context.drawImage(image, 0, 0);
  const pixels = context.getImageData(0, 0, 512, 512).data;
  let partialPixels = 0, brightPixels = 0;
  for (let offset = 0; offset < pixels.length; offset += 4) {
    const alpha = pixels[offset + 3], pixel = offset / 4;
    if (alpha > 0 && alpha < 255) partialPixels++;
    if (alpha >= 192) brightPixels++;
    if (Math.hypot(pixel % 512 - 255.5, Math.floor(pixel / 512) - 255.5) < 64) assert.equal(alpha, 0);
    if (alpha >= 192) assert.ok(pixels[offset] >= 250 && pixels[offset + 1] >= 250 && pixels[offset + 2] >= 250);
  }
  assert.ok(partialPixels > 10000);
  assert.ok(brightPixels > 100);
});

test("glow has a bright local attack and nearly disappears by 810ms", async () => {
  const api = await modules;
  assert.equal(typeof api.getAreaGlowFrame, "function", "generated glow frame model must exist");
  assert.equal(api.getAreaGlowFrame(150, 0, false).alpha, 0);
  const peak = api.getAreaGlowFrame(150, 135, false);
  assert.ok(peak.alpha >= .75 && peak.alpha <= 1);
  assert.ok(peak.alpha > api.getAreaGlowFrame(150, 45, false).alpha);
  assert.ok(peak.alpha > api.getAreaGlowFrame(150, 360, false).alpha);
  assert.ok(api.getAreaGlowFrame(150, 810, false).alpha <= .03);
  assert.equal(api.getAreaGlowFrame(150, 900, false).alpha, 0);
});

test("glow matches wave scale and rotation while staying within the wave diameter", async () => {
  const api = await modules;
  assert.equal(typeof api.getAreaGlowFrame, "function");
  for (const radius of [0, 60, 150, 300]) for (let age = 0; age <= 900; age += 45) {
    const wave = api.getAreaWaveFrame(radius, age, false), glow = api.getAreaGlowFrame(radius, age, false);
    assert.equal(glow.scale, wave.scale);
    assert.equal(glow.rotation, wave.rotation);
    assert.ok(glow.displaySize >= 0 && glow.displaySize <= wave.radius * 2 * wave.scale);
    assert.ok(glow.alpha >= 0 && glow.alpha <= 1);
    assert.equal(api.getAreaGlowFrame(radius, age, true).alpha, 0);
  }
  assert.equal(api.getAreaWaveFrame(150, 135, false).alpha, .6);
  assert.equal(api.getAreaWaveFrame(150, 135, true).alpha, .36);
});

test("each wave reuses one additive generated image tinted under entities", async () => {
  const fixtureData = await fixture({ count: 2 });
  fixtureData.view.update(135, fixtureData.runtime);
  assert.equal(graphics(fixtureData).length, 16);
  assert.equal(images(fixtureData).length, 6);
  assert.equal(fixtureData.objects.length, 22);
  for (const image of images(fixtureData)) {
    assert.equal(image.texture, textureKey);
    assert.equal(image.blendMode, 1);
    assert.ok(image.depth === .69 || image.depth === .685);
    assert.ok(image.calls.some(call => call[0] === "setTint" && [fixtureData.getAreaVfxSpec("poison").primaryColor, fixtureData.getAreaVfxSpec("ketchup").primaryColor].includes(call[1])));
  }
  for (const layer of fixtureData.view.layers.values()) {
    assert.ok(layer.motes.every(mote => !mote.glow));
    for (const wave of layer.waves) assert.ok(wave.glow.calls.some(call => call[0] === "setTint" && call[1] === fixtureData.getAreaVfxSpec(layer.kind).primaryColor));
  }
  assert.equal(fixtureData.scene.cameras.main.flashes + fixtureData.scene.cameras.main.shakes, 0);
  fixtureData.view.destroy();
});

test("generated image shares the current hero origin while size, rotation and alpha advance independently", async () => {
  const fixtureData = await fixture();
  fixtureData.view.update(135, fixtureData.runtime);
  const layer = fixtureData.view.layers.get("aura-0"), wave = layer.waves[0], glow = wave.glow;
  assert.ok(glow, "wave must own its optional image");
  const initial = fixtureData.getAreaGlowFrame(150, 135, false);
  assert.equal(glow.x, wave.visual.x);
  assert.equal(glow.y, wave.visual.y);
  assert.equal(glow.width, initial.displaySize);
  assert.equal(glow.height, initial.displaySize);
  assert.equal(glow.rotation, wave.visual.rotation);
  assert.equal(glow.alpha, initial.alpha);
  const oldSize = glow.width;
  fixtureData.runtime.world.components.transforms.get(fixtureData.runtime.playerId).x = 480;
  fixtureData.view.update(225, fixtureData.runtime);
  assert.equal(glow.x, 480);
  assert.equal(glow.y, 250);
  assert.equal(glow.x, wave.visual.x);
  assert.ok(glow.width > oldSize);
  assert.equal(glow.rotation, wave.visual.rotation);
  fixtureData.view.update(675, fixtureData.runtime);
  assert.equal(glow.x, 480);
  assert.equal(glow.x, wave.visual.x);
  assert.equal(glow.alpha, fixtureData.getAreaGlowFrame(150, 135, false).alpha);
  fixtureData.view.destroy();
});

test("shrinking an aura clamps both glow and wave without broadening the boundary", async () => {
  const fixtureData = await fixture();
  fixtureData.view.update(135, fixtureData.runtime);
  const wave = fixtureData.view.layers.get("aura-0").waves[0];
  assert.ok(wave.glow);
  fixtureData.profiles[0].radius = 80;
  fixtureData.view.update(0, fixtureData.runtime);
  assert.equal(wave.radius, 80);
  assert.ok(wave.glow.width <= 160 * wave.visual.scaleX);
  fixtureData.view.destroy();
});

test("zero delta freezes animation phase but synchronizes externally changed hero coordinates", async () => {
  const fixtureData = await fixture();
  fixtureData.view.update(135, fixtureData.runtime);
  assert.equal(images(fixtureData).length, 3);
  const before = state(fixtureData);
  fixtureData.runtime.world.components.transforms.get(fixtureData.runtime.playerId).x = 480;
  fixtureData.view.update(0, fixtureData.runtime);
  const after = state(fixtureData);
  assert.deepEqual(after.map(s => s.slice(2)), before.map(s => s.slice(2)));
  for (let i = 0; i < after.length; i++) {
    assert.ok(Math.abs(after[i][0] - before[i][0] - 180) < 1e-9);
    assert.equal(after[i][1], before[i][1]);
  }
  fixtureData.view.destroy();
});

test("all aura waves, glow images and motes follow walking, direction changes and dash jumps every frame", async () => {
  const f = await fixture({ count: 2, userTexture: "real" });
  f.view.update(135, f.runtime);
  const original = [...f.objects];
  for (const [x, y, delta] of [[312, 267, 16], [290, 310, 16], [490, 220, 16], [280, 420, 33], [270, 400, 1000]]) {
    Object.assign(f.runtime.world.components.transforms.get(f.runtime.playerId), { x, y });
    f.view.update(delta, f.runtime);
    for (const layer of f.view.layers.values()) {
      for (const wave of layer.waves) {
        assert.deepEqual([wave.visual.x, wave.visual.y], [x, y]);
        assert.deepEqual([wave.glow.x, wave.glow.y], [x, y]);
      }
      for (const [index, mote] of layer.motes.entries()) {
        const frame = f.getAreaMoteFrame(mote.radius, (f.view.elapsedMs + index * 120) % f.AREA_MOTE_PERIOD_MS, index, false);
        assert.deepEqual([mote.visual.x, mote.visual.y], [x + frame.x, y + frame.y]);
      }
    }
    assert.deepEqual(f.objects, original);
  }
  f.view.destroy();
});

test("reduced effects hides both glow images but keeps one wave and two motes", async () => {
  const fixtureData = await fixture();
  fixtureData.view.update(135, fixtureData.runtime);
  assert.equal(images(fixtureData).length, 3);
  fixtureData.view.setReducedEffects(true);
  fixtureData.view.update(0, fixtureData.runtime);
  assert.ok(images(fixtureData).every(image => image.alpha === 0 && !image.visible));
  assert.equal(graphics(fixtureData).filter(object => object.visible).length, 3);
  fixtureData.view.setReducedEffects(false);
  fixtureData.view.update(0, fixtureData.runtime);
  assert.ok(images(fixtureData).every(image => image.visible && image.alpha > 0));
  fixtureData.view.destroy();
});

test("updates and arbitrarily large deltas allocate no further display objects", async () => {
  const fixtureData = await fixture({ count: 12 });
  fixtureData.view.update(135, fixtureData.runtime);
  assert.equal(graphics(fixtureData).length, 24);
  assert.equal(images(fixtureData).length, 9);
  assert.equal(fixtureData.objects.length, 33);
  const original = [...fixtureData.objects];
  for (let iteration = 0; iteration < 30; iteration++) fixtureData.view.update(iteration % 2 ? 16 : 1000000, fixtureData.runtime);
  assert.deepEqual(fixtureData.objects, original);
  assert.equal(fixtureData.tweens.length, 0);
  fixtureData.view.destroy();
  assert.ok(fixtureData.objects.every(object => object.destroyed));
  assert.equal(fixtureData.removedTextures(), 0);
});

test("skill removal and profile-kind replacement release images without deleting the shared texture", async () => {
  const fixtureData = await fixture();
  fixtureData.view.update(135, fixtureData.runtime);
  assert.equal(images(fixtureData).length, 3);
  const original = [...fixtureData.objects];
  fixtureData.profiles[0].vfxKind = "ketchup";
  fixtureData.view.update(0, fixtureData.runtime);
  assert.ok(original.every(object => object.destroyed));
  assert.equal(fixtureData.objects.filter(object => !object.destroyed).length, 11);
  fixtureData.profiles.length = 0;
  fixtureData.view.update(0, fixtureData.runtime);
  assert.ok(fixtureData.objects.every(object => object.destroyed));
  assert.equal(fixtureData.removedTextures(), 0);
  assert.ok(fixtureData.textures.has(textureKey));
  fixtureData.view.destroy();
});

test("hero removal and repeated destroy release all generated image ownership", async () => {
  const fixtureData = await fixture();
  fixtureData.view.update(135, fixtureData.runtime);
  assert.equal(images(fixtureData).length, 3);
  fixtureData.runtime.world.components.transforms.delete(fixtureData.runtime.playerId);
  fixtureData.view.update(0, fixtureData.runtime);
  assert.ok(fixtureData.objects.every(object => object.destroyed));
  fixtureData.view.destroy();
  fixtureData.view.destroy();
  fixtureData.view.update(135, fixtureData.runtime);
  assert.equal(fixtureData.objects.length, 11);
  assert.equal(fixtureData.removedTextures(), 0);
});

test("terminal combat result releases glow images even without another update", async () => {
  const fixtureData = await fixture(), system = new fixtureData.CombatVfxSystem(fixtureData.scene);
  system.update(135, fixtureData.runtime);
  assert.equal(images(fixtureData).length, 3);
  fixtureData.EventBus.emit("game:over", { outcome: "defeat" });
  assert.ok(fixtureData.objects.every(object => object.destroyed));
  system.update(135, fixtureData.runtime);
  assert.equal(fixtureData.objects.length, 11);
  system.destroy();
  fixtureData.view.destroy();
  assert.equal(fixtureData.removedTextures(), 0);
});

for (const texture of ["missing", "__MISSING", "__DEFAULT", "invalid-frame", "stub"]) {
  test(`texture ${texture} keeps the thin code wave fallback without any image`, async () => {
    const fixtureData = await fixture({ texture });
    fixtureData.view.update(135, fixtureData.runtime);
    assert.equal(images(fixtureData).length, 0);
    assert.equal(graphics(fixtureData).length, 8);
    const wave = fixtureData.view.layers.get("aura-0").waves[0].visual;
    assert.equal(wave.alpha, .6);
    assert.ok(wave.calls.some(call => call[0] === "strokeCircle"));
    assert.ok(wave.calls.filter(call => call[0] === "lineTo").length >= 30);
    assert.ok(!wave.calls.some(call => call[0] === "fillCircle"));
    fixtureData.view.destroy();
  });
}
