import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function loadModel() {
  try {
    return await import("../src/systems/ElementalReactionModel.ts");
  } catch {
    return {};
  }
}

test("elemental pairings resolve into four distinct reactions", async () => {
  const model = await loadModel();
  assert.equal(typeof model.resolveElementalReaction, "function");

  assert.equal(model.resolveElementalReaction("fire", ["poison"])?.kind, "toxic_ignition");
  assert.equal(model.resolveElementalReaction("lightning", ["freeze"])?.kind, "superconduct");
  assert.equal(model.resolveElementalReaction("peeler", ["freeze"])?.kind, "shatter");
  assert.equal(model.resolveElementalReaction("frost", ["burn"])?.kind, "thermal_shock");
});

test("reactions consume their setup status and keep splash bounded", async () => {
  const model = await loadModel();
  assert.equal(typeof model.resolveElementalReaction, "function");

  for (const reaction of [
    model.resolveElementalReaction("explosion", ["poison"]),
    model.resolveElementalReaction("lightning", ["slow"]),
    model.resolveElementalReaction("kinetic", ["freeze"]),
    model.resolveElementalReaction("frost", ["burn"]),
  ]) {
    assert.ok(reaction);
    assert.ok(reaction.consumeStatus.length > 0);
    assert.ok(reaction.bonusDamageMultiplier > 0 && reaction.bonusDamageMultiplier <= 0.8);
    assert.ok(reaction.splashDamageMultiplier >= 0 && reaction.splashDamageMultiplier <= 0.4);
    assert.ok(reaction.maxSplashTargets >= 1 && reaction.maxSplashTargets <= 8);
  }

  assert.equal(model.resolveElementalReaction("fire", ["burn"]), undefined);
  assert.equal(model.resolveElementalReaction("poison", []), undefined);
});

test("projectiles, auras, and combat VFX share the reaction event chain", async () => {
  const [projectileSource, auraSource, vfxSource] = await Promise.all([
    readFile(new URL("../src/systems/ProjectileCollisionSystem.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/systems/AuraSystem.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/systems/CombatVfxSystem.ts", import.meta.url), "utf8"),
  ]);

  assert.match(projectileSource, /triggerElementalReaction/);
  assert.match(auraSource, /triggerElementalReaction/);
  assert.match(vfxSource, /combat:reaction/);
  assert.match(vfxSource, /showElementalReaction/);
});
