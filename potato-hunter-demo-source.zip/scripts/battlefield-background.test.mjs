import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));

async function makeBackground(stage) {
  const bundle = await build({ stdin: { contents: 'export { BattlefieldBackground } from "./src/systems/BattlefieldBackground.ts";', resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
    plugins: [{ name: "headless-phaser", setup(context) {
      context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
      context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: 'export default { Scale: { Events: { RESIZE: "resize" } }, Scenes: { Events: { SHUTDOWN: "shutdown" } } };' }));
    } }] });
  const { BattlefieldBackground } = await import(`data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].text).toString("base64")}`);
  const objects = [];
  const chain = (kind) => {
    const object = { kind, commands: [] };
    const proxy = new Proxy(object, { get(target, key) {
      if (key in target) return target[key];
      return (...args) => { target.commands.push([key, ...args]); return proxy; };
    } });
    objects.push(proxy);
    return proxy;
  };
  const scene = { textures: { exists: () => true }, scale: { width: 1280, height: 720, on() {}, off() {} }, events: { once() {} },
    cameras: { main: { scrollX: 230, scrollY: -120, width: 1280, height: 720 } },
    add: { tileSprite: () => chain("tile"), graphics: () => chain("graphics"), rectangle: () => chain("overlay") } };
  return { background: new BattlefieldBackground(scene, stage), objects, scene };
}

test("desert sand stays registered to the world while the camera moves", async () => {
  const { background, objects, scene } = await makeBackground("desert");
  background.update(0);
  const tile = objects.find(object => object.kind === "tile");
  assert.equal(tile.tilePositionX, scene.cameras.main.scrollX);
  assert.equal(tile.tilePositionY, scene.cameras.main.scrollY);
});

test("desert has no detached shadow-like ground props but keeps the boss arena", async () => {
  const { background, objects } = await makeBackground("desert");
  const graphics = objects.find(object => object.kind === "graphics");
  background.update(0);
  assert.equal(graphics.commands.filter(([name]) => name === "fillEllipse" || name === "strokeEllipse").length, 0);
  background.update(60_000, 400, 300);
  assert.ok(graphics.commands.some(([name]) => name === "strokeCircle"), "boss arena remains visible");
});

test("meadow keeps its existing ground decorations", async () => {
  const { background, objects } = await makeBackground("meadow");
  background.update(0);
  const graphics = objects.find(object => object.kind === "graphics");
  assert.ok(graphics.commands.some(([name]) => ["fillEllipse", "lineTo"].includes(name)));
});

test("battlefield background follows the camera and owns resize cleanup", async () => {
  let source = "";
  try {
    source = await readFile(new URL("../src/systems/BattlefieldBackground.ts", import.meta.url), "utf8");
  } catch {
    // The first red run intentionally reaches this assertion with an empty source.
  }

  assert.match(source, /add\.tileSprite/);
  assert.match(source, /setScrollFactor\(0\)/);
  assert.match(source, /Scale\.Events\.RESIZE/);
  assert.match(source, /this\.background\.destroy\(\)/);
  assert.match(source, /background_battlefield_grassland/);
});

test("render system does not cover the grass with the legacy dark grid", async () => {
  const source = await readFile(new URL("../src/systems/RenderSystem.ts", import.meta.url), "utf8");

  assert.doesNotMatch(source, /this\.drawGrid\(runtime\)/);
  assert.doesNotMatch(source, /private drawGrid\(/);
});

test("battlefield layers deterministic chapter props behind the combat plane", async () => {
  const source = await readFile(new URL("../src/systems/BattlefieldBackground.ts", import.meta.url), "utf8");

  assert.match(source, /getBattlefieldDecoration/);
  assert.match(source, /decorationGraphics/);
  assert.match(source, /chapterOverlay/);
  assert.match(source, /drawDecoration/);
  assert.match(source, /drawBossArena/);
  assert.match(source, /setDepth\(-1[5-9]\)/);
});
