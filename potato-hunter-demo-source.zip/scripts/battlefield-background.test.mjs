import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("battlefield background follows the camera and owns resize cleanup", async () => {
  let source = "";
  try {
    source = await readFile(new URL("../src/systems/BattlefieldBackground.ts", import.meta.url), "utf8");
  } catch {
    // The first red run intentionally reaches this assertion with an empty source.
  }

  assert.match(source, /add\.tileSprite/);
  assert.match(source, /setScrollFactor\(0\)/);
  assert.match(source, /Scale\.Events\.RESIZE/);
  assert.match(source, /this\.background\.destroy\(\)/);
  assert.match(source, /background_battlefield_grassland/);
});

test("render system does not cover the grass with the legacy dark grid", async () => {
  const source = await readFile(new URL("../src/systems/RenderSystem.ts", import.meta.url), "utf8");

  assert.doesNotMatch(source, /this\.drawGrid\(runtime\)/);
  assert.doesNotMatch(source, /private drawGrid\(/);
});

test("battlefield layers deterministic chapter props behind the combat plane", async () => {
  const source = await readFile(new URL("../src/systems/BattlefieldBackground.ts", import.meta.url), "utf8");

  assert.match(source, /getBattlefieldDecoration/);
  assert.match(source, /decorationGraphics/);
  assert.match(source, /chapterOverlay/);
  assert.match(source, /drawDecoration/);
  assert.match(source, /drawBossArena/);
  assert.match(source, /setDepth\(-1[5-9]\)/);
});
