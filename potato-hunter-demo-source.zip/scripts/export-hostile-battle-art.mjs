import { mkdir, writeFile } from 'node:fs/promises';
import { createCanvas, loadImage } from '@napi-rs/canvas';

const assets = new URL('../public/assets/', import.meta.url);
const enemyDir = new URL('enemies/meadow-v1/', assets);
const shotDir = new URL('projectiles/hostile-v1/', assets);
await Promise.all([mkdir(enemyDir, { recursive: true }), mkdir(shotDir, { recursive: true })]);

const portraits = {
  delivery_box: 3, drone_summoner: 3, mushroom_hexer: 4,
  chili_scatter: 4, pea_sniper: 4, donut_jumper: 4,
};
for (const [id, version] of Object.entries(portraits)) {
  const image = await loadImage(new URL(`bestiary/v${version}/${id}.png`, assets));
  const canvas = createCanvas(192, 192);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(image, 0, 0, 192, 192);
  await writeFile(new URL(`${id}.webp`, enemyDir), canvas.toBuffer('image/webp', 87));
}

// These are transformed bitmap layers from the in-project CC0 library, not
// procedural shapes. All sprites face right and have their head at (75, 24).
const layers = {};
for (const name of ['glow', 'trace', 'flame', 'crystal']) {
  layers[name] = await loadImage(new URL(`vfx/${name}.png`, assets));
}

const recipes = {
  cola:    ['#381922', '#d64d25', '#ff9657', '#fff0c7', 49, 45, 'glow', 34],
  ember:   ['#4e2021', '#f44324', '#ff935a', '#fff0d5', 56, 36, 'flame', 56],
  cactus:  ['#133f37', '#009d76', '#76f3c7', '#eafff5', 63, 34, 'crystal', 49],
  sniper:  ['#452729', '#e06d20', '#ffbe47', '#fffde5', 66, 30, 'crystal', 81],
  oil:     ['#50241c', '#f65b0b', '#ffc346', '#fff6ba', 53, 41, 'flame', 60],
  sauce:   ['#4a1b29', '#e93b31', '#ff8f62', '#fff3c8', 48, 41, 'glow', 50],
  sand:    ['#172e4c', '#138ac4', '#74dfff', '#e6ffff', 57, 39, 'crystal', 59],
};

// Tint the alpha masks offline so the runtime needs only one sprite per shot.
function stamp(ctx, name, color, x, y, width, height, alpha = 1) {
  const layer = createCanvas(112, 48);
  const mask = layer.getContext('2d');
  mask.imageSmoothingQuality = 'high';
  mask.drawImage(layers[name], x - width / 2, y - height / 2, width, height);
  mask.globalCompositeOperation = 'source-in';
  mask.fillStyle = color;
  mask.fillRect(0, 0, layer.width, layer.height);
  ctx.globalAlpha = alpha;
  ctx.drawImage(layer, 0, 0);
}

for (const [name, [edge, color, bright, hot, width, height, texture, tail]] of Object.entries(recipes)) {
  const canvas = createCanvas(112, 48);
  const ctx = canvas.getContext('2d');
  stamp(ctx, 'glow', edge, 65, 24, tail * 1.64, height * .94, .78);
  stamp(ctx, 'trace', color, 54, 24, tail * 1.62, height * 1.86, .91);
  stamp(ctx, 'glow', edge, 74, 24, width * 1.26, height * 1.17);
  stamp(ctx, 'glow', color, 74, 24, width, height);
  stamp(ctx, texture, bright, 74, 24, width * .82, height * .79, .98);
  if (texture === 'glow') {
    stamp(ctx, 'glow', hot, 80, 21, width * .42, height * .38, .98);
  } else {
    stamp(ctx, 'trace', bright, 71, 24, width * 1.14, height * 1.12);
    stamp(ctx, 'glow', hot, 80, 22.5, width * .47, height * .52, .98);
    if (texture === 'crystal') stamp(ctx, 'trace', hot, 81, 24, width * .92, height * .69, .91);
  }
  await writeFile(new URL(`${name}.webp`, shotDir), canvas.toBuffer('image/webp', 90));
}
