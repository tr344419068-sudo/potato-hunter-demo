import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { UI_FONT, UI_BODY_FONT } from "../src/ui/UITheme.ts";
import { parseHTML } from 'linkedom';

const fontModule = build({ entryPoints: [fileURLToPath(new URL("../src/ui/UIFontLoader.ts", import.meta.url))], bundle: true, platform: "node", format: "esm", write: false }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));
const loadModule = () => fontModule;

test("font preloading measures the standard Chinese UI stack before canvas layout", async () => {
  const { loadUIFonts } = await loadModule(); assert.equal(typeof loadUIFonts, "function", "standard font has no startup loader");
  let resolveFont; const requests = [];
  const fonts = { load: (family, text) => { requests.push({ family, text }); return new Promise(resolve => resolveFont = resolve); } };
  let settled = false; const result = loadUIFonts(fonts, 200).then(ready => { settled = true; return ready; });
  await Promise.resolve(); assert.equal(settled, false);
  assert.ok(!UI_FONT.includes("ZCOOL")); assert.ok(!UI_FONT.includes("Yuanti"));
  assert.equal(UI_FONT, UI_BODY_FONT); assert.ok(UI_FONT.includes('"PingFang SC"')); assert.ok(UI_FONT.endsWith("sans-serif"));
  assert.equal(requests[0].family, `400 24px ${UI_FONT}`); assert.ok(requests[0].text.includes("选择"));
  resolveFont([{}]); assert.equal(await result, true);
});

test("missing, rejected, and indefinitely pending fonts fall back without blocking startup", async () => {
  const { loadUIFonts } = await loadModule(); assert.equal(typeof loadUIFonts, "function", "font fallback has no startup loader");
  assert.equal(await loadUIFonts(undefined, 5), false);
  assert.equal(await loadUIFonts({ load: async () => { throw new Error("offline font"); } }, 5), false);
  assert.equal(await loadUIFonts({ load: () => new Promise(() => {}) }, 5), false);
});

test("actual startup defers Phaser creation until ordinary glyph measurement is ready", async () => {
  const root = fileURLToPath(new URL("../", import.meta.url));
  const output = await build({ entryPoints: [fileURLToPath(new URL("../src/main.ts", import.meta.url))], bundle: true, platform: "node", format: "esm", write: false, loader: { ".css": "empty" }, plugins: [{ name: "font-boot", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "font-boot" }));
    context.onLoad({ filter: /.*/, namespace: "font-boot" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Scene: class {}, Events: { EventEmitter }, Game: class { constructor(config) { globalThis.__fontBootGames.push(config); } destroy() {} }, AUTO: 0, Scale: { RESIZE: 1, CENTER_BOTH: 2 } };', resolveDir: root }));
  }}] });
  const previousDocument = globalThis.document; const previousWindow=globalThis.window; const previousGames = globalThis.__fontBootGames;
  const {document,window}=parseHTML('<html><body><div id="game"></div></body></html>');
  let resolveFace; globalThis.__fontBootGames = []; globalThis.document = document; globalThis.window=window;
  document.fonts={load:()=>new Promise(resolve=>resolveFace=resolve)};
  try {
    await import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`);
    assert.equal(globalThis.__fontBootGames.length, 0, "Phaser booted before Chinese glyph measurement was ready");
    resolveFace([{}]); await Promise.resolve(); await Promise.resolve(); await Promise.resolve(); await Promise.resolve();
    assert.equal(globalThis.__fontBootGames.length, 1);
  } finally { window.dispatchEvent(new window.Event('pagehide')); globalThis.document = previousDocument; globalThis.window=previousWindow; globalThis.__fontBootGames = previousGames; }
  const [theme, css] = await Promise.all([readFile(new URL("../src/ui/UITheme.ts", import.meta.url), "utf8"), readFile(new URL("../src/styles.css", import.meta.url), "utf8")]);
  assert.ok(!css.includes("ZCOOL")); assert.ok(!theme.includes("ZCOOL"));
  assert.match(css, /font-family:\s*["']PingFang SC["']/);
  assert.ok((await readFile(new URL("../public/assets/fonts/ZCOOLKuaiLe-Regular.ttf", import.meta.url))).length > 0);
  assert.ok((await readFile(new URL("../public/assets/fonts/OFL.txt", import.meta.url), "utf8")).includes("SIL OPEN FONT LICENSE"));
});
