import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

test("render system gives bosses, every elite affix, and map objectives distinct silhouettes", async () => {
  const source = await readFile(new URL("src/systems/RenderSystem.ts", root), "utf8");

  assert.match(source, /drawMonsterGroundCue/);
  assert.match(source, /drawEliteAffix/);
  assert.match(source, /drawMapEvent/);
  for (const affix of ["shield", "haste", "split", "death_bomb"]) {
    assert.match(source, new RegExp(`case ["']${affix}["']`));
  }
  for (const kind of ["supply", "heal", "magnet", "haste", "xp_burst"]) {
    assert.match(source, new RegExp(`case ["']${kind}["']`));
  }
});

test("UI keeps chapter progression silent and routes only real boss phase transitions", async () => {
  const { uiModules, displayScene } = await import("./ui-runtime-helpers.mjs");
  const { UIScene, EventBus } = await uiModules;
  EventBus.removeAllListeners();
  const scene = new UIScene(); Object.assign(scene, displayScene().scene); scene.create();
  assert.equal(EventBus.listenerCount("level:chapter"), 0);
  assert.equal(EventBus.listenerCount("boss:phase"), 1);
  EventBus.emit("boss:phase", { text: "油弹扇射 · 留意空隙" }); assert.equal(scene.notification, undefined);
  EventBus.emit("boss:phase", { text: "炸锅二阶段 · 冲锋与增援" }); assert.equal(scene.notification.message, "炸锅二阶段 · 冲锋与增援");
  scene.events.emit("shutdown"); assert.equal(EventBus.listenerCount("boss:phase"), 0);
});
