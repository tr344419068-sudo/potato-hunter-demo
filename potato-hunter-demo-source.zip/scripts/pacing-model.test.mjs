import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { fileURLToPath } from "node:url";

const root = new URL("../", import.meta.url);

async function loadPacingModel() {
  try {
    return await import("../src/managers/PacingModel.ts");
  } catch {
    return {};
  }
}

let waveManagerModulePromise;

async function loadWaveManager() {
  waveManagerModulePromise ??= import("esbuild")
    .then(({ build }) => build({
      entryPoints: [fileURLToPath(new URL("../src/managers/WaveManager.ts", import.meta.url))],
      bundle: true,
      write: false,
      format: "esm",
      platform: "node",
      target: "node24",
      logLevel: "silent",
    }))
    .then(({ outputFiles }) => {
      const bundledSource = Buffer.from(outputFiles[0].contents).toString("base64");
      return import(`data:text/javascript;base64,${bundledSource}`);
    });
  return waveManagerModulePromise;
}

function getNormalizedRoster(wave) {
  const roster = wave.weights
    ? [...Object.entries(wave.weights)].map(([monsterId, weight]) => ({ monsterId, weight }))
    : wave.monsterMix?.length > 0
    ? wave.monsterMix
    : [{ monsterId: wave.monsterId, weight: 1 }];
  const weights = new Map();
  for (const entry of roster) {
    weights.set(entry.monsterId, (weights.get(entry.monsterId) ?? 0) + entry.weight);
  }
  const totalWeight = [...weights.values()].reduce((sum, weight) => sum + weight, 0);
  return new Map([...weights].map(([monsterId, weight]) => [monsterId, weight / totalWeight]));
}

function getWeightedAverageMonsterHp(wave, hpByMonsterId) {
  return [...getNormalizedRoster(wave)].reduce((sum, [monsterId, weight]) => {
    assert.ok(hpByMonsterId.has(monsterId), `unknown monster ${monsterId}`);
    return sum + hpByMonsterId.get(monsterId) * weight;
  }, 0);
}

function assertRosterClose(actualWave, expectedRoster, message) {
  const actualRoster = getNormalizedRoster(actualWave);
  const monsterIds = new Set([...actualRoster.keys(), ...expectedRoster.keys()]);
  for (const monsterId of monsterIds) {
    const actualWeight = actualRoster.get(monsterId) ?? 0;
    const expectedWeight = expectedRoster.get(monsterId) ?? 0;
    assert.ok(
      Math.abs(actualWeight - expectedWeight) < 1e-9,
      `${message}: ${monsterId} weight ${actualWeight} != ${expectedWeight}`,
    );
  }
}

function blendRosters(fromWave, toWave, easedProgress) {
  const fromRoster = getNormalizedRoster(fromWave);
  const toRoster = getNormalizedRoster(toWave);
  const monsterIds = new Set([...fromRoster.keys(), ...toRoster.keys()]);
  return new Map([...monsterIds].map((monsterId) => [
    monsterId,
    (fromRoster.get(monsterId) ?? 0) * (1 - easedProgress)
      + (toRoster.get(monsterId) ?? 0) * easedProgress,
  ]));
}

function baselineMixAt(config, elapsedMs, stage, smoothstep) {
  const seconds = elapsedMs / 1000;
  const index = Math.max(0, config.waves.findLastIndex((wave) => wave.startSeconds <= seconds));
  const checkpoint = config.waves[index];
  const base = blendRosters(config.waves[Math.max(0, index - 1)], checkpoint,
    smoothstep(Math.max(0, Math.min(1, (seconds - checkpoint.startSeconds) / 6))));
  if (stage === "desert" && seconds > 10) {
    const specialistWeight = smoothstep(Math.min(1, (seconds - 10) / 8)) * .22;
    const scorpionShare = smoothstep(Math.min(1, Math.max(0, (seconds - 55) / 15)));
    for (const [id, weight] of base) base.set(id, weight * (1 - specialistWeight));
    base.set("desert_cactus", specialistWeight * (1 - scorpionShare));
    base.set("desert_scorpion", specialistWeight * scorpionShare);
  }
  return { monsterMix: [...base].map(([monsterId, weight]) => ({ monsterId, weight })) };
}

test("pacing checkpoint selection advances at the first-minute pressure beats", async () => {
  const model = await loadPacingModel();
  assert.equal(typeof model.getPacingCheckpoint, "function");

  const checkpoints = [0, 10, 24, 40, 60, 105, 165].map((seconds) =>
    model.getPacingCheckpoint(seconds * 1000).startSeconds,
  );
  assert.deepEqual(checkpoints, [0, 10, 24, 40, 60, 105, 165]);
  assert.equal(model.getPacingCheckpoint(59_999).startSeconds, 40);
});

test("configured wave pressure increases through the opening checkpoints", async () => {
  const config = JSON.parse(await readFile(new URL("src/configs/waves.json", root), "utf8"));
  const opening = config.waves.slice(0, 5);

  assert.deepEqual(opening.map((wave) => wave.startSeconds), [0, 10, 24, 40, 60]);
  assert.deepEqual(config.waves.map((wave) => wave.spawnCount), [3, 3, 3, 3, 3, 3, 3]);
  assert.deepEqual(config.waves.map((wave) => wave.spawnIntervalMs), [1350, 1230, 820, 650, 460, 354, 270]);
  assert.deepEqual(config.waves.map((wave) => wave.maxAlive), [24, 32, 44, 58, 76, 108, 132]);
  assert.ok(opening.every((wave, index) => index === 0 || wave.maxAlive > opening[index - 1].maxAlive));
  assert.ok(opening.every((wave, index) => index === 0 || wave.spawnIntervalMs <= opening[index - 1].spawnIntervalMs));
});

test("configured wave health throughput stays within the pacing budget", async () => {
  const [waveConfig, monsterConfig] = await Promise.all([
    readFile(new URL("src/configs/waves.json", root), "utf8").then(JSON.parse),
    readFile(new URL("src/configs/monsters.json", root), "utf8").then(JSON.parse),
  ]);
  const hpByMonsterId = new Map(monsterConfig.monsters.map((monster) => [monster.id, monster.hp]));
  const healthThroughputPerSecond = (wave) => {
    const roster = wave.monsterMix ?? [{ monsterId: wave.monsterId, weight: 1 }];
    const totalWeight = roster.reduce((sum, entry) => sum + entry.weight, 0);
    const weightedAverageHp = roster.reduce((sum, entry) => {
      assert.ok(hpByMonsterId.has(entry.monsterId), `unknown monster ${entry.monsterId}`);
      return sum + hpByMonsterId.get(entry.monsterId) * entry.weight;
    }, 0) / totalWeight;
    return (wave.spawnCount * 1000 * weightedAverageHp) / wave.spawnIntervalMs;
  };
  const throughputTargets = waveConfig.waves.map(healthThroughputPerSecond);
  const firstMinuteTargets = waveConfig.waves
    .filter((wave) => wave.startSeconds <= 60)
    .map(healthThroughputPerSecond);
  const sixtySecondWave = waveConfig.waves.find((wave) => wave.startSeconds === 60);

  assert.ok(throughputTargets[0] >= 45 && throughputTargets[0] <= 65);
  assert.ok(firstMinuteTargets.every((target, index) => index === 0 || target >= firstMinuteTargets[index - 1]));
  assert.ok(throughputTargets.every((target, index) => index === 0 || target / throughputTargets[index - 1] < 1.95));
  assert.ok(healthThroughputPerSecond(sixtySecondWave) < 450);
});

test("every authored wave has ordered time and positive pressure inputs", async () => {
  const config = JSON.parse(await readFile(new URL("src/configs/waves.json", root), "utf8"));

  for (const [index, wave] of config.waves.entries()) {
    assert.ok(index === 0 || wave.startSeconds > config.waves[index - 1].startSeconds);
    assert.ok(wave.spawnIntervalMs > 0);
    assert.ok(wave.spawnCount > 0);
    assert.ok(wave.maxAlive > 0);
  }
});

test("wave pressure interpolates total pressure and derives the active roster spawn rate", async () => {
  const model = await loadPacingModel();
  const targets = [
    { startSeconds: 0, spawnIntervalMs: 1000, spawnCount: 1, maxAlive: 10, pressurePerSpawn: 10 },
    { startSeconds: 10, spawnIntervalMs: 1000, spawnCount: 2, maxAlive: 20, pressurePerSpawn: 20 },
  ];

  assert.deepEqual(model.getWavePressure(targets, 5000), {
    spawnRatePerSecond: 2.5,
    pressurePerSecond: 25,
    maxAlive: 15,
  });
  assert.deepEqual(model.getWavePressure(targets, 10_000), {
    spawnRatePerSecond: 2,
    pressurePerSecond: 40,
    maxAlive: 20,
  });
});

test("wave pressure rejects non-positive per-spawn pressure", async () => {
  const model = await loadPacingModel();
  const target = { startSeconds: 0, spawnIntervalMs: 1000, spawnCount: 1, maxAlive: 10 };

  for (const pressurePerSpawn of [0, -1]) {
    assert.throws(
      () => model.getWavePressure([{ ...target, pressurePerSpawn }], 0),
      /pressurePerSpawn must be a positive finite number/,
    );
  }
});

test("wave pressure uses smoothstep at quarter points between configured pressure targets", async () => {
  const [config, model] = await Promise.all([
    readFile(new URL("src/configs/waves.json", root), "utf8").then(JSON.parse),
    loadPacingModel(),
  ]);
  assert.equal(typeof model.getWavePressure, "function");

  const [first, second, ...remaining] = config.waves;
  const firstRate = (first.spawnCount * 1000) / first.spawnIntervalMs;
  const secondRate = (second.spawnCount * 1000) / second.spawnIntervalMs;
  const rateDelta = secondRate - firstRate;
  const aliveDelta = second.maxAlive - first.maxAlive;
  const samples = [
    { progress: 0.25, easedProgress: 0.15625 },
    { progress: 0.5, easedProgress: 0.5 },
    { progress: 0.75, easedProgress: 0.84375 },
  ];

  for (const { progress, easedProgress } of samples) {
    assert.equal(model.smoothstep(progress), easedProgress);
    const elapsedMs = (first.startSeconds + (second.startSeconds - first.startSeconds) * progress) * 1000;
    const pressure = model.getWavePressure(config.waves, elapsedMs);
    assert.ok(Math.abs(pressure.spawnRatePerSecond - (firstRate + rateDelta * easedProgress)) < 1e-12);
    assert.ok(Math.abs(pressure.pressurePerSecond - (firstRate + rateDelta * easedProgress)) < 1e-12);
    assert.equal(pressure.maxAlive, Math.round(first.maxAlive + aliveDelta * easedProgress));
  }

  assert.deepEqual(model.getWavePressure(config.waves, -1), {
    spawnRatePerSecond: firstRate,
    pressurePerSecond: firstRate,
    maxAlive: first.maxAlive,
  });

  const last = remaining.at(-1);
  assert.deepEqual(model.getWavePressure(config.waves, (last.startSeconds + 60) * 1000), {
    spawnRatePerSecond: (last.spawnCount * 1000) / last.spawnIntervalMs,
    pressurePerSecond: (last.spawnCount * 1000) / last.spawnIntervalMs,
    maxAlive: last.maxAlive,
  });
});

test("wave pressure stays monotonic and continuous at every checkpoint", async () => {
  const [config, model] = await Promise.all([
    readFile(new URL("src/configs/waves.json", root), "utf8").then(JSON.parse),
    loadPacingModel(),
  ]);

  let previous = model.getWavePressure(config.waves, 0);
  const lastCheckpointSeconds = config.waves.at(-1).startSeconds;
  for (let seconds = 1; seconds <= lastCheckpointSeconds + 10; seconds += 1) {
    const pressure = model.getWavePressure(config.waves, seconds * 1000);
    assert.ok(pressure.spawnRatePerSecond >= previous.spawnRatePerSecond, `spawn rate fell at ${seconds}s`);
    assert.ok(pressure.maxAlive >= previous.maxAlive, `max alive fell at ${seconds}s`);
    assert.ok(Number.isInteger(pressure.maxAlive), `max alive was fractional at ${seconds}s`);
    previous = pressure;
  }

  for (const checkpoint of config.waves) {
    const samples = [-1, 0, 1].map((offsetMs) =>
      model.getWavePressure(config.waves, checkpoint.startSeconds * 1000 + offsetMs),
    );
    const rates = samples.map((sample) => sample.spawnRatePerSecond);
    const alive = samples.map((sample) => sample.maxAlive);
    assert.ok(Math.max(...rates) - Math.min(...rates) < 0.02, `spawn rate jumped at ${checkpoint.startSeconds}s`);
    assert.ok(Math.max(...alive) - Math.min(...alive) <= 1, `max alive jumped at ${checkpoint.startSeconds}s`);
  }
});

test("stage rosters preserve batch size, live caps, and the original effective HP and count budgets", async () => {
  const [config, monsterConfig, model, { WaveManager }] = await Promise.all([
    readFile(new URL("src/configs/waves.json", root), "utf8").then(JSON.parse),
    readFile(new URL("src/configs/monsters.json", root), "utf8").then(JSON.parse),
    loadPacingModel(),
    loadWaveManager(),
  ]);
  const hpByMonsterId = new Map(monsterConfig.monsters.map((monster) => [monster.id, monster.hp]));
  const effectiveHpByMonsterId = new Map(monsterConfig.monsters.map((monster) => [monster.id, monster.hp + (monster.shieldHp ?? 0)]));
  const pressureTargets = config.waves.map((wave) => {
    return { ...wave, pressurePerSpawn: getWeightedAverageMonsterHp(wave, hpByMonsterId) };
  });

  for (const stage of ["meadow", "desert"]) {
    const manager = new WaveManager(stage);
    for (let elapsedMs = 0; elapsedMs < 180_000; elapsedMs += 250) {
      const expectedWave = config.waves.findLast((wave) => wave.startSeconds * 1000 <= elapsedMs);
      const wave = manager.getCurrentWave(elapsedMs);
      const pressure = model.getWavePressure(pressureTargets, elapsedMs);
      const spawnRatePerSecond = (wave.spawnCount * 1000) / wave.spawnIntervalMs;
      const baselineMix = baselineMixAt(config, elapsedMs, stage, model.smoothstep);
      const baselineRate = pressure.pressurePerSecond / getWeightedAverageMonsterHp(baselineMix, hpByMonsterId);
      const effectiveHpBudget = baselineRate * getWeightedAverageMonsterHp(baselineMix, effectiveHpByMonsterId);
      const effectiveHpRate = spawnRatePerSecond * getWeightedAverageMonsterHp(wave, effectiveHpByMonsterId);

      assert.equal(wave.monsterId, expectedWave.monsterId);
      assert.equal(wave.spawnCount, expectedWave.spawnCount);
      assert.equal(wave.maxAlive, pressure.maxAlive);
      assert.ok(spawnRatePerSecond <= baselineRate + 1e-9, `${stage} exceeded count budget at ${elapsedMs}ms`);
      assert.ok(effectiveHpRate <= effectiveHpBudget + 1e-9, `${stage} exceeded effective HP budget at ${elapsedMs}ms`);
      assert.ok(effectiveHpRate >= effectiveHpBudget * .9, `${stage} lost too much effective HP pressure at ${elapsedMs}ms`);
    }
  }
});

test("wave manager keeps runtime rate, interval, and health pressure continuous across roster transitions", async () => {
  const [waveConfig, monsterConfig, { WaveManager }] = await Promise.all([
    readFile(new URL("src/configs/waves.json", root), "utf8").then(JSON.parse),
    readFile(new URL("src/configs/monsters.json", root), "utf8").then(JSON.parse),
    loadWaveManager(),
  ]);
  const effectiveHpByMonsterId = new Map(monsterConfig.monsters.map((monster) => [monster.id, monster.hp + (monster.shieldHp ?? 0)]));
  const getRuntimePressure = (manager, elapsedMs) => {
    const wave = manager.getCurrentWave(elapsedMs);
    const enemyRatePerSecond = (wave.spawnCount * 1000) / wave.spawnIntervalMs;
    return {
      enemyRatePerSecond,
      batchIntervalMs: wave.spawnIntervalMs,
      healthPressurePerSecond: enemyRatePerSecond * getWeightedAverageMonsterHp(wave, effectiveHpByMonsterId),
    };
  };
  const continuityViolations = [];

  for (const [stage, rosters] of Object.entries(waveConfig.rosters)) {
    const manager = new WaveManager(stage);
    const checkpoints = new Set([...waveConfig.waves, ...rosters].flatMap(({ startSeconds }) => [startSeconds, startSeconds + 6]));
    for (const checkpointSeconds of checkpoints) {
      const samples = [-1, 0, 1].map((offsetMs) => getRuntimePressure(manager, checkpointSeconds * 1000 + offsetMs));
      for (const metric of ["enemyRatePerSecond", "batchIntervalMs", "healthPressurePerSecond"]) {
        const values = samples.map((sample) => sample[metric]);
        const relativeSpread = (Math.max(...values) - Math.min(...values)) / Math.max(...values);
        if (relativeSpread >= 0.01) continuityViolations.push({ stage, checkpointSeconds, metric, relativeSpread });
      }
    }
  }

  assert.deepEqual(continuityViolations, [], `runtime pressure jumped at checkpoints: ${JSON.stringify(continuityViolations)}`);
});

test("wave manager smoothsteps each roster from the previous target over six seconds", async () => {
  const [waveConfig, { WaveManager }] = await Promise.all([
    readFile(new URL("src/configs/waves.json", root), "utf8").then(JSON.parse),
    loadWaveManager(),
  ]);
  for (const [stage, roster] of Object.entries(waveConfig.rosters)) {
    const manager = new WaveManager(stage);
    assert.equal(roster[0].startSeconds, 0);
    for (const [index, target] of roster.entries()) {
      const fromTarget = index === 0 ? target : roster[index - 1];
      assert.ok(index === 0 || target.startSeconds - fromTarget.startSeconds >= 6, "teaching transitions must not overlap");
      const atCheckpoint = manager.getCurrentWave(target.startSeconds * 1000);
      const atMidpoint = manager.getCurrentWave((target.startSeconds + 3) * 1000);
      const afterTransition = manager.getCurrentWave((target.startSeconds + 6) * 1000);

      assert.ok(Math.abs(atCheckpoint.monsterMix.reduce((sum, entry) => sum + entry.weight, 0) - 1) < 1e-12);
      assertRosterClose(atCheckpoint, getNormalizedRoster(fromTarget), `${stage} checkpoint ${target.startSeconds}s`);
      assertRosterClose(atMidpoint, blendRosters(fromTarget, target, 0.5), `${stage} midpoint ${target.startSeconds + 3}s`);
      assertRosterClose(afterTransition, getNormalizedRoster(target), `${stage} transition end ${target.startSeconds + 6}s`);
    }
  }
});

test("first minute offers three readable battlefield objectives before the boss", async () => {
  const config = JSON.parse(await readFile(new URL("src/configs/mapEvents.json", root), "utf8"));
  const opening = config.events
    .filter((event) => event.spawnAfterSeconds < 60)
    .sort((left, right) => left.spawnAfterSeconds - right.spawnAfterSeconds);

  assert.deepEqual(opening.map((event) => event.kind), ["magnet", "supply", "heal"]);
  assert.deepEqual(opening.map((event) => event.spawnAfterSeconds), [18, 30, 43]);
  assert.ok(opening.every((event) => event.lifetimeMs >= 12000));
});

test("opening runtime health pressure stays lower than the former aggressive curve", async () => {
  const [waveConfig, monsterConfig, model, { WaveManager }] = await Promise.all([
    readFile(new URL("src/configs/waves.json", root), "utf8").then(JSON.parse),
    readFile(new URL("src/configs/monsters.json", root), "utf8").then(JSON.parse),
    loadPacingModel(),
    loadWaveManager(),
  ]);
  const oldIntervals = [900, 820, 570, 525, 390, 354, 270];
  const hpByMonsterId = new Map(monsterConfig.monsters.map((monster) => [monster.id, monster.hp]));
  const baselineTargets = waveConfig.waves.map((wave, index) => ({
    ...wave,
    spawnIntervalMs: oldIntervals[index],
    pressurePerSpawn: getWeightedAverageMonsterHp(wave, hpByMonsterId),
  }));
  const manager = new WaveManager();
  for (let second = 0; second <= 30; second += 1) {
    const runtimeWave = manager.getCurrentWave(second * 1000);
    const runtimePressure = runtimeWave.spawnCount * 1000 / runtimeWave.spawnIntervalMs
      * getWeightedAverageMonsterHp(runtimeWave, hpByMonsterId);
    const oldPressure = model.getWavePressure(baselineTargets, second * 1000).pressurePerSecond;
    assert.ok(runtimePressure / oldPressure <= 0.8, `opening reduction too small at ${second}s`);
  }
  assert.equal(manager.getCurrentWave(0).maxAlive, 24);
  assert.ok(manager.getCurrentWave(0).spawnCount * 1000 / manager.getCurrentWave(0).spawnIntervalMs <= 2.25);
  assert.equal(manager.getCurrentWave(60_000).maxAlive, 76);
});

test("boss cadence stays fixed while the first upgrades arrive at a gentler XP cost", async () => {
  const [config, model] = await Promise.all([
    readFile(new URL("src/configs/waves.json", root), "utf8").then(JSON.parse),
    loadPacingModel(),
  ]);

  assert.equal(config.bossEverySeconds, 60);
  const costs = [model.INITIAL_EXPERIENCE_REQUIREMENT];
  for (let level = 2; level <= 5; level += 1) {
    costs.push(model.getNextExperienceRequirement(costs.at(-1), level));
  }
  assert.deepEqual(costs, [12, 28, 50, 78, 112]);
  const opening = config.waves[0];
  const firstThreeUpgradeXp = costs.slice(0, 3).reduce((sum, value) => sum + value, 0);
  const adjustedXpSupplyBudget = firstThreeUpgradeXp / (opening.spawnCount * 1000 / opening.spawnIntervalMs);
  const originalXpSupplyBudget = (14 + 73 + 131) / (3 * 1000 / 900);
  assert.ok(adjustedXpSupplyBudget < originalXpSupplyBudget * 0.7,
    "fewer monsters must not make early upgrade resource pacing slower");
});

test("XP curve grows smoothly through the early-to-late handover without a new cost cliff", async () => {
  const model = await loadPacingModel();
  let previous = model.INITIAL_EXPERIENCE_REQUIREMENT;
  for (let level = 2; level <= 40; level += 1) {
    const requirement = model.getNextExperienceRequirement(previous, level);
    assert.ok(Number.isInteger(requirement) && requirement > previous);
    assert.ok(requirement / previous <= (level === 2 ? 2.4 : 1.8), `XP cost cliff at level ${level}`);
    if (level >= 12) {
      assert.ok(requirement >= 14 + 18 * Math.pow(level, 1.7));
      assert.ok(requirement >= previous + 6 + level * 14);
      assert.equal(requirement, Math.ceil(Math.max(14 + 18 * Math.pow(level, 1.7), previous + 6 + level * 14)));
    }
    previous = requirement;
  }
});
