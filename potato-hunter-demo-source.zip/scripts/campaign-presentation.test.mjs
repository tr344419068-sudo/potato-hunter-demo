import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import test from 'node:test';
import {build} from 'esbuild';

const api=build({stdin:{contents:'export {CampaignPresentation} from "./src/campaign/CampaignPresentation.ts";',resolveDir:process.cwd(),loader:'ts'},bundle:true,platform:'node',format:'esm',write:false}).then(r=>import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));
const prefs={musicVolume:.5,sfxVolume:.7,reducedEffects:false};
async function fixture(){
 const {CampaignPresentation}=await api,events=new EventEmitter(),played=[],gains=[];
 const context={state:'suspended',currentTime:1,resume:async()=>{context.state='running'},close:async()=>{context.state='closed'}};
 const sink={load:async()=>true,playSfx(c){played.push(c.asset.id);return {stop(){}}},playMusic(a){played.push(a.id);return {stop(){}}},setSfxGain(v){gains.push(v)},setMusicGain(){},destroy(){}};
 const presentation=new CampaignPresentation(events,prefs,{createContext:()=>context,sink});
 return {presentation,events,played,gains,context};
}
test('real audio requires explicit gesture, follows campaign boss and pause, and chooser retains upgrade cue',async()=>{
 const {presentation:p,events:e,played,context}=await fixture();e.emit('campaign:ready',{atHome:false});assert.equal(context.state,'suspended');assert.equal(p.getSnapshot().state,'combat');
 await p.unlockAudio();await new Promise(r=>setImmediate(r));assert.ok(played.includes('music-combat'));
 e.emit('campaign:status',{bossActive:true,paused:false,choosing:false});assert.equal(p.getSnapshot().state,'boss');
 e.emit('campaign:paused',true);assert.equal(p.getSnapshot().state,'paused');e.emit('campaign:paused',false);assert.equal(p.getSnapshot().state,'boss');
 e.emit('level:choices',{});assert.equal(p.getSnapshot().state,'paused');assert.equal(played.at(-1),'upgrade');
 e.emit('campaign:status',{bossActive:false,paused:false,choosing:false});assert.equal(p.getSnapshot().state,'combat');
 e.emit('game:over',{campaign:true,outcome:'victory'});e.emit('campaign:status',{bossActive:false,paused:false,choosing:false});assert.equal(p.getSnapshot().state,'victory');
 e.emit('campaign:ready',{atHome:true});assert.equal(p.getSnapshot().state,'home');p.destroy();
});
test('saved preferences reach actual mixer and visual event consumer after restart, then cleanup releases listeners',async()=>{
 const {presentation:p,events:e,gains,context}=await fixture(),visual=[];e.on('presentation:preferences',v=>visual.push(v));
 p.setPreferences({...prefs,sfxVolume:.2,reducedEffects:true});assert.equal(visual.at(-1).reducedEffects,true);
 await p.unlockAudio();await new Promise(r=>setImmediate(r));assert.equal(gains.at(-1),.2);
 e.emit('campaign:ready',{atHome:false});assert.equal(visual.at(-1).reducedEffects,true);p.destroy();p.destroy();
 assert.equal(context.state,'closed');assert.equal(e.listenerCount('campaign:ready'),0);assert.equal(e.listenerCount('weapon:fired'),0);
});
