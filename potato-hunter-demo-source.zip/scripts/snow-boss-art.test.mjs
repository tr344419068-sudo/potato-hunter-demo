import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import { createCanvas, loadImage } from '@napi-rs/canvas';

test('snow Boss uses the same new RemBg sprite family for neutral and all eight combat frames', async () => {
  const manifest = JSON.parse(await readFile(new URL('../src/configs/assets.json', import.meta.url)));
  const idle = manifest.boss_snow_hammer;
  const sheet = manifest.boss_snow_hammer_swing;
  for (const [asset, filename] of [[idle, 'idle'], [sheet, 'swing']]) {
    assert.equal(asset.path, `assets/snow-v1/shengong-boss/${filename}.webp`);
    assert.equal(asset.stage, 'snow');
  }
  assert.deepEqual(idle.pivot, sheet.pivot);
  assert.deepEqual(idle.footPoint, sheet.footPoint);
  assert.equal(idle.displaySize, sheet.displaySize);
  assert.deepEqual([sheet.frameWidth, sheet.frameHeight, sheet.frameCount], [idle.width, idle.height, 8]);
  const signatures = new Set();
  for (const asset of [idle, sheet]) {
    const image = await loadImage(await readFile(new URL(`../public/${asset.path}`, import.meta.url)));
    assert.deepEqual([image.width, image.height], [asset.width, asset.height]);
    const { width, height } = idle;
    const ctx = createCanvas(width, height).getContext('2d');
    for (let frame = 0; frame < (asset.frameCount ?? 1); frame++) {
      ctx.clearRect(0, 0, width, height);
      ctx.drawImage(image, frame % 4 * width, Math.floor(frame / 4) * height, width, height, 0, 0, width, height);
      const { data } = ctx.getImageData(0, 0, width, height);
      let opaque = 0;
      for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
        const alpha = data[(y * width + x) * 4 + 3];
        if (!x || !y || x === width - 1 || y === height - 1) assert.equal(alpha, 0, `frame ${frame} is cropped`);
        if (alpha >= 128) opaque++;
      }
      assert.ok(opaque > width * height * .12, `frame ${frame} has no readable body`);
      if (asset === sheet) signatures.add(createHash('sha256').update(data).digest('hex'));
    }
  }
  assert.ok(signatures.size >= 7, 'the attack and charge poses cannot be copies of the neutral sprite');
});
