import assert from "node:assert/strict";
import test from "node:test";
import { uiModules, displayScene } from "./ui-runtime-helpers.mjs";
import { parseHTML } from 'linkedom';

async function fixture() {
  const api = await uiModules; api.EventBus.removeAllListeners();
  const gameDisplay = displayScene(); const scene = new api.GameScene(); Object.assign(scene, gameDisplay.scene);
  scene.playerId = api.createPlayer(scene.world, 0, 0, 210, 100, 100);
  const input = new api.InputSystem(scene, scene.playerId); scene.systems = [input];
  api.EventBus.on("skill:selected", scene.handleSkillSelected, scene); api.EventBus.on("upgrade:cancel", scene.cancelUpgradeChoices, scene);
  let choices; api.EventBus.once("level:choices", payload => choices = payload); scene.requestSkillChoice([]);
  const uiDisplay = displayScene(); const popup = new api.UpgradePopup(uiDisplay.scene, choices);
  return { ...api, scene, input, popup, uiDisplay, pointer: scene.input.activePointer, velocity: scene.world.components.velocities.get(scene.playerId) };
}

for (const dismissal of ["selection", "cancel"]) {
  test(`actual ${dismissal} dismisses immediately without carrying its held pointer into movement`, async () => {
    const { scene, input, popup, uiDisplay, pointer, velocity, EventBus } = await fixture();
    Object.assign(pointer, { id: 7, isDown: true, x: 400, y: 350 });
    if (dismissal === "selection") popup.cards[0].hitZone.emit("pointerdown", pointer);
    else uiDisplay.objects.find(object => object.kind === "zone" && object.width === 82).emit("pointerdown", pointer);
    assert.equal(scene.choosingSkill, false); assert.equal(popup.root.destroyed, true);
    assert.equal(scene.pendingUpgrades, dismissal === "selection" ? 0 : 1);
    scene.update(0, 16); assert.equal(velocity.x, 0); assert.equal(velocity.y, 0);
    scene.input.keyboard.keyStates.d.isDown = true; scene.update(0, 16);
    assert.ok(velocity.x > 0); assert.equal(velocity.y, 0, "pointer block also blocked keyboard movement");
    scene.input.keyboard.keyStates.d.isDown = false; scene.update(0, 16); assert.equal(velocity.x, 0); assert.equal(velocity.y, 0);
    pointer.isDown = false; scene.input.emit("pointerup", pointer);
    pointer.isDown = true; scene.update(0, 16); assert.ok(velocity.x > 0 && velocity.y > 0, "new press after release stayed blocked");
    scene.events.emit("shutdown");
    assert.equal(EventBus.listenerCount("player:pointer-consume"), 0);
    assert.equal(scene.input.listenerCount("pointerup"), 0); assert.equal(scene.input.listenerCount("pointerupoutside"), 0);
  });
}

test("a different touch remains usable while only the dismissal gesture is consumed", async () => {
  const { scene, popup, pointer, velocity } = await fixture();
  Object.assign(pointer, { id: 1, isDown: true, x: 400, y: 350 }); popup.cards[0].hitZone.emit("pointerdown", pointer);
  scene.input.activePointer = { id: 2, isDown: true, x: -200, y: 0 }; scene.update(0, 16);
  assert.ok(velocity.x < 0); assert.equal(velocity.y, 0); scene.events.emit("shutdown");
});
test('DOM pause owns underlying chooser keys and pointer selection until explicit resume',async()=>{
 const f=await fixture(),{document,window}=parseHTML('<html><body></body></html>');
 const shell=new f.CampaignShell(f.EventBus,new f.ProgressionStore({getItem:()=>null,setItem(){}}),{document});
 f.EventBus.on('campaign:pause',f.scene.setCampaignPaused,f.scene);f.EventBus.emit('campaign:ready',{atHome:false});
 document.querySelector('[data-action="pause"]').click();assert.equal(f.scene.paused,true);
 f.uiDisplay.scene.input.keyboard.emit('keydown',{key:'1',repeat:false,preventDefault(){}});f.popup.cards[0].hitZone.emit('pointerdown',{isDown:false});
 assert.equal(f.scene.pendingUpgrades,1);assert.equal(f.popup.destroyed,false);
 f.uiDisplay.scene.input.keyboard.emit('keydown',{key:'Escape',repeat:false,preventDefault(){}});assert.equal(f.popup.destroyed,false);
 const escape=new window.Event('keydown',{bubbles:true,cancelable:true});escape.key='Escape';escape.repeat=false;document.dispatchEvent(escape);assert.equal(f.scene.paused,false);assert.equal(f.scene.pendingUpgrades,1);
 const repeat=new window.Event('keydown',{bubbles:true,cancelable:true});repeat.key='Escape';repeat.repeat=true;document.dispatchEvent(repeat);assert.equal(f.scene.paused,false);
 f.uiDisplay.scene.input.keyboard.emit('keydown',{key:'1',repeat:false,preventDefault(){}});assert.equal(f.scene.pendingUpgrades,0);assert.equal(f.popup.destroyed,true);shell.destroy();
 assert.equal(f.EventBus.listenerCount('campaign:paused'),0);
});
