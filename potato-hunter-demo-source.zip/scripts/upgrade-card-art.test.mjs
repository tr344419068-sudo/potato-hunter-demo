import assert from "node:assert/strict";
import test from "node:test";
import { uiModules, displayScene } from "./ui-runtime-helpers.mjs";

test("registered rarity artwork frames the graded opaque surface behind readable content", async () => {
  const { UpgradePopup, ConfigManager, UI_ASSET_IDS } = await uiModules;
  for (const [rarity, category] of [["common", "passive"], ["rare", "passive"], ["epic", "passive"], ["epic", "evolution"]]) {
    const choice = { ...ConfigManager.skills[0], rarity, category };
    const { scene } = displayScene();
    const popup = new UpgradePopup(scene, { choices: [choice], hints: [], levels: {} });
    const card = popup.cards[0];
    const frame = card.container.children.find(child => child.texture === `asset:${UI_ASSET_IDS.cards[category === "evolution" ? "evolution" : rarity]}`);
    assert.ok(frame, `${rarity}/${category} does not use its registered dimensional bitmap`);
    assert.equal(frame.kind, "image");
    assert.ok(Math.abs(frame.width / frame.height - 320 / 420) < 0.001, "portrait art is distorted");
    assert.ok(card.cardSurface.calls.some(call => call[0] === "fillStyle" && call[2] === 1), "frame center must stay opaque");
    assert.ok(card.cardSurface.calls.some(call => call[0] === "fillGradientStyle"), "icon material is still flat");
    assert.ok(card.cardSurface.calls.some(call => call[0] === "fillStyle" && call[1] === 0xf7f1e3), "readable ivory information plate is missing");
    assert.ok(card.container.children.indexOf(card.cardSurface) < card.container.children.indexOf(frame));
    assert.ok(card.container.children.filter(child => child.kind === "text").every(child => card.container.children.indexOf(frame) < card.container.children.indexOf(child)));
    popup.destroy();
  }
});

test("compact artwork keeps corner and gem proportions rather than flattening portrait art", async () => {
  const { UpgradePopup, ConfigManager } = await uiModules;
  for (const [width, height] of [[320, 480], [390, 844], [722, 794]]) {
    const { scene } = displayScene(width, height);
    const popup = new UpgradePopup(scene, { choices: ConfigManager.skills.slice(0, 3), hints: [], levels: {} });
    const card = popup.cards[0];
    const frame = card.container.children.find(child => child.texture?.startsWith("asset:ui_v2_card_"));
    assert.ok(frame, "compact cards discarded the bitmap artwork");
    assert.equal(frame.kind, "nineslice", "portrait art must be adapted without stretching its gems");
    assert.equal(frame.scaleX, frame.scaleY, "frame corners are nonuniformly scaled");
    assert.equal(frame.rotation, Math.PI / 2);
    assert.ok(Math.abs(frame.height * frame.scaleY - card.width) < 0.001);
    assert.ok(Math.abs(frame.width * frame.scaleX - card.height) < 0.001);
    assert.ok(frame.slices.every(slice => slice >= 60));
    popup.destroy();
  }
});

test("unavailable textures keep opaque material and readable text without missing images", async () => {
  const { UpgradePopup, ConfigManager } = await uiModules;
  const { scene } = displayScene(390, 844, false);
  const popup = new UpgradePopup(scene, { choices: ConfigManager.skills.slice(0, 3), hints: [], levels: {} });
  for (const card of popup.cards) {
    assert.equal(card.container.children.some(child => ["image", "nineslice"].includes(child.kind)), false);
    assert.ok(card.cardSurface.calls.some(call => call[0] === "fillStyle" && call[2] === 1));
    assert.ok(card.cardSurface.calls.some(call => call[0] === "fillStyle" && call[1] === 0xf7f1e3));
    assert.equal(card.icon.kind, "circle");
    assert.equal(card.container.children.filter(child => child.kind === "text").length, 4);
  }
});

test("compact Canvas cards use a visible Graphics frame while retaining images and readable content", async () => {
  const { UpgradePopup, ConfigManager, Phaser } = await uiModules;
  for (const [width, height] of [[320, 480], [722, 794]]) {
    const { scene } = displayScene(width, height);
    scene.game = { renderer: { type: Phaser.CANVAS } };
    const popup = new UpgradePopup(scene, { choices: ConfigManager.skills.slice(0, 3), hints: [], levels: {} });
    for (const card of popup.cards) {
      const frame = card.container.children[1];
      assert.equal(frame.kind, "graphics", "Canvas must not receive an invisible NineSlice frame");
      assert.ok(frame.calls.some(call => call[0] === "strokeRoundedRect"), "Canvas fallback has no visible frame border");
      assert.equal(card.container.children.some(child => child.kind === "nineslice"), false);
      assert.equal(card.icon.kind, "image");
      assert.ok(card.cardSurface.calls.some(call => call[0] === "fillStyle" && call[1] === 0xf7f1e3 && call[2] === 1));
      assert.equal(card.container.children.filter(child => child.kind === "text").length, 4);
    }
    popup.destroy();
  }
});

test("explicit WebGL and unknown renderer compact cards keep their accepted bitmap composition", async () => {
  const { UpgradePopup, ConfigManager, Phaser } = await uiModules;
  for (const game of [undefined, {}, { renderer: {} }, { renderer: { type: Phaser.WEBGL } }]) {
    const { scene } = displayScene(390, 844);
    scene.game = game;
    const popup = new UpgradePopup(scene, { choices: ConfigManager.skills.slice(0, 3), hints: [], levels: {} });
    for (const card of popup.cards) assert.equal(card.container.children[1].kind, "nineslice");
    popup.destroy();
  }
});

test("desktop Canvas cards retain the supported portrait bitmap frame", async () => {
  const { UpgradePopup, ConfigManager, Phaser } = await uiModules;
  const { scene } = displayScene();
  scene.game = { renderer: { type: Phaser.CANVAS } };
  const popup = new UpgradePopup(scene, { choices: ConfigManager.skills.slice(0, 3), hints: [], levels: {} });
  for (const card of popup.cards) {
    assert.equal(card.container.children[1].kind, "image");
    assert.ok(card.container.children[1].texture.startsWith("asset:ui_v2_card_"));
  }
  popup.destroy();
});
