import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';
import { readFile } from 'node:fs/promises';
import { createCanvas, loadImage } from '@napi-rs/canvas';

const root = fileURLToPath(new URL('../', import.meta.url));
const modules = build({ stdin: { contents: `
export { PalmStrikeSystem, getPalmProfile } from './src/systems/PalmStrikeSystem.ts';
export { SkillManager } from './src/managers/SkillManager.ts';
export { ConfigManager } from './src/managers/ConfigManager.ts';
export { EventBus } from './src/managers/EventBus.ts';
export { World } from './src/entities/World.ts';
export { createPlayer, createMonster } from './src/entities/factories.ts';
export { getSkillUpgradeBenefit } from './src/ui/UIModel.ts';
export { mapAudioEvent, AUDIO_EVENTS } from './src/audio/CombatAudioModel.ts';
`, resolveDir: root, loader: 'ts' }, bundle: true, platform: 'node', format: 'esm', write: false,
plugins: [{ name: 'phaser-stub', setup(ctx) {
  ctx.onResolve({ filter: /^phaser$/ }, () => ({ path: 'phaser', namespace: 'stub' }));
  ctx.onLoad({ filter: /.*/, namespace: 'stub' }, () => ({ contents: `import EventEmitter from 'eventemitter3'; export default {Events:{EventEmitter},Display:{Color:{HexStringToColor:v=>({color:parseInt(v.slice(1),16)})}},Utils:{Array:{Shuffle:v=>v}},Math:{Clamp:(v,a,b)=>Math.min(b,Math.max(a,v)),Between:(a,b)=>a,FloatBetween:(a,b)=>a}};`, resolveDir: root }));
}}] }).then(o => import(`data:text/javascript;base64,${Buffer.from(o.outputFiles[0].text).toString('base64')}`));

async function fixture(rank = 1) {
  const api = await modules; api.EventBus.removeAllListeners();
  const world = new api.World(), playerId = api.createPlayer(world, 0, 0, 220, 100, 145);
  const skills = new api.SkillManager({ random: () => 0.37, enforceSlots: true });
  for (let i=0; i<rank; i++) skills.levelUp('potato_palm');
  const runtime = { world, playerId, skillManager: skills, stats: { elapsedMs: 0, kills: 0, bossKills: 0, gold: 0 }, endRun() {} };
  const events = []; api.EventBus.on('palm:telegraph', e => events.push(['telegraph', e])); api.EventBus.on('palm:impact', e => events.push(['impact', e]));
  const spawn = (x,y) => { const id = api.createMonster(world, api.ConfigManager.getMonster('fries_cultist'), x,y); world.components.health.set(id,{current:1000,max:1000}); return id; };
  return { ...api, world, playerId, skills, runtime, events, spawn, system:new api.PalmStrikeSystem() };
}

test('reserved palm and evolution stay out of upgrade choices and hints', async () => {
  const f = await fixture();
  assert.ok(!f.skills.getChoices(100).some(s => s.id === 'potato_palm'));
  for(let i=1;i<5;i++) f.skills.levelUp('potato_palm'); f.skills.levelUp('salt_spread');
  const choices = f.skills.getChoices(100);
  assert.ok(!choices.some(s => ['potato_palm','potato_palm_ascended'].includes(s.id)));
  const saltHint = f.skills.getChoiceHints([f.ConfigManager.getSkill('salt_spread')])[0];
  assert.doesNotMatch(JSON.stringify(saltHint), /金薯掌|天降薯神掌/);
  f.skills.levelUp('potato_palm_ascended');
  assert.equal(f.skills.isSkillSuppressed('potato_palm'), true);
  assert.ok(!f.skills.getChoices(100).some(s => s.id === 'potato_palm_ascended'));
});

test('four staggered palms resolve on impact, deduplicate overlapping targets and respect shield', async () => {
  const f = await fixture(); const east=f.spawn(130,0), center=f.spawn(0,0), outside=f.spawn(1000,0);
  f.world.components.monsters.get(east).shieldHp=20;
  f.system.update(16,f.runtime); assert.equal(f.world.components.health.get(east).current,1000);
  f.system.update(300,f.runtime);
  assert.ok(f.events.filter(e=>e[0]==='telegraph').length <= 2, 'palms should not all obscure the screen at once');
  for(let i=0;i<12;i++) f.system.update(100,f.runtime);
  const impacts=f.events.filter(e=>e[0]==='impact'); assert.equal(impacts.length,4);
  assert.ok(f.world.components.health.get(east).current < 1000); assert.equal(f.world.components.monsters.get(east).shieldHp,0);
  assert.ok(f.world.components.health.get(center).current < 1000);
  assert.equal(f.world.components.health.get(center).current, 1000-f.getPalmProfile(1, false, 1, 1, 1, 1).damage);
  assert.equal(f.world.components.health.get(outside).current,1000);
  assert.equal(f.world.components.health.get(f.playerId).current,100);
  f.system.update(100,f.runtime); assert.equal(f.events.filter(e=>e[0]==='impact').length,4);
});

test('faraway enemies cannot consume a cast before they enter its reach', async () => {
  const f = await fixture(); const target = f.spawn(500, 0);
  f.system.update(100, f.runtime); assert.equal(f.events.length, 0);
  f.world.components.transforms.get(target).x = 220;
  f.system.update(16, f.runtime); assert.equal(f.events[0][0], 'telegraph');
});

test('rank and evolution grow radius and damage; player death cancels pending attacks', async () => {
  const f = await fixture(); const one=f.getPalmProfile(1,false,1,1,1,1), high=f.getPalmProfile(8,false,1,1,1,1), evo=f.getPalmProfile(5,true,1,1,1,1);
  assert.ok(high.radius>one.radius && high.damage>one.damage); assert.ok(evo.radius>high.radius && evo.damage>high.damage);
  assert.ok(f.getPalmProfile(12,true,1,1,3,1).radius <= 260, 'area scaling stays legible at extreme ranks');
  f.spawn(130,0); f.system.update(16,f.runtime); f.world.components.health.get(f.playerId).current=0;
  f.system.update(1000,f.runtime); assert.equal(f.events.filter(e=>e[0]==='impact').length,0);
});

test('upgrade card tells players how the signature skill grows', async () => {
  const f = await fixture();
  const skill = f.ConfigManager.getSkill('potato_palm');
  assert.match(f.getSkillUpgradeBenefit(skill, 1), /伤害.*范围/);
});

test('each palm impact has a bounded existing impact sound cue', async () => {
  const f = await fixture();
  assert.ok(f.AUDIO_EVENTS.includes('palm:impact'));
  assert.deepEqual(f.mapAudioEvent('palm:impact', {}), ['impact-explosive']);
});

test('generated palm is a transparent game texture with a distinct framed icon', async () => {
  const f = await fixture();
  const effect = f.ConfigManager.assets.vfx_potato_palm, icon = f.ConfigManager.assets.icon_skill_potato_palm;
  assert.notEqual(effect.path, icon.path);
  const bytes = await readFile(`${root}public/${effect.path}`); assert.equal(bytes[25], 6);
  const image = await loadImage(`${root}public/${effect.path}`), canvas = createCanvas(512,512), ctx = canvas.getContext('2d');
  ctx.drawImage(image, 0,0); const data = ctx.getImageData(0,0,512,512).data;
  assert.equal(data[3], 0); let visible = 0, soft = 0;
  for (let i=3; i<data.length; i+=4) { if (data[i] > 100) visible++; if (data[i] > 0 && data[i] < 255) soft++; }
  assert.ok(visible > 10000 && soft > 1000);
});
