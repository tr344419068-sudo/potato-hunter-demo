import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
export { GameScene } from "./src/scenes/GameScene.ts";
export { ExperienceSystem } from "./src/systems/ExperienceSystem.ts";
export { EventBus } from "./src/managers/EventBus.ts";
export { ConfigManager } from "./src/managers/ConfigManager.ts";
export { createPlayer } from "./src/entities/factories.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
plugins: [{ name: "headless", setup(context) {
context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: `import EventEmitter from "eventemitter3"; export default { Scene: class {}, Events: { EventEmitter }, Display: { Color: { HexStringToColor: value=>({ color: parseInt(value.slice(1),16) }) } }, Utils: { Array: { Shuffle: value => value } }, Math: { Clamp: (value,min,max)=>Math.min(max,Math.max(min,value)), Between: (min,max)=>min, FloatBetween: (min,max)=>min } };`, resolveDir: root }));
}}] }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

async function fixture() {
  const api = await modules;
  api.EventBus.removeAllListeners();
  const scene = new api.GameScene();
  scene.playerId = api.createPlayer(scene.world, 0, 0, 210, 100, 100);
  scene.cameras = { main: { width: 1280, height: 720, shake() {} } };
  scene.scene = { restart() {} };
  const popups = [];
  api.EventBus.on("level:choices", payload => popups.push(payload));
  return { ...api, scene, popups, player: scene.world.components.players.get(scene.playerId) };
}

function addExperienceOrb(scene, value) {
  const orbId = scene.world.createEntity();
  scene.world.components.experienceOrbs.set(orbId, { value });
  scene.world.components.transforms.set(orbId, { x: 0, y: 0, radius: 4, rotation: 0 });
  scene.world.components.velocities.set(orbId, { x: 0, y: 0 });
}

test("earned upgrades open one chooser and stop later actual GameScene systems", async () => {
  const { scene, popups, ConfigManager } = await fixture();
  const choices = ConfigManager.skills.slice(0, 3);
  let earningSystemUpdates = 0;
  let laterSystemUpdates = 0;
  scene.systems = [{ update() { earningSystemUpdates++; scene.requestSkillChoice(choices); scene.requestSkillChoice(choices); } }, { update() { laterSystemUpdates++; } }];
  scene.update(0, 16);
  assert.equal(scene.choosingSkill, true);
  assert.equal(scene.pendingUpgrades, 2);
  assert.equal(popups.length, 1, "a second credit replaced the active choices");
  assert.equal(popups[0].choices.length, 3);
  assert.deepEqual([...scene.offeredUpgradeIds], popups[0].choices.map(choice => choice.id));
  assert.equal(laterSystemUpdates, 0);
  assert.equal(scene.stats.elapsedMs, 16);
  scene.update(16, 16);
  assert.equal(scene.stats.elapsedMs, 16);
  assert.equal(earningSystemUpdates, 1);
  assert.equal(laterSystemUpdates, 0);
  assert.equal(popups.length, 1);
});

test("each valid skill choice applies before automatically opening the next credit", async () => {
  const { scene, popups } = await fixture();
  scene.requestSkillChoice([]);
  scene.requestSkillChoice([]);
  scene.openUpgradeChoices();
  const first = popups[0];
  const skillId = first.choices[0].id;
  scene.handleSkillSelected({ skillId, sessionId: first.sessionId });
  assert.equal(scene.pendingUpgrades, 1);
  assert.equal(scene.choosingSkill, true);
  assert.equal(popups.length, 2);
  const second = popups[1];
  assert.notEqual(second.sessionId, first.sessionId);
  assert.notEqual(second.choices, first.choices);
  assert.notEqual(second.levels, first.levels);
  assert.ok(second.choices.some(choice => choice.id === skillId));
  assert.equal(second.levels[skillId], scene.skillManager.getLevel(skillId));
  assert.equal(second.levels[skillId], first.levels[skillId] + 1);
  let combatUpdates = 0;
  scene.systems = [{ update() { combatUpdates++; } }];
  scene.update(0, 16);
  assert.equal(combatUpdates, 0);
  assert.equal(scene.stats.elapsedMs, 0);
  scene.handleSkillSelected({ skillId: second.choices[0].id, sessionId: second.sessionId });
  assert.equal(scene.pendingUpgrades, 0);
  assert.equal(scene.choosingSkill, false);
  assert.equal(scene.offeredUpgradeIds.size, 0);
  assert.equal(popups.length, 2);
  scene.update(16, 16);
  assert.equal(combatUpdates, 1);
  assert.equal(scene.stats.elapsedMs, 16);
});

test("next queued choices exclude the skill that the previous choice just maxed", async () => {
  const { scene, popups, ConfigManager } = await fixture();
  const skill = scene.skillManager.getChoices(3)[0];
  for (let level = 0; level < skill.maxLevel - 1; level++) scene.skillManager.levelUp(skill.id);
  scene.requestSkillChoice([]);
  scene.requestSkillChoice([]);
  scene.openUpgradeChoices();
  const first = popups[0];
  assert.ok(first.choices.some(choice => choice.id === skill.id));
  scene.handleSkillSelected({ skillId: skill.id, sessionId: first.sessionId });
  assert.equal(scene.skillManager.getLevel(skill.id), ConfigManager.getSkill(skill.id).maxLevel);
  assert.equal(popups.length, 2);
  assert.ok(popups[1].choices.every(choice => choice.id !== skill.id));
  assert.equal(popups[1].choices.length, 3);
});

test("cancel keeps credits and does not reopen during updates, but a newly earned level does", async () => {
  const { scene, popups } = await fixture();
  scene.requestSkillChoice([]);
  scene.requestSkillChoice([]);
  scene.openUpgradeChoices();
  scene.cancelUpgradeChoices();
  assert.equal(scene.choosingSkill, false);
  assert.equal(scene.pendingUpgrades, 2);
  assert.equal(scene.offeredUpgradeIds.size, 0);
  scene.systems = [];
  scene.update(0, 16);
  scene.update(16, 16);
  assert.equal(scene.stats.elapsedMs, 32);
  assert.equal(scene.choosingSkill, false);
  assert.equal(popups.length, 1);
  scene.requestSkillChoice([]);
  assert.equal(scene.pendingUpgrades, 3);
  assert.equal(scene.choosingSkill, true);
  assert.equal(popups.length, 2);
  assert.notEqual(popups[1].sessionId, popups[0].sessionId);
});

test("invalid, repeated, and stale offered selections cannot award or spend", async () => {
  const { scene, popups } = await fixture();
  scene.requestSkillChoice([]); scene.requestSkillChoice([]);
  scene.openUpgradeChoices(); const first = popups.at(-1);
  scene.handleSkillSelected(undefined);
  scene.handleSkillSelected({ skillId: "not_offered", sessionId: first.sessionId });
  scene.handleSkillSelected({ skillId: first.choices[0].id, sessionId: first.sessionId - 1 });
  assert.equal(scene.pendingUpgrades, 2); assert.equal(scene.choosingSkill, true);
  const selection = { skillId: first.choices[0].id, sessionId: first.sessionId };
  scene.handleSkillSelected(selection); const earnedLevel = scene.skillManager.getLevel(selection.skillId);
  assert.equal(popups.length, 2);
  scene.handleSkillSelected(selection); assert.equal(scene.pendingUpgrades, 1);
  scene.handleSkillSelected(selection);
  assert.equal(scene.pendingUpgrades, 1); assert.equal(scene.choosingSkill, true);
  assert.equal(scene.skillManager.getLevel(selection.skillId), earnedLevel);
  const second = popups[1];
  const finalSelection = { skillId: second.choices[0].id, sessionId: second.sessionId };
  scene.handleSkillSelected(finalSelection);
  const finalLevel = scene.skillManager.getLevel(finalSelection.skillId);
  scene.handleSkillSelected(finalSelection);
  assert.equal(scene.pendingUpgrades, 0);
  assert.equal(scene.skillManager.getLevel(finalSelection.skillId), finalLevel);
});

test("reward selection applies once before chaining the remaining upgrade", async () => {
  const { scene, popups, ConfigManager, EventBus } = await fixture();
  for (const skill of ConfigManager.skills) {
    for (let level = 0; level < skill.maxLevel; level++) scene.skillManager.levelUp(skill.id);
  }
  const health = scene.world.components.health.get(scene.playerId);
  health.current = 10;
  let notifications = 0;
  EventBus.on("boss:phase", () => notifications++);
  let healthAtNextPopup;
  EventBus.on("level:choices", () => { if (popups.length === 2) healthAtNextPopup = health.current; });
  scene.requestSkillChoice([]); scene.requestSkillChoice([]);
  scene.openUpgradeChoices();
  const first = popups[0];
  assert.ok(first.choices.some(choice => choice.id === "reward_heal"));
  const selection = { skillId: "reward_heal", sessionId: first.sessionId };
  scene.handleSkillSelected(selection);
  assert.equal(health.current, 50);
  assert.equal(notifications, 1);
  assert.equal(scene.pendingUpgrades, 1);
  assert.equal(scene.choosingSkill, true);
  assert.equal(popups.length, 2);
  assert.equal(healthAtNextPopup, 50);
  assert.notEqual(popups[1].sessionId, first.sessionId);
  scene.handleSkillSelected(selection);
  assert.equal(health.current, 50);
  assert.equal(notifications, 1);
  assert.equal(scene.pendingUpgrades, 1);
  scene.handleSkillSelected({ skillId: "reward_heal", sessionId: popups[1].sessionId });
  assert.equal(health.current, 90);
  assert.equal(scene.pendingUpgrades, 0);
  assert.equal(scene.choosingSkill, false);
});

test("one XP collection processes every affordable level through the real ExperienceSystem", async () => {
  const { scene, player, popups, ExperienceSystem } = await fixture();
  addExperienceOrb(scene, 1000);
  new ExperienceSystem().update(16, scene.createRuntime());
  assert.ok(player.level >= 4);
  assert.equal(scene.pendingUpgrades, player.level - 1);
  assert.ok(player.experience < player.experienceToNext);
  assert.equal(scene.choosingSkill, true);
  assert.equal(popups.length, 1);
});

test("90 opening XP reaches level four and queues three paused choices", async () => {
  const { scene, player, popups, ExperienceSystem } = await fixture();
  addExperienceOrb(scene, 90);
  let combatUpdates = 0;
  scene.systems = [new ExperienceSystem(), { update() { combatUpdates++; } }];
  scene.update(0, 16);
  assert.equal(player.level, 4);
  assert.equal(player.experience, 0);
  assert.equal(player.experienceToNext, 78);
  assert.equal(scene.pendingUpgrades, 3);
  assert.equal(scene.choosingSkill, true);
  assert.equal(popups.length, 1);
  assert.equal(combatUpdates, 0);
  scene.update(16, 16);
  assert.equal(scene.stats.elapsedMs, 16);
  for (let credit = 3; credit > 0; credit--) {
    const popup = popups.at(-1);
    scene.handleSkillSelected({ skillId: popup.choices[0].id, sessionId: popup.sessionId });
    assert.equal(scene.pendingUpgrades, credit - 1);
    assert.equal(scene.choosingSkill, credit > 1);
  }
  assert.equal(popups.length, 3);
  assert.equal(new Set(popups.map(popup => popup.sessionId)).size, 3);
  scene.update(32, 16);
  assert.equal(combatUpdates, 1);
  assert.equal(scene.stats.elapsedMs, 32);
});

test("an ordinary XP level automatically pauses combat without requiring U or a HUD click", async () => {
  const { scene, player, popups, ExperienceSystem } = await fixture();
  addExperienceOrb(scene, player.experienceToNext);
  let combatUpdates = 0;
  scene.systems = [new ExperienceSystem(), { update() { combatUpdates++; } }];
  scene.update(0, 16);
  assert.equal(player.level, 2);
  assert.equal(player.experience, 0);
  assert.equal(scene.pendingUpgrades, 1);
  assert.equal(scene.choosingSkill, true);
  assert.equal(popups.length, 1);
  assert.equal(combatUpdates, 0);
  scene.update(16, 16);
  assert.equal(scene.stats.elapsedMs, 16);
});

test("restart clears pending credits, offered choices, and visible popup immediately", async () => {
  const { scene, EventBus, popups } = await fixture();
  let visible = false;
  EventBus.on("level:choices", () => visible = true);
  scene.requestSkillChoice([]); scene.openUpgradeChoices();
  const oldSelection = { skillId: popups[0].choices[0].id, sessionId: popups[0].sessionId };
  let cleared = 0; EventBus.on("ui:clear", () => { cleared++; visible = false; });
  scene.handleRestart();
  assert.equal(scene.pendingUpgrades, 0); assert.equal(scene.choosingSkill, false);
  assert.equal(scene.offeredUpgradeIds.size, 0);
  assert.equal(visible, false);
  assert.equal(cleared, 1);
  scene.handleSkillSelected(oldSelection);
  scene.openUpgradeChoices();
  assert.equal(scene.pendingUpgrades, 0);
  assert.equal(popups.length, 1);
  assert.equal(scene.skillManager.getLevel(oldSelection.skillId), 0);
});

test("game over discards unspendable credits and prevents earning, reopening, or spending an upgrade", async () => {
  const { scene, popups } = await fixture();
  scene.requestSkillChoice([]); scene.openUpgradeChoices();
  const first = popups[0];
  scene.endRun();
  scene.handleSkillSelected({ skillId: first.choices[0].id, sessionId: first.sessionId });
  assert.equal(scene.pendingUpgrades, 0);
  assert.equal(scene.pendingOffer, undefined);
  assert.equal(scene.offeredUpgradeIds.size, 0);
  assert.equal(scene.skillManager.getLevel(first.choices[0].id), 0);
  scene.cancelUpgradeChoices();
  scene.requestSkillChoice([]);
  scene.openUpgradeChoices();
  assert.equal(scene.pendingUpgrades, 0);
  assert.equal(scene.choosingSkill, false);
  assert.equal(popups.length, 1);
});

test("optional U can reopen postponed credits but held U cannot", async () => {
  const { scene, popups } = await fixture();
  scene.requestSkillChoice([]); scene.requestSkillChoice([]);
  scene.openUpgradeChoices({ repeat: false });
  scene.cancelUpgradeChoices();
  assert.equal(scene.pendingUpgrades, 2); assert.equal(scene.choosingSkill, false);
  scene.openUpgradeChoices({ repeat: true });
  assert.equal(scene.choosingSkill, false, "keyboard repeat reopened the chooser without renewed intent");
  assert.equal(popups.length, 1);
  scene.openUpgradeChoices({ repeat: false }); assert.equal(scene.choosingSkill, true);
  assert.equal(popups.length, 2);
});

test("HUD exposes the firing starter peeler at actual Lv1 before any upgrade", async () => {
  const { scene, EventBus, ConfigManager, popups } = await fixture();
  let hud; EventBus.on("hud:update", payload => hud = payload);
  scene.emitHud(0);
  assert.ok(scene.skillManager.getWeaponProfiles().some(weapon => weapon.skillId === "peeler_blade"));
  assert.equal(hud.skills.find(skill => skill.id === "peeler_blade")?.level, 1);
  assert.ok(ConfigManager.getSkill("peeler_blade").iconAssetId);
  for (const skill of ConfigManager.skills.filter(skill => skill.id !== "peeler_blade")) {
    for (let level = 0; level < skill.maxLevel; level++) scene.skillManager.levelUp(skill.id);
  }
  scene.requestSkillChoice([]); scene.openUpgradeChoices(); const popup = popups[0];
  assert.ok(popup.choices.some(choice => choice.id === "peeler_blade"));
  scene.handleSkillSelected({ skillId: "peeler_blade", sessionId: popup.sessionId });
  scene.emitHud(0);
  assert.equal(hud.skills.find(skill => skill.id === "peeler_blade")?.level, 2);
  assert.equal(hud.skills.filter(skill => skill.id === "peeler_blade").length, 1);
});
