#!/usr/bin/env python3
"""Repack selected Brackeys artwork from a pinned checkout; does not draw new art."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageOps

REV = '23b58f272b828b0a894ed7ef72fbf9033ee9d177'
ROOT = Path(__file__).resolve().parents[1]
SUBDIR = 'vfx/brackeys_particle_bundle'
SIZE = 96
SHEETS = (
    ('fire', 'predrawn/explosion_6x5.png', (6, 5), range(24)),
    ('dust', 'flipbooks/explosion_smoke_01_8x8.tga', (5, 5), range(25)),
    ('impact', 'predrawn/impact_white_6x4.png', (6, 4), range(12)),
    ('ember-ring', 'predrawn/fire_ring_6x5.png', (6, 5), range(0, 24, 2)),
    ('static-ring', 'predrawn/electric_ring_6x5.png', (6, 5), range(0, 24, 2)),
)


def repack(source, grid, frames, name):
    cols, rows = grid
    out = Image.new('RGBA', (6 * SIZE, ((len(frames) + 5) // 6) * SIZE))
    for i, source_frame in enumerate(frames):
        x, y = source_frame % cols, source_frame // cols
        frame = source.crop((round(x * source.width / cols), round(y * source.height / rows),
                             round((x + 1) * source.width / cols), round((y + 1) * source.height / rows)))
        frame = ImageOps.contain(frame, (SIZE, SIZE), Image.Resampling.LANCZOS)
        if name == 'dust':
            # Lift the original shaded plume before runtime tints it sand gold.
            a = frame.getchannel('A')
            frame = ImageOps.grayscale(frame).point(lambda value: round(45 + value * .82)).convert('RGBA')
            frame.putalpha(a)
        out.paste(frame, (i % 6 * SIZE + (SIZE - frame.width) // 2, i // 6 * SIZE + (SIZE - frame.height) // 2))
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checkout', type=Path)
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'public/assets/vfx/brackeys-boss-v1')
    args = parser.parse_args()
    rev = subprocess.check_output(['git', '-C', args.checkout, 'rev-parse', 'HEAD'], text=True).strip()
    if rev != REV:
        parser.error(f'expected upstream commit {REV}, got {rev}')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    outputs = []
    for name, rel, grid, frames in (*SHEETS, ('muzzle', 'particles/alpha/muzzle_03_a.png', None, range(1))):
        original = args.checkout / SUBDIR / rel
        with Image.open(original) as img:
            source = img.convert('RGBA')
        if grid:
            image = repack(source, grid, frames, name)
        else:
            image = source.transpose(Image.Transpose.ROTATE_270).resize((128, 128), Image.Resampling.LANCZOS)
        path = args.output_dir / f'{name}.webp'
        image.save(path, format='WEBP', quality=79, alpha_quality=96, method=6)
        outputs.append({'file': path.name, 'upstreamFile': f'{SUBDIR}/{rel}', 'upstreamSha256': sha256(original.read_bytes()).hexdigest(),
                        'sourceGrid': grid, 'sourceFrames': list(frames), 'frames': len(frames),
                        'dimensions': list(image.size), 'sha256': sha256(path.read_bytes()).hexdigest()})
    manifest = {'creator': 'Brackeys', 'pack': 'Brackeys VFX Bundle', 'license': 'CC0-1.0',
                'licenseEvidence': f'https://github.com/Brackeys/vfx-in-godot/blob/{REV}/README.md#license',
                'upstream': 'https://github.com/Brackeys/vfx-in-godot', 'commit': REV, 'outputs': outputs}
    (args.output_dir / 'sources.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
