import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
export { GameScene } from "./src/scenes/GameScene.ts";
export { World } from "./src/entities/World.ts";
export { ExperienceSystem } from "./src/systems/ExperienceSystem.ts";
export { PlayerStatsSystem } from "./src/systems/PlayerStatsSystem.ts";
export { AutoAttackSystem } from "./src/systems/AutoAttackSystem.ts";
export { AuraSystem } from "./src/systems/AuraSystem.ts";
export { ProjectileCollisionSystem } from "./src/systems/ProjectileCollisionSystem.ts";
export { ConfigManager } from "./src/managers/ConfigManager.ts";
export { SkillManager } from "./src/managers/SkillManager.ts";
export { getPlayerLevelGrowth } from "./src/managers/PlayerLevelGrowthModel.ts";
export { EventBus } from "./src/managers/EventBus.ts";
export { createPlayer, createMonster, createExperienceOrb } from "./src/entities/factories.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
plugins: [{ name: "headless-growth", setup(context) {
  context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless-growth" }));
  context.onLoad({ filter: /.*/, namespace: "headless-growth" }, () => ({ contents: `import EventEmitter from "eventemitter3"; export default { Scene: class {}, Events: { EventEmitter }, Display: { Color: { HexStringToColor: value=>({ color: parseInt(value.slice(1),16) }) } }, Utils: { Array: { Shuffle: values=>values } }, Math: { Clamp: (value,min,max)=>Math.min(max,Math.max(min,value)), Between: (min,max)=>min, FloatBetween: (min,max)=>min } };`, resolveDir: root }));
}}] }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

async function fixture() {
  const api = await modules;
  api.EventBus.removeAllListeners();
  const game = new api.GameScene();
  game.playerId = api.createPlayer(game.world, 0, 0, 220, 100, 145);
  game.cameras = { main: { width: 1280, height: 720, shakes: 0, flashes: 0, shake() { this.shakes++; }, flash() { this.flashes++; } } };
  game.scene = { restart() {} };
  const player = game.world.components.players.get(game.playerId);
  const health = game.world.components.health.get(game.playerId);
  const popups = [];
  api.EventBus.on("level:choices", payload => popups.push(payload));
  return { ...api, game, player, health, popups, runtime: game.createRuntime() };
}

function earn(f, value) {
  f.createExperienceOrb(f.game.world, 0, 0, value);
  new f.ExperienceSystem().update(16, f.runtime);
}

test("actual earned level raises HP and heals before opening automatic choices", async () => {
  const f = await fixture(); f.health.current = 40;
  let atOpening;
  f.EventBus.on("level:choices", () => atOpening = { ...f.health });
  earn(f, 12);
  assert.equal(f.player.level, 2);
  assert.deepEqual(atOpening, { current: 66, max: 105 });
  assert.deepEqual(f.health, { current: 66, max: 105 });
  assert.equal(f.game.pendingUpgrades, 1);
  assert.equal(f.game.choosingSkill, true);
  assert.equal(f.popups.length, 1);
  assert.equal(f.game.cameras.main.shakes + f.game.cameras.main.flashes, 0);
});

test("one XP pickup awards each affordable level once without replacing the current chooser", async () => {
  const f = await fixture(); f.health.current = 10;
  earn(f, 90);
  assert.equal(f.player.level, 4);
  assert.deepEqual(f.health, { current: 91, max: 115 });
  assert.equal(f.player.experience, 0);
  assert.equal(f.player.experienceToNext, 78);
  assert.equal(f.game.pendingUpgrades, 3);
  assert.equal(f.popups.length, 1);
  new f.ExperienceSystem().update(16, f.runtime);
  assert.deepEqual(f.health, { current: 91, max: 115 });
});

test("full-health upgrades fill new capacity but never overheal", async () => {
  const f = await fixture(); earn(f, 90);
  assert.deepEqual(f.health, { current: 115, max: 115 });
});

for (const [level, ratio] of [[2, .20], [5, .20], [6, .18], [10, .18], [11, .15], [20, .15]]) {
  test(`reaching Lv${level} heals ${ratio * 100}% of its new maximum`, async () => {
    const f = await fixture();
    f.player.level = level - 1; f.player.experienceToNext = 12;
    f.health.max = 100 + (level - 2) * 5; f.health.current = 50;
    earn(f, 12);
    const maximum = 100 + (level - 1) * 5;
    assert.equal(f.health.max, maximum);
    assert.equal(f.health.current, Math.min(maximum, 55 + Math.ceil(maximum * ratio)));
  });
}

test("selection, cancellation, reopening and duplicate selection never award level healing", async () => {
  const f = await fixture(); f.health.current = 40; earn(f, 12);
  const earned = { ...f.health };
  f.game.cancelUpgradeChoices(); f.game.openUpgradeChoices();
  const popup = f.popups.at(-1);
  const selection = { skillId: popup.choices[0].id, sessionId: popup.sessionId };
  f.game.handleSkillSelected(selection); f.game.handleSkillSelected(selection);
  f.game.requestSkillChoice([]); f.game.cancelUpgradeChoices(); f.game.openUpgradeChoices();
  assert.deepEqual(f.health, earned);
  assert.equal(f.player.level, 2);
});

test("max-HP skill bonuses stack with level growth and enter the percentage-healing base", async () => {
  const f = await fixture(); f.health.current = 40; f.game.skillManager.levelUp("cheese_armor");
  new f.PlayerStatsSystem().update(0, f.runtime);
  assert.deepEqual(f.health, { current: 62, max: 122 });
  earn(f, 12);
  assert.deepEqual(f.health, { current: 93, max: 127 });
  const stats = new f.PlayerStatsSystem();
  stats.update(0, f.runtime); stats.update(0, f.runtime);
  assert.deepEqual(f.health, { current: 93, max: 127 });
  stats.update(1000, f.runtime);
  assert.ok(Math.abs(f.health.current - 93.7) < 1e-9, "existing skill regeneration remains independent");
});

test("ordinary stats recomputation preserves earned HP rather than resetting or healing every frame", async () => {
  const f = await fixture(); f.health.current = 40; earn(f, 12);
  f.health.current -= 17;
  const stats = new f.PlayerStatsSystem();
  for (let frame = 0; frame < 30; frame++) stats.update(16, f.runtime);
  assert.deepEqual(f.health, { current: 49, max: 105 });
});

for (const hp of [0, -8]) {
  test(`a dead player at ${hp} HP cannot collect XP, level or revive`, async () => {
    const f = await fixture(); f.health.current = hp; earn(f, 12);
    new f.PlayerStatsSystem().update(16, f.runtime);
    assert.equal(f.health.current, hp);
    assert.equal(f.player.level, 1);
    assert.equal(f.player.experience, 0);
    assert.equal(f.popups.length, 0);
    assert.equal(f.game.world.components.experienceOrbs.size, 1);
  });
}

test("missing player health prevents XP rewards without throwing", async () => {
  const f = await fixture(); f.game.world.components.health.delete(f.game.playerId); earn(f, 12);
  assert.equal(f.player.level, 1); assert.equal(f.popups.length, 0);
});

test("a reused stats system does not leak previous-run growth or max-HP skill state", async () => {
  const f = await fixture(); const stats = new f.PlayerStatsSystem();
  f.player.level = 10; f.game.skillManager.levelUp("cheese_armor"); stats.update(0, f.runtime);
  assert.equal(f.health.max, 167);
  f.game.handleRestart(); f.game.world = new f.World(); f.game.skillManager = new f.SkillManager();
  f.game.playerId = f.createPlayer(f.game.world, 0, 0, 220, 100, 145);
  stats.update(0, f.game.createRuntime());
  assert.deepEqual(f.game.world.components.health.get(f.game.playerId), { current: 100, max: 100 });
});

function target(f, x = 120, y = 0) {
  return f.createMonster(f.game.world, { ...f.ConfigManager.monsters[0], hp: 1000, shieldHp: 0, behavior: "chaser" }, x, y);
}

test("growth is linear, sanitizes invalid levels and leaves Lv1 unchanged", async () => {
  const { getPlayerLevelGrowth: growth } = await modules;
  for (const level of [undefined, 0, -2, NaN, Infinity]) {
    assert.deepEqual(growth(level), { maxHpBonus: 0, damageMultiplier: 1, healRatio: 0 });
  }
  assert.deepEqual(growth(2), { maxHpBonus: 5, damageMultiplier: 1.02, healRatio: .2 });
  assert.deepEqual(growth(10.9), { maxHpBonus: 45, damageMultiplier: 1.18, healRatio: .18 });
});

test("Lv1 profile defaults preserve existing skill progression and combat attributes", async () => {
  const f = await fixture();
  for (const id of ["fire_potato", "ketchup_aura", "pickle_crit", "pepper_motor", "starch_boots"]) f.game.skillManager.levelUp(id);
  assert.deepEqual(f.game.skillManager.getWeaponProfiles(), f.game.skillManager.getWeaponProfiles(1));
  assert.deepEqual(f.game.skillManager.getAuraProfiles(), f.game.skillManager.getAuraProfiles(1));
  const stats = f.game.skillManager.getCombatStats();
  const base = f.game.skillManager.getWeaponProfiles(1);
  const grown = f.game.skillManager.getWeaponProfiles(10);
  for (let i = 0; i < base.length; i++) {
    const { damage: baseDamage, effects: baseEffects, ...baseNonDamage } = base[i];
    const { damage: grownDamage, effects: grownEffects, ...grownNonDamage } = grown[i];
    assert.deepEqual(grownNonDamage, baseNonDamage, "cooldown, crit, count, speed and presentation are skill-defined");
    assert.equal(grownEffects.length, baseEffects.length);
  }
  assert.deepEqual(f.game.skillManager.getCombatStats(), stats);
  assert.equal(f.player.moveSpeed, 220); assert.equal(f.player.pickupRadius, 145);
});

for (const [level, multiplier] of [[2, 1.02], [10, 1.18]]) {
  test(`actual auto attacks at Lv${level} snapshot base damage growth`, async () => {
    const f = await fixture(); target(f); f.player.level = level;
    new f.AutoAttackSystem().update(16, f.runtime);
    const projectile = [...f.game.world.components.projectiles.values()].find(p => p.skillId === "peeler_blade");
    assert.equal(projectile.damage, Math.ceil(f.ConfigManager.getSkill("peeler_blade").weapon.damage * multiplier));
    assert.equal(projectile.critChance, 0);
  });
}

test("skill and elemental bonuses multiply before rounding rather than compounding character levels", async () => {
  const f = await fixture(); const manager = f.game.skillManager;
  manager.levelUp("fire_potato"); manager.levelUp("fire_potato");
  manager.levelUp("butter_lube");
  const stats = manager.getCombatStats();
  const skill = f.ConfigManager.skills.find(s => s.id === "fire_potato");
  const profile = manager.getWeaponProfiles(10).find(p => p.skillId === skill.id);
  const tagDamage = stats.fireDamageMultiplier * stats.dotDamageMultiplier;
  assert.equal(profile.damage, Math.ceil(skill.weapon.damage * 1.28 * tagDamage * 1.18));
  assert.ok(Math.abs(profile.effects.find(e => e.type === "burn").damagePerSecond - 8 * tagDamage * 1.18 * 1.18) < 1e-9);
  assert.equal(manager.getLevel("fire_potato"), 2);
  manager.levelUp("thunder_potato"); manager.levelUp("thunder_potato");
  manager.levelUp("socket_chain"); manager.levelUp("socket_chain");
  const lightning = manager.getWeaponProfiles(10).find(p => p.skillId === "thunder_potato");
  assert.equal(lightning.damage, Math.ceil(f.ConfigManager.getSkill("thunder_potato").weapon.damage * 1.28 * 1.24 * 1.18));
  assert.equal(lightning.damageBeforePlayerGrowth, Math.ceil(f.ConfigManager.getSkill("thunder_potato").weapon.damage * 1.28 * 1.24));
  assert.equal(lightning.effects.find(e => e.type === "chain").jumps, 4);
});

test("in-flight projectiles keep cast-time damage and DoT; the next attack uses the new level", async () => {
  const f = await fixture(); target(f); f.game.skillManager.levelUp("fire_potato");
  const attack = new f.AutoAttackSystem(); attack.update(0, f.runtime);
  const old = [...f.game.world.components.projectiles.values()].find(p => p.skillId === "fire_potato");
  earn(f, 12); assert.equal(f.player.level, 2);
  assert.equal(old.damage, f.ConfigManager.getSkill("fire_potato").weapon.damage); assert.equal(old.effects.find(e => e.type === "burn").damagePerSecond, 8);
  attack.update(1000, f.runtime);
  const newest = [...f.game.world.components.projectiles.values()].filter(p => p.skillId === "fire_potato").at(-1);
  assert.equal(newest.damage, Math.ceil(f.ConfigManager.getSkill("fire_potato").weapon.damage * 1.02));
  assert.equal(newest.effects.find(e => e.type === "burn").damagePerSecond, 8.16);
});

test("actual projectile collision applies grown direct damage and a cast-time burn snapshot", async () => {
  const f = await fixture(); const id = target(f); f.player.level = 10;
  f.game.skillManager.levelUp("fire_potato"); new f.AutoAttackSystem().update(0, f.runtime);
  for (const [pid, p] of f.game.world.components.projectiles) {
    if (p.skillId !== "fire_potato") f.game.world.destroyEntity(pid);
    else f.game.world.components.transforms.set(pid, { x: 120, y: 0, radius: 10 });
  }
  new f.ProjectileCollisionSystem().update(16, f.runtime);
  assert.equal(f.game.world.components.health.get(id).current, 1000 - Math.ceil(f.ConfigManager.getSkill("fire_potato").weapon.damage * 1.18));
  const status = f.game.world.components.statuses.get(id).find(s => s.type === "burn");
  assert.equal(status.damagePerSecond, 8 * 1.18);
  f.player.level = 11; new f.PlayerStatsSystem().update(0, f.runtime);
  assert.equal(status.damagePerSecond, 8 * 1.18);
});

for (const [skillId, statusType] of [["ketchup_aura", "burn"], ["toxic_tomato", "poison"]]) {
  test(`actual ${skillId} aura ticks and ${statusType} use live character level exactly once`, async () => {
    const f = await fixture(); const id = target(f, 50); f.player.level = 10;
    f.game.skillManager.levelUp(skillId);
    const skill = f.ConfigManager.skills.find(s => s.id === skillId);
    new f.AuraSystem().update(0, f.runtime);
    const expectedDamage = (skill.aura.entryDamage + skill.aura.damagePerSecond * skill.aura.tickMs / 1000) * 1.18;
    assert.ok(Math.abs(f.game.world.components.health.get(id).current - (1000 - expectedDamage)) < 1e-9);
    assert.equal(f.game.world.components.statuses.get(id).find(s => s.type === statusType).damagePerSecond,
      skill.effects.find(e => e.type === statusType).damagePerSecond * 1.18);
    const base = f.game.skillManager.getAuraProfiles(1)[0];
    const grown = f.game.skillManager.getAuraProfiles(10)[0];
    assert.equal(grown.radius, base.radius); assert.equal(grown.tickMs, base.tickMs);
  });
}

for (const [skillId, effectType] of [["starch_bomb", "explosion"], ["thunder_potato", "chain"]]) {
  test(`${effectType} derives grown source-hit damage without scaling its multiplier a second time`, async () => {
    const f = await fixture(); const first = target(f, 120); const splash = target(f, 190);
    f.player.level = 10; f.game.skillManager.levelUp(skillId);
    new f.AutoAttackSystem().update(0, f.runtime);
    const skill = f.ConfigManager.skills.find(s => s.id === skillId);
    const effect = skill.effects.find(e => e.type === effectType);
    const profile = f.game.skillManager.getWeaponProfiles(10).find(p => p.skillId === skillId);
    assert.equal(profile.effects.find(e => e.type === effectType).damageMultiplier, effect.damageMultiplier);
    for (const [pid, p] of f.game.world.components.projectiles) {
      if (p.skillId !== skillId) f.game.world.destroyEntity(pid);
      else f.game.world.components.transforms.set(pid, { x: 120, y: 0, radius: 10 });
    }
    new f.ProjectileCollisionSystem().update(16, f.runtime);
    const source = Math.ceil(skill.weapon.damage * 1.18);
    const splashDamage = Math.ceil(source * effect.damageMultiplier);
    assert.equal(f.game.world.components.health.get(splash).current, 1000 - splashDamage);
    assert.equal(f.game.world.components.health.get(first).current, 1000 - source - (effectType === "explosion" ? splashDamage : 0));
  });
}

for (const [skillId, xp, reachedLevel] of [["corn_burst", 12, 2], ["pepper_overdrive", 168, 5]]) {
  test(`${skillId} completes its spaced burst across earned levels without changing the cycle cooldown`, async () => {
    const f = await fixture(); target(f); f.game.skillManager.levelUp(skillId);
    const skill = f.ConfigManager.skills.find(s => s.id === skillId);
    const weapon = skill.weapon;
    const source = weapon.damage * (skill.category === "evolution" ? 1.25 : 1);
    const shots = () => [...f.game.world.components.projectiles.values()].filter(p => p.skillId === skillId);
    const attack = new f.AutoAttackSystem(); attack.update(0, f.runtime);
    assert.equal(shots().length, 1);
    earn(f, xp); assert.equal(f.player.level, reachedLevel);
    f.game.cancelUpgradeChoices();
    const grown = Math.ceil(source * (1 + (reachedLevel - 1) * .02));
    for (let i = 1; i < weapon.burstCount; i++) {
      attack.update(weapon.burstIntervalMs - 1, f.runtime);
      assert.equal(shots().length, i, "upgrade must not restart or accelerate the burst");
      attack.update(1, f.runtime);
      assert.equal(shots().length, i + 1, "earned growth must not cancel remaining shots");
    }
    assert.deepEqual(shots().map(p => p.damage), [Math.ceil(source), ...Array(weapon.burstCount - 1).fill(grown)]);
    const remainingCooldown = weapon.cooldownMs - weapon.burstIntervalMs * (weapon.burstCount - 1);
    attack.update(remainingCooldown - 1, f.runtime); assert.equal(shots().length, weapon.burstCount);
    attack.update(1, f.runtime); assert.equal(shots().length, weapon.burstCount + 1);
    assert.equal(shots().at(-1).damage, grown);
  });
}

test("a real burst skill-rank change retains the existing intentional queue invalidation", async () => {
  const f = await fixture(); target(f); f.game.skillManager.levelUp("corn_burst");
  const attack = new f.AutoAttackSystem(); attack.update(0, f.runtime);
  f.game.skillManager.levelUp("corn_burst"); attack.update(75, f.runtime); attack.update(75, f.runtime);
  assert.equal([...f.game.world.components.projectiles.values()].filter(p => p.skillId === "corn_burst").length, 1);
});
