import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function loadModel() {
  try {
    return await import("../src/systems/DashModel.ts");
  } catch {
    return {};
  }
}

test("dash starts in the requested direction and falls back to the last heading", async () => {
  const model = await loadModel();
  assert.equal(typeof model.createDashState, "function");

  const direct = model.createDashState(3, 4, -1, 0);
  const fallback = model.createDashState(0, 0, -1, 0);

  assert.ok(Math.abs(direct.directionX - 0.6) < 0.001);
  assert.ok(Math.abs(direct.directionY - 0.8) < 0.001);
  assert.equal(fallback.directionX, -1);
  assert.equal(fallback.directionY, 0);
  assert.equal(direct.remainingMs, model.DASH_DURATION_MS);
  assert.equal(direct.cooldownMs, model.DASH_COOLDOWN_MS);
});

test("dash timing and HUD cooldown ratio remain clamped", async () => {
  const model = await loadModel();
  assert.equal(typeof model.tickDashState, "function");
  assert.equal(typeof model.getDashCooldownRatio, "function");

  const state = model.createDashState(1, 0, 1, 0);
  const ticked = model.tickDashState(state, model.DASH_DURATION_MS + 40);

  assert.equal(ticked.remainingMs, 0);
  assert.ok(ticked.cooldownMs > 0);
  assert.equal(model.getDashCooldownRatio(-10), 0);
  assert.equal(model.getDashCooldownRatio(model.DASH_COOLDOWN_MS * 2), 1);
  assert.ok(model.DASH_SPEED >= 650 && model.DASH_SPEED <= 800);
});

test("input, damage immunity, HUD, and VFX all consume dash state", async () => {
  const [inputSource, contactSource, enemyProjectileSource, hudSource, sceneSource, vfxSource, damageModel] = await Promise.all([
    readFile(new URL("../src/systems/InputSystem.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/systems/MonsterContactSystem.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/systems/EnemyProjectileSystem.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/ui/HUDView.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/scenes/GameScene.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/systems/CombatVfxSystem.ts", import.meta.url), "utf8"),
    import("../src/systems/PlayerDamageModel.ts"),
  ]);

  assert.match(inputSource, /player:dash-request/);
  assert.match(inputSource, /!this\.dashRequested[\s\S]{0,160}activePointer\.isDown|activePointer\.isDown[\s\S]{0,160}!this\.dashRequested/);
  assert.match(contactSource, /canReceiveHostileDamage\(player\)/);
  assert.match(enemyProjectileSource, /canReceiveHostileDamage\(protectionAtContact\)/);
  assert.equal(damageModel.canReceiveHostileDamage({ dashRemainingMs: 1, damageCooldownMs: 0 }), false);
  assert.equal(damageModel.canReceiveHostileDamage({ dashRemainingMs: 0, damageCooldownMs: 0 }), true);
  assert.match(hudSource, /dashCooldownRatio/);
  assert.match(sceneSource, /dashCooldownRatio/);
  assert.match(vfxSource, /hero:dash/);
});
