import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import { loadImage } from '@napi-rs/canvas';

const root = fileURLToPath(new URL('../', import.meta.url));
const source = new URL('../src/systems/HeroFilmModel.ts', import.meta.url);
const api = readFile(source).catch(error => { if (error.code === 'ENOENT') return null; throw error; }).then(async code => {
  if (!code) return null;
  const bundle = await build({ entryPoints: [fileURLToPath(source)], absWorkingDir: root, bundle: true, platform: 'node', format: 'esm', write: false });
  return import(`data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].text).toString('base64')}`);
});
async function model() { const value = await api; assert.ok(value, 'K1 motion model is not implemented'); return value; }
const motion = (overrides = {}) => ({ deltaMs: 16, speed: 0, facingX: 1, dashRemainingMs: 0, dashDirectionX: 0, hit: false, dead: false, ...overrides });
const aim = (sequence, action = 'shoot', directionX = 1, remainingMs = 0) => ({ sequence, action, directionX, remainingMs });

test('selects the visually matching skill without triggering on auras or oil', async () => {
  const { getHeroWeaponAction } = await model();
  for (const skill of ['pepper_gatling', 'pepper_overdrive', 'skewer_javelin', 'thunder_skewer', 'corn_burst', 'frost_chips']) assert.equal(getHeroWeaponAction(skill), 'shoot');
  for (const skill of ['peeler_blade', 'peeler_returning']) assert.equal(getHeroWeaponAction(skill), 'slash');
  for (const skill of ['ketchup_aura', 'toxic_tomato', 'hot_oil_flask', 'wildfire_flask', 'potato_palm', undefined]) assert.equal(getHeroWeaponAction(skill), undefined);
});

test('windup cannot invent contact; a real release uses the exact cue from either attack', async () => {
  const { HeroFilmMotion, HERO_FILM } = await model();
  const state = new HeroFilmMotion();
  const windup = aim(1, 'slash', -1, 80);
  assert.equal(state.update(motion({ windup })).action, 'slash');
  for (let i = 0; i < 6; i++) assert.ok(state.update(motion({ windup })).frame < HERO_FILM.slash.cue);
  assert.deepEqual(state.update(motion({ windup, release: aim(1, 'slash', -1) })), { action: 'slash', frame: HERO_FILM.slash.cue, facingX: -1 });
  assert.deepEqual(state.update(motion({ release: aim(2) })), { action: 'shoot', frame: HERO_FILM.shoot.cue, facingX: 1 });
  assert.ok(state.update(motion({ deltaMs: 65, release: aim(2) })).frame > HERO_FILM.shoot.cue);
  assert.equal(state.update(motion({ deltaMs: 140, release: aim(2) })).action, 'idle');
});

test('a priority Moon Draw windup can replace the recoil of a previous shot', async () => {
  const { HeroFilmMotion, HERO_FILM } = await model();
  const state = new HeroFilmMotion();
  assert.equal(state.update(motion({ release: aim(1) })).action, 'shoot');
  const pose = state.update(motion({ windup: { ...aim(1, 'slash', 1, 190), priority: true } }));
  assert.equal(pose.action, 'slash');
  assert.ok(pose.frame < HERO_FILM.slash.cue);
});

test('uses actual travel, freezes on pause, and restores movement without replaying a suppressed attack', async () => {
  const { HeroFilmMotion } = await model();
  const state = new HeroFilmMotion();
  assert.equal(state.update(motion({ speed: 75 })).action, 'walk');
  const run = state.update(motion({ speed: 220, facingX: -1 }));
  assert.equal(run.action, 'run');
  assert.deepEqual(state.update(motion({ deltaMs: 0 })), run);
  assert.equal(state.update(motion({ speed: 800, dashRemainingMs: 160, dashDirectionX: -1, release: aim(1) })).action, 'dash');
  assert.equal(state.update(motion({ speed: 220, release: aim(1) })).action, 'run');
  assert.equal(state.update(motion({ hit: true, release: aim(2) })).action, 'hit');
  assert.equal(state.update(motion({ dead: true, hit: true, dashRemainingMs: 150 })).action, 'down');
  let final;
  for (let i = 0; i < 70; i++) final = state.update(motion({ dead: true }));
  assert.deepEqual(state.update(motion({ dead: true, deltaMs: 100 })), final);
});

test('keeps all eight compressed game atlases within the download budget and registered as spritesheets', async () => {
  const { HERO_FILM } = await model();
  const manifest = JSON.parse(await readFile(new URL('../src/configs/assets.json', import.meta.url), 'utf8'));
  let bytes = 0;
  assert.equal(Object.keys(HERO_FILM).length, 8);
  for (const [action, clip] of Object.entries(HERO_FILM)) {
    const sheet = manifest[`hero_k1_${action}`];
    assert.equal(sheet.frameWidth, 160);
    assert.equal(sheet.frameHeight, 160);
    assert.equal(sheet.frameCount, clip.frameMs.length);
    const path = fileURLToPath(new URL(`../public/${sheet.path}`, import.meta.url));
    bytes += (await stat(path)).size;
    const img = await loadImage(path);
    assert.equal(img.width, sheet.width);
    assert.equal(img.height, sheet.height);
  }
  assert.ok(bytes <= 480 * 1024, `eight texture sheets cost ${bytes} bytes`);
});

test('mirrors the release-cell muzzle with the pose, including the vertical aim fallback', async () => {
  const { getHeroFilmMuzzle } = await model();
  const left = getHeroFilmMuzzle(100, 120, 84, -.9, 1);
  const right = getHeroFilmMuzzle(100, 120, 84, .9, -1);
  assert.ok(left.x < 80 && right.x > 120 && left.y < 90);
  assert.equal(left.y, right.y);
  assert.equal(left.x + right.x, 200);
  assert.deepEqual(getHeroFilmMuzzle(100, 120, 84, .09, -1), left);
});

test('a gait pose is based on distance covered, not the number or length of render frames', async () => {
  const { HeroFilmMotion } = await model();
  const one = new HeroFilmMotion(), many = new HeroFilmMotion();
  const frame = (state, deltaMs, speed) => state.update(motion({ deltaMs, speed }));
  const a = frame(one, 160, 220);
  for (let i = 0; i < 9; i++) frame(many, 16, 220);
  assert.deepEqual(a, frame(many, 16, 220));
  assert.ok(a.frame > 3, 'a normal-speed K1 should show a planted alternating stride over 35 world units');
});

test('movement leads with the stride, while a blade winds up and follows through on real cues', async () => {
  const { HeroFilmMotion, HERO_FILM } = await model();
  const state = new HeroFilmMotion();
  const step = (input = {}) => state.update(motion({ speed: 220, ...input }));
  const windup = aim(1, 'slash', -1, 112);
  assert.equal(step({ windup }).action, 'run');
  for (let i = 0; i < 4; i++) assert.equal(step().action, 'run');
  const lead = step();
  assert.equal(lead.action, 'slash');
  assert.ok(lead.frame < HERO_FILM.slash.cue);
  assert.equal(step({ release: aim(1,'slash',-1) }).frame, HERO_FILM.slash.cue);
  assert.equal(step({ deltaMs: 80 }).action, 'run');
});

test('fast moving shots visibly recoil between releases without restarting a full planted attack', async () => {
  const { HeroFilmMotion, HERO_FILM } = await model();
  const state = new HeroFilmMotion();
  const step = (input = {}) => state.update(motion({ speed: 220, ...input }));
  assert.equal(step({ windup: aim(1, 'shoot', 1, 100) }).action, 'run');
  assert.equal(step({ release: aim(1) }).frame, HERO_FILM.shoot.cue);
  assert.ok(step({deltaMs:32}).frame > HERO_FILM.shoot.cue, 'recoil should follow, not stick on contact');
  assert.equal(step({deltaMs:24}).action, 'run');
  assert.equal(step({release: aim(2)}).frame, HERO_FILM.shoot.cue);
});

test('measured support boots are grounded while the airborne phase stays visible', async () => {
  const { getHeroFilmGroundOffset } = await model();
  assert.ok(getHeroFilmGroundOffset('run', 2) < -.02, 'overshooting support foot should move back up to the shadow line');
  assert.equal(getHeroFilmGroundOffset('run', 0), 0, 'do not artificially plant the lead boot in the air');
  assert.equal(getHeroFilmGroundOffset('shoot', 6), 0, 'a calibrated muzzle must not be moved by the gait');
});
