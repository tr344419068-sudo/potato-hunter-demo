import assert from 'node:assert/strict';
import test from 'node:test';
import {build} from 'esbuild';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const api=build({stdin:{contents:`
export {GameScene} from './src/scenes/GameScene.ts';
export {CampaignDirector} from './src/campaign/CampaignModel.ts';
export {RunTelemetry} from './src/campaign/RunTelemetry.ts';
export {SkillManager} from './src/managers/SkillManager.ts';
export {DeathSystem} from './src/systems/DeathSystem.ts';
export {SpawnSystem} from './src/systems/SpawnSystem.ts';
export {MapEventSystem} from './src/systems/MapEventSystem.ts';
export {BossSystem} from './src/systems/BossSystem.ts';
export {AutoAttackSystem} from './src/systems/AutoAttackSystem.ts';
export {ProjectileCollisionSystem} from './src/systems/ProjectileCollisionSystem.ts';
export {ExperienceSystem} from './src/systems/ExperienceSystem.ts';
export {mapAudioEvent} from './src/audio/CombatAudioModel.ts';
export {MonsterContactSystem} from './src/systems/MonsterContactSystem.ts';
export {MonsterBehaviorSystem} from './src/systems/MonsterBehaviorSystem.ts';
export {MonsterAISystem} from './src/systems/MonsterAISystem.ts';
export {AoeWarningSystem} from './src/systems/AoeWarningSystem.ts';
export {EnemyProjectileSystem} from './src/systems/EnemyProjectileSystem.ts';
export {StatusEffectSystem} from './src/systems/StatusEffectSystem.ts';
export {RewardManager} from './src/managers/RewardManager.ts';
export {ConfigManager} from './src/managers/ConfigManager.ts';
export {EventBus} from './src/managers/EventBus.ts';
export {createPlayer,createMonster,createMapEvent,createExperienceOrb} from './src/entities/factories.ts';
`,resolveDir:root,loader:'ts'},bundle:true,minify:true,platform:'node',format:'esm',write:false,plugins:[{name:'headless-campaign',setup(c){
c.onResolve({filter:/^phaser$/},()=>({path:'phaser',namespace:'stub'}));
c.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:`import EventEmitter from 'eventemitter3'; export default {Scene:class{},Events:{EventEmitter},Display:{Color:{HexStringToColor:v=>({color:parseInt(v.slice(1),16)})}},Utils:{Array:{Shuffle:a=>a}},Math:{Clamp:(v,a,b)=>Math.min(b,Math.max(a,v)),Between:(a,b)=>a,FloatBetween:(a,b)=>a}};`,resolveDir:root}));
}}]}).then(r=>import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));
let runSerial=0;
async function fixture(){const a=await api;a.EventBus.removeAllListeners();const g=new a.GameScene();g.runId=`fixture-${++runSerial}`;g.playerId=a.createPlayer(g.world,0,0,220,100,145);g.cameras={main:{width:1280,height:720}};g.scene={restart(){}};g.campaign=new a.CampaignDirector(42);g.telemetry=new a.RunTelemetry(42);return {...a,g};}
test('meadow elite gives a single respite without adding any health or healing pickup', async () => {
 const f = await fixture(), g = f.g, w = g.world;
 g.runStage = 'meadow'; g.stats.elapsedMs = 60_000;
 const killElite = () => {
   g.updateCampaign(g.createRuntime());
   const [elite] = [...w.components.monsters].find(([,m]) => m.bossKind === 'intermediate');
   w.components.health.get(elite).current = 0;
   new f.DeathSystem().update(16, g.createRuntime());
 };
 w.components.health.get(g.playerId).current = 75;
 killElite();
 assert.equal(w.components.mapEvents.size, 0);
 assert.equal(w.components.health.get(g.playerId).current, 75);
 assert.equal(g.createRuntime().campaign.spawnMultiplier, .38);
 assert.equal(g.choosingSkill, false);
 g.paused = true; g.update(0, 1000); assert.equal(g.stats.elapsedMs, 60_000);
 g.paused = false; g.stats.elapsedMs = 69_000;
 assert.equal(g.createRuntime().campaign.spawnMultiplier, 1.08);
 g.stats.elapsedMs = 110_000; killElite(); assert.equal(w.components.mapEvents.size, 0);
});
test('campaign runtime carries the run-snapshot training bonuses and settlement stage',async()=>{
 const {g,EventBus}=await fixture();g.trainingBonuses={damageMultiplier:1.08,maxHp:16,pickupRadius:24};g.runStage='meadow';
 assert.deepEqual(g.createRuntime().campaign.training,{maxHp:16,pickupRadius:24});
 let result;EventBus.on('game:over',r=>result=r);g.stats.elapsedMs=360000;g.stats.kills=10;g.stats.bossKills=1;g.endRun('victory');
 assert.equal(result.stage,'meadow');assert.equal(result.settlement.firstClearBonus,40);
});
test('selected starter replaces implicit peeler, and its first upgrade is real rank2',async()=>{
 const {SkillManager}=await api;const m=new SkillManager({starterSkillId:'pepper_gatling',enforceSlots:true});
 assert.deepEqual(m.getWeaponProfiles().map(p=>p.skillId),['pepper_gatling']);assert.equal(m.getLevel('pepper_gatling'),1);
 m.levelUp('pepper_gatling');assert.equal(m.getLevel('pepper_gatling'),2);assert.ok(m.getWeaponProfiles()[0].damage>7);
 const legacy=new SkillManager();assert.equal(legacy.getWeaponProfiles()[0].skillId,'peeler_blade');
});
test('active capacity rejects new seventh weapon while allowing upgrades and evolution replacement',async()=>{
 const {SkillManager}=await api;const m=new SkillManager({starterSkillId:'peeler_blade',enforceSlots:true});
 for(const id of ['fire_potato','frost_chips','thunder_potato','corn_burst','ketchup_aura'])m.levelUp(id);
 assert.equal(m.levelUp('starch_bomb'),0);assert.equal(m.levelUp('fire_potato'),2);m.levelUp('fork_splitter');m.levelUp('inferno_pierce');
 assert.ok(!m.getWeaponProfiles().some(p=>p.skillId==='fire_potato'));assert.ok(m.getWeaponProfiles().some(p=>p.skillId==='inferno_pierce'));
 assert.ok(m.getChoices(10).every(s=>s.category==='reward'||m.canLearnSkill(s.id)));
});
test('real scene home and pause stop combat time and all gameplay systems',async()=>{
 const {g}=await fixture();let ticks=0;g.systems=[{update(){ticks++}}];g.atHome=true;g.update(0,16);
 assert.equal(g.stats.elapsedMs,0);assert.equal(ticks,0);g.atHome=false;g.paused=true;g.update(0,16);assert.equal(ticks,0);
 g.paused=false;g.update(0,16);assert.equal(ticks,1);assert.equal(g.stats.elapsedMs,16);
});
test('production campaign spawns one tracked final boss and suppresses the legacy timed boss',async()=>{
 const f=await fixture();f.g.stats.elapsedMs=360000;assert.equal(typeof f.g.updateCampaign,'function');
 f.g.updateCampaign(f.g.createRuntime());f.g.updateCampaign(f.g.createRuntime());
 assert.equal([...f.g.world.components.monsters.values()].filter(m=>m.isBoss).length,1);
 const [id,monster]=[...f.g.world.components.monsters].find(([,monster])=>monster.isBoss);
 assert.equal(monster.bossKind,'final');assert.equal(f.g.world.components.renders.get(id).assetId,'boss_burger_tyrant_v4');
 new f.SpawnSystem().update(16,f.g.createRuntime());assert.equal([...f.g.world.components.monsters.values()].filter(m=>m.isBoss).length,1);
});
test('desert final boss has its own asset and name without changing meadow',async()=>{
 const f=await fixture(),g=f.g;g.runStage='desert';g.stats.elapsedMs=360000;g.updateCampaign(g.createRuntime());
 const [id]=[...g.world.components.monsters].find(([,m])=>m.bossKind==='final');
 assert.equal(g.world.components.renders.get(id).assetId,'boss_desert_sultan');
 assert.equal(g.getBossHudData().name,'沙海堡垒之王');
});
test('finale stops ordinary spawns and requires both the final boss and remaining enemies to be defeated',async()=>{
 const f=await fixture(), g=f.g, w=g.world;g.stats.elapsedMs=360000;
 g.updateCampaign(g.createRuntime());
 const final=[...w.components.monsters].find(([,m])=>m.bossKind==='final')[0];
 const other=f.createMonster(w,f.ConfigManager.monsters[0],40,0);
 const count=w.components.monsters.size;
 new f.SpawnSystem().update(1000,g.createRuntime());assert.equal(w.components.monsters.size,count);
 const results=[];f.EventBus.on('game:over',v=>results.push(v));
 const runtime=g.createRuntime(),health=w.components.health.get(final);
 const death=new f.DeathSystem(),boss=new f.BossSystem(),aoe=new f.AoeWarningSystem();
 health.current=0;death.update(16,runtime);
 assert.ok(w.components.monsters.has(final),'lethal damage may not bypass the first phase');
 for(let tick=0;tick<200&&health.current>0;tick++){
  boss.update(100,runtime);aoe.update(100,runtime);health.current=0;
 }
 assert.equal(health.current,0);
 death.update(16,runtime);assert.equal(results.length,0);
 assert.equal(g.campaign.hasDefeatedFinalBoss(),true);
 w.components.health.get(other).current=0;death.update(16,g.createRuntime());
 assert.equal(results.length,1);assert.equal(results[0].outcome,'victory');
});
test('distant remaining flankers return toward the player after the final boss dies',async()=>{
 const f=await fixture(),g=f.g,w=g.world;
 const enemy=f.createMonster(w,f.ConfigManager.getMonster('onion_flanker'),5000,0);
 g.campaign.registerBoss(900,'final');g.campaign.onMonsterDefeated(900,true,1);
 new f.MonsterAISystem().update(16,g.createRuntime());
 const velocity=w.components.velocities.get(enemy);
 assert.ok(velocity.x < -400, `expected fast direct return, got ${velocity.x}`);
 assert.equal(velocity.y,0);
 assert.equal(w.components.transforms.get(enemy).x,5000,'catch-up does not teleport into view');
});
test('distant intermediate bosses also return after the final boss dies',async()=>{
 const f=await fixture(),g=f.g,w=g.world;
 const enemy=f.createMonster(w,f.ConfigManager.getMonster('onion_flanker'),5000,0,true);
 w.components.monsters.get(enemy).bossKind='intermediate';
 g.campaign.registerBoss(900,'final');g.campaign.onMonsterDefeated(900,true,1);
 new f.MonsterAISystem().update(16,g.createRuntime());
 const velocity=w.components.velocities.get(enemy);
 assert.ok(velocity.x < -400, `expected fast direct return for the remaining boss, got ${velocity.x}`);
 assert.equal(velocity.y,0);
 assert.equal(w.components.transforms.get(enemy).x,5000,'catch-up does not teleport into view');
});
test('actual final-boss DeathSystem triggers victory once, ordinary boss deaths do not',async()=>{
 const f=await fixture();const world=f.g.world;const first=f.createMonster(world,f.ConfigManager.monsters[0],100,0,true);
 f.g.campaign.registerBoss(first,'intermediate');world.components.health.get(first).current=0;
 const death=new f.DeathSystem();death.update(16,f.g.createRuntime());assert.equal(f.g.gameOver,false);
 const final=f.createMonster(world,f.ConfigManager.monsters[0],100,0,true);f.g.campaign.registerBoss(final,'final');
 world.components.health.get(final).current=0;let results=[];f.EventBus.on('game:over',v=>results.push(v));
 death.update(16,f.g.createRuntime());death.update(16,f.g.createRuntime());assert.equal(f.g.gameOver,true);
 assert.equal(results.length,1);assert.equal(results[0].outcome,'victory');assert.equal(f.g.campaign.outcome,'victory');
});
test('reroll creates a fresh session without spending XP credit or awarding HP',async()=>{
 const {g,EventBus}=await fixture();let choices=[];EventBus.on('level:choices',p=>choices.push(p));g.requestSkillChoice([]);
 const hp={...g.world.components.health.get(g.playerId)};const session=choices[0].sessionId;
 assert.equal(typeof g.rerollUpgradeChoices,'function');g.rerollUpgradeChoices();assert.equal(g.pendingUpgrades,1);
 assert.ok(choices.at(-1).sessionId>session);assert.equal(g.rerollsRemaining,1);assert.deepEqual(g.world.components.health.get(g.playerId),hp);
 g.rerollUpgradeChoices();g.rerollUpgradeChoices();assert.equal(g.rerollsRemaining,0);assert.equal(choices.length,3);
});
test('abandon from pause settles actual elapsed run once as defeat',async()=>{
 const {g,EventBus}=await fixture();g.stats={elapsedMs:60000,kills:20,bossKills:1,gold:5};g.paused=true;let results=[];EventBus.on('game:over',r=>results.push(r));
 assert.equal(typeof g.abandonCampaign,'function');g.abandonCampaign();g.abandonCampaign();assert.equal(results.length,1);assert.equal(results[0].outcome,'defeat');assert.equal(results[0].settlement.awarded,33);assert.equal(results[0].settlement.duplicate,false);
});
test('dead player never receives campaign rescue and cannot win simultaneously with final boss',async()=>{
 const f=await fixture();f.g.stats.elapsedMs=360000;f.g.world.components.health.get(f.g.playerId).current=0;
 f.g.updateCampaign(f.g.createRuntime());assert.equal(f.g.world.components.mapEvents.size,0);
 const final=[...f.g.world.components.monsters.keys()][0];f.g.world.components.health.get(final).current=0;new f.DeathSystem().update(16,f.g.createRuntime());assert.notEqual(f.g.campaign.outcome,'victory');
});
test('recovery rewards and map pickups never resurrect a dead player',async()=>{
 const f=await fixture(),runtime=f.g.createRuntime(),health=f.g.world.components.health.get(f.g.playerId);health.current=0;
 f.RewardManager.applyReward(runtime,{id:'heal',kind:'heal',value:25,text:'回复'});assert.equal(health.current,0);
 f.createMapEvent(f.g.world,{id:'campaign_rescue',name:'急救',kind:'heal',value:25,radius:22,color:0x93d378,lifetimeMs:20000,spawnAfterSeconds:0,intervalSeconds:0},0,0);new f.MapEventSystem().collectEvents(runtime);assert.equal(health.current,0);
});
test('final boss and simultaneously dead elite bomb finish together, defeat wins and terminal stats are complete',async()=>{
 const f=await fixture();f.g.stats.elapsedMs=360000;const world=f.g.world;const final=f.createMonster(world,f.ConfigManager.monsters[0],100,0,true);f.g.campaign.nextBoss(360000);f.g.campaign.registerBoss(final,'final');
 const bomb=f.createMonster(world,f.ConfigManager.monsters[0],0,0);Object.assign(world.components.monsters.get(bomb),{isElite:true,eliteAffix:'death_bomb',damage:90});world.components.health.get(final).current=0;world.components.health.get(bomb).current=0;world.components.health.get(f.g.playerId).current=10;let result;f.EventBus.on('game:over',r=>result=r);f.g.systems=[new f.DeathSystem(),new f.MonsterContactSystem()];f.g.update(0,16);assert.equal(result.outcome,'defeat');assert.equal(result.kills,2);assert.equal(result.bossKills,1);assert.ok(result.telemetry.damageBySource.DeathSystem>=10);
});
test('chosen pepper does not fabricate peeler in HUD or new acquisition ranks',async()=>{
 const f=await fixture();const manager=seed=>{const d=new f.CampaignDirector(seed);return new f.SkillManager({starterSkillId:'pepper_gatling',enforceSlots:true,random:d.random.bind(d)})};const seed=Array.from({length:100},(_,i)=>i+1).find(seed=>manager(seed).getChoices(3).some(c=>c.id==='peeler_blade'));assert.ok(seed);f.g.skillManager=manager(seed);let hud,offer;f.EventBus.on('hud:update',p=>hud=p);f.EventBus.on('level:choices',p=>offer=p);f.g.emitHud(16);assert.deepEqual(hud.skills.map(s=>s.id),['pepper_gatling']);f.g.requestSkillChoice([]);assert.equal(offer.levels.peeler_blade,0);f.g.handleSkillSelected({skillId:'peeler_blade',sessionId:offer.sessionId});assert.equal(f.g.skillManager.getLevel('peeler_blade'),1);
});
test('real lethal contact is included in the report emitted at settlement',async()=>{
 const f=await fixture();f.g.stats.elapsedMs=60000;const monster=f.createMonster(f.g.world,f.ConfigManager.monsters[0],0,0);f.g.world.components.monsters.get(monster).damage=50;f.g.world.components.health.get(f.g.playerId).current=10;f.g.systems=[new f.MonsterContactSystem()];let result;f.EventBus.on('game:over',r=>result=r);f.g.update(0,16);assert.equal(result.outcome,'defeat');assert.equal(result.telemetry.damageBySource.MonsterContactSystem,10);
});
test('pause and automatic chooser freeze authored presentation clocks as well as gameplay',async()=>{
 const {g}=await fixture();const deltas=[];g.renderSystem={update(dt){deltas.push(dt)}};g.paused=true;g.update(0,16);g.paused=false;g.choosingSkill=true;g.update(0,16);assert.deepEqual(deltas,[0,0]);g.choosingSkill=false;g.update(0,16);assert.equal(deltas.at(-1),16);
});
test('valid offered healing upgrade records actual restored HP once, including max-HP clamp',async()=>{
 const f=await fixture();f.g.campaign=new f.CampaignDirector(1);f.g.skillManager=new f.SkillManager({starterSkillId:'peeler_blade',enforceSlots:true,random:f.g.campaign.random.bind(f.g.campaign)});
 for(const skill of f.ConfigManager.skills.filter(s=>s.category!=='evolution'))for(let i=0;i<skill.maxLevel;i++)f.g.skillManager.levelUp(skill.id);
 const health=f.g.world.components.health.get(f.g.playerId);health.current=80;health.max=100;let offer;
 f.EventBus.on('level:choices',p=>offer=p);f.g.requestSkillChoice([]);for(let i=0;i<2&&!offer.choices.some(c=>c.id==='reward_heal');i++)f.g.rerollUpgradeChoices();
 assert.ok(offer.choices.some(c=>c.id==='reward_heal'));const selection={skillId:'reward_heal',sessionId:offer.sessionId};f.g.handleSkillSelected(selection);f.g.handleSkillSelected(selection);
 assert.equal(health.current,100);assert.equal(f.g.telemetry.getReport().healing,20);
});
test('actual attacks, boss warnings and collected supplies carry actionable audio metadata, generic notices stay silent',async()=>{
 const f=await fixture(),runtime=f.g.createRuntime(),fired=[],warnings=[],collected=[];
 f.EventBus.on('weapon:fired',p=>fired.push(p));f.EventBus.on('boss:phase',p=>warnings.push(p));f.EventBus.on('reward:collected',p=>collected.push(p));
 f.g.skillManager=new f.SkillManager({starterSkillId:'pepper_gatling',enforceSlots:true});f.createMonster(f.g.world,f.ConfigManager.monsters[0],100,0,true);
 new f.AutoAttackSystem().update(16,f.g.createRuntime());assert.equal(fired[0].skillId,'pepper_gatling');assert.deepEqual(f.mapAudioEvent('weapon:fired',fired[0]),['launch-rapid']);
 new f.BossSystem().update(5000,runtime);assert.ok(warnings.some(p=>f.mapAudioEvent('boss:phase',p).includes('boss-danger')));
 f.RewardManager.applyReward(runtime,{id:'supply',kind:'heal',value:10,text:'战地急救'});assert.deepEqual(f.mapAudioEvent('boss:phase',warnings.at(-1)),[]);assert.deepEqual(f.mapAudioEvent('reward:collected',collected.at(-1)),['pickup']);
 f.createExperienceOrb(f.g.world,0,0,1);new f.ExperienceSystem().update(16,runtime);assert.equal(collected.at(-1).kind,'experience');
});
test('normal campaign cannot mutate elapsed time or delete tracked finale through debug entry points',async()=>{
 const f=await fixture();f.g.stats.elapsedMs=360000;f.g.updateCampaign(f.g.createRuntime());const monsters=f.g.world.components.monsters.size;
 f.g.addDebugTime(60000);f.g.clearMonsters();f.g.spawnBossNow();assert.equal(f.g.stats.elapsedMs,360000);assert.equal(f.g.world.components.monsters.size,monsters);
});
test('slow visible frames preserve campaign time through bounded simulation slices without running through a chooser',async()=>{
 const {g}=await fixture(),steps=[];g.systems=[{update(dt){steps.push(dt)}}];for(let i=0;i<20;i++)g.update(0,50);
 assert.equal(g.stats.elapsedMs,1000);assert.ok(steps.every(dt=>dt>0&&dt<=40));g.stats.elapsedMs=0;g.systems=[{update(){g.choosingSkill=true}}];g.update(0,100);assert.equal(g.stats.elapsedMs,40);
 g.choosingSkill=false;g.systems=[];const before=g.stats.elapsedMs;g.update(0,NaN);g.update(0,-10);assert.equal(g.stats.elapsedMs,before);g.update(0,5000);assert.equal(g.stats.elapsedMs,before+250);
});
test('postponing and reopening a credit cannot bypass the two-reroll budget or redraw during pause',async()=>{
 const {g,EventBus,SkillManager}=await fixture(),offers=[];g.skillManager=new SkillManager({starterSkillId:'peeler_blade',enforceSlots:true,random:g.campaign.random.bind(g.campaign)});EventBus.on('level:choices',p=>offers.push(p));g.requestSkillChoice([]);g.rerollUpgradeChoices();g.rerollUpgradeChoices();const current=offers.at(-1),ids=current.choices.map(c=>c.id);
 for(let i=0;i<4;i++){g.cancelUpgradeChoices();g.openUpgradeChoices();assert.deepEqual(offers.at(-1).choices.map(c=>c.id),ids);assert.equal(g.rerollsRemaining,0);assert.equal(g.pendingUpgrades,1)}
 assert.ok(offers.at(-1).sessionId>current.sessionId);g.handleSkillSelected({skillId:ids[0],sessionId:current.sessionId});assert.equal(g.pendingUpgrades,1);
 g.cancelUpgradeChoices();g.paused=true;const count=offers.length;g.openUpgradeChoices();assert.equal(offers.length,count);assert.equal(g.choosingSkill,false);
});
test('reopening postponed choice refreshes authoritative HUD on its very next visible frame',async()=>{
 const {g,EventBus}=await fixture(),hud=[];g.systems=[];EventBus.on('hud:update',payload=>hud.push(payload));
 g.requestSkillChoice([]);g.cancelUpgradeChoices();g.update(0,16);assert.equal(hud.at(-1).choosingUpgrade,false);assert.equal(hud.at(-1).pendingUpgrades,1);
 const count=hud.length;g.openUpgradeChoices();g.update(0,16);assert.equal(hud.length,count+1);assert.equal(hud.at(-1).choosingUpgrade,true);
});
test('all hostile damage sources retain stable identity after production class-name minification',async()=>{
 const a=await api;
 for(const name of ['MonsterContactSystem','MonsterBehaviorSystem','AoeWarningSystem','EnemyProjectileSystem','DeathSystem','StatusEffectSystem']){
  const system=new a[name]();assert.notEqual(system.constructor.name,name,'fixture must actually minify constructors');assert.equal(system.telemetrySource,name);
 }
});
for(const grantXp of [false,true])test(`real final projectile kill does not skip same-step lethal contact${grantXp?' or let an earned chooser prevent damage resolution':''}`,async()=>{
 const f=await fixture(),g=f.g,w=g.world;g.stats.elapsedMs=360000;g.campaign.nextBoss(360000);
 const final=f.createMonster(w,f.ConfigManager.monsters[0],10,0,true);g.campaign.registerBoss(final,'final');w.components.health.get(final).current=1;
 w.components.monsters.get(final).experienceValue=grantXp?500:0;
 const contact=f.createMonster(w,f.ConfigManager.monsters[0],0,0);w.components.health.get(contact).current=100000;w.components.monsters.get(contact).damage=10000;w.components.health.get(g.playerId).current=1;
 let result,shots=0,offers=0;f.EventBus.on('weapon:fired',()=>shots++);f.EventBus.on('level:choices',()=>offers++);f.EventBus.on('game:over',r=>result=r);
 g.systems=[new f.AutoAttackSystem(),new f.ProjectileCollisionSystem(),new f.DeathSystem(),...(grantXp?[new f.ExperienceSystem()]:[]),new f.MonsterContactSystem()];g.update(0,16);
 assert.equal(shots,1);assert.equal(w.components.monsters.has(final),false);assert.equal(w.components.monsters.has(contact),true);assert.equal(result.outcome,'defeat');assert.equal(w.components.health.get(g.playerId).current,0);
 assert.ok(result.telemetry.damageBySource.MonsterContactSystem>=1);assert.equal(result.bossKills,1);assert.equal(g.pendingOutcome,undefined);assert.equal(g.choosingSkill,false);
 if(grantXp)assert.ok(offers>0,'the test must really open an earned chooser between death and contact');
});
test('surviving final-kill step includes contact and victory waits for the remaining enemy',async()=>{
 const f=await fixture(),g=f.g,w=g.world;g.stats.elapsedMs=360000;g.campaign.nextBoss(360000);
 const final=f.createMonster(w,f.ConfigManager.monsters[0],10,0,true);g.campaign.registerBoss(final,'final');w.components.health.get(final).current=1;w.components.monsters.get(final).experienceValue=0;
 const contact=f.createMonster(w,f.ConfigManager.monsters[0],0,0);w.components.health.get(contact).current=100000;w.components.monsters.get(contact).damage=7;const results=[];f.EventBus.on('game:over',r=>results.push(r));
 g.systems=[new f.AutoAttackSystem(),new f.ProjectileCollisionSystem(),new f.DeathSystem(),new f.MonsterContactSystem()];g.update(0,16);g.update(0,16);
 assert.equal(results.length,0);assert.equal(w.components.health.get(g.playerId).current,93);
 w.components.health.get(contact).current=0;g.update(0,16);g.update(0,16);
 assert.equal(results.length,1);assert.equal(results[0].outcome,'victory');assert.equal(results[0].telemetry.damageBySource.MonsterContactSystem,7);
});
