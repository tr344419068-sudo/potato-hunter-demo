"""Regression tests for grey-backed user glow extraction, not image generation."""
import importlib.util
from pathlib import Path
import unittest
import json
import subprocess
import sys
import tempfile
import numpy as np
from PIL import Image

SCRIPT = Path(__file__).with_name("process-user-halo.py")


class ExtractionTests(unittest.TestCase):
    def processor(self):
        self.assertTrue(SCRIPT.exists(), "user glow background processor is not implemented")
        spec = importlib.util.spec_from_file_location("user_halo", SCRIPT)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.extract_glow

    def test_grey_checker_and_small_rgb_noise_are_completely_transparent(self):
        y, x = np.indices((64, 64))
        value = np.where(((x // 8 + y // 8) % 2) == 0, 140, 200)
        a = np.stack([value, value + 1, value - 1], axis=2).astype(np.uint8)
        output = self.processor()(Image.fromarray(a, "RGB"))
        self.assertEqual(output.mode, "RGBA")
        self.assertEqual(output.getchannel("A").getextrema(), (0, 0))

    def test_green_cyan_and_white_highlights_survive_without_grey_floor(self):
        a = np.array([[[80, 255, 160], [100, 240, 255], [254, 254, 254], [150, 153, 150]]], dtype=np.uint8)
        out = np.asarray(self.processor()(Image.fromarray(a, "RGB")))
        self.assertGreater(out[0, 0, 1], out[0, 0, 0])
        self.assertGreater(out[0, 1, 2], out[0, 1, 0])
        self.assertGreater(out[0, 0, 3], 180)
        self.assertGreater(out[0, 2, 3], 200, "white star centers must not turn into dim holes")
        self.assertEqual(out[0, 3, 3], 0)

    def test_low_chroma_soft_glow_fades_smoothly(self):
        a = np.array([[[145, green, 145] for green in [150, 154, 160, 175, 200]]], dtype=np.uint8)
        alphas = np.asarray(self.processor()(Image.fromarray(a, "RGB")))[0, :, 3]
        self.assertEqual(alphas[0], 0)
        self.assertTrue(np.all(np.diff(alphas.astype(int)) > 0))

    def test_real_transparency_and_authored_color_are_preserved_exactly(self):
        source = Image.new("RGBA", (32, 32), (30, 240, 80, 0))
        source.putpixel((16, 16), (120, 255, 220, 128))
        output = self.processor()(source)
        self.assertEqual(output.tobytes(), source.tobytes())

    def test_named_ketchup_import_preserves_true_alpha_and_reports_no_extraction(self):
        with tempfile.TemporaryDirectory(prefix="ketchup-alpha-test-") as directory:
            base = Path(directory)
            source = Image.new("RGBA", (1024, 1024), (255, 35, 20, 0))
            source.putpixel((800, 512), (255, 170, 130, 128))
            source_path = base / "source.png"
            source.save(source_path)
            result = subprocess.run([sys.executable, str(SCRIPT), "--source", str(source_path), "--artifact-dir", str(base), "--output", str(base / "runtime.png"), "--name", "ketchup"], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            with Image.open(base / "ketchup-halo-prepared-1024.png") as prepared:
                self.assertEqual(prepared.tobytes(), source.tobytes())
            report = json.loads((base / "processing.json").read_text())
            self.assertEqual(report["processing"], "preserved source RGBA; Lanczos resize only")

    def test_archived_user_input_has_empty_center_and_nonempty_color_ring(self):
        path = Path(__file__).resolve().parent.parent / "artifacts/user-poison-halo-2026-11-18/source-original.png"
        with Image.open(path) as source:
            output = self.processor()(source)
        a = np.asarray(output)
        self.assertEqual(a[350:674, 350:674, 3].max(), 0)
        self.assertEqual(a[:50, :50, 3].max(), 0)
        self.assertGreater((a[..., 3] > 100).sum(), 30000)
        self.assertGreater(((a[..., 3] > 0) & (a[..., 3] < 255)).sum(), 20000)


if __name__ == "__main__":
    unittest.main()
