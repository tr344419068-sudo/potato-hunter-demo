"""Key and re-register selected frames from the original Shengong Moon Draw video."""

import argparse
import hashlib
import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image


CELL = (144, 192)
# Source frames / tracked horizontal anchors / final opacity. Video pans the
# wave right; engine flight replaces that travel. The source opens upward,
# so the affine transform rotates it to open behind its travel direction.
FRAMES = (
    (9, 948, .78), (11, 956, .96), (15, 955, 1), (22, 956, 1),
    (30, 959, 1), (39, 978, .99), (49, 1044, .97), (58, 1154, .94),
    (67, 1360, .86), (71, 1478, .72), (75, 1597, .43), (84, 1775, .24),
)
PALETTES = {
    "blue": (.555, .28, 5.6), "violet": (.75, .36, 4.2), "gold": (.105, .23, 3.3)
}


def extract(bgr, anchor, opacity):
    rgb = bgr[:, :, ::-1].astype(np.float32) / 255
    backdrop = np.median(rgb[:150:3, ::4].reshape(-1, 3), axis=0)
    r, g, b = rgb.transpose(2, 0, 1)
    spill = g - np.maximum(r, b)
    backdrop_spill = backdrop[1] - max(backdrop[0], backdrop[2])
    if backdrop_spill < .12:
        raise ValueError("Source backdrop is not a keyable green")
    alpha = np.clip(1 - (spill - .012) / (backdrop_spill - .035), 0, 1)
    # Retain feathered cyan wisps without a green matte at the edge.
    rgb = ((rgb - (1 - alpha[..., None]) * backdrop) / np.maximum(.05, alpha[..., None])).clip(0, 1)
    rgb[..., 1] = np.minimum(rgb[..., 1], np.maximum(rgb[..., 0], rgb[..., 2]) + .012)
    rgba = Image.fromarray((np.dstack((rgb, alpha * opacity)) * 255).round().astype(np.uint8))
    w, h = CELL
    keyed = rgba.transform(CELL, Image.Transform.AFFINE,
                           (0, -3.94, anchor + h * 1.97, 5.28, 0, 567 - w * 2.64),
                           resample=Image.Resampling.BICUBIC)
    values = np.array(keyed)
    yy, xx = np.mgrid[:h, :w]
    # Reject frame-edge noise and leave a fully transparent gutter for WebGL sampling.
    edge = np.minimum.reduce([yy, xx, h-1-yy, w-1-xx])
    values[..., 3] = (values[..., 3] * np.clip((edge - 1) / 8, 0, 1)).round().astype(np.uint8)
    values[values[..., 3] < 5] = 0
    return Image.fromarray(values)


def grade(frame, palette):
    hue, saturation_floor, hue_response = palette
    image = np.array(frame)
    rgb = image[..., :3].astype(np.float32) / 255
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    sat = hsv[..., 1]
    brightness = hsv[..., 2]
    # Bright elements retain a cool/neutral white core. Medium values take the
    # rank palette, while the darker translucent tail carries the richest color.
    blade = np.clip((1 - brightness) * hue_response, .04, .83)
    hsv[..., 0] = 360 * (hue + np.clip((brightness - .72) * .1, -.06, .028))
    hsv[..., 1] = np.clip(np.maximum(sat * .76, blade * saturation_floor) * (1 - .72*np.clip((brightness-.92)/.08, 0, 1)), 0, 1)
    hsv[..., 2] = np.clip(brightness * 1.08 + .015, 0, 1)
    image[..., :3] = (cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB) * 255).round().astype(np.uint8)
    image[image[..., 3] == 0] = 0
    return Image.fromarray(image)


def main(source, output, preview):
    capture = cv2.VideoCapture(str(source))
    if not capture.isOpened() or (capture.get(3), capture.get(4)) != (1920, 1080):
        raise ValueError("Expected the original 1920×1080 Shengong clip")
    frames = []
    for idx, anchor, opacity in FRAMES:
        capture.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ok, image = capture.read()
        if not ok:
            raise ValueError(f"Cannot decode source frame {idx}")
        frames.append(extract(image, anchor, opacity))
    capture.release()
    output.mkdir(parents=True, exist_ok=True)
    w, h = CELL
    review = Image.new("RGB", (3 * 180, 198), "#344445")
    for idx, (color, palette) in enumerate(PALETTES.items()):
        graded = [grade(frame, palette) for frame in frames]
        atlas = Image.new("RGBA", (w * 4, h * 3))
        for column, frame in enumerate(graded):
            if not frame.getchannel("A").getbbox():
                raise ValueError(f"Empty keyed frame: {column}")
            atlas.paste(frame, (column % 4 * w, column // 4 * h))
        atlas.save(output / f"{color}.webp", method=6, quality=80)
        review.paste(graded[4], (idx * 180 + 18, 3), graded[4])
        if color == "blue":
            icon = graded[4].rotate(-27, Image.Resampling.BICUBIC, expand=True)
            icon = icon.crop(icon.getbbox())
            icon.thumbnail((151, 160), Image.Resampling.LANCZOS)
            tile = Image.new("RGBA", (192, 192))
            tile.paste(icon, ((192 - icon.width) // 2, (192 - icon.height) // 2))
            tile.save(output / "icon.webp", method=6, quality=90)
    (output / "source.json").write_text(json.dumps({"provider": "神工", "model": "SeeDance2.5", "mode": "文生视频",
        "sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "frames": [f[0] for f in FRAMES],
        "frameWidth": w, "frameHeight": h, "columns": 4}, ensure_ascii=False, indent=2) + "\n")
    review.save(preview)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("preview", type=Path)
    args = parser.parse_args()
    main(args.source, args.output, args.preview)
