#!/usr/bin/env python3
"""Size already-transparent 神工 RemBg weapon exports without re-keying them."""
from math import atan2, cos, hypot, sin
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "artifacts/pepper-shengong"
OUTPUT = ROOT / "public/assets/weapons"
HERO = ROOT / "public/assets/characters/potato_hunter/articulated-v3"


def export_weapon(name, size, grip, muzzle):
    with Image.open(SOURCE / f"{name}-rembg.png") as image:
        if image.mode != "RGBA" or image.getchannel("A").getextrema() != (0, 255):
            raise ValueError(f"{name}: expected a real transparent RemBg export")
        bounds = image.getchannel("A").point(lambda alpha: 255 if alpha > 12 else 0).getbbox()
        sprite = image.crop(bounds).convert("RGBa")
        scale = min((size[0] - 8) / sprite.width, (size[1] - 8) / sprite.height)
        width, height = round(sprite.width * scale), round(sprite.height * scale)
        x, y = (size[0] - width) // 2, (size[1] - height) // 2
        result = Image.new("RGBA", size)
        result.paste(sprite.resize((width, height), Image.Resampling.LANCZOS).convert("RGBA"), (x, y))
        result.save(OUTPUT / f"pepper-{name}-shengong-v1.png", optimize=True)
        for label, (px, py) in [("grip", grip), ("muzzle", muzzle)]:
            nx = (x + (px - bounds[0]) * width / sprite.width) / size[0]
            ny = (y + (py - bounds[1]) * height / sprite.height) / size[1]
            print(f"{name} {label}: {nx:.4f}, {ny:.4f}")


def export_support_arm():
    # Map the empty right sleeve/glove to the original left shoulder and wrist.
    # This reuses the hero's pixels instead of creating a new illustration style.
    shoulder, seam = (201, 139), (92, 123)
    original, target = (28, 45), (-22, 18)
    angle = atan2(target[1], target[0]) - atan2(original[1], -original[0])
    inverse_scale = hypot(*original) / hypot(*target)
    a, b = -cos(angle) * inverse_scale, -sin(angle) * inverse_scale
    d, e = -sin(angle) * inverse_scale, cos(angle) * inverse_scale
    with Image.open(HERO / "right_arm.png") as arm:
        arm.convert("RGBA").convert("RGBa").transform(
            (256, 256), Image.Transform.AFFINE,
            (a, b, shoulder[0] - a * seam[0] - b * seam[1],
             d, e, shoulder[1] - d * seam[0] - e * seam[1]),
            resample=Image.Resampling.BICUBIC,
        ).convert("RGBA").save(OUTPUT / "pepper-support-arm-hero-v1.png", optimize=True)


if __name__ == "__main__":
    export_weapon("gatling", (208, 190), grip=(178, 758), muzzle=(934, 582))
    export_weapon("overdrive", (224, 164), grip=(184, 629), muzzle=(925, 438))
    export_support_arm()
