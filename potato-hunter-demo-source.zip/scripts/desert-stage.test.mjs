import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';
import { createCanvas, loadImage } from '@napi-rs/canvas';
const root = fileURLToPath(new URL('../', import.meta.url));
const api = build({ stdin: { contents: `export { WaveManager } from './src/managers/WaveManager.ts'; export { ConfigManager } from './src/managers/ConfigManager.ts'; export { getLevelChapter } from './src/managers/LevelChapterModel.ts'; export { getBattlefieldAssetId } from './src/progression/CampaignGrowth.ts'; export { getCharacterWalkRig } from './src/systems/CharacterWalkModel.ts';`, resolveDir: root, loader: 'ts' }, bundle: true, platform: 'node', format: 'esm', write: false }).then(r => import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));

test('desert gets exclusive cactus and scorpion enemies with articulated gait', async () => {
  const { WaveManager, ConfigManager, getCharacterWalkRig } = await api;
  const desert = new WaveManager('desert'), meadow = new WaveManager('meadow');
  for (const [time, id, asset] of [[45_000,'desert_cactus','enemy_desert_cactus'], [110_000,'desert_scorpion','enemy_desert_scorpion']]) {
    assert.ok(desert.getCurrentWave(time).monsterMix.some(entry => entry.monsterId === id));
    assert.ok(!meadow.getCurrentWave(time).monsterMix.some(entry => entry.monsterId === id));
    assert.equal(ConfigManager.getMonster(id).assetId,asset);
    assert.ok(getCharacterWalkRig(asset));
  }
});

test('desert uses its own sand visual and chapter descriptions', async () => {
  const { getBattlefieldAssetId, getLevelChapter, ConfigManager } = await api;
  assert.equal(getBattlefieldAssetId('meadow'), 'background_battlefield_grassland');
  assert.equal(getBattlefieldAssetId('desert'), 'background_battlefield_desert');
  assert.match(ConfigManager.assets[getBattlefieldAssetId('desert')].path, /desert_tile-v2\.webp$/);
  assert.equal(getLevelChapter(0, 'desert').title, '香料沙海');
  assert.notEqual(getLevelChapter(40_000, 'desert').title, getLevelChapter(40_000, 'meadow').title);
});

test('desert ground is a subdued, seamless tile rather than a high-frequency pattern', async () => {
  async function measure(name) {
    const image = await loadImage(fileURLToPath(new URL(`../public/assets/backgrounds/${name}`, import.meta.url)));
    const canvas = createCanvas(image.width, image.height);
    const context = canvas.getContext('2d');
    context.drawImage(image, 0, 0);
    const pixels = context.getImageData(0, 0, image.width, image.height).data;
    let sum = 0, squares = 0, count = 0;
    for (let index = 0; index < pixels.length; index += 4) {
      const light = pixels[index] * .2126 + pixels[index + 1] * .7152 + pixels[index + 2] * .0722;
      sum += light; squares += light * light; count++;
    }
    return { image, pixels, std: Math.sqrt(squares / count - (sum / count) ** 2) };
  }
  const original = await measure('desert_tile-v1.webp');
  const revised = await measure('desert_tile-v2.webp');
  assert.equal(revised.image.width, 512);
  assert.equal(revised.image.height, 512);
  assert.ok(revised.std < original.std * .8, `revised contrast ${revised.std} remains too strong`);
  assert.ok(revised.std > .4, 'sand should retain some texture');
  let edgeDifference = 0;
  for (let i = 0; i < 512; i++) for (let channel = 0; channel < 3; channel++) {
    edgeDifference += Math.abs(revised.pixels[(i * 512) * 4 + channel] - revised.pixels[(i * 512 + 511) * 4 + channel]);
    edgeDifference += Math.abs(revised.pixels[i * 4 + channel] - revised.pixels[(511 * 512 + i) * 4 + channel]);
  }
  assert.ok(edgeDifference / (512 * 6) < 2, 'tile edges should meet without visible seams');
});

test('desert introduces its own ranged and flanking roster without changing meadow', async () => {
  const { WaveManager, ConfigManager } = await api;
  const meadow = new WaveManager('meadow');
  const desert = new WaveManager('desert');
  for (const elapsed of [15_000, 45_000, 110_000, 220_000]) {
    const base = meadow.getCurrentWave(elapsed);
    const next = desert.getCurrentWave(elapsed);
    assert.notDeepEqual(next.monsterMix, base.monsterMix);
    assert.ok(next.monsterMix.some(entry => entry.monsterId === 'desert_cactus' || entry.monsterId === 'desert_scorpion'));
    for (const entry of next.monsterMix) assert.ok(ConfigManager.monsters.some(monster => monster.id === entry.monsterId));
    assert.ok(next.spawnIntervalMs > 0 && Number.isFinite(next.spawnIntervalMs));
    assert.ok(next.maxAlive <= base.maxAlive * 1.15);
  }
});

test('desert specialist replacement transitions gradually rather than changing at once', async () => {
  const { WaveManager } = await api;
  const desert = new WaveManager('desert');
  const weight = (elapsed, id) => desert.getCurrentWave(elapsed).monsterMix.find(entry => entry.monsterId === id)?.weight ?? 0;
  assert.ok(Math.abs(weight(23_999, 'desert_scorpion') - weight(24_001, 'desert_scorpion')) < .005);
  assert.ok(weight(27_000, 'desert_scorpion') > weight(24_000, 'desert_scorpion'));
  assert.ok(weight(30_000, 'desert_scorpion') > weight(27_000, 'desert_scorpion'));
  assert.ok(weight(30_000, 'desert_cactus') >= .08, 'the fan-shot role remains after flanks arrive');
});

test('new desert portraits have transparent edges and visible content', async () => {
  const { ConfigManager } = await api;
  for (const id of ['enemy_desert_cactus', 'enemy_desert_scorpion', 'boss_desert_sultan']) {
    const asset = ConfigManager.assets[id];
    const image = await loadImage(fileURLToPath(new URL(`../public/${asset.path}`, import.meta.url)));
    assert.equal(image.width, asset.width); assert.equal(image.height, asset.height);
    const canvas = createCanvas(image.width, image.height), context = canvas.getContext('2d');
    context.drawImage(image, 0, 0);
    const pixels = context.getImageData(0, 0, image.width, image.height).data;
    assert.equal(pixels[3], 0, `${id} needs a transparent corner`);
    let opaque = 0; for (let i = 3; i < pixels.length; i += 4) if (pixels[i] > 128) opaque++;
    assert.ok(opaque > image.width * image.height * .1 && opaque < image.width * image.height * .85, `${id} needs visible isolated artwork`);
  }
});
