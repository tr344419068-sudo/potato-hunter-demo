"""Prepare user-supplied hollow halo textures without generating new artwork.

This is local approximate matte preparation, NOT AI generation and NOT recovery
of the absent original alpha. Grey backgrounds cancel through channel differences;
bright white accents are retained separately. Existing true alpha is preserved.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image


def extract_glow(source):
    if "A" in source.getbands() and source.getchannel("A").getextrema()[0] < 255:
        return source.convert("RGBA").copy()
    rgb = np.asarray(source.convert("RGB"), dtype=np.float32)
    low = rgb.min(axis=2)
    high = rgb.max(axis=2)
    chroma = high - low
    # Actual empty areas measure <=5/255 chroma, <=219/255 brightness. Use a
    # continuous gate above that floor; never key individual checker colors.
    confidence = np.clip((chroma - 6.0) / 18.0, 0.0, 1.0)
    confidence = confidence * confidence * (3.0 - 2.0 * confidence)
    white = np.clip((high - 220.0) * 10.0, 0.0, 255.0) * (1.0 - .6 * confidence)
    emission = (rgb - low[..., None]) * 1.4 * confidence[..., None] + white[..., None]
    peak = emission.max(axis=2)
    # Soft glow stored as straight RGBA so Phaser's additive blend adds the
    # extracted emitted light, without double-darkening its transparent edges.
    straight = np.zeros_like(emission)
    np.divide(emission * 255.0, peak[..., None], out=straight, where=peak[..., None] > 0)
    rgba = np.concatenate((straight, np.minimum(peak, 255.0)[..., None]), axis=2)
    return Image.fromarray(np.rint(rgba).clip(0, 255).astype(np.uint8), "RGBA")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--artifact-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--name", choices=("poison", "ketchup"), default="poison")
    args = parser.parse_args()
    with Image.open(args.source) as image:
        source = image.copy()
    true_alpha = "A" in source.getbands() and source.getchannel("A").getextrema()[0] < 255
    prepared = extract_glow(source)
    runtime = prepared.resize((512, 512), Image.Resampling.LANCZOS)
    args.artifact_dir.mkdir(parents=True, exist_ok=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    prepared.save(args.artifact_dir / f"{args.name}-halo-prepared-1024.png")
    runtime.save(args.output)
    preview = Image.new("RGBA", runtime.size, (0, 0, 0, 255))
    preview.alpha_composite(runtime)
    preview.convert("RGB").save(args.artifact_dir / f"{args.name}-halo-black-preview.png")
    pixels = np.asarray(runtime)
    report = {
        "source": str(args.source),
        "sourceSha256": hashlib.sha256(args.source.read_bytes()).hexdigest(),
        "sourceMode": source.mode,
        "sourceSize": list(source.size),
        "output": str(args.output),
        "outputSha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
        "outputMode": runtime.mode,
        "outputSize": list(runtime.size),
        "centerMaxAlpha": int(pixels[185:327, 185:327, 3].max()),
        "cornerMaxAlpha": int(pixels[:25, :25, 3].max()),
        "softAlphaPixels": int(((pixels[..., 3] > 0) & (pixels[..., 3] < 255)).sum()),
        "processing": "preserved source RGBA; Lanczos resize only" if true_alpha else "approximate luminous-color extraction above measured grey noise; no generated or painted replacement shapes",
        "authorship": "user-supplied image; no AI tool called by agent for this import",
    }
    (args.artifact_dir / "processing.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
