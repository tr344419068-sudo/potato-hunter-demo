"""Downsample the approved local K1 action atlases for the game, cell by cell."""
import argparse
import json
from pathlib import Path

from PIL import Image


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='Folder of the 256px atlases and their JSON manifests')
    parser.add_argument('--output', type=Path, default=Path('public/assets/characters/hero-k1'))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for action in ('idle', 'walk', 'run', 'dash', 'shoot', 'slash', 'hit', 'down'):
        meta = json.loads((args.source / f'{action}.json').read_text())
        cols, count = meta['columns'], meta['frameCount']
        assert meta['cell'] == [256, 256] and meta['origin'] == [128, 205]
        with Image.open(args.source / meta['image']) as original:
            rows = (count + cols - 1) // cols
            assert original.mode == 'RGBA' and original.size == (cols * 256, rows * 256)
            export = Image.new('RGBA', (cols * 160, rows * 160))
            for idx in range(count):
                x, y = idx % cols, idx // cols
                cell = original.crop((x * 256, y * 256, (x + 1) * 256, (y + 1) * 256))
                export.paste(cell.resize((160, 160), Image.Resampling.LANCZOS), (x * 160, y * 160))
            path = args.output / f'{action}.webp'
            export.save(path, method=6, quality=58, alpha_quality=82)
            print(f'{action}: {export.width}x{export.height}, {count} frames, {path.stat().st_size:,} bytes')


if __name__ == '__main__':
    main()
