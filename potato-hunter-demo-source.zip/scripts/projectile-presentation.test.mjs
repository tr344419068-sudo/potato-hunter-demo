import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("projectiles retain their configured sprite and VFX family", async () => {
  const [factorySource, componentSource] = await Promise.all([
    readFile(new URL("../src/entities/factories.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/components/ComponentTypes.ts", import.meta.url), "utf8"),
  ]);

  assert.match(factorySource, /assetId:\s*projectileAssetId/);
  assert.match(factorySource, /vfxKind,/);
  assert.match(componentSource, /vfxKind\?:\s*CombatVfxKind/);
});

test("rendering grounds every character and gives enemy shots an outlined directional comet", async () => {
  const renderSource = await readFile(new URL("../src/systems/RenderSystem.ts", import.meta.url), "utf8");

  assert.match(renderSource, /drawCharacterShadow\(/);
  assert.match(renderSource, /getCharacterShadowProfile/);
  assert.match(renderSource, /drawEnemyProjectile\(/);
  assert.match(renderSource, /components\.enemyProjectiles\.has\(entityId\)/);
  assert.match(renderSource, /0xffffff/);
  assert.match(renderSource, /0x29132e/);
  assert.match(renderSource, /velocity\?\.x[^\n]*\/\s*speed/);
  assert.match(renderSource, /velocity\?\.y[^\n]*\/\s*speed/);
});
