import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { createCanvas, loadImage } from "@napi-rs/canvas";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
  export { World } from './src/entities/World';
  export * from './src/entities/factories';
  export { EventBus } from './src/managers/EventBus';
  export { SkillManager } from './src/managers/SkillManager';
  export { ConfigManager } from './src/managers/ConfigManager';
  export { AutoAttackSystem } from './src/systems/AutoAttackSystem';
  export { ProjectileCollisionSystem } from './src/systems/ProjectileCollisionSystem';
  export { getProjectileDrawPoint, getPepperCastOrigin } from './src/systems/WeaponPresentationModel';
  export { MovementSystem } from './src/systems/MovementSystem';
  export { LifetimeSystem } from './src/systems/LifetimeSystem';
  export { getHeroWeaponAction } from './src/systems/HeroFilmModel';
  export { SpriteJuiceSystem } from './src/systems/SpriteJuiceSystem';
  export { getCrescentFrame } from './src/systems/CrescentModel';
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless-weapons", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Scenes: { Events: { SHUTDOWN: "shutdown" } }, Display: { Color: { HexStringToColor: value => ({ color: parseInt(value.slice(1), 16) }) } }, Math: { Clamp: (v,lo,hi)=>Math.min(hi,Math.max(lo,v)) } };', resolveDir: root }));
  }}],
}).then(result => import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString("base64")}`));

test('the Moon Draw upgrades widen, split and change color without creating off-scale extra shots', async () => {
  const { SkillManager, ConfigManager, getHeroWeaponAction, getCrescentFrame } = await modules;
  const skill = ConfigManager.skills.find(skill => skill.id === 'moon_draw');
  assert.ok(skill && skill.weapon && skill.choicePoolEnabled !== false, 'Moon Draw is not a draftable weapon');
  assert.equal(getHeroWeaponAction(skill.id), 'slash');
  const manager = new SkillManager({ stage: 'meadow', starterSkillId: skill.id, enforceSlots: true });
  const profiles = [];
  for (let rank = 1; rank <= 12; rank++) {
    profiles.push(manager.getWeaponProfiles().find(w => w.skillId === skill.id));
    if (rank === 2 || rank === 4) assert.match(manager.getChoiceHints([skill])[0].upgradeBenefit, rank === 2 ? /双紫刃/ : /三金刃/);
    if (rank < 12) manager.levelUp(skill.id);
  }
  assert.deepEqual(profiles.map(w => w.projectileCount), [1, 1, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3]);
  assert.ok(profiles.every((w, i) => !i || w.size > profiles[i - 1].size));
  assert.equal(new Set([profiles[0].color, profiles[2].color, profiles[4].color]).size, 3);
  assert.equal(new Set([profiles[0].projectileAssetId, profiles[2].projectileAssetId, profiles[4].projectileAssetId]).size, 3);
  assert.deepEqual([480, 240, 0].map(ms => getCrescentFrame(ms, 480)), [0, 6, 11]);
  const normalDraft = new SkillManager({ stage: 'meadow', starterSkillId: 'peeler_blade', enforceSlots: true, random: () => .37 });
  assert.ok(normalDraft.getChoices(100).some(c => c.id === skill.id));
  const firstFour = Array.from({ length: 4 }, () => normalDraft.getChoices(3));
  assert.ok(firstFour.every(choices => choices.every(c => c.id !== skill.id)), 'new route must not crowd out introductory routes');
  const alternateDraft = normalDraft.getChoices(3, new Set(firstFour[3].map(c => c.id)));
  assert.equal(alternateDraft[2]?.id, skill.id, 'a post-intro reroll can reliably reveal the new route');
  let seed = 38771;
  const alternatePool = new SkillManager({ stage: 'meadow', starterSkillId: 'peeler_blade', enforceSlots: true,
    random: () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 2 ** 32) });
  const offers = Array.from({ length: 15 }, () => alternatePool.getChoices(3));
  assert.ok(offers.slice(4).some(choices => choices[2]?.id === skill.id), 'regular drafts also surface Moon Draw without requiring reroll');
});

test('Moon Draw waits for its release cue, then sweeps sideways without double-hitting or clipping a distant lane', async () => {
  const a = await modules;
  const world = new a.World();
  const playerId = a.createPlayer(world, 100, 100, 210, 100, 100, 'char_potato_hunter');
  const skillManager = new a.SkillManager({ starterSkillId:'moon_draw', enforceSlots:true, stage:'meadow' });
  const runtime = { world, playerId, skillManager, random:()=>1 };
  const monster = (x,y) => a.createMonster(world, a.ConfigManager.getMonster('delivery_box'), x,y);
  const center = monster(250,100), wing = monster(252,145), miss = monster(256,205);
  const health = id => world.components.health.get(id).current;
  const [initialCenter, initialWing, initialMiss] = [health(center),health(wing),health(miss)];
  const attack = new a.AutoAttackSystem(), movement = new a.MovementSystem(), collision = new a.ProjectileCollisionSystem();
  const cues = [];
  const windup = e => { if (e.world === world) cues.push(e.skillId); };
  a.EventBus.on('weapon:windup',windup);
  try {
    attack.update(16,runtime);
    assert.deepEqual(cues,['moon_draw']);
    assert.equal(world.components.projectiles.size,0,'blade appeared before the windup');
    for(let i=0;i<20;i++) attack.update(16,runtime);
    assert.equal(world.components.projectiles.size,1);
    movement.update(420,runtime); collision.update(420,runtime);
    assert.ok(health(center)<initialCenter && health(wing)<initialWing,'the visible blade must cover a wider lane than its center');
    assert.equal(health(miss),initialMiss);
    const after = health(wing);
    collision.update(16,runtime);
    assert.equal(health(wing),after);
  } finally { a.EventBus.off('weapon:windup',windup); }
});

test('Moon Draw ships real alpha flipbooks with twelve distinct video-derived frames per palette', async () => {
  const dir = new URL('../public/assets/vfx/moon-draw-v1/', import.meta.url);
  const source = JSON.parse(await readFile(new URL('source.json', dir)));
  const registry = JSON.parse(await readFile(new URL('../src/configs/assets.json', import.meta.url)));
  assert.equal(source.provider, '神工');
  assert.equal(new Set(source.frames).size, 12);
  assert.match(source.sha256, /^[a-f0-9]{64}$/);
  for (const tone of ['blue', 'violet', 'gold']) {
    const asset = registry[`vfx_moon_draw_${tone}`];
    const image = await loadImage(await readFile(new URL(`${tone}.webp`, dir)));
    assert.deepEqual([image.width, image.height], [asset.width, asset.height]);
    assert.equal(asset.frameCount, 12);
    const context = createCanvas(image.width, image.height).getContext('2d');
    context.drawImage(image, 0, 0);
    const frames = new Set();
    for (let i = 0; i < asset.frameCount; i++) {
      const pixels = context.getImageData((i % 4) * asset.frameWidth, Math.floor(i / 4) * asset.frameHeight, asset.frameWidth, asset.frameHeight).data;
      assert.equal(pixels[3], 0, 'transparent corner');
      assert.ok(pixels.some((value, j) => j % 4 === 3 && value > 24), 'nonempty blade');
      frames.add(createHash('sha256').update(pixels).digest('hex'));
    }
    assert.equal(frames.size, 12);
  }
});

test('a mixed loadout keeps the Moon Draw pose through simultaneous shots', async () => {
  const a = await modules;
  const world = new a.World(), playerId = a.createPlayer(world, 100, 100, 210, 100, 100, 'char_potato_hunter');
  const juice = new a.SpriteJuiceSystem({ events: { once() {} } });
  const payload = { world, playerId, directionX: 1, directionY: 0 };
  const getHero = () => world.components.spriteJuices.get(playerId);
  const shoot = () => a.EventBus.emit('weapon:fired', { ...payload, directionX: -1, skillId: 'pepper_gatling' });
  try {
    shoot();
    juice.update(16, payload);
    a.EventBus.emit('weapon:windup', { ...payload, remainingMs: 190, skillId: 'moon_draw' });
    shoot();
    juice.update(16, payload);
    assert.deepEqual([getHero().heroWindup?.action, getHero().heroWindup?.priority], ['slash', true]);
    a.EventBus.emit('weapon:fired', { ...payload, skillId: 'moon_draw' });
    shoot();
    juice.update(16, payload);
    assert.equal(getHero().heroRelease?.action, 'slash');
    shoot();
    juice.update(16, payload);
    assert.equal(getHero().heroRelease?.action, 'slash');
    juice.update(160, payload);
    shoot();
    juice.update(16, payload);
    assert.equal(getHero().heroRelease?.action, 'shoot');
  } finally { juice.destroy(); }
});

test("both Pepper skills use the original skill icon and do not preload held-weapon art", async () => {
  const registry = JSON.parse(await readFile(new URL("../src/configs/assets.json", import.meta.url)));
  const { skills } = JSON.parse(await readFile(new URL("../src/configs/skills.json", import.meta.url)));
  for (const id of ["pepper_gatling", "pepper_overdrive"]) {
    const skill = skills.find(skill => skill.id === id);
    assert.equal(skill.iconAssetId, "icon_skill_fries_storm");
  }
  assert.equal(registry.icon_skill_fries_storm.path, "assets/icons/skills/fries_storm.png");
  assert.equal(Object.keys(registry).some(id => id.startsWith("weapon_pepper_")), false);
});

test("Pepper casts mirror around the hero and respect current facing for vertical shots", async () => {
  const { getPepperCastOrigin } = await modules;
  const right = getPepperCastOrigin(150, 190, 1, -1);
  const left = getPepperCastOrigin(150, 190, -1, 1);
  assert.ok(Math.abs(right.x + left.x - 300) < 1e-8);
  assert.equal(right.y, left.y);
  assert.deepEqual(getPepperCastOrigin(150, 190, 0, -1), left);
});

async function fire(skillId, enemyX = 250, enemyY = 100) {
  const api = await modules;
  const world = new api.World();
  const playerId = api.createPlayer(world, 100, 100, 210, 100, 100, "char_potato_hunter");
  const enemyId = api.createMonster(world, api.ConfigManager.getMonster("delivery_box"), enemyX, enemyY);
  const skillManager = new api.SkillManager({ starterSkillId: skillId, enforceSlots: true });
  const runtime = { world, playerId, skillManager, random: () => 1 };
  const shots = [], impacts = [];
  const attack = new api.AutoAttackSystem();
  const onShot = event => { if (event.world === world) shots.push(event); };
  const onImpact = event => impacts.push(event);
  api.EventBus.on("weapon:fired", onShot);
  api.EventBus.on("weapon:impact", onImpact);
  try {
    attack.update(16, runtime);
    const [projectileId, projectile] = [...world.components.projectiles][0];
    return { ...api, world, runtime, attack, enemyId, shots, impacts, projectileId, projectile, cleanup() {
      api.EventBus.off("weapon:fired", onShot); api.EventBus.off("weapon:impact", onImpact);
    } };
  } catch (error) {
    api.EventBus.off("weapon:fired", onShot); api.EventBus.off("weapon:impact", onImpact); throw error;
  }
}

test("Pepper shots have a dedicated sprite and visual muzzle without moving the collision spawn", async () => {
  const f = await fire("pepper_gatling");
  try {
    assert.deepEqual(f.world.components.transforms.get(f.projectileId), { x: 100, y: 100, radius: 6 });
    assert.equal(f.world.components.velocities.get(f.projectileId).x, 690);
    assert.equal(f.projectile.damage, 7);
    assert.equal(f.world.components.renders.get(f.projectileId).assetId, "projectile_pepper_gatling");
    const shot = f.shots[0];
    assert.equal(shot.x, 100);
    assert.ok(shot.muzzle.x > 125 && shot.muzzle.x < 138, "tracer starts near the hero's hand, not a removed barrel");
    assert.deepEqual(f.projectile.launchVisual.offset, { x: shot.muzzle.x - shot.x, y: shot.muzzle.y - shot.y });
    const spawn = f.world.components.transforms.get(f.projectileId);
    assert.deepEqual(f.getProjectileDrawPoint(spawn, f.projectile, f.projectile.lifetimeMs), shot.muzzle);
    assert.equal(f.getProjectileDrawPoint(spawn, f.projectile, f.projectile.lifetimeMs - 260), spawn);
  } finally { f.cleanup(); }
});

test("long skewer uses the hand for its visual release without changing its collision origin", async () => {
  const f = await fire("skewer_javelin");
  try {
    const spawn = f.world.components.transforms.get(f.projectileId);
    assert.equal(spawn.x, 100);
    const muzzle = f.shots[0].muzzle;
    assert.ok(muzzle && muzzle.x > spawn.x + 20);
    assert.deepEqual(f.getProjectileDrawPoint(spawn, f.projectile, f.projectile.lifetimeMs), muzzle);
  } finally { f.cleanup(); }
});

test("Overdrive keeps its four-shot burst and casts from the hand toward a left-side target", async () => {
  const f = await fire("pepper_overdrive", 10);
  try {
    assert.equal(f.world.components.renders.get(f.projectileId).assetId, "projectile_pepper_overdrive");
    assert.ok(f.shots[0].muzzle.x > 62 && f.shots[0].muzzle.x < 75);
    f.attack.update(64, f.runtime); assert.equal(f.shots.length, 1);
    f.attack.update(1, f.runtime); f.attack.update(65, f.runtime); f.attack.update(65, f.runtime);
    assert.equal(f.shots.length, 4);
  } finally { f.cleanup(); }
});

test("shield hit feedback starts at the incoming edge without modifying absorption", async () => {
  const f = await fire("pepper_gatling");
  try {
    const enemy = f.world.components.transforms.get(f.enemyId);
    const health = f.world.components.health.get(f.enemyId);
    const monster = f.world.components.monsters.get(f.enemyId);
    monster.shieldHp = 20;
    const projectile = f.world.components.transforms.get(f.projectileId);
    projectile.x = enemy.x - enemy.radius;
    new f.ProjectileCollisionSystem().update(16, f.runtime);
    assert.equal(monster.shieldHp, 13);
    assert.equal(health.current, health.max);
    assert.equal(f.impacts[0].material, "shield");
    assert.equal(f.impacts[0].skillId, "pepper_gatling");
    assert.equal(f.impacts[0].x, enemy.x - enemy.radius);
    monster.shieldHp = 0;
    f.attack.update(240, f.runtime);
    const [nextId] = f.world.components.projectiles.keys();
    f.world.components.transforms.get(nextId).x = enemy.x - enemy.radius;
    new f.ProjectileCollisionSystem().update(16, f.runtime);
    assert.equal(f.impacts[1].material, "body");
    assert.equal(health.current, health.max - 7);
  } finally { f.cleanup(); }
});

test("point-blank shots render a flash only and a frame that crosses the target center still hits the incoming edge", async () => {
  const f = await fire("pepper_gatling", 124);
  try {
    const enemy = f.world.components.transforms.get(f.enemyId);
    const spawn = f.world.components.transforms.get(f.projectileId);
    const visible = f.getProjectileDrawPoint(spawn, f.projectile, f.projectile.lifetimeMs);
    new f.MovementSystem().update(40, f.runtime);
    assert.ok(spawn.x > enemy.x, "exercise a frame that steps past the center");
    new f.ProjectileCollisionSystem().update(40, f.runtime);
    assert.equal(f.impacts[0].x, enemy.x - enemy.radius);
    assert.equal(visible, undefined);
    assert.ok(f.shots[0].muzzle);
  } finally { f.cleanup(); }
});

test("long-range tracers advance visibly each frame instead of hovering at the cast origin", async () => {
  const f = await fire("pepper_overdrive", 320);
  try {
    const spawn = f.world.components.transforms.get(f.projectileId);
    const movement = new f.MovementSystem(), lifetime = new f.LifetimeSystem();
    const advance = () => {
      movement.update(16, f.runtime); lifetime.update(16, f.runtime);
      return f.getProjectileDrawPoint(spawn, f.projectile, f.world.components.lifetimes.get(f.projectileId).remainingMs).x;
    };
    const previous = advance();
    assert.ok(advance() - previous >= 5, "the visual shot should make perceptible forward progress");
  } finally { f.cleanup(); }
});

test("projectiles retain their configured sprite and VFX family", async () => {
  const [factorySource, componentSource] = await Promise.all([
    readFile(new URL("../src/entities/factories.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/components/ComponentTypes.ts", import.meta.url), "utf8"),
  ]);

  assert.match(factorySource, /assetId:\s*projectileAssetId/);
  assert.match(factorySource, /vfxKind,/);
  assert.match(componentSource, /vfxKind\?:\s*CombatVfxKind/);
});

test("rendering grounds characters independently from hostile shot art", async () => {
  const renderSource = await readFile(new URL("../src/systems/RenderSystem.ts", import.meta.url), "utf8");

  assert.match(renderSource, /drawCharacterShadow\(/);
  assert.match(renderSource, /getCharacterShadowProfile/);
});
