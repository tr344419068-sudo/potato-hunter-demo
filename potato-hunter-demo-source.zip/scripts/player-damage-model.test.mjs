import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { build } from "esbuild";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));
const damageModelUrl = new URL("../src/systems/PlayerDamageModel.ts", import.meta.url);

async function loadDamageModel() {
  assert.ok(existsSync(damageModelUrl), "shared hostile damage model is missing");
  return import(damageModelUrl.href);
}

const runtimeModulePromise = build({
  stdin: {
    contents: `
      export { World } from "./src/entities/World.ts";
      export { createPlayer, createMonster, createEnemyProjectile, createAoeWarning } from "./src/entities/factories.ts";
      export { ConfigManager } from "./src/managers/ConfigManager.ts";
      export { EventBus } from "./src/managers/EventBus.ts";
      export { PlayerStatsSystem } from "./src/systems/PlayerStatsSystem.ts";
      export { MonsterContactSystem } from "./src/systems/MonsterContactSystem.ts";
      export { EnemyProjectileSystem } from "./src/systems/EnemyProjectileSystem.ts";
      export { MonsterBehaviorSystem } from "./src/systems/MonsterBehaviorSystem.ts";
      export { AoeWarningSystem } from "./src/systems/AoeWarningSystem.ts";
      export { DeathSystem } from "./src/systems/DeathSystem.ts";
    `,
    resolveDir: projectRoot,
    sourcefile: "player-damage-test-entry.ts",
    loader: "ts",
  },
  bundle: true,
  platform: "node",
  format: "esm",
  write: false,
  plugins: [{
    name: "headless-phaser-events",
    setup(buildContext) {
      buildContext.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless-events" }));
      buildContext.onLoad({ filter: /.*/, namespace: "headless-events" }, () => ({
        contents: 'import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter } };',
        resolveDir: projectRoot,
      }));
    },
  }],
}).then((result) => import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString("base64")}`));

async function createRuntime() {
  const modules = await runtimeModulePromise;
  const world = new modules.World();
  const playerId = modules.createPlayer(world, 0, 0, 220, 100, 145);
  return {
    modules,
    world,
    playerId,
    scene: { cameras: { main: { shake() {} } } },
    stats: { elapsedMs: 0, kills: 0, bossKills: 0, gold: 0 },
    skillManager: {
      getMaxHpBonus: () => 0,
      getRegenPerSecond: () => 0,
      hasSkill: () => false,
    },
    ended: 0,
    endRun() { this.ended += 1; },
  };
}

const damageSources = [
  { kind: "contact", system: "MonsterContactSystem", damage: 10, graceMs: 900, consumed: false },
  { kind: "projectile", system: "EnemyProjectileSystem", damage: 10, graceMs: 520, consumed: true },
  { kind: "explosion", system: "MonsterBehaviorSystem", damage: 22, graceMs: 700, consumed: true },
  { kind: "aoe", system: "AoeWarningSystem", damage: 15, graceMs: 700, consumed: true },
  { kind: "death_bomb", system: "DeathSystem", damage: 16, graceMs: 700, consumed: true },
];

function addDamageSource(runtime, source) {
  const { modules, world } = runtime;
  if (source.kind === "projectile") {
    return modules.createEnemyProjectile(world, 0, 0, 0, 0, source.damage);
  }
  if (source.kind === "aoe") {
    return modules.createAoeWarning(world, 0, 0, 150, source.damage, 1);
  }
  const monsterConfig = modules.ConfigManager.getMonster(source.kind === "explosion" ? "ketchup_slug" : "fries_cultist");
  const monsterId = modules.createMonster(world, monsterConfig, 0, 0);
  const monster = world.components.monsters.get(monsterId);
  monster.damage = 10;
  if (source.kind === "death_bomb") {
    monster.isElite = true;
    monster.eliteAffix = "death_bomb";
    world.components.health.get(monsterId).current = 0;
  }
  return monsterId;
}

test("hostile damage gate rejects dash and an active recovery window", async () => {
  const model = await loadDamageModel();
  assert.equal(model.canReceiveHostileDamage({ dashRemainingMs: 1, damageCooldownMs: 0 }), false);
  assert.equal(model.canReceiveHostileDamage({ dashRemainingMs: 0, damageCooldownMs: 1 }), false);
  assert.equal(model.canReceiveHostileDamage({ dashRemainingMs: 0, damageCooldownMs: 0 }), true);
});

test("damage grace preserves contact protection and gives ranged hits bounded recovery", async () => {
  const model = await loadDamageModel();
  assert.equal(model.getHostileHitGraceMs("contact"), 900);
  assert.equal(model.getHostileHitGraceMs("projectile"), 520);
  assert.equal(model.getHostileHitGraceMs("explosion"), 700);
  assert.equal(model.getHostileHitGraceMs("aoe"), 700);
});

for (const source of damageSources) {
  test(`${source.kind} damage respects dash immunity and consumes one-shot attacks`, async () => {
    const runtime = await createRuntime();
    const player = runtime.world.components.players.get(runtime.playerId);
    player.dashRemainingMs = 1;
    const sourceId = addDamageSource(runtime, source);
    new runtime.modules[source.system]().update(16, runtime);
    assert.equal(runtime.world.components.health.get(runtime.playerId).current, 100);
    assert.equal(player.damageCooldownMs, 0);
    assert.equal(runtime.world.isAlive(sourceId), !source.consumed);
  });

  test(`${source.kind} damage respects the same recovery window`, async () => {
    const runtime = await createRuntime();
    const player = runtime.world.components.players.get(runtime.playerId);
    player.damageCooldownMs = 1;
    const sourceId = addDamageSource(runtime, source);
    new runtime.modules[source.system]().update(16, runtime);
    assert.equal(runtime.world.components.health.get(runtime.playerId).current, 100);
    assert.equal(player.damageCooldownMs, 1, "damage systems must not advance the shared clock");
    assert.equal(runtime.world.isAlive(sourceId), !source.consumed);
  });

  test(`${source.kind} damage still hits a ready player and starts source recovery`, async () => {
    const runtime = await createRuntime();
    addDamageSource(runtime, source);
    new runtime.modules[source.system]().update(16, runtime);
    assert.equal(runtime.world.components.health.get(runtime.playerId).current, 100 - source.damage);
    assert.equal(runtime.world.components.players.get(runtime.playerId).damageCooldownMs, source.graceMs);
  });
}

test("a same-frame projectile volley lands only one hit and is fully consumed", async () => {
  const runtime = await createRuntime();
  const source = damageSources.find((candidate) => candidate.kind === "projectile");
  for (let index = 0; index < 6; index += 1) addDamageSource(runtime, source);
  new runtime.modules.EnemyProjectileSystem().update(16, runtime);
  assert.equal(runtime.world.components.health.get(runtime.playerId).current, 90);
  assert.equal(runtime.world.components.enemyProjectiles.size, 0);
});

test("clustered exploders land only one hit and cannot re-hit after recovery", async () => {
  const runtime = await createRuntime();
  const source = damageSources.find((candidate) => candidate.kind === "explosion");
  for (let index = 0; index < 4; index += 1) addDamageSource(runtime, source);
  new runtime.modules.MonsterBehaviorSystem().update(16, runtime);
  assert.equal(runtime.world.components.health.get(runtime.playerId).current, 78);
  assert.equal(runtime.world.components.monsters.size, 0);
});

test("mixed hostile sources cannot stack into one frame of lethal damage", async () => {
  const runtime = await createRuntime();
  for (const source of damageSources) addDamageSource(runtime, source);
  for (const system of ["MonsterBehaviorSystem", "AoeWarningSystem", "EnemyProjectileSystem", "DeathSystem", "MonsterContactSystem"]) {
    new runtime.modules[system]().update(16, runtime);
  }
  assert.equal(runtime.world.components.health.get(runtime.playerId).current, 78);
  assert.equal(runtime.world.components.players.get(runtime.playerId).damageCooldownMs, 700);
});

test("the shared recovery clock ticks once before damage systems", async () => {
  const runtime = await createRuntime();
  const player = runtime.world.components.players.get(runtime.playerId);
  player.damageCooldownMs = 520;
  new runtime.modules.PlayerStatsSystem().update(16, runtime);
  assert.equal(player.damageCooldownMs, 504);
  new runtime.modules.MonsterContactSystem().update(16, runtime);
  assert.equal(player.damageCooldownMs, 504);
});

test("a new projectile can hit exactly when recovery expires", async () => {
  const runtime = await createRuntime();
  const source = damageSources.find((candidate) => candidate.kind === "projectile");
  const system = new runtime.modules.EnemyProjectileSystem();
  addDamageSource(runtime, source);
  system.update(16, runtime);
  new runtime.modules.PlayerStatsSystem().update(520, runtime);
  addDamageSource(runtime, source);
  system.update(16, runtime);
  assert.equal(runtime.world.components.health.get(runtime.playerId).current, 80);
  assert.equal(runtime.world.components.players.get(runtime.playerId).damageCooldownMs, 520);
});

test("telegraphed AOE keeps its safe center intact", async () => {
  const runtime = await createRuntime();
  runtime.modules.createAoeWarning(runtime.world, 0, 0, 320, 30, 1, 92);
  new runtime.modules.AoeWarningSystem().update(16, runtime);
  assert.equal(runtime.world.components.health.get(runtime.playerId).current, 100);
  assert.equal(runtime.world.components.aoeWarnings.size, 0);
});
