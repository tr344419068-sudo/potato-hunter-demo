import assert from 'node:assert/strict';
import test from 'node:test';
import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const root = fileURLToPath(new URL('../', import.meta.url));
const expectedIds = ['fries_cultist', 'ketchup_slug', 'delivery_box', 'cola_spitter', 'shield_guard', 'onion_flanker', 'corn_bombardier', 'drone_summoner'];
const newIds = ['mushroom_hexer', 'chili_scatter', 'pea_sniper', 'donut_jumper'];
const desertImages = { desert_cactus: '/assets/enemies/desert-v1/cactus.png', desert_scorpion: '/assets/enemies/desert-v1/scorpion.png' };
const config = JSON.parse(readFileSync(new URL('../src/configs/monsters.json', import.meta.url), 'utf8'));

async function entries() {
  assert.equal(existsSync(new URL('../src/ui/BestiaryModel.ts', import.meta.url)), true, 'the camp bestiary needs a model');
  const compiled = await build({ stdin: { contents: `export { BESTIARY_ENTRIES } from './src/ui/BestiaryModel.ts';`, resolveDir: root, loader: 'ts' }, bundle: true, platform: 'node', format: 'esm', write: false });
  return (await import(`data:text/javascript;base64,${Buffer.from(compiled.outputFiles[0].text).toString('base64')}`)).BESTIARY_ENTRIES;
}

test('bestiary preserves the eight original identities and appends four configured monsters with actual names and portrait paths', async () => {
  const model = await entries();
  assert.deepEqual(model.map(entry => entry.id), [...expectedIds, ...newIds, ...Object.keys(desertImages)]);
  for (const entry of model) {
    const monster = config.monsters.find(candidate => candidate.id === entry.id);
    assert.equal(entry.name, monster.name);
    assert.equal(entry.behavior, monster.behavior);
    assert.equal(entry.imagePath, desertImages[entry.id] ?? (newIds.includes(entry.id) ? `/assets/bestiary/v4/${entry.id}.png` : `/assets/bestiary/v3/${entry.id}.png`));
    for (const field of ['role', 'attack', 'counterplay']) assert.ok(entry[field]?.trim(), `${entry.id}.${field} must explain the encounter`);
  }
});

test('bestiary entries and their stable order are immutable', async () => {
  const model = await entries();
  assert.equal(Object.isFrozen(model), true);
  for (const entry of model) {
    assert.equal(Object.isFrozen(entry), true);
    assert.throws(() => { entry.name = '替换名称'; }, TypeError);
  }
  assert.throws(() => model.reverse(), TypeError);
});

test('bestiary copy describes existing attacks and useful responses without inventing shield directions or drone summons', async () => {
  const model = await entries();
  const byId = Object.fromEntries(model.map(entry => [entry.id, entry]));
  assert.match(byId.fries_cultist.attack, /追|靠近/);
  assert.match(byId.ketchup_slug.attack, /近身|靠近/);
  assert.match(byId.ketchup_slug.attack, /爆炸|自爆/);
  assert.match(byId.delivery_box.attack, /直线|冲刺/);
  assert.match(byId.delivery_box.counterplay, /侧|横/);
  assert.match(byId.cola_spitter.attack, /弹|喷射/);
  assert.match(byId.shield_guard.attack, /护盾|冰盾/);
  assert.match(byId.shield_guard.counterplay, /破盾|消耗护盾/);
  assert.doesNotMatch(`${byId.shield_guard.attack}${byId.shield_guard.counterplay}`, /背后|正面免疫|只能/);
  assert.match(byId.onion_flanker.attack, /侧|绕/);
  assert.match(byId.onion_flanker.counterplay, /预警|恢复/);
  assert.match(byId.corn_bombardier.attack, /范围|投弹/);
  assert.match(byId.corn_bombardier.counterplay, /橙圈|预警/);
  assert.match(byId.drone_summoner.attack, /炸薯教徒/);
  assert.doesNotMatch(byId.drone_summoner.attack, /无人机/);
  assert.match(byId.drone_summoner.counterplay, /优先/);
  assert.match(byId.desert_cactus.attack, /三枚|扇形/);
  assert.match(byId.desert_scorpion.attack, /侧面|突进/);
});

test('bestiary styling bounds its scroll area and uses a responsive 4, 2, 1 card grid with keyboard focus visibility', () => {
  const styles = readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
  assert.match(styles, /\.campaign-bestiary\s*\{[^}]*max-height:/s);
  assert.match(styles, /\.campaign-bestiary-scroll\s*\{[^}]*min-height:\s*0;[^}]*overflow-y:\s*auto/s);
  assert.match(styles, /\.campaign-bestiary-grid\s*\{[^}]*grid-template-columns:\s*repeat\(4,\s*minmax\(0,\s*1fr\)\)/s);
  assert.match(styles, /@media\s*\(max-width:\s*900px\)\s*\{\s*\.campaign-bestiary-grid\s*\{[^}]*repeat\(2,\s*minmax\(0,\s*1fr\)\)/s);
  assert.match(styles, /@media\s*\(max-width:\s*540px\)\s*\{[\s\S]*?\.campaign-bestiary-grid\s*\{[^}]*grid-template-columns:\s*minmax\(0,\s*1fr\)/);
  assert.match(styles, /\.campaign-bestiary-scroll:focus-visible/);
  assert.match(styles, /prefers-reduced-motion:\s*reduce/);
  assert.doesNotMatch(styles, /@keyframes\s+(?:flash|shake)|animation:\s*(?:flash|shake)/);
});
