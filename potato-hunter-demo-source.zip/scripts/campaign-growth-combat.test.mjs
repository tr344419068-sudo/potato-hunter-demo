import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const api = build({ stdin: { contents: `export { SkillManager } from './src/managers/SkillManager.ts'; export { PlayerStatsSystem } from './src/systems/PlayerStatsSystem.ts'; export { ConfigManager } from './src/managers/ConfigManager.ts';`, loader: 'ts', resolveDir: root }, bundle: true, platform: 'node', format: 'esm', write: false, plugins: [{ name: 'stub-phaser', setup(b) { b.onResolve({ filter: /^phaser$/ }, () => ({ path: 'phaser', namespace: 'stub' })); b.onLoad({ filter: /.*/, namespace: 'stub' }, () => ({ contents: `export default {Display:{Color:{HexStringToColor:v=>({color:parseInt(v.slice(1),16)})}},Utils:{Array:{Shuffle:a=>a}}}` })); } }] }).then(r => import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));

test('permanent attack upgrades affect projectiles and auras without changing skill ranks', async () => {
  const { SkillManager } = await api;
  const base = new SkillManager({ starterSkillId: 'peeler_blade' });
  const trained = new SkillManager({ starterSkillId: 'peeler_blade', permanentDamageMultiplier: 1.2 });
  base.levelUp('toxic_tomato'); trained.levelUp('toxic_tomato');
  assert.ok(trained.getWeaponProfiles()[0].damage > base.getWeaponProfiles()[0].damage);
  assert.ok(trained.getAuraProfiles()[0].damagePerSecond > base.getAuraProfiles()[0].damagePerSecond);
  assert.equal(trained.getLevel('toxic_tomato'), base.getLevel('toxic_tomato'));
});

test('permanent health bonus is retained when player stats recalculate', async () => {
  const { PlayerStatsSystem, SkillManager, ConfigManager } = await api;
  const health = { current: ConfigManager.player.maxHp + 16, max: ConfigManager.player.maxHp + 16 };
  const runtime = { playerId: 1, world: { components: { health: new Map([[1, health]]), players: new Map([[1, { level: 1, damageCooldownMs: 0 }]]) } }, skillManager: new SkillManager(), campaign: { training: { maxHp: 16 } } };
  new PlayerStatsSystem().update(16, runtime);
  assert.equal(health.max, ConfigManager.player.maxHp + 16);
  assert.equal(health.current, health.max);
});
