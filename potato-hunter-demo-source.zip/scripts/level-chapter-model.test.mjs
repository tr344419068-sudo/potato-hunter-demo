import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function loadModel() {
  try {
    return await import("../src/managers/LevelChapterModel.ts");
  } catch {
    return {};
  }
}

test("first-minute chapters advance through five authored beats", async () => {
  const model = await loadModel();
  assert.equal(typeof model.getLevelChapter, "function");

  const starts = [0, 10, 24, 40, 60].map((seconds) => model.getLevelChapter(seconds * 1000).startSeconds);
  assert.deepEqual(starts, [0, 10, 24, 40, 60]);
  assert.equal(new Set(model.LEVEL_CHAPTERS.map((chapter) => chapter.formation)).size, 5);
  assert.equal(model.getLevelChapter(39_999).id, "delivery_hunt");
});

test("spawn formations stay normalized and visibly distinct", async () => {
  const model = await loadModel();
  assert.equal(typeof model.getSpawnAngle, "function");

  const signatures = model.LEVEL_CHAPTERS.map((chapter) => (
    Array.from({ length: 8 }, (_, index) => model.getSpawnAngle(chapter, index, 8, 0.5).toFixed(3)).join("|")
  ));
  assert.equal(new Set(signatures).size, model.LEVEL_CHAPTERS.length);
  for (const chapter of model.LEVEL_CHAPTERS) {
    for (let index = 0; index < 12; index += 1) {
      const angle = model.getSpawnAngle(chapter, index, 12, 0.73);
      assert.ok(angle >= 0 && angle < Math.PI * 2);
    }
  }
});

test("battlefield decorations are deterministic, sparse, and chapter-specific", async () => {
  const model = await loadModel();
  assert.equal(typeof model.getBattlefieldDecoration, "function");

  const chapter = model.LEVEL_CHAPTERS[1];
  const first = model.getBattlefieldDecoration(4, -7, chapter);
  const second = model.getBattlefieldDecoration(4, -7, chapter);
  assert.deepEqual(first, second);

  const decorations = [];
  for (let x = -10; x < 10; x += 1) {
    for (let y = -10; y < 10; y += 1) {
      const decoration = model.getBattlefieldDecoration(x, y, chapter);
      if (decoration) decorations.push(decoration);
    }
  }
  assert.ok(decorations.length >= 80 && decorations.length <= 240);
  assert.ok(decorations.every((decoration) => decoration.scale >= 0.65 && decoration.scale <= 1.35));

  const meadowKinds = new Set();
  const siegeKinds = new Set();
  for (let x = -8; x < 8; x += 1) {
    for (let y = -8; y < 8; y += 1) {
      const meadow = model.getBattlefieldDecoration(x, y, model.LEVEL_CHAPTERS[0]);
      const siege = model.getBattlefieldDecoration(x, y, model.LEVEL_CHAPTERS[4]);
      if (meadow) meadowKinds.add(meadow.kind);
      if (siege) siegeKinds.add(siege.kind);
    }
  }
  assert.notDeepEqual([...meadowKinds].sort(), [...siegeKinds].sort());
});

test("chapter model is wired into spawning, directing, and scene registration", async () => {
  const [spawnSource, directorSource, sceneSource] = await Promise.all([
    readFile(new URL("../src/systems/SpawnSystem.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/systems/ChapterDirectorSystem.ts", import.meta.url), "utf8").catch(() => ""),
    readFile(new URL("../src/scenes/GameScene.ts", import.meta.url), "utf8"),
  ]);
  assert.match(spawnSource, /getSpawnAngle/);
  assert.match(directorSource, /level:chapter/);
  assert.match(sceneSource, /ChapterDirectorSystem/);
});
