"""Repack ParticleFX Studio's official APNG exports without generating motion.

Usage: python3 scripts/export-desert-boss-flipbooks.py /path/to/downloaded-apngs
"""
from pathlib import Path
import sys
from PIL import Image, ImageChops, ImageOps


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'public/assets/vfx/desert-sovereign-v2'

# output, source, source crop, cell, columns, sampled frames, source first/last,
# dark and bright sand hues, alpha lift, edge feather (x and y in output pixels)
SHEETS = (
    ('wave', 'rolling-dust-cloud', (40, 0, 688, 354), (224, 104), 6, 30, 0, 87,
     ('#583018', '#ffdc83'), 1.85, (18, 5)),
    ('cyclone', 'fire-tornado', (80, 35, 524, 671), (144, 192), 6, 30, 0, 69,
     ('#693518', '#ffe0a0'), 1.64, (13, 9)),
    ('sandfall', 'sand-burst', (10, 1, 363, 265), (176, 128), 6, 24, 3, 37,
     ('#8b4b27', '#ffe8a0'), 2.10, (8, 2)),
    ('storm', 'desert-sandstorm-overlay', (0, 144, 512, 368), (224, 96), 6, 24, 0, 115,
     ('#8a512f', '#ffe0a0'), 1.27, (14, 18)),
    ('whirl', 'whirlwind', (13, 5, 371, 237), (128, 80), 6, 18, 0, 22,
     ('#765236', '#fff0a8'), 1.28, (5, 5)),
)


def feather(cell, margin):
    w, h = cell
    mx, my = margin
    edge = Image.new('L', cell)
    edge.putdata([round(255 * min(x / mx, (w - 1 - x) / mx, 1) * min(y / my, (h - 1 - y) / my, 1))
                  for y in range(h) for x in range(w)])
    return edge


def export(directory):
    OUTPUT.mkdir(parents=True, exist_ok=True)
    for name, source, crop, cell, cols, count, start, stop, colors, lift, margin in SHEETS:
        with Image.open(directory / f'{source}.png') as original:
            if original.n_frames <= stop:
                raise ValueError(f'{source} does not have the expected source sequence')
            w, h = cell
            atlas = Image.new('RGBA', (w * cols, h * ((count + cols - 1) // cols)))
            fade = feather(cell, margin)
            grading = [min(255, round(36 + 1.15 * value)) for value in range(256)]
            opacity = [min(255, round(lift * value)) for value in range(256)]
            for index in range(count):
                original.seek(round(start + (stop - start) * index / (count - 1)))
                frame = original.convert('RGBA').crop(crop).resize(cell, Image.Resampling.LANCZOS)
                sand = ImageOps.colorize(ImageOps.grayscale(frame).point(grading), *colors)
                sand.putalpha(ImageChops.multiply(frame.getchannel('A').point(opacity), fade))
                atlas.paste(sand, ((index % cols) * w, (index // cols) * h))
            output = OUTPUT / f'{name}.webp'
            atlas.save(output, quality=78, alpha_quality=78, method=6)
            print(f'{name}: {count} × {w}×{h}, {output.stat().st_size:,} B')


if __name__ == '__main__':
    export(Path(sys.argv[1]))
