import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("scene shutdown clears pooled Phaser objects before a restart", async () => {
  const [poolSource, feedbackSource] = await Promise.all([
    readFile(new URL("../src/managers/EntityPools.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/systems/FeedbackSystem.ts", import.meta.url), "utf8"),
  ]);

  assert.match(poolSource, /clearScene\(scene:\s*Phaser\.Scene\)/);
  assert.match(poolSource, /damageTextPools\.delete\(scene\)/);
  assert.match(poolSource, /graphicsPools\.delete\(scene\)/);
  assert.match(feedbackSource, /EntityPools\.clearScene\(this\.scene\)/);
});

test("reused graphics reset their transform before the next combat effect", async () => {
  const poolSource = await readFile(new URL("../src/managers/EntityPools.ts", import.meta.url), "utf8");

  assert.match(poolSource, /graphics\.setPosition\(0,\s*0\)/);
  assert.match(poolSource, /graphics\.setScale\(1\)/);
  assert.match(poolSource, /graphics\.setRotation\(0\)/);
});
