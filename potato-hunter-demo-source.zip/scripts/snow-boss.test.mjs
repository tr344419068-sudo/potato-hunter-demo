import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { displayScene } from "./ui-runtime-helpers.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
  export { World } from "./src/entities/World.ts";
  export { createMonster, createPlayer } from "./src/entities/factories.ts";
  export { ConfigManager } from "./src/managers/ConfigManager.ts";
  export { startBossDuel } from "./src/systems/BossDuelArena.ts";
  export { BossSystem } from "./src/systems/BossSystem.ts";
  export { MovementSystem } from "./src/systems/MovementSystem.ts";
  export { getIceCover, getIceCoverShatters, setIceCover } from "./src/systems/IceTerrain.ts";
  export { getSnowCast, getSnowHammerFilmFrame, getSnowPunishWindow, getSnowSafePaths } from "./src/systems/SnowBossEncounter.ts";
  export { SnowBossView, canShowSnowAttack } from "./src/systems/SnowBossView.ts";
  export * from "./src/systems/FinalBossPatternModel.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless-snow-boss", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({
      contents: 'export default { Math: { Clamp: (v,lo,hi)=>Math.max(lo,Math.min(hi,v)) } };',
    }));
  } }],
}).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

async function fixture(phase = 1, playerX = 122, stage = "snow") {
  const api = await modules;
  const world = new api.World();
  const playerId = api.createPlayer(world, playerX, 0, 220, 100, 100);
  const id = api.createMonster(world, api.ConfigManager.getMonster("delivery_box"), 0, 0, true);
  const encounter = { phase, completedCasts: 0, transitioning: false };
  Object.assign(world.components.monsters.get(id), { bossKind: "final", finalBossEncounter: encounter });
  api.startBossDuel(world, { x: 0, y: 0, bossId: id, stage, startedAt: 0 });
  const boss = new api.BossSystem();
  const move = new api.MovementSystem();
  const runtime = { world, playerId, campaign: { stage }, canShowSnowAttack: () => true };
  const p = world.components.transforms.get(playerId);
  const b = world.components.transforms.get(id);
  const hp = world.components.health.get(playerId);
  const step = (totalMs, afterStep = () => {}) => {
    for (let elapsed = 0; elapsed < totalMs; elapsed += 20) {
      const dt = Math.min(20, totalMs - elapsed);
      const player = world.components.players.get(playerId);
      runtime.hostileProtectionAtStepStart = { dashRemainingMs: player.dashRemainingMs, damageCooldownMs: player.damageCooldownMs };
      player.damageCooldownMs = Math.max(0, player.damageCooldownMs - dt);
      player.dashRemainingMs = Math.max(0, player.dashRemainingMs - dt);
      boss.update(dt, runtime);
      move.update(dt, runtime);
      afterStep();
    }
  };
  return { ...api, world, id, playerId, encounter, runtime, step, p, b, hp };
}

test("snow uses six health cells and locks each of the three stages until its signature attack", async () => {
  const f = await fixture();
  assert.equal(f.SNOW_BOSS_HEALTH_BANDS?.length, 7);
  const health = f.createFinalBossHealth(100, f.encounter, "snow");
  assert.equal(f.getFinalBossPhaseFloor(100, 1, "snow"), f.SNOW_BOSS_HEALTH_BANDS[4] * 100);
  assert.equal(f.getFinalBossPhaseFloor(100, 2, "snow"), f.SNOW_BOSS_HEALTH_BANDS[2] * 100);
  for (const phase of [1, 2, 3]) {
    assert.equal(f.getCampaignFinalBossPhase("snow", phase).requiredCasts, phase === 1 ? 1 : 2);
    f.encounter.phase = phase;
    f.encounter.completedCasts = 0;
    health.current = -1;
    assert.ok(health.current > 0);
  }
});

test("snow pursues immediately and puts multiple real pose frames on a locked hammer attack", async () => {
  const f = await fixture(1, 218);
  f.step(240);
  assert.ok(f.b.x > 35, "boss closes distance before casting");
  assert.equal(f.hp.current, 100, "pursuit does not hit");
  const frames = new Set();
  f.step(940, () => { if (f.encounter.swingFrame !== undefined) frames.add(f.encounter.swingFrame); });
  assert.ok(frames.size >= 5, `expected an articulated swing, got frames ${[...frames]}`);
  assert.ok(f.hp.current < 100, "the struck side takes damage once the hammer connects");
  assert.equal(f.encounter.completedCasts, 0, "basic does not skip the signature attack gate");
});

test("leaving the announced strike direction during the hammer windup avoids damage", async () => {
  const f = await fixture();
  f.step(220);
  assert.equal(f.encounter.swingFrame !== undefined, true, "hammer is telegraphing");
  f.p.x = -134;
  f.step(740);
  assert.equal(f.hp.current, 100);
});

test("the visual hammer impact frame and the damage tick coincide", async () => {
  const f = await fixture();
  f.step(20);
  const cast = f.getSnowCast(f.world);
  assert.equal(cast.shape.kind, "hammer_swing");
  f.step(cast.tellMs - 1);
  assert.equal(f.encounter.swingFrame, 4, "last visible anticipation pose");
  assert.equal(f.hp.current, 100);
  f.step(1);
  assert.equal(f.encounter.swingFrame, 5, "frame 5 is authored hammer contact");
  assert.ok(f.hp.current < 100);
});

test("the video atlas hits on the original damage tick and only replaces the basic hammer cast", async () => {
  const f = await fixture();
  f.step(20);
  const cast = f.getSnowCast(f.world);
  assert.equal(f.getSnowHammerFilmFrame(cast), 0);
  f.step(cast.tellMs - 1);
  assert.equal(f.getSnowHammerFilmFrame(cast), 9);
  assert.equal(f.hp.current, 100);
  f.step(1);
  assert.equal(f.getSnowHammerFilmFrame(cast), 10);
  assert.ok(f.hp.current < 100);
  f.step(cast.durationMs - cast.tellMs - 1);
  assert.equal(f.getSnowHammerFilmFrame(cast), 15);
  assert.equal(f.getSnowHammerFilmFrame(undefined), undefined);
  assert.equal(f.getSnowHammerFilmFrame({ ...cast, shape: { ...cast.shape, kind: "ice_spikes" } }), undefined);
});

test("snow spikes punish the original lane, even if the target moves after the tell", async () => {
  const hit = await fixture(1, 336);
  hit.step(2820);
  assert.ok(hit.hp.current < 100, "holding the marked lane is punished");

  const dodge = await fixture(1, 336);
  // Keep the target outside hammer reach until the boss commits to its first ranged cast.
  dodge.world.components.velocities.get(dodge.playerId).x = 210;
  dodge.step(1280);
  dodge.world.components.velocities.get(dodge.playerId).x = 0;
  dodge.p.y = 112;
  dodge.step(1650);
  assert.equal(dodge.hp.current, 100, "leaving the locked lane is safe");
});

test("charging into ice cover breaks the pillar, cancels armor, and grants a long stationary punish", async () => {
  const f = await fixture(2, 270);
  f.setIceCover(f.world, [{ id: "pillar", x: 152, y: 0, radius: 27 }]);
  f.step(240);
  assert.ok(f.encounter.sandArmor?.hp > 0, "charge starts under a shield");
  assert.equal(f.getIceCover(f.world).length, 1, "the tell itself doesn't affect cover");
  f.step(1200);
  assert.equal(f.getIceCover(f.world).length, 0);
  assert.equal(f.getIceCoverShatters(f.world).length, 1, "cover broke once");
  assert.equal(f.encounter.sandArmor, undefined);
  assert.equal(f.hp.current, 100, "the boss stopped on the near side of the pillar");
  assert.ok(f.b.x > 45 && f.b.x < 152, "charge stopped at contact in front of the pillar");
  const start = f.b.x;
  f.step(970);
  assert.equal(f.b.x, start);
  assert.equal(f.encounter.completedCasts, 1);
});

test("avalanche has a safe route through all three pulses and leaves the boss open to punish", async () => {
  const f = await fixture(3, 137);
  f.step(40); // right slab is locked
  f.p.x = 0; // center seam is outside both side pulses
  f.step(2230);
  assert.equal(f.hp.current, 100);
  f.p.x = 135; // exit the seam before the last pulse
  f.step(1410);
  assert.equal(f.hp.current, 100);
  assert.equal(f.encounter.completedCasts, 1);
  const start = f.b.x;
  f.step(1150);
  assert.equal(f.b.x, start, "no follow-up interrupts the finale punish");
  const health = f.createFinalBossHealth(100, f.encounter, "snow");
  health.current = 0;
  assert.equal(health.current, 8, "leave a visible sliver until the final phase's second cast");
  f.step(4900);
  assert.ok(f.encounter.completedCasts >= 2);
  health.current = 0;
  assert.equal(health.current, 0, "the cap lifts once both final phase casts have completed");
});

test("an unloaded attack stays benign rather than dealing invisible damage", async () => {
  const f = await fixture(3, 137);
  f.runtime.canShowSnowAttack = () => false;
  f.step(3690);
  assert.equal(f.hp.current, 100);
  assert.equal(f.encounter.completedCasts, 1, "missing texture doesn't soft-lock the run");
});

test("avalanche alternates active/art and safe-route ground marks without leaking objects", async () => {
  const f = await fixture(3, 137);
  const { scene, objects } = displayScene(390, 844);
  const view = new f.SnowBossView(scene);
  f.step(40);
  const cast = f.getSnowCast(f.world);
  const { pulses } = cast.shape;
  assert.ok(pulses.every(pulse => f.getSnowSafePaths(cast.arena, pulse).every(path => path.maxX < pulse.minX || path.minX > pulse.maxX)));
  assert.equal(f.canShowSnowAttack(scene, "avalanche"), true);
  view.draw(f.runtime);
  const ground = objects.find(object => object.kind === "graphics");
  assert.ok(ground.calls.filter(([name]) => name === "fillPoints").length >= 2, "safe route and danger ground are independently marked");
  f.step(1110);
  view.draw(f.runtime);
  assert.ok(objects.some(object => object.texture === "asset:vfx_snow_avalanche" && object.visible), "pulse renders the flipbook");
  const objectsAtImpact = objects.length;
  view.draw(f.runtime);
  assert.equal(objects.length, objectsAtImpact, "existing images are reused");
  f.world.destroyEntity(f.id);
  view.draw(f.runtime);
  assert.ok(objects.every(object => object.kind === "graphics" || !object.visible), "no abandoned pulse remains after death");
});
