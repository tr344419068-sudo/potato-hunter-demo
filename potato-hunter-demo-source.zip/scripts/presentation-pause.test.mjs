import assert from 'node:assert/strict';
import test from 'node:test';
import {createRequire} from 'node:module';
import {uiModules,displayScene} from './ui-runtime-helpers.mjs';
const require=createRequire(import.meta.url);
const TweenManager=require('phaser/src/tweens/TweenManager.js');
const Clock=require('phaser/src/time/Clock.js');
const ScenePlugin=require('phaser/src/scene/ScenePlugin.js');
const SceneManager=require('phaser/src/scene/SceneManager.js');
function clocks(scene,EventEmitter){
 scene.sys={events:new EventEmitter(),game:{loop:{time:0}}};
 scene.tweens=new TweenManager(scene);scene.tweens.getDelta=()=>100;
 scene.time=new Clock(scene);
 const effect={alpha:1};scene.tweens.add({targets:effect,alpha:0,duration:1000});scene.tweens.update();scene.tweens.update();
 let callbacks=0;scene.time.delayedCall(100,()=>callbacks++);scene.time.preUpdate();
 return {effect,advance(){scene.tweens.update();scene.time.update(100,100);},callbacks:()=>callbacks};
}
test('production boot queue subscribes UI before home ready, freezing its real presentation clocks',async t=>{
 const a=await uiModules;a.EventBus.removeAllListeners();
 const ui=new a.UIScene();Object.assign(ui,displayScene().scene);const c=clocks(ui,a.Phaser.Events.EventEmitter);
 const manager=Object.create(SceneManager.prototype);manager._queue=[];manager._pending=[];
 manager.stop=()=>{};manager.start=key=>{if(key==='UIScene')ui.create();else if(key==='GameScene')a.EventBus.emit('campaign:ready',{atHome:true});};
 const boot=new a.BootScene();boot.sys={settings:{key:'BootScene'},game:{scene:manager},events:new a.Phaser.Events.EventEmitter()};boot.scene=new ScenePlugin(boot);boot.load=new a.Phaser.Events.EventEmitter();
 t.mock.method(a.AssetManager,'loadAvailable',async(_scene,complete)=>complete());boot.create();manager.processQueue();
 const alpha=c.effect.alpha;c.advance();assert.equal(c.effect.alpha,alpha,'UI created after ready incorrectly advances at home');assert.equal(c.callbacks(),0);
 a.EventBus.emit('campaign:ready',{atHome:false});c.advance();assert.ok(c.effect.alpha<alpha);assert.equal(c.callbacks(),1);
 ui.events.emit('shutdown');
});
test('actual Phaser combat tweens and timed effects freeze through pause and chooser, then resume',async()=>{
 const a=await uiModules;a.EventBus.removeAllListeners();const g=new a.GameScene();Object.assign(g,displayScene().scene);g.playerId=a.createPlayer(g.world,0,0,220,100,145);
 const c=clocks(g,a.Phaser.Events.EventEmitter),alpha=c.effect.alpha;
 g.setCampaignPaused(true);c.advance();assert.equal(c.effect.alpha,alpha);assert.equal(c.callbacks(),0);
 g.setCampaignPaused(false);g.requestSkillChoice([]);c.advance();assert.equal(c.effect.alpha,alpha);assert.equal(c.callbacks(),0);
 g.cancelUpgradeChoices();c.advance();assert.ok(c.effect.alpha<alpha);assert.equal(c.callbacks(),1);
 g.setCampaignPaused(true);g.endRun('defeat');assert.equal(g.tweens.paused,false,'terminal death presentation must still advance');
});
test('actual Phaser UI notification tweens and timers freeze under choices and explicit pause',async()=>{
 const a=await uiModules;a.EventBus.removeAllListeners();const ui=new a.UIScene();Object.assign(ui,displayScene().scene);const c=clocks(ui,a.Phaser.Events.EventEmitter);ui.create();const alpha=c.effect.alpha;
 a.EventBus.emit('level:choices',{choices:a.ConfigManager.skills.slice(0,3),hints:[],sessionId:1});c.advance();assert.equal(c.effect.alpha,alpha);assert.equal(c.callbacks(),0);
 a.EventBus.emit('campaign:paused',true);a.EventBus.emit('upgrade:closed');c.advance();assert.equal(c.effect.alpha,alpha);assert.equal(c.callbacks(),0);
 a.EventBus.emit('campaign:paused',false);c.advance();assert.ok(c.effect.alpha<alpha);assert.equal(c.callbacks(),1);
 ui.events.emit('shutdown');assert.equal(a.EventBus.listenerCount('campaign:paused'),0);
});
test('resuming does not turn a short pause into a burst of accumulated tween time',async t=>{
 const a=await uiModules;a.EventBus.removeAllListeners();let wallTime=10000;t.mock.method(Date,'now',()=>wallTime);
 const g=new a.GameScene();Object.assign(g,displayScene().scene);g.sys={events:new a.Phaser.Events.EventEmitter()};g.tweens=new TweenManager(g);g.tweens.start();
 const effect={alpha:1};g.tweens.add({targets:effect,alpha:0,duration:1000});wallTime+=100;g.tweens.update();wallTime+=100;g.tweens.update();
 const alpha=effect.alpha;g.setCampaignPaused(true);wallTime+=300;g.setCampaignPaused(false);g.tweens.update();assert.equal(effect.alpha,alpha,'resume must discard pause backlog');
 wallTime+=100;g.tweens.update();assert.ok(effect.alpha<alpha);assert.ok(effect.alpha>=alpha-.11);
});

for(const [width,height] of [[1280,720],[390,844],[390,650]]){
 test(`actual UI suppresses the independent living boss HUD during choices at ${width}x${height}`,async()=>{
  const a=await uiModules;a.EventBus.removeAllListeners();
  const ui=new a.UIScene();Object.assign(ui,displayScene(width,height).scene);ui.create();
  const payload={elapsedMs:60000,kills:80,bossKills:0,gold:0,level:5,experience:0,experienceToNext:28,hp:100,maxHp:120,skills:[],builds:[],aliveMonsters:19,waveMonsterId:'fries_cultist',difficulty:{level:1},dashCooldownRatio:0,boss:{hp:800,maxHp:1000}};
  const choose=()=>a.EventBus.emit('level:choices',{choices:a.ConfigManager.skills.slice(0,3),hints:[],sessionId:1});
  const resize=()=>{ui.scale.width=height;ui.scale.height=width;ui.scale.emit('resize');};
  a.EventBus.emit('campaign:ready',{atHome:false});a.EventBus.emit('hud:update',payload);
  assert.equal(ui.bossBar.root.visible,true);
  choose();assert.equal(ui.bossBar.root.visible,false,'boss plaque must yield immediately when the chooser opens');
  a.EventBus.emit('hud:update',{...payload,choosingUpgrade:true,boss:{hp:450,maxHp:1000}});
  assert.equal(ui.hud.root.visible,false);assert.equal(ui.bossBar.root.visible,false,'HUD updates must not resurrect the suppressed boss plaque');
  assert.match(ui.bossBar.label.text,/450 \/ 1000/);resize();assert.equal(ui.bossBar.root.visible,false);
  a.EventBus.emit('upgrade:closed');assert.equal(ui.bossBar.root.visible,true,'close restores the latest living boss without waiting for another HUD tick');
  assert.match(ui.bossBar.label.text,/450 \/ 1000/);
  assert.ok(Math.abs(ui.bossBar.fill.width-ui.currentLayout.boss.width*.72*.45)<1e-8);
  choose();a.EventBus.emit('hud:update',{...payload,choosingUpgrade:true,boss:{hp:0,maxHp:1000}});resize();
  a.EventBus.emit('upgrade:closed');assert.equal(ui.bossBar.root.visible,false,'closing must not resurrect a dead boss');
  a.EventBus.emit('hud:update',payload);choose();a.EventBus.emit('ui:clear');assert.equal(ui.bossBar.root.visible,true,'clearing choices releases suppression');
  choose();a.EventBus.emit('campaign:ready',{atHome:false});assert.equal(ui.bossBar.root.visible,true,'new run readiness resets chooser suppression');
  a.EventBus.emit('hud:update',{...payload,boss:undefined});resize();assert.equal(ui.bossBar.root.visible,false);
  ui.events.emit('shutdown');
 });
}
