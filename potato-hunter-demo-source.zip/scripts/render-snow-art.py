"""Render original orthographic frost-forge sprites; see snow-art-provenance.md."""
import bpy
import math
import random
import sys
from pathlib import Path
from mathutils import Vector, Quaternion

TAU = math.tau
OUT = Path(sys.argv[sys.argv.index('--') + 1]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
GROUP = sys.argv[sys.argv.index('--') + 2] if len(sys.argv) > sys.argv.index('--') + 2 else 'all'
S = bpy.context.scene
S.render.engine = 'BLENDER_EEVEE'
S.eevee.taa_render_samples = 24
S.render.resolution_percentage = 100
S.render.image_settings.file_format = 'PNG'
S.render.image_settings.color_mode = 'RGBA'
S.render.film_transparent = True
S.render.fps = 12
S.view_settings.view_transform = 'AgX'
S.view_settings.look = 'AgX - Medium High Contrast'
S.view_settings.exposure = .22


def color(h):
    srgb = [int(h[i:i+2], 16)/255 for i in (0, 2, 4)]
    return tuple(x/12.92 if x < .04045 else ((x+.055)/1.055)**2.4 for x in srgb) + (1,)


def material(name, tint, metal=0, rough=.4, emit=0, frost=0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = color(tint)
    m.use_nodes = True
    n = m.node_tree.nodes['Principled BSDF']
    n.inputs['Base Color'].default_value = color(tint)
    n.inputs['Metallic'].default_value = metal
    n.inputs['Roughness'].default_value = rough
    if emit:
        n.inputs['Emission Color'].default_value = color(tint)
        n.inputs['Emission Strength'].default_value = emit
    if frost:
        noise = m.node_tree.nodes.new('ShaderNodeTexNoise')
        noise.inputs['Scale'].default_value = 26
        noise.inputs['Detail'].default_value = 2.8
        bump = m.node_tree.nodes.new('ShaderNodeBump')
        bump.inputs['Distance'].default_value = frost
        bump.inputs['Strength'].default_value = .22
        m.node_tree.links.new(noise.outputs['Fac'], bump.inputs['Height'])
        m.node_tree.links.new(bump.outputs['Normal'], n.inputs['Normal'])
    return m


IRON = material('Carbon blue blacksmith iron', '25374a', .56, .36, frost=.035)
BLACK = material('Dark forge recess', '111823', .12, .5)
BLUE = material('Cobalt-blue fired enamel', '2c6995', .48, .31, frost=.026)
STEEL = material('Cold forged pale steel', '648ba6', .62, .3, frost=.022)
COPPER = material('Hammered copper edging', 'c97c4a', .65, .3, frost=.025)
CREAM = material('Frosted meal dough', 'f1c78b', .06, .46, frost=.022)
CRUST = material('Toasted crust', 'b36132', .04, .46, frost=.032)
FLOUR = material('Powder snow cap', 'd1e8f2', .03, .51, frost=.035)
VIOLET = material('Nightberry jam', '584477', .18, .42)
BERRY = material('Cranberry wool', '852e5a', .06, .52, frost=.027)
WOOD = material('Baked hickory', '603e34', .14, .49, frost=.035)
ICE = material('Glacier base', '207b9f', .22, .29, frost=.012)
SKY = material('Glacier body', '38b4d4', .2, .28)
ICE_LIGHT = material('Glacier highlight', '9cebf5', .18, .23, .14)
ICE_DARK = material('Glacier deep faces', '175577', .24, .29)
EYE = material('Arctic cyan light', '6ef5ff', .1, .27, 2.4)
EMBER = material('Furnace orange heat', 'fc6021', .05, .33, 2.3)
CORE = material('Furnace central heat', 'ffd17c', .05, .33, 3)
SNOW_BLUE = material('Avalanche shaded snow', '91c4dc', .02, .52)
SNOW_WHITE = material('Avalanche fresh snow', 'e3f6fb', .02, .55)


def ob(mat, name, smooth=True):
    o = bpy.context.object
    o.name = name
    o.data.materials.append(mat)
    if smooth:
        for f in o.data.polygons:
            f.use_smooth = True
    return o


def bevel(o, width, segments=3):
    b = o.modifiers.new('Machined edge highlights', 'BEVEL')
    b.width = width
    b.segments = segments
    b = o.modifiers.new('Face-weighted surface normals', 'WEIGHTED_NORMAL')
    b.keep_sharp = True
    return o


def ball(name, p, scale, mat, segments=24):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=16, location=p)
    o = ob(mat, name)
    o.scale = scale
    return o


def box(name, p, dim, mat, chamfer=.08):
    bpy.ops.mesh.primitive_cube_add(size=1, location=p)
    o = ob(mat, name)
    o.dimensions = dim
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return bevel(o, chamfer)


def rod(name, a, b, r, mat, r2=None, verts=24):
    a, b = Vector(a), Vector(b)
    delta = b-a
    bpy.ops.mesh.primitive_cone_add(vertices=verts, radius1=r, radius2=r if r2 is None else r2,
                                   depth=delta.length, location=(a+b)*.5)
    o = ob(mat, name)
    o.rotation_euler = delta.to_track_quat('Z', 'Y').to_euler()
    return bevel(o, min(.04, r*.26), 2)


def loop(name, p, radius, width, mat, normal=(0, 0, 1), scale=(1, 1, 1)):
    bpy.ops.mesh.primitive_torus_add(major_segments=32, minor_segments=10, location=p,
                                    major_radius=radius, minor_radius=width)
    o = ob(mat, name)
    o.rotation_euler = Vector(normal).to_track_quat('Z', 'Y').to_euler()
    o.scale = scale
    return o


def stroke(name, pts, radius, mat):
    curve = bpy.data.curves.new(name, 'CURVE')
    curve.dimensions = '3D'
    curve.bevel_depth = radius
    curve.bevel_resolution = 3
    spline = curve.splines.new('POLY')
    spline.points.add(len(pts)-1)
    for p, xyz in zip(spline.points, pts):
        p.co = (*xyz, 1)
    o = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(o)
    o.data.materials.append(mat)
    return o


def shard(name, p, sc, lean=(.1,.07), yaw=0, seed=1):
    rng = random.Random(seed)
    verts = []
    count = 6
    for ring, z in [(.65, 0), (1, .18), (.82, .74), (.27, 1.02)]:
        for k in range(count):
            angle = yaw + TAU*k/count
            radius = ring*rng.uniform(.83, 1.11)
            verts.append(((math.cos(angle)*radius + lean[0]*z)*sc[0],
                          (math.sin(angle)*radius + lean[1]*z)*sc[1],
                          (z+rng.uniform(-.033,.033))*sc[2]))
    faces = [tuple(reversed(range(count)))]
    for level in range(3):
        for j in range(count):
            lo = level*count
            a = lo+j
            b = lo+(j+1)%count
            if (j+level)%3 == 0:
                faces.extend(((a,b,b+count),(a,b+count,a+count)))
            else:
                faces.append((a,b,b+count,a+count))
    faces.append(tuple(range(count*3,count*4)))
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    o = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(o)
    o.location = p
    for m in (ICE, SKY, ICE_LIGHT, ICE_DARK):
        o.data.materials.append(m)
    for face in mesh.polygons:
        face.material_index = 2 if face.index == len(faces)-1 else rng.choices([0,1,2,3],(5,5,2,2))[0]
    b = o.modifiers.new('Broken ice edge', 'BEVEL')
    b.width = min(sc)*.028
    b.segments = 2
    return o


def studio(ortho, target, angle=(4.2,-9,6.8)):
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    target = Vector(target)
    bpy.ops.object.camera_add(location=target+Vector(angle))
    c = bpy.context.object
    c.name = 'Game three-quarter orthographic sprite camera'
    c.rotation_euler = (target - c.location).to_track_quat('-Z', 'Y').to_euler()
    c.data.type = 'ORTHO'
    c.data.ortho_scale = ortho
    S.camera = c
    world = bpy.data.worlds.new('Ice canyon ambient')
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs['Color'].default_value = (.32,.46,.62,1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value = .32
    S.world = world
    for name,p,power,sz,col in (
        ('Warm arctic key',(-4,-4,8), 1350, 5, (1,.92,.83)),
        ('Blue front fill',(5,-3,4), 740, 5, (.60,.82,1)),
        ('Winter rim',(-2,5,6), 1700, 4, (.67,.87,1))):
        bpy.ops.object.light_add(type='AREA', location=p)
        l = bpy.context.object
        l.name = name
        l.rotation_euler = (target-l.location).to_track_quat('-Z','Y').to_euler()
        l.data.energy, l.data.size, l.data.color = power, sz, col


def render(name, w, h=None):
    S.render.resolution_x = w
    S.render.resolution_y = h or w
    S.render.filepath = str(OUT / (name+'.png'))
    bpy.ops.render.render(write_still=True)


def rivet(p, size=.073):
    return ball('Copper rivet',p,(size,size*.58,size),COPPER,16)


def eyes(x, y, z, size=1):
    ball('Shadowed sneer under helmet', (x,y+.008,z),(.56*size,.11*size,.232*size),BLACK)
    for d in (-1,1):
        iris = ball('Hot spearmint eye',(x+d*.222*size,y-.095*size,z+.016*size),(.183*size,.055*size,.097*size),EYE)
        iris.rotation_euler[1] = d*-.32
        ball('Black narrowed pupil',(x+d*.184*size,y-.136*size,z+.012*size),(.049*size,.017*size,.071*size),BLACK,16)
        brow = box('Jagged brow ridge',(x+d*.244*size,y-.12*size,z+.103*size),(.39*size,.087*size,.107*size),STEEL,.028*size)
        brow.rotation_euler[1] = -d*.25


def gauntlet(center, scale, parent=None):
    x,y,z = center
    items = [ball('Round leather mitten',(x,y,z),(.29*scale,.265*scale,.29*scale),IRON),
             ball('Knuckled metal plate',(x,y-.15*scale,z+.07*scale),(.235*scale,.12*scale,.185*scale),BLUE)]
    for d in (-1,0,1):
        items.append(ball('Cold copper knuckle',(x+d*.111*scale,y-.238*scale,z+.027*scale),(.05*scale,.035*scale,.077*scale),COPPER,16))
    items.append(ball('Hooked thumb',(x-.198*scale,y-.09*scale,z-.135*scale),(.117*scale,.134*scale,.164*scale),IRON,20))
    if parent:
        for o in items:
            o.parent = parent


def boss():
    studio(6.65,(.12,-.03,1.85))
    for d in (-1,1):
        x=d*.61
        ball('Hammer king boot hinge',(x,.08,.55),(.31,.33,.43),BLACK)
        boot = box('Boot with rounded glacier cap',(x,-.29,.28),(.76,.94,.50),IRON,.155)
        boot.rotation_euler[2] = d*.15
        ball('Steel boot cap',(x+d*.04,-.63,.30),(.365,.235,.213),BLUE)
        box('Copper welt',(x,-.34,.12),(.68,.83,.13),COPPER,.065)
        for j in range(3): rivet((x+(j-1)*.142,-.76,.315),.05)
    ball('Squat iron oven boiler',(0,.05,1.42),(1.17,.78,1.11),IRON)
    ball('Cobalt belly enamel',(0,-.08,1.48),(1.065,.75,.92),BLUE)
    for z,r in ((.72,.79),(.83,.93),(1.96,1.06),(2.065,.94)):
        loop('Thick band around the boiler',(0,.05,z),r,.060,COPPER,scale=(1,.66,1))
    for d in (-1,1):
        for z in (.86,1.23,1.66,1.99):
            rivet((d*(.88 if z in (.86,1.99) else .99),-.462,z),.074)
    ball('Recessed round oven door',(0,-.779,1.38),(.64,.127,.53),BLACK)
    loop('Forged elliptical oven ring',(0,-.886,1.38),.531,.095,COPPER,(0,-1,0),(1.14,.9,1))
    ball('Burning furnace interior',(0,-.893,1.36),(.48,.03,.385),EMBER)
    for d in (-1,0,1):
        tongue = ball('Fire tongue',(d*.18,-.928,1.36+(d==0)*.055),(.105,.03,.22-(d!=0)*.065),CORE)
        tongue.rotation_euler[1] = d*.39
    for z in (1.22,1.41,1.60):
        box('Heat grille bar',(0,-.966,z),(.80 if z==1.41 else .73,.075,.083),IRON,.024)
    for x in (-.22,0,.22):
        box('Vertical grill rib',(x,-.979,1.40),(.064,.07,.68 if x==0 else .57),IRON,.022)
    for d in (-1,1):
        ball('Rear oven stack plate',(d*.47,.33,2.43),(.26,.27,.40),IRON)
        rod('Copper vents',(d*.47,.33,2.64),(d*.47,.33,3.04-abs(d+1)*.09),.19,BLUE,r2=.225)
        loop('Vent brass crown',(d*.47,.33,3.02-abs(d+1)*.09),.17,.050,COPPER)
        ball('Open vent',(d*.47,.33,3.009-abs(d+1)*.09),(.128,.128,.022),BLACK)
    ball('Frost helm',(0,-.14,2.21),(.79,.60,.64),IRON)
    ball('Rounded cobalt helmet crown',(0,-.13,2.39),(.745,.57,.53),BLUE)
    eyes(0,-.753,2.385,1.03)
    box('Steel helmet nose ridge',(0,-.802,2.535),(.14,.18,.31),STEEL,.04)
    ball('Copper helmet brow crest',(0,-.57,2.73),(.24,.13,.16),COPPER)
    for x,h in ((-.42,.29),(0,.52),(.40,.33)):
        shard('Frost-forged crown crystal',(x,-.24,2.80-abs(x)*.43),(.22,.16,h),(x*1.3,.25),yaw=.4+x,seed=163+int(10*x))
    for d in (-1,1):
        x=d*1.035
        ball('Wide forged pauldron',(x,.006,2.0),(.55,.53,.454),BLUE)
        loop('Pauldron trim band',(x,-.344,1.955),.367,.056,COPPER,(0,-1,.22),(1.06,.88,1))
        for j in range(3):
            shard('Chunky pauldron ice cut',(x+(j-1)*.22,.005+(j%2)*.17,2.32),(.17,.155,.24+(.14 if j==1 else .015)),(d*.29,.07),yaw=.6+j,seed=j+44)
        for j in range(2): rivet((x+(j-.5)*.29,-.489,2.005),.065)
    rod('Non-dominant cuff',(-1.24,-.008,1.84),(-1.35,-.39,1.21),.235,STEEL)
    loop('Non-dominant trim',(-1.35,-.36,1.30),.236,.054,COPPER,(.1,-.48,-.9))
    gauntlet((-1.40,-.44,1.12),1.16)

    shoulder = Vector((1.12,-.105,1.92))
    pivot = bpy.data.objects.new('Hammer shoulder joint',None)
    bpy.context.collection.objects.link(pivot)
    pivot.location = shoulder
    pivot.rotation_mode = 'QUATERNION'
    # Everything in this assembly is shoulder-local, including the hammer grip.
    elbow = Vector((.47,-.12,-.265))
    grip = Vector((.85,-.245,-.56))
    before = set(bpy.context.collection.objects)
    rod('Upper hammer arm',(0,0,0),elbow,.24,IRON,r2=.26)
    ball('Hammer elbow swivel',elbow,(.306,.28,.28),BLUE)
    rod('Swinging forearm',elbow,grip,.231,STEEL,r2=.255)
    loop('Hammer arm wrist cuff',grip.lerp(elbow,.18),.222,.055,COPPER,(grip-elbow))
    gauntlet(grip,1.13)
    axis = Vector((.22,.05,.976)).normalized()
    head = grip + 1.105*axis
    rod('Hammer grip hickory shaft',grip-.44*axis,head,.103,WOOD,r2=.112)
    for t in (-.40,-.29,-.19,-.085,.07,.2,.34,.47,.60,.83,.98):
        loop('Iron handle bands',grip+t*axis,.104,.025,COPPER if t in (-.40,.98) else IRON,axis)
    cap = box('One piece cast sledge',head,(1.26,.76,.73),IRON,.14)
    cap.rotation_euler[1] = -.16
    for d in (-1,1):
        x,y,z = head+Vector((d*.525,.0,d*.083))
        bit = box('Cobalt hammer striking cap',(x,y,z),(.23,.824,.778),BLUE,.09)
        bit.rotation_euler[1] = -.16
        bit = box('Pale steel strike face',(x+d*.103,y,z+d*.016),(.115,.776,.724),STEEL,.055)
        bit.rotation_euler[1] = -.16
        for zz in (-.23,.23): rivet((x,-.385,z+zz),.061)
    box('Bronze hammer center clasp',head+Vector((0,-.013,0)),(.30,.79,.77),COPPER,.075)
    ball('Hammer cold socket',head+Vector((0,-.435,0)),(.288,.070,.283),IRON)
    s = box('Luminous diamond cold core',head+Vector((0,-.485,.01)),(.264,.082,.264),EYE,.032)
    s.rotation_euler[1] = math.pi*.25
    for o in set(bpy.context.collection.objects)-before:
        o.parent = pivot

    # About actual shoulder socket: rest, two anticipation poses, two accelerating
    # poses, impact, rebound and settle. World origin never becomes a fake hinge.
    angles = [(7,-8,-6),(7,-29,8),(15,-62,12),(20,-70,14),
              (30,-43,-3),(56,44,-31),(35,22,-17),(11,-6,-6)]
    for i,(a,b,c) in enumerate(angles):
        q = (Quaternion((0,0,1),math.radians(c)) @ Quaternion((1,0,0),math.radians(a))
             @ Quaternion((0,1,0),math.radians(b)))
        pivot.rotation_quaternion = q
        pivot.keyframe_insert('rotation_quaternion',frame=i+1)
    S.frame_start,S.frame_end = 1,len(angles)
    S.frame_set(1)
    # Same camera and anchor for base and swing layers.
    render('boss_snow_hammer',384)
    for i in range(len(angles)):
        S.frame_set(i+1)
        assert (pivot.matrix_world.translation-shoulder).length < 1e-6
        render(f'boss_snow_hammer_swing-{i:02}',384)


def guard():
    studio(3.4,(0,-.11,1.01))
    for d in (-1,1):
        ball('Roasted dumpling boot',(d*.40,-.16,.28),(.34,.43,.27),CRUST)
        box('Pale boot buckle',(d*.42,-.46,.29),(.24,.095,.15),COPPER,.042)
    ball('Golden dumpling core',(0,.06,.94),(.72,.63,.75),CREAM)
    ball('Ice navy coat',(0,-.065,.94),(.758,.636,.52),BLUE)
    for i in range(5):
        p = (-.55+.26*i,-.552-.038*(2-abs(i-2)),1.26)
        ridge=ball('Dumpling fold highlight',p,(.108,.10,.25),CREAM)
        ridge.rotation_euler[1] = (i-2)*.32
    ball('Glacier guard helm',(0,-.04,1.55),(.73,.645,.54),BLUE)
    ball('Frosted helmet cap',(0,.025,1.72),(.67,.58,.40),FLOUR)
    eyes(0,-.676,1.574,.83)
    for x in (-.43,.43):
        ball('Guard earmuff',(x,-.455,1.49),(.198,.16,.253),COPPER)
    for i in range(3):
        x = (i-1)*.22
        shard('Frozen helmet crest',(x,-.17,2.005-abs(x)*.25),(.116,.123,.24+(.1 if i==1 else 0)),(x,.2),seed=i+7)
    ball('Dumpling free mitt',(-.73,-.27,.98),(.252,.258,.265),CRUST)
    # Big flat-sided kite silhouette, readable even when the face is partly covered.
    shield=[]
    for y,dim,mat in ((-.51,(1.25,.28,1.38),IRON),(-.661,(1.16,.20,1.29),COPPER),(-.787,(1.00,.14,1.13),ICE_DARK)):
        shield.append(box('Sloped bastion shield',(.60,y,.84),dim,mat,.195))
    stone=box('Shield inlaid glacier sigil',(.60,-.891,.89),(.43,.12,.43),SKY,.067)
    stone.rotation_euler[1]=math.pi*.25; shield.append(stone)
    for x in (.21,1.0):
        for z in (.47,1.21):
            shield.append(rivet((x,-.866,z),.081))
    render('enemy_snow_guard',256)
    mob_pose(shield,(.60,-.50,.92),-.38,offset=(-.26,-.29,.25))
    render('enemy_snow_guard_pose',256)


def needle():
    studio(3.18,(0,-.18,.98))
    for d in (-1,1):
        ball('Tiny candied pastry boot',(d*.265,-.05,.156),(.238,.36,.17),CRUST)
    ball('Tall sugared berry pastry',(0,.05,.92),(.50,.49,.77),BERRY)
    ball('Toasted face',(0,-.262,1.04),(.438,.31,.58),CREAM)
    ball('Powdered top',(0,.056,1.51),(.49,.46,.312),FLOUR)
    for i in range(5):
        t=i*TAU/5
        ball('Snow cap drip',(.4*math.cos(t),.38*math.sin(t),1.44),(.13,.115,.205),FLOUR)
    eyes(0,-.59,1.197,.73)
    ball('Berry cloth mask',(0,-.544,.94),(.47,.13,.17),BERRY)
    for i in range(3):
        p=(.16+(i-1)*.16,.042+(i%2)*.10,1.71)
        shard('Frozen crown quill',p,(.09,.09,.29+(.14 if i==2 else 0)),(.42,.25),yaw=i,seed=i+120)
    # A broad bow, visible ice bolt, and warm red hood (not another blue body).
    box('Cranberry quiver',(0,.43,1.01),(.56,.5,.99),BERRY,.17)
    for i in range(3):
        shard('Quivered bolt',(-.2+.19*i,.46,1.55+.10*(i%2)),(.087,.088,.24),(.13,.23),seed=51+i)
    bow=[]
    bow.append(rod('Crossbow arm',(.41,-.06,.96),(.51,-.56,.74),.155,CRUST))
    bow.append(ball('Gripping mitten',(.51,-.56,.74),(.19,.159,.159),BERRY))
    bow.append(box('Long hickory stock',(.48,-.91,.80),(.26,1.34,.245),WOOD,.073))
    bow.append(rod('Bolt shank',(.48,-.56,.97),(.48,-1.54,.97),.083,SKY))
    bow.append(shard('Glowing gaff tip',(.48,-1.65,.97),(.123,.146,.20),(-.12,-1.3),seed=83))
    for d in (-1,1):
        tip=(.48+d*.60,-.92,.99)
        bow.append(rod('Crossbow front recurve',(.48,-1.33,.88),tip,.109,COPPER,r2=.07))
        bow.append(rod('Taut crossbow strand',tip,(.48,-.65,.99),.023,ICE_LIGHT,verts=12))
    render('enemy_snow_needle',256)
    mob_pose(bow,(.48,-.25,.83),-.44,offset=(0,.06,.14))
    render('enemy_snow_needle_pose',256)


def roller():
    studio(3.13,(0,-.07,.96))
    boots=[]
    for d in (-1,1):
        boots.append(ball('Frozen pretzel wheel toe',(d*.49,-.18,.23),(.33,.44,.22),CRUST))
    ball('Toasted pretzel roller belly',(0,.02,.96),(.85,.66,.91),CRUST)
    loop('Pretzel belt outer tread',(0,-.275,.95),.752,.151,CRUST,(0,-1,0),(1,.99,1))
    loop('Pretzel belt golden toasted facing',(0,-.382,.95),.748,.105,CREAM,(0,-1,0),(1,.99,1))
    for i in range(12):
        a=TAU*i/12
        x,z=.75*math.cos(a),.95+.76*math.sin(a)
        ball('Chunky pretzel rock salt',(x,-.452,z),(.069,.062,.08),FLOUR,16)
        cap = box('Tread hardened ice stud',(x,-.41,z),(.30,.36,.26),BLUE,.062)
        cap.rotation_euler[1] = -a
    ball('Pretzel frozen mask',(0,-.575,1.07),(.675,.207,.558),ICE_DARK)
    ball('Roller mask ice highlight',(0,-.677,1.175),(.586,.123,.38),SKY)
    eyes(0,-.786,1.164,.93)
    # Small sharp rear nibs reinforce direction when the body is flicked to roll.
    for j,(x,y) in enumerate(((-.47,.10),(.29,.24),(.50,.136))):
        shard('Pretzel rolling spine',(x,y,1.59),(.15,.17,.36),(.49,.19),seed=110+j)
    render('enemy_snow_roller',256)
    for boot in boots:
        boot.hide_render=True
    loop('Continuous rolling ice tread',(0,-.22,.96),.862,.139,ICE_DARK,(0,-1,0),(1,1,1))
    for j in range(5):
        a=j*TAU/5
        rod('Glacier wheel spoke',(.15*math.cos(a),-.794,.96+.15*math.sin(a)),(.84*math.cos(a),-.67,.96+.84*math.sin(a)),.115,ICE,r2=.164)
    ball('Glowing wheel hub',(0,-.84,.96),(.30,.146,.30),ICE_LIGHT)
    render('enemy_snow_roller_pose',256)


def mob_pose(parts, pivot, angle, offset=(0,0,0)):
    q = Quaternion((1,0,0), angle)
    pivot = Vector(pivot)
    for o in parts:
        o.location = pivot + q @ (o.location-pivot) + Vector(offset)
        o.rotation_euler = (q @ o.rotation_euler.to_quaternion()).to_euler()


def patrol(keg=False):
    studio(3.33,(0,-.08,.99))
    for d in (-1,1):
        ball('Traction boot',(d*.37,-.27,.235),(.29,.39,.225),WOOD)
        box('Toe cap',(d*.37,-.50,.23),(.36,.22,.20),IRON,.09)
        ball('Wool mitten',(d*.72,-.27,.83),(.194,.208,.20),BERRY if keg else IRON)
    ball('Roast pastry',(0,.06,.91),(.68,.58,.74),CRUST)
    ball('Toasted face',(0,-.37,1.23),(.48,.30,.42),CREAM)
    eyes(0,-.63,1.30,.76)
    if keg:
        box('Red cask apron',(0,-.22,.74),(1.21,.93,.83),BERRY,.235)
        for z in (.46,.90):
            loop('Copper bands',(0,-.21,z),.59,.057,COPPER,scale=(1,.79,1))
        box('Square pressure gauge',(0,-.695,.70),(.42,.14,.32),BLACK,.09)
        ball('Hot pressure indicator',(0,-.78,.70),(.105,.018,.09),CORE)
        ball('Berry keg cap',(0,.02,1.55),(.61,.54,.31),BERRY)
        rod('Bent match wick',(.24,.04,1.75),(.46,.08,2.00),.078,WOOD)
        ball('Hot match tip',(.46,.08,2.00),(.10,.10,.117),EMBER)
    else:
        box('Coal shoulder satchel',(.53,.46,.95),(.61,.42,.86),IRON,.16)
        ball('Saffron hood',(0,.086,1.42),(.64,.56,.49),COPPER)
        loop('Thick toasted collar',(0,-.08,.96),.51,.144,BERRY,scale=(1,.84,1))
        ball('Overhanging snow bonnet',(0,.03,1.68),(.55,.55,.19),FLOUR)
        ball('Bonnet pompom',(.17,.085,1.87),(.145,.138,.159),FLOUR)
        rod('Icepick handle',(.6,-.275,.50),(.89,-.23,1.04),.079,WOOD)
        rod('Curved pick head',(.56,-.32,1.06),(1.04,-.16,1.14),.105,STEEL,r2=.059)
        shard('Pick scar',(1.04,-.17,1.11),(.083,.076,.21),(-.12,.07),seed=28)
    render('enemy_snow_keg' if keg else 'enemy_snow_scout',256)


def frost_plow():
    studio(4.16,(.04,-.20,1.22),angle=(4.8,-9,6.4))
    for d in (-1,1):
        ball('Siege track assembly',(d*.79,-.04,.49),(.4,.77,.42),BLACK)
        for y in (-.48,-.13,.22,.55):
            box('Rose metal track link',(d*.99,y,.42),(.26,.27,.48),IRON,.091)
        ball('Chassis pauldron',(d*.91,-.03,1.36),(.48,.47,.43),VIOLET)
        rod('Caribou siege horn',(d*.54,-.06,1.83),(d*.95,.07,2.17),.175,CREAM,r2=.117)
        rod('Horn point',(d*.95,.07,2.17),(d*1.11,.10,2.58),.117,CREAM,r2=.015)
    box('Purple forge armor',(0,.03,1.0),(1.58,1.29,1.23),VIOLET,.28)
    ball('Commander helm',(0,-.1,1.64),(.67,.63,.53),IRON)
    box('Warm helm brow',(0,-.62,1.83),(1.10,.28,.26),COPPER,.115)
    eyes(0,-.73,1.58,1.0)
    ball('Ice furnace top',(0,-.05,2.08),(.334,.34,.188),ICE_DARK)
    shard('Furnace exhaust',(0,-.01,2.27),(.149,.181,.23),(.05,.06),seed=85)
    plow=[]
    for d in (-1,1):
        o=box('Obsidian plow cheek',(d*.55,-.88,.69),(1.23,.35,.91),IRON,.12)
        o.rotation_euler[2]=d*.34; plow.append(o)
        o=box('Golden plow cutting blade',(d*.55,-.923,.425),(1.28,.39,.22),COPPER,.074)
        o.rotation_euler[2]=d*.34; plow.append(o)
        for i in range(3):
            x=d*(.33+i*.295)
            plow.append(rivet((x,-1.133+i*.098,.76)))
    plow.append(ball('Hot forge grille',(0,-1.09,.825),(.192,.084,.144),EMBER))
    render('enemy_snow_elite',256)
    mob_pose(plow,(0,-.54,.6),-.54,offset=(0,-.03,.18))
    render('enemy_snow_elite_pose',256)


def cover():
    studio(3.68,(0,-.14,.92))
    ball('Compact glacial foot',(0,-.04,.106),(1.23,.73,.116),ICE_DARK)
    ball('Pressed snow under formation',(.02,-.11,.148),(1.17,.69,.132),SNOW_BLUE)
    gems = [(-.59,.10,.06,.55,.52,1.31),(.1,.20,.06,.63,.57,2.14),
            (.64,.081,.03,.47,.49,1.53),(-.18,-.34,.08,.39,.32,1.26),
            (.74,-.31,.055,.34,.31,.71),(-.93,-.15,.10,.28,.25,.62)]
    for i,(x,y,z,w,d,h) in enumerate(gems):
        shard('Thick run-blocking glacial crystal',(x,y,z),(w,d,h),((-1)**i*.25,.22),yaw=.37+i*.3,seed=17+i)
    for i,(x,y,w) in enumerate(((-.89,-.42,.28),(-.44,-.53,.5),(.11,-.53,.43),(.63,-.46,.52),(.93,-.22,.23))):
        ball('Packed white snow drift',(x,y,.186),(w,.264,.145 if i%2 else .17),FLOUR)
    render('snow_ice_cover',256)


def projectile():
    studio(2.9,(0,0,.34),angle=(0,-1,12))
    # Points right in texture space, ready for game rotation from its travel vector.
    a=(-.92,0,.34); b=(.36,0,.34)
    rod('Needle cobalt core',a,b,.145,SKY,r2=.154,verts=6)
    rod('Needle point',b,(1.18,0,.34),.156,ICE_LIGHT,r2=.005,verts=6)
    rod('Bright glacial glint',(-.72,-.022,.475),(.76,-.002,.416),.03,EYE,r2=.01,verts=8)
    loop('Blunt cold ferrule',(-.74,0,.34),.142,.035,COPPER,(1,0,0))
    for d in (-1,1):
        rod('Needle tail flange',(-.84,d*.29,.32),(-.57,0,.33),.036,SKY,r2=.092,verts=5)
    render('projectile_snow_needle',128)


def fence():
    studio(10.45,(0,0,.22),angle=(.08,-2.4,15))
    rng=random.Random(18)
    radius=4.64
    for row in range(2):
        for i in range(54):
            t=(i+row*.5)*TAU/54
            x,y=radius*math.cos(t),radius*math.sin(t)
            brick=box('Frost canyon ashlar',(x,y,.14+row*.22+rng.uniform(-.014,.014)),
                      (.28,.527,.25),rng.choice((ICE,ICE,ICE_DARK,BLUE,SKY)),.071)
            brick.rotation_euler[2]=t+rng.uniform(-.035,.035)
    for i in range(54):
        t=i*TAU/54
        x,y=radius*math.cos(t),radius*math.sin(t)
        cap=box('Packed frost wall coping',(x,y,.52),(.325,.526,.12),
                rng.choice((FLOUR,SNOW_BLUE,ICE_LIGHT)),.048)
        cap.rotation_euler[2]=t
    for i in range(10):
        t=(i+.5)*TAU/10
        x,y=radius*math.cos(t),radius*math.sin(t)
        pillar=box('Rounded armored ice buttress',(x,y,.29),(.56,.62,.57),STEEL,.12)
        pillar.rotation_euler[2]=t
        cap=box('Retaining band cast in copper',(x,y,.47),(.59,.65,.12),COPPER,.055)
        cap.rotation_euler[2]=t
        shard('Glacial ledge crystal finial',(x,y,.48),(.27,.243,.53),(.29*math.cos(t),.29*math.sin(t)),yaw=t,seed=162+i)
    render('duel_fence_snow',768)


def powder_material():
    material = bpy.data.materials.new('Soft density of suspended glacial powder')
    material.use_nodes = True
    nodes, links = material.node_tree.nodes, material.node_tree.links
    nodes.clear()
    out = nodes.new('ShaderNodeOutputMaterial')
    volume = nodes.new('ShaderNodeVolumePrincipled')
    volume.inputs['Color'].default_value = (.68,.83,.95,1)
    volume.inputs['Anisotropy'].default_value = .22
    links.new(volume.outputs['Volume'],out.inputs['Volume'])
    generated = nodes.new('ShaderNodeTexCoord').outputs['Generated']
    distance = nodes.new('ShaderNodeVectorMath')
    distance.operation = 'DISTANCE'
    distance.inputs[1].default_value = (.5,.5,.5)
    links.new(generated,distance.inputs[0])
    radial = nodes.new('ShaderNodeMapRange')
    radial.clamp = True
    radial.interpolation_type = 'SMOOTHSTEP'
    radial.inputs['From Min'].default_value = .20
    radial.inputs['From Max'].default_value = .50
    radial.inputs['To Min'].default_value = 1.75
    radial.inputs['To Max'].default_value = 0
    links.new(distance.outputs['Value'],radial.inputs['Value'])
    noise = nodes.new('ShaderNodeTexNoise')
    noise.noise_dimensions = '4D'
    noise.inputs['Scale'].default_value = 6.0
    noise.inputs['Detail'].default_value = 2
    links.new(generated,noise.inputs['Vector'])
    links.new(nodes.new('ShaderNodeObjectInfo').outputs['Random'],noise.inputs['W'])
    multiply = nodes.new('ShaderNodeMath')
    multiply.operation = 'MULTIPLY'
    links.new(radial.outputs[0],multiply.inputs[0])
    links.new(noise.outputs['Fac'],multiply.inputs[1])
    links.new(multiply.outputs[0],volume.inputs['Density'])
    return material


def animate_shards(mode, count=8):
    # The particles live in three-dimensional space; transparent pixels come from
    # Blender film alpha rather than a removed white backing or vector overlays.
    avalanche = mode == 'avalanche'
    eruption = mode == 'ice_spikes'
    studio(8.8 if avalanche else (5.15 if eruption else 6.0), (.12 if avalanche else 0,-.04,.83), angle=(.70,-9,6.7))
    rng=random.Random({'avalanche':313,'ice_spikes':931,'ice_shatter':425}[mode])
    persistent=[]
    if eruption:
        for i,x in enumerate((-1.59,-1.12,-.52,.06,.69,1.28,1.67)):
            y=rng.uniform(-.36,.33)
            gem=shard('Erupting ice column',(x,y,0),(.49,.42,rng.uniform(1.15,2.35)),(x*.31,.32),seed=i+101)
            persistent.append((gem,Vector((x,y,0)),i))
        for i in range(4):
            x = -.95 + i*.63
            gem=shard('Secondary ice tooth',(x,-.53,0),(.31,.33,1.08),(x*.46,.05),seed=i+19)
            persistent.append((gem,Vector((x,-.53,.011)),i+2))
    puffs=[]
    powder = powder_material() if avalanche else None
    for i in range(40 if avalanche else 18):
        x=rng.uniform(-2.7,2.7) if avalanche else rng.uniform(-1.45,1.45)
        y=rng.uniform(-.66,.66)
        size=rng.uniform(.16,.62) if avalanche else rng.uniform(.075,.19)
        mist = avalanche and i%2 == 0
        if mist:
            bpy.ops.mesh.primitive_cube_add(size=2)
            puff=ob(powder,'Volumetric air-borne snow',False)
        else:
            puff=ball('Dense falling snow cullet',(0,0,0),(1,1,1),SNOW_WHITE if i%3 else SNOW_BLUE,16)
            if avalanche:
                for j,v in enumerate(puff.data.vertices):
                    v.co *= .92 + .15 * math.cos(v.co.x * 7+i) * math.sin(v.co.y * 4+j%3)
        puffs.append((puff,x,y,size,rng.random(),mist))
    pieces=[]
    for i in range(24 if avalanche else (22 if eruption else 35)):
        ang=rng.uniform(0,TAU)
        travel=rng.uniform(.95,2.4)
        size=rng.uniform(.068,.29)
        cr=shard('Spinning free ice debris',(0,0,0),(size,size*.77,size*rng.uniform(1.4,3)),(.63,.24),seed=i+166)
        pieces.append((cr,ang,travel,rng.uniform(.15,1),rng.uniform(-1,1)))

    for i in range(count):
        t=(i+.28)/(count-.45)
        for gem,loc,j in persistent:
            local_t=max(0,min(1,(t-j*.023)*3.4))
            height=(1-(1-local_t)**2)*(1- max(0,t-.53)**1.4*2.56)
            gem.location=loc
            gem.scale=(max(.01,height**.33),max(.01,height**.33),max(.001,height))
        for puff,x,y,s,offset,mist in puffs:
            pt=max(.0,t-offset*.145)
            if avalanche:
                pop=(.33+1.25*math.sin(min(1,pt+.05)*math.pi)**.74)*(1-pt*.43)
                front=1.9-3.55*t
                puff.location=(x*(.55+.80*t),front+y*1.16+.76*offset,
                               s*.65+math.sin(pt*math.pi)*(1.02-abs(y)*.48)*offset+(0.42 if mist else 0))
                n=s*pop*(2.05 if mist else .69)
            else:
                puff.location=(x*(.15+1.32*t),y*(.3+2.8*t),s+.25*math.sin(pt*math.pi))
                n=s*(.38+math.sin(pt*math.pi)*1.08)*(1-t*.8)
            puff.scale=(n*1.37,n,n*.86)
        for j,(cr,a,d,lo,spin) in enumerate(pieces):
            pt=max(0,t-lo*.13)
            if avalanche:
                cr.location=(math.cos(a)*d*(.79+.40*t),1.62-3.82*t+math.sin(a)*lo,
                             .26+math.sin(pt*math.pi)*lo*1.3)
            else:
                cr.location=(math.cos(a)*d*pt, math.sin(a)*d*pt, .07+math.sin(pt*math.pi)*lo*1.65)
            f=max(.04,(1-t**2.7))*(.50+min(1,pt*6)*.5)
            cr.scale=(f,f,f)
            cr.rotation_euler=(spin*(.28+t*5),t*4*lo,spin*t*7)
        render(f'vfx_snow_{mode}-{i:02}',256)


if GROUP in ('all','boss'):
    boss()
if GROUP in ('all','props'):
    cover()
    projectile()
if GROUP in ('all','props','mobs'):
    patrol()
    patrol(keg=True)
    guard()
    needle()
    roller()
    frost_plow()
if GROUP in ('all','fence'):
    fence()
if GROUP in ('all','vfx'):
    for fx in ('ice_spikes','avalanche','ice_shatter'):
        animate_shards(fx)
