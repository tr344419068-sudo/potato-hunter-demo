import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const api = build({ stdin: { resolveDir: root, contents: `
  export * from './src/progression/CampaignGrowth';
  export * from './src/progression/ProgressionStore';
  export * from './src/campaign/CampaignModel';
  export * from './src/managers/WaveManager';
  export * from './src/managers/ConfigManager';
` }, bundle: true, platform: 'node', format: 'esm', write: false })
  .then(({ outputFiles }) => import(`data:text/javascript;base64,${Buffer.from(outputFiles[0].text).toString('base64')}`));
const win = { outcome: 'victory', elapsedMs: 265_000, kills: 220, bossKills: 4, gold: 12 };

test('desert first clear unlocks snow with no extra course of grinding and pays first-clear gold once', async () => {
  const { ProgressionStore } = await api;
  const values = new Map();
  const storage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) };
  const store = new ProgressionStore(storage);
  assert.equal(store.selectStage('snow').ok, false);
  store.settleRun('snow-test-meadow', win, 'meadow');
  assert.equal(store.selectStage('snow').ok, false);
  assert.equal(store.settleRun('snow-test-desert-loss', { ...win, outcome: 'defeat' }, 'desert').unlockedStage, undefined);
  assert.equal(store.settleRun('snow-test-desert-win', win, 'desert').unlockedStage, 'snow');
  const resumed = new ProgressionStore(storage);
  assert.equal(resumed.getCampaignProgress().selectedStage, 'snow');
  assert.equal(resumed.selectStage('snow').ok, true);
  assert.equal(resumed.settleRun('snow-test-win', win, 'snow').firstClearBonus, 120);
  assert.equal(resumed.settleRun('snow-test-replay', win, 'snow').firstClearBonus, 0);
  assert.deepEqual(new ProgressionStore(storage).getCampaignProgress().clearedStages, ['meadow', 'desert', 'snow']);
});

test('old desert clears unlock snow but preserve explicit selection and reject out-of-order clears', async () => {
  const { normalizeCampaignProgress, stageUnlocked } = await api;
  const old = normalizeCampaignProgress({ selectedStage: 'desert', clearedStages: ['meadow', 'desert'], stageSelectionConfirmed: true }, 2);
  assert.equal(old.selectedStage, 'desert');
  assert.equal(stageUnlocked(old, 'snow'), true);
  assert.deepEqual(normalizeCampaignProgress({ clearedStages: ['meadow', 'snow'] }, 2).clearedStages, ['meadow']);
});

test('snow gets a four-minute cadence and a late pressure/respite beat without lengthening either earlier map', async () => {
  const { CampaignDirector, getCampaignBeat, getFinalBossAtMs } = await api;
  for (const stage of ['meadow', 'desert']) {
    assert.equal(getFinalBossAtMs(stage), 180_000);
    assert.equal(new CampaignDirector(4, stage).nextBoss(180_000), 'final');
  }
  const snow = new CampaignDirector(4, 'snow');
  const windows = [55_000, 116_000, 184_000];
  assert.deepEqual(windows.map(t => snow.nextBoss(t)), ['intermediate', 'intermediate', 'intermediate']);
  assert.equal(snow.nextBoss(239_999), undefined);
  assert.equal(snow.nextBoss(240_000), 'final');
  assert.equal(snow.nextBoss(241_000), undefined);
  assert.equal(getCampaignBeat(212_000, 'snow').phase, 'pressure');
  assert.equal(getCampaignBeat(231_000, 'snow').phase, 'respite');
  assert.match(getCampaignBeat(240_000, 'snow').objective, /霜炉重锤王/);
});

test('snow waves include a gradual entrance and combined stage-specific threats before finale', async () => {
  const { WaveManager } = await api;
  const snow = new WaveManager('snow');
  const roster = seconds => snow.getCurrentWave(seconds * 1000).monsterMix.map(entry => entry.monsterId);
  assert.ok(roster(0).includes('snow_guard'));
  assert.ok(!roster(0).includes('snow_roller'));
  for (const monster of ['snow_guard', 'snow_needle', 'snow_roller']) assert.ok(roster(205).includes(monster));
});

test('snow only draws snow-native mobs and preserves the two previous maps', async () => {
  const { WaveManager, ConfigManager } = await api;
  for (const stage of ['meadow', 'desert', 'snow']) {
    const wave = new WaveManager(stage);
    for (const t of [0, 14, 36, 78, 122, 190, 205]) {
      const ids = wave.getCurrentWave(t * 1000).monsterMix.map(entry => entry.monsterId);
      assert.ok(ids.every(id => id.startsWith('snow_') === (stage === 'snow')), `${stage} ${t}s: ${ids}`);
    }
  }
  assert.equal(ConfigManager.getMonster('snow_scout').behavior, 'chaser');
  assert.equal(ConfigManager.getMonster('snow_keg').behavior, 'exploder');
});

test('snow roles have explicit stage-scoped visual sizes independent of their hitboxes', async () => {
  const { ConfigManager } = await api;
  const sizes = ['scout', 'needle', 'keg', 'guard', 'roller', 'elite'].map(role => {
    const monster = ConfigManager.getMonster(`snow_${role}`);
    const asset = ConfigManager.assets[monster.assetId];
    assert.equal(asset.stage, 'snow');
    assert.ok(asset.displaySize >= 57 && asset.displaySize > monster.radius * 2, role);
    return asset.displaySize;
  });
  assert.deepEqual([...new Set(sizes)].sort((a,b) => a-b), sizes);
});
