import assert from "node:assert/strict";
import test from "node:test";

import { UIOverlayController } from "../src/ui/UIOverlayController.ts";

test("replacing an overlay destroys the previous owner exactly once", () => {
  let firstDestroyCount = 0;
  const first = { destroy: () => { firstDestroyCount += 1; } };
  const second = { destroy: () => {} };
  const controller = new UIOverlayController();

  controller.replace(first);
  controller.replace(second);

  assert.equal(firstDestroyCount, 1);
  assert.equal(controller.current, second);
});

test("layout is forwarded only to the active layout-aware overlay", () => {
  const received = [];
  const controller = new UIOverlayController();
  controller.replace({ destroy: () => {}, layout: (layout) => received.push(layout) });

  controller.layout("portrait");
  controller.clear();
  controller.layout("desktop");

  assert.deepEqual(received, ["portrait"]);
  assert.equal(controller.current, undefined);
});
