"""Crop four authored effects from the 1024px transparent RemBg source sheet."""
from pathlib import Path
import sys

from PIL import Image, ImageChops, ImageDraw


def main(source_path: str) -> None:
    source = Image.open(source_path).convert("RGBA")
    if source.size != (1024, 1024) or source.getextrema()[-1][0] != 0:
        raise ValueError("Expected the 1024×1024 transparent RemBg export")
    target = Path(__file__).resolve().parents[1] / "public/assets/vfx/desert-sovereign-v1"
    target.mkdir(parents=True, exist_ok=True)
    # Polygon points use the review sheet's 768px coordinates. They cut only the gutters.
    sprites = {
        "wave": ((512, 224), [(0, 72), (476, 72), (476, 345), (0, 345)]),
        "cyclone": ((288, 416), [(476, 0), (767, 0), (767, 430), (476, 430)]),
        "sandfall": ((384, 352), [(0, 345), (328, 345), (328, 576), (333, 609), (407, 721), (0, 721)]),
        "wind": ((448, 176), [(328, 444), (767, 444), (767, 680), (403, 680), (333, 609), (328, 576)]),
    }
    for name, (size, polygon) in sprites.items():
        mask = Image.new("L", source.size)
        ImageDraw.Draw(mask).polygon([(int(x * 4 / 3), int(y * 4 / 3)) for x, y in polygon], fill=255)
        sprite = source.copy()
        sprite.putalpha(ImageChops.multiply(mask, source.getchannel("A")))
        sprite = sprite.crop(sprite.getbbox())
        pixels = sprite.load()
        # RemBg preserved a thin white matte on some edges. Suppress the near-neutral whites
        # while keeping warm glints and softer, low-alpha dust.
        for y in range(sprite.height):
            for x in range(sprite.width):
                r, g, b, a = pixels[x, y]
                whiteness = min(max(0, (b - 218) / 31), max(0, 1 - (r - b) / 26))
                pixels[x, y] = (r, g, b, round(a * (1 - whiteness * .94)))
        sprite.thumbnail((size[0] - 8, size[1] - 8), Image.Resampling.LANCZOS)
        sheet = Image.new("RGBA", size)
        sheet.paste(sprite, ((size[0] - sprite.width) // 2, (size[1] - sprite.height) // 2))
        sheet.save(target / f"{name}.webp", method=6, quality=88, exact=False)
    # Reuse the painted camera angle and masonry from the sandstone arena art.
    fence = Image.open(target.parent / "boss-duel-sg-v1/desert-fence.png").convert("RGBA")
    fence.crop((248, 3, 520, 89)).save(target / "windbreak.webp", method=6, quality=88, exact=False)


if __name__ == "__main__":
    main(sys.argv[1])
