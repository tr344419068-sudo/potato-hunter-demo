import assert from 'node:assert/strict';
import test from 'node:test';
import {build} from 'esbuild';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {loadImage,createCanvas} from '@napi-rs/canvas';
import {createHash} from 'node:crypto';
const root=fileURLToPath(new URL('../',import.meta.url));
const api=build({stdin:{contents:`export * from './src/systems/AuthoredHeroModel.ts'; export {AuthoredHeroView} from './src/systems/AuthoredHeroView.ts';`,resolveDir:root,loader:'ts'},bundle:true,platform:'node',format:'esm',write:false}).then(r=>import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));
test('authored rig has six required actions and independently posed limbs, not a UV warp',async()=>{
 const {HERO_ACTIONS,getAuthoredHeroPose}=await api;assert.deepEqual(Object.keys(HERO_ACTIONS),['idle','run','attack','dash','hit','death']);
 const pose=getAuthoredHeroPose({action:'run',timeMs:100,phase:0,moving:true,attack:0});assert.equal(pose.length,7);assert.equal(pose.find(p=>p.id==='body').rotation<.04,true);assert.ok(pose.every(p=>[p.x,p.y,p.rotation,p.scaleX,p.scaleY,p.alpha].every(Number.isFinite)));
 const a=getAuthoredHeroPose({action:'run',timeMs:200,phase:Math.PI,moving:true,attack:0});assert.notEqual(pose.find(p=>p.id==='left_boot').rotation,a.find(p=>p.id==='left_boot').rotation);
});
test('planted foot stays grounded and only opposite foot lifts during the stride',async()=>{const {getAuthoredHeroPose,HERO_RIG}=await api;for(let i=0;i<32;i++){const phase=i/32*Math.PI*2;const p=getAuthoredHeroPose({action:'run',timeMs:0,phase,moving:true,attack:0});let feet=[];for(const id of ['left_boot','right_boot']){const part=p.find(p=>p.id===id),bone=HERO_RIG[id],point=bone.end;feet.push(part.y+Math.sin(part.rotation)*(point.x-bone.joint.x)+Math.cos(part.rotation)*(point.y-bone.joint.y));}assert.ok(Math.max(...feet)>238&&Math.max(...feet)<243,'one heel remains near ground');assert.ok(Math.min(...feet)>226,'swing does not turn into a hop');}});
test('weapon arm has windup, contact and recovery while walking continues',async()=>{const {getAuthoredHeroPose}=await api;const base={action:'attack',timeMs:0,phase:1,moving:true};const a=getAuthoredHeroPose({...base,attack:.25}),b=getAuthoredHeroPose({...base,attack:.6}),c=getAuthoredHeroPose({...base,attack:1});assert.notEqual(a.find(p=>p.id==='left_arm').rotation,b.find(p=>p.id==='left_arm').rotation);assert.ok(Math.abs(c.find(p=>p.id==='left_arm').rotation)<.2);assert.notEqual(a.find(p=>p.id==='left_thigh').rotation,0);});
test('death legitimately overrides per-shot contact without changing its authored pose',async()=>{const {getAuthoredHeroPose}=await api;const input={action:'death',timeMs:250,phase:1,moving:false,attack:0};assert.deepEqual(getAuthoredHeroPose({...input,releaseContact:1,releaseRecoil:.016}),getAuthoredHeroPose(input));});
test('real articulated view freezes elapsed action clock on pause, mirrors and falls back safely',async()=>{
 const {AuthoredHeroView}=await api;const objects=[];const image=(x,y,key)=>{const o={x,y,key,destroyed:false,setOrigin(){return this},setDepth(){return this},setDisplaySize(){return this},setPosition(x,y){this.x=x;this.y=y;return this},setScale(x,y){this.sx=x;this.sy=y;return this},setRotation(r){this.r=r;return this},setAlpha(a){this.a=a;return this},setTint(){return this},clearTint(){return this},setVisible(){return this},destroy(){this.destroyed=true}};objects.push(o);return o};
 const scene={textures:{exists:()=>true},add:{image},events:{once(){}}};const view=new AuthoredHeroView(scene);const input={entityId:1,assetId:'char_potato_hunter',x:0,y:0,worldX:0,worldY:0,visualSize:84,pivot:{x:.5,y:.65},facingX:1,alpha:1,deltaMs:16,attack:0,dead:false,dashing:false,hit:false};assert.equal(view.draw(input),true);assert.equal(objects.length,7);view.draw({...input,worldX:4});const before=objects.map(o=>({x:o.x,y:o.y,r:o.r}));view.draw({...input,worldX:4,deltaMs:0});assert.deepEqual(objects.map(o=>({x:o.x,y:o.y,r:o.r})),before);view.draw({...input,worldX:8,facingX:-1});assert.ok(objects.every(o=>o.sx<0));view.prune(new Set());assert.ok(objects.every(o=>o.destroyed));assert.equal(new AuthoredHeroView({...scene,textures:{exists:()=>false}}).draw(input),false);
});
test('accepted weapon event sequence starts authored windup immediately even before smear becomes visible',async()=>{
 const {AuthoredHeroView}=await api,objects=[];const scene={textures:{exists:()=>true},events:{once(){}},add:{image(x,y,key){const o={key,r:0,setOrigin(){return this},setDepth(){return this},setDisplaySize(){return this},setScale(){return this},setPosition(){return this},setRotation(r){this.r=r;return this},setAlpha(){return this},setVisible(){return this},clearTint(){return this},destroy(){}};objects.push(o);return o}}};
 const view=new AuthoredHeroView(scene),input={entityId:1,assetId:'char_potato_hunter',x:0,y:0,worldX:0,worldY:0,visualSize:84,pivot:{x:.5,y:.65},facingX:1,alpha:1,deltaMs:16,attack:0,attackSequence:0,dead:false,dashing:false,hit:false};
 view.draw(input);view.draw({...input,attackSequence:1});view.draw({...input,attackSequence:1,deltaMs:55});assert.ok(objects.find(o=>o.key==='asset:hero_part_left_arm').r<-.15);
});
test('exported source layers and authored action sheets have alpha, finite pivots and no missing actions',async()=>{
 const manifest=JSON.parse(await readFile(root+'artifacts/source-character/hero-v3-manifest.json','utf8'));assert.equal(manifest.method,'articulated-2d-source-layers');assert.equal(manifest.source,'public/assets/characters/potato_hunter/idle-v2.png');
 assert.equal(createHash('sha256').update(await readFile(root+manifest.source)).digest('hex'),manifest.sourceSha256,'manifest source hash does not match the actual source PNG');
 assert.deepEqual(manifest.clips.map(clip=>clip.action),['idle','run','attack','dash','hit','death']);assert.deepEqual(manifest.parts.map(part=>part.id),['right_thigh','right_boot','left_thigh','left_boot','body','right_arm','left_arm']);
 for(const clip of manifest.clips){const img=await loadImage(root+clip.path);assert.equal(img.width,clip.frameWidth*clip.frameCount);assert.equal(img.height,clip.frameHeight);assert.ok(clip.frameCount>=6);}
 for(const part of manifest.parts){const img=await loadImage(root+part.path);assert.equal(img.width,256);const c=createCanvas(256,256),ctx=c.getContext('2d');ctx.drawImage(img,0,0);const rgba=ctx.getImageData(0,0,256,256).data;assert.ok(rgba.some((v,i)=>i%4===3&&v>0));assert.equal(rgba[3],0);assert.ok([part.pivot.x,part.pivot.y].every(Number.isFinite));}
});

test('the painted hem between the boots belongs only to the torso', async () => {
 const art = root + 'public/assets/characters/potato_hunter/';
 const hem = async path => {
  const context = createCanvas(26, 10).getContext('2d');
  context.drawImage(await loadImage(art + path), -132, -194);
  return context.getImageData(0, 0, 26, 10).data;
 };
 const source = await hem('idle-v2.png');
 assert.ok(source.some((value, index) => index % 4 === 3 && value === 255));
 assert.deepEqual(await hem('articulated-v3/body.png'), source);
 for (const part of ['left_thigh', 'left_boot', 'right_thigh', 'right_boot']) {
  const rgba = await hem(`articulated-v3/${part}.png`);
  assert.ok(!rgba.some((value, index) => index % 4 === 3 && value > 0), `${part} must not animate the center hem`);
 }
});

test('horizontal and vertical runtime strides keep both boot silhouettes readable', async () => {
 const { AuthoredHeroView, HERO_RIG } = await api;
 const directions = [[1, 0], [-1, 0], [0, 1], [0, -1], [Math.SQRT1_2, Math.SQRT1_2], [Math.SQRT1_2, -Math.SQRT1_2]];
 for (const [dx, dy] of directions) {
  const objects = new Map();
  const view = new AuthoredHeroView({ textures: { exists: () => true }, events: { once() {} }, add: { image(x, y, key) {
   const image = { setOrigin() { return this; }, setDepth() { return this; },
    setScale(x, y) { this.sx = x; this.sy = y; return this; }, setPosition(x, y) { this.x = x; this.y = y; return this; },
    setRotation(angle) { this.angle = angle; return this; }, setAlpha() { return this; },
    setVisible() { return this; }, clearTint() { return this; } };
   objects.set(key.replace('asset:hero_part_', ''), image);
   return image;
  } } });
  const point = (part, { x, y }) => {
   const image = objects.get(part), joint = HERO_RIG[part].joint;
   const sx = (x - joint.x) * image.sx, sy = (y - joint.y) * image.sy;
   return { x: image.x + sx * Math.cos(image.angle) - sy * Math.sin(image.angle),
    y: image.y + sx * Math.sin(image.angle) + sy * Math.cos(image.angle) };
  };
  const bodyY = [], stepHeights = [], planted = new Set(), previous = new Map();
  for (let frame = 0; frame < 75; frame++) {
   const travel = frame * 220 * .016;
   const worldX = dx * travel, worldY = dy * travel;
   view.draw({ entityId: 1, assetId: 'char_potato_hunter', x: 0, y: 0, worldX, worldY,
    visualSize: 84, pivot: { x: .5, y: .65 }, facingX: dx < 0 ? -1 : 1, alpha: 1, deltaMs: 16, attack: 0,
    dead: false, dashing: false, hit: false });
   if (frame > 0) bodyY.push(objects.get('body').y);
   const heels = [];
   for (const side of ['left', 'right']) {
    const boot = `${side}_boot`, cuff = `${side}_thigh`, ankle = objects.get(boot);
    assert.ok(Math.abs(ankle.angle) <= .65, `${side} sole tipped vertically at ${dx},${dy} on frame ${frame}`);
    const cuffEnd = point(cuff, HERO_RIG[cuff].end);
    assert.ok(Math.hypot(cuffEnd.x - ankle.x, cuffEnd.y - ankle.y) < .001, 'cuff and boot share an ankle');
    const heel = point(boot, HERO_RIG[boot].end);
    const world = { x: worldX + heel.x, y: worldY + heel.y }, last = previous.get(boot);
    if (last && Math.hypot(world.x - last.x, world.y - last.y) < .02) planted.add(boot);
    previous.set(boot, world);
    heels.push(heel.y);
   }
   stepHeights.push(heels[0] - heels[1]);
  }
  assert.ok(Math.max(...bodyY) - Math.min(...bodyY) < .1, 'the walk does not bounce the torso');
  assert.ok(Math.min(...stepHeights) < -.5 && Math.max(...stepHeights) > .5, 'both feet visibly take turns stepping');
  assert.equal(planted.size, 2, `both feet get a world-space stance at ${dx},${dy}`);
 }
});

test('Pepper and its evolution cannot replace the authored arms or add a held sprite', async () => {
 const { AuthoredHeroView, HERO_RIG } = await api;
 for (const skillId of ['pepper_gatling', 'pepper_overdrive']) {
  const objects = [];
  const scene = { textures: { exists: () => true }, add: { image(x, y, key) {
   const image = { texture: { key }, setTexture(key) { this.texture.key = key; return this; },
    setOrigin() { return this; }, setDepth() { return this; }, setDisplaySize() { return this; },
    setScale() { return this; }, setPosition() { return this; }, setRotation(r) { this.rotation = r; return this; },
    setAlpha() { return this; }, setVisible(visible) { this.visible = visible; return this; }, clearTint() { return this; } };
   objects.push(image); return image;
  } } };
  const view = new AuthoredHeroView(scene);
  const input = { entityId: 1, assetId: 'char_potato_hunter', x: 0, y: 0, worldX: 0, worldY: 0,
   visualSize: 84, pivot: { x: .5, y: .65 }, facingX: 1, alpha: 1, deltaMs: 16, attack: 0,
   dead: false, dashing: false, hit: false, heldPepper: skillId };
  const textures = () => objects.filter(o => o.visible).map(o => o.texture.key);
  const authored = Object.keys(HERO_RIG).map(id => `asset:hero_part_${id}`);
  const arm = id => objects.find(o => o.texture.key === `asset:hero_part_${id}`);
  view.draw(input);
  assert.deepEqual(textures(), authored);
  const idle = [arm('left_arm').rotation, arm('right_arm').rotation];
  view.draw({ ...input, x: -4, worldX: -4, facingX: -1, attackSequence: 1, weaponReleaseSequence: 1,
   weaponAim: { skillId, facing: -1, directionX: -1, directionY: 0, ageMs: 0 } });
  assert.deepEqual(textures(), authored);
  assert.notDeepEqual([arm('left_arm').rotation, arm('right_arm').rotation], idle);
 }
});
