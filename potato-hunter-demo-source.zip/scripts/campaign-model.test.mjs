import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const api=build({stdin:{contents:'export * from "./src/campaign/CampaignModel.ts"; export * from "./src/campaign/RunTelemetry.ts";',resolveDir:root,loader:'ts'},bundle:true,platform:'node',format:'esm',write:false}).then(r=>import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));
test('campaign retains opening and creates a real recovery interval',async()=>{
 const {getCampaignBeat}=await api;
 assert.equal(getCampaignBeat(0).phase,'warmup'); assert.equal(getCampaignBeat(59000).spawnMultiplier,1);
 assert.equal(getCampaignBeat(65000).phase,'pressure'); assert.equal(getCampaignBeat(75000).phase,'respite');
 assert.ok(getCampaignBeat(75000).spawnMultiplier<.5); assert.equal(getCampaignBeat(90000).phase,'build');
 assert.equal(getCampaignBeat(360000).phase,'finale'); assert.match(getCampaignBeat(360000).objective,/击败堡垒暴君/);
});
test('director emits authored bosses once and prioritizes final boss on a skipped-time frame',async()=>{
 const {CampaignDirector}=await api; const d=new CampaignDirector(42);
 assert.equal(d.nextBoss(59999),undefined); assert.equal(d.nextBoss(60000),'intermediate'); assert.equal(d.nextBoss(60001),undefined);
 assert.equal(d.nextBoss(180000),'intermediate'); assert.equal(d.nextBoss(300000),'intermediate');
 assert.equal(d.nextBoss(360000),'final'); assert.equal(d.nextBoss(900000),undefined);
 const skipped=new CampaignDirector(1); assert.equal(skipped.nextBoss(450000),'final'); assert.equal(skipped.nextBoss(450001),undefined);
});
test('only death of the tracked final boss while player lives wins; despawn is not death',async()=>{
 const {CampaignDirector}=await api; const d=new CampaignDirector(1); d.registerBoss(5,'intermediate');
 assert.equal(d.onMonsterDefeated(5,true),false); d.registerBoss(8,'final');
 assert.equal(d.onMonsterDefeated(9,true),false); assert.equal(d.onMonsterDefeated(8,false),false);
 assert.equal(d.outcome,undefined); assert.equal(d.onMonsterDefeated(8,true),true);
 assert.equal(d.finish('victory'),true); assert.equal(d.finish('defeat'),false); assert.equal(d.outcome,'victory');
});
test('rescue is earned by low living HP, cooled down and never revives',async()=>{
 const {CampaignDirector}=await api; const d=new CampaignDirector(1);
 assert.equal(d.shouldRescue(10000,.2),false); assert.equal(d.shouldRescue(30000,0),false);
 assert.equal(d.shouldRescue(30000,.6),false); assert.equal(d.shouldRescue(30000,.3),true);
 assert.equal(d.shouldRescue(30001,.2),false); assert.equal(d.shouldRescue(105000,.3),true);
});
test('seeded combat random source is reproducible, finite and isolated',async()=>{
 const {CampaignDirector}=await api; const a=new CampaignDirector(123),b=new CampaignDirector(123),c=new CampaignDirector(124);
 const x=Array.from({length:100},()=>a.random()); assert.deepEqual(x,Array.from({length:100},()=>b.random()));
 assert.notDeepEqual(x,Array.from({length:100},()=>c.random())); assert.ok(x.every(n=>n>=0&&n<1));
});
test('telemetry separates healing/damage sources and owns bounded immutable phase snapshots',async()=>{
 const {RunTelemetry}=await api; const t=new RunTelemetry(42);
 t.recordHealthChange(100,80,'projectile');t.recordHealthChange(80,94,'upgrade');t.recordHealthChange(94,84,'contact');
 t.snapshot({elapsedMs:0,level:1,hp:100,maxHp:100,entities:1});
 t.snapshot({elapsedMs:5000,level:2,hp:94,maxHp:105,entities:12});
 t.snapshot({elapsedMs:10000,level:2,hp:84,maxHp:105,entities:20});
 const report=t.getReport(); assert.deepEqual(report.damageBySource,{projectile:20,contact:10}); assert.equal(report.healing,14);
 assert.equal(report.snapshots.length,2); report.snapshots[0].hp=0; assert.equal(t.getReport().snapshots[0].hp,100);
 for(let i=2;i<400;i++)t.snapshot({elapsedMs:i*10000,level:20,hp:50,maxHp:195,entities:100});
 assert.ok(t.getReport().snapshots.length<=256);
});
