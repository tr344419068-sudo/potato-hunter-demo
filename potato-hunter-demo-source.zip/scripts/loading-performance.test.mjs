import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { parseHTML } from 'linkedom';
import EventEmitter from 'eventemitter3';

const api = build({ stdin: { contents: `
export { CampaignShell } from './src/ui/CampaignShell.ts';
export { ProgressionStore } from './src/progression/ProgressionStore.ts';
export { AssetManager } from './src/managers/AssetManager.ts';
export { ConfigManager } from './src/managers/ConfigManager.ts';
`, resolveDir: process.cwd(), loader: 'ts' }, bundle: true, platform: 'node', format: 'esm', write: false,
plugins: [{ name: 'headless-phaser', setup(context) {
  context.onResolve({ filter: /^phaser$/ }, () => ({ path: 'phaser', namespace: 'mock' }));
  context.onLoad({ filter: /.*/, namespace: 'mock' }, () => ({ contents: 'export default {Loader:{Events:{COMPLETE:"complete",PROGRESS:"progress"}}};' }));
} }] }).then(result => import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString('base64')}`));

test('home is immediately usable while battle loads, then enables start without closing the bestiary', async () => {
  const { CampaignShell, ProgressionStore } = await api;
  const { document } = parseHTML('<html><body></body></html>');
  const events = new EventEmitter();
  const shell = new CampaignShell(events, new ProgressionStore({ getItem: () => null, setItem() {} }), { document });
  assert.ok(document.querySelector('.campaign-home'));
  assert.equal(document.querySelector('[data-action="start"]').disabled, true);
  events.emit('campaign:loading', { progress: .42, failed: 0 });
  assert.match(document.querySelector('.campaign-load-status').textContent, /42%/);
  document.querySelector('[data-action="bestiary"]').click();
  events.emit('campaign:ready', { atHome: true });
  assert.ok(document.querySelector('.campaign-bestiary'));
  document.querySelector('[data-action="close-bestiary"]').click();
  assert.equal(document.querySelector('[data-action="start"]').disabled, false);
  shell.destroy();
});

test('asset loader queues images directly without an unbounded image preflight', async () => {
  const { AssetManager, ConfigManager } = await api;
  const loader = new EventEmitter();
  const queued = [];
  loader.image = (...args) => queued.push(args);
  loader.spritesheet = (...args) => queued.push(args);
  loader.start = () => {};
  const scene = { load: loader, textures: { exists: () => false } };
  await AssetManager.loadAvailable(scene, () => {});
  assert.equal(queued.length, Object.keys(ConfigManager.assets).length - 5);
  assert.ok(queued.every(([, path]) => !/food_wasteland|campaign-v3|glow_gold_center/.test(path)));
});

test('game engine load failure tells the player to refresh and keeps start disabled', async () => {
  const { CampaignShell, ProgressionStore } = await api;
  const { document } = parseHTML('<html><body></body></html>');
  const events = new EventEmitter();
  const shell = new CampaignShell(events, new ProgressionStore({ getItem: () => null, setItem() {} }), { document });
  events.emit('campaign:load-failed');
  assert.match(document.querySelector('.campaign-load-status').textContent, /失败.*刷新/);
  assert.equal(document.querySelector('[data-action="start"]').disabled, true);
  shell.destroy();
});

test('initial shell bundle does not require the Phaser engine before showing the home screen', async () => {
  const result = await build({ entryPoints: ['src/main.ts'], bundle: true, splitting: true, platform: 'browser', format: 'esm', outdir: '/tmp/potato-test-bundle', write: false, metafile: true });
  const entry = Object.values(result.metafile.outputs).find(output => output.entryPoint === 'src/main.ts');
  assert.ok(entry);
  assert.ok(!Object.keys(entry.inputs).some(path => /node_modules\/phaser\//.test(path)), 'Phaser belongs in the deferred game bundle');
  assert.ok(entry.imports.some(item => item.kind === 'dynamic-import'), 'game bundle should be loaded in the background');
});
