import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { statSync } from 'node:fs';
import { parseHTML } from 'linkedom';
import EventEmitter from 'eventemitter3';

const api = build({ stdin: { contents: `
export { CampaignShell } from './src/ui/CampaignShell.ts';
export { ProgressionStore } from './src/progression/ProgressionStore.ts';
export { AssetManager } from './src/managers/AssetManager.ts';
export { ConfigManager } from './src/managers/ConfigManager.ts';
`, resolveDir: process.cwd(), loader: 'ts' }, bundle: true, platform: 'node', format: 'esm', write: false,
plugins: [{ name: 'headless-phaser', setup(context) {
  context.onResolve({ filter: /^phaser$/ }, () => ({ path: 'phaser', namespace: 'mock' }));
  context.onLoad({ filter: /.*/, namespace: 'mock' }, () => ({ contents: 'export default {Loader:{Events:{COMPLETE:"complete",PROGRESS:"progress"}}};' }));
} }] }).then(result => import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString('base64')}`));

test('home is immediately usable while battle loads, then enables start without closing the bestiary', async () => {
  const { CampaignShell, ProgressionStore } = await api;
  const { document } = parseHTML('<html><body></body></html>');
  const events = new EventEmitter();
  const shell = new CampaignShell(events, new ProgressionStore({ getItem: () => null, setItem() {} }), { document });
  assert.ok(document.querySelector('.campaign-home'));
  assert.equal(document.querySelector('[data-action="start"]').disabled, true);
  events.emit('campaign:loading', { progress: .42, failed: 0 });
  assert.match(document.querySelector('.campaign-load-status').textContent, /42%/);
  document.querySelector('[data-action="bestiary"]').click();
  events.emit('campaign:ready', { atHome: true });
  assert.ok(document.querySelector('.campaign-bestiary'));
  document.querySelector('[data-action="close-bestiary"]').click();
  assert.equal(document.querySelector('[data-action="start"]').disabled, false);
  shell.destroy();
});

test('asset loader queues images directly without an unbounded image preflight', async () => {
  const { AssetManager, ConfigManager } = await api;
  const loader = new EventEmitter();
  const queued = [];
  loader.image = (...args) => queued.push(args);
  loader.spritesheet = (...args) => queued.push(args);
  loader.start = () => {};
  const scene = { load: loader, textures: { exists: () => false } };
  await AssetManager.loadAvailable(scene, () => {});
  const late = Object.values(ConfigManager.assets).filter(asset => /food_wasteland|campaign-v3|glow_gold_center|assets\/bestiary\//.test(asset.path));
  assert.equal(queued.length, Object.keys(ConfigManager.assets).length - late.length);
  assert.ok(queued.every(([, path]) => !late.some(asset => asset.path === path)));
  for (const id of ['icon_skill_hot_oil', 'projectile_long_skewer']) {
    assert.ok(queued.some(([key]) => key === `asset:${id}`), 'a combat skill must never wait for the bestiary');
  }
});

test('every small enemy queues a battle texture without pulling in large bestiary portraits', async () => {
  const { AssetManager, ConfigManager } = await api;
  const loader = new EventEmitter();
  const queued = new Map();
  loader.image = (key, path) => queued.set(key, path);
  loader.spritesheet = loader.image;
  loader.start = () => {};
  await AssetManager.loadAvailable({ load: loader, textures: { exists: () => false } }, () => {});
  for (const monster of ConfigManager.monsters) {
    const path = queued.get(AssetManager.getTextureKey(monster.assetId));
    assert.ok(path?.startsWith('assets/enemies/'), `${monster.id} must not render as a color block`);
  }
  const battleExports = [...queued.values()].filter(path => path.startsWith('assets/enemies/meadow-v1/'));
  const bytes = battleExports.reduce((size, path) => size + statSync(new URL(`../public/${path}`, import.meta.url)).size, 0);
  assert.ok(bytes <= 128 * 1024, `mobile battle exports total ${bytes} bytes`);
});

test('game engine load failure tells the player to refresh and keeps start disabled', async () => {
  const { CampaignShell, ProgressionStore } = await api;
  const { document } = parseHTML('<html><body></body></html>');
  const events = new EventEmitter();
  const shell = new CampaignShell(events, new ProgressionStore({ getItem: () => null, setItem() {} }), { document });
  events.emit('campaign:load-failed');
  assert.match(document.querySelector('.campaign-load-status').textContent, /失败.*刷新/);
  assert.equal(document.querySelector('[data-action="start"]').disabled, true);
  shell.destroy();
});

test('initial shell bundle does not require the Phaser engine before showing the home screen', async () => {
  const result = await build({ entryPoints: ['src/main.ts'], bundle: true, splitting: true, platform: 'browser', format: 'esm', outdir: '/tmp/potato-test-bundle', write: false, metafile: true });
  const entry = Object.values(result.metafile.outputs).find(output => output.entryPoint === 'src/main.ts');
  assert.ok(entry);
  assert.ok(!Object.keys(entry.inputs).some(path => /node_modules\/phaser\//.test(path)), 'Phaser belongs in the deferred game bundle');
  assert.ok(entry.imports.some(item => item.kind === 'dynamic-import'), 'game bundle should be loaded in the background');
});
