import assert from "node:assert/strict";
import test from "node:test";

import {
  formatElapsedTime,
  getProgressRatio,
  getVisibleSkills,
  getWaveCounterLabel,
  shouldShowUpgradeSticker,
} from "../src/ui/UIModel.ts";

test("formatElapsedTime returns a stable two-digit clock", () => {
  assert.equal(formatElapsedTime(0), "00:00");
  assert.equal(formatElapsedTime(65_999), "01:05");
  assert.equal(formatElapsedTime(-500), "00:00");
});

test("getProgressRatio clamps invalid and overflowing values", () => {
  assert.equal(getProgressRatio(25, 100), 0.25);
  assert.equal(getProgressRatio(120, 100), 1);
  assert.equal(getProgressRatio(-3, 100), 0);
  assert.equal(getProgressRatio(10, 0), 0);
});

test("getVisibleSkills respects the tray capacity without mutating input", () => {
  const skills = Array.from({ length: 7 }, (_, index) => ({ id: `skill-${index}`, name: `Skill ${index}`, level: index + 1 }));
  const visible = getVisibleSkills(skills, 5);

  assert.deepEqual(visible.map((skill) => skill.id), ["skill-0", "skill-1", "skill-2", "skill-3", "skill-4"]);
  assert.equal(skills.length, 7);
});

test("wave labels use short localized names and never expose internal ids", () => {
  assert.equal(getWaveCounterLabel("fries_cultist", "薯条小兵"), "薯条小兵");
  assert.equal(getWaveCounterLabel("fries_cultist"), "怪潮");
  assert.equal(getWaveCounterLabel("", "巨型炸薯机器"), "巨型炸薯");
});

test("upgrade corner sticker is hidden at narrow widths", () => {
  assert.equal(shouldShowUpgradeSticker(390), false);
  assert.equal(shouldShowUpgradeSticker(780), true);
});
