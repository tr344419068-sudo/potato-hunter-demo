#!/usr/bin/env python3
"""Bake seven shoulder-keyed poses from our existing Desert Sultan character art."""
from pathlib import Path
from PIL import Image, ImageChops, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'public/assets'
SOURCE = ASSETS / 'bosses/desert_sultan/idle-v1.png'
DEST = ASSETS / 'bosses/desert_sultan/cleave-v2.webp'
PIVOT = (264, 248)
ARM = [(35, 86), (210, 83), (216, 163), (272, 168), (287, 211), (286, 262),
       (256, 311), (224, 343), (177, 365), (129, 362), (46, 342), (34, 235)]
# Rotate the cut-out as one weighted shoulder pose; avoid resampling face and legs.
POSES = [(0, 0, 0), (-14, 1, -3), (-25, 5, -9), (37, -25, 19),
         (51, -15, 16), (24, -8, 7), (8, -2, 2)]


def mask(size, points, radius):
    result = Image.new('L', size)
    ImageDraw.Draw(result).polygon(points, fill=255)
    return result.filter(ImageFilter.GaussianBlur(radius))


def export():
    source = Image.open(SOURCE).convert('RGBA')
    m = mask(source.size, ARM, 4)
    arm = source.copy()
    arm.putalpha(ImageChops.multiply(source.getchannel('A'), m))
    body = source.copy()
    body.putalpha(ImageChops.multiply(source.getchannel('A'), ImageChops.invert(m)))
    # Fill the small exposed shoulder seam with fabric sampled from the same cloak.
    sleeve = Image.new('RGBA', source.size)
    sleeve.paste(source.crop((100, 377, 212, 536)).resize((145, 166), Image.Resampling.LANCZOS), (142, 184))
    sleeve_mask = mask(source.size, [(229, 171), (278, 183), (290, 224), (282, 285),
                                     (253, 325), (161, 360), (154, 343), (164, 285), (188, 220)], 7)
    sleeve.putalpha(ImageChops.multiply(sleeve.getchannel('A'), sleeve_mask))
    body = Image.alpha_composite(sleeve, body)

    sheet = Image.new('RGBA', (1024, 512))
    for i, (angle, dx, dy) in enumerate(POSES):
        if not i:
            pose = source
        else:
            swung = arm.rotate(angle, resample=Image.Resampling.BICUBIC, center=PIVOT)
            pose = body.copy()
            pose.alpha_composite(swung, (dx, dy))
        sheet.paste(pose.resize((256, 256), Image.Resampling.LANCZOS), (i % 4 * 256, i // 4 * 256))
    sheet.save(DEST, quality=85, alpha_quality=94, method=6)
    print(DEST.relative_to(ROOT), DEST.stat().st_size, 'bytes')


if __name__ == '__main__':
    export()
