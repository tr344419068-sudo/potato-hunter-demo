import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const api = build({ entryPoints: [fileURLToPath(new URL('../src/progression/ProgressionStore.ts', import.meta.url))], bundle: true, platform: 'node', format: 'esm', write: false })
  .then(result => import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString('base64')}`));
const key = 'potato-hunter.profile.v1';
function storage(initial) {
  const values = new Map(initial ? [[key, JSON.stringify(initial)]] : []);
  return { values, getItem: k => values.get(k) ?? null, setItem: (k, v) => values.set(k, v) };
}
const legacy = { version: 1, gold: 100, unlockedLoadouts: ['peeler', 'pepper'], selectedLoadout: 'pepper', preferences: { musicVolume: .2, sfxVolume: .6, reducedEffects: false }, totalRuns: 3, victories: 1, bestSeconds: 400, rewardedRunIds: ['old-run'] };
const win = { outcome: 'victory', elapsedMs: 360000, kills: 200, bossKills: 1, gold: 10 };

test('legacy saves retain currency and loadouts and existing wins unlock the next stage', async () => {
  const { ProgressionStore } = await api;
  const store = new ProgressionStore(storage(legacy));
  assert.equal(store.getProfile().gold, 100);
  assert.equal(store.getProfile().selectedLoadout, 'pepper');
  assert.deepEqual(store.getCampaignProgress(), { selectedStage: 'desert', clearedStages: ['meadow'], training: { attack: 0, health: 0, pickup: 0 } });
  assert.equal(store.selectStage('desert').ok, true);
});

test('first clear selects the newly unlocked desert and survives reload', async () => {
  const { ProgressionStore } = await api; const saved = storage(); const store = new ProgressionStore(saved);
  assert.equal(store.getCampaignProgress().selectedStage, 'meadow');
  store.settleRun('new-first', win, 'meadow');
  assert.equal(store.getCampaignProgress().selectedStage, 'desert');
  assert.equal(new ProgressionStore(saved).getCampaignProgress().selectedStage, 'desert');
});

test('old cleared saves recommend desert once, while subsequent explicit meadow choice is preserved', async () => {
  const { ProgressionStore } = await api;
  const saved = storage({ ...legacy, campaign: { selectedStage: 'meadow', clearedStages: ['meadow'], training: {} } });
  const store = new ProgressionStore(saved);
  assert.equal(store.getCampaignProgress().selectedStage, 'desert');
  assert.equal(store.selectStage('meadow').ok, true);
  assert.equal(new ProgressionStore(saved).getCampaignProgress().selectedStage, 'meadow');
  store.settleRun('replay', win, 'meadow');
  assert.equal(new ProgressionStore(saved).getCampaignProgress().selectedStage, 'meadow');
});

test('old saves with both stages cleared keep their existing choice', async () => {
  const { ProgressionStore } = await api;
  const saved = storage({ ...legacy, campaign: { selectedStage: 'meadow', clearedStages: ['meadow', 'desert'], training: {} } });
  assert.equal(new ProgressionStore(saved).getCampaignProgress().selectedStage, 'meadow');
});

test('training purchase is persisted together with currency, bounded, and rejects invalid purchases', async () => {
  const { ProgressionStore } = await api;
  const saved = storage({ ...legacy, gold: 20, victories: 0 });
  const store = new ProgressionStore(saved);
  assert.equal(store.upgradeTraining('attack').ok, true);
  assert.equal(store.getProfile().gold, 0);
  assert.equal(store.upgradeTraining('health').ok, false);
  assert.equal(store.upgradeTraining('unknown').ok, false);
  const restored = new ProgressionStore(saved);
  assert.equal(restored.getCampaignProgress().training.attack, 1);
  assert.equal(restored.getProfile().gold, 0);
});

test('stage selection is locked until a legitimate first clear, rewarded only once and preserved on reload', async () => {
  const { ProgressionStore } = await api;
  const saved = storage();
  const store = new ProgressionStore(saved);
  assert.equal(store.selectStage('desert').ok, false);
  assert.equal(store.selectStage('unknown').ok, false);
  const first = store.settleRun('first', win, 'meadow');
  assert.equal(first.firstClearBonus, 40);
  assert.equal(first.unlockedStage, 'desert');
  assert.equal(store.selectStage('desert').ok, true);
  assert.equal(store.settleRun('first', win, 'meadow').duplicate, true);
  assert.equal(store.settleRun('again', win, 'meadow').firstClearBonus, 0);
  const restored = new ProgressionStore(saved);
  assert.equal(restored.getCampaignProgress().selectedStage, 'desert');
  assert.deepEqual(restored.getCampaignProgress().clearedStages, ['meadow']);
});

test('defeat, fake victories and locked or unknown stages cannot grant progression', async () => {
  const { ProgressionStore } = await api;
  const store = new ProgressionStore(storage());
  store.settleRun('loss', { ...win, outcome: 'defeat' }, 'meadow');
  store.settleRun('no-boss', { ...win, bossKills: 0 }, 'meadow');
  store.settleRun('locked', win, 'desert');
  store.settleRun('unknown', win, 'unknown');
  assert.deepEqual(store.getCampaignProgress().clearedStages, []);
  assert.equal(store.selectStage('desert').ok, false);
});

test('corrupted stage order cannot unlock desert without a meadow clear', async () => {
  const { ProgressionStore } = await api;
  const saved = storage({ ...legacy, victories: 0, campaign: { selectedStage: 'desert', clearedStages: ['desert'], training: {} } });
  const store = new ProgressionStore(saved);
  assert.deepEqual(store.getCampaignProgress().clearedStages, []);
  assert.equal(store.getCampaignProgress().selectedStage, 'meadow');
});
