import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const source = (path) => readFileSync(resolve(root, path), "utf8");

test("GitHub Pages builds under the potato-hunter-demo base path", () => {
  const vite = source("vite.config.ts");
  assert.match(vite, /base:\s*isGitHubPagesBuild\s*\?\s*["']\/potato-hunter-demo\/["']\s*:\s*["']\/["']/);
});

test("runtime UI, audio, and stylesheet assets never bypass Vite's deployment base", () => {
  const publishableSources = [
    "src/audio/CombatAudioModel.ts",
    "src/ui/BestiaryModel.ts",
    "src/ui/CampaignShell.ts",
    "src/styles.css",
  ].map(source).join("\n");

  assert.doesNotMatch(publishableSources, /["'`]\/assets\//);
  assert.match(source("src/ui/CampaignShell.ts"), /assetUrl/);
  assert.match(source("src/audio/CombatAudioModel.ts"), /assetUrl/);
  assert.match(source("src/ui/BestiaryModel.ts"), /assetUrl/);
  assert.match(source("src/utils/assetUrl.ts"), /import\.meta\.env\?\.BASE_URL/);
  assert.match(source("src/main.ts"), /--campaign-grass-texture/);
});
