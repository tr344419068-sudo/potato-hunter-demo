import assert from "node:assert/strict";
import test from "node:test";
import { uiModules, displayScene } from "./ui-runtime-helpers.mjs";

async function fixture() {
  const api = await uiModules; api.EventBus.removeAllListeners();
  const display = displayScene(); const scene = new api.UIScene(); Object.assign(scene, display.scene); scene.create();
  return { ...api, ...display, scene };
}

test("actual notification routing ignores chapters and cast labels while preserving phase changes", async () => {
  const { scene, EventBus } = await fixture();
  EventBus.emit("level:chapter", { act: "一", title: "章", subtitle: "不要打断", primaryColor: 1 });
  for (const text of ["油弹扇射 · 留意空隙", "环形热浪", "冲锋", "炸锅增援"]) EventBus.emit("boss:phase", { text });
  assert.equal(scene.notification, undefined);
  EventBus.emit("boss:phase", { text: "炸锅二阶段 · 冲锋与增援" });
  assert.equal(scene.notification.message, "炸锅二阶段 · 冲锋与增援");
  assert.ok(scene.notification.text.fontSize >= 16 && scene.notification.text.fontSize <= 20);
  assert.equal(scene.cameras.main.shakes, 0);
  scene.events.emit("shutdown");
});

test("ordinary key notices are eight seconds apart and boss arrival bypasses that gate once", async () => {
  const { scene, EventBus, objects } = await fixture();
  const count = () => objects.filter(object => object.kind === "container" && object.calls.some(call => call[0] === "setDepth" && call[1] === 700)).length;
  EventBus.emit("boss:phase", { text: "炸锅二阶段 · 冲锋与增援" }); assert.equal(count(), 1);
  scene.time.now = 1000; EventBus.emit("boss:phase", { text: "炸锅三阶段 · 环形热浪" }); assert.equal(count(), 1);
  EventBus.emit("boss:spawned"); assert.equal(count(), 2); assert.equal(scene.notification.message, "巨型炸薯机来袭！");
  EventBus.emit("boss:spawned"); assert.equal(count(), 2, "duplicate high priority notice interrupts again");
  scene.time.now = 7999; EventBus.emit("boss:defeated"); assert.equal(count(), 2);
  scene.time.now = 8000; EventBus.emit("boss:defeated"); assert.equal(count(), 3);
  assert.equal(scene.notification.message, "首领击破！");
  assert.equal(scene.cameras.main.shakes, 0);
  scene.events.emit("shutdown");
});

test("desert final boss arrival names the actual boss", async () => {
  const { scene, EventBus } = await fixture();
  EventBus.emit("boss:spawned", { final: true, stage: "desert" });
  assert.equal(scene.notification.message, "沙海堡垒之王来袭！");
  scene.events.emit("shutdown");
});

test("final duel countdown reuses one non-interactive caption and replaces the arrival banner", async () => {
  const { scene, EventBus, objects } = await fixture();
  EventBus.emit("boss:intro", { text: "3", progress: .1 });
  const caption = objects.find(o => o.kind === "text" && o.text === "3");
  assert.ok(caption);
  EventBus.emit("boss:intro", { text: "对决开始", progress: .3 });
  assert.equal(caption.text, "对决开始");
  assert.ok(caption.calls.some(([name]) => name === "setScale"));
  assert.ok(!caption.calls.some(([name]) => name === "setInteractive"));
  EventBus.emit("boss:intro", undefined);
  EventBus.emit("boss:spawned", { final: true, stage: "desert", afterIntro: true });
  assert.equal(caption.destroyed, true);
  assert.equal(scene.notification, undefined);
  assert.equal(scene.cameras.main.shakes, 0);
  assert.equal(scene.cameras.main.flashes, 0);
  EventBus.emit("boss:intro", { text: "3", progress: .1 });
  const next = objects.find(o => !o.destroyed && o.kind === "text" && o.text === "3");
  EventBus.emit("ui:clear");
  assert.equal(next.destroyed, true);
  scene.events.emit("shutdown");
  assert.equal(EventBus.listenerCount("boss:intro"), 0);
});

test("clear resets run-local notices and shutdown detaches all routing", async () => {
  const { scene, EventBus } = await fixture();
  EventBus.emit("boss:spawned"); const previous = scene.notification.container;
  EventBus.emit("ui:clear"); assert.equal(scene.notification, undefined); assert.equal(previous.destroyed, true);
  EventBus.emit("boss:spawned"); assert.ok(scene.notification);
  scene.events.emit("shutdown"); assert.equal(scene.notification, undefined);
  EventBus.emit("boss:spawned"); assert.equal(scene.notification, undefined);
  assert.equal(EventBus.listenerCount("boss:phase"), 0);
});

test("composed UI and combat feedback produce no parallel cast text or duplicate phase banner", async () => {
  const { scene, EventBus, FeedbackSystem, objects } = await fixture();
  const feedbackDisplay = displayScene(); const feedback = new FeedbackSystem(feedbackDisplay.scene);
  const cast = "油弹扇射 · 留意空隙"; const phase = "炸锅二阶段 · 冲锋与增援";
  EventBus.emit("boss:phase", { text: cast });
  assert.equal([...objects, ...feedbackDisplay.objects].filter(object => object.kind === "text" && object.text === cast).length, 0);
  EventBus.emit("boss:phase", { text: phase }); EventBus.emit("boss:phase", { text: phase });
  const banners = [...objects, ...feedbackDisplay.objects].filter(object => object.kind === "text" && object.text === phase);
  assert.equal(banners.length, 1, "combat feedback bypassed the UI notice gate");
  assert.ok(banners[0].fontSize <= 20);
  feedback.destroy(); scene.events.emit("shutdown");
});

test("composed evolution notification stays small below HUD without camera flashes or shakes", async () => {
  const { scene, EventBus, FeedbackSystem, objects } = await fixture();
  const feedbackDisplay = displayScene(); const feedback = new FeedbackSystem(feedbackDisplay.scene);
  EventBus.emit("evolution:unlocked", { name: "烈焰薯弹", color: "#ff6b35" });
  const banners = [...objects, ...feedbackDisplay.objects].filter(object => object.kind === "text" && object.text.includes("烈焰薯弹"));
  assert.equal(banners.length, 1); assert.ok(banners[0].fontSize <= 20);
  assert.equal(feedbackDisplay.scene.cameras.main.shakes, 0); assert.equal(feedbackDisplay.scene.cameras.main.flashes, 0);
  assert.equal(scene.cameras.main.shakes, 0); assert.equal(scene.cameras.main.flashes, 0);
  assert.ok(banners[0].y > scene.currentLayout.boss.y + scene.currentLayout.boss.height / 2);
  feedback.destroy(); scene.events.emit("shutdown");
});
