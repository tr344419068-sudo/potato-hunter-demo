import { createCanvas, loadImage } from "@napi-rs/canvas";
import { createHash } from "node:crypto";
import { writeFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const cutout = await loadImage(new URL("artifacts/hot-oil-shengong-v2/rembg.png", root));
const frame = await loadImage(new URL("public/assets/icons/skills/butter_lube.png", root));
const { width, height } = cutout;
const input = createCanvas(width, height).getContext("2d");
input.drawImage(cutout, 0, 0);
const { data } = input.getImageData(0, 0, width, height);
let left = width, top = height, right = -1, bottom = -1;
for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
  if (data[(y * width + x) * 4 + 3] < 16) continue;
  left = Math.min(left, x); right = Math.max(right, x);
  top = Math.min(top, y); bottom = Math.max(bottom, y);
}
if (left <= 0 || top <= 0 || right >= width - 1 || bottom >= height - 1 || right <= left || bottom <= top) {
  throw new Error("Expected a complete, isolated RemBg cutout");
}
const w = right - left + 1, h = bottom - top + 1;
function drawFlask(context, cx, cy, size) {
  const scale = size / Math.max(w, h);
  context.imageSmoothingQuality = "high";
  context.drawImage(cutout, left, top, w, h, cx - w * scale / 2, cy - h * scale / 2, w * scale, h * scale);
}

const projectile = createCanvas(128, 128);
drawFlask(projectile.getContext("2d"), 64, 64, 112);

const badge = createCanvas(256, 256);
const icon = badge.getContext("2d");
icon.drawImage(frame, 0, 0, 256, 256);
// Keep the original gold rim; remove only the butter art inside its inner edge.
icon.globalCompositeOperation = "destination-out";
icon.beginPath(); icon.arc(128, 128, 96, 0, Math.PI * 2); icon.fill();
icon.globalCompositeOperation = "destination-over";
const navy = icon.createRadialGradient(111, 88, 8, 128, 135, 102);
navy.addColorStop(0, "#1443ae"); navy.addColorStop(.63, "#092465"); navy.addColorStop(1, "#030f35");
icon.fillStyle = navy;
icon.beginPath(); icon.arc(128, 128, 97, 0, Math.PI * 2); icon.fill();
icon.globalCompositeOperation = "source-over";
drawFlask(icon, 127, 128, 156);

for (const [name, canvas] of [["hot-oil-flask-sg-v2.png", projectile], ["hot-oil-badge-sg-v2.png", badge]]) {
  const png = await canvas.encode("png");
  await writeFile(new URL(`public/assets/vfx/ranged-v1/${name}`, root), png);
  console.log(`${name} ${canvas.width}×${canvas.height} ${png.length} bytes ${createHash("sha256").update(png).digest("hex")}`);
}
