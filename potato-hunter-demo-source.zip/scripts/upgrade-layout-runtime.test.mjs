import assert from "node:assert/strict";
import test from "node:test";
import { uiModules, displayScene, overlaps } from "./ui-runtime-helpers.mjs";
import { build } from "esbuild";
const benefits = build({entryPoints:['src/ui/UIModel.ts'],bundle:true,platform:'node',format:'esm',write:false}).then(r=>import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));

const luminance = color => {
  const channels = [1, 3, 5].map(offset => parseInt(color.slice(offset, offset + 2), 16) / 255).map(channel => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4);
  return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
};
const ivoryContrast = color => (luminance("#f7f1e3") + 0.05) / (luminance(color) + 0.05);

test('375px cards fit actual damage, recipe, and replacement without clipping', async () => {
  const { UpgradePopup, ConfigManager } = await uiModules;
  const choices = ['hot_oil_flask', 'ketchup_surge', 'ketchup_aura'].map(id => ConfigManager.getSkill(id));
  const hints = [
    { skillId: 'hot_oil_flask', upgradeBenefit: '每跳伤害 11 → 13', recipeProgress: '配方 滚油火海 · 缺 盐粒扩散 0/1' },
    { skillId: 'ketchup_surge', replacesSkill: '番茄酱力场' },
    { skillId: 'ketchup_aura', upgradeBenefit: '半径 190 → 217 · 每秒伤害 21 → 26', recipeProgress: '配方 番茄酱潮汐 · 缺 盐粒扩散 0/1' },
  ];
  const popup = new UpgradePopup(displayScene(375, 812).scene, { choices, hints, levels: { hot_oil_flask: 2, ketchup_aura: 1 } });
  const texts = card => card.container.children.filter(child => child.kind === 'text');
  assert.match(texts(popup.cards[0])[2].text, /每跳伤害 11 → 13/);
  assert.match(texts(popup.cards[0])[2].text.replace(/\s/g,''), /滚油火海·缺盐粒扩散0\/1/);
  assert.equal(texts(popup.cards[1])[1].text, '进化 · Lv 1');
  assert.match(texts(popup.cards[1])[2].text, /替换 番茄酱力场/);
  assert.match(texts(popup.cards[2])[2].text, /半径 190 → 217/);
  assert.match(texts(popup.cards[2])[2].text.replace(/\s/g,''), /番茄酱潮汐·缺盐粒扩散0\/1/);
  popup.destroy();
});

test("chooser offers immediate stable hit targets and visible cancel instruction", async () => {
  const { UpgradePopup, ConfigManager, EventBus } = await uiModules;
  EventBus.removeAllListeners();
  const { scene, objects, timers } = displayScene();
  const popup = new UpgradePopup(scene, { choices: ConfigManager.skills.slice(0, 3), hints: [], levels: {}, sessionId: 41 });
  assert.ok(objects.some(object => object.text.includes("选择时暂停 · 可稍后升级")));
  for (const card of popup.cards) { assert.equal(card.container.alpha, 1); assert.equal(card.container.scaleX, 1); assert.equal(card.container.y, card.hitZone.y); }
  const selected = []; EventBus.on("skill:selected", payload => selected.push(payload));
  popup.cards[0].hitZone.emit("pointerdown"); popup.cards[0].hitZone.emit("pointerup");
  assert.deepEqual(selected, [{ skillId: ConfigManager.skills[0].id, sessionId: 41 }]);
  assert.equal(timers.length, 0, "click waits on presentation timer");
});

test("long names, levels, benefits and icons remain inside bitmap rails across compact and desktop boundaries", async () => {
  const { UpgradePopup, ConfigManager, getUILayout, UPGRADE_REWARD_CHOICES } = await uiModules;
  const choices = [ConfigManager.getSkill("peeler_blade"), { ...ConfigManager.skills.find(skill => skill.id !== "peeler_blade"), name: "超级超长名字的薯条战斗技能" }, UPGRADE_REWARD_CHOICES[0]];
  for (const [width, height] of [[320, 480], [390, 844], [722, 794], [800, 600], [900, 650], [1280, 720]]) {
    const { scene } = displayScene(width, height);
    const popup = new UpgradePopup(scene, { choices, hints: [], levels: { peeler_blade: 1 }, sessionId: 4 });
    popup.layout(getUILayout(width, height));
    assert.equal(popup.cards.length, 3);
    for (const card of popup.cards) {
      assert.ok(card.container.x - card.width / 2 >= 8); assert.ok(card.container.x + card.width / 2 <= width - 8);
      assert.ok(card.container.y - card.height / 2 >= 70); assert.ok(card.container.y + card.height / 2 <= height - 12);
      const texts = card.container.children.filter(child => child.kind === "text");
      assert.equal(texts.length, 4);
      const compact = card.container.children.some(child => child.kind === "nineslice");
      const frameScale = compact ? Math.min(0.5, card.height / (card.height < 160 ? 600 : 420)) : card.width / 320;
      const safeX = frameScale * (compact ? 90 : 60) + 3;
      const safeTop = frameScale * (compact ? 60 : 74) + 3;
      const safeBottom = frameScale * (compact ? 60 : 81) + 3;
      for (const text of [...texts, card.icon]) { const bounds = text.getBounds(); assert.ok(bounds.x >= -card.width / 2 + safeX, `${width}: ${text.text} crosses left frame rail`); assert.ok(bounds.x + bounds.width <= card.width / 2 - safeX, `${width}: ${text.text} crosses right frame rail`); assert.ok(bounds.y >= -card.height / 2 + safeTop, `${width}: ${text.text} touches the upper frame/gem`); assert.ok(bounds.y + bounds.height <= card.height / 2 - safeBottom, `${width}: ${text.text} crosses the lower frame rail`); }
      for (let first = 0; first < texts.length; first++) for (let second = first + 1; second < texts.length; second++) assert.equal(overlaps(texts[first].getBounds(), texts[second].getBounds()), false, `${width}: ${texts[first].text} overlaps ${texts[second].text}`);
      assert.ok(card.icon.width >= (compact ? 60 : card.width * 0.39));
      assert.ok(texts[0].fontSize >= 12); assert.ok(texts[1].fontSize >= 12); assert.ok(texts[2].fontSize >= 12); assert.ok(texts[3].fontSize >= 10);
      assert.ok(texts.every(text => !text.style.fontFamily.includes("ZCOOL")));
      assert.ok(texts.every(text => !["700", "bold"].includes(text.style.fontStyle)));
      assert.ok(texts.slice(0, 3).every(text => ivoryContrast(text.style.color) >= 4.5), "primary information must use dark high-contrast ink");
    }
    assert.ok(popup.cards[0].container.children.some(child => child.text === "Lv 1 → 2"));
    assert.ok(popup.cards[1].container.children.some(child => child.text === "新技能 · Lv 0 → 1"));
    assert.ok(popup.cards[2].container.children.some(child => child.text === "补给"));
    popup.destroy();
  }
});

test("desktop uses spacious portrait cards and readable benefits without one-character orphans", async () => {
  const { UpgradePopup, ConfigManager } = await uiModules;
  const choices = ["peeler_blade", "fire_potato", "pepper_motor"].map(id => ConfigManager.getSkill(id));
  const popup = new UpgradePopup(displayScene().scene, { choices, hints: [], levels: {} });
  for (const card of popup.cards) {
    assert.ok(card.width >= 312, "desktop cards leave usable viewport space unused");
    const texts = card.container.children.filter(child => child.kind === "text");
    assert.ok(texts[2].fontSize >= 14);
    const lines = texts[2].text.split("\n");
    assert.ok(lines.length === 1 || Array.from(lines.at(-1)).length > 2, "benefit has a stranded final character");
    for (let index = 1; index < texts.length; index++) assert.ok(texts[index].getBounds().y - (texts[index - 1].getBounds().y + texts[index - 1].height) >= 3, "desktop rows need positive breathing room");
  }
});

test("wide compact cards increase type size and very short desktops retain bounded cards", async () => {
  const { UpgradePopup, ConfigManager } = await uiModules;
  const choices = ConfigManager.skills.slice(0, 3);
  const popup = new UpgradePopup(displayScene(722, 794).scene, { choices, hints: [], levels: {} });
  const texts = popup.cards[0].container.children.filter(child => child.kind === "text");
  assert.ok(texts[0].fontSize >= 22); assert.ok(texts[1].fontSize >= 14); assert.ok(texts[2].fontSize >= 16);
  popup.destroy();
  const shortPopup = new UpgradePopup(displayScene(1280, 480).scene, { choices, hints: [], levels: {} });
  for (const card of shortPopup.cards) {
    assert.ok(card.container.y - card.height / 2 >= 70);
    assert.ok(card.container.y + card.height / 2 <= 468);
    const rows = card.container.children.filter(child => child.kind === "text");
    for (let first = 0; first < rows.length; first++) for (let second = first + 1; second < rows.length; second++) assert.equal(overlaps(rows[first].getBounds(), rows[second].getBounds()), false);
  }
});

test("unexpected oversized future copy is bounded at the readable minimum", async () => {
  const { UpgradePopup, ConfigManager } = await uiModules;
  const choice = { ...ConfigManager.skills[0], name: "未来特别长的技能名称".repeat(15) };
  const popup = new UpgradePopup(displayScene(320, 480).scene, { choices: [choice], hints: [], levels: {} });
  const texts = popup.cards[0].container.children.filter(child => child.kind === "text");
  assert.equal(texts[0].fontSize, 12);
  assert.ok(texts[0].text.endsWith("…"));
  assert.equal(overlaps(texts[0].getBounds(), texts[1].getBounds()), false);
});

test("every authored skill and supply keeps its full name and benefit without text collisions", async () => {
  const { UpgradePopup, ConfigManager, UPGRADE_REWARD_CHOICES } = await uiModules;
  const { getSkillUpgradeBenefit } = await benefits;
  for (const [width, height] of [[320, 480], [390, 844], [722, 794], [800, 600], [900, 650], [1280, 720]]) {
    for (const choice of [...ConfigManager.skills, ...UPGRADE_REWARD_CHOICES]) for (const rank of new Set([0, Math.min(3, choice.maxLevel - 1), Math.min(7, choice.maxLevel - 1), choice.maxLevel - 1])) {
      const auraPreview = choice.aura && rank > 0 ? { currentRadius: 510, nextRadius: 520 } : undefined;
      const popup = new UpgradePopup(displayScene(width, height).scene, { choices: [choice], hints: [{ skillId: choice.id, buildHints: [], progressHints: [], auraPreview }], levels: { [choice.id]: rank } });
      const card = popup.cards[0];
      const texts = card.container.children.filter(child => child.kind === "text");
      assert.equal(texts[0].text.replaceAll("\n", ""), choice.name, `${width}: skill name truncated`);
      // Wrapping may trim separator whitespace at a line break, but never copy.
      assert.equal(texts[2].text.replace(/\s/g, ""), getSkillUpgradeBenefit(choice, Math.max(choice.id === 'peeler_blade' ? 1 : 0, rank), auraPreview).replace(/\s/g, ""), `${width}: benefit truncated at rank ${rank}`);
      for (let first = 0; first < texts.length; first++) for (let second = first + 1; second < texts.length; second++) assert.equal(overlaps(texts[first].getBounds(), texts[second].getBounds()), false, `${width}: ${choice.id} text collides`);
      popup.destroy();
    }
  }
});

test("modal shade stays lighter and constant without entrance or brightness tweens", async () => {
  const { UpgradePopup, ConfigManager } = await uiModules;
  const { scene, tweens } = displayScene();
  const popup = new UpgradePopup(scene, { choices: ConfigManager.skills.slice(0, 3), hints: [], levels: {} });
  const shade = popup.root.children.find(child => child.kind === "rectangle");
  assert.ok(shade.fillAlpha >= 0.4 && shade.fillAlpha <= 0.45);
  assert.equal(tweens.length, 0);
  popup.destroy();
});

test("cancel and destruction unsubscribe keyboard without spending or leaking targets", async () => {
  const { UpgradePopup, ConfigManager, EventBus } = await uiModules;
  EventBus.removeAllListeners(); const { scene } = displayScene();
  const popup = new UpgradePopup(scene, { choices: ConfigManager.skills.slice(0, 3), hints: [], levels: {}, sessionId: 1 });
  let cancelled = 0; let awarded = 0; EventBus.on("upgrade:cancel", () => cancelled++); EventBus.on("skill:selected", () => awarded++);
  scene.input.keyboard.emit("keydown", { key: "Escape", code: "Escape", preventDefault() {} });
  assert.equal(cancelled, 1); assert.equal(awarded, 0); assert.equal(popup.root.destroyed, true);
  assert.equal(scene.input.keyboard.listenerCount("keydown"), 0);
});

for (const key of ["1", "2", "3"]) {
  test(`held numeric ${key} is ignored until a fresh key press selects the chooser`, async () => {
    const { UpgradePopup, ConfigManager, EventBus } = await uiModules;
    EventBus.removeAllListeners();
    const { scene } = displayScene();
    const popup = new UpgradePopup(scene, { choices: ConfigManager.skills.slice(0, 3), hints: [], levels: {}, sessionId: 8 });
    const selections = [];
    EventBus.on("skill:selected", payload => selections.push(payload));
    let prevented = 0;
    scene.input.keyboard.emit("keydown", { key, repeat: true, preventDefault() { prevented++; } });
    assert.equal(selections.length, 0);
    assert.equal(popup.root.destroyed, false);
    assert.equal(prevented, 0);
    scene.input.keyboard.emit("keydown", { key, repeat: false, preventDefault() { prevented++; } });
    assert.deepEqual(selections, [{ skillId: ConfigManager.skills[Number(key) - 1].id, sessionId: 8 }]);
    assert.equal(popup.root.destroyed, true);
    assert.equal(prevented, 1);
    scene.input.keyboard.emit("keydown", { key, repeat: false, preventDefault() { prevented++; } });
    assert.equal(selections.length, 1);
    assert.equal(scene.input.keyboard.listenerCount("keydown"), 0);
  });
}

test("held number cannot consume the next automatically queued popup", async () => {
  const { GameScene, UpgradePopup, createPlayer, EventBus } = await uiModules;
  EventBus.removeAllListeners();
  const { scene: uiScene } = displayScene();
  const game = new GameScene();
  Object.assign(game, displayScene().scene);
  game.playerId = createPlayer(game.world, 0, 0, 210, 100, 100);
  const popups = [];
  EventBus.on("skill:selected", game.handleSkillSelected, game);
  EventBus.on("upgrade:cancel", game.cancelUpgradeChoices, game);
  EventBus.on("upgrade:closed", () => popups.at(-1)?.destroy());
  EventBus.on("level:choices", payload => popups.push(new UpgradePopup(uiScene, payload)));
  game.requestSkillChoice([]);
  game.requestSkillChoice([]);
  game.openUpgradeChoices();
  assert.equal(popups.length, 1);
  const first = popups[0];
  uiScene.input.keyboard.emit("keydown", { key: "1", repeat: false, preventDefault() {} });
  assert.equal(first.root.destroyed, true);
  assert.equal(game.pendingUpgrades, 1);
  assert.equal(game.choosingSkill, true);
  assert.equal(popups.length, 2);
  const second = popups[1];
  assert.notEqual(second.payload.sessionId, first.payload.sessionId);
  uiScene.input.keyboard.emit("keydown", { key: "1", repeat: true, preventDefault() {} });
  first.cards[0].hitZone.emit("pointerdown", { id: 7, isDown: true });
  assert.equal(game.pendingUpgrades, 1);
  assert.equal(second.root.destroyed, false);
  uiScene.input.keyboard.emit("keydown", { key: "1", repeat: false, preventDefault() {} });
  assert.equal(game.pendingUpgrades, 0);
  assert.equal(game.choosingSkill, false);
  assert.equal(second.root.destroyed, true);
  assert.equal(uiScene.input.keyboard.listenerCount("keydown"), 0);
});

test("HUD explicit upgrade button and enlarged skills do not overlap dash or status", async () => {
  const { HUDView, ConfigManager, getUILayout, EventBus } = await uiModules;
  for (const [width, height] of [[320, 480], [390, 844], [1280, 720]]) {
    const { scene } = displayScene(width, height); const layout = getUILayout(width, height); const hud = new HUDView(scene, layout);
    hud.update({ pendingUpgrades: 3, elapsedMs: 0, hp: 100, maxHp: 100, level: 4, experience: 0, experienceToNext: 100, kills: 0, gold: 0, skills: ConfigManager.skills.slice(0, 5).map(skill => ({ ...skill, level: 1 })), builds: [], aliveMonsters: 0, waveMonsterId: "fries_cultist", difficulty: { level: 1 }, dashCooldownRatio: 0 });
    assert.equal(hud.upgradeText.text, "升级 x3"); assert.equal(hud.upgradeButton.visible, true);
    let opened = 0; EventBus.once("upgrade:open", () => opened++); hud.upgradeButton.emit("pointerdown"); assert.equal(opened, 1);
    const upgrade = hud.upgradeButton.getBounds();
    for (const text of [hud.difficultyText, hud.attackSpeedText]) assert.equal(overlaps(upgrade, text.getBounds()), false);
    assert.equal(overlaps(upgrade, { x: layout.dash.x - layout.dash.width / 2, y: layout.dash.y - layout.dash.height / 2, width: layout.dash.width, height: layout.dash.height }), false);
    const slots = hud.skillsRoot.children.filter(child => child.texture === "asset:ui_v2_skill_slot");
    assert.ok(slots.every(slot => slot.width >= (width < 700 ? 48 : 72)));
    hud.update({ ...hud.payload, pendingUpgrades: 0 }); assert.equal(hud.upgradeButton.visible, false); hud.destroy();
  }
});

test("a pending credit never leaves a second upgrade button underneath the active chooser",async()=>{
 const {HUDView,getUILayout,EventBus}=await uiModules;const {scene}=displayScene(390,844),hud=new HUDView(scene,getUILayout(390,844));
 const payload={pendingUpgrades:1,choosingUpgrade:true,elapsedMs:0,hp:105,maxHp:105,level:2,experience:0,experienceToNext:28,kills:10,gold:0,skills:[],builds:[],aliveMonsters:26,waveMonsterId:'fries_cultist',difficulty:{level:1},dashCooldownRatio:0};
 hud.update(payload);assert.equal(hud.upgradeButton.visible,false);assert.equal(hud.upgradeText.visible,false);
 let opened=0;EventBus.once('upgrade:open',()=>opened++);hud.upgradeButton.emit('pointerdown');assert.equal(opened,0);
 hud.update({...payload,choosingUpgrade:false});assert.equal(hud.upgradeButton.visible,true);assert.equal(hud.upgradeText.text,'升级 x1');
 hud.upgradeButton.emit('pointerdown');assert.equal(opened,1);hud.destroy();
});

test('health and experience fills stay inside the actual PNG inner well instead of bleeding past gold endcaps',async()=>{
 const {HUDView,getUILayout}=await uiModules;
 for(const[width,height]of[[390,844],[1280,720]]){
  const {scene}=displayScene(width,height),layout=getUILayout(width,height),hud=new HUDView(scene,layout);
  const payload={pendingUpgrades:0,elapsedMs:0,hp:100,maxHp:100,level:1,experience:100,experienceToNext:100,kills:0,gold:0,skills:[],builds:[],aliveMonsters:0,waveMonsterId:'fries_cultist',difficulty:{level:1},dashCooldownRatio:0};
  hud.update(payload);
  // progress-frame.png has a transparent well at x=129..511 in its 640px canvas.
  for(const[fill,rail]of[[hud.healthFill,layout.health],[hud.experienceFill,layout.experience]]){
   const bounds=fill.getBounds();assert.ok(bounds.x>=rail.x-rail.width*.295);assert.ok(bounds.x+bounds.width<=rail.x+rail.width*.295);assert.ok(bounds.y>=rail.y-rail.height*.18);assert.ok(bounds.y+bounds.height<=rail.y+rail.height*.22);
  }
  hud.update({...payload,hp:0,experience:0});assert.equal(hud.healthFill.visible,false);assert.equal(hud.experienceFill.visible,false);hud.destroy();
 }
});
test('upgrade selection hides secondary combat labels and controls so portrait heading has a quiet lane',async()=>{
 const {HUDView,getUILayout}=await uiModules;
 for(const[width,height]of[[390,844],[1280,720]]){
  const {scene}=displayScene(width,height),hud=new HUDView(scene,getUILayout(width,height));
  const payload={choosingUpgrade:true,elapsedMs:10000,hp:105,maxHp:105,level:2,experience:0,experienceToNext:28,kills:8,gold:0,skills:[],builds:['弹幕流'],aliveMonsters:19,waveMonsterId:'fries_cultist',difficulty:{level:1},dashCooldownRatio:.5};
  const secondary=[hud.difficultyText,hud.attackSpeedText,hud.buildText,hud.skillsRoot,hud.dashButton,hud.dashIcon,hud.dashCooldownArc,hud.dashText,hud.dashHint];
  hud.update(payload);for(const view of secondary)assert.equal(view.visible,false);
  assert.equal(hud.healthText.visible,true);assert.equal(hud.experienceText.visible,true);assert.equal(hud.timerText.visible,true);
  hud.layout(getUILayout(height,width));for(const view of secondary)assert.equal(view.visible,false);
  hud.update({...payload,choosingUpgrade:false});for(const view of secondary)assert.equal(view.visible,true);hud.destroy();
 }
});
test('chooser owns a quiet modal layer while retaining HUD data for complete restoration',async()=>{
 const {HUDView,getUILayout}=await uiModules;
 for(const[width,height]of[[320,480],[390,844],[1280,720]]){
  const {scene}=displayScene(width,height),hud=new HUDView(scene,getUILayout(width,height));
  const payload={choosingUpgrade:true,elapsedMs:10000,hp:105,maxHp:105,level:2,experience:0,experienceToNext:28,kills:8,gold:0,skills:[],builds:[],aliveMonsters:19,waveMonsterId:'fries_cultist',difficulty:{level:1},dashCooldownRatio:0};
  hud.update(payload);for(const counter of Object.values(hud.counters))for(const view of Object.values(counter))assert.equal(view.visible,false);
  assert.equal(hud.root.visible,false);assert.equal(hud.healthText.text,'105 / 105');assert.equal(hud.timerText.text,'00:10');hud.update({...payload,choosingUpgrade:false});assert.equal(hud.root.visible,true);
  for(const counter of Object.values(hud.counters))for(const view of Object.values(counter))assert.equal(view.visible,true);hud.destroy();
 }
});
test('actual upgrade headings cannot overlap a visible HUD at intermediate compact heights',async()=>{
 const {HUDView,UpgradePopup,ConfigManager,getUILayout}=await uiModules;
 for(const[width,height]of[[390,650],[390,800],[799,650],[1024,640],[1280,720]]){
  const fixture=displayScene(width,height),hud=new HUDView(fixture.scene,getUILayout(width,height));
  hud.update({choosingUpgrade:true,elapsedMs:0,hp:105,maxHp:105,level:2,experience:0,experienceToNext:28,kills:8,gold:0,skills:[],builds:[],aliveMonsters:19,waveMonsterId:'fries_cultist',difficulty:{level:1},dashCooldownRatio:0});
  const popup=new UpgradePopup(fixture.scene,{choices:ConfigManager.skills.slice(0,3),hints:[],levels:{}}),title=fixture.objects.find(object=>object.text==='选择一项升级');
  const collision=[hud.healthFrame,hud.experienceFrame,hud.timerFrame].some(view=>overlaps(view.getBounds(),title.getBounds()));
  assert.equal(hud.root.visible&&collision,false,`${width}x${height}: visible primary HUD intersects actual chooser heading`);popup.destroy();hud.destroy();
 }
});
