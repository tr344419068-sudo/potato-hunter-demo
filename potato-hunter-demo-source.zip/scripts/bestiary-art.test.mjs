import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import test from "node:test";

const json = async path => JSON.parse(await readFile(path, "utf8"));

test("all eleven generated illustrations are registered with real alpha and safe margins", async () => {
  const [selection, registry] = await Promise.all([json("artifacts/generated-2026-11-18/selection.json"), json("src/configs/assets.json")]);
  assert.equal(selection.assets.length, 11);
  for (const asset of selection.assets) {
    const scene = ["camp", "victory", "retry"].includes(asset.id);
    const path = `assets/${scene ? "ui/campaign-v3" : "bestiary/v3"}/${asset.id}.png`;
    const entry = Object.values(registry).find(e => e.path === path);
    assert.ok(entry, `${asset.id} is not registered`);
    const inspect = spawnSync("python3", ["-c", "from PIL import Image; import sys; im=Image.open(sys.argv[1]); a=im.getchannel('A'); w,h=im.size; b=a.getbbox(); print(im.mode,w,h,a.getextrema()[0],a.getextrema()[1],all(v==0 for v in [a.getpixel((0,0)),a.getpixel((w-1,0)),a.getpixel((0,h-1)),a.getpixel((w-1,h-1))]),b[0]>0 and b[1]>0 and b[2]<w and b[3]<h)", `public/${path}`]);
    assert.equal(inspect.status, 0, inspect.stderr.toString());
    assert.equal(inspect.stdout.toString().trim(), `RGBA ${entry.width} ${entry.height} 0 255 True True`);
  }
});

test("three previously shared identities use dedicated art without changing combat values", async () => {
  const [current, before, registry] = await Promise.all([json("src/configs/monsters.json"), json("artifacts/generated-2026-11-18/monsters-before-art.json"), json("src/configs/assets.json")]);
  const previousIds = new Set(before.monsters.map(monster => monster.id));
  const existing = current.monsters.filter(monster => previousIds.has(monster.id));
  assert.equal(existing.length, 8);
  assert.deepEqual(existing.map(monster => monster.id), before.monsters.map(monster => monster.id));
  const changedIds = existing.filter(monster => monster.assetId !== before.monsters.find(previous => previous.id === monster.id)?.assetId).map(monster => monster.id).sort();
  const expectedChanges = ["delivery_box", "drone_summoner", "shield_guard"];
  assert.deepEqual(changedIds, [...expectedChanges].sort(), "only the three intended identities may change art");
  for (const id of expectedChanges) {
    const monster = current.monsters.find(m => m.id === id);
    assert.equal(monster.assetId, `enemy_${id}_v3`);
    const asset = registry[monster.assetId];
    assert.equal(asset.type, "enemy");
    assert.ok(asset.footPoint.y > asset.pivot.y);
    assert.ok(asset.footPoint.x > .35 && asset.footPoint.x < .7);
  }
  assert.deepEqual(existing.map(({assetId, ...stats}) => stats), before.monsters.map(({assetId, ...stats}) => stats));
  const { finalBossAssetId, ...intermediateBoss } = current.boss;
  assert.deepEqual(intermediateBoss, before.boss);
  assert.equal(finalBossAssetId, "boss_burger_tyrant_v4");
});
