import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { readFile } from "node:fs/promises";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
  export { World } from "./src/entities/World.ts";
  export * from "./src/entities/factories.ts";
  export { ConfigManager } from "./src/managers/ConfigManager.ts";
  export { SkillManager } from "./src/managers/SkillManager.ts";
  export { WaveManager } from "./src/managers/WaveManager.ts";
  export { GameScene } from "./src/scenes/GameScene.ts";
  export { EventBus } from "./src/managers/EventBus.ts";
  export { getAttackCooldown } from "./src/systems/AttackTempoModel.ts";
  export { BossSystem } from "./src/systems/BossSystem.ts";
  export { MonsterBehaviorSystem } from "./src/systems/MonsterBehaviorSystem.ts";
  export { MonsterAISystem } from "./src/systems/MonsterAISystem.ts";
  export { AutoAttackSystem } from "./src/systems/AutoAttackSystem.ts";
  export { AoeWarningSystem } from "./src/systems/AoeWarningSystem.ts";
  export { ProjectileCollisionSystem } from "./src/systems/ProjectileCollisionSystem.ts";
  export { KnockbackSystem } from "./src/systems/KnockbackSystem.ts";
  export { AuraSystem } from "./src/systems/AuraSystem.ts";
  export { MovementSystem } from "./src/systems/MovementSystem.ts";
  export { SkillEvolutionSystem } from "./src/managers/SkillEvolutionSystem.ts";
  export { MonsterContactSystem } from "./src/systems/MonsterContactSystem.ts";
  export { HUDView } from "./src/ui/HUDView.ts";
  export { getUILayout } from "./src/ui/UILayout.ts";
  export { RenderSystem } from "./src/systems/RenderSystem.ts";
  export * as roleModel from "./src/systems/MonsterRoleModel.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Scene: class {}, Events: { EventEmitter }, Display: { Color: { HexStringToColor: x => ({ color: parseInt(x.slice(1), 16) }) } }, Math: { Clamp: (x,a,b)=>Math.min(b,Math.max(a,x)), Between: (a,b)=>Math.round((a+b)/2), FloatBetween: (a,b)=>(a+b)/2 } };', resolveDir: root }));
  }}],
}).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

async function fixture() {
  const api = await modules;
  const world = new api.World();
  const playerId = api.createPlayer(world, 250, 0, 210, 100, 100);
  const runtime = { world, playerId, scene: { cameras: { main: { shake() {} } } }, skillManager: new api.SkillManager(), waveManager: new api.WaveManager(), stats: { elapsedMs: 60000, kills: 0, bossKills: 0, gold: 0 } };
  return { ...api, runtime, world, playerId };
}

function displayScene() {
  const objects = [];
  const add = new Proxy({}, { get(_owner, kind) { return (x, y, value, style = {}) => {
    const target = { kind, x: x ?? 0, y: y ?? 0, texture: kind === "image" ? value : undefined, text: kind === "text" ? value : "", width: 0, height: kind === "text" ? parseFloat(style.fontSize ?? 11) + (style.strokeThickness ?? 0) * 2 : 0, originX: 0.5, originY: 0.5, calls: [], destroyed: false };
    const proxy = new Proxy(target, { get(owner, property) {
      if (property in owner) return owner[property];
      if (property === "getBounds") return () => ({ x: owner.x - owner.width * owner.originX, y: owner.y - owner.height * owner.originY, width: owner.width, height: owner.height });
      return (...args) => {
        owner.calls.push([property, ...args]);
        if (property === "setPosition") [owner.x, owner.y] = args;
        if (property === "setDisplaySize") [owner.width, owner.height] = args;
        if (property === "setOrigin") { owner.originX = args[0]; owner.originY = args[1] ?? args[0]; }
        if (property === "setText") { owner.text = args[0]; owner.width = String(args[0]).length * 6; }
        if (property === "setFontSize") owner.height = args[0] + 6;
        if (property === "destroy") owner.destroyed = true;
        return proxy;
      };
    }});
    objects.push(proxy); return proxy;
  }; }});
  return { add, objects, textures: { exists: () => true }, events: { once() {} }, cameras: { main: { shake() {} } } };
}

function overlaps(first, second) {
  return first.x < second.x + second.width && first.x + first.width > second.x && first.y < second.y + second.height && first.y + first.height > second.y;
}

test("bombardier respects finite cast range before placing one snapshot warning", async () => {
  const { runtime, world, createMonster, ConfigManager, MonsterBehaviorSystem } = await fixture();
  const id = createMonster(world, ConfigManager.getMonster("corn_bombardier"), 10000, 0);
  const behavior = new MonsterBehaviorSystem(); behavior.update(1200, runtime);
  assert.equal(world.components.aoeWarnings.size, 0, "off-screen bomber cast at arbitrary distance");
  world.components.transforms.get(id).x = 0;
  behavior.update(16, runtime);
  assert.equal(world.components.aoeWarnings.size, 1);
  const warningId = [...world.components.aoeWarnings.keys()][0];
  const warning = world.components.aoeWarnings.get(warningId);
  assert.equal(warning.sourceId, id);
  assert.ok(warning.totalMs >= 900);
  assert.equal(world.components.monsters.get(id).behaviorTimerMs, 3200);
  world.components.transforms.get(runtime.playerId).x = 450;
  behavior.update(100, runtime);
  assert.equal(world.components.transforms.get(warningId).x, 250);
  assert.equal(world.components.aoeWarnings.size, 1);
});

test("shared warning geometry exposes padded diagonal origin and end envelopes", async () => {
  const { roleModel } = await modules;
  assert.equal(typeof roleModel.getChargeWarningEnvelope, "function", "missing shared collision envelope geometry");
  assert.equal(typeof roleModel.isPointInChargeWarning, "function");
  const warning = { angle: Math.PI / 4, length: 273, width: 104, contactPadding: 52 };
  const origin = { x: 50, y: 70 };
  const direction = Math.SQRT1_2;
  for (const along of [-52, 0, 273, 325]) assert.ok(roleModel.isPointInChargeWarning(origin.x + along * direction, origin.y + along * direction, origin.x, origin.y, warning));
  assert.equal(roleModel.isPointInChargeWarning(origin.x + 326 * direction, origin.y + 326 * direction, origin.x, origin.y, warning), false);
  const envelope = roleModel.getChargeWarningEnvelope(origin.x, origin.y, warning);
  assert.equal(envelope.travelLength, 273, "collision padding must not alter authored travel distance");
  assert.ok(Math.abs(envelope.points[0].x - (50 - 104 * direction)) < 0.0001);
  assert.equal(envelope.points.length, 4);
});

test("boss endpoint contact lies inside the actual rendered padded warning", async () => {
  const { runtime, world, BossSystem, createMonster, ConfigManager, MovementSystem, MonsterContactSystem, RenderSystem } = await fixture();
  const id = createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0, true);
  const player = world.components.transforms.get(runtime.playerId); player.x = 300; player.radius = 22;
  world.components.health.get(id).current *= 0.4;
  const boss = new BossSystem(); for (const delta of [1500, 750, 800, 1000, 800]) boss.update(delta, runtime);
  const warning = [...world.components.aoeWarnings.values()].find(item => item.shape === "rectangle");
  const scene = displayScene(); runtime.scene = scene;
  const graphics = scene.add.graphics(); new RenderSystem(scene, graphics).update(16, runtime);
  const points = graphics.calls.find(call => call[0] === "fillPoints")?.[1];
  assert.ok(points && Math.max(...points.map(point => point.x)) >= 300, "rendered charge warning excludes endpoint contact");
  assert.ok(Math.min(...points.map(point => point.x)) <= -(world.components.transforms.get(id).radius + player.radius));
  assert.equal(warning.width, (world.components.transforms.get(id).radius + player.radius) * 2);
  assert.equal(warning.length, 273);
  boss.update(950, runtime); new MovementSystem().update(650, runtime); new MonsterContactSystem().update(16, runtime);
  assert.equal(world.components.transforms.get(id).x, 273);
  assert.equal(world.components.health.get(runtime.playerId).current, 82);
});

test("flanker endpoint contact receives the same padded warning coverage", async () => {
  const { runtime, world, createMonster, ConfigManager, MonsterBehaviorSystem, MovementSystem, MonsterContactSystem } = await fixture();
  const id = createMonster(world, ConfigManager.getMonster("onion_flanker"), 0, 0);
  const player = world.components.transforms.get(runtime.playerId); player.x = 100; player.radius = 20;
  const behavior = new MonsterBehaviorSystem(); behavior.update(1200, runtime);
  const warning = [...world.components.aoeWarnings.values()][0];
  assert.equal(warning.contactPadding, world.components.transforms.get(id).radius + player.radius);
  assert.ok(warning.length + warning.contactPadding >= player.x);
  assert.equal(warning.width, (world.components.transforms.get(id).radius + player.radius) * 2);
  behavior.update(800, runtime); new MovementSystem().update(250, runtime); new MonsterContactSystem().update(16, runtime);
  assert.equal(world.components.transforms.get(id).x, 72.5);
  assert.equal(world.components.health.get(runtime.playerId).current, 91);
});

test("actual HUD status text never overlaps compact counters or dash after layout and resize", async () => {
  const { HUDView, getUILayout } = await modules;
  const scene = displayScene(); const hud = new HUDView(scene, getUILayout(390, 844));
  for (const [width, height] of [[390, 844], [320, 480], [1280, 720]]) {
    const layout = getUILayout(width, height); hud.layout(layout);
    hud.update({ elapsedMs: 0, hp: 100, maxHp: 100, level: 1, experience: 0, experienceToNext: 14, kills: 0, gold: 0, skills: [], builds: [], waveMonsterId: "fries_cultist", aliveMonsters: 99, difficulty: { level: 3 }, dashCooldownRatio: 0, attackSpeedBonus: 0.64, tempoStacks: 8 });
    const statuses = scene.objects.filter(item => item.kind === "text" && /^(攻速|难度)/.test(item.text));
    const counters = scene.objects.filter(item => item.texture === "asset:ui_v2_resource_pill");
    assert.equal(statuses.length, 2); assert.equal(counters.length, 3);
    for (const text of statuses) {
      for (const counter of counters) assert.equal(overlaps(text.getBounds(), counter.getBounds()), false, `${width}px ${text.text} overlaps counter`);
      const dash = { x: layout.dash.x - layout.dash.width / 2, y: layout.dash.y - layout.dash.height / 2, width: layout.dash.width, height: layout.dash.height };
      assert.equal(overlaps(text.getBounds(), dash), false);
    }
    assert.equal(overlaps(statuses[0].getBounds(), statuses[1].getBounds()), false, "status texts overlap each other");
    if (layout.compact) {
      const bottom = element => element.y + element.height / 2;
      assert.ok(layout.boss.y - layout.boss.height / 2 >= bottom(layout.counters.wave) + 4);
      assert.ok(layout.notification.y - layout.notification.height / 2 >= bottom(layout.boss) + 4);
    }
  }
});

test("role enemies and attack-speed skills retain registered art, including dedicated Pepper projectiles", async () => {
  const { ConfigManager: config } = await modules;
  for (const id of ["shield_guard", "onion_flanker", "corn_bombardier"]) {
    const monster = config.monsters.find(item => item.id === id);
    assert.ok(monster, `missing ${id}`);
    const battleArt = config.assets[monster.assetId];
    assert.equal(battleArt.type, "enemy");
    assert.match(battleArt.path, /\.(png|webp)$/);
    assert.ok(monster.speed < config.player.moveSpeed);
  }
  for (const id of ["pepper_gatling", "corn_burst", "pepper_motor", "combo_gear", "pepper_overdrive"]) {
    const skill = config.skills.find(item => item.id === id);
    assert.ok(skill, `missing ${id}`);
    const icon = config.assets[skill.iconAssetId];
    assert.equal(icon.type, "skill_icon");
    if (id === "pepper_gatling" || id === "pepper_overdrive") {
      assert.equal(icon.path, "assets/icons/skills/fries_storm.png");
      assert.equal(skill.weapon.projectileAssetId, `projectile_${id}`);
    } else assert.ok(icon.path.endsWith(".png"));
    if (skill.weapon) assert.ok(config.assets[skill.weapon.projectileAssetId]);
  }
  assert.ok(config.builds.some(build => build.id === "attack_speed"));
  const evolution = config.skillEvolutions.find(item => item.resultSkillId === "pepper_overdrive");
  assert.ok(evolution);
  for (const requirement of evolution.requiredSkills) assert.ok(requirement.level <= config.getSkill(requirement.id).maxLevel);
});

test("boss waits, winds up one cast, freezes, snapshots aim, then recovers", async () => {
  const { runtime, world, BossSystem, MonsterAISystem, createMonster, ConfigManager } = await fixture();
  const id = createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0, true);
  const boss = new BossSystem();
  boss.update(1499, runtime);
  assert.equal(world.components.aoeWarnings.size, 0);
  assert.equal(world.components.enemyProjectiles.size, 0);
  boss.update(1, runtime);
  assert.equal(world.components.aoeWarnings.size, 1, "first fan must visibly wind up");
  new MonsterAISystem().update(16, runtime);
  assert.deepEqual(world.components.velocities.get(id), { x: 0, y: 0 });
  world.components.transforms.get(runtime.playerId).y = 500;
  boss.update(749, runtime);
  assert.equal(world.components.enemyProjectiles.size, 0);
  boss.update(1, runtime);
  assert.equal(world.components.enemyProjectiles.size, 5);
  const velocities = [...world.components.enemyProjectiles.keys()].map(key => world.components.velocities.get(key));
  assert.ok(velocities.every(velocity => velocity.x > 0), "fan changed locked aim");
  boss.update(799, runtime);
  assert.equal(world.components.aoeWarnings.size, 0, "cast overlaps recovery");
  boss.update(1, runtime);
  assert.equal(world.components.aoeWarnings.size, 1, "second first-phase pattern missing");
  const warningId = [...world.components.aoeWarnings.keys()][0];
  assert.deepEqual({ x: world.components.transforms.get(warningId).x, y: world.components.transforms.get(warningId).y }, { x: 250, y: 500 });
});

test("boss pending hazards cancel on death and two boss clocks are independent", async () => {
  const { runtime, world, BossSystem, createMonster, ConfigManager, AoeWarningSystem } = await fixture();
  const first = createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0, true);
  const system = new BossSystem();
  system.update(1500, runtime);
  const second = createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 100, true);
  system.update(500, runtime);
  assert.equal(world.components.aoeWarnings.size, 1);
  world.components.health.get(first).current = 0;
  system.update(250, runtime);
  new AoeWarningSystem().update(1500, runtime);
  assert.equal(world.components.enemyProjectiles.size, 0, "dead boss executed cast");
  assert.equal(world.components.aoeWarnings.size, 0);
  system.update(750, runtime);
  assert.equal(world.components.aoeWarnings.size, 1, "second boss inherited first timer");
  world.destroyEntity(second);
  system.update(1000, runtime);
  assert.equal(world.components.aoeWarnings.size, 0);
});

test("phase two charge warning locks its rectangle and movement until execution", async () => {
  const { runtime, world, BossSystem, MonsterAISystem, createMonster, ConfigManager } = await fixture();
  const id = createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0, true);
  const health = world.components.health.get(id); health.current = health.max * 0.4;
  const system = new BossSystem();
  system.update(1500, runtime); system.update(750, runtime); system.update(800, runtime); system.update(1000, runtime); system.update(800, runtime);
  const [warningId, warning] = [...world.components.aoeWarnings].find(([, item]) => item.shape === "rectangle") ?? [];
  assert.ok(warning, "phase two has no charge telegraph");
  assert.equal(warning.damage, 0);
  assert.ok(warning.totalMs >= 950);
  assert.equal(warning.angle, 0);
  world.components.transforms.get(runtime.playerId).y = 500;
  new MonsterAISystem().update(16, runtime);
  assert.deepEqual(world.components.velocities.get(id), { x: 0, y: 0 });
  system.update(949, runtime);
  assert.equal(world.components.velocities.get(id).x, 0);
  system.update(1, runtime);
  new MonsterAISystem().update(16, runtime);
  assert.ok(world.components.velocities.get(id).x > 0);
  assert.equal(world.components.velocities.get(id).y, 0);
  assert.equal(world.components.aoeWarnings.has(warningId), false);
});

test("phase three includes annular heat and summon respects alive budget", async () => {
  const { runtime, world, BossSystem, createMonster, ConfigManager } = await fixture();
  const id = createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0, true);
  world.components.health.get(id).current *= 0.1;
  runtime.waveManager.getCurrentWave = () => ({ maxAlive: 3 });
  runtime.stats.elapsedMs = 0;
  const system = new BossSystem();
  let ring;
  for (let frame = 0; frame < 1600; frame++) {
    system.update(16, runtime);
    ring ??= [...world.components.aoeWarnings.values()].find(warning => warning.safeRadius > 0);
    assert.ok(world.components.monsters.size <= 3, "summons exceed alive budget");
  }
  assert.ok(ring, "phase three ring missing");
  assert.ok(ring.totalMs >= 750);
});

test("guard shield absorbs once then leaves health vulnerable", async () => {
  const { runtime, world, createMonster, createProjectile, ConfigManager, ProjectileCollisionSystem } = await fixture();
  const guard = ConfigManager.monsters.find(item => item.id === "shield_guard"); assert.ok(guard);
  const id = createMonster(world, guard, 0, 0); const health = world.components.health.get(id);
  assert.equal(world.components.monsters.get(id).shieldHp, 16);
  const system = new ProjectileCollisionSystem();
  createProjectile(world, 0, 0, 0, 0, "peeler_blade", 10, 0, 1000); system.update(16, runtime);
  assert.equal(health.current, health.max);
  createProjectile(world, 0, 0, 0, 0, "peeler_blade", 10, 0, 1000); system.update(16, runtime);
  assert.equal(world.components.monsters.get(id).shieldHp, 0);
  assert.equal(health.current, health.max - 4);
});

test("flanker has windup and bomber targets snapshot with one finite blast", async () => {
  const { runtime, world, createMonster, ConfigManager, MonsterBehaviorSystem, MonsterAISystem, AoeWarningSystem } = await fixture();
  for (const role of ["onion_flanker", "corn_bombardier"]) assert.ok(ConfigManager.monsters.find(item => item.id === role));
  const flanker = createMonster(world, ConfigManager.getMonster("onion_flanker"), 200, 0);
  const bomber = createMonster(world, ConfigManager.getMonster("corn_bombardier"), 0, 0);
  const system = new MonsterBehaviorSystem();
  system.update(1200, runtime); new MonsterAISystem().update(16, runtime);
  assert.equal(world.components.velocities.get(flanker).x, 0);
  const bomb = [...world.components.aoeWarnings].find(([, warning]) => warning.sourceId === bomber);
  assert.ok(bomb); assert.ok(bomb[1].totalMs >= 900);
  assert.equal(world.components.transforms.get(bomb[0]).x, 250);
  world.components.transforms.get(runtime.playerId).x = 500;
  const aoe = new AoeWarningSystem(); aoe.update(0, runtime); aoe.update(899, runtime);
  assert.ok(world.components.aoeWarnings.has(bomb[0]));
  aoe.update(1, runtime);
  assert.equal(world.components.health.get(runtime.playerId).current, 100);
  assert.equal(world.components.aoeWarnings.has(bomb[0]), false);
  system.update(1, runtime);
  assert.equal([...world.components.aoeWarnings.values()].filter(item => item.sourceId === bomber).length, 0);
});

test("boss damage warnings cannot detonate ahead of the serial windup clock", async () => {
  const { runtime, world, BossSystem, createMonster, ConfigManager, AoeWarningSystem } = await fixture();
  createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0, true);
  const boss = new BossSystem(); const aoe = new AoeWarningSystem();
  boss.update(1500, runtime); boss.update(750, runtime); boss.update(800, runtime);
  assert.equal(world.components.aoeWarnings.size, 1);
  aoe.update(1000, runtime);
  assert.equal(world.components.health.get(runtime.playerId).current, 100, "warning outran actual boss windup");
  boss.update(999, runtime); aoe.update(16, runtime);
  assert.equal(world.components.health.get(runtime.playerId).current, 100);
  boss.update(1, runtime); aoe.update(1, runtime);
  assert.equal(world.components.health.get(runtime.playerId).current, 85);
});

test("a newly placed bomber warning receives its full delay after the placement frame", async () => {
  const { runtime, world, createMonster, ConfigManager, MonsterBehaviorSystem, AoeWarningSystem } = await fixture();
  createMonster(world, ConfigManager.getMonster("corn_bombardier"), 0, 0);
  const behavior = new MonsterBehaviorSystem(); const aoe = new AoeWarningSystem();
  behavior.update(1200, runtime); aoe.update(16, runtime);
  const warning = [...world.components.aoeWarnings.values()][0];
  assert.equal(warning.remainingMs, 900);
  aoe.update(899, runtime); assert.equal(world.components.health.get(runtime.playerId).current, 100);
  aoe.update(1, runtime); assert.equal(world.components.health.get(runtime.playerId).current, 90);
});

test("locked boss windup does not slide under knockback", async () => {
  const { runtime, world, BossSystem, createMonster, ConfigManager, KnockbackSystem } = await fixture();
  const id = createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0, true);
  new BossSystem().update(1500, runtime);
  world.components.knockbacks.set(id, { x: 220, y: 0, remainingMs: 150 });
  new KnockbackSystem().update(16, runtime);
  assert.equal(world.components.transforms.get(id).x, 0);
});

test("charge travel stays inside its authored warning length on a long movement frame", async () => {
  const { runtime, world, BossSystem, createMonster, ConfigManager, MovementSystem } = await fixture();
  const id = createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0, true);
  world.components.health.get(id).current *= 0.4;
  const boss = new BossSystem();
  for (const delta of [1500, 750, 800, 1000, 800]) boss.update(delta, runtime);
  const warning = [...world.components.aoeWarnings.values()].find(item => item.shape === "rectangle");
  boss.update(950, runtime);
  new MovementSystem().update(1000, runtime);
  assert.ok(Math.abs(world.components.transforms.get(id).x - warning.length) < 0.0001);
});

test("legacy profiles keep their original haste multiplier without rapid-only floors", async () => {
  const { runtime, world, AutoAttackSystem, createMonster, ConfigManager } = await fixture();
  createMonster(world, ConfigManager.getMonster("fries_cultist"), 500, 0);
  runtime.skillManager.getWeaponProfiles = () => [{ skillId: "legacy", cooldownMs: 120, damage: 1, projectileSpeed: 500, projectileCount: 1, pierce: 0, lifetimeMs: 800, color: 0xffffff, size: 9, spread: 0, effects: [], critChance: 0, critMultiplier: 1.6, vfxKind: "kinetic" }];
  world.components.playerBuffs.set(runtime.playerId, [{ cooldownMultiplier: 0.35 }]);
  const attack = new AutoAttackSystem();
  attack.update(1, runtime); attack.update(42, runtime);
  assert.equal(world.components.projectiles.size, 2);
});

test("guard shield also absorbs aura damage and shield feedback is cool blue", async () => {
  const { runtime, world, createMonster, ConfigManager, AuraSystem } = await fixture();
  const id = createMonster(world, ConfigManager.getMonster("shield_guard"), 250, 0);
  runtime.skillManager.getAuraProfiles = () => [{ skillId: "test", radius: 100, damagePerSecond: 10, tickMs: 1000, effects: [], vfxKind: "kinetic" }];
  const health = world.components.health.get(id);
  new AuraSystem().update(1, runtime);
  assert.equal(health.current, health.max);
  assert.equal(world.components.monsters.get(id).shieldHp, 6);
});

test("renderer has role ornaments, directional telegraphs and localized attack-speed HUD", async () => {
  const render = await readFile(new URL("../src/systems/RenderSystem.ts", import.meta.url), "utf8");
  assert.ok(render.includes("drawRoleMarker"), "roles have no rendered marker");
  assert.ok(render.includes('warning.shape === "rectangle"'), "charge warns as a misleading circle");
  assert.ok(render.includes("getChargeWarningEnvelope(transform.x, transform.y, warning)") && render.includes("warning.angle"));
  const hud = await readFile(new URL("../src/ui/HUDView.ts", import.meta.url), "utf8");
  assert.ok(hud.includes("tempoStacks") && hud.includes("attackSpeedBonus"));
  assert.ok(hud.includes("攻速"));
});

test("ordinary summoner budget and dead ranged sources are bounded", async () => {
  const { runtime, world, createMonster, ConfigManager, MonsterBehaviorSystem } = await fixture();
  runtime.waveManager.getCurrentWave = () => ({ maxAlive: 2 }); runtime.stats.elapsedMs = 0;
  createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0);
  const ranged = createMonster(world, ConfigManager.getMonster("cola_spitter"), 0, 0);
  world.components.health.get(ranged).current = 0;
  new MonsterBehaviorSystem().update(1300, runtime);
  assert.equal(world.components.enemyProjectiles.size, 0);
  assert.ok(world.components.monsters.size <= 2);
});

test("rapid profiles keep legacy defaults, additive speed and zero count growth", async () => {
  const { runtime } = await fixture();
  const base = runtime.skillManager.getWeaponProfiles()[0]; assert.equal(base.cooldownMs, 620);
  runtime.skillManager.levelUp("pepper_gatling"); runtime.skillManager.levelUp("corn_burst");
  assert.ok(runtime.skillManager.getWeaponProfiles().some(item => item.skillId === "pepper_gatling"));
  for (let level = 0; level < 4; level++) runtime.skillManager.levelUp("pepper_gatling");
  const before = runtime.skillManager.getWeaponProfiles().find(item => item.skillId === "pepper_gatling");
  assert.equal(before.projectileCount, 1);
  runtime.skillManager.levelUp("pepper_motor");
  assert.equal(runtime.skillManager.getCombatStats().attackSpeedBonus, 0.08);
  const after = runtime.skillManager.getWeaponProfiles().find(item => item.skillId === "pepper_gatling");
  assert.ok(Math.abs(after.cooldownMs - before.cooldownMs / 1.08) < 0.001);
});

test("live HUD emission compounds permanent speed and confirmed-hit tempo like the weapon pipeline", async () => {
  const { runtime, world, playerId, GameScene, EventBus, getAttackCooldown } = await fixture();
  const originalCooldown = runtime.skillManager.getWeaponProfiles()[0].cooldownMs;
  for (let level = 0; level < 5; level++) runtime.skillManager.levelUp("pepper_motor");
  for (let level = 0; level < 3; level++) runtime.skillManager.levelUp("combo_gear");
  world.components.players.get(playerId).tempo = { stacks: 8, holdRemainingMs: 1500, decayElapsedMs: 0 };
  const scene = new GameScene();
  Object.assign(scene, { world, playerId, skillManager: runtime.skillManager, waveManager: runtime.waveManager });
  let payload;
  const capture = value => { payload = value; };
  EventBus.on("hud:update", capture);
  try { scene.emitHud(40); } finally { EventBus.off("hud:update", capture); }
  assert.ok(payload, "production scene did not emit HUD state");
  assert.ok(Math.abs(payload.attackSpeedBonus - 0.736) < 1e-9, `HUD reports ${payload.attackSpeedBonus} instead of compounded +73.6%`);
  const profile = runtime.skillManager.getWeaponProfiles()[0];
  const actualCooldown = getAttackCooldown(profile.cooldownMs, profile.minCooldownMs ?? 0, 0.24, 1);
  assert.ok(Math.abs(payload.attackSpeedBonus - (originalCooldown / actualCooldown - 1)) < 1e-9);
  assert.equal(payload.tempoStacks, 8);
});

test("attack-speed evolution actually unlocks and choice hints explain its reachable requirements", async () => {
  const { runtime, SkillEvolutionSystem, ConfigManager } = await fixture();
  const evolution = new SkillEvolutionSystem(runtime.skillManager);
  assert.equal(evolution.canUnlockEvolution("pepper_overdrive"), false);
  for (let level = 0; level < 5; level++) runtime.skillManager.levelUp("pepper_gatling");
  for (let level = 0; level < 3; level++) runtime.skillManager.levelUp("butter_lube");
  assert.equal(evolution.canUnlockEvolution("pepper_overdrive"), true);
  const hint = runtime.skillManager.getChoiceHints([ConfigManager.getSkill("pepper_gatling")])[0];
  assert.ok(hint.buildHints.some(value => value.includes("攻速")));
  assert.ok(hint.evolutionHint.includes("胡椒超频"));
  runtime.skillManager.levelUp("pepper_overdrive");
  assert.equal(evolution.canUnlockEvolution("pepper_overdrive"), false);
  const profile = runtime.skillManager.getWeaponProfiles().find(item => item.skillId === "pepper_overdrive");
  assert.equal(profile.burstCount, 4);
});

test("attack-speed evolution needs its matching passive once, with no extra passive rank gate", async () => {
  const { SkillManager, SkillEvolutionSystem, ConfigManager } = await fixture();
  const skills = new SkillManager({ random: () => 0.3, enforceSlots: true });
  const evolution = new SkillEvolutionSystem(skills);
  for (let level = 0; level < 5; level++) skills.levelUp("pepper_gatling");
  assert.equal(evolution.canUnlockEvolution("pepper_overdrive"), false, "active alone is insufficient");
  skills.levelUp("butter_lube");
  assert.equal(evolution.canUnlockEvolution("pepper_overdrive"), true, "one rank of the matching passive is enough");
  assert.ok(skills.getChoices(3).some(choice => choice.id === "pepper_overdrive"));
  assert.match(ConfigManager.getSkill("pepper_overdrive").description, /黄油润滑1级/);
});

test("new wave weights substitute tank roles and retain effective durability within ten percent", async () => {
  const { ConfigManager } = await modules;
  const previous = { 24: 348 / 9, 40: 456 / 11, 60: 690 / 13, 105: 792 / 15, 165: 960 / 17 };
  for (const wave of ConfigManager.waves.waves.filter(item => item.startSeconds >= 24)) {
    const sum = wave.monsterMix.reduce((total, item) => {
      const monster = ConfigManager.getMonster(item.monsterId);
      return total + item.weight * (monster.hp + (monster.shieldHp ?? 0));
    }, 0);
    const weight = wave.monsterMix.reduce((total, item) => total + item.weight, 0);
    assert.ok(Math.abs(sum / weight / previous[wave.startSeconds] - 1) <= 0.1, `${wave.startSeconds}s durability pressure changed substantially`);
    assert.ok(wave.monsterMix.some(item => item.monsterId === "fries_cultist"));
  }
  assert.equal(ConfigManager.waves.waves.find(wave => wave.startSeconds === 24).monsterMix.some(item => item.monsterId === "onion_flanker"), false);
  assert.equal(ConfigManager.waves.waves.find(wave => wave.startSeconds === 40).monsterMix.some(item => item.monsterId === "corn_bombardier"), false);
});

test("burst emits exactly three spaced shots and enforces its next cycle", async () => {
  const { runtime, world, createMonster, ConfigManager, AutoAttackSystem } = await fixture();
  runtime.skillManager.levelUp("corn_burst");
  const getter = runtime.skillManager.getWeaponProfiles.bind(runtime.skillManager);
  runtime.skillManager.getWeaponProfiles = () => getter().filter(item => item.skillId === "corn_burst");
  createMonster(world, ConfigManager.getMonster("fries_cultist"), 500, 0);
  const attack = new AutoAttackSystem();
  attack.update(1, runtime); attack.update(75, runtime); attack.update(75, runtime);
  assert.equal(world.components.projectiles.size, 3);
  attack.update(749, runtime); assert.equal(world.components.projectiles.size, 3);
  attack.update(1, runtime); assert.equal(world.components.projectiles.size, 4);
});

test("true burst spaces shots, retargets, drops empty queues and cannot backlog", async () => {
  const { runtime, world, createMonster, ConfigManager, AutoAttackSystem } = await fixture();
  runtime.skillManager.levelUp("corn_burst");
  runtime.skillManager.getWeaponProfiles = (() => { const getter = runtime.skillManager.getWeaponProfiles.bind(runtime.skillManager); return () => getter().filter(item => item.skillId === "corn_burst"); })();
  const target = createMonster(world, ConfigManager.getMonster("fries_cultist"), 500, 0);
  const system = new AutoAttackSystem(); system.update(1, runtime);
  assert.equal(world.components.projectiles.size, 1);
  system.update(74, runtime); assert.equal(world.components.projectiles.size, 1);
  world.components.transforms.get(runtime.playerId).y = 100;
  world.components.transforms.get(target).y = 300;
  system.update(1, runtime); assert.equal(world.components.projectiles.size, 2);
  const last = [...world.components.projectiles.keys()].at(-1);
  assert.equal(world.components.transforms.get(last).y, 100);
  assert.ok(world.components.velocities.get(last).y > 0);
  world.components.health.get(target).current = 0;
  system.update(75, runtime); assert.equal(world.components.projectiles.size, 2);
  system.update(10000, runtime); assert.equal(world.components.projectiles.size, 2);
  world.components.health.get(target).current = 10;
  system.update(10000, runtime); assert.equal(world.components.projectiles.size, 3, "burst caught up giant backlog");
});

test("confirmed hits alone increase capped run-local tempo, which holds then decays", async () => {
  const { runtime, world, playerId, createMonster, createProjectile, ConfigManager, AutoAttackSystem, ProjectileCollisionSystem, createPlayer } = await fixture();
  runtime.skillManager.levelUp("combo_gear");
  const attack = new AutoAttackSystem(); attack.update(1, runtime);
  assert.equal(world.components.players.get(playerId).tempo?.stacks ?? 0, 0);
  const target = createMonster(world, ConfigManager.getMonster("drone_summoner"), 0, 0);
  world.components.health.get(target).current = 10000;
  const collision = new ProjectileCollisionSystem();
  for (let hit = 0; hit < 12; hit++) { createProjectile(world, 0, 0, 0, 0, "peeler_blade", 1, 0, 1000); collision.update(1, runtime); }
  assert.equal(world.components.players.get(playerId).tempo?.stacks, 8);
  attack.update(1499, runtime); assert.equal(world.components.players.get(playerId).tempo.stacks, 8);
  attack.update(161, runtime); assert.equal(world.components.players.get(playerId).tempo.stacks, 7);
  world.components.health.get(target).current = 0;
  createProjectile(world, 0, 0, 0, 0, "peeler_blade", 1, 0, 1000); collision.update(1, runtime);
  assert.equal(world.components.players.get(playerId).tempo.stacks, 7);
  const fresh = createPlayer(world, 0, 0, 210, 100, 100);
  assert.equal(world.components.players.get(fresh).tempo?.stacks ?? 0, 0);
});
