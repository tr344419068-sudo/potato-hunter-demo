import { createCanvas, loadImage } from '@napi-rs/canvas';
import { writeFile } from 'node:fs/promises';

// The generated PNG contains a painted neutral checkerboard, not alpha. Extract
// the golden light by chroma. Colored checkerboard remnants can still be
// visible inside the palm; see the provenance note for this limitation.
const source = await loadImage('artifacts/potato-palm-2026-11-19/source.png');
const canvas = createCanvas(512, 512), ctx = canvas.getContext('2d');
ctx.drawImage(source, 0, 0, 512, 512);
const image = ctx.getImageData(0, 0, 512, 512);
for (let i = 0; i < image.data.length; i += 4) {
  const r = image.data[i], g = image.data[i + 1], b = image.data[i + 2];
  const chroma = Math.max(r, g, b) - Math.min(r, g, b);
  image.data[i + 3] = Math.round(255 * Math.max(0, Math.min(1, (chroma - 8) / 50)));
}
ctx.putImageData(image, 0, 0);
await writeFile('public/assets/vfx/potato-palm-v1/palm.png', await canvas.encode('png'));

// Reuse this project's own gold-and-blue icon frame to keep upgrade cards
// visually consistent; the generated palm remains the icon's main subject.
const frame = await loadImage('public/assets/icons/skills/salt_spread.png');
const icon = createCanvas(256, 256), iconCtx = icon.getContext('2d');
iconCtx.drawImage(frame, 0, 0);
iconCtx.save();
iconCtx.beginPath(); iconCtx.arc(128, 128, 88, 0, Math.PI * 2); iconCtx.clip();
const glow = iconCtx.createRadialGradient(128, 120, 8, 128, 128, 92);
glow.addColorStop(0, '#154d97'); glow.addColorStop(.7, '#06285a'); glow.addColorStop(1, '#06152f');
iconCtx.fillStyle = glow; iconCtx.fillRect(34, 34, 188, 188);
iconCtx.drawImage(canvas, 39, 39, 178, 178);
iconCtx.restore();
await writeFile('public/assets/vfx/potato-palm-v1/icon.png', await icon.encode('png'));
