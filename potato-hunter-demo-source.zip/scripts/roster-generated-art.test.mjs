import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import test from 'node:test';
import { uiModules, displayScene } from './ui-runtime-helpers.mjs';
import { createHash } from 'node:crypto';

const read = async path => JSON.parse(await readFile(path, 'utf8'));
test('new roster, finale and four area textures have production assets with real alpha', async () => {
  const registry = await read('src/configs/assets.json');
  const ids = ['enemy_mushroom_hexer_v4','enemy_chili_scatter_v4','enemy_pea_sniper_v4','enemy_donut_jumper_v4','boss_burger_tyrant_v4','vfx_poison_area_v4','vfx_ketchup_area_v4','vfx_poison_puff_v4','vfx_ketchup_splash_v4'];
  for (const id of ids) {
    const entry = registry[id]; assert.ok(entry, `${id} absent`);
    const result = spawnSync('python3', ['-c', "from PIL import Image; import sys; im=Image.open(sys.argv[1]); a=im.getchannel('A'); b=a.getbbox(); print(im.mode,*im.size,*a.getextrema(),b[0]>0 and b[1]>0 and b[2]<im.width and b[3]<im.height, a.getpixel((im.width//2,im.height//2)))", `public/${entry.path}`]);
    assert.equal(result.status,0,result.stderr.toString());
    const values=result.stdout.toString().trim().split(' ');
    assert.deepEqual(values.slice(0,6), ['RGBA',String(entry.width),String(entry.height),'0','255','True']);
    if (id.includes('_area_')) assert.equal(Number(values[6]),0,'the hero center must be genuinely transparent');
  }
  const monsters=await read('src/configs/monsters.json');
  assert.equal(monsters.boss.finalBossAssetId,'boss_burger_tyrant_v4');
  assert.equal(registry.boss_burger_tyrant_v4.displaySize,150);
});
test('selected assets retain original generation and processing provenance', async () => {
  const selection=await read('artifacts/generated-2026-11-18-roster/selection.json');
  assert.equal(selection.assets.length,9);
  for(const asset of selection.assets) { assert.equal(asset.sha256,createHash('sha256').update(await readFile(asset.outputPath)).digest('hex')); assert.ok(asset.originalPath); await readFile(asset.originalPath); assert.ok(asset.sourceUrl); assert.ok(asset.processing); }
});
test('actual HUD selects the final boss even when an old fryer remains alive', async () => {
  const { GameScene, createPlayer, ConfigManager, EventBus } = await uiModules;
  EventBus.removeAllListeners();
  const game=new GameScene();Object.assign(game,displayScene().scene);
  game.playerId=createPlayer(game.world,0,0,210,100,100);
  game.campaign={random:()=>0.5,registerBoss(){}};
  game.spawnCampaignBoss('intermediate');game.spawnCampaignBoss('final');
  const bosses=[...game.world.components.monsters.entries()];
  const intermediate=bosses.find(([,monster])=>monster.bossKind==='intermediate')[0];
  const final=bosses.find(([,monster])=>monster.bossKind==='final')[0];
  game.world.components.health.get(intermediate).current=123;
  const finalHealth=game.world.components.health.get(final);
  const phaseOneHp=Math.ceil(finalHealth.max * .75);
  finalHealth.current=phaseOneHp;
  assert.deepEqual(game.getBossHudData(),{hp:phaseOneHp,maxHp:finalHealth.max,name:'堡垒暴君',phase:{current:1,label:'芝麻火线',transitioning:false}});
  assert.equal(game.world.components.renders.get(final).assetId,ConfigManager.boss.finalBossAssetId);
  Object.assign(game.world.components.monsters.get(final).finalBossEncounter,{phase:3,completedCasts:1});
  finalHealth.current=0;
  assert.equal(game.getBossHudData().name,'巨型炸薯机');
  assert.equal(game.getBossHudData().hp,123);
});
test('final HUD has a distinct name and the boss bar renders it', async () => {
  const { BossBarView, getUILayout } = await uiModules;
  const { scene, objects } = displayScene(375,812);
  const layout=getUILayout(375,812).boss;
  const bar = new BossBarView(scene,layout);
  bar.update({hp:720,maxHp:720,name:'堡垒暴君',phase:{current:1,label:'芝麻火线',transitioning:false}});
  assert.ok(objects.some(o=>o.kind==='text'&&o.visible&&o.text==='堡垒暴君'));
  assert.ok(objects.some(o=>o.kind==='text'&&o.visible&&o.text.startsWith('阶段 1/3')));
  assert.equal(objects.filter(o=>o.kind==='rectangle'&&o.visible&&o.fillAlpha===1&&o.height>=8).length,3);
});
