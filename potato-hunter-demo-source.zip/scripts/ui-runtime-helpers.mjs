import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import EventEmitter from "eventemitter3";

const root = fileURLToPath(new URL("../", import.meta.url));
export const uiModules = build({ stdin: { contents: `
export { UpgradePopup } from "./src/ui/UpgradePopup.ts";
export { HUDView } from "./src/ui/HUDView.ts";
export { UIScene } from "./src/scenes/UIScene.ts";
export { FeedbackSystem } from "./src/systems/FeedbackSystem.ts";
export { getDamageNumberPresentation } from "./src/systems/DamageNumberModel.ts";
export { ProjectileCollisionSystem } from "./src/systems/ProjectileCollisionSystem.ts";
export { EnemyProjectileSystem } from "./src/systems/EnemyProjectileSystem.ts";
export { AuraSystem } from "./src/systems/AuraSystem.ts";
export { triggerElementalReaction } from "./src/systems/ElementalReactionSystem.ts";
export { InputSystem } from "./src/systems/InputSystem.ts";
export { GameScene } from "./src/scenes/GameScene.ts";
export { BootScene } from "./src/scenes/BootScene.ts";
export { AssetManager } from "./src/managers/AssetManager.ts";
export { CampaignShell } from "./src/ui/CampaignShell.ts";
export { ProgressionStore } from "./src/progression/ProgressionStore.ts";
export { createPlayer } from "./src/entities/factories.ts";
export { getUILayout } from "./src/ui/UILayout.ts";
export { ConfigManager } from "./src/managers/ConfigManager.ts";
export { EventBus } from "./src/managers/EventBus.ts";
export { UPGRADE_REWARD_CHOICES } from "./src/managers/RewardManager.ts";
export { UI_FONT, UI_BODY_FONT, UI_ASSET_IDS } from "./src/ui/UITheme.ts";
export { default as Phaser } from "phaser";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
plugins: [{ name: "headless-ui", setup(context) {
context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless-ui" }));
context.onLoad({ filter: /.*/, namespace: "headless-ui" }, () => ({ contents: `import EventEmitter from "eventemitter3"; export default { CANVAS: 1, WEBGL: 2, Scene: class {}, Events: { EventEmitter }, Loader: { Events: { PROGRESS: "progress", FILE_LOAD_ERROR: "loaderror", COMPLETE: "complete" } }, Scenes: { Events: { SHUTDOWN: "shutdown" } }, Input: { Keyboard: { KeyCodes: { W: "w", A: "a", S: "s", D: "d", SPACE: "space" }, JustDown: key=>{ const value=key.justDown; key.justDown=false; return value; } }, Events: { POINTER_MOVE: "pointermove", POINTER_OVER: "pointerover", POINTER_OUT: "pointerout", POINTER_DOWN: "pointerdown", POINTER_UP: "pointerup", POINTER_UP_OUTSIDE: "pointerupoutside" } }, Scale: { Events: { RESIZE: "resize" } }, BlendModes: { ADD: 1 }, Geom: { Rectangle: { Contains: (rect,x,y)=>x>=rect.x&&x<=rect.x+rect.width&&y>=rect.y&&y<=rect.y+rect.height } }, Utils: { Array: { Shuffle: values=>values } }, Math: { Vector2: class { constructor(x,y) { this.x=x; this.y=y; } }, Clamp: (value,min,max)=>Math.min(max,Math.max(min,value)), Between: (min,max)=>min, FloatBetween: (min,max)=>min, DegToRad: value=>value*Math.PI/180 }, Display: { Color: { HexStringToColor: color=>({ color: parseInt(color.slice(1),16) }), IntegerToColor: color=>({ rgba: String(color) }) } } };`, resolveDir: root }));
}}] }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

export const measuredWidth = (text, size) => Array.from(text).reduce((sum, character) => sum + size * (/\s/.test(character) ? 0.3 : /[\x00-\x7f]/.test(character) ? 0.58 : 1), 0);

export function displayScene(width = 1280, height = 720, hasTextures = true) {
  const objects = []; const tweens = []; const timers = []; const killed = [];
  const make = (kind, x = 0, y = 0, value, style = {}) => {
    const emitter = new EventEmitter();
    const target = { scene, kind, x, y, texture: ["image", "nineslice"].includes(kind) ? value : undefined, text: kind === "text" ? value : "", style, children: [], list: [], calls: [], width: 0, height: 0, originX: 0.5, originY: 0.5, fontSize: parseFloat(style.fontSize ?? 16), scaleX: 1, scaleY: 1, alpha: 1, visible: true, active: true, destroyed: false };
    const refresh = () => { const lines = String(target.text).split("\n"); target.width = Math.max(0, ...lines.map(line => measuredWidth(line, target.fontSize))) + (style.strokeThickness ?? 0) * 2; target.height = lines.length * (target.fontSize + (style.strokeThickness ?? 0) * 2) + Math.max(0, lines.length - 1) * (style.lineSpacing ?? 0); };
    target.context = { measureText: text => ({ width: measuredWidth(text, target.fontSize) }) };
    const proxy = new Proxy(target, { get(owner, property) {
      if (property in owner) return owner[property];
      if (["on", "off", "once", "emit"].includes(property)) return (...args) => { emitter[property](...args); return proxy; };
      if (property === "getBounds") return () => ({ x: owner.x - owner.width * owner.originX, y: owner.y - owner.height * owner.originY, width: owner.width, height: owner.height });
      return (...args) => {
        owner.calls.push([property, ...args]);
        if (property === "setPosition") [owner.x, owner.y] = args;
        if (property === "setX") owner.x = args[0];
        if (property === "setY") owner.y = args[0];
        if (property === "setDepth") owner.depth = args[0];
        if (property === "setRotation") owner.rotation = args[0];
        if (property === "setTexture") owner.texture = args[0];
        if (property === "setBlendMode") owner.blendMode = args[0];
        if (property === "setText") { owner.text = args[0]; refresh(); }
        if (property === "setFontSize") { owner.fontSize = args[0]; refresh(); }
        if (property === "setOrigin") { owner.originX = args[0]; owner.originY = args[1] ?? args[0]; }
        if (["setDisplaySize", "setSize"].includes(property)) [owner.width, owner.height] = args;
        if (property === "setAlpha") owner.alpha = args[0];
        if (property === "setVisible") owner.visible = args[0];
        if (property === "setActive") owner.active = args[0];
        if (property === "setScale") { owner.scaleX = args[0]; owner.scaleY = args[1] ?? args[0]; }
        if (property === "setInteractive") owner.interactive = true;
        if (property === "disableInteractive") owner.interactive = false;
        if (property === "add") { owner.children.push(...(Array.isArray(args[0]) ? args[0] : [args[0]])); owner.list = owner.children; }
        if (property === "removeAll") { if (args[0]) owner.children.forEach(child => child.destroy(true)); owner.children = []; owner.list = owner.children; }
        if (property === "destroy") { owner.destroyed = true; owner.active = false; if (args[0]) owner.children.forEach(child => child.destroy(true)); }
        return proxy;
      };
    }});
    if (kind === "text") refresh(); objects.push(proxy); return proxy;
  };
  const add = new Proxy({}, { get(_owner, kind) { return (x, y, value, style, ...rest) => {
    const object = make(kind, typeof x === "number" ? x : 0, typeof y === "number" ? y : 0, value, kind === "text" ? style : {});
    if (kind === "zone" || kind === "rectangle") object.setSize(value, style);
    if (kind === "rectangle") { object.fillColor = rest[0]; object.fillAlpha = rest[1] ?? 1; }
    if (kind === "nineslice") { object.setSize(rest[0], rest[1]); object.slices = rest.slice(2); }
    return object;
  }; }});
  const scale = Object.assign(new EventEmitter(), { width, height });
  const keyStates = {};
  const key = code => keyStates[code] ??= { isDown: false, justDown: false };
  const keyboard = Object.assign(new EventEmitter(), { keyStates, createCursorKeys: () => ({ up: key("up"), down: key("down"), left: key("left"), right: key("right") }), addKeys: mapping => Object.fromEntries(Object.entries(mapping).map(([name, code]) => [name, key(code)])), addKey: key });
  const scene = { add, objects, tweens: { add: config => { tweens.push(config); return config; }, killTweensOf: target => killed.push(target) }, time: { now: 0, delayedCall: (delay, callback) => { const timer = { delay, callback, remove() {} }; timers.push(timer); return timer; } }, scale, input: Object.assign(new EventEmitter(), { keyboard, activePointer: { id: 0, isDown: false, x: 0, y: 0 } }), textures: { exists: () => hasTextures }, events: new EventEmitter(), cameras: { main: { width, height, shakes: 0, flashes: 0, getWorldPoint: (x, y) => ({ x, y }), shake() { this.shakes++; }, flash() { this.flashes++; } } } };
  return { scene, objects, tweens, timers, killed };
}

export function overlaps(first, second) {
  return first.x < second.x + second.width && first.x + first.width > second.x && first.y < second.y + second.height && first.y + first.height > second.y;
}
