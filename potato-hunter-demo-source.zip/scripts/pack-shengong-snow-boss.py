"""Pack the selected Shengong RemBg PNGs without re-drawing or removing a background."""

import argparse
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SIZE = 320
FOOT = (round(SIZE * .56), round(SIZE * .78))
MARGIN = 4
# Scene-space stance anchors, measured at the boots; the hammer is allowed to
# extend below this line. Fixed-scale pose registration avoids snap-to-fit beats.
NEUTRAL = ((0, 0, 1024, 1024), (632, 900), .215)
POSES = (
    ((0, 0, 355, 512), (151, 446), .529),    # Brace
    ((355, 0, 667, 512), (508, 464), .527),  # Lift
    ((667, 0, 1024, 512), (883, 422), .533), # Charge
    ((0, 512, 353, 1024), (220, 849), .531), # Downswing
    ((353, 512, 676, 1024), (515, 856), .527), # Contact
    ((676, 512, 1024, 1024), (887, 932), .531), # Recoil
)


def read_cutout(path):
    image = Image.open(path)
    if image.mode != 'RGBA' or image.size != (1024, 1024) or image.getchannel('A').getextrema() != (0, 255):
        raise ValueError(f'{path}: expected a 1024×1024 transparent RemBg PNG')
    return image


def pack(source, crop, anchor, scale):
    sprite = source.crop(crop)
    bounds = sprite.getbbox()
    if not bounds:
        raise ValueError(f'No sprite in crop {crop}')
    left, top, right, bottom = bounds
    sprite = sprite.crop(bounds).resize((round((right - left) * scale), round((bottom - top) * scale)), Image.Resampling.LANCZOS)
    x = FOOT[0] + round((crop[0] + left - anchor[0]) * scale)
    y = FOOT[1] + round((crop[1] + top - anchor[1]) * scale)
    if min(x, y, SIZE - x - sprite.width, SIZE - y - sprite.height) < MARGIN:
        raise ValueError(f'Art would clip at frame boundary: {crop} → {(x, y, sprite.width, sprite.height)}')
    canvas = Image.new('RGBA', (SIZE, SIZE))
    canvas.paste(sprite, (x, y))
    return canvas


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('idle', type=Path)
    parser.add_argument('poses', type=Path)
    args = parser.parse_args()
    idle = pack(read_cutout(args.idle), *NEUTRAL)
    poses = read_cutout(args.poses)
    frames = [idle, *(pack(poses, *pose) for pose in POSES), idle]
    sheet = Image.new('RGBA', (SIZE * 4, SIZE * 2))
    for i, frame in enumerate(frames):
        sheet.paste(frame, (i % 4 * SIZE, i // 4 * SIZE))
    out = ROOT / 'public/assets/snow-v1/shengong-boss'
    out.mkdir(parents=True, exist_ok=True)
    for name, picture in (('idle', idle), ('swing', sheet)):
        file = out / f'{name}.webp'
        picture.save(file, 'WEBP', quality=83, method=6)
        print(f'{file.name}: {file.stat().st_size:,} bytes')


if __name__ == '__main__':
    main()
