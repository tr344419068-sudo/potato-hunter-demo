import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function loadJuiceModel() {
  try {
    return await import("../src/systems/CombatJuiceModel.ts");
  } catch {
    return {};
  }
}

async function loadShadowModel() {
  try {
    return await import("../src/systems/ShadowProfileModel.ts");
  } catch {
    return {};
  }
}

test("attack pose reads as a backward recoil followed by a forward rebound", async () => {
  const model = await loadJuiceModel();
  assert.equal(typeof model.getPlayerAttackPose, "function");

  const recoil = model.getPlayerAttackPose(0.24, 1, 0);
  const rebound = model.getPlayerAttackPose(0.6, 1, 0);

  assert.ok(recoil.offsetX < -3, `expected recoil, got ${recoil.offsetX}`);
  assert.ok(recoil.scaleY > 1, `expected loaded pose, got ${recoil.scaleY}`);
  assert.ok(rebound.offsetX > 0, `expected rebound, got ${rebound.offsetX}`);
  assert.ok(rebound.scaleY < 1, `expected settling squash, got ${rebound.scaleY}`);
});

test("attack pose exposes anticipation, strike, and recovery with a bounded smear", async () => {
  const model = await loadJuiceModel();

  const anticipation = model.getPlayerAttackPose(0.16, 1, 0);
  const strike = model.getPlayerAttackPose(0.43, 1, 0);
  const recovery = model.getPlayerAttackPose(0.82, 1, 0);

  assert.equal(anticipation.phase, "anticipation");
  assert.equal(strike.phase, "strike");
  assert.equal(recovery.phase, "recovery");
  assert.ok(strike.offsetX > 4.5, `strike should drive forward, got ${strike.offsetX}`);
  assert.ok(strike.smear >= 0.5 && strike.smear <= 1);
  assert.ok(recovery.smear < strike.smear);
});

test("fast elemental projectiles get a distinct motion profile without extreme scaling", async () => {
  const model = await loadJuiceModel();
  assert.equal(typeof model.getProjectileMotion, "function");

  const fire = model.getProjectileMotion("fire", 180, 7, 560);
  const frost = model.getProjectileMotion("frost", 180, 7, 560);

  assert.ok(fire.trailIntervalMs < 46);
  assert.ok(fire.scaleX > 1);
  assert.ok(fire.scaleY < 1);
  assert.ok(frost.rotation !== fire.rotation);
  for (const motion of [fire, frost]) {
    assert.ok(motion.scaleX <= 1.35 && motion.scaleX >= 0.75);
    assert.ok(motion.scaleY <= 1.35 && motion.scaleY >= 0.75);
  }
});

test("hit squash makes a target read as compressed instead of uniformly enlarged", async () => {
  const model = await loadJuiceModel();
  assert.equal(typeof model.getHitSquashPose, "function");

  const hit = model.getHitSquashPose(0.8, 3);

  assert.ok(hit.scaleX > 1);
  assert.ok(hit.scaleY < 1);
  assert.notEqual(hit.rotation, 0);
});

test("hero idle pose breathes asymmetrically with restrained grounded motion", async () => {
  const model = await loadJuiceModel();
  assert.equal(typeof model.getHeroLocomotionPose, "function");

  const poseA = model.getHeroLocomotionPose(0, 0, 0, 1);
  const poseB = model.getHeroLocomotionPose(420, 0, 0, 1);

  assert.notEqual(poseA.offsetY, poseB.offsetY);
  assert.notEqual(poseB.scaleX, poseB.scaleY);
  assert.ok(Math.abs(poseB.offsetY) <= 2);
  assert.ok(Math.abs(poseB.rotation) <= 0.02);
  assert.equal(poseB.facingX, 1);
});

test("hero walking keeps a level torso and stable planted shadow while leaning with direction", async () => {
  const model = await loadJuiceModel();
  assert.equal(typeof model.getHeroLocomotionPose, "function");

  const left = model.getHeroLocomotionPose(90, -220, 0, 1);
  const right = model.getHeroLocomotionPose(90, 220, 0, -1);

  assert.ok(Math.abs(left.offsetY) <= 0.6, "walking still bounces the entire bitmap");
  assert.ok(Math.abs(left.scaleX - 1) <= 0.012);
  assert.ok(Math.abs(left.scaleY - 1) <= 0.012);
  assert.equal(left.facingX, -1);
  assert.equal(right.facingX, 1);
  assert.ok(left.rotation < right.rotation);
  assert.ok(left.shadowScaleX >= 0.98 && left.shadowScaleX <= 1.02);
});

test("hero run alternates lateral weight without losing its grounded bounds", async () => {
  const model = await loadJuiceModel();
  const leftPlant = model.getHeroLocomotionPose(90, 0, -220, 1);
  const rightPlant = model.getHeroLocomotionPose(270, 0, -220, 1);

  assert.ok(leftPlant.offsetX > 0 && leftPlant.offsetX <= 0.8, `expected restrained left weight shift, got ${leftPlant.offsetX}`);
  assert.ok(rightPlant.offsetX < 0 && rightPlant.offsetX >= -0.8, `expected restrained right weight shift, got ${rightPlant.offsetX}`);
  assert.ok(Math.abs(leftPlant.rotation) <= 0.09);
  assert.ok(Math.abs(rightPlant.rotation) <= 0.09);
});

test("character shadow profiles provide ambient and contact layers for every combat role", async () => {
  const model = await loadShadowModel();
  assert.equal(typeof model.getCharacterShadowProfile, "function");

  const hero = model.getCharacterShadowProfile("hero", 84, 0);
  const monster = model.getCharacterShadowProfile("monster", 62, 0.35);
  const elite = model.getCharacterShadowProfile("elite", 76, 0.2);
  const boss = model.getCharacterShadowProfile("boss", 150, 0);

  for (const profile of [hero, monster, elite, boss]) {
    assert.ok(profile.ambientWidth > profile.contactWidth);
    assert.ok(profile.ambientHeight > profile.contactHeight);
    assert.ok(profile.ambientAlpha > 0 && profile.ambientAlpha <= 0.3);
    assert.ok(profile.contactAlpha > profile.ambientAlpha && profile.contactAlpha <= 0.55);
  }
  assert.ok(boss.ambientWidth > hero.ambientWidth);
  assert.ok(monster.contactAlpha < model.getCharacterShadowProfile("monster", 62, 0).contactAlpha);
});

test("hero renderer consumes facing and keeps the animated double-layer shadow grounded", async () => {
  const renderSource = await readFile(new URL("../src/systems/RenderSystem.ts", import.meta.url), "utf8");

  assert.match(renderSource, /drawCharacterShadow\(/);
  assert.match(renderSource, /getCharacterShadowProfile/);
  assert.match(renderSource, /scaleX\s*\*\s*facingX/);
  assert.match(renderSource, /shadowScaleX/);
});

test("sprite juice composes the full attack phase and smear into the hero silhouette", async () => {
  const source = await readFile(new URL("../src/systems/SpriteJuiceSystem.ts", import.meta.url), "utf8");

  assert.match(source, /totalMs:\s*230/);
  assert.match(source, /attack\.smear/);
  assert.match(source, /attack\.phase/);
  assert.match(source, /shadowScaleX/);
});

test("monster death squashes, pops upward, rotates, and leaves a pooled dust ring", async () => {
  const source = await readFile(new URL("../src/systems/SpriteJuiceSystem.ts", import.meta.url), "utf8");

  assert.match(source, /showDeathDustRing/);
  assert.match(source, /y:\s*payload\.y\s*-/);
  assert.match(source, /rotation:/);
  assert.match(source, /scaleY:\s*image\.scaleY\s*\*\s*0\.72/);
  assert.match(source, /EntityPools\.acquireGraphics/);
  assert.match(source, /EntityPools\.releaseGraphics/);
});
