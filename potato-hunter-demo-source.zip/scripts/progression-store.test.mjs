import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { build } from "esbuild";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));
const profileKey = "potato-hunter.profile.v1";
const defaultProfile = {
  version: 1,
  gold: 0,
  unlockedLoadouts: ["peeler"],
  selectedLoadout: "peeler",
  preferences: { musicVolume: 0.28, sfxVolume: 0.65, reducedEffects: false },
  totalRuns: 0,
  victories: 0,
  bestSeconds: 0,
  rewardedRunIds: [],
};

const modulesPromise = Promise.all([
  access(new URL("../src/progression/ProgressionStore.ts", import.meta.url)),
  access(new URL("../src/progression/RunRewardModel.ts", import.meta.url)),
]).then(() => build({
  stdin: {
    contents: 'export * from "./src/progression/ProgressionStore.ts"; export * from "./src/progression/RunRewardModel.ts";',
    resolveDir: projectRoot,
    loader: "ts",
  },
  bundle: true,
  platform: "node",
  format: "esm",
  write: false,
})).then((result) => import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString("base64")}`))
  .catch((error) => {
    if (error.code === "ENOENT") return {};
    throw error;
  });

async function loadModules() {
  const modules = await modulesPromise;
  assert.equal(typeof modules.ProgressionStore, "function", "ProgressionStore export is required");
  assert.equal(typeof modules.calculateRunReward, "function", "calculateRunReward export is required");
  return modules;
}

function createStorage(profile = null) {
  const items = new Map([["unrelated-save", "leave-me-alone"]]);
  if (profile !== null) items.set(profileKey, typeof profile === "string" ? profile : JSON.stringify(profile));
  return {
    items,
    getItem(key) { return items.get(key) ?? null; },
    setItem(key, value) { items.set(key, value); },
  };
}

function createProfile(patch = {}) {
  return { ...structuredClone(defaultProfile), ...patch };
}

function createRun(patch = {}) {
  return { outcome: "defeat", elapsedMs: 20_000, kills: 3, bossKills: 0, gold: 0, ...patch };
}

test("fresh profiles preserve the original audio defaults and free loadout", async () => {
  const { ProgressionStore, LOADOUTS } = await loadModules();
  const registry = JSON.parse(await readFile(new URL("../src/configs/assets.json", import.meta.url)));
  const storage = createStorage();
  assert.deepEqual(new ProgressionStore(storage).getProfile(), defaultProfile);
  assert.deepEqual(LOADOUTS.map(({ id, price, starterSkillId, iconPath }) => ({ id, price, starterSkillId, iconPath })), [
    { id: "peeler", price: 0, starterSkillId: "peeler_blade", iconPath: "assets/icons/skills/peeler_blade-v2.png" },
    { id: "pepper", price: 30, starterSkillId: "pepper_gatling", iconPath: registry.icon_skill_fries_storm.path },
    { id: "lightning", price: 90, starterSkillId: "thunder_potato", iconPath: "assets/icons/skills/thunder_chain-v2.png" },
  ]);
  assert.ok(LOADOUTS.every(({ name, description }) => name.length > 0 && description.length > 0));
  assert.equal(storage.getItem("unrelated-save"), "leave-me-alone");
  assert.equal(storage.getItem(profileKey), null, "reading defaults must not overwrite storage");
});

test("corrupt JSON and foreign or incomplete schemas use safe defaults without deleting saves", async () => {
  const { ProgressionStore } = await loadModules();
  for (const serialized of ["{bad json", "null", "[]", JSON.stringify({ version: 2, gold: 999 }), JSON.stringify({ version: 1, arbitrary: true })]) {
    const storage = createStorage(serialized);
    assert.deepEqual(new ProgressionStore(storage).getProfile(), defaultProfile);
    assert.equal(storage.getItem(profileKey), serialized);
    assert.equal(storage.getItem("unrelated-save"), "leave-me-alone");
  }
});

test("negative, fractional, nonfinite, and oversized stored currency cannot fund purchases", async () => {
  const { ProgressionStore } = await loadModules();
  for (const gold of [-1, -Infinity, Infinity, NaN, 90.5, "90", 1e100, Number.MAX_SAFE_INTEGER]) {
    const store = new ProgressionStore(createStorage(createProfile({ gold })));
    assert.equal(store.getProfile().gold, 0, `invalid currency ${String(gold)} must reset safely`);
    assert.equal(store.purchaseLoadout("pepper").ok, false);
  }
});

test("stored counters and loadout enums are sanitized with peeler always available", async () => {
  const { ProgressionStore } = await loadModules();
  const profile = new ProgressionStore(createStorage(createProfile({
    unlockedLoadouts: ["unknown", "pepper", "pepper", null],
    selectedLoadout: "lightning",
    totalRuns: -1,
    victories: 1e100,
    bestSeconds: -10,
    rewardedRunIds: ["run-1", "run-1", "", " ", 123, "bad/run"],
  }))).getProfile();
  assert.deepEqual(profile.unlockedLoadouts, ["peeler", "pepper"]);
  assert.equal(profile.selectedLoadout, "peeler");
  assert.equal(profile.totalRuns, 0);
  assert.equal(profile.victories, 0);
  assert.equal(profile.bestSeconds, 0);
  assert.deepEqual(profile.rewardedRunIds, ["run-1"]);
});

test("oversized receipt arrays and serialized profiles fall back safely", async () => {
  const { ProgressionStore } = await loadModules();
  assert.deepEqual(new ProgressionStore(createStorage(createProfile({ rewardedRunIds: Array(10_001).fill("run-1") }))).getProfile(), defaultProfile);
  assert.deepEqual(new ProgressionStore(createStorage(" ".repeat(2_000_001))).getProfile(), defaultProfile);
});

test("profile snapshots and settlement snapshots cannot mutate internal state", async () => {
  const { ProgressionStore } = await loadModules();
  const store = new ProgressionStore(createStorage());
  const snapshot = store.getProfile();
  snapshot.gold = 500;
  snapshot.preferences.musicVolume = 1;
  snapshot.unlockedLoadouts.push("pepper");
  snapshot.rewardedRunIds.push("run-1");
  assert.deepEqual(store.getProfile(), defaultProfile);
  const settlement = store.settleRun("run-1", createRun());
  settlement.profile.preferences.sfxVolume = 0;
  settlement.profile.rewardedRunIds.length = 0;
  assert.equal(store.getProfile().preferences.sfxVolume, 0.65);
  assert.deepEqual(store.getProfile().rewardedRunIds, ["run-1"]);
});

test("each starter charges its own price once and never charges for an owned loadout", async () => {
  const { ProgressionStore } = await loadModules();
  for (const [loadoutId, price] of [["pepper", 30], ["lightning", 90]]) {
    const storage = createStorage(createProfile({ gold: price }));
    const store = new ProgressionStore(storage);
    assert.deepEqual(store.purchaseLoadout(loadoutId), { ok: true, persisted: true });
    assert.equal(store.getProfile().gold, 0);
    assert.deepEqual(store.getProfile().unlockedLoadouts, ["peeler", loadoutId]);
    assert.deepEqual(store.purchaseLoadout(loadoutId), { ok: true, persisted: true });
    assert.equal(store.getProfile().gold, 0);
    assert.deepEqual(new ProgressionStore(storage).getProfile(), store.getProfile());
  }
});

test("unaffordable and unknown purchases preserve currency and ownership", async () => {
  const { ProgressionStore } = await loadModules();
  const store = new ProgressionStore(createStorage(createProfile({ gold: 29 })));
  assert.deepEqual(store.purchaseLoadout("pepper"), { ok: false, persisted: false, reason: "insufficient-gold" });
  assert.deepEqual(store.purchaseLoadout("invalid"), { ok: false, persisted: false, reason: "invalid-loadout" });
  assert.equal(store.getProfile().gold, 29);
  assert.deepEqual(store.getProfile().unlockedLoadouts, ["peeler"]);
});

test("selection rejects locked or unknown loadouts and persists unlocked choices", async () => {
  const { ProgressionStore } = await loadModules();
  const storage = createStorage(createProfile({ gold: 90 }));
  const store = new ProgressionStore(storage);
  assert.deepEqual(store.selectLoadout("lightning"), { ok: false, persisted: false });
  assert.deepEqual(store.selectLoadout("invalid"), { ok: false, persisted: false });
  store.purchaseLoadout("pepper");
  assert.deepEqual(store.selectLoadout("pepper"), { ok: true, persisted: true });
  assert.equal(new ProgressionStore(storage).getProfile().selectedLoadout, "pepper");
  assert.deepEqual(store.selectLoadout("peeler"), { ok: true, persisted: true });
});

test("reward bonuses follow survival, kill, boss, and victory boundaries exactly", async () => {
  const { calculateRunReward } = await loadModules();
  assert.equal(calculateRunReward(createRun({ elapsedMs: 14_999, kills: 2, gold: 7 })), 7);
  assert.equal(calculateRunReward(createRun({ elapsedMs: 15_000, kills: 2, gold: 7 })), 17);
  assert.equal(calculateRunReward(createRun({ elapsedMs: 1_000, kills: 3, gold: 7 })), 17);
  assert.equal(calculateRunReward(createRun({ elapsedMs: 19_999, gold: 7 })), 17);
  assert.equal(calculateRunReward(createRun({ elapsedMs: 20_000, gold: 7 })), 18);
  assert.equal(calculateRunReward(createRun({ outcome: "victory", elapsedMs: 60_000, bossKills: 2, gold: 7 })), 130);
  assert.equal(calculateRunReward(createRun({ outcome: "victory", elapsedMs: 1_000, kills: 2, gold: 7 })), 7);
});

test("zero-time fake victories and malformed reward inputs earn nothing", async () => {
  const { calculateRunReward, RUN_REWARD_POLICY } = await loadModules();
  for (const patch of [
    { elapsedMs: 0, outcome: "victory", kills: 99, gold: 99 },
    { elapsedMs: -1 }, { elapsedMs: NaN }, { elapsedMs: Infinity }, { elapsedMs: 1e100 },
    { kills: -1 }, { kills: 3.5 }, { kills: 1e100 }, { bossKills: 4 },
    { bossKills: -1 }, { gold: -1 }, { gold: 0.5 }, { gold: NaN }, { gold: Infinity },
    { gold: 1e100 }, { outcome: "win" }, { gold: "90" },
  ]) assert.equal(calculateRunReward(createRun(patch)), 0, JSON.stringify(patch));
  assert.equal(calculateRunReward(null), 0);
  assert.match(RUN_REWARD_POLICY, /zero-time|positive elapsed/i);
  assert.match(RUN_REWARD_POLICY, /collected gold|collection/i);
});

test("settlement updates currency and run records once and survives a fresh store", async () => {
  const { ProgressionStore } = await loadModules();
  const storage = createStorage();
  const store = new ProgressionStore(storage);
  const first = store.settleRun("victory-1", createRun({ outcome: "victory", elapsedMs: 60_000, bossKills: 2, gold: 7 }));
  assert.equal(first.awarded, 130);
  assert.equal(first.duplicate, false);
  assert.equal(first.persisted, true);
  assert.deepEqual(first.profile, createProfile({ gold: 130, totalRuns: 1, victories: 1, bestSeconds: 60, rewardedRunIds: ["victory-1"] }));
  const duplicate = new ProgressionStore(storage).settleRun("victory-1", createRun({ gold: 500 }));
  assert.equal(duplicate.awarded, 0);
  assert.equal(duplicate.duplicate, true);
  assert.equal(duplicate.persisted, true);
  assert.deepEqual(duplicate.profile, first.profile);
});

test("early valid runs record collected gold without an unearned victory", async () => {
  const { ProgressionStore } = await loadModules();
  const store = new ProgressionStore(createStorage());
  assert.equal(store.settleRun("early", createRun({ outcome: "victory", elapsedMs: 1_250, kills: 2, gold: 7 })).awarded, 7);
  assert.equal(store.getProfile().totalRuns, 1);
  assert.equal(store.getProfile().victories, 0);
  assert.equal(store.getProfile().bestSeconds, 1.25);
  store.settleRun("later", createRun({ elapsedMs: 20_000 }));
  assert.equal(store.getProfile().totalRuns, 2);
  assert.equal(store.getProfile().bestSeconds, 20);
});

test("invalid IDs and malformed runs do not change or consume a settlement receipt", async () => {
  const { ProgressionStore } = await loadModules();
  const storage = createStorage();
  const store = new ProgressionStore(storage);
  for (const runId of ["", " ", "bad/run", "x".repeat(129), null, 42]) {
    assert.deepEqual(store.settleRun(runId, createRun()), { awarded: 0, duplicate: false, persisted: false, profile: defaultProfile });
  }
  assert.deepEqual(store.settleRun("correctable", createRun({ elapsedMs: 0 })), { awarded: 0, duplicate: false, persisted: false, profile: defaultProfile });
  assert.equal(store.settleRun("correctable", createRun()).awarded, 11);
  assert.equal(storage.getItem("unrelated-save"), "leave-me-alone");
});

test("receipt capacity preserves old exact-once claims instead of evicting them", async () => {
  const { ProgressionStore } = await loadModules();
  const rewardedRunIds = Array.from({ length: 10_000 }, (_, index) => `run-${index}`);
  const profile = createProfile({ rewardedRunIds });
  const store = new ProgressionStore(createStorage(profile));
  assert.deepEqual(store.settleRun("new-run", createRun()), { awarded: 0, duplicate: false, persisted: false, profile });
  assert.equal(store.settleRun("run-0", createRun()).duplicate, true);
});

test("reward accumulation remains bounded and exact", async () => {
  const { ProgressionStore } = await loadModules();
  const store = new ProgressionStore(createStorage(createProfile({ gold: 999_999_995, totalRuns: 1_000_000_000, victories: 1_000_000_000 })));
  const settlement = store.settleRun("cap", createRun({ outcome: "victory" }));
  assert.equal(settlement.awarded, 5, "awarded reports the actual increase at the currency cap");
  assert.equal(settlement.profile.gold, 1_000_000_000);
  assert.equal(settlement.profile.totalRuns, 1_000_000_000);
  assert.equal(settlement.profile.victories, 1_000_000_000);
});

test("preferences clamp volumes while rejecting nonfinite or nonboolean patches", async () => {
  const { ProgressionStore } = await loadModules();
  const storage = createStorage();
  const store = new ProgressionStore(storage);
  assert.deepEqual(store.setPreferences({ musicVolume: -1, sfxVolume: 2, reducedEffects: true }), { persisted: true });
  assert.deepEqual(store.getProfile().preferences, { musicVolume: 0, sfxVolume: 1, reducedEffects: true });
  store.setPreferences({ musicVolume: NaN, sfxVolume: Infinity, reducedEffects: "false" });
  assert.deepEqual(store.getProfile().preferences, { musicVolume: 0, sfxVolume: 1, reducedEffects: true });
  store.setPreferences({ musicVolume: 0.4 });
  assert.deepEqual(new ProgressionStore(storage).getProfile().preferences, { musicVolume: 0.4, sfxVolume: 1, reducedEffects: true });
});

test("stored malformed preferences and counter relationships are sanitized", async () => {
  const { ProgressionStore } = await loadModules();
  const profile = new ProgressionStore(createStorage(createProfile({
    totalRuns: 2,
    victories: 8,
    preferences: { musicVolume: -20, sfxVolume: Infinity, reducedEffects: "true" },
  }))).getProfile();
  assert.deepEqual(profile.preferences, { musicVolume: 0, sfxVolume: 0.65, reducedEffects: false });
  assert.equal(profile.victories, 2);
});

test("blocked reads fall back safely and blocked writes preserve honest playable memory", async () => {
  const { ProgressionStore } = await loadModules();
  const blockedStorage = { getItem() { throw new Error("blocked read"); }, setItem() { throw new Error("blocked write"); } };
  const store = new ProgressionStore(blockedStorage);
  assert.deepEqual(store.getProfile(), defaultProfile);
  const settlement = store.settleRun("unsaved", createRun({ outcome: "victory" }));
  assert.equal(settlement.awarded, 91);
  assert.equal(settlement.persisted, false);
  assert.equal(store.getProfile().gold, 91);
  assert.deepEqual(store.purchaseLoadout("pepper"), { ok: true, persisted: false });
  assert.deepEqual(store.selectLoadout("pepper"), { ok: true, persisted: false });
  assert.deepEqual(store.setPreferences({ reducedEffects: true }), { persisted: false });
  const duplicate = store.settleRun("unsaved", createRun());
  assert.equal(duplicate.duplicate, true);
  assert.equal(duplicate.awarded, 0);
  assert.equal(duplicate.persisted, false);
  assert.equal(store.getProfile().gold, 61);
  assert.equal(store.getProfile().selectedLoadout, "pepper");
});

test("a failed initialization read cannot overwrite an unread save after access recovers", async () => {
  const { ProgressionStore } = await loadModules();
  const savedProfile = createProfile({
    gold: 250,
    unlockedLoadouts: ["peeler", "pepper"],
    selectedLoadout: "pepper",
    totalRuns: 1,
    bestSeconds: 20,
    rewardedRunIds: ["old-receipt"],
  });
  const storage = createStorage(savedProfile);
  const savedText = storage.getItem(profileKey);
  const read = storage.getItem;
  storage.getItem = () => { throw new Error("initial read blocked"); };
  const store = new ProgressionStore(storage);
  assert.deepEqual(store.getProfile(), defaultProfile);
  storage.getItem = read;
  assert.deepEqual(store.setPreferences({ reducedEffects: true }), { persisted: false });
  assert.equal(storage.getItem(profileKey), savedText, "preference changes must preserve the unread save");
  const settlement = store.settleRun("old-receipt", createRun());
  assert.equal(settlement.persisted, false);
  assert.equal(storage.getItem(profileKey), savedText, "ephemeral rewards must never erase durable receipts");
  assert.equal(store.settleRun("new-run", createRun({ outcome: "victory" })).persisted, false);
  assert.deepEqual(store.purchaseLoadout("pepper"), { ok: true, persisted: false });
  assert.deepEqual(store.selectLoadout("pepper"), { ok: true, persisted: false });
  assert.equal(storage.getItem(profileKey), savedText);
  const restoredStore = new ProgressionStore(storage);
  assert.deepEqual(restoredStore.getProfile(), savedProfile);
  assert.equal(restoredStore.settleRun("old-receipt", createRun()).duplicate, true);
  assert.equal(restoredStore.getProfile().gold, 250);
});

test("storage policy documents a single live writer and failed-read write protection", async () => {
  const { PROFILE_STORAGE_POLICY } = await loadModules();
  assert.equal(typeof PROFILE_STORAGE_POLICY, "string");
  assert.match(PROFILE_STORAGE_POLICY, /one live writer|single live writer/i);
  assert.match(PROFILE_STORAGE_POLICY, /cross-tab/i);
  assert.match(PROFILE_STORAGE_POLICY, /initial.*read.*disables persistence/i);
});

test("retrying a failed settlement save does not award twice", async () => {
  const { ProgressionStore } = await loadModules();
  const storage = createStorage();
  const write = storage.setItem;
  storage.setItem = () => { throw new Error("temporary write failure"); };
  const store = new ProgressionStore(storage);
  assert.equal(store.settleRun("retry", createRun()).persisted, false);
  storage.setItem = write;
  const retry = store.settleRun("retry", createRun());
  assert.equal(retry.duplicate, true);
  assert.equal(retry.awarded, 0);
  assert.equal(retry.persisted, true);
  assert.equal(new ProgressionStore(storage).settleRun("retry", createRun()).duplicate, true);
  assert.equal(new ProgressionStore(storage).getProfile().gold, 11);
});

test("missing browser storage remains playable without claiming persistence", async () => {
  const { ProgressionStore } = await loadModules();
  const store = new ProgressionStore();
  assert.equal(store.settleRun("headless", createRun()).persisted, false);
  assert.equal(store.getProfile().gold, 11);
});
