import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync, existsSync, mkdtempSync, readdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, join } from "node:path";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { inflateSync } from "node:zlib";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import EventEmitter from "eventemitter3";
import { displayScene } from "./ui-runtime-helpers.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const publicRoot = join(root, "public");
const hash = contents => createHash("sha256").update(contents).digest("hex");
const assetIds = ["glow", "ring", "slash", "trace", "flame", "smoke", "arc", "crystal", "motes", "chip", "peeler_spell", "fire_spell", "energy_spell", "lightning_spell", "smoke_spell"].map(name => `vfx_${name}`);
const assetConfig = () => JSON.parse(readFileSync(join(root, "src/configs/assets.json"), "utf8"));

function decodePng(path) {
  const contents = readFileSync(path);
  assert.equal(contents.subarray(1, 4).toString(), "PNG");
  const width = contents.readUInt32BE(16);
  const height = contents.readUInt32BE(20);
  assert.equal(contents[24], 8);
  assert.equal(contents[25], 6, "output must be RGBA, not an opaque additive rectangle");
  const chunks = [];
  for (let offset = 8; offset < contents.length;) {
    const size = contents.readUInt32BE(offset);
    if (contents.toString("ascii", offset + 4, offset + 8) === "IDAT") chunks.push(contents.subarray(offset + 8, offset + 8 + size));
    offset += size + 12;
  }
  const packed = inflateSync(Buffer.concat(chunks));
  const pixels = Buffer.alloc(width * height * 4);
  const stride = width * 4;
  for (let row = 0; row < height; row++) {
    const filter = packed[row * (stride + 1)];
    for (let column = 0; column < stride; column++) {
      const destination = row * stride + column;
      const left = column >= 4 ? pixels[destination - 4] : 0;
      const up = row > 0 ? pixels[destination - stride] : 0;
      const upperLeft = row > 0 && column >= 4 ? pixels[destination - stride - 4] : 0;
      const prediction = left + up - upperLeft;
      const distances = [Math.abs(prediction - left), Math.abs(prediction - up), Math.abs(prediction - upperLeft)];
      const paeth = distances[0] <= distances[1] && distances[0] <= distances[2] ? left : distances[1] <= distances[2] ? up : upperLeft;
      const correction = [0, left, up, Math.floor((left + up) / 2), paeth][filter];
      pixels[destination] = packed[row * (stride + 1) + column + 1] + correction;
    }
  }
  return { width, height, pixels };
}

test("curated PNG masks and one-shot strips are registered with transparent, nonempty temporal silhouettes", () => {
  const registry = assetConfig();
  for (const assetId of assetIds) {
    const asset = registry[assetId];
    assert.ok(asset, `missing imported asset registration: ${assetId}`);
    assert.equal(asset.type, "vfx");
    const png = decodePng(join(publicRoot, asset.path));
    assert.equal(png.height, 192);
    assert.equal(png.width, asset.frameCount ? 1536 : 192);
    assert.equal(asset.width, png.width);
    assert.equal(asset.height, png.height);
    const alphas = [];
    for (let offset = 3; offset < png.pixels.length; offset += 4) alphas.push(png.pixels[offset]);
    assert.ok(alphas.some(alpha => alpha === 0), `${assetId} has no transparent background`);
    assert.ok(alphas.some(alpha => alpha > 20), `${assetId} lost its silhouette`);
    assert.ok(alphas.filter(alpha => alpha > 20).length < alphas.length * 0.8, `${assetId} obscures a square tile`);
    assert.ok(alphas.some(alpha => alpha > 0 && alpha < 255), `${assetId} lost soft alpha`);
    if (asset.frameCount) {
      assert.equal(asset.frameWidth, 192); assert.equal(asset.frameHeight, 192); assert.equal(asset.frameCount, 8);
      const frames = [];
      for (let frame = 0; frame < 8; frame++) {
        const rows = [];
        for (let row = 0; row < 192; row++) rows.push(png.pixels.subarray((row * png.width + frame * 192) * 4, (row * png.width + (frame + 1) * 192) * 4));
        frames.push(hash(Buffer.concat(rows)));
      }
      assert.ok(new Set(frames).size >= 7, `${assetId} is not a finite animated silhouette`);
    }
  }
});

test("every shipped bitmap retains explicit per-output CC0 author, archive digest, and transforms", () => {
  const path = join(publicRoot, "assets/vfx/sources.json");
  assert.ok(existsSync(path), "missing licensed sourced-art provenance");
  const manifest = JSON.parse(readFileSync(path, "utf8"));
  assert.equal(manifest.outputs.length, assetIds.length);
  for (const output of manifest.outputs) {
    assert.ok(assetIds.includes(output.assetId));
    assert.ok(["Kenney", "Mikodrak"].includes(output.author));
    assert.equal(output.license, "CC0-1.0");
    assert.match(output.source, /^https:\/\/opengameart\.org\/content\//);
    assert.match(output.archiveSha256, /^[a-f0-9]{64}$/);
    assert.ok(output.entries.every(entry => entry.endsWith(".png")));
    assert.ok(output.transform.alpha && output.transform.scale > 0);
    assert.equal(hash(readFileSync(join(publicRoot, output.path))), output.outputSha256);
  }
  assert.match(readFileSync(join(publicRoot, "assets/vfx/Kenney-License.txt"), "utf8"), /Creative Commons Zero/);
  assert.ok(!readdirSync(join(publicRoot, "assets/vfx")).some(name => name.endsWith(".zip")));
});

test("the importer regenerates byte-identical bitmaps and provenance from the archived PNGs", () => {
  const importer = join(root, "scripts/import-combat-vfx.py");
  assert.ok(existsSync(importer), "missing deterministic import pipeline");
  const destination = mkdtempSync(join(tmpdir(), "combat-vfx-import-"));
  execFileSync("python3", [importer, "--output-dir", destination], { cwd: root });
  // This importer owns the archived CC0 root files. Generated AoE assets live in
  // a separate versioned directory and have their own provenance/hash tests.
  const registry = assetConfig();
  const originalFiles = [...assetIds.map(id => basename(registry[id].path)), "Kenney-License.txt", "sources.json"];
  assert.deepEqual(readdirSync(destination).sort(), [...originalFiles].sort());
  for (const name of originalFiles) {
    assert.equal(hash(readFileSync(join(destination, name))), hash(readFileSync(join(publicRoot, "assets/vfx", name))), `${name} was not deterministic`);
  }
});

const modules = build({ stdin: { contents: `
export { CombatParticleEmitter } from "./src/systems/CombatParticleEmitter.ts";
export { CombatVfxSystem } from "./src/systems/CombatVfxSystem.ts";
export { EventBus } from "./src/managers/EventBus.ts";
export { ConfigManager } from "./src/managers/ConfigManager.ts";
export { AssetManager } from "./src/managers/AssetManager.ts";
export { getCombatVfxTexture } from "./src/systems/CombatVfxTextures.ts";
export { World } from "./src/entities/World.ts";
export { createMonster, createPlayer, createProjectile } from "./src/entities/factories.ts";
export { SkillManager } from "./src/managers/SkillManager.ts";
export { MonsterBehaviorSystem } from "./src/systems/MonsterBehaviorSystem.ts";
export { AoeWarningSystem } from "./src/systems/AoeWarningSystem.ts";
export { BossSystem } from "./src/systems/BossSystem.ts";
export { ProjectileCollisionSystem } from "./src/systems/ProjectileCollisionSystem.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false, plugins: [{ name: "headless-textured-vfx", setup(context) {
  context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless-textured-vfx" }));
  context.onLoad({ filter: /.*/, namespace: "headless-textured-vfx" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Scenes: { Events: { SHUTDOWN: "shutdown" } }, Loader: { Events: { COMPLETE: "complete" } }, BlendModes: { NORMAL: 0, ADD: 1 }, Math: { Clamp: (value,min,max)=>Math.min(max,Math.max(min,value)), Between: (min,max)=>(min+max)/2, FloatBetween: (min,max)=>(min+max)/2 } };', resolveDir: root }));
}}] }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

async function fixture(width = 1280, loaded = true) {
  const api = await modules; api.EventBus.removeAllListeners();
  const display = displayScene(width, 720);
  const textures = new Map(); const removed = [];
  if (loaded) for (const assetId of assetIds) {
    const frameCount = assetId.endsWith("_spell") ? 8 : 1;
    const frames = Object.fromEntries(Array.from({ length: frameCount }, (_, frame) => [frame, { name: frame, width: 192, height: 192 }]));
    textures.set(`asset:${assetId}`, { frames, has: frame => Object.hasOwn(frames, frame), get: frame => frames[frame] });
  }
  display.scene.textures = { exists: key => textures.has(key), get: key => textures.get(key), remove: key => { removed.push(key); textures.delete(key); } };
  display.scene.cameras.main.worldView = { x: 0, y: 0, width, height: 720 };
  const originalAdd = display.scene.add;
  const imageFactory = (...args) => {
    const image = originalAdd.image(...args);
    image.frame = 0; image.tint = 0xffffff;
    image.setFrame = frame => { image.frame = frame; return image; };
    image.setTexture = (key, frame = 0) => { image.texture = key; image.frame = frame; return image; };
    image.setTint = tint => { image.tint = tint; return image; };
    image.clearTint = () => { image.tint = 0xffffff; return image; };
    return image;
  };
  display.scene.add = new Proxy({ image: imageFactory }, { get(owner, property) { return owner[property] ?? originalAdd[property]; } });
  return { ...api, ...display, textures, removed };
}

const activeImages = objects => objects.filter(image => image.kind === "image" && image.active && image.visible && !image.destroyed);

const sourcedAssetIds = ['vfx_boss_fire_flipbook', 'vfx_boss_dust_flipbook', 'vfx_boss_impact', 'vfx_boss_ember_ring', 'vfx_boss_static_ring', 'vfx_boss_muzzle'];
const enemyFlipbooks = ['vfx_enemy_sweep', 'vfx_enemy_lunge', 'vfx_enemy_bomb_debris', 'vfx_enemy_shield_break'];

test('all shipped Brackeys clips match pinned sources, playback metadata and mobile size budget', () => {
  const registry = assetConfig();
  const manifest = JSON.parse(readFileSync(join(publicRoot, 'assets/vfx/brackeys-boss-v1/sources.json'), 'utf8'));
  assert.equal(manifest.license, 'CC0-1.0');
  assert.match(manifest.commit, /^[a-f0-9]{40}$/);
  assert.ok(manifest.licenseEvidence.includes(manifest.commit));
  let total = 0;
  for (const id of sourcedAssetIds) {
    const asset = registry[id];
    const bytes = readFileSync(join(publicRoot, asset.path));
    const source = manifest.outputs.find(output => output.file === basename(asset.path));
    assert.ok(source?.upstreamFile.startsWith('vfx/brackeys_particle_bundle/'));
    assert.equal(bytes.toString('ascii', 8, 12), 'WEBP');
    assert.equal(source.sha256, hash(bytes));
    assert.deepEqual(source.dimensions, [asset.width, asset.height]);
    assert.equal(source.frames, asset.frameCount ?? 1);
    total += bytes.length;
  }
  assert.ok(total < 320 * 1024, `mobile asset budget exceeded: ${total} bytes`);
});
async function sourcedFixture() {
  const f = await fixture(375);
  for (const id of sourcedAssetIds) f.textures.set(`asset:${id}`, { has: () => true });
  const runtime = { world: { components: { projectiles: new Map(), transforms: new Map() } } };
  return { ...f, runtime };
}

test('enemy flipbooks are individually attributed and use less than 110 KiB together', () => {
  const registry = assetConfig();
  const manifest = JSON.parse(readFileSync(join(publicRoot, 'assets/vfx/cethiel-enemy-v1/sources.json'), 'utf8'));
  let total = 0;
  for (const id of enemyFlipbooks) {
    const asset = registry[id];
    const source = manifest.outputs.find(entry => entry.file === basename(asset.path));
    const bytes = readFileSync(join(publicRoot, asset.path));
    assert.equal(source.author, 'Cethiel');
    assert.equal(source.license, 'CC0-1.0');
    assert.equal(source.sha256, hash(bytes));
    assert.equal(bytes.toString('ascii', 8, 12), 'WEBP');
    assert.equal(source.entries.length, asset.frameCount);
    assert.deepEqual(source.dimensions, [asset.width, asset.height]);
    total += bytes.length;
  }
  assert.ok(total < 110 * 1024, `${total} bytes`);
});

async function enemyArtFixture() {
  const f = await sourcedFixture();
  for (const id of enemyFlipbooks) f.textures.set(`asset:${id}`, { has: () => true });
  const world = new f.World();
  const playerId = f.createPlayer(world, 280, 320, 210, 100, 100);
  const runtime = { ...f.runtime, world, playerId, skillManager: new f.SkillManager() };
  const create = (id, x = 30, y = 320, boss = false) => f.createMonster(world, f.ConfigManager.getMonster(id), x, y, boss);
  const art = id => activeImages(f.objects).filter(node => node.texture === `asset:vfx_enemy_${id}`);
  return { ...f, runtime, world, playerId, create, art, vfx: new f.CombatVfxSystem(f.scene), behavior: new f.MonsterBehaviorSystem(), aoe: new f.AoeWarningSystem() };
}

for (const desert of [false, true]) test(`real ${desert ? 'desert' : 'meadow'} sweep plays one wide flipbook for four hit circles`, async () => {
  const f = await enemyArtFixture();
  if (desert) f.runtime.campaign = { stage: 'desert' };
  const id = f.create('delivery_box', 30, 320, true);
  f.world.components.monsters.get(id).bossKind = 'final';
  const boss = new f.BossSystem();
  const tick = ms => { boss.update(ms, f.runtime); f.aoe.update(ms, f.runtime); };
  for (const ms of [1800, 1050, 1050, 1800, 1050]) tick(ms);
  assert.equal(f.world.components.aoeWarnings.size, 4);
  tick(1249);
  assert.equal(f.art('sweep').length, 0);
  tick(1);
  assert.equal(f.art('sweep').length, 1);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  const slash = f.art('sweep')[0];
  f.vfx.update(170, f.runtime);
  assert.ok(slash.frame > 0);
  f.vfx.update(550, f.runtime);
  assert.equal(f.art('sweep').length, 0);
  f.vfx.destroy();
});

for (const canceled of [false, true]) test(`bombardment plays debris only on a live cast at the locked landing point (canceled=${canceled})`, async () => {
  const f = await enemyArtFixture();
  const id = f.create('corn_bombardier');
  f.behavior.update(1500, f.runtime);
  f.aoe.update(16, f.runtime);
  f.world.components.transforms.get(f.playerId).x = 350;
  f.aoe.update(899, f.runtime);
  assert.equal(f.art('bomb_debris').length, 0);
  if (canceled) f.world.components.health.get(id).current = 0;
  f.aoe.update(1, f.runtime);
  assert.equal(f.art('bomb_debris').length, canceled ? 0 : 1);
  if (!canceled) assert.equal(f.art('bomb_debris')[0].x, 280);
  f.aoe.update(16, f.runtime);
  assert.equal(f.art('bomb_debris').length, canceled ? 0 : 1);
  f.vfx.destroy();
});

test('flanker blade plays on lunge, travels along the locked direction and respects reduced effects', async () => {
  const f = await enemyArtFixture();
  f.create('onion_flanker', 90);
  f.behavior.update(1500, f.runtime);
  assert.equal(f.art('lunge').length, 0);
  f.world.components.transforms.get(f.playerId).y = 410;
  f.behavior.update(800, f.runtime);
  const [blade] = f.art('lunge');
  assert.ok(blade);
  const startX = blade.x;
  f.vfx.update(100, f.runtime);
  assert.ok(blade.frame > 0 && blade.x > startX);
  assert.equal(blade.y, 320);
  f.EventBus.emit('presentation:preferences', { reducedEffects: true });
  assert.equal(f.art('lunge').length, 0);
  f.vfx.destroy();
});

test('a live guard breaks its shield once, not on partial shield damage or subsequent hits', async () => {
  const f = await enemyArtFixture();
  f.create('shield_guard', 140);
  const collision = new f.ProjectileCollisionSystem();
  const hit = damage => {
    f.createProjectile(f.world, 140, 320, 100, 0, 'peeler_blade', damage, 0, 900);
    collision.update(16, f.runtime);
    return f.art('shield_break').length;
  };
  assert.equal(hit(5), 0);
  assert.equal(hit(11), 1);
  assert.equal(hit(4), 1);
  f.vfx.destroy();
});

test('real hostile strike events play imported fire and dust frames once, then free the layer', async () => {
  const f = await sourcedFixture();
  const system = new f.CombatVfxSystem(f.scene);
  f.EventBus.emit('hostile:impact', { x: 180, y: 330, radius: 118, style: 'oil' });
  const fire = activeImages(f.objects).find(node => node.texture === 'asset:vfx_boss_fire_flipbook');
  assert.ok(fire, 'boss oil explosion must show the newly imported clip');
  assert.equal(fire.frame, 0);
  assert.ok(activeImages(f.objects).some(node => node.texture === 'asset:vfx_boss_dust_flipbook'));
  for (let i = 0; i < 6; i++) system.update(40, f.runtime);
  assert.ok(fire.frame >= 4, 'the burst cannot be a static image');
  for (let i = 0; i < 24; i++) system.update(40, f.runtime);
  assert.equal(fire.active, false);
  system.destroy();
  assert.ok(fire.destroyed);
});

test('terrain art stays outside a hostile ring center and reduced mode skips textured embellishments', async () => {
  const f = await sourcedFixture();
  const system = new f.CombatVfxSystem(f.scene);
  const strike = { x: 180, y: 330, radius: 260, safeRadius: 110, style: 'sauce' };
  f.EventBus.emit('hostile:impact', strike);
  const textures = activeImages(f.objects).filter(node => sourcedAssetIds.some(id => node.texture === `asset:${id}`));
  assert.ok(textures.length >= 3);
  const rim = textures.find(node => node.texture === 'asset:vfx_boss_ember_ring');
  assert.ok(rim && rim.x === strike.x && rim.width * .30 >= strike.safeRadius);
  assert.ok(textures.filter(node => node !== rim).every(node => Math.hypot(node.x - strike.x, node.y - strike.y) - Math.hypot(node.width, node.height) / 2 >= strike.safeRadius));
  f.EventBus.emit('presentation:preferences', { reducedEffects: true });
  f.EventBus.emit('hostile:impact', { ...strike, radius: 118, safeRadius: undefined, style: 'oil' });
  assert.ok(!activeImages(f.objects).some(node => sourcedAssetIds.some(id => node.texture === `asset:${id}`)));
  system.destroy();
});

test('boss volley uses one imported muzzle sprite per actual ray and no sprite at the central gap', async () => {
  const f = await sourcedFixture();
  const system = new f.CombatVfxSystem(f.scene);
  f.EventBus.emit('hostile:volley', { x: 180, y: 270, angles: [-.62, -.38, .38, .62], style: 'sand' });
  const flashes = activeImages(f.objects).filter(node => node.texture === 'asset:vfx_boss_muzzle');
  assert.deepEqual(flashes.map(node => node.rotation), [-.62, -.38, .38, .62]);
  system.destroy();
});

test('a hostile ring has a visible impact at the exact rim and preserves the safe center', async () => {
  const f = await fixture(375);
  const system = new f.CombatVfxSystem(f.scene);
  // The center is off-screen; the damaging rim still intersects the viewport.
  f.EventBus.emit('hostile:impact', { x: -200, y: 300, radius: 260, safeRadius: 110, style: 'sauce' });
  const graphics = f.objects.filter(object => object.kind === 'graphics' && object.calls.some(call => call[0] === 'strokeCircle' && call[3] === 260));
  assert.ok(graphics.length > 0);
  assert.ok(graphics.some(object => object.calls.some(call => call[0] === 'strokeCircle' && call[3] === 110)));
  assert.ok(!graphics.some(object => object.calls.some(call => call[0] === 'fillCircle' && call[1] === 0 && call[2] === 0)));
  system.destroy();
});

test('player hit effects cannot starve a boss impact, including in reduced mode', async () => {
  const f = await fixture(375);
  const system = new f.CombatVfxSystem(f.scene);
  f.EventBus.emit('presentation:preferences', { reducedEffects: true });
  for (let i = 0; i < 48; i++) f.EventBus.emit('weapon:impact', { x: 180, y: 270, color: 0xffffff, radius: 12, vfxKind: 'kinetic', critical: true });
  f.EventBus.emit('hostile:impact', { x: 180, y: 300, radius: 118, style: 'oil' });
  assert.ok(f.objects.some(object => object.kind === 'graphics' && object.active && object.calls.some(call => call[0] === 'strokeCircle' && call[3] === 118)));
  system.destroy();
});

test('a hero body crit plays imported impact frames, not an effect for ordinary hits or reduced mode', async () => {
  const f = await sourcedFixture();
  const system = new f.CombatVfxSystem(f.scene);
  const hit = { x: 180, y: 270, color: 0xffffff, radius: 18, vfxKind: 'peeler', skillId: 'peeler_blade' };
  const sourcedHits = () => activeImages(f.objects).filter(node => node.texture === 'asset:vfx_boss_impact');
  f.EventBus.emit('weapon:impact', hit);
  assert.equal(sourcedHits().length, 0);
  f.EventBus.emit('weapon:impact', { ...hit, critical: true });
  assert.equal(sourcedHits().length, 1);
  system.update(75, f.runtime);
  assert.ok(sourcedHits()[0].frame > 0);
  f.EventBus.emit('presentation:preferences', { reducedEffects: true });
  f.EventBus.emit('weapon:impact', { ...hit, critical: true });
  assert.equal(sourcedHits().length, 0);
  system.destroy();
});

test("the real loader uses valid sheet metadata and keeps ordinary or invalid-sheet assets as images", async () => {
  const { AssetManager, ConfigManager, scene } = await fixture(1280, false);
  const original = ConfigManager.assets;
  const previousImage = globalThis.Image;
  const queued = [];
  ConfigManager.assets = {
    strip: { type: "vfx", path: "strip.png", width: 1536, height: 192, frameWidth: 192, frameHeight: 192, frameCount: 8 },
    still: { type: "vfx", path: "still.png", width: 192, height: 192 },
    invalid: { type: "vfx", path: "invalid.png", width: 1536, height: 192, frameWidth: 0, frameHeight: 192, frameCount: Infinity },
    character: { type: "character", path: "hero.png", width: 192, height: 192 },
  };
  globalThis.Image = class { set src(_path) { queueMicrotask(() => this.onload()); } };
  scene.load = Object.assign(new EventEmitter(), { image: (...args) => queued.push(["image", ...args]), spritesheet: (...args) => queued.push(["spritesheet", ...args]), start() { this.emit("complete"); } });
  let completed = false;
  try {
    await AssetManager.loadAvailable(scene, () => { completed = true; });
    assert.equal(completed, true);
    assert.deepEqual(queued.find(entry => entry[1] === "asset:strip"), ["spritesheet", "asset:strip", "strip.png", { frameWidth: 192, frameHeight: 192, endFrame: 7 }]);
    assert.ok(queued.filter(entry => entry[1] !== "asset:strip").every(entry => entry[0] === "image"));
  } finally { ConfigManager.assets = original; globalThis.Image = previousImage; }
});

test("all six real impact families use imported artwork and advance finite local strip frames", async () => {
  const { CombatParticleEmitter, scene, objects } = await fixture();
  const emitter = new CombatParticleEmitter(scene);
  const signatures = [];
  for (const kind of ["peeler", "fire", "frost", "lightning", "poison", "explosion"]) {
    const count = emitter.emit({ x: 250, y: 250, kind, phase: "impact", directionX: 1, directionY: 0 });
    const images = activeImages(objects);
    assert.equal(images.length, count);
    assert.ok(images.every(image => image.texture.startsWith("asset:vfx_")), `${kind} still uses code-only artwork`);
    const strip = images.find(image => image.texture.endsWith("_spell"));
    assert.ok(strip, `${kind} has no finite spell strip`);
    assert.equal(strip.frame, 0);
    assert.ok(strip.width >= 70 && strip.width <= 160);
    signatures.push(images.map(image => `${image.texture}:${image.tint}:${image.blendMode}`).sort().join(","));
    emitter.update(140);
    assert.ok(strip.frame > 0 && strip.frame < 8, `${kind} frame did not advance`);
    emitter.update(2500);
    assert.equal(emitter.activeCount, 0);
  }
  assert.equal(new Set(signatures).size, 6);
  emitter.destroy();
});

test("artwork light, expanding ring, and drifting smoke have separate material and motion state", async () => {
  const { CombatParticleEmitter, scene, objects } = await fixture();
  const emitter = new CombatParticleEmitter(scene);
  emitter.emit({ x: 250, y: 250, kind: "explosion", phase: "impact", critical: true, radius: 100 });
  const images = activeImages(objects);
  const ring = images.find(image => image.texture === "asset:vfx_ring");
  const smoke = images.find(image => image.texture === "asset:vfx_smoke_spell");
  assert.ok(ring && smoke, "explosion lacks imported ring or smoky aftermath");
  assert.equal(ring.blendMode, 1); assert.equal(smoke.blendMode, 0);
  assert.ok(smoke.alpha < 0.6);
  assert.ok(images.every(image => image.width <= 160 && image.height <= 160 && image.depth > 2 && image.depth < 4));
  const ringWidth = ring.width; const smokeWidth = smoke.width; const smokeY = smoke.y;
  emitter.update(110);
  assert.ok(ring.width > ringWidth); assert.ok(smoke.width > smokeWidth); assert.ok(smoke.y < smokeY);
  assert.ok(smoke.alpha < 0.6);
  emitter.destroy();
});

test("pooled artwork resets frames, tint, blend, pivot, direction, dimensions, and shared ownership", async () => {
  const { CombatParticleEmitter, scene, objects, textures, removed } = await fixture();
  const first = new CombatParticleEmitter(scene); const second = new CombatParticleEmitter(scene);
  first.emit({ x: 250, y: 250, kind: "poison", phase: "aura", count: 1 });
  first.update(160);
  const smoky = activeImages(objects)[0];
  assert.equal(smoky.blendMode, 0); assert.ok(smoky.frame > 0);
  const previousTint = smoky.tint;
  first.update(3000);
  const pooled = objects.filter(image => image.kind === "image");
  assert.equal(first.emit({ x: 220, y: 200, kind: "peeler", phase: "muzzle", directionX: 0, directionY: -1, count: 1 }), 1);
  const reused = activeImages(objects)[0];
  assert.ok(pooled.includes(reused));
  assert.equal(reused.texture, "asset:vfx_slash"); assert.equal(reused.frame, 0); assert.equal(reused.blendMode, 1);
  assert.notEqual(reused.tint, 0xffffff); assert.notEqual(reused.tint, previousTint); assert.equal(reused.originX, 0.5); assert.equal(reused.originY, 0.5);
  assert.equal(reused.rotation, -Math.PI / 2); assert.equal(reused.x, 220); assert.equal(reused.y, 200);
  assert.ok(reused.width > reused.height && reused.alpha > 0);
  first.destroy(); first.destroy();
  assert.equal(textures.size, assetIds.length); assert.deepEqual(removed, []);
  assert.equal(second.emit({ x: 250, y: 250, kind: "fire", phase: "impact", count: 1 }), 1);
  second.destroy(); assert.equal(textures.size, assetIds.length);
});

for (const width of [1280, 390]) test(`loaded artwork retains event caps, reserve, culling, and finite hints at ${width}px`, async () => {
  const { CombatParticleEmitter, scene, objects } = await fixture(width);
  const emitter = new CombatParticleEmitter(scene);
  const capacity = width < 700 ? 100 : 180;
  for (let burst = 0; burst < 80; burst++) emitter.emit({ x: 250, y: 250, kind: "poison", phase: "impact", count: 10000, radius: NaN, directionX: Infinity });
  assert.equal(emitter.activeCount, capacity - 36);
  assert.equal(emitter.emit({ x: 250, y: 250, kind: "explosion", phase: "impact", critical: true, count: 10000 }), 18);
  assert.equal(emitter.emit({ x: 250, y: 250, kind: "lightning", phase: "reaction", count: 10000 }), 18);
  assert.equal(emitter.activeCount, capacity);
  assert.equal(emitter.emit({ x: -500, y: -500, kind: "fire", phase: "impact" }), 0);
  assert.equal(emitter.emit({ x: 250, y: 250, kind: "fire", phase: "impact", count: NaN }), 0);
  scene.scale.width = 390; emitter.update(16);
  assert.ok(emitter.activeCount <= 100);
  assert.ok(activeImages(objects).every(image => [image.x, image.y, image.width, image.height, image.rotation, image.alpha].every(Number.isFinite)));
  emitter.update(3000); assert.equal(emitter.activeCount, 0); emitter.destroy();
});

test("real weapon and aura events select imported artwork without ordinary camera effects", async () => {
  const { CombatVfxSystem, EventBus, scene, objects } = await fixture();
  const system = new CombatVfxSystem(scene);
  EventBus.emit("weapon:fired", { x: 250, y: 250, directionX: 0, directionY: -1, color: 0xffffff, size: 16, projectileCount: 1, vfxKind: "peeler" });
  EventBus.emit("weapon:impact", { x: 250, y: 250, radius: 42, color: 0xffaa22, vfxKind: "fire" });
  EventBus.emit("aura:pulse", { x: 250, y: 250, radius: 65, color: 0x99ff33, vfxKind: "poison" });
  assert.ok(activeImages(objects).some(image => image.texture === "asset:vfx_slash"));
  assert.ok(activeImages(objects).some(image => image.texture === "asset:vfx_fire_spell"));
  assert.ok(activeImages(objects).some(image => image.blendMode === 0));
  assert.equal(scene.cameras.main.shakes, 0); assert.equal(scene.cameras.main.flashes, 0);
  system.destroy(); assert.equal(activeImages(objects).length, 0);
});

test("kinetic and ketchup receive imported masks, while missing or malformed sheets fall back safely", async () => {
  const { CombatParticleEmitter, scene, objects, textures } = await fixture();
  const emitter = new CombatParticleEmitter(scene);
  for (const kind of ["kinetic", "ketchup"]) {
    assert.ok(emitter.emit({ x: 250, y: 250, kind, phase: "impact" }) > 0);
    assert.ok(activeImages(objects).every(image => image.texture.startsWith("asset:vfx_")));
    emitter.update(3000);
  }
  textures.set("asset:vfx_fire_spell", { has: () => false });
  scene.textures.createCanvas = undefined;
  assert.equal(emitter.emit({ x: 250, y: 250, kind: "fire", phase: "impact", count: 1 }), 0, "malformed strip was treated as an animation without fallback support");
  emitter.destroy();
  const missing = await fixture(1280, false);
  assert.equal(new missing.CombatParticleEmitter(missing.scene).emit({ x: 250, y: 250, kind: "fire", phase: "impact" }), 0);
});

test("an unavailable texture retrieval API never mistakes placeholder existence for loaded artwork", async () => {
  const { CombatParticleEmitter, scene } = await fixture();
  scene.textures = { exists: () => true };
  const emitter = new CombatParticleEmitter(scene);
  assert.doesNotThrow(() => emitter.emit({ x: 250, y: 250, kind: "fire", phase: "impact", count: 1 }));
  emitter.destroy();
});

for (const [label, changes] of [
  ["missing frameCount", { frameCount: undefined }],
  ["missing frameWidth", { frameWidth: undefined }],
  ["missing frameHeight", { frameHeight: undefined }],
  ["missing all sheet fields", { frameCount: undefined, frameWidth: undefined, frameHeight: undefined }],
  ["invalid frameWidth", { frameWidth: 0 }],
  ["nonfinite frameHeight", { frameHeight: Infinity }],
  ["fractional frameWidth", { frameWidth: 191.5 }],
  ["frameWidth outside source", { frameWidth: 1537 }],
  ["frame count outside source capacity", { frameWidth: 768 }],
]) test(`the artwork resolver rejects ${label} instead of displaying the whole spell strip`, async () => {
  const { ConfigManager, getCombatVfxTexture, CombatParticleEmitter, scene } = await fixture();
  const original = ConfigManager.assets.vfx_fire_spell;
  ConfigManager.assets.vfx_fire_spell = { ...original, ...changes };
  try {
    assert.equal(getCombatVfxTexture(scene, "fire", "impact", "glow", 0), undefined);
    const emitter = new CombatParticleEmitter(scene);
    assert.equal(emitter.emit({ x: 250, y: 250, kind: "fire", phase: "impact", count: 1 }), 0);
    emitter.destroy();
  } finally { ConfigManager.assets.vfx_fire_spell = original; }
});

test("the artwork resolver continues accepting ordinary static masks without sheet metadata", async () => {
  const { getCombatVfxTexture, scene } = await fixture();
  const texture = getCombatVfxTexture(scene, "kinetic", "impact", "glow", 0);
  assert.equal(texture.key, "asset:vfx_glow");
  assert.equal(texture.frameCount, 1);
});
