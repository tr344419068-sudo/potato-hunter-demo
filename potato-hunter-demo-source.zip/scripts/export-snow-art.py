"""Build and verify the run-time snow WebPs from Blender PNGs and periodic ground noise."""
import hashlib
import math
from pathlib import Path
import sys

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'public/assets/snow-v1'
FRAME_COUNT = 8
COLS = 4
BOSS_CROP = (65, 78, 355, 368)
STILLS = {
    'boss_snow_hammer': (384, BOSS_CROP),
    'snow_ice_cover': (256, (27, 10, 228, 211)),
    'projectile_snow_needle': (128, (16, 12, 124, 120)),
    'duel_fence_snow': (768, None),
}
MOB_CROPS = {
    'scout': (38, 42, 222, 226),
    'keg': (32, 44, 216, 228),
    'guard': (25, 28, 229, 232),
    'needle': (39, 27, 231, 219),
    'roller': (22, 25, 222, 225),
    'elite': (23, 20, 231, 228),
}
POSED_MOBS = ('guard', 'needle', 'roller', 'elite')
MOBS = {f'enemy_snow_{name}{suffix}': crop for name, crop in MOB_CROPS.items()
        for suffix in (('', '_pose') if name in POSED_MOBS else ('',))}
SHEETS = {
    'boss_snow_hammer_swing': (384, BOSS_CROP),
    'vfx_snow_ice_spikes': (256, (8, 14, 248, 254)),
    'vfx_snow_avalanche': (256, None),
    'vfx_snow_ice_shatter': (256, (23, 21, 233, 231)),
}


def floor_texture(n=768):
    """Periodic spectral noise with soft hoarfrost islands, short striae and fine powder."""
    rng = np.random.default_rng(8490)
    f = np.fft.fftfreq(n)*n
    fx, fy = np.meshgrid(f, f)
    theta = math.radians(34)
    ux = fx * math.cos(theta) - fy * math.sin(theta)
    vy = fy * math.cos(theta) + fx * math.sin(theta)

    def noise(sx, sy):
        signal = np.fft.fft2(rng.standard_normal((n, n)))
        filtered = np.fft.ifft2(signal * np.exp(-(ux/sx)**2-(vy/sy)**2)).real
        return (filtered-filtered.mean())/filtered.std()

    same = noise(6, 7)
    ripple = noise(9, 21)
    patches = .5 + .5*np.tanh(1.1*(same+.25*noise(32, 24)))
    scratches = np.clip(noise(17, 52), .8, 2.2)-.8
    light = (patches-.5)*14 + 2.2*ripple + 1.9*noise(48, 53) + 1.25*noise(239, 240) + 1.6*scratches
    powder = np.clip(noise(178, 184), 1.55, 3.35) - 1.55
    channels = [103 + 1.01*light + .95*powder + .95*patches,
                149 + .89*light + .95*powder + 1.45*patches,
                174 + .78*light + .90*powder + 1.60*patches]
    return Image.fromarray(np.round(np.clip(np.stack(channels, axis=2), 0, 255)).astype(np.uint8))


def render_cell(source, side, crop):
    with Image.open(source) as im:
        frame = im.convert('RGBA')
    if crop:
        frame = frame.crop(crop)
    return frame.resize((side, side), Image.Resampling.LANCZOS)


def save(image, name, quality=86):
    path = OUTPUT / (name+'.webp')
    image.save(path, quality=quality, alpha_quality=97, method=6)
    print(f'{path.relative_to(ROOT)}: {image.width}x{image.height}; {path.stat().st_size:,} B')


def export(directory):
    OUTPUT.mkdir(parents=True, exist_ok=True)
    save(floor_texture(), 'background_battlefield_snow', 87)
    for name, (side, crop) in STILLS.items():
        save(render_cell(directory / (name+'.png'), side, crop), name)
    export_mobs(directory)
    for name, (side, crop) in SHEETS.items():
        atlas = Image.new('RGBA', (side*COLS, side*math.ceil(FRAME_COUNT/COLS)))
        for i in range(FRAME_COUNT):
            frame = render_cell(directory / f'{name}-{i:02}.png', side, crop)
            atlas.paste(frame, (i % COLS*side, i//COLS*side))
        save(atlas, name, 85)


def export_mobs(directory):
    for name, crop in MOBS.items():
        size = 160 if name.endswith('_pose') else 192
        save(render_cell(directory / (name+'.png'), size, crop), name, 81)


def validate():
    with Image.open(OUTPUT / 'background_battlefield_snow.webp') as floor:
        assert floor.mode == 'RGB' and floor.size == (768, 768)
        data = np.asarray(floor).astype(np.float32)
        assert np.abs(data[0] - data[-1]).mean() < 6
        assert np.abs(data[:,0] - data[:,-1]).mean() < 6
        assert .0 < data[:, :, 0].std() < 14
    for name,(side,_) in STILLS.items():
        with Image.open(OUTPUT / (name+'.webp')) as image:
            assert image.size == (side, side) and image.mode == 'RGBA', name
            assert image.getchannel('A').getextrema() == (0,255), name
    for name in MOBS:
        with Image.open(OUTPUT / (name+'.webp')) as image:
            side = 160 if name.endswith('_pose') else 192
            assert image.size == (side, side) and image.mode == 'RGBA', name
            alpha = image.getchannel('A')
            box = alpha.point(lambda a: 255 if a >= 128 else 0).getbbox()
            assert box and box[0] > 1 and box[1] > 1 and box[2] < side-1 and box[3] < side-1, name
            assert (box[3] - box[1]) >= .73 * side and alpha.getextrema() == (0, 255), name
    for name,(side,_) in SHEETS.items():
        with Image.open(OUTPUT / (name+'.webp')) as image:
            assert image.size == (side*COLS, side*2) and image.mode == 'RGBA', name
            hashes = set()
            for i in range(FRAME_COUNT):
                x,y = i%COLS*side,i//COLS*side
                alpha = image.getchannel('A').crop((x,y,x+side,y+side))
                assert alpha.getextrema() == (0,255), (name, i)
                assert alpha.getbbox(), (name, i)
                hashes.add(hashlib.sha256(alpha.tobytes()).hexdigest())
            assert len(hashes) == FRAME_COUNT, name
    print(f'Validated one opaque repeating floor, {len(STILLS) + len(MOBS)} transparent sprites, '
          f'and {len(SHEETS)} atlases of {FRAME_COUNT} distinct transparent frames.')


if __name__ == '__main__':
    if sys.argv[1] == '--mobs':
        export_mobs(Path(sys.argv[2]))
    elif sys.argv[1] != '--verify':
        export(Path(sys.argv[1]))
    validate()
