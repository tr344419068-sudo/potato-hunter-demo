import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import { createCanvas, loadImage } from '@napi-rs/canvas';
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const roles = ['scout', 'keg', 'guard', 'needle', 'roller', 'elite'];
const posed = ['guard', 'needle', 'roller', 'elite'];
const assetData = JSON.parse(await readFile(new URL('../src/configs/assets.json', import.meta.url)));

test('the snow roster uses one transparent Shengong set in combat, poses and bestiary', async () => {
  const { outputFiles } = await build({
    stdin: { resolveDir: root, contents: `export { SNOW_BESTIARY_ENTRIES } from './src/ui/BestiaryModel'` },
    bundle: true, platform: 'node', format: 'esm', write: false,
  });
  const { SNOW_BESTIARY_ENTRIES } = await import(`data:text/javascript;base64,${Buffer.from(outputFiles[0].text).toString('base64')}`);
  for (const role of roles) {
    const base = assetData[`enemy_snow_${role}`];
    const portrait = SNOW_BESTIARY_ENTRIES.find(entry => entry.id === `snow_${role}`);
    assert.ok(portrait.imagePath.endsWith(base.path), `${role} bestiary and combat must share an asset`);
    for (const suffix of posed.includes(role) ? ['', '_pose'] : ['']) {
      const id = `enemy_snow_${role}${suffix}`;
      const { path, width, height, footPoint } = assetData[id];
      assert.equal(path, `assets/enemies/snow-shengong-v1/${id}.webp`);
      const image = await loadImage(await readFile(new URL(`../public/${path}`, import.meta.url)));
      assert.deepEqual([image.width, image.height], [width, height], id);
      const ctx = createCanvas(width, height).getContext('2d');
      ctx.drawImage(image, 0, 0);
      const { data } = ctx.getImageData(0, 0, width, height);
      let top = height, bottom = -1;
      for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
        const alpha = data[(y * width + x) * 4 + 3];
        if (x === 0 || y === 0 || x === width - 1 || y === height - 1) assert.equal(alpha, 0, `${id} edge`);
        if (alpha >= 128) { top = Math.min(top, y); bottom = Math.max(bottom, y); }
      }
      assert.ok((bottom - top + 1) / height >= .68, `${id} should fill the tile at mobile size`);
      assert.ok(Math.abs(bottom / height - footPoint.y) <= .08, `${id} should meet the ground anchor`);
    }
  }
});
