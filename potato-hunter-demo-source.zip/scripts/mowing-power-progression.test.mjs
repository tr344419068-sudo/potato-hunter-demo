import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { createCanvas, loadImage } from "@napi-rs/canvas";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
export { SkillManager } from "./src/managers/SkillManager.ts";
export { ConfigManager } from "./src/managers/ConfigManager.ts";
export { AuraSystem } from "./src/systems/AuraSystem.ts";
export { MonsterAISystem } from "./src/systems/MonsterAISystem.ts";
export { KnockbackSystem } from "./src/systems/KnockbackSystem.ts";
export { StatusEffectSystem } from "./src/systems/StatusEffectSystem.ts";
export { DeathSystem } from "./src/systems/DeathSystem.ts";
export { createFinalBossHealth } from "./src/systems/FinalBossPatternModel.ts";
export { AutoAttackSystem } from "./src/systems/AutoAttackSystem.ts";
export { MovementSystem } from "./src/systems/MovementSystem.ts";
export { ProjectileCollisionSystem } from "./src/systems/ProjectileCollisionSystem.ts";
export { SpatialSkillSystem, getSpatialSkillVisuals } from "./src/systems/SpatialSkillSystem.ts";
export * from "./src/systems/SpatialSkillView.ts";
export { World } from "./src/entities/World.ts";
export { EventBus } from "./src/managers/EventBus.ts";
export { createPlayer, createMonster, createProjectile } from "./src/entities/factories.ts";
export { getNextExperienceRequirement } from "./src/managers/PacingModel.ts";
export { getTempoSpeedBonus } from "./src/systems/AttackTempoModel.ts";
export { getPalmProfile } from "./src/systems/PalmStrikeSystem.ts";
export { getSkillUpgradeBenefit } from "./src/ui/UIModel.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
plugins: [{ name: "mowing-headless", setup(context) {
  context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "mowing-headless" }));
  context.onLoad({ filter: /.*/, namespace: "mowing-headless" }, () => ({ contents: `import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Display: { Color: { HexStringToColor: v=>({color:parseInt(v.slice(1),16)}) } }, Utils: { Array: { Shuffle: v=>v } }, Math: { Clamp: (v,a,b)=>Math.min(b,Math.max(a,v)), Between: (a,b)=>a, FloatBetween: (a,b)=>a } };`, resolveDir: root }));
}}] }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

function raise(manager, id, rank) { for (let i = manager.getLevel(id); i < rank; i++) manager.levelUp(id); }

test('upgrade choices preview real combat upgrades and expose the recipe, without spending any ranks', async () => {
  const { SkillManager, ConfigManager } = await modules;
  const manager = new SkillManager({ starterSkillId: 'peeler_blade', enforceSlots: true });
  raise(manager, 'hot_oil_flask', 2); raise(manager, 'ketchup_aura', 2);
  const hints = ids => manager.getChoiceHints(ids.map(id => ConfigManager.getSkill(id)), 6);
  const [peeler, oil, aura, salt] = hints(['peeler_blade', 'hot_oil_flask', 'ketchup_aura', 'salt_spread']);
  const before = manager.getSpatialProfiles(6).find(profile => profile.skillId === 'hot_oil_flask');
  assert.match(peeler.upgradeBenefit, /单发伤害 \d+ → \d+/);
  assert.match(oil.upgradeBenefit, new RegExp(`每跳伤害 ${before.damage} → \\d+`));
  assert.match(aura.upgradeBenefit, /半径 \d+ → \d+/);
  assert.match(salt.recipeProgress, /配方.*(滚油火海|番茄酱潮汐).*2\/3/);
  assert.equal(manager.getLevel('hot_oil_flask'), 2);
  manager.levelUp('hot_oil_flask');
  assert.match(oil.upgradeBenefit, new RegExp(`→ ${manager.getSpatialProfiles(6).find(profile => profile.skillId === 'hot_oil_flask').damage}(?:\\D|$)`));
  manager.levelUp('ketchup_aura');
  manager.levelUp('salt_spread');
  const [evolution] = hints(['ketchup_surge']);
  assert.equal(evolution.replacesSkill, ConfigManager.getSkill('ketchup_aura').name);
});
async function fixture(id = "toxic_tomato", rank = 1, campaign = false) {
  const api = await modules; api.EventBus.removeAllListeners();
  const world = new api.World(); const playerId = api.createPlayer(world, 0, 0, 220, 100, 145);
  const skillManager = new api.SkillManager({ random: () => .37, ...(campaign && { starterSkillId: id, enforceSlots: true }) }); raise(skillManager, id, rank);
  const runtime = { world, playerId, skillManager, stats: { elapsedMs: 0, kills: 0, bossKills: 0, gold: 0 }, endRun() {} };
  const damage = []; api.EventBus.on("combat:damage", event => damage.push(event));
  const system = new api.AuraSystem();
  const spawn = (x, hp = 1000, behavior = "chaser") => {
    const entity = api.createMonster(world, api.ConfigManager.getMonster("fries_cultist"), x, 0);
    world.components.health.set(entity, { current: hp, max: hp });
    const monster = world.components.monsters.get(entity); monster.behavior = behavior;
    return entity;
  };
  return { ...api, world, playerId, skillManager, runtime, system, damage, spawn };
}

const newRecipes = [
  ["peeler_blade", "fork_splitter", "peeler_returning"],
  ["ketchup_aura", "salt_spread", "ketchup_surge"],
  ["corn_burst", "pepper_motor", "corn_crossfire"],
];

const rangedRecipes = [
  ["hot_oil_flask", "salt_spread", "wildfire_flask"],
  ["skewer_javelin", "pickle_crit", "thunder_skewer"],
];

test("the ranged routes add two independent active picks and use exact existing passives", async () => {
  const { SkillManager, ConfigManager } = await modules;
  for (const [active, passive, evolved] of rangedRecipes) {
    const manager = new SkillManager({ random: () => .37, enforceSlots: true });
    const config = ConfigManager.skills.find(skill => skill.id === active);
    assert.ok((config.spatial || config.weapon) && config.category === "active", `${active} should be a new active skill`);
    assert.ok(config.iconAssetId && config.choicePoolEnabled !== false);
    assert.ok(!config.aura);
    const profiles = () => [...manager.getSpatialProfiles(), ...manager.getWeaponProfiles()];
    raise(manager, active, 2); raise(manager, passive, 1);
    assert.ok(!manager.getChoices(3).some(s => s.id === evolved));
    raise(manager, active, 3);
    assert.equal(manager.getChoices(3)[0].id, evolved);
    assert.ok(profiles().some(p => p.skillId === active));
    manager.levelUp(evolved);
    assert.ok(profiles().some(p => p.skillId === evolved));
    assert.ok(!profiles().some(p => p.skillId === active));
    assert.equal(manager.getKnownSkills().some(s => s.id === active), false);
  }
});

test("the two ranged families use distinct compact transparent PNGs for both card tiers", async () => {
  const { ConfigManager } = await modules;
  const icons = rangedRecipes.map(([active, , evolved]) => {
    const icon = ConfigManager.getSkill(active).iconAssetId;
    assert.equal(ConfigManager.getSkill(evolved).iconAssetId, icon);
    return icon;
  });
  assert.equal(new Set(icons).size, 2);
  const paths = new Set();
  for (const icon of icons) {
    const { path, width, height } = ConfigManager.assets[icon];
    assert.match(path, /\.png$/);
    paths.add(path);
    const image = await loadImage(`${root}public/${path}`);
    assert.deepEqual([image.width, image.height], [width, height]);
    assert.ok(width <= 256 && height <= 256);
    const ctx = createCanvas(width, height).getContext("2d");
    ctx.drawImage(image, 0, 0);
    const { data } = ctx.getImageData(0, 0, width, height);
    let clear = 0, opaque = 0;
    for (let i = 3; i < data.length; i += 4) {
      clear += Number(data[i] === 0);
      opaque += Number(data[i] >= 248);
    }
    assert.ok(clear >= width * height * .18 && opaque >= width * height * .16, "PNG has clear space and a solid subject");
  }
  assert.equal(paths.size, 2);
});

test("guidance rotates between competing invested recipes instead of starving one route", async () => {
  const { SkillManager } = await modules;
  const m = new SkillManager({ starterSkillId: "peeler_blade", enforceSlots: true, random: () => .37 });
  raise(m, "peeler_blade", 2); raise(m, "hot_oil_flask", 1);
  const first = m.getChoices(3)[0].id;
  const second = m.getChoices(3)[0].id;
  assert.deepEqual(new Set([first, second]), new Set(["fork_splitter", "hot_oil_flask"]));
});

test("the first four earned offers can reveal both new play styles without forcing a pick", async () => {
  const { SkillManager } = await modules;
  const m = new SkillManager({ starterSkillId: "peeler_blade", enforceSlots: true, random: () => .37 });
  const shown = new Set();
  for (let i = 0; i < 4; i++) {
    const offer = m.getChoices(3);
    assert.equal(offer.length, 3);
    assert.ok(offer.some(c => !c.spatial));
    for (const card of offer) {
      assert.ok(!["starch_spikes", "roast_turret", "starch_runway", "roast_bastion"].includes(card.id));
      if (["hot_oil_flask", "skewer_javelin"].includes(card.id)) shown.add(card.id);
    }
  }
  assert.deepEqual(shown, new Set(["hot_oil_flask", "skewer_javelin"]));
});

test('oil locks a forward ground point before impact, ticks there only, and expires', async () => {
  const f = await fixture('hot_oil_flask');
  const ahead = f.spawn(315), behind = f.spawn(-70);
  f.world.components.velocities.get(f.playerId).x = 200;
  const system = new f.SpatialSkillSystem();
  const impact = []; f.EventBus.on('oil:impact', e => impact.push(e));
  system.update(16, f.runtime);
  assert.equal(f.world.components.health.get(ahead).current, 1000);
  f.world.components.transforms.get(f.playerId).y = 185;
  system.update(450, f.runtime);
  const first = f.world.components.health.get(ahead).current;
  assert.ok(first < 1000);
  assert.equal(f.world.components.health.get(behind).current, 1000);
  assert.deepEqual(impact.map(p => [p.x, p.y]), [[315, 0]]);
  system.update(500, f.runtime);
  assert.ok(f.world.components.health.get(ahead).current < first);
  f.world.components.monsters.delete(behind);
  f.world.components.velocities.get(f.playerId).x = -200;
  system.update(3400, f.runtime);
  const last = f.world.components.health.get(ahead).current;
  system.update(600, f.runtime);
  assert.equal(f.world.components.health.get(ahead).current, last);
  assert.equal(impact.length, 1);
});

test('skewer aims through intervening monsters at a distant boss and can pierce both', async () => {
  const f = await fixture('skewer_javelin');
  const boss = f.spawn(710), near = f.spawn(145), offAxis = f.spawn(48);
  f.world.components.transforms.get(offAxis).y = 100;
  f.world.components.monsters.get(boss).isBoss = true;
  const attack = new f.AutoAttackSystem(), movement = new f.MovementSystem(), collision = new f.ProjectileCollisionSystem();
  attack.update(16, f.runtime);
  const projectile = [...f.world.components.projectiles].find(([, p]) => p.skillId === 'skewer_javelin');
  assert.ok(projectile);
  for (const [id, p] of f.world.components.projectiles) if (p !== projectile[1]) f.world.destroyEntity(id);
  const contacts = []; f.EventBus.on('weapon:impact', event => contacts.push(event.x));
  movement.update(920, f.runtime); collision.update(920, f.runtime);
  assert.ok(f.world.components.health.get(near).current < 1000);
  assert.ok(f.world.components.health.get(boss).current < 1000);
  assert.equal(f.world.components.health.get(offAxis).current, 1000);
  assert.equal(contacts.length, 2);
  assert.ok(contacts[0] < contacts[1]);
});

test('one complete oil field deals the same damage at 25 ms and 40 ms step sizes', async () => {
  const totals = [];
  for (const step of [25, 40]) {
    const f = await fixture('hot_oil_flask', 2);
    const id = f.spawn(315), spatial = new f.SpatialSkillSystem();
    f.world.components.velocities.get(f.playerId).x = 200;
    for (let elapsed = 0; elapsed < 4000; elapsed += step) spatial.update(step, f.runtime);
    totals.push(1000 - f.world.components.health.get(id).current);
  }
  assert.ok(totals[0] > 40);
  assert.equal(totals[0], totals[1]);
});

test('skewer hits a moving monster crossing between sampled poses', async () => {
  const f = await fixture();
  const id = f.spawn(16);
  Object.assign(f.world.components.transforms.get(id), { y: -40, radius: 5 });
  Object.assign(f.world.components.velocities.get(id), { x: 0, y: 2000 });
  f.createProjectile(f.world, 0, 0, 825, 0, 'skewer_javelin', 39, 6, 1090);
  new f.MovementSystem().update(40, f.runtime);
  new f.ProjectileCollisionSystem().update(40, f.runtime);
  assert.equal(f.world.components.health.get(id).current, 961);
});

test('phase gates suppress fake damage numbers for the skewer and oil', async () => {
  const f = await fixture('hot_oil_flask');
  const boss = f.spawn(315);
  const encounter = {phase: 2, completedCasts: 0, transitioning: true};
  const monster = f.world.components.monsters.get(boss); monster.isBoss = true; monster.finalBossEncounter = encounter;
  const hp = f.createFinalBossHealth(1000, encounter, 'meadow'); hp.current = 600;
  f.world.components.health.set(boss, hp);
  f.createProjectile(f.world, 315, 0, 0, 0, 'skewer_javelin', 39, 6, 1090);
  new f.ProjectileCollisionSystem().update(16, f.runtime);
  const oil = new f.SpatialSkillSystem(); oil.update(16, f.runtime); oil.update(420, f.runtime);
  assert.equal(hp.current, 600);
  assert.ok(!f.damage.some(event => event.targetId === boss));
});

async function spatialFixture(active, rank = 1) {
  const f = await fixture();
  raise(f.skillManager, active, rank);
  const spatial = new f.SpatialSkillSystem();
  const hero = f.world.components.transforms.get(f.playerId);
  const step = (ms, x = hero.x, y = hero.y) => { Object.assign(hero, { x, y }); spatial.update(ms, f.runtime); };
  const view = () => f.getSpatialSkillVisuals(f.world);
  const hp = id => f.world.components.health.get(id).current;
  return { ...f, step, view, hp, spatial };
}

test("battlefield art stays at deployed positions and reuses hidden sprites after expiry", async () => {
  const f = await spatialFixture("starch_spikes");
  raise(f.skillManager, "roast_turret", 1);
  const sprites = [];
  const scene = { textures: { exists: () => true }, add: { image(x, y, texture) {
    const image = { x, y, texture };
    for (const [method, ...fields] of [["setPosition", "x", "y"], ["setVisible", "visible"], ["setAlpha", "alpha"],
      ["setOrigin", "originX", "originY"], ["setDisplaySize", "width", "height"], ["setDepth", "depth"], ["setFlipX", "flipX"]]) {
      image[method] = (...values) => { fields.forEach((field, i) => { image[field] = values[i]; }); return image; };
    }
    sprites.push(image); return image;
  } } };
  const graphics = new Proxy({}, { get: () => () => graphics });
  assert.equal(typeof f.SpatialSkillView, "function", "battlefield has a reusable raster art view");
  const view = new f.SpatialSkillView(scene);
  f.spawn(-170);
  f.step(0); f.step(500, 132);
  view.draw(graphics, f.world);
  const spikes = sprites.filter(s => s.texture === "asset:icon_skill_starch_spikes");
  const turret = sprites.find(s => s.texture === "asset:icon_skill_roast_turret");
  assert.deepEqual(spikes.map(s => s.x), [44, 88, 132]);
  assert.ok(turret?.visible && turret.x === 0 && turret.flipX);
  assert.ok(sprites.every(s => s.visible && s.depth < 2 && s.originY > .75));
  f.step(4800);
  view.draw(graphics, f.world);
  assert.ok(sprites.every(s => !s.visible));
  f.step(120, 220);
  view.draw(graphics, f.world);
  assert.equal(sprites.length, 4, "reuses previously deployed sprite slots");
  assert.deepEqual(spikes.filter(s => s.visible).map(s => s.x), f.view().trail.map(s => s.x));
});

test("running leaves a bounded set of spikes at fixed positions; idle does not", async () => {
  const f = await spatialFixture("starch_spikes");
  f.step(0); f.step(1000);
  assert.equal(f.view().trail.length, 0);
  f.step(500, 132);
  assert.deepEqual(f.view().trail.map(p => p.x), [44, 88, 132]);
  const target = f.spawn(44);
  f.step(330);
  assert.ok(f.hp(target) < 1000);
  assert.deepEqual(f.view().trail.map(p => p.x), [88, 132], "contact consumes the old trap in place");
  f.step(300, 400);
  f.step(300, 650);
  assert.ok(f.view().trail.length <= 11);
  f.step(4000);
  assert.equal(f.view().trail.length, 0);
});

test("an evolved trail connects the gap between spikes and limits repeat damage to each target", async () => {
  const f = await spatialFixture("starch_spikes", 3);
  raise(f.skillManager, "starch_boots", 1); raise(f.skillManager, "starch_runway", 1);
  const target = f.spawn(66), boss = f.spawn(70);
  Object.assign(f.world.components.transforms.get(target), { y: 18, radius: 0 });
  f.world.components.monsters.get(boss).isBoss = true;
  f.step(0); f.step(330, 88); f.step(300);
  const damage = 1000 - f.hp(target);
  assert.ok(damage > 0, "the contact is on the strip, outside both individual spikes");
  assert.ok(f.world.components.statuses.get(target)?.some(s => s.slowMultiplier < 1));
  assert.equal(f.world.components.statuses.has(boss), false);
  f.step(470);
  assert.equal(f.hp(target), 1000 - damage);
  f.step(144);
  assert.equal(f.hp(target), 1000 - damage * 2);
});

test("one turret stays at its deployment point, respects its firing radius, and expires", async () => {
  const f = await spatialFixture("roast_turret");
  const front = f.spawn(168), far = f.spawn(950);
  f.step(0); f.step(260, 930);
  assert.equal(f.view().turret?.x, 0);
  assert.ok(f.hp(front) < 1000, "shots originate at the emplacement, not the hero");
  assert.equal(f.hp(far), 1000);
  f.step(4600);
  assert.equal(f.view().turret, undefined);
  f.step(3000);
  assert.equal(f.view().turret?.x, 930);
});

test("only the evolved turret splashes nearby enemies on a critical shot", async () => {
  const f = await spatialFixture("roast_turret", 3);
  raise(f.skillManager, "pickle_crit", 1);
  const target = f.spawn(150), neighbor = f.spawn(180), far = f.spawn(248);
  f.runtime.random = () => 0;
  f.step(0); f.step(250);
  assert.ok(f.hp(target) < 1000);
  assert.equal(f.hp(neighbor), 1000);
  raise(f.skillManager, "roast_bastion", 1);
  f.step(0); f.step(250);
  assert.ok(f.hp(neighbor) < 1000);
  assert.equal(f.hp(far), 1000);
  assert.equal(f.view().turret?.evolved, true);
});

test("the three unpaired active skills offer a real evolution with their exact companion", async () => {
  const { SkillManager, ConfigManager, getSkillUpgradeBenefit } = await modules;
  for (const [active, passive, result] of newRecipes) {
    const m = new SkillManager({ starterSkillId: active, random: () => .37, enforceSlots: true });
    raise(m, active, 2);
    assert.ok(m.getChoices(3).some(s => s.id === passive || s.id === active), `${active} should be possible to pursue`);
    const hint = m.getChoiceHints([ConfigManager.getSkill(active)])[0];
    assert.match(hint.evolutionHint, new RegExp(ConfigManager.getSkill(result).name));
    raise(m, active, 3);
    assert.ok(!m.getChoices(3).some(s => s.id === result));
    assert.ok(m.getChoices(3).some(s => s.id === passive), "the missing companion should be offered");
    raise(m, passive, 1);
    assert.equal(m.getChoices(3)[0].id, result);
    assert.match(getSkillUpgradeBenefit(ConfigManager.getSkill(result), 0), /折返|扫开|三向/, "the card foregrounds the new play pattern");
    m.levelUp(result);
    const profiles = [...m.getWeaponProfiles(), ...m.getAuraProfiles()];
    assert.ok(profiles.some(p => p.skillId === result));
    assert.ok(!profiles.some(p => p.skillId === active));
    assert.equal(ConfigManager.getSkill(active).maxLevel, 12);
  }
});

test("returning peeler deals damage on both legs, follows the moving player and is reclaimed", async () => {
  const f = await fixture("peeler_blade", 3, true);
  raise(f.skillManager, "fork_splitter", 1); raise(f.skillManager, "peeler_returning", 1);
  const target = f.spawn(65, 10000);
  new f.AutoAttackSystem().update(16, f.runtime);
  const entry = [...f.world.components.projectiles].find(([, p]) => p.skillId === "peeler_returning");
  assert.ok(entry, "the new evolution should fire");
  const [id, shot] = entry;
  const bladeCount = f.world.components.projectiles.size;
  const movement = new f.MovementSystem(), collisions = new f.ProjectileCollisionSystem();
  const hero = f.world.components.transforms.get(f.playerId);
  for (let time = 0; time < 850 && f.world.components.projectiles.has(id); time += 16) {
    if (time >= 290) { hero.x += .5; hero.y = 14; }
    movement.update(16, f.runtime); collisions.update(16, f.runtime);
  }
  assert.equal(f.world.components.health.get(target).current, 10000 - bladeCount * 2 * shot.damage);
  assert.equal(f.world.components.projectiles.has(id), false);
});

test("returning peeler resolves its apex before granting a new hit allowance", async () => {
  const f = await fixture();
  const hit = f.spawn(169), atApex = f.spawn(201);
  f.createProjectile(f.world, 160, 0, 600, 0, "peeler_returning", 20, 4, 1100,
    undefined, undefined, [], 0, 1.6, undefined, undefined, undefined, 40);
  const movement = new f.MovementSystem(), collisions = new f.ProjectileCollisionSystem();
  const step = ms => { movement.update(ms, f.runtime); collisions.update(ms, f.runtime); };
  const hp = id => f.world.components.health.get(id).current;
  step(16);
  assert.equal(hp(hit), 980);
  assert.equal(hp(atApex), 1000);
  step(40);
  assert.equal(hp(hit), 980, "the outgoing pass cannot hit twice at the bend");
  assert.equal(hp(atApex), 980, "the endpoint is checked before the blade leaves it");
  step(16);
  assert.equal(hp(hit), 960, "the blade can hit again after return travel");
});

test("ketchup surge hits outward as it grows, once per target per pulse", async () => {
  const f = await fixture("ketchup_aura", 3, true);
  raise(f.skillManager, "salt_spread", 1); raise(f.skillManager, "ketchup_surge", 1);
  const aura = f.skillManager.getAuraProfiles().find(p => p.skillId === "ketchup_surge");
  assert.ok(aura, "the evolved aura should exist");
  const inner = f.spawn(aura.radius * .2), outer = f.spawn(aura.radius * .88), outside = f.spawn(aura.radius + 5);
  const hp = id => f.world.components.health.get(id).current;
  for (let t = 16; t <= 192; t += 16) { f.runtime.stats.elapsedMs = t; f.system.update(16, f.runtime); }
  assert.ok(hp(inner) < 1000);
  assert.equal(hp(outer), 1000);
  const firstHp = hp(inner);
  for (let t = 208; t <= 624; t += 16) { f.runtime.stats.elapsedMs = t; f.system.update(16, f.runtime); }
  assert.equal(hp(inner), firstHp);
  assert.ok(hp(outer) < 1000 && f.world.components.knockbacks.has(outer));
  assert.equal(hp(outside), 1000);
  f.runtime.stats.elapsedMs = aura.tickMs + 192; f.system.update(aura.tickMs + 192 - 624, f.runtime);
  assert.ok(hp(inner) < firstHp);
});

test("ketchup cooldown upgrades do not restart an active sweep", async () => {
  const f = await fixture("ketchup_aura", 3, true);
  raise(f.skillManager, "salt_spread", 1); raise(f.skillManager, "ketchup_surge", 1);
  const aura = f.skillManager.getAuraProfiles().find(p => p.skillId === "ketchup_surge");
  const target = f.spawn(8);
  const hp = () => f.world.components.health.get(target).current;
  f.runtime.stats.elapsedMs = 60000;
  f.system.update(0, f.runtime);
  assert.ok(hp() < 1000);
  const firstHp = hp();
  raise(f.skillManager, "butter_lube", 1);
  f.runtime.stats.elapsedMs += 16; f.system.update(16, f.runtime);
  assert.equal(hp(), firstHp);
  f.system.update(aura.tickMs - 17, f.runtime);
  assert.equal(hp(), firstHp, "the previous period is still in force");
  f.system.update(1, f.runtime);
  assert.ok(hp() < firstHp, "the next sweep can hit again");
});

test("evolved corn splits each of three launches into a visible projectile fan", async () => {
  const f = await fixture("corn_burst", 3, true);
  raise(f.skillManager, "pepper_motor", 1); raise(f.skillManager, "corn_crossfire", 1);
  f.spawn(180, 10000);
  const system = new f.AutoAttackSystem();
  system.update(16, f.runtime);
  const shots = () => [...f.world.components.projectiles].filter(([, p]) => p.skillId === "corn_crossfire");
  assert.equal(shots().length, 3);
  assert.ok(shots().every(([id]) => f.world.components.renders.get(id).assetId === "projectile_corn_kernel"));
  const ys = shots().map(([id]) => f.world.components.velocities.get(id).y);
  assert.ok(ys[0] < -25 && Math.abs(ys[1]) < .01 && ys[2] > 25);
  system.update(90, f.runtime); system.update(90, f.runtime);
  assert.equal(shots().length, 9);
  system.update(90, f.runtime);
  assert.equal(shots().length, 9);
});

test("overlapping auras keep a modest combo without triggering once for every monster in a dense pack", async () => {
  async function simulate(count) {
    const f = await fixture(); raise(f.skillManager, "ketchup_aura", 1);
    const ids = Array.from({length: count}, (_, i) => f.spawn(100 + i, 10000));
    const status = new f.StatusEffectSystem(); let reactions = 0;
    f.EventBus.on("combat:reaction", () => reactions++);
    for (let elapsed = 0; elapsed < 5000; elapsed += 20) { f.system.update(20, f.runtime); status.update(20, f.runtime); }
    return {reactions, damage: ids.reduce((sum, id) => sum + 10000 - f.world.components.health.get(id).current, 0) / count};
  }
  const single = await simulate(1), crowd = await simulate(8);
  assert.ok(single.reactions >= 4 && single.reactions <= 6, `single reactions: ${single.reactions}`);
  assert.ok(crowd.reactions >= 4 && crowd.reactions <= 6, `crowd reactions: ${crowd.reactions}`);
  assert.ok(crowd.damage < single.damage * 1.2, `cluster damage ${crowd.damage} vs ${single.damage}`);
});

test("initial poison and ketchup reach enemies at 180/190 radii without an opening one-shot", async () => {
  for (const [id, radius, status] of [["toxic_tomato", 180, "poison"], ["ketchup_aura", 190, "burn"]]) {
    const f = await fixture(id); const profile = f.skillManager.getAuraProfiles()[0];
    assert.equal(profile.radius, radius);
    const inside = f.spawn(radius - 1, 24), outside = f.spawn(radius + 1, 24);
    f.system.update(16, f.runtime);
    assert.ok(f.world.components.health.get(inside).current >= 16);
    assert.ok(f.world.components.health.get(inside).current < 24);
    assert.ok(f.world.components.statuses.get(inside).some(effect => effect.type === status));
    assert.equal(f.world.components.knockbacks.has(inside), id === "ketchup_aura");
    assert.equal(f.world.components.health.get(outside).current, 24);
  }
});

test("ordinary fries advance through overlapping auras before attrition earns XP", async () => {
  const f = await fixture(); raise(f.skillManager, "ketchup_aura", 1);
  const launchPoints = [135, 149, 163, 177];
  const ids = launchPoints.map(x => f.createMonster(f.world, f.ConfigManager.getMonster("fries_cultist"), x, 0));
  const ai = new f.MonsterAISystem(), movement = new f.MovementSystem(), knockback = new f.KnockbackSystem();
  const status = new f.StatusEffectSystem(), death = new f.DeathSystem();
  const advance = ms => {
    for (let elapsed = 0; elapsed < ms; elapsed += 20) {
      ai.update(20, f.runtime); f.system.update(20, f.runtime); status.update(20, f.runtime);
      movement.update(20, f.runtime); knockback.update(20, f.runtime); death.update(20, f.runtime);
    }
  };
  advance(500);
  assert.equal(f.runtime.stats.kills, 0);
  assert.ok(ids.every((id, i) => f.world.components.transforms.get(id)?.x < launchPoints[i] - 8));
  advance(3000);
  assert.equal(f.runtime.stats.kills, ids.length);
  assert.equal(f.world.components.experienceOrbs.size, ids.length);
});

test("newly evolved poison and ketchup control healthy slugs without a first-sweep wipe", async () => {
  const f = await fixture("toxic_tomato", 3, true);
  raise(f.skillManager, "ketchup_aura", 3); raise(f.skillManager, "salt_spread", 1);
  raise(f.skillManager, "toxic_burst_cloud", 1); raise(f.skillManager, "ketchup_surge", 1);
  const ids = [90, 106, 122, 138].map(x => f.createMonster(f.world, f.ConfigManager.getMonster("ketchup_slug"), x, 0));
  const status = new f.StatusEffectSystem(), death = new f.DeathSystem();
  for (let elapsed = 0; elapsed < 500; elapsed += 20) {
    f.system.update(20, f.runtime); status.update(20, f.runtime); death.update(20, f.runtime);
  }
  assert.ok(ids.every(id => f.world.components.health.get(id)?.current > 0));
  assert.ok(ids.every(id => f.world.components.knockbacks.has(id)), "tidal sweep should still repel threats");
  assert.ok(ids.every(id => f.world.components.statuses.get(id)?.some(effect => effect.type === "poison")));
});

test("entry hit respects guard shields and high-HP Bosses instead of type-based execution", async () => {
  const f = await fixture(); const guard = f.spawn(150, 58, "guard"), boss = f.spawn(155, 2000);
  const {entryDamage, damagePerSecond, tickMs} = f.skillManager.getAuraProfiles()[0];
  const firstHit = entryDamage + damagePerSecond * tickMs / 1000;
  f.world.components.monsters.get(guard).shieldHp = 2; f.world.components.monsters.get(boss).isBoss = true;
  f.system.update(16, f.runtime);
  assert.equal(f.world.components.monsters.get(guard).shieldHp, 0);
  assert.ok(Math.abs(f.world.components.health.get(guard).current - (58 - firstHit + 2)) < 1e-9);
  assert.ok(f.world.components.health.get(boss).current > 1900);
  assert.equal(f.damage.find(event => event.targetId === guard && event.category === "shield").value, 2);
  assert.ok(Math.abs(f.damage.find(event => event.targetId === guard && event.category === "outgoing").value - (firstHit - 2)) < 1e-9);
});

test("late entrants hit immediately even when ordinary aura DOT timer has not expired", async () => {
  const f = await fixture(); f.system.update(16, f.runtime);
  const id = f.spawn(170); f.system.update(16, f.runtime);
  assert.equal(f.world.components.health.get(id).current, 1000 - f.skillManager.getAuraProfiles()[0].entryDamage);
  assert.equal(f.damage.length, 1); assert.equal(f.damage[0].isDot, false);
});

test("continuous residence, zero delta, and upgrading do not replay entry hits", async () => {
  const f = await fixture(); const id = f.spawn(170); f.system.update(16, f.runtime);
  f.system.update(0, f.runtime); raise(f.skillManager, "toxic_tomato", 2); f.system.update(16, f.runtime);
  assert.equal(f.damage.filter(event => event.targetId === id && !event.isDot).length, 1);
});

test("exit and reentry cannot exploit the 1.5s entry-hit cooldown", async () => {
  const f = await fixture(); const id = f.spawn(170); f.system.update(16, f.runtime);
  f.world.components.transforms.get(id).x = 300; f.system.update(16, f.runtime);
  f.world.components.transforms.get(id).x = 170; f.system.update(16, f.runtime);
  assert.equal(f.damage.filter(event => !event.isDot).length, 1);
  f.system.update(1600, f.runtime); assert.equal(f.damage.filter(event => !event.isDot).length, 1);
  f.world.components.transforms.get(id).x = 300; f.system.update(16, f.runtime);
  f.world.components.transforms.get(id).x = 170; f.system.update(16, f.runtime);
  assert.equal(f.damage.filter(event => !event.isDot).length, 2);
});

test("poison and ketchup have independent entry hits and no repeat on long frames", async () => {
  const f = await fixture(); raise(f.skillManager, "ketchup_aura", 1); f.spawn(170);
  f.system.update(16, f.runtime); assert.equal(f.damage.filter(event => !event.isDot && !event.isReaction).length, 2);
  f.damage.length = 0; f.system.update(5000, f.runtime);
  assert.ok(f.damage.filter(event => !event.isReaction).length <= 2);
  assert.ok(f.damage.filter(event => !event.isReaction).every(event => event.isDot));
});

test("dead player cannot deal aura damage", async () => {
  const f = await fixture(); const id = f.spawn(170); f.world.components.health.get(f.playerId).current = 0;
  f.system.update(16, f.runtime); assert.equal(f.world.components.health.get(id).current, 1000);
});

test("removed profiles and destroyed enemies release entry state", async () => {
  const f = await fixture(); const id = f.spawn(170); f.system.update(16, f.runtime);
  const profiles = f.skillManager.getAuraProfiles();
  f.runtime.skillManager = { getAuraProfiles: () => [] }; f.world.destroyEntity(id); f.system.update(16, f.runtime);
  f.runtime.skillManager = { getAuraProfiles: () => profiles }; const next = f.spawn(170); f.system.update(16, f.runtime);
  assert.ok(f.world.components.health.get(next).current < 1000 - profiles[0].entryDamage);
  assert.equal(f.system.entries.get("toxic_tomato").size, 1);
});

test("world or player replacement resets entry and tick state", async () => {
  const f = await fixture(); f.spawn(170); f.system.update(16, f.runtime);
  const next = await fixture(); const id = next.spawn(170); f.system.update(16, next.runtime);
  const {entryDamage} = next.skillManager.getAuraProfiles()[0];
  assert.ok(next.world.components.health.get(id).current < 1000 - entryDamage);
  const playerId = next.createPlayer(next.world, 0, 0, 220, 100, 145); next.runtime.playerId = playerId;
  const before = next.world.components.health.get(id).current; f.system.update(16, next.runtime);
  assert.ok(next.world.components.health.get(id).current < before - entryDamage);
});

test("all active, passive and evolution ranks have functional raised caps", async () => {
  const { ConfigManager, SkillManager } = await modules;
  for (const skill of ConfigManager.skills) {
    const expected = skill.category === "active" ? 12 : skill.category === "evolution" || skill.id === "combo_gear" ? 6 : 8;
    assert.equal(skill.maxLevel, expected, skill.id);
    const manager = new SkillManager({ random: () => .37 }); raise(manager, skill.id, expected + 2);
    assert.equal(manager.getLevel(skill.id), expected);
    assert.ok(manager.getChoices(100).every(choice => choice.id !== skill.id));
  }
});

test("owned evolutions continue appearing in choices until rank6 and hints indicate reinforcement", async () => {
  const f = await fixture("toxic_burst_cloud");
  const choices = f.skillManager.getChoices(100);
  assert.ok(choices.some(choice => choice.id === "toxic_burst_cloud")); assert.equal(new Set(choices.map(s => s.id)).size, choices.length);
  const hint = f.skillManager.getChoiceHints([f.ConfigManager.getSkill("toxic_burst_cloud")])[0];
  assert.match(hint.evolutionHint, /强化/); assert.doesNotMatch(hint.progressHints.join(""), /进化完成后/);
});

test("initial evolution is still locked without its recipe", async () => {
  const f = await fixture(); assert.ok(f.skillManager.getChoices(100).every(choice => choice.category !== "evolution"));
  raise(f.skillManager, "toxic_tomato", 3); raise(f.skillManager, "salt_spread", 1);
  assert.equal(f.skillManager.getChoices(3)[0].id, "toxic_burst_cloud");
});

test("aura growth is visible and shares a safe 520 radius cap at all raised ranks", async () => {
  for (const id of ["toxic_tomato", "ketchup_aura", "toxic_burst_cloud"]) for (const areaLevel of [0, 8]) {
    const f = await fixture(id); raise(f.skillManager, "salt_spread", areaLevel);
    const skill = f.ConfigManager.getSkill(id);
    let previous = 0;
    for (let level = 1; level <= skill.maxLevel; level++) {
      raise(f.skillManager, id, level); const profile = f.skillManager.getAuraProfiles()[0];
      assert.equal(profile.radius, Math.min(520, skill.aura.radius * f.skillManager.getCombatStats().areaMultiplier * (1 + .14 * (level - 1))));
      assert.ok(profile.radius >= previous); previous = profile.radius;
    }
  }
});

test("poison ranks4 and8 slow, ketchup ranks4 and8 knock back with visible card milestones", async () => {
  for (const [id, level, strength] of [["toxic_tomato", 4, .82], ["toxic_tomato", 8, .65], ["ketchup_aura", 4, 100], ["ketchup_aura", 8, 160]]) {
    const f = await fixture(id, level); const profile = f.skillManager.getAuraProfiles()[0]; const target = f.spawn(170);
    f.system.update(16, f.runtime);
    if (id === "toxic_tomato") assert.equal(f.world.components.statuses.get(target).find(s => s.type === "slow").slowMultiplier, strength);
    else { assert.equal(profile.entryKnockback, strength); assert.equal(f.world.components.knockbacks.get(target).x, strength); }
    assert.match(f.getSkillUpgradeBenefit(f.ConfigManager.getSkill(id), level - 1), id === "toxic_tomato" ? /减速/ : /击退|重击/);
  }
});

test("evolution cannot shrink or weaken an invested aura, weapon, or spatial skill", async () => {
  const { ConfigManager, SkillManager, getPalmProfile } = await modules;
  for (const recipe of ConfigManager.skillEvolutions) for (const rank of [3, 6, 12]) {
    const manager = new SkillManager({ enforceSlots: true, random: () => .37 });
    for (const needed of recipe.requiredSkills) raise(manager, needed.id, ConfigManager.getSkill(needed.id).category === "active" ? Math.max(rank, needed.level) : needed.level);
    const predecessor = recipe.requiredSkills.find(s => ConfigManager.getSkill(s.id).category === "active").id;
    if (predecessor === "potato_palm") {
      const stats = manager.getCombatStats(), baseRank = manager.getLevel(predecessor);
      const base = getPalmProfile(baseRank, false, 1, 1, stats.areaMultiplier, stats.cooldownMultiplier);
      manager.levelUp(recipe.resultSkillId);
      const upgraded = getPalmProfile(manager.getLevel(recipe.resultSkillId) + Math.max(0, baseRank - 2), true, 1, 1, stats.areaMultiplier, stats.cooldownMultiplier);
      assert.ok(upgraded.radius >= base.radius && upgraded.damage >= base.damage, `${recipe.id} rank ${rank}`);
      manager.levelUp(recipe.resultSkillId);
      const reinforced = getPalmProfile(manager.getLevel(recipe.resultSkillId) + Math.max(0, baseRank - 2), true, 1, 1, stats.areaMultiplier, stats.cooldownMultiplier);
      assert.ok(reinforced.damage > upgraded.damage);
      continue;
    }
    const profiles = () => [...manager.getAuraProfiles(), ...manager.getWeaponProfiles(), ...manager.getSpatialProfiles()];
    const old = profiles().find(p => p.skillId === predecessor);
    manager.levelUp(recipe.resultSkillId);
    const evolved = profiles().find(p => p.skillId === recipe.resultSkillId);
    assert.ok(old && evolved, `${recipe.id} needs a recognized runtime profile`);
    if ("damagePerSecond" in old) { assert.ok(evolved.radius >= old.radius, `${recipe.id} radius at ${rank}`); assert.ok(evolved.damagePerSecond >= old.damagePerSecond); assert.ok(evolved.entryDamage >= old.entryDamage); }
    else assert.ok(evolved.damage >= old.damage, `${recipe.id} damage at ${rank}`);
    if ("kind" in old) {
      assert.ok(evolved.radius >= old.radius, `${recipe.id} reach at ${rank}`);
      assert.ok(evolved.lifeMs >= old.lifeMs, `${recipe.id} uptime at ${rank}`);
      if (old.kind === "turret") assert.ok(evolved.critChance > old.critChance, "the evolved turret should show its splash even with one point in crit");
    }
    const firstDamage = evolved.damage ?? evolved.damagePerSecond; manager.levelUp(recipe.resultSkillId);
    const reinforced = profiles().find(p => p.skillId === recipe.resultSkillId);
    assert.ok((reinforced.damage ?? reinforced.damagePerSecond) > firstDamage);
  }
});

test("opening single-hit weapons kill 24HP trash while pepper and corn retain rapid multi-hit identity", async () => {
  const { SkillManager } = await modules;
  for (const id of ["peeler_blade", "fire_potato", "frost_chips", "thunder_potato"]) {
    const manager = new SkillManager({ starterSkillId: id }); assert.ok(manager.getWeaponProfiles()[0].damage >= 24, id);
  }
  for (const id of ["pepper_gatling", "corn_burst"]) { const manager = new SkillManager({ starterSkillId: id }); assert.ok(manager.getWeaponProfiles()[0].damage < 24); }
});

test("combo gear levels4 to6 genuinely add tempo speed", async () => {
  const { getTempoSpeedBonus } = await modules; const player = { tempo: { stacks: 8 } };
  assert.equal(getTempoSpeedBonus(player, 3), .24); assert.equal(getTempoSpeedBonus(player, 6), .48);
});

test("high-rank weapons add piercing or a fourth burst round rather than only damage", async () => {
  for (const [id, rank, field, minimum] of [["peeler_blade", 8, "pierce", 2], ["pepper_gatling", 8, "pierce", 1], ["corn_burst", 6, "burstCount", 4]]) {
    const f = await fixture(id, rank); const profile = f.skillManager.getWeaponProfiles().find(p => p.skillId === id);
    assert.ok(profile[field] >= minimum, id);
    assert.match(f.getSkillUpgradeBenefit(f.ConfigManager.getSkill(id), rank - 1), /穿透|四连/);
  }
});

test("XP preserves opening costs and has no exponential wall in long-term leveling", async () => {
  const { getNextExperienceRequirement } = await modules; let cost = 12; const costs = [];
  for (let level = 2; level <= 100; level++) {
    const next = getNextExperienceRequirement(cost, level); assert.ok(next > cost); assert.ok(Number.isFinite(next));
    if (level >= 13) assert.ok(next - cost <= 6 + level * 14 + 1, `Lv${level}: ${cost} -> ${next}`);
    costs.push(next); cost = next;
  }
  assert.deepEqual(costs.slice(0, 4), [28, 50, 78, 112]); assert.ok(cost < 100000);
});

test("upgrade card radius includes area passives and inherited evolution ranks", async () => {
  const f = await fixture("toxic_tomato", 6); raise(f.skillManager, "salt_spread", 8);
  for (const id of ["toxic_tomato", "toxic_burst_cloud"]) {
    if (id === "toxic_burst_cloud") raise(f.skillManager, id, 1);
    const choice = f.ConfigManager.getSkill(id), level = f.skillManager.getLevel(id);
    const hint = f.skillManager.getChoiceHints([choice])[0]; const current = f.skillManager.getAuraProfiles().find(p => p.skillId === id).radius;
    assert.equal(hint.auraPreview.currentRadius, current);
    raise(f.skillManager, id, level + 1);
    assert.equal(hint.auraPreview.nextRadius, f.skillManager.getAuraProfiles().find(p => p.skillId === id).radius);
    const benefit = f.getSkillUpgradeBenefit(choice, level, hint.auraPreview);
    assert.match(benefit, new RegExp(`半径 ${Math.round(current)} → ${Math.round(hint.auraPreview.nextRadius)}`));
  }
});

test("evolved pepper preserves earned piercing and real collinear horde throughput", async () => {
  const probe = async evolved => {
    const f = await fixture("pepper_gatling", 12); f.skillManager = new f.SkillManager({ enforceSlots: true }); f.runtime.skillManager = f.skillManager;
    raise(f.skillManager, "pepper_gatling", 12); raise(f.skillManager, "butter_lube", 3);
    if (evolved) raise(f.skillManager, "pepper_overdrive", 1);
    const targets = [90, 135, 180].map(x => f.spawn(x, 100000));
    const attack = new f.AutoAttackSystem(), movement = new f.MovementSystem(), collision = new f.ProjectileCollisionSystem();
    for (let time = 0; time < 4000; time += 20) { attack.update(20, f.runtime); movement.update(20, f.runtime); collision.update(20, f.runtime); }
    const values = targets.map(id => 100000 - f.world.components.health.get(id).current);
    return { values, pierce: f.skillManager.getWeaponProfiles().find(p => p.skillId === (evolved ? "pepper_overdrive" : "pepper_gatling")).pierce };
  };
  const old = await probe(false), evolved = await probe(true);
  assert.ok(evolved.pierce >= old.pierce); assert.ok(evolved.values[1] > 0 && evolved.values[2] > 0);
  assert.ok(evolved.values.reduce((a,b) => a+b,0) >= old.values.reduce((a,b) => a+b,0));
});

test("evolved poison preserves rank4 and8 slow-control milestones", async () => {
  for (const rank of [4, 8]) {
    const f = await fixture("toxic_tomato", rank);
    const original = f.skillManager.getAuraProfiles()[0].effects.find(e => e.type === "slow");
    raise(f.skillManager, "toxic_burst_cloud", 1);
    const evolved = f.skillManager.getAuraProfiles().find(p => p.skillId === "toxic_burst_cloud").effects.find(e => e.type === "slow");
    assert.ok(evolved); assert.ok(evolved.slowMultiplier <= original.slowMultiplier);
  }
});
