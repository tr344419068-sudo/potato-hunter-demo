import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
export { SkillManager } from "./src/managers/SkillManager.ts";
export { ConfigManager } from "./src/managers/ConfigManager.ts";
export { AuraSystem } from "./src/systems/AuraSystem.ts";
export { StatusEffectSystem } from "./src/systems/StatusEffectSystem.ts";
export { DeathSystem } from "./src/systems/DeathSystem.ts";
export { AutoAttackSystem } from "./src/systems/AutoAttackSystem.ts";
export { MovementSystem } from "./src/systems/MovementSystem.ts";
export { ProjectileCollisionSystem } from "./src/systems/ProjectileCollisionSystem.ts";
export { World } from "./src/entities/World.ts";
export { EventBus } from "./src/managers/EventBus.ts";
export { createPlayer, createMonster } from "./src/entities/factories.ts";
export { getNextExperienceRequirement } from "./src/managers/PacingModel.ts";
export { getTempoSpeedBonus } from "./src/systems/AttackTempoModel.ts";
export { getSkillUpgradeBenefit } from "./src/ui/UIModel.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
plugins: [{ name: "mowing-headless", setup(context) {
  context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "mowing-headless" }));
  context.onLoad({ filter: /.*/, namespace: "mowing-headless" }, () => ({ contents: `import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Display: { Color: { HexStringToColor: v=>({color:parseInt(v.slice(1),16)}) } }, Utils: { Array: { Shuffle: v=>v } }, Math: { Clamp: (v,a,b)=>Math.min(b,Math.max(a,v)), Between: (a,b)=>a, FloatBetween: (a,b)=>a } };`, resolveDir: root }));
}}] }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

function raise(manager, id, rank) { for (let i = manager.getLevel(id); i < rank; i++) manager.levelUp(id); }
async function fixture(id = "toxic_tomato", rank = 1) {
  const api = await modules; api.EventBus.removeAllListeners();
  const world = new api.World(); const playerId = api.createPlayer(world, 0, 0, 220, 100, 145);
  const skillManager = new api.SkillManager({ random: () => .37 }); raise(skillManager, id, rank);
  const runtime = { world, playerId, skillManager, stats: { elapsedMs: 0, kills: 0, bossKills: 0, gold: 0 }, endRun() {} };
  const damage = []; api.EventBus.on("combat:damage", event => damage.push(event));
  const system = new api.AuraSystem();
  const spawn = (x, hp = 1000, behavior = "chaser") => {
    const entity = api.createMonster(world, api.ConfigManager.getMonster("fries_cultist"), x, 0);
    world.components.health.set(entity, { current: hp, max: hp });
    const monster = world.components.monsters.get(entity); monster.behavior = behavior;
    return entity;
  };
  return { ...api, world, playerId, skillManager, runtime, system, damage, spawn };
}

test("initial poison and ketchup reach enemies before contact with real 180/190 radii", async () => {
  for (const [id, radius, entryDamage] of [["toxic_tomato", 180, 32], ["ketchup_aura", 190, 36]]) {
    const f = await fixture(id); const profile = f.skillManager.getAuraProfiles()[0];
    assert.equal(profile.radius, radius); assert.equal(profile.entryDamage, entryDamage);
    const inside = f.spawn(radius - 1, 24), outside = f.spawn(radius + 1, 24);
    f.system.update(16, f.runtime);
    assert.ok(f.world.components.health.get(inside).current <= 0);
    assert.equal(f.world.components.health.get(outside).current, 24);
  }
});

test("a whole opening wave dies on entry and real DeathSystem produces XP", async () => {
  const f = await fixture(); const ids = [70, 120, 170].map(x => f.spawn(x, 24));
  f.system.update(16, f.runtime); new f.DeathSystem().update(16, f.runtime);
  assert.equal(f.runtime.stats.kills, 3); assert.equal(f.world.components.experienceOrbs.size, 3);
  for (const id of ids) assert.equal(f.world.isAlive(id), false);
  assert.ok(f.damage.every(event => event.category === "outgoing" && !event.isDot));
});

test("42HP opening slow enemy dies before it can cross the expanded aura", async () => {
  const f = await fixture(); const id = f.spawn(179, 42); const statuses = new f.StatusEffectSystem();
  let elapsed = 0;
  while (elapsed < 1000 && f.world.components.health.get(id).current > 0) {
    f.system.update(20, f.runtime); statuses.update(20, f.runtime); elapsed += 20;
  }
  assert.ok(f.world.components.health.get(id).current <= 0); assert.ok(elapsed < 1000);
  assert.ok(elapsed / 1000 * 58 < 180 - 20 - 18);
});

test("entry hit respects guard shields and high-HP Bosses instead of type-based execution", async () => {
  const f = await fixture(); const guard = f.spawn(150, 58, "guard"), boss = f.spawn(155, 2000);
  f.world.components.monsters.get(guard).shieldHp = 16; f.world.components.monsters.get(boss).isBoss = true;
  f.system.update(16, f.runtime);
  assert.equal(f.world.components.monsters.get(guard).shieldHp, 0);
  assert.ok(Math.abs(f.world.components.health.get(guard).current - (58 - (32 + 12 * .22 - 16))) < 1e-9);
  assert.ok(f.world.components.health.get(boss).current > 1900);
  assert.equal(f.damage.find(event => event.targetId === guard && event.category === "shield").value, 16);
  assert.ok(f.damage.find(event => event.targetId === guard && event.category === "outgoing").value > 18);
});

test("late entrants hit immediately even when ordinary aura DOT timer has not expired", async () => {
  const f = await fixture(); f.system.update(16, f.runtime);
  const id = f.spawn(170); f.system.update(16, f.runtime);
  assert.equal(f.world.components.health.get(id).current, 968);
  assert.equal(f.damage.length, 1); assert.equal(f.damage[0].isDot, false);
});

test("continuous residence, zero delta, and upgrading do not replay entry hits", async () => {
  const f = await fixture(); const id = f.spawn(170); f.system.update(16, f.runtime);
  f.system.update(0, f.runtime); raise(f.skillManager, "toxic_tomato", 2); f.system.update(16, f.runtime);
  assert.equal(f.damage.filter(event => event.targetId === id && !event.isDot).length, 1);
});

test("exit and reentry cannot exploit the 1.5s entry-hit cooldown", async () => {
  const f = await fixture(); const id = f.spawn(170); f.system.update(16, f.runtime);
  f.world.components.transforms.get(id).x = 300; f.system.update(16, f.runtime);
  f.world.components.transforms.get(id).x = 170; f.system.update(16, f.runtime);
  assert.equal(f.damage.filter(event => !event.isDot).length, 1);
  f.system.update(1600, f.runtime); assert.equal(f.damage.filter(event => !event.isDot).length, 1);
  f.world.components.transforms.get(id).x = 300; f.system.update(16, f.runtime);
  f.world.components.transforms.get(id).x = 170; f.system.update(16, f.runtime);
  assert.equal(f.damage.filter(event => !event.isDot).length, 2);
});

test("poison and ketchup have independent entry hits and no repeat on long frames", async () => {
  const f = await fixture(); raise(f.skillManager, "ketchup_aura", 1); f.spawn(170);
  f.system.update(16, f.runtime); assert.equal(f.damage.filter(event => !event.isDot && !event.isReaction).length, 2);
  f.damage.length = 0; f.system.update(5000, f.runtime);
  assert.ok(f.damage.filter(event => !event.isReaction).length <= 2);
  assert.ok(f.damage.filter(event => !event.isReaction).every(event => event.isDot));
});

test("dead player cannot deal aura damage", async () => {
  const f = await fixture(); const id = f.spawn(170); f.world.components.health.get(f.playerId).current = 0;
  f.system.update(16, f.runtime); assert.equal(f.world.components.health.get(id).current, 1000);
});

test("removed profiles and destroyed enemies release entry state", async () => {
  const f = await fixture(); const id = f.spawn(170); f.system.update(16, f.runtime);
  const profiles = f.skillManager.getAuraProfiles();
  f.runtime.skillManager = { getAuraProfiles: () => [] }; f.world.destroyEntity(id); f.system.update(16, f.runtime);
  f.runtime.skillManager = { getAuraProfiles: () => profiles }; const next = f.spawn(170); f.system.update(16, f.runtime);
  assert.ok(f.world.components.health.get(next).current <= 968);
  assert.equal(f.system.entries.get("toxic_tomato").size, 1);
});

test("world or player replacement resets entry and tick state", async () => {
  const f = await fixture(); f.spawn(170); f.system.update(16, f.runtime);
  const next = await fixture(); const id = next.spawn(170); f.system.update(16, next.runtime);
  assert.ok(next.world.components.health.get(id).current < 968);
  const playerId = next.createPlayer(next.world, 0, 0, 220, 100, 145); next.runtime.playerId = playerId;
  const before = next.world.components.health.get(id).current; f.system.update(16, next.runtime);
  assert.ok(next.world.components.health.get(id).current < before - 32);
});

test("all active, passive and evolution ranks have functional raised caps", async () => {
  const { ConfigManager, SkillManager } = await modules;
  for (const skill of ConfigManager.skills) {
    const expected = skill.category === "active" ? 12 : skill.category === "evolution" || skill.id === "combo_gear" ? 6 : 8;
    assert.equal(skill.maxLevel, expected, skill.id);
    const manager = new SkillManager({ random: () => .37 }); raise(manager, skill.id, expected + 2);
    assert.equal(manager.getLevel(skill.id), expected);
    assert.ok(manager.getChoices(100).every(choice => choice.id !== skill.id));
  }
});

test("owned evolutions continue appearing in choices until rank6 and hints indicate reinforcement", async () => {
  const f = await fixture("toxic_burst_cloud");
  const choices = f.skillManager.getChoices(100);
  assert.ok(choices.some(choice => choice.id === "toxic_burst_cloud")); assert.equal(new Set(choices.map(s => s.id)).size, choices.length);
  const hint = f.skillManager.getChoiceHints([f.ConfigManager.getSkill("toxic_burst_cloud")])[0];
  assert.match(hint.evolutionHint, /强化/); assert.doesNotMatch(hint.progressHints.join(""), /进化完成后/);
});

test("initial evolution is still locked without its recipe", async () => {
  const f = await fixture(); assert.ok(f.skillManager.getChoices(100).every(choice => choice.category !== "evolution"));
  raise(f.skillManager, "toxic_tomato", 3); raise(f.skillManager, "salt_spread", 1);
  assert.equal(f.skillManager.getChoices(3)[0].id, "toxic_burst_cloud");
});

test("aura growth is visible and shares a safe 520 radius cap at all raised ranks", async () => {
  for (const id of ["toxic_tomato", "ketchup_aura", "toxic_burst_cloud"]) for (const areaLevel of [0, 8]) {
    const f = await fixture(id); raise(f.skillManager, "salt_spread", areaLevel);
    const skill = f.ConfigManager.getSkill(id);
    let previous = 0;
    for (let level = 1; level <= skill.maxLevel; level++) {
      raise(f.skillManager, id, level); const profile = f.skillManager.getAuraProfiles()[0];
      assert.equal(profile.radius, Math.min(520, skill.aura.radius * f.skillManager.getCombatStats().areaMultiplier * (1 + .14 * (level - 1))));
      assert.ok(profile.radius >= previous); previous = profile.radius;
    }
  }
});

test("poison ranks4 and8 slow, ketchup ranks4 and8 knock back with visible card milestones", async () => {
  for (const [id, level, strength] of [["toxic_tomato", 4, .82], ["toxic_tomato", 8, .65], ["ketchup_aura", 4, 100], ["ketchup_aura", 8, 160]]) {
    const f = await fixture(id, level); const profile = f.skillManager.getAuraProfiles()[0]; const target = f.spawn(170);
    f.system.update(16, f.runtime);
    if (id === "toxic_tomato") assert.equal(f.world.components.statuses.get(target).find(s => s.type === "slow").slowMultiplier, strength);
    else { assert.equal(profile.entryKnockback, strength); assert.equal(f.world.components.knockbacks.get(target).x, strength); }
    assert.match(f.getSkillUpgradeBenefit(f.ConfigManager.getSkill(id), level - 1), id === "toxic_tomato" ? /减速/ : /击退|重击/);
  }
});

test("evolution cannot shrink or weaken an invested aura or weapon", async () => {
  const { ConfigManager, SkillManager } = await modules;
  for (const recipe of ConfigManager.skillEvolutions) for (const rank of [3, 6, 12]) {
    const manager = new SkillManager({ enforceSlots: true, random: () => .37 });
    for (const needed of recipe.requiredSkills) raise(manager, needed.id, ConfigManager.getSkill(needed.id).category === "active" ? Math.max(rank, needed.level) : needed.level);
    const predecessor = recipe.requiredSkills.find(s => ConfigManager.getSkill(s.id).category === "active").id;
    const old = [...manager.getAuraProfiles(), ...manager.getWeaponProfiles()].find(p => p.skillId === predecessor);
    manager.levelUp(recipe.resultSkillId);
    const evolved = [...manager.getAuraProfiles(), ...manager.getWeaponProfiles()].find(p => p.skillId === recipe.resultSkillId);
    if (old.radius) { assert.ok(evolved.radius >= old.radius, `${recipe.id} radius at ${rank}`); assert.ok(evolved.damagePerSecond >= old.damagePerSecond); assert.ok(evolved.entryDamage >= old.entryDamage); }
    else assert.ok(evolved.damage >= old.damage, `${recipe.id} damage at ${rank}`);
    const firstDamage = evolved.damage ?? evolved.damagePerSecond; manager.levelUp(recipe.resultSkillId);
    const reinforced = [...manager.getAuraProfiles(), ...manager.getWeaponProfiles()].find(p => p.skillId === recipe.resultSkillId);
    assert.ok((reinforced.damage ?? reinforced.damagePerSecond) > firstDamage);
  }
});

test("opening single-hit weapons kill 24HP trash while pepper and corn retain rapid multi-hit identity", async () => {
  const { SkillManager } = await modules;
  for (const id of ["peeler_blade", "fire_potato", "frost_chips", "thunder_potato"]) {
    const manager = new SkillManager({ starterSkillId: id }); assert.ok(manager.getWeaponProfiles()[0].damage >= 24, id);
  }
  for (const id of ["pepper_gatling", "corn_burst"]) { const manager = new SkillManager({ starterSkillId: id }); assert.ok(manager.getWeaponProfiles()[0].damage < 24); }
});

test("combo gear levels4 to6 genuinely add tempo speed", async () => {
  const { getTempoSpeedBonus } = await modules; const player = { tempo: { stacks: 8 } };
  assert.equal(getTempoSpeedBonus(player, 3), .24); assert.equal(getTempoSpeedBonus(player, 6), .48);
});

test("high-rank weapons add piercing or a fourth burst round rather than only damage", async () => {
  for (const [id, rank, field, minimum] of [["peeler_blade", 8, "pierce", 2], ["pepper_gatling", 8, "pierce", 1], ["corn_burst", 6, "burstCount", 4]]) {
    const f = await fixture(id, rank); const profile = f.skillManager.getWeaponProfiles().find(p => p.skillId === id);
    assert.ok(profile[field] >= minimum, id);
    assert.match(f.getSkillUpgradeBenefit(f.ConfigManager.getSkill(id), rank - 1), /穿透|四连/);
  }
});

test("XP preserves opening costs and has no exponential wall in long-term leveling", async () => {
  const { getNextExperienceRequirement } = await modules; let cost = 12; const costs = [];
  for (let level = 2; level <= 100; level++) {
    const next = getNextExperienceRequirement(cost, level); assert.ok(next > cost); assert.ok(Number.isFinite(next));
    if (level >= 13) assert.ok(next - cost <= 6 + level * 14 + 1, `Lv${level}: ${cost} -> ${next}`);
    costs.push(next); cost = next;
  }
  assert.deepEqual(costs.slice(0, 4), [28, 50, 78, 112]); assert.ok(cost < 100000);
});

test("upgrade card radius includes area passives and inherited evolution ranks", async () => {
  const f = await fixture("toxic_tomato", 6); raise(f.skillManager, "salt_spread", 8);
  for (const id of ["toxic_tomato", "toxic_burst_cloud"]) {
    if (id === "toxic_burst_cloud") raise(f.skillManager, id, 1);
    const choice = f.ConfigManager.getSkill(id), level = f.skillManager.getLevel(id);
    const hint = f.skillManager.getChoiceHints([choice])[0]; const current = f.skillManager.getAuraProfiles().find(p => p.skillId === id).radius;
    assert.equal(hint.auraPreview.currentRadius, current);
    raise(f.skillManager, id, level + 1);
    assert.equal(hint.auraPreview.nextRadius, f.skillManager.getAuraProfiles().find(p => p.skillId === id).radius);
    const benefit = f.getSkillUpgradeBenefit(choice, level, hint.auraPreview);
    assert.match(benefit, new RegExp(`半径 ${Math.round(current)} → ${Math.round(hint.auraPreview.nextRadius)}`));
  }
});

test("evolved pepper preserves earned piercing and real collinear horde throughput", async () => {
  const probe = async evolved => {
    const f = await fixture("pepper_gatling", 12); f.skillManager = new f.SkillManager({ enforceSlots: true }); f.runtime.skillManager = f.skillManager;
    raise(f.skillManager, "pepper_gatling", 12); raise(f.skillManager, "butter_lube", 3);
    if (evolved) raise(f.skillManager, "pepper_overdrive", 1);
    const targets = [90, 135, 180].map(x => f.spawn(x, 100000));
    const attack = new f.AutoAttackSystem(), movement = new f.MovementSystem(), collision = new f.ProjectileCollisionSystem();
    for (let time = 0; time < 4000; time += 20) { attack.update(20, f.runtime); movement.update(20, f.runtime); collision.update(20, f.runtime); }
    const values = targets.map(id => 100000 - f.world.components.health.get(id).current);
    return { values, pierce: f.skillManager.getWeaponProfiles().find(p => p.skillId === (evolved ? "pepper_overdrive" : "pepper_gatling")).pierce };
  };
  const old = await probe(false), evolved = await probe(true);
  assert.ok(evolved.pierce >= old.pierce); assert.ok(evolved.values[1] > 0 && evolved.values[2] > 0);
  assert.ok(evolved.values.reduce((a,b) => a+b,0) >= old.values.reduce((a,b) => a+b,0));
});

test("evolved poison preserves rank4 and8 slow-control milestones", async () => {
  for (const rank of [4, 8]) {
    const f = await fixture("toxic_tomato", rank);
    const original = f.skillManager.getAuraProfiles()[0].effects.find(e => e.type === "slow");
    raise(f.skillManager, "toxic_burst_cloud", 1);
    const evolved = f.skillManager.getAuraProfiles().find(p => p.skillId === "toxic_burst_cloud").effects.find(e => e.type === "slow");
    assert.ok(evolved); assert.ok(evolved.slowMultiplier <= original.slowMultiplier);
  }
});
