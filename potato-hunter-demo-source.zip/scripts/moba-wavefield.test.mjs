import assert from 'node:assert/strict';
import test from 'node:test';
import { build } from 'esbuild';
import { displayScene } from './ui-runtime-helpers.mjs';
const api=build({stdin:{contents:`export * from './src/systems/AreaVfxModel.ts';export {AreaVfxView} from './src/systems/AreaVfxView.ts';export {World} from './src/entities/World.ts';`,resolveDir:process.cwd(),loader:'ts'},bundle:true,platform:'node',format:'esm',write:false,plugins:[{name:'phaser-stub',setup(c){c.onResolve({filter:/^phaser$/},()=>({path:'p',namespace:'p'}));c.onLoad({filter:/.*/,namespace:'p'},()=>({contents:'export default {BlendModes:{NORMAL:0,ADD:1}}'}))}}]}).then(r=>import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));
async function fixture(count=1){const a=await api;const f=displayScene();const world=new a.World();world.components.transforms.set(1,{x:300,y:250,radius:20});world.components.players.set(1,{level:5});const profiles=Array.from({length:count},(_,i)=>({skillId:`aura-${i}`,vfxKind:i%2?'ketchup':'poison',radius:150,color:0x80b918}));const runtime={world,playerId:1,skillManager:{getAuraProfiles:()=>profiles}};return {...a,...f,runtime,profiles,view:new a.AreaVfxView(f.scene)}}
test('wave model expands and fades rather than attaching a full opaque image',async()=>{const a=await api;assert.equal(typeof a.getAreaWaveFrame,'function');const start=a.getAreaWaveFrame(150,0,false),mid=a.getAreaWaveFrame(150,330,false),end=a.getAreaWaveFrame(150,900,false);assert.ok(mid.scale>start.scale);assert.ok(mid.scale<end.scale);assert.equal(start.alpha,0);assert.equal(end.alpha,0);assert.ok(mid.alpha>0&&mid.alpha<=.65);assert.equal(end.radius,150);});
test('outward motes move radially and disappear before leaving their boundary',async()=>{const a=await api;assert.equal(typeof a.getAreaMoteFrame,'function');const early=a.getAreaMoteFrame(150,60,0,false),late=a.getAreaMoteFrame(150,540,0,false);assert.ok(late.distance>early.distance+40);assert.ok(late.distance+late.size/2<=150);assert.ok(late.size<=10);assert.equal(a.getAreaMoteFrame(150,720,0,false).alpha,0)});
test('thin boundary has a legible bright phase on grass without filling its center',async()=>{const f=await fixture();f.view.update(135,f.runtime);const wave=f.view.layers.get('aura-0').waves[0].visual;assert.ok(wave.alpha>=.45&&wave.alpha<=.65);assert.ok(wave.calls.some(c=>c[0]==='lineStyle'&&c[1]>=2.5&&c[3]>=.9));assert.ok(!wave.calls.some(c=>c[0]==='fillCircle'));f.view.destroy()});
test('wave crest remains legible as it expands before its final fade',async()=>{const a=await api;assert.ok(a.getAreaWaveFrame(150,360,false).alpha>=.4);assert.ok(a.getAreaWaveFrame(150,810,false).alpha<.1)});
test('wave front carries broken energy ribbons rather than only uniform circles',async()=>{const f=await fixture();f.view.update(160,f.runtime);const wave=f.view.layers.get('aura-0').waves[0].visual;assert.ok(wave.calls.filter(c=>c[0]==='lineTo').length>=30);assert.ok(!wave.calls.some(c=>c[0]==='fillCircle'));f.view.destroy()});
test('both auras retain a wide hollow luminous field through the wave reset and follow the upgraded damage radius',async()=>{
 const f=await fixture(2);f.profiles[0].radius=180;f.profiles[1].radius=190;
 for(const time of [0,135,900,1800]){
  f.view.update(time-f.view.elapsedMs,f.runtime);
  for(const p of f.profiles){
   const wave=f.view.layers.get(p.skillId).waves[0].visual;
   assert.ok(wave.visible && wave.alpha>=.15,'the sustained ring must remain visible even as wave pulses reset');
   const circles=wave.calls.filter(c=>c[0]==='strokeCircle');
   assert.ok(circles.length>=7,'several translucent concentric strokes create a wide light band');
   assert.ok(wave.calls.some(c=>c[0]==='lineStyle' && c[1]*wave.scaleX>=p.radius*.12),'the field must have a broad halo, not just a thin outline');
   assert.ok(wave.calls.filter(c=>c[0]==='lineStyle').every(c=>c[3]>=0 && c[3]<=1),'stroke opacity must remain valid throughout the animation');
   assert.ok(!wave.calls.some(c=>c[0]==='fillCircle'),'the hero remains visible through a hollow center');
  }
 }
 Object.assign(f.runtime.world.components.transforms.get(1),{x:490,y:310});f.profiles[0].radius=260;f.view.update(0,f.runtime);
 const visual=f.view.layers.get('aura-0').waves[0].visual;
 assert.deepEqual([visual.x,visual.y],[490,310]);
 assert.ok(visual.calls.some(c=>c[0]==='strokeCircle'&&Math.abs(c[3]*visual.scaleX-260*.78)<.001),'the light band expands when the skill is upgraded');
 f.view.destroy();
});
test('real view has no heavy full-ring imagery or large filled disk',async()=>{const f=await fixture();f.view.update(200,f.runtime);assert.equal(f.objects.filter(o=>o.kind==='image').length,0);assert.equal(f.objects.length,8);assert.ok(f.objects.every(o=>o.depth<1));assert.ok(f.objects.every(o=>!o.calls.some(c=>c[0]==='fillCircle'&&c[3]>12)));f.view.destroy()});
test('expanding waves follow the moved hero on the very next frame, not the next emission cycle',async()=>{const f=await fixture();f.view.update(100,f.runtime);const wave=f.view.layers.get('aura-0').waves[0].visual;const before={scale:wave.scaleX,alpha:wave.alpha};Object.assign(f.runtime.world.components.transforms.get(1),{x:480,y:330});f.view.update(230,f.runtime);assert.equal(wave.x,480);assert.equal(wave.y,330);assert.ok(wave.scaleX>before.scale);assert.notEqual(wave.alpha,before.alpha);f.view.update(650,f.runtime);assert.equal(wave.x,480);assert.equal(wave.y,330);f.view.destroy()});
test('zero delta freezes phase, reduced mode lowers decoration, large delta never catches up allocations',async()=>{const f=await fixture(12);f.view.update(180,f.runtime);assert.equal(f.objects.length,24);const state=()=>f.objects.map(o=>[o.x,o.y,o.scaleX,o.alpha,o.visible]);const before=state();f.view.update(0,f.runtime);assert.deepEqual(state(),before);f.view.setReducedEffects(true);f.view.update(16,f.runtime);assert.ok(f.objects.filter(o=>o.visible).length<=9);for(let n=0;n<30;n++)f.view.update(10000,f.runtime);assert.equal(f.objects.length,24);f.profiles.length=0;f.view.update(16,f.runtime);assert.ok(f.objects.every(o=>o.destroyed));f.view.destroy();f.view.destroy()});
