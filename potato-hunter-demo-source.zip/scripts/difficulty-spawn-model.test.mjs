import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { build } from "esbuild";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));
const modulesPromise = build({
  stdin: {
    contents: `
      export { World } from "./src/entities/World.ts";
      export { createPlayer } from "./src/entities/factories.ts";
      export { DifficultyManager } from "./src/managers/DifficultyManager.ts";
      export { WaveManager } from "./src/managers/WaveManager.ts";
      export { SpawnSystem } from "./src/systems/SpawnSystem.ts";
      export { ConfigManager } from "./src/managers/ConfigManager.ts";
    `,
    resolveDir: projectRoot,
    loader: "ts",
  },
  bundle: true,
  platform: "node",
  format: "esm",
  write: false,
  plugins: [{
    name: "headless-phaser-spawns",
    setup(buildContext) {
      buildContext.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless-spawns" }));
      buildContext.onLoad({ filter: /.*/, namespace: "headless-spawns" }, () => ({
        contents: 'import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Math: { Between: (minimum, maximum) => Math.floor((minimum + maximum) / 2) } };',
        resolveDir: projectRoot,
      }));
    },
  }],
}).then((result) => import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString("base64")}`));

async function sampleActualSpawnCadence(elapsedMs) {
  const modules = await modulesPromise;
  const world = new modules.World();
  const playerId = modules.createPlayer(world, 0, 0, 220, 100, 145);
  const waveManager = new modules.WaveManager();
  const runtime = {
    world,
    playerId,
    stats: { elapsedMs },
    waveManager: {
      getCurrentWave: (timeMs) => waveManager.getCurrentWave(timeMs),
      shouldSpawnBoss: () => false,
    },
  };
  const system = new modules.SpawnSystem();
  system.update(0, runtime);
  const batchSize = world.components.monsters.size;
  let intervalMs = 0;
  while (world.components.monsters.size === batchSize && intervalMs < 2000) {
    intervalMs += 1;
    system.update(1, runtime);
  }
  assert.ok(intervalMs < 2000, `regular spawn never repeated at ${elapsedMs}ms`);
  assert.equal(world.components.monsters.size, batchSize * 2, "each burst must preserve the fixed batch");
  const wave = waveManager.getCurrentWave(elapsedMs);
  const totalWeight = wave.monsterMix.reduce((sum, entry) => sum + entry.weight, 0);
  const averageHp = wave.monsterMix.reduce((sum, entry) => sum + modules.ConfigManager.getMonster(entry.monsterId).hp * entry.weight / totalWeight, 0);
  return { batchSize, intervalMs, countRate: batchSize * 1000 / intervalMs, healthRate: batchSize * 1000 / intervalMs * averageHp };
}

test("difficulty spawn bonuses ramp over six seconds instead of jumping", async () => {
  const modules = await modulesPromise;
  const manager = new modules.DifficultyManager();
  assert.equal(manager.getState(74_999).extraSpawnCount, 0);
  assert.equal(manager.getState(75_000).extraSpawnCount, 0);
  assert.equal(manager.getState(78_000).extraSpawnCount, 0.5);
  assert.equal(manager.getState(81_000).extraSpawnCount, 1);
  assert.equal(manager.getState(130_000).extraSpawnCount, 1);
  assert.equal(manager.getState(133_000).extraSpawnCount, 1.5);
  assert.equal(manager.getState(136_000).extraSpawnCount, 2);
});

test("actual spawn batches stay small before and after difficulty growth", async () => {
  for (const elapsedMs of [74_999, 75_000, 78_000, 81_000, 129_999, 130_000, 133_000, 136_000, 185_000, 188_000, 191_000]) {
    const cadence = await sampleActualSpawnCadence(elapsedMs);
    assert.equal(cadence.batchSize, 3, `batch jumped to ${cadence.batchSize} at ${elapsedMs}ms`);
  }
});

test("effective runtime count, interval, and health pressure stay continuous at difficulty boundaries", async () => {
  for (const seconds of [75, 81, 130, 136, 185, 191]) {
    const samples = [];
    for (const offsetMs of [-1, 0, 1]) samples.push(await sampleActualSpawnCadence(seconds * 1000 + offsetMs));
    for (const metric of ["countRate", "intervalMs", "healthRate"]) {
      const values = samples.map((sample) => sample[metric]);
      const relativeRange = (Math.max(...values) - Math.min(...values)) / values[1];
      assert.ok(relativeRange < 0.01, `${metric} jumped ${relativeRange * 100}% at ${seconds}s: ${values.join(", ")}`);
    }
  }
});

test("difficulty bonuses still increase sustained pressure after their ramp", async () => {
  const before = await sampleActualSpawnCadence(75_000);
  const after = await sampleActualSpawnCadence(81_000);
  assert.ok(after.countRate > before.countRate);
  assert.ok(after.healthRate > before.healthRate);
});
