#!/usr/bin/env python3
"""Convert internal image-generation exports into clean game-ready PNG assets."""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np
from PIL import Image


def chroma_pixels(rgb: np.ndarray) -> np.ndarray:
    red = rgb[:, :, 0]
    green = rgb[:, :, 1]
    blue = rgb[:, :, 2]
    return (red > 165) & (blue > 165) & (green < 115) & (((red.astype(np.int16) + blue.astype(np.int16)) // 2 - green) > 105)


def chroma_spill_pixels(rgb: np.ndarray) -> np.ndarray:
    red = rgb[:, :, 0]
    green = rgb[:, :, 1]
    blue = rgb[:, :, 2]
    magenta_level = (red.astype(np.int16) + blue.astype(np.int16)) // 2
    return (red > 115) & (blue > 115) & (green < 165) & ((magenta_level - green) > 38)


def connected_chroma_background(rgb: np.ndarray) -> np.ndarray:
    chroma = chroma_pixels(rgb)
    count, labels = cv2.connectedComponents(chroma.astype(np.uint8), connectivity=8)
    if count <= 1:
        return np.zeros(chroma.shape, dtype=bool)

    border_labels = np.unique(np.concatenate((labels[0, :], labels[-1, :], labels[:, 0], labels[:, -1])))
    border_labels = border_labels[border_labels != 0]
    return np.isin(labels, border_labels)


def make_transparent(image: Image.Image, size: int, all_chroma: bool = False) -> Image.Image:
    rgb = np.asarray(image.convert("RGB"))
    original_alpha = np.asarray(image.convert("RGBA"))[:, :, 3]
    if np.any(original_alpha < 255):
        # Website cutouts already contain a mask: never replace it with RGB keying.
        alpha = original_alpha.copy()
    else:
        background = chroma_spill_pixels(rgb) if all_chroma else connected_chroma_background(rgb)
        alpha = np.where(background, 0, 255).astype(np.uint8)
        if not all_chroma:
            alpha = cv2.GaussianBlur(alpha, (0, 0), 0.7)
            alpha[alpha < 10] = 0
            alpha[alpha > 245] = 255

    rgba = np.dstack((rgb, alpha))
    ys, xs = np.where(alpha > 20)
    if xs.size == 0 or ys.size == 0:
        raise ValueError("No foreground remained after chroma extraction")

    left, right = int(xs.min()), int(xs.max()) + 1
    top, bottom = int(ys.min()), int(ys.max()) + 1
    crop = Image.fromarray(rgba, "RGBA").crop((left, top, right, bottom))
    padding = max(4, round(max(crop.size) * 0.07))
    square_edge = max(crop.size) + padding * 2
    square = Image.new("RGBA", (square_edge, square_edge), (0, 0, 0, 0))
    square.alpha_composite(crop, ((square_edge - crop.width) // 2, (square_edge - crop.height) // 2))
    return square.convert("RGBa").resize((size, size), Image.Resampling.LANCZOS).convert("RGBA")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--size", type=int, required=True)
    parser.add_argument("--opaque", action="store_true")
    parser.add_argument("--all-chroma", action="store_true", help="remove enclosed chroma-key regions as well as the border-connected background")
    args = parser.parse_args()

    image = Image.open(args.source)
    if args.opaque:
        result = image.convert("RGB").resize((args.size, args.size), Image.Resampling.LANCZOS)
    else:
        result = make_transparent(image, args.size, args.all_chroma)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.save(args.output, format="PNG", optimize=True)


if __name__ == "__main__":
    main()
