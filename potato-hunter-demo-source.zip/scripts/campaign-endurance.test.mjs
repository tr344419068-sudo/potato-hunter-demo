import assert from 'node:assert/strict';
import test from 'node:test';
import {build} from 'esbuild';
import {performance} from 'node:perf_hooks';
import {displayScene} from './ui-runtime-helpers.mjs';

const systems=['PlayerStats','ChapterDirector','Spawn','MonsterAI','MonsterBehavior','Boss','AoeWarning','MapEvent','AutoAttack','Aura','StatusEffect','Movement','Knockback','ProjectileCollision','EnemyProjectile','Death','Experience','MonsterContact','HitFeedback','Lifetime'];
const api=build({stdin:{contents:`
export {GameScene} from './src/scenes/GameScene.ts';
export {CampaignDirector} from './src/campaign/CampaignModel.ts';
export {RunTelemetry} from './src/campaign/RunTelemetry.ts';
export {SkillManager} from './src/managers/SkillManager.ts';
export {InputSystem} from './src/systems/InputSystem.ts';
export {EventBus} from './src/managers/EventBus.ts';
export {ConfigManager} from './src/managers/ConfigManager.ts';
export {createPlayer} from './src/entities/factories.ts';
${systems.map(s=>`export {${s}System} from './src/systems/${s}System.ts';`).join('\n')}
`,resolveDir:process.cwd(),loader:'ts'},bundle:true,platform:'node',format:'esm',write:false,plugins:[{name:'endurance-headless',setup(c){
 c.onResolve({filter:/^phaser$/},()=>({path:'phaser',namespace:'stub'}));
 c.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:`import EventEmitter from 'eventemitter3';export default {Scene:class{},Events:{EventEmitter},Scenes:{Events:{SHUTDOWN:'shutdown'}},Input:{Keyboard:{KeyCodes:{W:'w',A:'a',S:'s',D:'d',SPACE:'space'},JustDown:key=>{const v=key.justDown;key.justDown=false;return v}},Events:{POINTER_UP:'pointerup',POINTER_UP_OUTSIDE:'pointerupoutside'}},Display:{Color:{HexStringToColor:v=>({color:parseInt(v.slice(1),16)})}},Utils:{Array:{Shuffle:a=>a}},Math:{Clamp:(v,a,b)=>Math.min(b,Math.max(a,v)),Between:(a,b)=>a,FloatBetween:(a,b)=>a}};`,resolveDir:process.cwd()}));
}}]}).then(r=>import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));

function steer(g,a,pursueFinal){
 const w=g.world,p=w.components.transforms.get(g.playerId),health=w.components.health.get(g.playerId);
 let x=Math.cos(g.stats.elapsedMs/1800),y=Math.sin(g.stats.elapsedMs/1800),danger=0;
 let target,best=Infinity;
 for(const[id]of w.components.experienceOrbs){const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);if(d<best){best=d;target=t}}
 if(health.current<health.max*.7)for(const[id,event]of w.components.mapEvents){if(event.kind!=='heal')continue;const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);if(d<420){target=t;best=d;break}}
 if(target&&best<340){x=(target.x-p.x)/Math.max(1,best);y=(target.y-p.y)/Math.max(1,best)}
 // Observe/dodge a full telegraphed pattern cycle, then commit to the finale
 // instead of endlessly farming XP. Only normal pointer input is changed.
 if(pursueFinal)for(const[id,monster]of w.components.monsters){if(monster.bossKind!=='final'||(w.components.health.get(id)?.current??0)<=0)continue;
  const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);
  if(d>260){x=(t.x-p.x)/Math.max(1,d);y=(t.y-p.y)/Math.max(1,d)}
  break;
 }
 for(const[id]of w.components.monsters){const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);if(d<155){const force=(155-d)/155*2.2;x+=(p.x-t.x)/Math.max(1,d)*force;y+=(p.y-t.y)/Math.max(1,d)*force;if(d<65)danger++}}
 for(const[id,warning]of w.components.aoeWarnings){if(!warning.damage)continue;const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);if(warning.safeRadius&&d<warning.safeRadius-8)continue;if(d<t.radius+30){const force=(t.radius+30-d)/Math.max(1,t.radius)*4;x+=(p.x-t.x)/Math.max(1,d)*force;y+=(p.y-t.y)/Math.max(1,d)*force;if(warning.remainingMs<400)danger++}}
 for(const[id]of w.components.enemyProjectiles){const t=w.components.transforms.get(id),v=w.components.velocities.get(id);if(!v)continue;const dx=p.x-t.x,dy=p.y-t.y,speed=Math.hypot(v.x,v.y),arrival=(dx*v.x+dy*v.y)/Math.max(1,speed*speed),miss=Math.abs(dx*v.y-dy*v.x)/Math.max(1,speed);if(arrival>0&&arrival<.55&&miss<48){const side=dx*v.y-dy*v.x>=0?1:-1;x+=v.y/Math.max(1,speed)*side*2;y-=v.x/Math.max(1,speed)*side*2;if(arrival<.22)danger++}}
 const len=Math.max(.01,Math.hypot(x,y));Object.assign(g.input.activePointer,{isDown:true,x:p.x+x/len*220,y:p.y+y/len*220});
 if(danger&&w.components.players.get(g.playerId).dashCooldownMs<=0)a.EventBus.emit('player:dash-request');
}
const priority=['inferno_pierce','pepper_overdrive','thunder_storm','reward_heal','fire_potato','fork_splitter','butter_lube','cheese_armor','peeler_blade','thunder_potato','pepper_gatling','frost_chips','ketchup_aura','magnet_salt','pepper_motor','combo_gear','pickle_crit'];
async function run(seed){
 const a=await api;a.EventBus.removeAllListeners();const display=displayScene(),g=new a.GameScene();Object.assign(g,display.scene);g.scene={restart(){}};
 g.campaign=new a.CampaignDirector(seed);g.telemetry=new a.RunTelemetry(seed);g.runId=`endurance-${seed}`;g.skillManager=new a.SkillManager({starterSkillId:'peeler_blade',enforceSlots:true,random:g.campaign.random.bind(g.campaign)});
 g.playerId=a.createPlayer(g.world,0,0,a.ConfigManager.player.moveSpeed,a.ConfigManager.player.maxHp,a.ConfigManager.player.pickupRadius,a.ConfigManager.player.assetId);
 g.cameras.main.getWorldPoint=(x,y)=>({x,y});g.systems=[new a.InputSystem(g,g.playerId),...systems.map(s=>new a[`${s}System`])];
 let offer,result,finalSeen=false,finalId,bossDeathEvents=0,peakEntities=0,peakMonsters=0,peakProjectiles=0,peakHostileProjectiles=0,peakWarnings=0,ticks=0;const checkpoints=[],bossSpawns=[],defeatedBossIds=new Set(),rolesSeen=new Set(),finalPatterns=new Set();
 const onDefeated=g.campaign.onMonsterDefeated.bind(g.campaign);
 g.campaign.onMonsterDefeated=(id,alive)=>{if(bossSpawns.some(b=>b.id===id))defeatedBossIds.add(id);return onDefeated(id,alive)};
 a.EventBus.on('level:choices',p=>offer=p);a.EventBus.on('game:over',p=>result=p);
 a.EventBus.on('boss:spawned',p=>{if(!p)return;bossSpawns.push({id:p.entityId,final:p.final,ms:g.stats.elapsedMs});if(p.final){finalSeen=true;finalId=p.entityId}});
 a.EventBus.on('boss:defeated',()=>bossDeathEvents++);
 a.EventBus.on('boss:phase',p=>{if(p?.bossKind==='final'&&p.pattern)finalPatterns.add(p.pattern)});
 const start=performance.now();
 while(!g.gameOver&&g.stats.elapsedMs<480000){
  steer(g,a,finalPatterns.size===4);g.update(0,40);ticks++;
  while(g.choosingSkill&&offer){const health=g.world.components.health.get(g.playerId),choices=offer.choices;
   const selected=[...choices].sort((u,v)=>{const rank=c=>c.id==='reward_heal'&&health.current>health.max*.7?999:priority.includes(c.id)?priority.indexOf(c.id):100;return rank(u)-rank(v)})[0];
   const selection={skillId:selected.id,sessionId:offer.sessionId};offer=undefined;g.handleSkillSelected(selection);
  }
  peakEntities=Math.max(peakEntities,g.world.entityCount);peakMonsters=Math.max(peakMonsters,g.world.components.monsters.size);peakProjectiles=Math.max(peakProjectiles,g.world.components.projectiles.size);
  peakHostileProjectiles=Math.max(peakHostileProjectiles,g.world.components.enemyProjectiles.size);peakWarnings=Math.max(peakWarnings,g.world.components.aoeWarnings.size);
  assert.ok(g.world.components.enemyProjectiles.size<=72,'shared hostile projectile cap exceeded');assert.ok(g.world.components.aoeWarnings.size<=18,'shared warning cap exceeded');
  for(const monster of g.world.components.monsters.values())rolesSeen.add(monster.behavior);
  if(g.stats.elapsedMs>=checkpoints.length*60000){const h=g.world.components.health.get(g.playerId);checkpoints.push({seconds:Math.round(g.stats.elapsedMs/1000),hp:Math.round(h.current),level:g.world.components.players.get(g.playerId).level,monsters:g.world.components.monsters.size});}
  assert.ok(Number.isFinite(g.world.components.health.get(g.playerId).current));
 }
 const finalHp=g.world.components.health.get(finalId),finalTransform=g.world.components.transforms.get(finalId),playerTransform=g.world.components.transforms.get(g.playerId);
 const finalStatus=finalHp&&finalTransform?{hp:finalHp.current,maxHp:finalHp.max,distance:Math.hypot(finalTransform.x-playerTransform.x,finalTransform.y-playerTransform.y)}:undefined;
 if(!g.gameOver)g.abandonCampaign();g.events.emit('shutdown');
 return {seed,outcome:result?.outcome,seconds:Math.round(g.stats.elapsedMs/1000),kills:g.stats.kills,bossKills:g.stats.bossKills,bossDeathEvents,defeatedBossIds:[...defeatedBossIds],bossSpawns,finalDefeated:defeatedBossIds.has(finalId),finalStatus,playerAlive:g.world.components.health.get(g.playerId).current>0,rolesSeen:[...rolesSeen],finalPatterns:[...finalPatterns],level:g.world.components.players.get(g.playerId).level,build:g.skillManager.getKnownSkills(),finalSeen,peakEntities,peakMonsters,peakProjectiles,peakHostileProjectiles,peakWarnings,ticks,cpuMs:Math.round(performance.now()-start),checkpoints,report:result?.telemetry};
}
for(const seed of [42,7])test(`normal input/earned-choice endurance reaches a real terminal result for seed ${seed}`,async t=>{
 const r=await run(seed);t.diagnostic(JSON.stringify(r));assert.ok(['victory','defeat'].includes(r.outcome));assert.ok(r.kills>20);assert.ok(r.peakMonsters<300);assert.ok(r.peakProjectiles<500);assert.ok(r.peakEntities<5000);assert.ok(r.report.snapshots.length<256);
 assert.equal(r.bossKills,r.bossDeathEvents);assert.equal(r.bossKills,r.defeatedBossIds.length);
 if(seed===7){assert.equal(r.outcome,'victory');assert.equal(r.finalSeen,true);assert.equal(r.finalDefeated,true);assert.equal(r.playerAlive,true);assert.deepEqual(r.bossSpawns.map(s=>s.ms),[60000,180000,300000,360000]);assert.equal(new Set(r.bossSpawns.map(s=>s.id)).size,4);assert.deepEqual(r.bossSpawns.map(s=>s.final),[false,false,false,true]);assert.ok(r.seconds>=360&&r.seconds<=480);for(const role of ['hexer','scatter','sniper','jumper'])assert.ok(r.rolesSeen.includes(role));assert.equal(r.finalPatterns.length,4);}
});
test('over twenty simulated minutes across fresh runs reproduce outcomes without cross-run buildup',async t=>{
 const runs=[];
 for(let i=0;i<4;i++)runs.push(await run(7));
 assert.ok(runs.reduce((sum,r)=>sum+r.seconds,0)>=1200);
 const comparable=r=>({outcome:r.outcome,kills:r.kills,bossKills:r.bossKills,seconds:r.seconds,peakEntities:r.peakEntities,peakMonsters:r.peakMonsters,peakProjectiles:r.peakProjectiles,build:r.build,damage:r.report.damageBySource});
 for(const r of runs){assert.equal(r.outcome,'victory');assert.deepEqual(comparable(r),comparable(runs[0]));}
 t.diagnostic(JSON.stringify({simulatedMinutes:runs.reduce((sum,r)=>sum+r.seconds,0)/60,runs:runs.length,outcome:runs[0].outcome,peakEntities:runs[0].peakEntities,totalCpuMs:runs.reduce((sum,r)=>sum+r.cpuMs,0)}));
});
