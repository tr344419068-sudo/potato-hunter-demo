import assert from 'node:assert/strict';
import test from 'node:test';
import {build} from 'esbuild';
import {performance} from 'node:perf_hooks';
import {displayScene} from './ui-runtime-helpers.mjs';

const systems=['PlayerStats','ChapterDirector','Spawn','MonsterAI','MonsterBehavior','Boss','AoeWarning','MapEvent','AutoAttack','PalmStrike','Aura','StatusEffect','Movement','Knockback','SpatialSkill','ProjectileCollision','EnemyProjectile','Death','Experience','MonsterContact','HitFeedback','Lifetime'];
const api=build({stdin:{contents:`
export {GameScene} from './src/scenes/GameScene.ts';
export {CampaignDirector} from './src/campaign/CampaignModel.ts';
export {RunTelemetry} from './src/campaign/RunTelemetry.ts';
export {SkillManager} from './src/managers/SkillManager.ts';
export {WaveManager} from './src/managers/WaveManager.ts';
export {InputSystem} from './src/systems/InputSystem.ts';
export {EventBus} from './src/managers/EventBus.ts';
export {ConfigManager} from './src/managers/ConfigManager.ts';
export {createPlayer} from './src/entities/factories.ts';
export {getSpatialSkillVisuals} from './src/systems/SpatialSkillSystem.ts';
export {getBossDuel} from './src/systems/BossDuelArena.ts';
export {getSnowCast,isInsideSnowHammer,isInsideSnowLane} from './src/systems/SnowBossEncounter.ts';
export {SnowEnemySystem} from './src/systems/SnowEnemySystem.ts';
export {setupSnowIceTerrain} from './src/systems/IceTerrain.ts';
export {getDesertCast,getCyclonePoint,getWaveY,isInsideSandfall,isInsideDesertStrike} from './src/systems/DesertBossEncounter.ts';
${systems.map(s=>`export {${s}System} from './src/systems/${s}System.ts';`).join('\n')}
`,resolveDir:process.cwd(),loader:'ts'},bundle:true,platform:'node',format:'esm',write:false,plugins:[{name:'endurance-headless',setup(c){
 c.onResolve({filter:/^phaser$/},()=>({path:'phaser',namespace:'stub'}));
 c.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:`import EventEmitter from 'eventemitter3';export default {Scene:class{},Events:{EventEmitter},Scenes:{Events:{SHUTDOWN:'shutdown'}},Input:{Keyboard:{KeyCodes:{W:'w',A:'a',S:'s',D:'d',SPACE:'space'},JustDown:key=>{const v=key.justDown;key.justDown=false;return v}},Events:{POINTER_UP:'pointerup',POINTER_UP_OUTSIDE:'pointerupoutside'}},Display:{Color:{HexStringToColor:v=>({color:parseInt(v.slice(1),16)})}},Utils:{Array:{Shuffle:a=>a}},Math:{Clamp:(v,a,b)=>Math.min(b,Math.max(a,v)),Between:(a,b)=>a,FloatBetween:(a,b)=>a}};`,resolveDir:process.cwd()}));
}}]}).then(r=>import(`data:text/javascript;base64,${Buffer.from(r.outputFiles[0].text).toString('base64')}`));

// Face the same warnings a player sees: capsules need a sideways escape,
// and a ring sometimes needs an inward dodge rather than a radial retreat.
function steerDuel(g,a,duel,p) {
 const w=g.world, hero=w.components.players.get(g.playerId), boss=w.components.transforms.get(duel.bossId);
 const speed=hero.moveSpeed || 220, limit=duel.radius-p.radius;
 const warnings=[...w.components.aoeWarnings].filter(([,v])=>v.damage>0).map(([id,v])=>[w.components.transforms.get(id),v]);
 const sand=a.getDesertCast(w);
 const snow=a.getSnowCast(w);
 const bullets=[...w.components.enemyProjectiles.keys()].map(id=>[w.components.transforms.get(id),w.components.velocities.get(id)]).filter(([t,v])=>v&&Math.hypot(t.x-p.x,t.y-p.y)<480);
 let best=Infinity, direction;
 for(let i=0;i<=32;i++) {
  const dx=i===32?0:Math.cos(i*Math.PI/16),dy=i===32?0:Math.sin(i*Math.PI/16);
  const position=time=>{
   const x=p.x+dx*speed*time-duel.x,y=p.y+dy*speed*time-duel.y;
   const clamp=Math.min(1,limit/Math.max(1,Math.hypot(x,y)));
   return [duel.x+x*clamp,duel.y+y*clamp];
  };
  const [endX,endY]=position(.45), dist=Math.hypot(endX-boss.x,endY-boss.y);
  let score=Math.abs(dist-205)*.05+(dist<80?35:0);
  if(snow){
   const {shape,elapsedMs,tellMs}=snow;
   if(shape.kind==='avalanche'){
    const pulse=shape.pulses.find(v=>v.impactMs>elapsedMs);
    if(pulse){const [x]=position(Math.min(.65,(pulse.impactMs-elapsedMs)/1000));score+=Math.max(0,Math.min(x-pulse.minX+22,pulse.maxX+22-x))*4;}
   }else if(shape.kind==='glacier_charge'||elapsedMs<tellMs){
    const [x,y]=position(Math.max(.1,Math.min(.62,(tellMs-elapsedMs)/1000)));
    const hit=shape.kind==='hammer_swing'?a.isInsideSnowHammer({...shape,radius:shape.radius+10},{x,y}):a.isInsideSnowLane({...shape,radius:shape.radius+18},{x,y});
    if(hit)score+=480;
   }
  }
  if(sand){
   const shape=sand.shape,age=sand.elapsedMs-sand.tellMs;
   if(shape.kind==='dune_wave'&&(p.y-a.getWaveY(sand,age/sand.activeMs))*shape.direction>=-shape.halfDepth){
    const [x]=position(.40);
    score+=Math.max(0,Math.abs(x-shape.gapX)-shape.gapHalf+18)*2.4;
   }else if(shape.kind==='sand_siege'&&age<0){
    const [x,y]=position(Math.min(.65,-age/1000));
    const gap=Math.min(...shape.shelters.map(s=>Math.hypot(x-s.x,y-s.y)-s.radius));
    score+=Math.max(0,gap+23)*4;
   }else if(shape.kind==='sandfall'&&age<450){
    const [x,y]=position(Math.min(.65,Math.max(.2,-age/1000)));
    if(a.isInsideSandfall({...shape,halfWidth:shape.halfWidth+21},{x,y}))score+=380;
   }else if(shape.kind==='sand_burrow'&&age<0){
    const [x,y]=position(Math.min(.9,-age/1000));
    score+=Math.max(0,shape.radius+25-Math.hypot(x-shape.center.x,y-shape.center.y))*6;
   }else if(shape.kind==='sand_cleave'&&age<0){
    const [x,y]=position(-age/1000);
    if(a.isInsideDesertStrike(shape,{x,y},16))score+=450;
   }else if(shape.kind==='sand_cyclone'){
    for(const t of [.12,.27,.43,.61]){
     const at=(age+t*1000)/sand.activeMs;
     if(at<0||at>1)continue;
     const [x,y]=position(t), eye=a.getCyclonePoint(shape,at);
     score+=Math.max(0,shape.radius+25-Math.hypot(x-eye.x,y-eye.y))*4.5;
    }
   }
  }
  for(const [t,v] of warnings){
   const [x,y]=position(Math.min(1.3,(v.remainingMs+15)/1000));
   const x0=x-t.x,y0=y-t.y,ax=Math.cos(v.angle??0),ay=Math.sin(v.angle??0),half=(v.length??0)/2;
   const along=v.shape==='capsule'?Math.max(-half,Math.min(half,x0*ax+y0*ay)):0;
   const d=Math.hypot(x0-along*ax,y0-along*ay);
   const margin=Math.max(d-t.radius,v.safeRadius===undefined?-Infinity:v.safeRadius-d);
   score+=margin<0?450-margin*4:Math.max(0,23-margin)*2;
  }
  for(const [t,v] of bullets){
   const vx=v.x-speed*dx,vy=v.y-speed*dy;
   const nearest=Math.max(.02,Math.min(.55,((p.x-t.x)*vx+(p.y-t.y)*vy)/Math.max(1,vx*vx+vy*vy)));
   const [x,y]=position(nearest);
   const clearance=Math.hypot(x-(t.x+v.x*nearest),y-(t.y+v.y*nearest)) - t.radius - p.radius;
   score+=clearance<0?350-clearance*3:Math.max(0,24-clearance)*2;
  }
  if(score<best){best=score;direction=[dx,dy]}
 }
 const [dx,dy]=direction;
 Object.assign(g.input.activePointer,{isDown:true,x:p.x+dx*220,y:p.y+dy*220});
}

function steer(g,a,pursueFinal){
 const w=g.world,p=w.components.transforms.get(g.playerId),health=w.components.health.get(g.playerId);
 const duel=a.getBossDuel(w);
 if(duel)return steerDuel(g,a,duel,p);
 let x=Math.cos(g.stats.elapsedMs/1800),y=Math.sin(g.stats.elapsedMs/1800),danger=0;
 let target,best=Infinity;
 for(const[id]of w.components.experienceOrbs){const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);if(d<best){best=d;target=t}}
 if(health.current<health.max*.7)for(const[id,event]of w.components.mapEvents){if(event.kind!=='heal')continue;const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);if(d<420){target=t;best=d;break}}
 if(target&&best<340){x=(target.x-p.x)/Math.max(1,best);y=(target.y-p.y)/Math.max(1,best)}
 // Observe/dodge a full telegraphed pattern cycle, then commit to the finale
 // instead of endlessly farming XP. Only normal pointer input is changed.
 if(pursueFinal)for(const[id,monster]of w.components.monsters){if(monster.bossKind!=='final'||(w.components.health.get(id)?.current??0)<=0)continue;
  const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);
  if(d>260){x=(t.x-p.x)/Math.max(1,d);y=(t.y-p.y)/Math.max(1,d)}
  break;
 }
 for(const[id]of w.components.monsters){const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);if(d<155){const force=(155-d)/155*2.2;x+=(p.x-t.x)/Math.max(1,d)*force;y+=(p.y-t.y)/Math.max(1,d)*force;if(d<65)danger++}}
 for(const[id,warning]of w.components.aoeWarnings){if(!warning.damage)continue;const t=w.components.transforms.get(id),d=Math.hypot(t.x-p.x,t.y-p.y);if(warning.safeRadius&&d<warning.safeRadius-8)continue;if(d<t.radius+30){const force=(t.radius+30-d)/Math.max(1,t.radius)*4;x+=(p.x-t.x)/Math.max(1,d)*force;y+=(p.y-t.y)/Math.max(1,d)*force;if(warning.remainingMs<400)danger++}}
 for(const[id]of w.components.enemyProjectiles){const t=w.components.transforms.get(id),v=w.components.velocities.get(id);if(!v)continue;const dx=p.x-t.x,dy=p.y-t.y,speed=Math.hypot(v.x,v.y),arrival=(dx*v.x+dy*v.y)/Math.max(1,speed*speed),miss=Math.abs(dx*v.y-dy*v.x)/Math.max(1,speed);if(arrival>0&&arrival<.55&&miss<48){const side=dx*v.y-dy*v.x>=0?1:-1;x+=v.y/Math.max(1,speed)*side*2;y-=v.x/Math.max(1,speed)*side*2;if(arrival<.22)danger++}}
 const len=Math.max(.01,Math.hypot(x,y));Object.assign(g.input.activePointer,{isDown:true,x:p.x+x/len*220,y:p.y+y/len*220});
 if(danger&&w.components.players.get(g.playerId).dashCooldownMs<=0)a.EventBus.emit('player:dash-request');
}
const priority=['inferno_pierce','pepper_overdrive','thunder_storm','reward_heal','fire_potato','fork_splitter','butter_lube','cheese_armor','peeler_blade','thunder_potato','pepper_gatling','frost_chips','ketchup_aura','magnet_salt','pepper_motor','combo_gear','pickle_crit'];
async function run(seed,stage='meadow',goal,starterSkillId='peeler_blade'){
 const a=await api;a.EventBus.removeAllListeners();const display=displayScene(),g=new a.GameScene();Object.assign(g,display.scene);g.scene={restart(){}};
 g.campaign=new a.CampaignDirector(seed,stage);g.telemetry=new a.RunTelemetry(seed);g.runId=`endurance-${seed}`;g.skillManager=new a.SkillManager({stage,starterSkillId,enforceSlots:true,random:g.campaign.random.bind(g.campaign)});
 g.runStage=stage;g.waveManager=new a.WaveManager(stage);
 g.playerId=a.createPlayer(g.world,0,0,a.ConfigManager.player.moveSpeed,a.ConfigManager.player.maxHp,a.ConfigManager.player.pickupRadius,a.ConfigManager.player.assetId);
 g.cameras.main.getWorldPoint=(x,y)=>({x,y});g.systems=[new a.InputSystem(g,g.playerId),...systems.map(s=>new a[`${s}System`])];
 if(stage==='snow'){
  a.setupSnowIceTerrain(g.world,g.world.components.transforms.get(g.playerId));
  g.systems.splice(systems.indexOf('Boss')+1,0,new a.SnowEnemySystem());
 }
 let offer,result,finalSeen=false,finalId,bossDeathEvents=0,peakEntities=0,peakMonsters=0,peakProjectiles=0,peakHostileProjectiles=0,peakWarnings=0,ticks=0;const checkpoints=[],bossSpawns=[],defeatedBossIds=new Set(),rolesSeen=new Set(),finalPatterns=new Set(),selectedAt={};
 const fieldsSeen=new Set(),monsterIds=new Set(),drafts=[];
 const onDefeated=g.campaign.onMonsterDefeated.bind(g.campaign);
 g.campaign.onMonsterDefeated=(id,alive,remaining)=>{if(bossSpawns.some(b=>b.id===id))defeatedBossIds.add(id);return onDefeated(id,alive,remaining)};
 a.EventBus.on('level:choices',p=>{offer=p;drafts.push({ms:g.stats.elapsedMs,ids:p.choices.map(c=>c.id)})});a.EventBus.on('game:over',p=>result=p);
 a.EventBus.on('boss:spawned',p=>{if(!p)return;bossSpawns.push({id:p.entityId,final:p.final,ms:g.stats.elapsedMs});if(p.final){finalSeen=true;finalId=p.entityId}});
 a.EventBus.on('boss:defeated',()=>bossDeathEvents++);
 a.EventBus.on('boss:phase',p=>{if(p?.bossKind==='final'&&p.pattern)finalPatterns.add(p.pattern)});
 a.EventBus.on('weapon:fired',p=>{if(['pepper_gatling','pepper_overdrive','skewer_javelin','thunder_skewer'].includes(p?.skillId))fieldsSeen.add(p.skillId)});
 const start=performance.now();
 while(!g.gameOver&&g.stats.elapsedMs<(goal?150000:480000)){
  steer(g,a,finalPatterns.size===4);g.update(0,40);ticks++;
  const field=a.getSpatialSkillVisuals(g.world);
  if(field.oilField)fieldsSeen.add(field.oilField.evolved?'wildfire_flask':'hot_oil_flask');
  while(g.choosingSkill&&offer){const health=g.world.components.health.get(g.playerId),choices=offer.choices;
   const selected=[...choices].sort((u,v)=>{const rank=c=>{
    const requirement=goal?.requiredSkills.find(r=>r.id===c.id);
    if(c.id===goal?.preferSkill)return g.skillManager.hasSkill(c.id) ? 100 : -6;
    if(c.id===goal?.resultSkillId)return -5;
    if(requirement&&g.skillManager.getLevel(c.id)<requirement.level)return -4;
    if(c.id==='reward_heal'&&health.current>health.max*.7)return 999;
    return priority.includes(c.id)?priority.indexOf(c.id):100;
   };return rank(u)-rank(v)})[0];
   const selection={skillId:selected.id,sessionId:offer.sessionId};offer=undefined;g.handleSkillSelected(selection);
   selectedAt[selected.id]??=g.stats.elapsedMs;
  }
  peakEntities=Math.max(peakEntities,g.world.entityCount);peakMonsters=Math.max(peakMonsters,g.world.components.monsters.size);peakProjectiles=Math.max(peakProjectiles,g.world.components.projectiles.size);
  peakHostileProjectiles=Math.max(peakHostileProjectiles,g.world.components.enemyProjectiles.size);peakWarnings=Math.max(peakWarnings,g.world.components.aoeWarnings.size);
  assert.ok(g.world.components.enemyProjectiles.size<=72,'shared hostile projectile cap exceeded');assert.ok(g.world.components.aoeWarnings.size<=18,'shared warning cap exceeded');
  for(const monster of g.world.components.monsters.values()){rolesSeen.add(monster.behavior);monsterIds.add(monster.monsterId);}
  if(g.stats.elapsedMs>=checkpoints.length*60000){const h=g.world.components.health.get(g.playerId);checkpoints.push({seconds:Math.round(g.stats.elapsedMs/1000),hp:Math.round(h.current),level:g.world.components.players.get(g.playerId).level,monsters:g.world.components.monsters.size});}
  assert.ok(Number.isFinite(g.world.components.health.get(g.playerId).current));
  if(goal&&g.skillManager.hasSkill(goal.resultSkillId)&&g.stats.elapsedMs>=selectedAt[goal.resultSkillId]+(goal.inspectMs??0))break;
 }
 const finalHp=g.world.components.health.get(finalId),finalTransform=g.world.components.transforms.get(finalId),playerTransform=g.world.components.transforms.get(g.playerId);
 const finalStatus=finalHp&&finalTransform?{hp:finalHp.current,maxHp:finalHp.max,distance:Math.hypot(finalTransform.x-playerTransform.x,finalTransform.y-playerTransform.y)}:undefined;
 const remainingMonsters=[...g.world.components.monsters].map(([id,m])=>({id,role:m.behavior,isBoss:m.isBoss,bossKind:m.bossKind,hp:g.world.components.health.get(id)?.current,distance:Math.round(Math.hypot(g.world.components.transforms.get(id).x-playerTransform.x,g.world.components.transforms.get(id).y-playerTransform.y))}));
 if(!g.gameOver)g.abandonCampaign();g.events.emit('shutdown');
 return {seed,outcome:result?.outcome,seconds:Math.round(g.stats.elapsedMs/1000),remainingMonsters,kills:g.stats.kills,bossKills:g.stats.bossKills,bossDeathEvents,defeatedBossIds:[...defeatedBossIds],bossSpawns,finalDefeated:defeatedBossIds.has(finalId),finalStatus,playerAlive:g.world.components.health.get(g.playerId).current>0,rolesSeen:[...rolesSeen],monsterIds:[...monsterIds],finalPatterns:[...finalPatterns],level:g.world.components.players.get(g.playerId).level,build:g.skillManager.getKnownSkills(),finalSeen,peakEntities,peakMonsters,peakProjectiles,peakHostileProjectiles,peakWarnings,ticks,cpuMs:Math.round(performance.now()-start),checkpoints,report:result?.telemetry,selectedAt,fieldsSeen:[...fieldsSeen],drafts};
}
test('fresh meadow shows the three playstyles in the first three earned drafts, and each casts',async t=>{
 const routes=['pepper_gatling','hot_oil_flask','skewer_javelin'];
 for(const seed of [42,7,31])for(const route of routes){
  const r=await run(seed,'meadow',{preferSkill:route,resultSkillId:route,requiredSkills:[],inspectMs:6000});
  const firstChoices=r.drafts.slice(0,3);
  const shown=firstChoices.find(draft=>draft.ids.includes(route));
  t.diagnostic(JSON.stringify({seed,route,firstDraft:r.drafts[0]?.ms,shownAt:shown?.ms,selected:r.selectedAt[route],casts:r.fieldsSeen}));
  assert.ok(r.drafts[0]?.ms>0&&r.drafts[0].ms<=15000,'first upgrade is earned promptly');
  assert.ok(shown&&r.selectedAt[route]===shown.ms,`${route} did not appear by draft 3`);
  assert.ok(r.fieldsSeen.includes(route),`${route} was selected, but did not cast`);
 }
});
test('earned ranged cards cast both forms before the three-minute finale',async t=>{
 const {ConfigManager}=await api;
 for(const [resultSkillId,seed,stage,baseField,evolvedField] of [
  ['wildfire_flask',42,'meadow','hot_oil_flask','wildfire_flask'],['thunder_skewer',7,'desert','skewer_javelin','thunder_skewer'],
 ]){
  const goal=ConfigManager.skillEvolutions.find(e=>e.resultSkillId===resultSkillId);
  const r=await run(seed,stage,{...goal,inspectMs:2400}),ms=r.selectedAt[resultSkillId];
  t.diagnostic(JSON.stringify({resultSkillId,seed,stage,atSeconds:ms/1000,fields:r.fieldsSeen,selectedAt:r.selectedAt,...(ms===undefined?{drafts:r.drafts,build:r.build}:{})}));
  assert.ok(ms>0&&ms<=130000,'earn the evolution before the finale');
  assert.ok(r.fieldsSeen.includes(baseField)&&r.fieldsSeen.includes(evolvedField),'both forms deploy during the run');
 }
});
test('the new routes can be assembled through earned three-choice upgrades before the finale',async t=>{
 const {ConfigManager}=await api;
 for(const [resultSkillId,seed,stage] of [['peeler_returning',42,'meadow'],['ketchup_surge',7,'meadow'],['corn_crossfire',31,'desert']]){
  const goal=ConfigManager.skillEvolutions.find(item=>item.resultSkillId===resultSkillId);
  assert.ok(goal);
  const r=await run(seed,stage,goal),ms=r.selectedAt[resultSkillId];
  t.diagnostic(JSON.stringify({resultSkillId,seed,stage,atSeconds:ms===undefined?null:ms/1000,level:r.level}));
  // Keep at least 40 seconds to play the completed build before the 3:00 finale.
  assert.ok(ms>0&&ms<=140000, `${resultSkillId} did not form by 2:20: ${JSON.stringify(r.selectedAt)}`);
 }
});
for(const seed of [42,7])test(`normal input/earned-choice endurance reaches a real terminal result for seed ${seed}`,async t=>{
 const r=await run(seed);t.diagnostic(JSON.stringify(r));assert.ok(['victory','defeat'].includes(r.outcome));assert.ok(r.kills>20);assert.ok(r.peakMonsters<300);assert.ok(r.peakProjectiles<500);assert.ok(r.peakEntities<5000);assert.ok(r.report.snapshots.length<256);
 assert.equal(r.bossKills,r.bossDeathEvents);assert.equal(r.bossKills,r.defeatedBossIds.length);
 assert.equal(r.outcome,'victory');assert.equal(r.finalSeen,true);assert.equal(r.finalDefeated,true);assert.equal(r.playerAlive,true);assert.deepEqual(r.bossSpawns.map(s=>s.ms),[60000,110000,150000,180000]);assert.equal(new Set(r.bossSpawns.map(s=>s.id)).size,4);assert.deepEqual(r.bossSpawns.map(s=>s.final),[false,false,false,true]);assert.ok(r.seconds>=180&&r.seconds<=300);assert.ok(r.checkpoints.find(c=>c.seconds===180).level>=10,'the build has time to develop before the finale');
 if(seed===7)for(const role of ['hexer','scatter','sniper','jumper'])assert.ok(r.rolesSeen.includes(role));
 if(seed===42)assert.equal(r.finalPatterns.length,4);
});
test('desert stage completes a full seeded battle with all five specials and no survivors',async t=>{
 const r=await run(7,'desert');
 t.diagnostic(JSON.stringify({outcome:r.outcome,seconds:r.seconds,roles:r.rolesSeen,patterns:r.finalPatterns,remaining:r.remainingMonsters,build:r.build,finalDefeated:r.finalDefeated,finalStatus:r.finalStatus,checkpoints:r.checkpoints}));
 assert.equal(r.outcome,'victory');assert.equal(r.finalDefeated,true);assert.equal(r.remainingMonsters.length,0);
 assert.deepEqual(r.finalPatterns.slice(0,5),['dune_wave','sand_cyclone','sandfall','sand_siege','sand_burrow']);assert.ok(r.rolesSeen.includes('scatter'));assert.ok(r.rolesSeen.includes('bombardier'));
});
for(const [seed,starter] of [[7,'peeler_blade'],[42,'pepper_gatling']])test(`snow campaign reaches settlement with ${starter}`,async t=>{
 const r=await run(seed,'snow',undefined,starter);
 t.diagnostic(JSON.stringify({outcome:r.outcome,seconds:r.seconds,checkpoints:r.checkpoints,patterns:r.finalPatterns,build:r.build,damage:r.report?.damageBySource,remaining:r.remainingMonsters.length,finalStatus:r.finalStatus}));
 assert.equal(r.outcome,'victory');
 assert.deepEqual(r.bossSpawns.map(s=>s.ms),[55000,116000,184000,240000]);
 for(const role of ['snow_guard','snow_needle','snow_roller','snow_elite'])assert.ok(r.monsterIds.includes(role));
 for(const pattern of ['ice_spikes','glacier_charge','avalanche'])assert.ok(r.finalPatterns.includes(pattern));
 assert.equal(r.remainingMonsters.length,0);
 assert.ok(r.seconds>=264&&r.seconds<=315,`outside intended end-to-end duration: ${r.seconds}s`);
});
test('over twenty simulated minutes across fresh runs reproduce outcomes without cross-run buildup',async t=>{
 const runs=[];
 for(let i=0;i<7;i++)runs.push(await run(7));
 assert.ok(runs.reduce((sum,r)=>sum+r.seconds,0)>=1200);
 const comparable=r=>({outcome:r.outcome,kills:r.kills,bossKills:r.bossKills,seconds:r.seconds,peakEntities:r.peakEntities,peakMonsters:r.peakMonsters,peakProjectiles:r.peakProjectiles,build:r.build,damage:r.report.damageBySource});
 for(const r of runs){assert.equal(r.outcome,'victory');assert.deepEqual(comparable(r),comparable(runs[0]));}
 t.diagnostic(JSON.stringify({simulatedMinutes:runs.reduce((sum,r)=>sum+r.seconds,0)/60,runs:runs.length,outcome:runs[0].outcome,peakEntities:runs[0].peakEntities,totalCpuMs:runs.reduce((sum,r)=>sum+r.cpuMs,0)}));
});
