import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { build } from "esbuild";
import { displayScene } from "./ui-runtime-helpers.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({
  stdin: {
    contents: `
      export { World } from "./src/entities/World.ts";
      export { createPlayer, createMonster, createProjectile, createAoeWarning } from "./src/entities/factories.ts";
      export { ConfigManager } from "./src/managers/ConfigManager.ts";
      export { EventBus } from "./src/managers/EventBus.ts";
      export { ProjectileCollisionSystem } from "./src/systems/ProjectileCollisionSystem.ts";
      export { triggerElementalReaction } from "./src/systems/ElementalReactionSystem.ts";
      export { DeathSystem } from "./src/systems/DeathSystem.ts";
      export { AoeWarningSystem } from "./src/systems/AoeWarningSystem.ts";
      export { MonsterBehaviorSystem } from "./src/systems/MonsterBehaviorSystem.ts";
      export { ChapterDirectorSystem } from "./src/systems/ChapterDirectorSystem.ts";
      export { CombatVfxSystem } from "./src/systems/CombatVfxSystem.ts";
      export { InputSystem } from "./src/systems/InputSystem.ts";
    `,
    resolveDir: root,
    loader: "ts",
  },
  bundle: true,
  platform: "node",
  format: "esm",
  write: false,
  plugins: [{
    name: "headless-stable-camera",
    setup(context) {
      context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless-stable-camera" }));
      context.onLoad({ filter: /.*/, namespace: "headless-stable-camera" }, () => ({
        contents: `import EventEmitter from "eventemitter3";
          export default {
            Events: { EventEmitter },
            Scenes: { Events: { SHUTDOWN: "shutdown" } },
            BlendModes: { NORMAL: 0, ADD: 1 },
            Input: {
              Keyboard: {
                KeyCodes: { W: "w", A: "a", S: "s", D: "d", SPACE: "space" },
                JustDown: key => { const pressed = key.justDown; key.justDown = false; return pressed; },
              },
              Events: { POINTER_UP: "pointerup", POINTER_UP_OUTSIDE: "pointerupoutside" },
            },
            Math: {
              Clamp: (value, minimum, maximum) => Math.min(maximum, Math.max(minimum, value)),
              Between: (minimum, maximum) => Math.floor((minimum + maximum) / 2),
              FloatBetween: (minimum, maximum) => (minimum + maximum) / 2,
            },
          };`,
        resolveDir: root,
      }));
    },
  }],
}).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

const eventNames = ["combat:damage", "combat:vfx", "combat:reaction", "weapon:impact", "fx:sparks", "juice:death", "hostile:impact", "boss:defeated", "boss:phase", "level:chapter", "hero:dash"];

async function fixture(hasTextures = true) {
  const api = await modules;
  api.EventBus.removeAllListeners();
  const display = displayScene(1280, 720, hasTextures);
  display.scene.cameras.main.worldView = { x: 0, y: 0, width: 1280, height: 720 };
  const world = new api.World();
  const playerId = api.createPlayer(world, 250, 250, 220, 100, 145);
  const events = [];
  for (const name of eventNames) api.EventBus.on(name, payload => events.push({ name, payload }));
  return {
    ...api,
    ...display,
    world,
    playerId,
    events,
    stats: { elapsedMs: 0, kills: 0, bossKills: 0, gold: 0 },
    skillManager: { hasSkill: () => false, getLevel: () => 0, getMoveSpeedBonus: () => 0, getPickupRadiusBonus: () => 0 },
  };
}

function monster(runtime, x = 350, y = 250, isBoss = false) {
  return runtime.createMonster(runtime.world, runtime.ConfigManager.getMonster("fries_cultist"), x, y, isBoss);
}

function projectile(runtime, kind, damage = 10, effects = [], critChance = 0) {
  return runtime.createProjectile(runtime.world, 350, 250, 400, 0, "stable-camera-test", damage, 0, 1000, 0x69e8ff, 12, effects, critChance, 2, undefined, kind);
}

function assertStableCamera(runtime) {
  assert.equal(runtime.scene.cameras.main.shakes, 0, "combat feedback must not shake the whole camera");
  assert.equal(runtime.scene.cameras.main.flashes, 0, "combat feedback must not flash the whole camera");
}

function emitted(runtime, name) {
  return runtime.events.filter(event => event.name === name).map(event => event.payload);
}

for (const kind of ["kinetic", "peeler", "fire", "frost", "lightning", "poison", "explosion", "ketchup"]) {
  test(`${kind} projectile impact preserves damage and localized feedback without camera effects`, async () => {
    const runtime = await fixture();
    const targetId = monster(runtime);
    runtime.world.components.health.get(targetId).current = 200;
    const projectileId = projectile(runtime, kind);
    new runtime.ProjectileCollisionSystem().update(16, runtime);
    assert.equal(runtime.world.components.health.get(targetId).current, 190);
    assert.equal(runtime.world.components.projectiles.has(projectileId), false);
    assert.ok(runtime.world.components.hitFlashes.has(targetId));
    assert.equal(emitted(runtime, "combat:damage")[0].value, 10);
    assert.equal(emitted(runtime, "weapon:impact")[0].vfxKind, kind);
    assert.equal(emitted(runtime, "weapon:impact")[0].critical, false);
    assert.ok(emitted(runtime, "fx:sparks").length > 0);
    assertStableCamera(runtime);
  });
}

test("critical projectile preserves doubled damage and critical impact without camera effects", async () => {
  const runtime = await fixture();
  const targetId = monster(runtime);
  runtime.world.components.health.get(targetId).current = 200;
  projectile(runtime, "kinetic", 10, [], 1);
  new runtime.ProjectileCollisionSystem().update(16, runtime);
  assert.equal(runtime.world.components.health.get(targetId).current, 180);
  assert.equal(emitted(runtime, "combat:damage")[0].isCrit, true);
  assert.equal(emitted(runtime, "weapon:impact")[0].critical, true);
  assert.ok(emitted(runtime, "fx:sparks").length > 0);
  assertStableCamera(runtime);
});

for (const radius of [96, 260]) {
  test(`radius ${radius} explosion preserves splash, knockback and sparks without camera effects`, async () => {
    const runtime = await fixture();
    const targetId = monster(runtime);
    const neighborId = monster(runtime, 400, 250);
    for (const target of [targetId, neighborId]) runtime.world.components.health.get(target).current = 200;
    projectile(runtime, "explosion", 10, [{ type: "explosion", radius, damageMultiplier: 1 }]);
    new runtime.ProjectileCollisionSystem().update(16, runtime);
    assert.equal(runtime.world.components.health.get(targetId).current, 180);
    assert.equal(runtime.world.components.health.get(neighborId).current, 190);
    assert.equal(runtime.world.components.knockbacks.get(neighborId).x, radius >= 220 ? 540 : 360);
    assert.equal(emitted(runtime, "combat:vfx")[0].kind, "explosion");
    assert.equal(emitted(runtime, "combat:vfx")[0].radius, radius);
    assert.ok(emitted(runtime, "fx:sparks").some(payload => payload.count === (radius >= 220 ? 42 : 16)));
    assertStableCamera(runtime);
  });
}

for (const [incomingKind, setupStatus, reactionKind] of [
  ["fire", "poison", "toxic_ignition"],
  ["lightning", "freeze", "superconduct"],
  ["peeler", "freeze", "shatter"],
  ["frost", "burn", "thermal_shock"],
]) {
  test(`${reactionKind} consumes status and preserves reaction damage/VFX without camera effects`, async () => {
    const runtime = await fixture();
    const targetId = monster(runtime);
    const neighborId = monster(runtime, 380, 250);
    for (const target of [targetId, neighborId]) runtime.world.components.health.get(target).current = 200;
    runtime.world.components.statuses.set(targetId, [{ type: setupStatus, remainingMs: 1000, totalMs: 1000, damagePerSecond: 10, slowMultiplier: 0.5 }]);
    const reaction = runtime.triggerElementalReaction(runtime, targetId, incomingKind, 20);
    assert.equal(reaction.kind, reactionKind);
    assert.equal(runtime.world.components.statuses.has(targetId), false);
    assert.equal(runtime.world.components.health.get(targetId).current, 200 - Math.ceil(20 * reaction.bonusDamageMultiplier));
    assert.equal(runtime.world.components.health.get(neighborId).current, 200 - Math.ceil(20 * reaction.splashDamageMultiplier));
    assert.ok(runtime.world.components.knockbacks.has(targetId));
    assert.ok(runtime.world.components.hitFlashes.has(targetId));
    assert.equal(emitted(runtime, "combat:reaction")[0].kind, reactionKind);
    assert.equal(emitted(runtime, "combat:reaction")[0].affectedTargets, 2);
    assert.ok(emitted(runtime, "combat:damage").every(payload => payload.isReaction));
    assertStableCamera(runtime);
  });
}

for (const isBoss of [false, true]) {
  test(`${isBoss ? "boss" : "ordinary"} death preserves XP, kills and death feedback without camera effects`, async () => {
    const runtime = await fixture();
    const targetId = monster(runtime, 350, 250, isBoss);
    const experience = runtime.world.components.monsters.get(targetId).experienceValue;
    runtime.world.components.health.get(targetId).current = 0;
    new runtime.DeathSystem().update(16, runtime);
    assert.equal(runtime.stats.kills, 1);
    assert.equal(runtime.stats.bossKills, isBoss ? 1 : 0);
    assert.equal(runtime.world.components.monsters.has(targetId), false);
    assert.equal(runtime.world.components.experienceOrbs.size, isBoss ? 11 : 1);
    assert.ok([...runtime.world.components.experienceOrbs.values()].every(orb => orb.value === experience));
    assert.equal(emitted(runtime, "boss:defeated").length, isBoss ? 1 : 0);
    assert.equal(emitted(runtime, "juice:death").length, 1);
    assert.ok(emitted(runtime, "fx:sparks").length > 0);
    assertStableCamera(runtime);
  });
}

test("simultaneous toxic deaths trigger only one five-target poison splash without camera effects", async () => {
  const runtime = await fixture();
  runtime.skillManager.hasSkill = skillId => skillId === "toxic_burst_cloud";
  const sourceId = monster(runtime);
  runtime.world.components.health.get(sourceId).current = 0;
  runtime.world.components.health.get(monster(runtime)).current = 0;
  const neighbors = Array.from({ length: 5 }, (_, index) => monster(runtime, 380 + index * 8, 250));
  for (const targetId of neighbors) runtime.world.components.health.get(targetId).current = 200;
  new runtime.DeathSystem().update(16, runtime);
  for (const targetId of neighbors) {
    assert.equal(runtime.world.components.health.get(targetId).current, 193);
    assert.equal(runtime.world.components.statuses.get(targetId)[0].type, "poison");
  }
  assert.equal(runtime.stats.kills, 2);
  assert.equal(emitted(runtime, "combat:damage").length, 5);
  assert.equal(emitted(runtime, "combat:vfx")[0].kind, "poison");
  assert.ok(emitted(runtime, "fx:sparks").some(payload => payload.color === 0x70e000));
  assertStableCamera(runtime);
});

test("elite death bomb preserves player damage and explosion feedback without camera effects", async () => {
  const runtime = await fixture();
  const sourceId = monster(runtime, 250, 250);
  Object.assign(runtime.world.components.monsters.get(sourceId), { isElite: true, eliteAffix: "death_bomb", damage: 10 });
  runtime.world.components.health.get(sourceId).current = 0;
  new runtime.DeathSystem().update(16, runtime);
  assert.equal(runtime.world.components.health.get(runtime.playerId).current, 84);
  assert.equal(runtime.world.components.players.get(runtime.playerId).damageCooldownMs, 700);
  assert.deepEqual(emitted(runtime, "hostile:impact"), [{ x: 250, y: 250, radius: 118, style: "oil" }]);
  assert.equal(emitted(runtime, "combat:damage")[0].value, 16);
  assert.ok(!emitted(runtime, "fx:sparks").some(payload => payload.color === 0xff4800), "do not double-render the explosion");
  assertStableCamera(runtime);
});

test("elite split death preserves children and local announcement without camera effects", async () => {
  const runtime = await fixture();
  const sourceId = monster(runtime);
  Object.assign(runtime.world.components.monsters.get(sourceId), { isElite: true, eliteAffix: "split" });
  runtime.world.components.health.get(sourceId).current = 0;
  new runtime.DeathSystem().update(16, runtime);
  assert.equal(runtime.world.components.monsters.size, 3);
  assert.ok([...runtime.world.components.monsters.values()].every(child => !child.isElite && child.speedMultiplier === 1.18));
  assert.equal(runtime.stats.kills, 1);
  assert.equal(emitted(runtime, "boss:phase")[0].text, "精英分裂！");
  assert.ok(emitted(runtime, "fx:sparks").some(payload => payload.color === 0x4cc9f0));
  assertStableCamera(runtime);
});

for (const inSafeZone of [false, true]) {
  test(`hostile warning ${inSafeZone ? "safe zone" : "detonation"} preserves damage gate and local sparks without camera effects`, async () => {
    const runtime = await fixture();
    const warningId = runtime.createAoeWarning(runtime.world, 250, 250, 150, 15, 1, inSafeZone ? 30 : undefined);
    new runtime.AoeWarningSystem().update(16, runtime);
    assert.equal(runtime.world.components.aoeWarnings.has(warningId), false);
    assert.equal(runtime.world.components.health.get(runtime.playerId).current, inSafeZone ? 100 : 85);
    assert.equal(runtime.world.components.players.get(runtime.playerId).damageCooldownMs, inSafeZone ? 0 : 700);
    assert.equal(emitted(runtime, "combat:damage").length, inSafeZone ? 0 : 1);
    assert.equal(emitted(runtime, "fx:sparks")[0].count, 26);
    assertStableCamera(runtime);
  });
}

test("hostile exploder preserves contact explosion, damage recovery and death sparks without camera effects", async () => {
  const runtime = await fixture();
  const sourceId = runtime.createMonster(runtime.world, runtime.ConfigManager.getMonster("ketchup_slug"), 250, 250);
  runtime.world.components.monsters.get(sourceId).damage = 10;
  new runtime.MonsterBehaviorSystem().update(16, runtime);
  assert.equal(runtime.world.components.monsters.has(sourceId), false);
  assert.equal(runtime.world.components.health.get(runtime.playerId).current, 78);
  assert.equal(runtime.world.components.players.get(runtime.playerId).damageCooldownMs, 700);
  assert.equal(emitted(runtime, "combat:damage")[0].value, 22);
  assert.equal(emitted(runtime, "juice:death").length, 1);
  assert.equal(emitted(runtime, "fx:sparks")[0].count, 18);
  assertStableCamera(runtime);
});

for (const elapsedMs of [10000, 24000]) {
  test(`chapter at ${elapsedMs}ms preserves single transition and captain state without camera effects`, async () => {
    const runtime = await fixture();
    runtime.stats.elapsedMs = elapsedMs;
    const director = new runtime.ChapterDirectorSystem();
    director.update(16, runtime);
    director.update(16, runtime);
    assert.equal(emitted(runtime, "level:chapter").length, 1);
    assert.equal(emitted(runtime, "level:chapter")[0].id, elapsedMs === 10000 ? "tomato_ambush" : "delivery_hunt");
    assert.equal(runtime.world.components.monsters.size, elapsedMs === 24000 ? 1 : 0);
    if (elapsedMs === 24000) {
      const captain = [...runtime.world.components.monsters.values()][0];
      assert.equal(captain.isElite, true);
      assert.equal(captain.eliteAffix, "shield");
      assert.ok(captain.shieldHp > 0);
      assert.equal(emitted(runtime, "boss:phase").length, 1);
      assert.equal(emitted(runtime, "fx:sparks")[0].count, 24);
    }
    assert.equal(runtime.scene.cameras.main.flashes, 0, "chapter transitions must not flash the whole camera");
    assertStableCamera(runtime);
  });
}

for (const hasTextures of [false, true]) {
  test(`actual dash preserves ${hasTextures ? "textured" : "fallback"} afterimages and movement without camera effects`, async () => {
    const runtime = await fixture(hasTextures);
    runtime.world.components.renders.get(runtime.playerId).assetId = runtime.ConfigManager.player.assetId;
    const vfx = new runtime.CombatVfxSystem(runtime.scene);
    const input = new runtime.InputSystem(runtime.scene, runtime.playerId);
    runtime.EventBus.emit("player:dash-request");
    input.update(16, runtime);
    const player = runtime.world.components.players.get(runtime.playerId);
    assert.ok(player.dashRemainingMs > 0);
    assert.ok(player.dashCooldownMs > 0);
    assert.ok(runtime.world.components.velocities.get(runtime.playerId).x > player.moveSpeed);
    assert.equal(emitted(runtime, "hero:dash").length, 1);
    assert.equal(runtime.objects.filter(object => object.kind === (hasTextures ? "image" : "circle")).length, 3);
    assert.ok(runtime.objects.some(object => object.kind === "graphics" && object.calls.some(call => call[0] === "strokeEllipse")));
    assert.equal(runtime.tweens.length, 4);
    const camera = { shakes: runtime.scene.cameras.main.shakes, flashes: runtime.scene.cameras.main.flashes };
    runtime.scene.events.emit("shutdown");
    vfx.destroy();
    assert.equal(runtime.EventBus.listenerCount("hero:dash"), 1);
    assert.equal(camera.shakes, 0, "dash feedback must not shake the whole camera");
    assert.equal(camera.flashes, 0, "dash feedback must not flash the whole camera");
  });
}
