import { createCanvas, loadImage } from '@napi-rs/canvas';
import { writeFile } from 'node:fs/promises';

// RemBg exports already contain alpha; resize without chroma keying or redrawing.
const entries = [
  ['cactus', 'public/assets/enemies/desert-v1/cactus.png', 512],
  ['scorpion', 'public/assets/enemies/desert-v1/scorpion.png', 512],
  ['sultan', 'public/assets/bosses/desert_sultan/idle-v1.png', 768],
];
for (const [name, destination, size] of entries) {
  const image = await loadImage(`artifacts/desert-enemies-2026-11-19/${name}-cutout.png`);
  const canvas = createCanvas(size, size);
  canvas.getContext('2d').drawImage(image, 0, 0, size, size);
  await writeFile(destination, await canvas.encode('png'));
}
