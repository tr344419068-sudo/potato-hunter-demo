#!/usr/bin/env python3
"""Pack Cethiel's CC0 OpenGameArt PNG sequences into transparent WebP sheets."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

from PIL import Image, ImageOps

SOURCES = {
    'slash': ('weapon-slash-effect', 'Classic.zip'),
    'earth': ('earth-impact-magic-effect', 'Earth%20Impact%20-%20Magic%20Effect.zip'),
}
CLIPS = [
    ('sweep', 'slash', 'Classic/1/Classic_', 1, 6, 128, None),
    ('lunge', 'slash', 'Classic/5/Classic_', 25, 6, 96, None),
    ('bomb-debris', 'earth', '4/Earth-Impact_', 16, 5, 96, ('#612316', '#d47629', '#ffdc83')),
    ('shield-break', 'earth', '5/Earth-Impact_', 21, 5, 96, ('#20588a', '#79d6ff', '#e7ffff')),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pack(archives, output):
    output.mkdir(parents=True, exist_ok=True)
    manifest = []
    for name, source, prefix, first, count, size, palette in CLIPS:
        slug, remote_zip = SOURCES[source]
        archive = archives / f'{source}.zip'
        entries = [f'{prefix}{i:02d}.png' for i in range(first, first + count)]
        sheet = Image.new('RGBA', (size * count, size))
        with ZipFile(archive) as bundle:
            for index, entry in enumerate(entries):
                with bundle.open(entry) as png:
                    sprite = Image.open(png).convert('RGBA')
                if palette:
                    alpha = sprite.getchannel('A')
                    sprite = ImageOps.colorize(ImageOps.grayscale(sprite).point(lambda v: min(255, v * 2 + 18)),
                                               black=palette[0], mid=palette[1], white=palette[2]).convert('RGBA')
                    sprite.putalpha(alpha)
                sprite.thumbnail((size - 4, size - 4), Image.Resampling.LANCZOS)
                sheet.paste(sprite, (index * size + (size - sprite.width) // 2, (size - sprite.height) // 2))
        path = output / f'{name}.webp'
        sheet.save(path, 'WEBP', quality=88, alpha_quality=100, method=6)
        manifest.append(dict(file=path.name, author='Cethiel', license='CC0-1.0',
                             source=f'https://opengameart.org/content/{slug}',
                             archive=f'https://opengameart.org/sites/default/files/{remote_zip}',
                             archiveSha256=digest(archive), entries=entries, palette=palette,
                             transform='Center source frames without individual trimming; resize proportionally; retain alpha; pack left to right.',
                             dimensions=list(sheet.size), sha256=digest(path)))
    (output / 'sources.json').write_text(json.dumps({'outputs': manifest}, indent=2) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archives', type=Path, help='Directory containing slash.zip and earth.zip')
    parser.add_argument('--output', type=Path, default=Path('public/assets/vfx/cethiel-enemy-v1'))
    args = parser.parse_args()
    pack(args.archives, args.output)
