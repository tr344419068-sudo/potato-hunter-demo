import { mkdir, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import { createHash } from "node:crypto";

const SAMPLE_RATE = 24000;
const TAU = Math.PI * 2;
const GENERATOR_SEED = 20261118;

function seededRandom(seed) {
  let state = seed >>> 0;
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return (state >>> 0) / 4294967296;
  };
}

function seedFor(name) {
  let seed = GENERATOR_SEED;
  for (const character of name) seed = Math.imul(seed ^ character.charCodeAt(0), 16777619);
  return seed >>> 0;
}

function frequency(midi) { return 440 * 2 ** ((midi - 69) / 12); }

function canvas(duration, loop = false) {
  const frames = Math.round(duration * SAMPLE_RATE);
  return { left: new Float64Array(frames), right: new Float64Array(frames), frames, loop };
}

function addVoice(buffer, options) {
  const { start = 0, duration, frequency: pitch = 440, endFrequency = pitch, amplitude = 0.2, pan = 0, kind = "pluck", seed = 1 } = options;
  const first = Math.round(start * SAMPLE_RATE);
  const length = Math.ceil(duration * SAMPLE_RATE);
  const random = seededRandom(seed);
  let phase = 0;
  let filteredNoise = 0;
  const leftGain = Math.sqrt((1 - Math.max(-1, Math.min(1, pan))) * 0.5);
  const rightGain = Math.sqrt((1 + Math.max(-1, Math.min(1, pan))) * 0.5);
  for (let frame = 0; frame < length; frame++) {
    const time = frame / SAMPLE_RATE;
    const progress = time / duration;
    const hz = pitch * (endFrequency / pitch) ** progress;
    phase += TAU * hz / SAMPLE_RATE;
    const noise = random() * 2 - 1;
    filteredNoise = filteredNoise * 0.82 + noise * 0.18;
    let signal;
    let envelope;
    const attack = Math.min(1, time / (kind === "pad" ? 0.08 : 0.004));
    const release = Math.min(1, Math.max(0, (duration - time) / (kind === "pad" ? 0.12 : 0.025)));
    switch (kind) {
      case "noise": signal = noise * 0.6 + filteredNoise * 1.5; envelope = Math.exp(-progress * 5); break;
      case "air": signal = filteredNoise * 3; envelope = Math.sin(Math.PI * progress) ** 1.3; break;
      case "kick": signal = Math.sin(phase); envelope = Math.exp(-progress * 8); break;
      case "bell": signal = Math.sin(phase) + Math.sin(phase * 2.73) * 0.36 + Math.sin(phase * 4.11) * 0.12; envelope = Math.exp(-progress * 5); break;
      case "electric": signal = Math.sin(phase + Math.sin(phase * 3) * 1.9) * 0.75 + noise * 0.15; envelope = Math.exp(-progress * 4); break;
      case "reed": signal = Math.sin(phase) + Math.sin(phase * 2) * 0.25 + Math.sin(phase * 3) * 0.14; envelope = Math.sin(Math.PI * progress) * Math.exp(-progress * 2); break;
      case "pad": signal = Math.sin(phase) + Math.sin(phase * 2 + 0.2) * 0.12; envelope = Math.sin(Math.PI * progress) ** 0.4; break;
      default: signal = Math.sin(phase) + Math.sin(phase * 2) * 0.32 * Math.exp(-time * 18) + Math.sin(phase * 3) * 0.16 * Math.exp(-time * 28); envelope = Math.exp(-progress * 5);
    }
    const sample = signal * envelope * attack * release * amplitude;
    let index = first + frame;
    if (buffer.loop) index = ((index % buffer.frames) + buffer.frames) % buffer.frames;
    if (index >= buffer.frames || index < 0) continue;
    buffer.left[index] += sample * leftGain;
    buffer.right[index] += sample * rightGain;
  }
}

function addRoom(buffer, amount, delaySeconds = 0.071) {
  const dryLeft = buffer.left.slice();
  const dryRight = buffer.right.slice();
  for (const [tap, gain] of [[delaySeconds, amount], [delaySeconds * 1.71, amount * 0.53], [delaySeconds * 2.39, amount * 0.28]]) {
    const delay = Math.round(tap * SAMPLE_RATE);
    for (let frame = 0; frame < buffer.frames; frame++) {
      const previous = frame - delay;
      const index = buffer.loop ? (previous + buffer.frames) % buffer.frames : previous;
      if (index < 0) continue;
      buffer.left[frame] += dryRight[index] * gain;
      buffer.right[frame] += dryLeft[index] * gain;
    }
  }
}

function encodeWav(buffer, ceiling) {
  let averageLeft = 0;
  let averageRight = 0;
  for (let frame = 0; frame < buffer.frames; frame++) { averageLeft += buffer.left[frame]; averageRight += buffer.right[frame]; }
  averageLeft /= buffer.frames;
  averageRight /= buffer.frames;
  let peak = 0;
  for (let frame = 0; frame < buffer.frames; frame++) {
    buffer.left[frame] = Math.tanh((buffer.left[frame] - averageLeft) * 1.2);
    buffer.right[frame] = Math.tanh((buffer.right[frame] - averageRight) * 1.2);
    peak = Math.max(peak, Math.abs(buffer.left[frame]), Math.abs(buffer.right[frame]));
  }
  const scale = ceiling / Math.max(peak, 0.00001);
  const wav = Buffer.alloc(44 + buffer.frames * 4);
  wav.write("RIFF", 0);
  wav.writeUInt32LE(wav.length - 8, 4);
  wav.write("WAVEfmt ", 8);
  wav.writeUInt32LE(16, 16);
  wav.writeUInt16LE(1, 20);
  wav.writeUInt16LE(2, 22);
  wav.writeUInt32LE(SAMPLE_RATE, 24);
  wav.writeUInt32LE(SAMPLE_RATE * 4, 28);
  wav.writeUInt16LE(4, 32);
  wav.writeUInt16LE(16, 34);
  wav.write("data", 36);
  wav.writeUInt32LE(buffer.frames * 4, 40);
  let energy = 0;
  for (let frame = 0; frame < buffer.frames; frame++) {
    const edge = buffer.loop ? 1 : Math.min(1, frame / (SAMPLE_RATE * 0.003), (buffer.frames - frame - 1) / (SAMPLE_RATE * 0.014));
    const left = buffer.left[frame] * scale * Math.max(0, edge);
    const right = buffer.right[frame] * scale * Math.max(0, edge);
    if (!Number.isFinite(left) || !Number.isFinite(right)) throw new Error("Non-finite synthesized sample");
    wav.writeInt16LE(Math.round(Math.max(-0.999, Math.min(0.999, left)) * 32767), 44 + frame * 4);
    wav.writeInt16LE(Math.round(Math.max(-0.999, Math.min(0.999, right)) * 32767), 46 + frame * 4);
    energy += left * left + right * right;
  }
  return { wav, peak: ceiling, rms: Math.sqrt(energy / (buffer.frames * 2)) };
}

const SOUND_RECIPES = [
  ["launch-peeler", 0.24, [["air", 1600, 800, 0.27], ["bell", 1100, 1700, 0.15]]],
  ["launch-fire", 0.31, [["air", 300, 1100, 0.42], ["reed", 130, 260, 0.30]]],
  ["launch-ice", 0.28, [["bell", 1700, 2400, 0.22], ["air", 900, 1900, 0.18]]],
  ["launch-lightning", 0.22, [["electric", 450, 2100, 0.20], ["noise", 2000, 800, 0.12]]],
  ["launch-poison", 0.34, [["pluck", 420, 160, 0.28], ["air", 250, 600, 0.24]]],
  ["launch-explosion", 0.35, [["kick", 160, 70, 0.46], ["air", 700, 400, 0.22]]],
  ["launch-rapid", 0.14, [["pluck", 370, 190, 0.27], ["noise", 800, 500, 0.17]]],
  ["impact-organic", 0.22, [["kick", 190, 75, 0.42], ["noise", 400, 200, 0.23]]],
  ["impact-metal", 0.29, [["bell", 1250, 1250, 0.28], ["noise", 2800, 1900, 0.19]]],
  ["impact-fire", 0.36, [["noise", 500, 200, 0.35], ["kick", 170, 65, 0.37]]],
  ["impact-ice", 0.38, [["bell", 2100, 1600, 0.27], ["noise", 3300, 1800, 0.17]]],
  ["impact-electric", 0.27, [["electric", 1200, 320, 0.25], ["bell", 1760, 1760, 0.13]]],
  ["impact-toxic", 0.40, [["pluck", 300, 85, 0.33], ["noise", 450, 190, 0.19]]],
  ["impact-explosive", 0.62, [["kick", 95, 32, 0.66], ["noise", 500, 100, 0.37], ["air", 280, 70, 0.20]]],
  ["critical", 0.40, [["bell", 1320, 1650, 0.24], ["pluck", 660, 660, 0.24], ["noise", 2000, 1600, 0.10]]],
  ["shield", 0.38, [["bell", 780, 780, 0.28], ["electric", 260, 380, 0.16]]],
  ["dash", 0.28, [["air", 900, 260, 0.40], ["pluck", 320, 700, 0.16]]],
  ["pickup", 0.24, [["bell", 880, 1320, 0.22], ["pluck", 660, 990, 0.14]]],
  ["upgrade", 0.95, [["bell", 660, 990, 0.15], ["pluck", 330, 660, 0.20]]],
  ["boss-danger", 1.10, [["reed", 110, 87.31, 0.43], ["bell", 311.13, 311.13, 0.20], ["kick", 75, 38, 0.40]]],
  ["player-hurt", 0.32, [["reed", 290, 110, 0.27], ["noise", 700, 250, 0.16]]],
  ["victory", 2.10, [["pad", 261.63, 261.63, 0.10], ["bell", 523.25, 523.25, 0.08]]],
  ["defeat", 1.65, [["pad", 146.83, 146.83, 0.12], ["reed", 220, 146.83, 0.16]]],
];

function makeSound(id, duration, recipe) {
  const buffer = canvas(duration);
  recipe.forEach(([kind, pitch, endFrequency, amplitude], index) => addVoice(buffer, { kind, frequency: pitch, endFrequency, amplitude, duration: duration * 0.83, start: index * 0.009, pan: index % 2 ? 0.2 : -0.2, seed: seedFor(`${id}:${index}`) }));
  const melodic = id === "upgrade" ? [72, 76, 79, 84] : id === "victory" ? [72, 76, 79, 84, 83, 84, 88] : id === "defeat" ? [67, 65, 62, 57] : [];
  melodic.forEach((note, index) => addVoice(buffer, { kind: id === "defeat" ? "reed" : "pluck", frequency: frequency(note), start: 0.03 + index * (id === "upgrade" ? 0.14 : 0.22), duration: 0.42, amplitude: 0.24, pan: index % 2 ? 0.25 : -0.25, seed: index + 1 }));
  if (id === "boss-danger") {
    for (const start of [0.05, 0.39, 0.73]) addVoice(buffer, { kind: "bell", frequency: 233.08, start, duration: 0.28, amplitude: 0.17, seed: 4 });
  }
  addRoom(buffer, id === "victory" || id === "defeat" ? 0.17 : 0.07);
  return { buffer, melody: melodic, layers: recipe.map(([kind]) => kind).concat(melodic.length ? ["authored-note-phrase"] : []) };
}

const MUSIC_PHRASES = [
  { id: "music-calm", bpm: 96, roots: [48, 53, 55, 48, 57, 53, 55, 48], qualities: [0, 0, 0, 0, -1, 0, 0, 0], melody: [72, 76, 79, 76, 74, 77, 81, 77, 74, 79, 83, 79, 76, 79, 84, 79, 76, 81, 84, 81, 77, 81, 84, 81, 79, 83, 86, 83, 79, 76, 74, 72], layers: ["warm-plucked-melody", "soft-triad-pad", "rounded-bass", "woodblock-backbeat", "brushed-shaker"] },
  { id: "music-combat", bpm: 120, roots: [48, 55, 57, 53, 48, 55, 53, 55], qualities: [0, 0, -1, 0, 0, 0, 0, 0], melody: [72, 79, 76, 79, 74, 79, 83, 79, 76, 81, 79, 84, 77, 81, 84, 81, 72, 76, 79, 84, 74, 79, 83, 86, 77, 81, 79, 77, 79, 83, 86, 83], layers: ["syncopated-pluck-hook", "offbeat-chord-stabs", "eighth-note-bass", "kick-snare-groove", "stereo-shaker", "second-half-bell-counterline"] },
  { id: "music-boss", bpm: 132, roots: [45, 41, 43, 40, 45, 41, 43, 40], qualities: [-1, 0, 0, 0, -1, 0, 0, 0], melody: [69, 72, 76, 72, 65, 69, 72, 69, 67, 70, 74, 70, 68, 71, 76, 71, 69, 76, 81, 76, 65, 72, 77, 72, 67, 74, 79, 74, 68, 71, 76, 80], layers: ["minor-plucked-ostinato", "low-triad-pad", "pulsing-bass", "timpani-like-kick", "dark-bell-counterline", "snare-shaker"] },
];

function makeMusic(phrase) {
  const beat = 60 / phrase.bpm;
  const buffer = canvas(beat * 32, true);
  const boss = phrase.id === "music-boss";
  const calm = phrase.id === "music-calm";
  for (let bar = 0; bar < 8; bar++) {
    const root = phrase.roots[bar];
    const start = bar * 4 * beat;
    const chord = [root + 12, root + (phrase.qualities[bar] === -1 ? 15 : 16), root + 19];
    for (const [index, note] of chord.entries()) {
      addVoice(buffer, { kind: "pad", frequency: frequency(note), start, duration: beat * 4.3, amplitude: calm ? 0.075 : 0.045, pan: (index - 1) * 0.35 });
      if (!calm) for (const offset of [0.5, 1.5, 2.5, 3.5]) addVoice(buffer, { kind: "pluck", frequency: frequency(note + 12), start: start + offset * beat, duration: beat * 0.55, amplitude: 0.052, pan: (index - 1) * 0.4 });
    }
    for (let step = 0; step < (calm ? 4 : 8); step++) {
      addVoice(buffer, { kind: "pluck", frequency: frequency(root + (step % 4 === 2 ? 7 : 0)), start: start + step * beat * (calm ? 1 : 0.5), duration: beat * 0.65, amplitude: calm ? 0.17 : 0.21, pan: -0.08 });
    }
    for (let step = 0; step < 4; step++) {
      const note = phrase.melody[bar * 4 + step];
      addVoice(buffer, { kind: boss ? "bell" : "pluck", frequency: frequency(note), start: start + (step + (step % 2 ? 0.07 : 0)) * beat, duration: beat * 0.95, amplitude: calm ? 0.16 : 0.14, pan: step % 2 ? 0.28 : -0.28 });
      if (!calm) addVoice(buffer, { kind: "pluck", frequency: frequency(note + (boss ? -12 : 7)), start: start + (step + 0.5) * beat, duration: beat * 0.35, amplitude: bar >= 4 ? 0.085 : 0.045, pan: step % 2 ? -0.38 : 0.38 });
      if (step % 2 === 0 || (!calm && step === 3)) addVoice(buffer, { kind: "kick", frequency: boss ? 105 : 125, endFrequency: boss ? 42 : 48, start: start + step * beat, duration: beat * 0.48, amplitude: calm ? 0.17 : 0.32 });
      if (step % 2 === 1) {
        addVoice(buffer, { kind: "noise", start: start + step * beat, duration: 0.12, amplitude: calm ? 0.065 : 0.11, seed: seedFor(`${phrase.id}:snare:${bar}:${step}`), pan: 0.16 });
        addVoice(buffer, { kind: "pluck", frequency: calm ? 760 : 280, endFrequency: calm ? 490 : 190, start: start + step * beat, duration: 0.09, amplitude: 0.11, pan: -0.16 });
      }
    }
    for (let step = 0; step < 8; step++) addVoice(buffer, { kind: "noise", start: start + step * beat * 0.5, duration: step % 2 ? 0.095 : 0.05, amplitude: calm ? 0.024 : 0.042, pan: step % 2 ? 0.48 : -0.48, seed: seedFor(`${phrase.id}:hat:${bar}:${step}`) });
  }
  addRoom(buffer, 0.13, 0.089);
  return buffer;
}

export async function generateGameAudio(outputDirectory = fileURLToPath(new URL("../public/assets/audio/", import.meta.url))) {
  await mkdir(outputDirectory, { recursive: true });
  const assets = [];
  async function save(id, buffer, metadata) {
    const { wav, peak, rms } = encodeWav(buffer, buffer.loop ? 0.78 : 0.82);
    const file = `${id}.wav`;
    await writeFile(resolve(outputDirectory, file), wav);
    assets.push({ id, file, format: "PCM16 stereo WAV", sampleRate: SAMPLE_RATE, durationSeconds: buffer.frames / SAMPLE_RATE, loop: buffer.loop, masteredPeak: peak, rms, sha256: createHash("sha256").update(wav).digest("hex"), ...metadata });
  }
  for (const [id, duration, recipe] of SOUND_RECIPES) {
    const { buffer, layers, melody } = makeSound(id, duration, recipe);
    await save(id, buffer, { layers, melody });
  }
  for (const phrase of MUSIC_PHRASES) await save(phrase.id, makeMusic(phrase), { layers: phrase.layers, bpm: phrase.bpm, bars: 8, harmony: phrase.roots.map((root, index) => ({ midiRoot: root, quality: phrase.qualities[index] === -1 ? "minor" : "major" })), melody: phrase.melody });
  const provenance = { schemaVersion: 1, project: "Cartoon Survivor original game audio", generator: "scripts/generate-game-audio.mjs", command: "node scripts/generate-game-audio.mjs", seed: GENERATOR_SEED, externalRecordings: false, externalSamples: false, aiGenerated: false, authorship: "Project-owned algorithmic synthesis and explicitly authored note sequences; no borrowed recordings or generated-music service outputs.", synthesis: "Seeded noise, swept oscillators, additive plucks/bells, chord pads, authored percussion, wrapped stereo room taps, DC removal and finite soft mastering.", license: "Project-owned original assets; available for use with this project.", assets };
  await writeFile(resolve(outputDirectory, "provenance.json"), `${JSON.stringify(provenance, null, 2)}\n`);
  return provenance;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const provenance = await generateGameAudio(process.argv[2]);
  console.log(`Generated ${provenance.assets.length} original audio assets (${SAMPLE_RATE} Hz stereo) and provenance.json.`);
}
