import assert from "node:assert/strict";
import test from "node:test";

import { getUILayout } from "../src/ui/UILayout.ts";

function assertInside(element, width, height) {
  assert.ok(element.x - element.width / 2 >= 0, `${element.x} starts outside the left edge`);
  assert.ok(element.x + element.width / 2 <= width, `${element.x} ends outside the right edge`);
  assert.ok(element.y - element.height / 2 >= 0, `${element.y} starts above the viewport`);
  assert.ok(element.y + element.height / 2 <= height, `${element.y} ends below the viewport`);
}

test("desktop layout keeps HUD anchors inside a 1280x720 viewport", () => {
  const layout = getUILayout(1280, 720);

  assert.equal(layout.compact, false);
  [
    layout.hudPanel,
    layout.timer,
    layout.health,
    layout.experience,
    ...Object.values(layout.counters),
    layout.boss,
    layout.dash,
  ].forEach((element) => assertInside(element, 1280, 720));
  assert.equal(layout.skillTray.maxVisible, 6);
  assert.ok(layout.skillTray.y > 620);
  assert.ok(layout.dash.x > layout.skillTray.x);
});

test("portrait layout compacts controls and keeps results panel visible", () => {
  const layout = getUILayout(390, 844);

  assert.equal(layout.compact, true);
  [
    layout.hudPanel,
    layout.timer,
    layout.health,
    layout.experience,
    ...Object.values(layout.counters),
    layout.boss,
    layout.dash,
    layout.results,
  ].forEach((element) => assertInside(element, 390, 844));
  assert.equal(layout.skillTray.maxVisible, 5);
  assert.ok(layout.skillTray.slotSize >= 48 && layout.skillTray.slotSize <= 64);
  assert.ok(layout.boss.y > layout.counters.wave.y);
  assert.ok(layout.dash.y < layout.skillTray.y);
  assert.ok(layout.dash.width >= 54);
});

test("layout sanitizes transient zero-sized resize events", () => {
  const layout = getUILayout(0, 0);

  assert.equal(layout.width, 320);
  assert.equal(layout.height, 480);
  assertInside(layout.results, layout.width, layout.height);
});

test("campaign objective owns a separate lane from HUD, counters and boss at every viewport", () => {
  const overlaps = (a,b) => Math.abs(a.x-b.x)<(a.width+b.width)/2 && Math.abs(a.y-b.y)<(a.height+b.height)/2;
  for (const [width,height] of [[390,844],[768,600],[1024,768],[1280,720],[1920,1080]]) {
    const layout=getUILayout(width,height);
    assert.ok(layout.campaignToolbar, 'campaign toolbar must use the shared layout');
    assertInside(layout.campaignToolbar,width,height);
    for (const other of [layout.hudPanel,layout.timer,...Object.values(layout.counters),layout.boss]) {
      assert.equal(overlaps(layout.campaignToolbar,other),false, `toolbar collision at ${width}x${height}`);
    }
  }
});
