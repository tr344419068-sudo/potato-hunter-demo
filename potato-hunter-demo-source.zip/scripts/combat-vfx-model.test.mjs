import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function loadModel() {
  try {
    return await import("../src/systems/CombatVfxModel.ts");
  } catch {
    return {};
  }
}

test("combat styles resolve every configured elemental family", async () => {
  const model = await loadModel();
  assert.equal(typeof model.resolveCombatVfxKind, "function");

  assert.equal(model.resolveCombatVfxKind(["fire"], []), "fire");
  assert.equal(model.resolveCombatVfxKind(["ice"], []), "frost");
  assert.equal(model.resolveCombatVfxKind(["lightning"], []), "lightning");
  assert.equal(model.resolveCombatVfxKind(["pierce"], []), "peeler");
  assert.equal(model.resolveCombatVfxKind(["poison"], []), "poison");
  assert.equal(model.resolveCombatVfxKind(["aoe"], [{ type: "explosion" }]), "explosion");
  assert.equal(model.resolveCombatVfxKind([], [], "frost"), "frost");
});

test("particle budgets favor impacts while remaining bounded", async () => {
  const model = await loadModel();
  assert.equal(typeof model.getCombatVfxBudget, "function");

  for (const kind of ["peeler", "fire", "frost", "lightning", "poison", "explosion"]) {
    const trail = model.getCombatVfxBudget(kind, "trail");
    const impact = model.getCombatVfxBudget(kind, "impact");
    assert.ok(trail >= 1 && trail <= 8, `${kind} trail budget ${trail}`);
    assert.ok(impact > trail && impact <= 24, `${kind} impact budget ${impact}`);
  }
});

test("impact profiles retain stronger localized rings for heavy hits", async () => {
  const model = await loadModel();
  assert.equal(typeof model.getCombatImpactProfile, "function");

  const kinetic = model.getCombatImpactProfile("kinetic", false);
  const critical = model.getCombatImpactProfile("kinetic", true);
  const explosion = model.getCombatImpactProfile("explosion", false);

  assert.ok(kinetic.ringScale >= 1);
  assert.ok(critical.ringScale > kinetic.ringScale);
  assert.ok(explosion.ringScale > critical.ringScale);
  assert.ok(explosion.ringScale <= 2.5);
});

test("every elemental family owns a bounded and distinct four-stage VFX recipe", async () => {
  const model = await loadModel();
  assert.equal(typeof model.getCombatVfxRecipe, "function");

  const kinds = ["kinetic", "peeler", "fire", "frost", "lightning", "poison", "explosion", "ketchup"];
  const recipes = kinds.map((kind) => model.getCombatVfxRecipe(kind));

  for (const recipe of recipes) {
    assert.ok(recipe.trailLength >= 18 && recipe.trailLength <= 52);
    assert.ok(recipe.trailWidth >= 2 && recipe.trailWidth <= 8);
    assert.ok(recipe.coreScale >= 0.65 && recipe.coreScale <= 1.5);
    assert.ok(recipe.impactRays >= 4 && recipe.impactRays <= 12);
    assert.ok(recipe.debrisCount >= 6 && recipe.debrisCount <= 20);
    assert.ok(recipe.residueDurationMs >= 80 && recipe.residueDurationMs <= 560);
  }

  assert.ok(model.getCombatVfxRecipe("lightning").trailLength > model.getCombatVfxRecipe("kinetic").trailLength);
  assert.ok(model.getCombatVfxRecipe("explosion").debrisCount > model.getCombatVfxRecipe("peeler").debrisCount);
  assert.ok(model.getCombatVfxRecipe("poison").residueDurationMs > model.getCombatVfxRecipe("lightning").residueDurationMs);
  assert.equal(new Set(recipes.map((recipe) => JSON.stringify(recipe))).size, recipes.length);
});

test("runtime choreographs muzzle, streak, impact, debris, and residue from the recipe", async () => {
  const source = await readFile(new URL("../src/systems/CombatVfxSystem.ts", import.meta.url), "utf8");

  assert.match(source, /getCombatVfxRecipe/);
  assert.match(source, /drawMuzzleArc/);
  assert.match(source, /spawnTrailStreak/);
  assert.match(source, /spawnResidueMark/);
  assert.match(source, /recipe\.impactRays/);
  assert.match(source, /recipe\.debrisCount/);
  assert.match(source, /recipe\.residueDurationMs/);
});
