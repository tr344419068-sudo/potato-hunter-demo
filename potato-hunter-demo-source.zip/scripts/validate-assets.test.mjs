import assert from "node:assert/strict";
import { mkdtemp, mkdir, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import { validateAssets } from "./validate-assets.mjs";

function pngHeader(width, height) {
  const bytes = Buffer.alloc(24);
  Buffer.from("89504e470d0a1a0a", "hex").copy(bytes, 0);
  bytes.writeUInt32BE(13, 8);
  bytes.write("IHDR", 12, "ascii");
  bytes.writeUInt32BE(width, 16);
  bytes.writeUInt32BE(height, 20);
  return bytes;
}

test("reports duplicate ids, missing files, and PNG dimension mismatches", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "potato-assets-"));

  try {
    await mkdir(path.join(root, "public", "assets"), { recursive: true });
    await mkdir(path.join(root, "src", "configs"), { recursive: true });
    await writeFile(path.join(root, "public", "assets", "exists.png"), pngHeader(32, 48));
    await writeFile(
      path.join(root, "src", "configs", "assets.json"),
      `{
  "asset_duplicate": { "path": "assets/exists.png", "width": 32, "height": 48 },
  "asset_duplicate": { "path": "assets/exists.png", "width": 64, "height": 48 },
  "asset_missing": { "path": "assets/missing.png", "width": 16, "height": 16 }
}`,
    );

    const result = await validateAssets({ rootDir: root });

    assert.equal(result.ok, false);
    assert.match(result.errors.join("\n"), /duplicate asset id: asset_duplicate/);
    assert.match(result.errors.join("\n"), /dimension mismatch.*asset_duplicate.*expected 64x48.*actual 32x48/);
    assert.match(result.errors.join("\n"), /missing asset.*asset_missing/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
