"""Pack the two transparent Shengong RemBg outputs; no local background removal."""
import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps
from scipy import ndimage


ROOT = Path(__file__).resolve().parents[1]
BASE = ('scout', 'keg', 'guard', 'needle', 'roller', 'elite')
POSES = ('guard', 'needle', 'roller', 'elite')


def split(path, cols):
    rgba = np.array(Image.open(path))
    if rgba.ndim != 3 or rgba.shape[2] != 4:
        raise ValueError(f'{path}: expected the transparent RemBg PNG, not the white source')
    alpha = rgba[:, :, 3]
    labels, _ = ndimage.label(alpha >= 64)
    sizes = np.bincount(labels.ravel())
    ids = np.flatnonzero(sizes > alpha.size * .025)
    ids = set(ids[ids != 0])
    if len(ids) != 2 * cols:
        raise ValueError(f'{path}: expected {2 * cols} separate silhouettes, got {len(ids)}')
    centers = {i: ndimage.center_of_mass(alpha, labels, i) for i in ids}
    by_row = sorted(ids, key=lambda i: centers[i][0])
    order = sorted(by_row[:cols], key=lambda i: centers[i][1]) + sorted(by_row[cols:], key=lambda i: centers[i][1])
    distance, nearest = ndimage.distance_transform_edt(labels == 0, return_indices=True)
    # The artwork overlaps rectangular crop boundaries. Assign the original soft edges
    # to the nearest connected silhouette rather than clipping bows or copying neighbors.
    owner = labels[tuple(nearest)]
    for i in order:
        keep = (owner == i) & (distance <= 3)
        sprite = Image.fromarray(np.where(keep[:, :, None], rgba, 0).astype('uint8'))
        yield sprite.crop(sprite.getbbox())


def pack(sprite, spec, facing_left=True):
    if not facing_left:
        sprite = ImageOps.mirror(sprite)
    size = spec['width']
    foot = spec['footPoint']
    # Preserve the fit established for the mobile-sized actors, and keep the
    # ground edge on the same baseline for a character's two different poses.
    bottom = round(size * foot['y'])
    scale = min((bottom - .055 * size) / sprite.height, .935 * size / sprite.width)
    tile = sprite.resize((round(sprite.width * scale), round(sprite.height * scale)), Image.Resampling.LANCZOS)
    canvas = Image.new('RGBA', (size, size))
    x = min(size - tile.width - 3, max(3, round(foot['x'] * size - tile.width / 2)))
    canvas.paste(tile, (x, bottom - tile.height))
    return canvas


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('roster', type=Path)
    parser.add_argument('poses', type=Path)
    args = parser.parse_args()
    assets = json.loads((ROOT / 'src/configs/assets.json').read_text())
    for board, roles, cols, suffix in ((args.roster, BASE, 3, ''), (args.poses, POSES, 2, '_pose')):
        for role, sprite in zip(roles, split(board, cols)):
            spec = assets[f'enemy_snow_{role}{suffix}']
            path = ROOT / 'public' / spec['path']
            if path.parent.name != 'snow-shengong-v1':
                raise ValueError(f'Refusing to overwrite the Blender asset: {path}')
            path.parent.mkdir(parents=True, exist_ok=True)
            pack(sprite, spec, facing_left=(role, suffix) != ('needle', '')).save(path, 'WEBP', quality=82, method=6)
            print(f'{path.name}: {path.stat().st_size:,} bytes')


if __name__ == '__main__':
    main()
