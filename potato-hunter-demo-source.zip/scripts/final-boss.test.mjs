import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { displayScene } from "./ui-runtime-helpers.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
  export { World } from "./src/entities/World.ts";
  export * from "./src/entities/factories.ts";
  export { ConfigManager } from "./src/managers/ConfigManager.ts";
  export { EventBus } from "./src/managers/EventBus.ts";
  export { GameScene } from "./src/scenes/GameScene.ts";
  export { CampaignDirector, getCampaignBeat } from "./src/campaign/CampaignModel.ts";
  export { BossSystem } from "./src/systems/BossSystem.ts";
  export { MovementSystem } from "./src/systems/MovementSystem.ts";
  export { MonsterContactSystem } from "./src/systems/MonsterContactSystem.ts";
  export { BossDuelView, drawHeroHealthAtFeet } from "./src/systems/BossDuelView.ts";
  export { HostileWarningView } from "./src/systems/HostileWarningView.ts";
  export { createFinalBossHealth } from "./src/systems/FinalBossPatternModel.ts";
  export { EnemyProjectileSystem } from "./src/systems/EnemyProjectileSystem.ts";
  export { getBossDuel } from "./src/systems/BossDuelArena.ts";
  export { getDesertCast, getCyclonePoint, getWaveY, startDesertCast } from "./src/systems/DesertBossEncounter.ts";
  export { DesertBossView } from "./src/systems/DesertBossView.ts";
  export { MonsterAISystem } from "./src/systems/MonsterAISystem.ts";
  export { AoeWarningSystem } from "./src/systems/AoeWarningSystem.ts";
  export { MonsterBehaviorSystem } from "./src/systems/MonsterBehaviorSystem.ts";
  export { AutoAttackSystem } from "./src/systems/AutoAttackSystem.ts";
  export { ProjectileCollisionSystem } from "./src/systems/ProjectileCollisionSystem.ts";
  export { StatusEffectSystem } from "./src/systems/StatusEffectSystem.ts";
  export { SkillManager } from "./src/managers/SkillManager.ts";
  export { WaveManager } from "./src/managers/WaveManager.ts";
  export { BossBarView } from "./src/ui/BossBarView.ts";
  export { getUILayout } from "./src/ui/UILayout.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless-final-boss", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Scene: class {}, Events: { EventEmitter }, Display: { Color: { HexStringToColor: value => ({ color: parseInt(value.slice(1), 16) }) } }, Math: { Clamp: (value,lower,upper)=>Math.min(upper,Math.max(lower,value)), Between: (lower,upper)=>lower, FloatBetween: (lower,upper)=>lower } };', resolveDir: root }));
  }}],
}).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

const patterns = ["sesame_fan", "triple_slam", "spatula_sweep", "sauce_ring"];
const windups = [1050, 1800, 1250, 1250];

async function fixture(phase = 1, kind = "final") {
  const api = await modules;
  api.EventBus.removeAllListeners();
  const world = new api.World();
  const playerId = api.createPlayer(world, 250, 0, 210, 100, 100);
  const runtime = { world, playerId, waveManager: new api.WaveManager(), scene: { cameras: { main: { shake() {} } } }, stats: { elapsedMs: 360000, kills: 0, bossKills: 0, gold: 0 } };
  const id = api.createMonster(world, api.ConfigManager.getMonster("delivery_box"), 0, 0, true);
  world.components.monsters.get(id).bossKind = kind;
  const health = world.components.health.get(id);
  health.current = health.max * (phase === 3 ? .25 : phase === 2 ? .55 : 1);
  const boss = new api.BossSystem();
  const aoe = new api.AoeWarningSystem();
  const events = [];
  api.EventBus.on("boss:phase", event => events.push(event));
  const tick = deltaMs => { boss.update(deltaMs, runtime); aoe.update(deltaMs, runtime); };
  return { ...api, world, runtime, playerId, id, boss, aoe, events, tick };
}

test('the campaign finale pins a themed duel to the arrival point and releases it on boss death', async () => {
  const f = await fixture();
  const g = new f.GameScene();
  Object.assign(g, {world:f.world, playerId:f.playerId, runStage:'meadow', campaign:new f.CampaignDirector(7), stats:{elapsedMs:180000}});
  const hero=f.world.components.transforms.get(f.playerId);
  const origin={x:hero.x,y:hero.y};
  g.spawnCampaignBoss('final');
  const arena=f.getBossDuel(f.world);
  assert.deepEqual([arena.x,arena.y],[origin.x,origin.y]);
  assert.equal(arena.radius,450,'the real duel boundary is 25% wider');
  const boss=f.world.components.transforms.get(arena.bossId);
  assert.ok(Math.hypot(boss.x-arena.x,boss.y-arena.y)<arena.radius-80);
  f.world.components.velocities.get(f.playerId).x=2000;
  new f.MovementSystem().update(1000,f.runtime);
  assert.equal(hero.x,arena.x+arena.radius-hero.radius);
  f.world.destroyEntity(arena.bossId);
  new f.MovementSystem().update(1000,f.runtime);
  assert.ok(hero.x>arena.x+arena.radius,'normal movement returns on boss death');
});

test('pre-existing enemies still exist but cannot hit or fire into the duel before the gate opens', async () => {
  const f = await fixture(1,'intermediate');
  const g = new f.GameScene();
  Object.assign(g, {world:f.world, playerId:f.playerId, runStage:'meadow', campaign:new f.CampaignDirector(7), stats:{elapsedMs:180000}});
  const p=f.world.components.transforms.get(f.playerId);
  const guard=f.createMonster(f.world,f.ConfigManager.getMonster('cola_spitter'),p.x,p.y);
  const warning=f.createAoeWarning(f.world,p.x,p.y,100,99,200);
  g.spawnCampaignBoss('final');
  const arena=f.getBossDuel(f.world);
  const health=f.world.components.health.get(f.playerId);
  assert.equal(f.world.components.aoeWarnings.has(warning),false);
  assert.ok(f.world.components.monsters.has(guard)&&f.world.components.monsters.has(f.id));
  const contact=new f.MonsterContactSystem();
  contact.update(0,f.runtime);
  assert.equal(health.current,100);
  new f.MonsterBehaviorSystem().update(5000,f.runtime);
  assert.equal(f.world.components.enemyProjectiles.size,0);
  const ai=new f.MonsterAISystem(), move=new f.MovementSystem();
  for(let i=0;i<25;i++){ai.update(40,f.runtime);move.update(40,f.runtime);}
  const sentry=f.world.components.transforms.get(guard);
  assert.ok(Math.hypot(sentry.x-arena.x,sentry.y-arena.y)>=arena.radius);
  f.world.destroyEntity(arena.bossId);
  Object.assign(sentry,{x:p.x,y:p.y});
  contact.update(0,f.runtime);
  assert.ok(health.current<100,'the remaining enemies resume contact after the duel');
});

test('automatic weapons and lingering damage leave outside enemies alone until the finale ends', async () => {
  const f = await fixture(1, 'intermediate');
  const g = new f.GameScene();
  Object.assign(g, { world:f.world, playerId:f.playerId, runStage:'meadow', campaign:new f.CampaignDirector(7), stats:{elapsedMs:180000} });
  g.spawnCampaignBoss('final');
  const {bossId}=f.getBossDuel(f.world), p=f.world.components.transforms.get(f.playerId);
  const guard=f.createMonster(f.world,f.ConfigManager.getMonster('delivery_box'),p.x-18,p.y);
  Object.assign(f.world.components.transforms.get(bossId),{x:p.x+150,y:p.y});
  f.runtime.skillManager = new f.SkillManager();
  new f.AutoAttackSystem().update(1000,f.runtime);
  const shot=[...f.world.components.projectiles.keys()][0];
  assert.ok(f.world.components.velocities.get(shot).x>0,'auto aim selects the Boss, not the closer mob');
  const h=f.world.components.health.get(guard), max=h.current;
  const dot={type:'burn',remainingMs:1200,totalMs:1200,damagePerSecond:5,slowMultiplier:1};
  f.world.components.statuses.set(guard,[dot]);
  const hit=f.createProjectile(f.world,p.x-18,p.y,0,0,'peeler_blade',6,1,500);
  const collisions=new f.ProjectileCollisionSystem(), statuses=new f.StatusEffectSystem();
  collisions.update(0,f.runtime);statuses.update(100,f.runtime);
  assert.equal(h.current,max);assert.equal(f.world.components.projectiles.get(hit).hitEntities.has(guard),false);
  f.world.destroyEntity(bossId);
  collisions.update(0,f.runtime);statuses.update(100,f.runtime);
  assert.ok(h.current<max,'normal damage resumes when the gate opens');
});

test('finale art uses imported ring frames below the actors and hero HP tracks the foot point', async () => {
  const f = await fixture();
  const g = new f.GameScene();
  Object.assign(g, {world:f.world, playerId:f.playerId, runStage:'meadow', campaign:new f.CampaignDirector(7), stats:{elapsedMs:180000}});
  g.spawnCampaignBoss('final');
  const {scene,objects}=displayScene(750,1624);
  const graphics=scene.add.graphics();
  const view=new f.BossDuelView(scene);
  view.draw({...f.runtime,stats:g.stats});
  assert.ok(objects.some(o=>o.kind==='image'&&/duel_fence_meadow/.test(o.texture)&&o.depth<1));
  assert.ok(objects.some(o=>o.kind==='image'&&/vfx_boss_ember_ring/.test(o.texture)&&o.depth<2));
  f.drawHeroHealthAtFeet(graphics,370,812,62,{current:25,max:100});
  const filled=graphics.calls.filter(c=>c[0]==='fillRoundedRect').at(-1);
  assert.ok(filled[2]>812&&filled[3]>=10&&filled[3]<21);
  view.destroy();
});

test('a sweep warning is one raster layer aligned to the attack and removed when it expires', async () => {
  const f = await fixture(), {scene,objects}=displayScene(750,1624);
  const view=new f.HostileWarningView(scene);
  const warning={shape:'capsule',angle:Math.PI/3,length:255,impactStyle:'sweep',damage:18};
  view.draw(12,warning,{x:130,y:220,radius:68},.25);
  view.draw(12,warning,{x:130,y:220,radius:68},.75);
  assert.equal(objects.length,1);
  assert.equal(objects[0].texture,'asset:vfx_duel_sweep_tell');
  assert.equal(objects[0].rotation,warning.angle);
  assert.ok(objects[0].width>391&&objects[0].height>136);
  view.prune(new Map());
  assert.equal(objects[0].destroyed,true);
});

test('meadow campaign thunder deals damage only at its visibly warned targets', async () => {
  const f = await fixture();
  f.runtime.campaign={stage:'meadow',ownBossCadence:true,spawnMultiplier:1};
  const monster=f.world.components.monsters.get(f.id);
  monster.finalBossEncounter={phase:1,completedCasts:0,transitioning:false};
  f.world.components.health.set(f.id,f.createFinalBossHealth(1000,monster.finalBossEncounter,'meadow'));
  const strikes=[];f.EventBus.on('hostile:impact',e=>strikes.push(e));
  f.tick(1800);f.tick(1050);f.tick(1050);
  assert.match(f.events.at(-1).text,/雷/);
  const warnings=[...f.world.components.aoeWarnings.values()];
  assert.equal(warnings.length,3);
  assert.ok(warnings.every(w=>w.impactStyle==='lightning'));
  f.tick(1099);assert.equal(strikes.length,0);
  f.tick(1);assert.equal(strikes[0].style,'lightning');assert.equal(f.world.components.health.get(f.playerId).current,84);
});

test('desert boss uses themed labels and emits a ground-impact visual at the true warning radius', async () => {
  const f = await fixture();
  f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
  const volleys = [], strikes = []; f.EventBus.on('hostile:volley', e => volleys.push(e));
  f.EventBus.on('hostile:impact', e => strikes.push(e));
  f.tick(1800);
  assert.match(f.events.at(-1).text, /沙/);
  f.tick(1050);
  assert.equal(volleys[0].style, 'sand');
  assert.ok(volleys[0].angles.every(angle => Math.abs(angle) >= .38), 'the visual fan must leave the gap clear');
  f.tick(1050); f.tick(1800); f.tick(1100);
  const blast = strikes[0];
  assert.ok(blast); assert.equal(blast.radius, 88); assert.equal(blast.style, 'sand');
  assert.match(f.getCampaignBeat(360000, 'desert').objective, /沙海/);
  assert.match(f.getCampaignBeat(0, 'desert').title, /沙/);
});

test('meadow slam warns the larger real hit area, then publishes exactly one matching impact', async () => {
  const f = await fixture();
  const strikes = []; f.EventBus.on('hostile:impact', e => strikes.push(e));
  f.tick(1800); f.tick(1050); f.tick(1050);
  const [id, warning] = [...f.world.components.aoeWarnings][0];
  const target = f.world.components.transforms.get(id);
  assert.equal(target.radius, 88);
  assert.equal(warning.impactStyle, 'slam');
  const player = f.world.components.transforms.get(f.playerId);
  player.x = target.x + 83; player.y = target.y;
  f.tick(1099); assert.equal(strikes.length, 0);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 84);
  assert.deepEqual(strikes.map(({ x, y, radius, style }) => [x, y, radius, style]), [[target.x, target.y, 88, 'slam']]);
  f.tick(1); assert.equal(strikes.length, 1);
});

test('the fryer bombardment uses its full 118-unit tell, even if the player safely dodges', async () => {
  const f = await fixture(1, 'intermediate');
  const strikes = []; f.EventBus.on('hostile:impact', e => strikes.push(e));
  f.tick(1500); f.tick(750); f.tick(800);
  const [id] = [...f.world.components.aoeWarnings.keys()];
  const target = f.world.components.transforms.get(id);
  assert.equal(target.radius, 118);
  f.world.components.transforms.get(f.playerId).x = target.x + 124;
  f.tick(1000);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  assert.equal(strikes[0]?.radius, 118);
  assert.equal(strikes[0]?.style, 'oil');
});

test('desert crystal fan leaves a dodgeable central lane instead of the meadow fan', async () => {
  const f = await fixture();
  f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
  f.tick(1800);
  assert.match(f.events.at(-1).text, /中央|中间/);
  f.tick(1049); assert.equal(f.world.components.enemyProjectiles.size, 0);
  f.tick(1);
  const angles = [...f.world.components.enemyProjectiles.keys()].map(id => {
    const velocity = f.world.components.velocities.get(id);
    return Math.atan2(velocity.y, velocity.x);
  });
  assert.equal(angles.length, 7);
  assert.ok(angles.some(angle => angle < -.35) && angles.some(angle => angle > .35));
  assert.ok(angles.every(angle => Math.abs(angle) >= .35), 'the marked central escape lane must not contain a projectile');
});

test('desert boss staggers sand impacts along its locked aim direction', async () => {
  const f = await fixture();
  f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
  f.tick(1800); f.tick(1050); f.tick(1050);
  const warnings = [...f.world.components.aoeWarnings];
  assert.deepEqual(warnings.map(([, warning]) => warning.totalMs), [1100, 1450, 1800]);
  assert.deepEqual(warnings.map(([id]) => {
    const p = f.world.components.transforms.get(id); return [p.x, p.y];
  }), [[250, 0], [100, 0], [400, 0]]);
  f.tick(1099); assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 84);
});

test('desert cross-sweep targets the locked player location with a clear warning', async () => {
  const f = await fixture();
  f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
  f.tick(1800); f.tick(1050); f.tick(1050);
  f.world.components.transforms.get(f.playerId).x = 1000;
  f.tick(1800); f.tick(1050);
  const warnings = [...f.world.components.aoeWarnings];
  assert.equal(warnings.length, 1);
  assert.equal(warnings[0][1].shape, 'capsule');
  assert.deepEqual(warnings.map(([id]) => {
    const p = f.world.components.transforms.get(id); return [p.x, p.y];
  }), [[1000, 0]]);
  f.tick(1249); assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 82);
});

test('desert sandburst warns around the target and rewards moving outside', async () => {
  async function enterStorm() {
    const f = await fixture();
    f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
    f.tick(1800); f.tick(1050); f.tick(1050);
    f.world.components.transforms.get(f.playerId).x = 1000;
    f.tick(1800); f.tick(1050);
    f.world.components.transforms.get(f.playerId).y = 500;
    f.tick(1250); f.tick(1050);
    return f;
  }
  const hit = await enterStorm();
  const [warningId, warning] = [...hit.world.components.aoeWarnings][0];
  const position = hit.world.components.transforms.get(warningId);
  assert.deepEqual([position.x, position.y, position.radius, warning.safeRadius], [1000, 500, 150, undefined]);
  assert.match(warning.label, /离开/);
  hit.tick(1249); assert.equal(hit.world.components.health.get(hit.playerId).current, 100);
  hit.tick(1); assert.equal(hit.world.components.health.get(hit.playerId).current, 80);
  const dodged = await enterStorm();
  dodged.world.components.transforms.get(dodged.playerId).y += 151;
  dodged.tick(1250); assert.equal(dodged.world.components.health.get(dodged.playerId).current, 100);
});

test("campaign final boss gets its own identity, giant art, higher health and objective", async () => {
  const api = await modules;
  const spawn = kind => {
    const scene = new api.GameScene();
    scene.playerId = api.createPlayer(scene.world, 0, 0, 210, 100, 100);
    scene.campaign = new api.CampaignDirector(42);
    scene.stats.elapsedMs = 360000;
    scene.spawnCampaignBoss(kind);
    const id = [...scene.world.components.monsters.keys()][0];
    return { scene, monster: scene.world.components.monsters.get(id), health: scene.world.components.health.get(id), render: scene.world.components.renders.get(id), transform: scene.world.components.transforms.get(id) };
  };
  const intermediate = spawn("intermediate");
  const final = spawn("final");
  assert.equal(final.monster.bossKind, "final");
  assert.equal(intermediate.monster.bossKind, "intermediate");
  assert.equal(final.render.assetId, "boss_burger_tyrant_v4");
  assert.equal(intermediate.render.assetId, api.ConfigManager.boss.assetId);
  assert.ok(final.render.size >= 145 && final.render.size <= 165);
  assert.ok(final.transform.radius > intermediate.transform.radius);
  assert.equal(final.health.max, Math.ceil(intermediate.health.max * 1.95));
  assert.equal(final.monster.damage, intermediate.monster.damage);
  assert.equal(final.monster.experienceValue, intermediate.monster.experienceValue);
  assert.match(api.getCampaignBeat(360000).objective, /堡垒暴君/);
});

async function stagedCampaignBoss(stage) {
  const api = await modules;
  api.EventBus.removeAllListeners();
  const scene = new api.GameScene();
  scene.runStage = stage;
  scene.playerId = api.createPlayer(scene.world, 250, 0, 210, 100, 100);
  scene.campaign = new api.CampaignDirector(42);
  scene.stats.elapsedMs = 180_000;
  scene.spawnCampaignBoss("final");
  const id = [...scene.world.components.monsters.keys()][0];
  const world = scene.world;
  world.components.transforms.get(id).x = 0;
  world.components.transforms.get(id).y = 0;
  const runtime = {
    world, playerId: scene.playerId, scene: { cameras: { main: { shake() {} } } },
    stats: scene.stats, waveManager: new api.WaveManager(stage),
    campaign: { stage, ownBossCadence: true, spawnMultiplier: 1 },
  };
  const events = [], boss = new api.BossSystem(), aoe = new api.AoeWarningSystem();
  api.EventBus.on("boss:phase", event => events.push(event));
  const tick = (ms) => { boss.update(ms, runtime); aoe.update(ms, runtime); };
  return { ...api, scene, world, runtime, id, events, tick, health: world.components.health.get(id) };
}

test('duel opens its first tell within 850ms, and a real fan hit removes at least half of an upgraded health bar', async () => {
  const f = await stagedCampaignBoss('meadow');
  const player = f.world.components.health.get(f.scene.playerId);
  player.current = player.max = 170;
  f.tick(850);
  const cast = f.events.at(-1);
  assert.equal(cast?.pattern, 'sesame_fan');
  f.tick(cast.windupMs);
  const projectiles = new f.EnemyProjectileSystem();
  const movement = new f.MovementSystem();
  for (let i = 0; i < 30 && player.current === 170; i++) {
    movement.update(40, f.runtime); projectiles.update(40, f.runtime);
  }
  assert.ok(player.current > 0 && player.current <= 85, `remaining HP ${player.current}`);
});

test('the same Boss arm winds up, strikes, and follows through on the damaging sweep', async () => {
  const f = await stagedCampaignBoss('meadow');
  const e = f.world.components.monsters.get(f.id).finalBossEncounter;
  e.phase = 2;
  f.tick(1200);
  assert.equal(e.swingFrame, 0);
  const tell = f.events.at(-1).windupMs;
  f.tick(tell - 10);
  assert.equal(e.swingFrame, 2);
  f.tick(10);
  assert.equal(e.swingFrame, 3);
  const [warning] = f.world.components.aoeWarnings.values();
  for (let i = 0; i < 40 && !warning.triggered; i++) f.tick(10);
  assert.ok(warning.triggered);
  assert.equal(e.swingFrame, 5);
  f.tick(180);
  assert.equal(e.swingFrame, undefined);
});

for (const dodged of [false, true]) test(`campaign rush moves the Boss and ${dodged ? 'rewards a sideways dodge' : 'punishes staying in the lane'}`, async () => {
  const f = await stagedCampaignBoss('meadow');
  f.world.components.monsters.get(f.id).finalBossEncounter.phase = 2;
  f.tick(1200);
  const cast = f.events.at(-1);
  assert.equal(cast.pattern, 'spatula_sweep');
  const [warning] = f.world.components.aoeWarnings.values();
  assert.ok(warning.totalMs <= 1100, 'duel sweep completes sooner than the old static 1250ms sweep');
  const hero = f.world.components.transforms.get(f.scene.playerId);
  const boss = f.world.components.transforms.get(f.id);
  const hp = f.world.components.health.get(f.scene.playerId);
  const move = new f.MovementSystem();
  if (dodged) hero.y = 150;
  for (let elapsed = 0; elapsed < warning.totalMs; elapsed += 10) {
    assert.equal(hp.current, 100, 'no slash damage before the tell ends');
    f.tick(10); move.update(10, f.runtime);
  }
  assert.ok(boss.x > 260 && Math.abs(boss.y) < 1, 'boss actually crosses the arena on the locked heading');
  assert.equal(hp.current, dodged ? 100 : 42);
  assert.ok(f.world.components.aoeWarnings.size === 0, 'one strike per lunge');
});

test('the final boss closes a gap during recovery without running into the player', async () => {
  const f = await stagedCampaignBoss('meadow');
  f.tick(1200); f.tick(1050);
  const ai = new f.MonsterAISystem(), motion = new f.MovementSystem();
  const boss = f.world.components.transforms.get(f.id);
  for (let i = 0; i < 10; i++) {
    ai.update(40, f.runtime); f.tick(40); motion.update(40, f.runtime);
  }
  assert.ok(boss.x >= 80 && boss.x <= 125, 'boss closes distance, but stops outside body contact');
});

test('near the fence the rush effect and actual movement end at the same boundary', async () => {
  const f = await stagedCampaignBoss('meadow');
  const boss = f.world.components.transforms.get(f.id);
  const hero = f.world.components.transforms.get(f.scene.playerId);
  boss.x = -100; hero.x = -160;
  f.world.components.monsters.get(f.id).finalBossEncounter.phase = 2;
  let rush;
  f.EventBus.on('boss:rush', event => { rush = event; });
  f.tick(1200); f.tick(f.events.at(-1).windupMs);
  const d = f.getBossDuel(f.world);
  const edge = d.x - d.radius + boss.radius;
  assert.equal(rush?.distance, boss.x - edge);
  new f.MovementSystem().update(rush.duration, f.runtime);
  assert.ok(Math.abs(boss.x - edge) < .001);
});

test('the enlarged duel opens sooner and final boss shots can cross it', async () => {
  const f = await stagedCampaignBoss('meadow');
  f.tick(799);
  assert.equal(f.events.filter(event => event.pattern).length, 0);
  f.tick(1);
  assert.equal(f.events.at(-1)?.pattern, 'sesame_fan');
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 7);
  for (const [id, shot] of f.world.components.enemyProjectiles) {
    const {x, y} = f.world.components.velocities.get(id);
    const lifetime = f.world.components.lifetimes.get(id).totalMs;
    assert.ok(Math.hypot(x, y) * lifetime / 1000 >= 900);
    assert.ok(shot.damage > 12);
  }
});

for (const [stage, testDistance, safeDistance, damage] of [
  ['meadow', 350, 110, 68],
]) test(`${stage} duel finale lands a larger single hit while preserving a safe dodge`, async () => {
  const f = await stagedCampaignBoss(stage);
  f.world.components.monsters.get(f.id).finalBossEncounter.phase = 3;
  f.tick(1200);
  const cast = f.events.at(-1);
  assert.equal(cast?.pattern, 'sauce_ring');
  const [warningId, warn] = [...f.world.components.aoeWarnings][0];
  const center = f.world.components.transforms.get(warningId);
  assert.ok(center.radius >= testDistance);
  assert.equal(warn.damage, damage);
  const hero = f.world.components.transforms.get(f.scene.playerId);
  const hp = f.world.components.health.get(f.scene.playerId);
  Object.assign(hero, {x:center.x + testDistance,y:center.y});
  f.tick(cast.windupMs - 1);
  assert.equal(hp.current,100,'no early damage');
  f.tick(1);
  assert.equal(hp.current,100-damage);
  f.tick(239);
  assert.equal(hp.current,100-damage,'no repeated damage');
  assert.equal(f.events.at(-1),cast);
  f.tick(1);
  assert.notEqual(f.events.at(-1).pattern,'sauce_ring','phase three starts the next tell after 240 ms');

  const dodge = await stagedCampaignBoss(stage);
  dodge.world.components.monsters.get(dodge.id).finalBossEncounter.phase = 3;
  dodge.tick(1200);
  const [dodgeId] = dodge.world.components.aoeWarnings.keys();
  const dodgeCenter = dodge.world.components.transforms.get(dodgeId);
  Object.assign(dodge.world.components.transforms.get(dodge.scene.playerId), {x:dodgeCenter.x - safeDistance,y:dodgeCenter.y});
  dodge.tick(dodge.events.at(-1).windupMs);
  assert.equal(dodge.world.components.health.get(dodge.scene.playerId).current,100,'safe lane still works');
});

test('desert duel opens with a traveling sand wave instead of the meadow fan', async () => {
  const f = await stagedCampaignBoss('desert');
  f.tick(800);
  const cast = f.events.at(-1);
  assert.equal(cast?.pattern, 'dune_wave');
  assert.match(cast.text, /断岸沙浪/);
  f.tick(cast.windupMs + 1000);
  assert.equal(f.world.components.enemyProjectiles.size, 0, 'not a re-skinned projectile fan');
  assert.equal(f.world.components.health.get(f.scene.playerId).current, 50, 'the moving front can hit once');
});

test('walking into the locked gap dodges the wave even if the front sweeps across in a large step', async () => {
  const f = await stagedCampaignBoss('desert');
  f.tick(800);
  const cast = f.getDesertCast(f.world);
  f.world.components.transforms.get(f.scene.playerId).x = cast.shape.gapX;
  assert.ok((f.getWaveY(cast, .75) - f.getWaveY(cast, .25)) * cast.shape.direction > 400);
  f.tick(cast.tellMs + cast.activeMs);
  assert.equal(f.world.components.health.get(f.scene.playerId).current, 100);
  assert.equal(f.getDesertCast(f.world), undefined);
});

test('cyclone follows its published curve; sandfall only slows after its one hit and does not reduce dash speed', async () => {
  const f = await stagedCampaignBoss('desert');
  const { playerId } = f.scene;
  const encounter = f.world.components.monsters.get(f.id).finalBossEncounter;
  const hero = f.world.components.transforms.get(playerId);
  const player = f.world.components.players.get(playerId);
  const hp = f.world.components.health.get(playerId);
  encounter.phase = 2;
  f.tick(800);
  const cyclone = f.getDesertCast(f.world);
  assert.equal(cyclone.shape.kind, 'sand_cyclone');
  const midway = f.getCyclonePoint(cyclone.shape, .5);
  hero.x -= 70;
  f.tick(cyclone.tellMs - 1);
  assert.deepEqual(f.getCyclonePoint(f.getDesertCast(f.world).shape, .5), midway);
  assert.equal(hp.current, 100);
  Object.assign(hero, midway);
  f.tick(1 + cyclone.activeMs / 2);
  assert.equal(hp.current, 50);
  f.tick(cyclone.activeMs / 2);
  assert.equal(hp.current, 50);

  f.tick(cyclone.recoveryMs);
  const fall = f.getDesertCast(f.world);
  assert.equal(fall.shape.kind, 'sandfall');
  Object.assign(hero, fall.shape.center);
  hp.current = 100;
  player.damageCooldownMs = 0;
  f.tick(fall.tellMs);
  assert.equal(hp.current, 45);
  f.tick(230);
  const movement = new f.MovementSystem();
  f.world.components.velocities.get(playerId).x = 200;
  movement.update(100, f.runtime);
  assert.ok(Math.abs(hero.x - fall.shape.center.x - 13.6) < .001);
  player.dashRemainingMs = 150;
  movement.update(100, f.runtime);
  assert.ok(Math.abs(hero.x - fall.shape.center.x - 33.6) < .001);
  assert.equal(hp.current, 45);
});

test('siege shelters dodge the arena hit and the boss gives a 1.48s counterattack window', async () => {
  for (const shelterIndex of [-1, 0, 1]) {
    const f = await stagedCampaignBoss('desert');
    f.world.components.monsters.get(f.id).finalBossEncounter.phase = 3;
    f.tick(800);
    const cast = f.getDesertCast(f.world);
    assert.equal(cast.shape.kind, 'sand_siege');
    const hp = f.world.components.health.get(f.scene.playerId);
    if (shelterIndex >= 0) Object.assign(f.world.components.transforms.get(f.scene.playerId), cast.shape.shelters[shelterIndex]);
    f.tick(cast.tellMs - 1);
    assert.equal(hp.current, 100);
    f.tick(1 + cast.activeMs);
    assert.equal(hp.current, shelterIndex < 0 ? 34 : 100);
    assert.equal(f.getDesertCast(f.world), undefined);
    f.tick(1479);
    assert.equal(f.getDesertCast(f.world), undefined);
    f.tick(1);
    assert.equal(f.getDesertCast(f.world)?.shape.kind, 'sand_burrow');
  }
});

test('siege uses the hero position at release even when a movement step crosses the shelter boundary', async () => {
  const f = await stagedCampaignBoss('desert');
  f.world.components.monsters.get(f.id).finalBossEncounter.phase = 3;
  f.tick(800);
  const cast = f.getDesertCast(f.world);
  const [safe] = cast.shape.shelters;
  const { playerId } = f.scene;
  Object.assign(f.world.components.transforms.get(playerId), { x: safe.x - safe.radius - 5, y: safe.y });
  f.tick(cast.tellMs - 35);
  f.world.components.velocities.get(playerId).x = 220;
  f.tick(40);
  assert.equal(f.world.components.health.get(playerId).current, 100);
});

test('an unreadable environmental attack finishes without dealing invisible damage', async () => {
  const f = await stagedCampaignBoss('desert');
  f.runtime.canShowDesertAttack = () => false;
  f.tick(800);
  const cast = f.getDesertCast(f.world);
  f.tick(cast.tellMs + cast.activeMs);
  assert.equal(f.world.components.health.get(f.scene.playerId).current, 100);
  assert.equal(f.world.components.monsters.get(f.id).finalBossEncounter.completedCasts, 1);
});

test('desert basic attack moves into range, winds the arm, and hits only inside the fixed sector', async () => {
  for (const sidestep of [false, true]) {
    const f = await stagedCampaignBoss('desert');
    const boss = f.world.components.transforms.get(f.id), hero = f.world.components.transforms.get(f.scene.playerId);
    const monster = f.world.components.monsters.get(f.id);
    f.tick(200);
    assert.ok(f.world.components.velocities.get(f.id).x > 0, 'approaches before the first cast');
    f.tick(600);
    const wave = f.getDesertCast(f.world);
    Object.assign(hero, {x:wave.shape.gapX,y:wave.arena.y});
    f.tick(wave.tellMs + wave.activeMs);
    Object.assign(hero, { x:boss.x + 112, y:boss.y });
    f.tick(25);
    const swing = f.getDesertCast(f.world);
    assert.equal(swing.shape.kind, 'sand_cleave');
    f.tick(swing.tellMs * .7);
    assert.equal(monster.finalBossEncounter.swingFrame, 2);
    if (sidestep) Object.assign(hero, { x:boss.x, y:boss.y + 125 });
    f.tick(swing.tellMs * .31);
    assert.equal(monster.finalBossEncounter.swingFrame, 3);
    assert.equal(f.world.components.health.get(f.scene.playerId).current, sidestep ? 100 : 78);
  }
});

test('desert burrow hides the boss and strikes a locked landing point, not the moving hero', async () => {
  const f = await stagedCampaignBoss('desert');
  const encounter = f.world.components.monsters.get(f.id).finalBossEncounter;
  const hero = f.world.components.transforms.get(f.scene.playerId), boss = f.world.components.transforms.get(f.id);
  encounter.phase = 3;
  f.tick(800);
  const siege = f.getDesertCast(f.world);
  Object.assign(hero, siege.shape.shelters[0]);
  f.tick(siege.tellMs + siege.activeMs);
  f.tick(siege.recoveryMs);
  const burrow = f.getDesertCast(f.world);
  assert.equal(burrow.shape.kind, 'sand_burrow');
  f.tick(390);
  assert.equal(encounter.burrowed, true);
  const hp = f.health.current;
  f.health.current -= 100;
  assert.equal(f.health.current, hp);
  const x = burrow.shape.center.x, y = burrow.shape.center.y;
  Object.assign(hero, { x, y:y + burrow.shape.radius + 28 });
  f.tick(burrow.tellMs - 390);
  assert.equal(encounter.burrowed, false);
  assert.deepEqual([boss.x,boss.y],[x,y]);
  assert.equal(f.world.components.health.get(f.scene.playerId).current, 100);
});

test('desert health has six scaled cells and sand armor absorbs damage before HP', async () => {
  const f = await stagedCampaignBoss('desert'), meadow = await stagedCampaignBoss('meadow');
  assert.ok(f.health.max >= meadow.health.max * 1.4);
  const encounter = f.world.components.monsters.get(f.id).finalBossEncounter;
  f.health.current = f.health.max * .7;
  encounter.completedCasts = 1;
  f.tick(40);
  f.tick(900);
  const hud = f.scene.getBossHudData();
  assert.equal(hud.phase.bands.length, 7);
  assert.ok(hud.shield.current > 0);
  const hp = f.health.current, shield = hud.shield.current;
  f.health.current -= shield / 2;
  assert.equal(f.health.current, hp);
  f.health.current -= shield / 2 + 15;
  assert.ok(Math.abs(f.health.current - (hp - 15)) < 1e-6);
  assert.equal(f.scene.getBossHudData().shield, undefined);
});

test('desert green ground markings fill the actual lane and both shelter radii', async () => {
  const f = await stagedCampaignBoss('desert');
  const arena = f.getBossDuel(f.world);
  const {scene,objects} = displayScene(390,844);
  const view = new f.DesertBossView(scene);
  const marks = objects.find(o => o.kind === 'graphics');
  const wave = f.startDesertCast(f.world, f.id, arena, 'dune_wave', 1, arena, arena, 0);
  view.draw(f.runtime);
  const points = marks.calls.find(([m]) => m === 'fillPoints')[1];
  assert.equal(Math.min(...points.map(p=>p.x)), wave.shape.gapX - wave.shape.gapHalf);
  assert.equal(Math.max(...points.map(p=>p.x)), wave.shape.gapX + wave.shape.gapHalf);
  assert.ok(points.every(p=>Math.hypot(p.x-arena.x,p.y-arena.y)<=arena.radius+1e-6));
  const siege = f.startDesertCast(f.world, f.id, arena, 'sand_siege', 3, arena, arena, 0);
  view.draw(f.runtime);
  assert.deepEqual(marks.calls.filter(([m])=>m==='fillCircle').map(call=>call.slice(1)), siege.shape.shelters.map(s=>[s.x,s.y,s.radius]));
});

for (const [attack, art] of [
  ['dune_wave', 'wave'], ['sand_cyclone', 'cyclone'], ['sandfall', 'sandfall'], ['sand_siege', 'storm'],
]) test(`${attack} advances the primary flipbook through different atlas frames`, async () => {
  const f = await stagedCampaignBoss('desert');
  const arena = f.getBossDuel(f.world);
  const cast = f.startDesertCast(f.world, f.id, arena, attack, 3, arena, {x:arena.x, y:arena.y - 210}, 0);
  const {scene, objects} = displayScene(390, 844);
  const view = new f.DesertBossView(scene);
  const asset = `vfx_desert_${art}_flipbook`;
  const framesAt = age => {
    cast.elapsedMs = cast.tellMs + age;
    view.draw(f.runtime);
    return objects.filter(o => o.visible && o.texture === `asset:${asset}`).map(o => o.calls.filter(([m]) => m === 'setTexture').at(-1)[2]);
  };
  const first = framesAt(110);
  assert.ok(first.length, 'attack body is drawn from the animation atlas, not a still');
  assert.deepEqual(framesAt(110), first, 'a paused cast holds its frame');
  const later = framesAt(310);
  assert.notDeepEqual(later, first, 'active time changes the pixels, not only the sprite transform');
  assert.ok([...first, ...later].every(index => Number.isInteger(index) && index >= 0 && index < f.ConfigManager.assets[asset].frameCount));
});

for (const [stage, attacks] of [
  ["meadow", [["sesame_fan"], ["spatula_sweep", "triple_slam"], ["sauce_ring"]]],
  ["desert", [["dune_wave"], ["sand_cyclone", "sandfall"], ["sand_siege", "sand_burrow"]]],
]) test(`${stage} campaign boss cannot skip phased signature attacks under lethal burst`, async () => {
  const f = await stagedCampaignBoss(stage);
  const health = f.health;
  const assertCurrent = (lowerPercent, upperPercent) =>
    assert.ok(health.current >= lowerPercent * health.max && health.current <= upperPercent * health.max);
  const phaseNumbers = new Set();
  const transitions = [];
  assert.equal(f.scene.getBossHudData().phase?.current, 1);
  health.current -= health.max * 10;
  if (stage === 'desert') assertCurrent(.7, .71); else assertCurrent(.6, .61);
  for (let iteration = 0; iteration < 400 && health.current > 0; iteration += 1) {
    const hud = f.scene.getBossHudData();
    phaseNumbers.add(hud.phase.current);
    const beforeHit = health.current;
    health.current -= health.max * 10;
    if (hud.phase.transitioning) {
      transitions.push(hud.phase.current);
      assert.equal(health.current, beforeHit, "transition protects the next segment");
      assert.equal(f.world.components.aoeWarnings.size, 0, "the new phase gets a clean, readable beat");
    }
    f.tick(50);
  }
  assert.equal(health.current, 0, "normal damage can finish the fight once phase three's opener resolves");
  assert.deepEqual([...phaseNumbers], [1, 2, 3]);
  assert.deepEqual([...new Set(transitions)], [2, 3]);
  assert.deepEqual([2, 3].map(phase => transitions.filter(transition => transition === phase).length * 50), [900, 900]);
  assert.deepEqual(attacks, [1, 2, 3].map(phase => f.events.filter(e => e.phase === phase && e.pattern).map(e => e.pattern)));
});

test("desert HUD shows six cells, empties the correct cells and keeps phase legible", async () => {
  const f = await stagedCampaignBoss("desert");
  for (const [width, height] of [[390, 844], [1280, 720]]) {
    const { scene, objects } = displayScene(width, height);
    const layout = f.getUILayout(width, height).boss;
    const bar = new f.BossBarView(scene, layout);
    const hp = f.scene.getBossHudData();
    bar.update(hp);
    const phaseLabel = objects.find(o => o.kind === "text" && /阶段 1\/3/.test(o.text));
    assert.ok(phaseLabel, "show the stage number independently of color");
  assert.match(phaseLabel.text, /沙浪/);
    assert.ok(phaseLabel.width <= layout.width, "phase fits the boss frame");
    const name = objects.find(o => o.kind === "text" && o.text === "沙海堡垒之王");
    assert.ok(name.getBounds().x + name.width < phaseLabel.getBounds().x, "boss name and phase do not collide");
    const fills = objects.filter(o => o.kind === "rectangle" && o.visible && o.fillAlpha === 1).sort((a, b) => a.x - b.x);
    assert.equal(fills.length, 6);
    assert.equal(new Set(fills.map(o => o.fillColor)).size, 3);
    const widths = fills.map(o => o.width);
    bar.update({ ...hp, hp: hp.maxHp * .925 });
    assert.deepEqual(fills.slice(0, 5).map(o => o.width), widths.slice(0, 5));
    assert.ok(fills[5].width < widths[5]);
    bar.update({ ...hp, hp: hp.maxHp * .7, phase: { ...hp.phase, current: 2, transitioning: true } });
    assert.ok(fills[3].visible && !fills[4].visible && !fills[5].visible);
    assert.match(phaseLabel.text, /阶段 2\/3.*转阶段/);
  }
});

for (const phase of [1, 2, 3]) test(`final phase ${phase} cycles exactly four serial skills with complete windups and recovery`, async () => {
  const f = await fixture(phase);
  const recovery = phase === 1 ? 1050 : phase === 2 ? 850 : 700;
  f.tick(1799);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  f.tick(1);
  for (let index = 0; index < 4; index++) {
    const cast = f.events.filter(event => event.pattern).at(-1);
    assert.equal(cast.pattern, patterns[index]);
    assert.equal(cast.bossKind, "final");
    assert.equal(cast.windupMs, windups[index]);
    const warningIds = [...f.world.components.aoeWarnings.keys()];
    assert.ok(warningIds.length > 0);
    new f.MonsterAISystem().update(16, f.runtime);
    assert.deepEqual(f.world.components.velocities.get(f.id), { x: 0, y: 0 });
    f.world.components.transforms.get(f.playerId).y += 400;
    f.tick(windups[index] - 1);
    if (index === 0) assert.equal(f.world.components.enemyProjectiles.size, 0);
    f.tick(1);
    assert.equal(f.world.components.aoeWarnings.size, 0, "finished skill left pending hazards");
    if (index === 0) {
      assert.equal(f.world.components.enemyProjectiles.size, phase === 1 ? 7 : 9);
      for (const projectile of f.world.components.enemyProjectiles.keys()) {
        const velocity = f.world.components.velocities.get(projectile);
        assert.ok(velocity.x > 0, "sesame fan did not retain snapshot aim");
        assert.ok(Math.hypot(velocity.x, velocity.y) >= 195 && Math.hypot(velocity.x, velocity.y) <= 220);
      }
    }
    const casts = f.events.filter(event => event.pattern).length;
    f.tick(recovery - 1);
    assert.equal(f.world.components.aoeWarnings.size, 0);
    assert.equal(f.events.filter(event => event.pattern).length, casts);
    f.tick(1);
  }
  assert.deepEqual(f.events.filter(event => event.pattern).map(event => event.pattern), [...patterns, "sesame_fan"]);
});

test("triple slam is a finite snapshot cluster with three full staggered reaction windows", async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050); f.tick(1050);
  const warnings = [...f.world.components.aoeWarnings];
  assert.equal(warnings.length, 3);
  assert.deepEqual(warnings.map(([, warning]) => warning.totalMs), [1100, 1450, 1800]);
  assert.deepEqual(warnings.map(([, warning]) => Boolean(warning.label)), [true, false, false], "only announce the staggered attack once");
  const snapshots = warnings.map(([id]) => ({ ...f.world.components.transforms.get(id) }));
  for (const snapshot of snapshots) assert.equal(snapshot.radius, 88);
  for (let first = 0; first < 3; first++) for (let second = first + 1; second < 3; second++) {
    assert.ok(Math.hypot(snapshots[first].x - snapshots[second].x, snapshots[first].y - snapshots[second].y) >= snapshots[first].radius + snapshots[second].radius);
  }
  const player = f.world.components.transforms.get(f.playerId);
  const health = f.world.components.health.get(f.playerId);
  f.tick(1099); assert.equal(health.current, 100);
  f.tick(1); assert.equal(health.current, 84);
  Object.assign(player, { x: snapshots[1].x, y: snapshots[1].y });
  f.world.components.players.get(f.playerId).damageCooldownMs = 0;
  f.tick(349); assert.equal(health.current, 84);
  f.tick(1); assert.equal(health.current, 68);
  Object.assign(player, { x: snapshots[2].x, y: snapshots[2].y });
  f.world.components.players.get(f.playerId).damageCooldownMs = 0;
  f.tick(349); assert.equal(health.current, 68);
  f.tick(1); assert.equal(health.current, 52);
  assert.equal(f.world.components.aoeWarnings.size, 0);
});

test("spatula sweep is a locked directional strip, not an untelegraphed charge", async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050); f.tick(1050);
  f.world.components.transforms.get(f.playerId).x = 1000;
  f.tick(1800); f.tick(1050);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "spatula_sweep");
  const warnings = [...f.world.components.aoeWarnings];
  assert.equal(warnings.length, 1);
  const [warningId, warning] = warnings[0];
  assert.equal(warning.shape, 'capsule');
  assert.equal(warning.length, 255);
  assert.equal(warning.angle, 0);
  const center = f.world.components.transforms.get(warningId);
  assert.equal(center.x, 227.5);
  Object.assign(f.world.components.transforms.get(f.playerId), { x: center.x, y: center.radius });
  f.tick(1249); assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 82);
  assert.deepEqual(f.world.components.transforms.get(f.id), { x: 0, y: 0, radius: f.world.components.transforms.get(f.id).radius });
  assert.deepEqual(f.world.components.velocities.get(f.id), { x: 0, y: 0 });
});

test("sauce ring preserves its safe center and bounded outer danger until full windup", async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050); f.tick(1050);
  f.world.components.transforms.get(f.playerId).x = 1000;
  f.tick(1800); f.tick(1050); f.tick(1250); f.tick(1050);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "sauce_ring");
  const [warningId, warning] = [...f.world.components.aoeWarnings][0];
  assert.equal(warning.safeRadius, 110);
  assert.equal(f.world.components.transforms.get(warningId).radius, 260);
  Object.assign(f.world.components.transforms.get(f.playerId), { x: 0, y: 0 });
  f.tick(1249); assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 100);
});

test("long frames cannot skip new warnings, repeat casts, or leave dead-source hazards", async () => {
  const f = await fixture();
  f.tick(20000);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  assert.equal(f.world.components.enemyProjectiles.size, 0);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 1050);
  f.tick(20000);
  assert.equal(f.world.components.enemyProjectiles.size, 7);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  f.tick(20000);
  assert.equal(f.world.components.aoeWarnings.size, 3);
  assert.ok([...f.world.components.aoeWarnings.values()].every(warning => warning.remainingMs >= 1100));
  f.world.components.health.get(f.id).current = 0;
  f.tick(20000);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  assert.equal(f.world.components.enemyProjectiles.size, 7);
});

test("final phase thresholds raise recovery pressure without changing intermediate boss skills", async () => {
  const final = await fixture();
  final.tick(1800);
  const finalHealth = final.world.components.health.get(final.id);
  finalHealth.current = finalHealth.max * .6;
  final.tick(1);
  assert.equal(final.events.at(-1).phase, 2);
  finalHealth.current = finalHealth.max * .3;
  final.tick(1);
  assert.equal(final.events.at(-1).phase, 3);
  assert.ok(final.events.every(event => !event.text.includes("炸锅")));
  const intermediate = await fixture(1, "intermediate");
  intermediate.tick(1500);
  assert.equal(intermediate.events.at(-1).pattern, "oil_fan");
  intermediate.tick(750);
  assert.equal(intermediate.world.components.enemyProjectiles.size, 5);
  intermediate.tick(800);
  assert.equal(intermediate.events.at(-1).pattern, "bombardment");
});

test("settling a run clears all pending boss warnings before terminal presentation", async () => {
  const api = await modules;
  const scene = new api.GameScene();
  scene.playerId = api.createPlayer(scene.world, 0, 0, 210, 100, 100);
  api.createAoeWarning(scene.world, 0, 0, 260, 20, 1250, 110);
  scene.endRun("defeat");
  assert.equal(scene.world.components.aoeWarnings.size, 0);
});

test("final damaging warnings cannot outrun the boss-owned staggered cast clock", async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050); f.tick(1050);
  f.aoe.update(20000, f.runtime);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  assert.equal(f.world.components.aoeWarnings.size, 3);
  f.boss.update(1099, f.runtime); f.aoe.update(0, f.runtime);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.boss.update(1, f.runtime); f.aoe.update(0, f.runtime);
  assert.equal(f.world.components.health.get(f.playerId).current, 84);
  assert.equal(f.world.components.aoeWarnings.size, 2);
});

test("full shared pellet capacity delays the whole final fan and preserves a fresh windup", async () => {
  const f = await fixture();
  const existing = Array.from({ length: 72 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1800);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.events.filter(event => event.pattern).length, 0);
  for (const id of existing.slice(0, 7)) f.world.destroyEntity(id);
  f.tick(0);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "sesame_fan");
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 1050);
  f.tick(1049); assert.equal(f.world.components.enemyProjectiles.size, 65);
  f.tick(1); assert.equal(f.world.components.enemyProjectiles.size, 72);
  f.tick(0); assert.equal(f.world.components.enemyProjectiles.size, 72);
});

test("full shared warning capacity delays even the one-marker final fan", async () => {
  const f = await fixture();
  const existing = Array.from({ length: 18 }, () => f.createAoeWarning(f.world, -1000, -1000, 20, 0, 100000));
  f.tick(1800);
  assert.equal(f.world.components.aoeWarnings.size, 18);
  assert.equal(f.events.filter(event => event.pattern).length, 0);
  f.world.destroyEntity(existing[0]);
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 18);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 7);
  assert.equal(f.world.components.aoeWarnings.size, 17);
});

for (const [pattern, count, priorCasts] of [["triple_slam", 3, 1], ["spatula_sweep", 1, 2]]) test(`${pattern} reserves all its warnings before dealing any damage`, async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050);
  if (priorCasts === 2) {
    f.tick(1050);
    f.world.components.transforms.get(f.playerId).x = 1000;
    f.tick(1800);
  }
  const existing = Array.from({ length: 19 - count }, () => f.createAoeWarning(f.world, -1000, -1000, 20, 0, 100000));
  f.tick(1050);
  assert.equal(f.world.components.aoeWarnings.size, 19 - count, "part of the cluster exceeded the cap");
  assert.equal(f.events.filter(event => event.pattern).length, priorCasts);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.world.destroyEntity(existing[0]);
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 18);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, pattern);
  const sourceWarnings = [...f.world.components.aoeWarnings.values()].filter(warning => warning.sourceId === f.id);
  assert.equal(sourceWarnings.length, count);
  assert.ok(sourceWarnings.every(warning => warning.remainingMs === warning.totalMs));
});

test("new scatter enemies filling capacity during a final windup delay its complete fan instead of truncating it", async () => {
  const f = await fixture();
  Array.from({ length: 65 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1800);
  const beforeScatter = new Set(f.world.components.enemyProjectiles.keys());
  for (const position of [-80, 80]) {
    const id = f.createMonster(f.world, f.ConfigManager.getMonster("chili_scatter"), 100, position);
    f.world.components.monsters.get(id).behaviorTimerMs = 0;
  }
  new f.MonsterBehaviorSystem().update(0, f.runtime);
  assert.equal(f.world.components.enemyProjectiles.size, 71);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 71, "final fan overflowed the mixed shared budget");
  assert.equal(f.world.components.aoeWarnings.size, 1, "the promised fan lost its warning while blocked");
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  for (const id of f.world.components.enemyProjectiles.keys()) if (!beforeScatter.has(id)) f.world.destroyEntity(id);
  f.tick(0);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
});

test("two final bosses cannot overbook fan capacity and death releases the pending reservation", async () => {
  const f = await fixture();
  Array.from({ length: 65 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  const second = f.createMonster(f.world, f.ConfigManager.getMonster("delivery_box"), 0, 100, true);
  f.world.components.monsters.get(second).bossKind = "final";
  f.tick(1800);
  assert.equal(f.world.components.aoeWarnings.size, 1, "two pending fans overbooked the last seven slots");
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  f.world.components.health.get(f.id).current = 0;
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 1);
  assert.equal([...f.world.components.aoeWarnings.values()][0].sourceId, second);
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 1050);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
});

for (const phase of [2, 3]) test(`phase ${phase} reserves all nine sesame pellets under the shared cap`, async () => {
  const f = await fixture(phase);
  const existing = Array.from({ length: 64 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1800);
  assert.equal(f.world.components.aoeWarnings.size, 0, "late fan was admitted with room for only eight pellets");
  f.world.destroyEntity(existing[0]);
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 1);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
});

test("legacy oil fan with seventy existing pellets waits for all five shared slots", async () => {
  const f = await fixture(1, "intermediate");
  const existing = Array.from({ length: 70 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1500);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.events.filter(event => event.pattern).length, 0);
  for (const id of existing.slice(0, 3)) f.world.destroyEntity(id);
  f.tick(0);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "oil_fan");
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 750);
  f.tick(749); assert.equal(f.world.components.enemyProjectiles.size, 67);
  f.tick(1); assert.equal(f.world.components.enemyProjectiles.size, 72);
  f.tick(0); assert.equal(f.world.components.enemyProjectiles.size, 72);
});

const legacyPatterns = ["oil_fan", "bombardment", "charge", "summon", "heat_ring"];
const legacyWindups = [750, 1000, 950, 750, 1200];
for (const [targetIndex, pattern] of legacyPatterns.entries()) test(`legacy ${pattern} reserves its one complete warning under the shared cap`, async () => {
  const f = await fixture(1, "intermediate");
  const health = f.world.components.health.get(f.id);
  health.current = health.max * .1;
  f.tick(1499);
  if (targetIndex > 0) {
    f.tick(1);
    for (let index = 0; index < targetIndex; index++) {
      f.world.components.transforms.get(f.playerId).x += 500;
      f.tick(legacyWindups[index]);
      if (legacyPatterns[index] === "charge") f.tick(650);
      if (index < targetIndex - 1) f.tick(800);
    }
  }
  const existing = Array.from({ length: 18 }, () => f.createAoeWarning(f.world, -1000, -1000, 20, 0, 100000));
  f.tick(targetIndex === 0 ? 1 : 800);
  assert.equal(f.world.components.aoeWarnings.size, 18, "legacy cast exceeded the shared warning cap");
  assert.equal(f.events.filter(event => event.pattern).length, targetIndex);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.world.destroyEntity(existing[0]);
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 18);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, pattern);
  const warning = [...f.world.components.aoeWarnings.values()].find(warning => warning.sourceId === f.id);
  assert.equal(warning.remainingMs, legacyWindups[targetIndex]);
  assert.equal(warning.armed, false);
  f.tick(legacyWindups[targetIndex] - 1);
  assert.equal(f.world.components.health.get(f.playerId).current, 100, "legacy cast hit before its complete warning");
  f.tick(1);
  if (pattern === "bombardment") assert.equal(f.world.components.health.get(f.playerId).current, 85);
});

test("actual scatter filling legacy windup capacity preserves its complete warned five-shot fan", async () => {
  const f = await fixture(1, "intermediate");
  Array.from({ length: 67 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1500);
  const beforeScatter = new Set(f.world.components.enemyProjectiles.keys());
  const scatter = f.createMonster(f.world, f.ConfigManager.getMonster("chili_scatter"), 100, 0);
  f.world.components.monsters.get(scatter).behaviorTimerMs = 0;
  new f.MonsterBehaviorSystem().update(0, f.runtime);
  assert.equal(f.world.components.enemyProjectiles.size, 70);
  f.tick(750);
  assert.equal(f.world.components.enemyProjectiles.size, 70, "legacy fan overflowed the mixed shared cap");
  assert.equal(f.world.components.aoeWarnings.size, 1);
  assert.equal([...f.world.components.aoeWarnings.values()][0].armed, false);
  for (const id of f.world.components.enemyProjectiles.keys()) if (!beforeScatter.has(id)) f.world.destroyEntity(id);
  f.tick(0);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
});

test("legacy and final bosses share pending fan reservations and death releases the legacy slots", async () => {
  const f = await fixture(1, "intermediate");
  Array.from({ length: 65 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  const final = f.createMonster(f.world, f.ConfigManager.getMonster("delivery_box"), 0, 100, true);
  f.world.components.monsters.get(final).bossKind = "final";
  f.tick(1800);
  assert.equal(f.world.components.aoeWarnings.size, 1, "legacy pending slots were not reserved against the final fan");
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "oil_fan");
  f.world.components.health.get(f.id).current = 0;
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 1);
  assert.equal([...f.world.components.aoeWarnings.values()][0].sourceId, final);
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 1050);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
});
