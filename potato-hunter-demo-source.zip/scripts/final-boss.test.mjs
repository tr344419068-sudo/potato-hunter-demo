import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { displayScene } from "./ui-runtime-helpers.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
  export { World } from "./src/entities/World.ts";
  export * from "./src/entities/factories.ts";
  export { ConfigManager } from "./src/managers/ConfigManager.ts";
  export { EventBus } from "./src/managers/EventBus.ts";
  export { GameScene } from "./src/scenes/GameScene.ts";
  export { CampaignDirector, getCampaignBeat } from "./src/campaign/CampaignModel.ts";
  export { BossSystem } from "./src/systems/BossSystem.ts";
  export { MonsterAISystem } from "./src/systems/MonsterAISystem.ts";
  export { AoeWarningSystem } from "./src/systems/AoeWarningSystem.ts";
  export { MonsterBehaviorSystem } from "./src/systems/MonsterBehaviorSystem.ts";
  export { WaveManager } from "./src/managers/WaveManager.ts";
  export { BossBarView } from "./src/ui/BossBarView.ts";
  export { getUILayout } from "./src/ui/UILayout.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless-final-boss", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Scene: class {}, Events: { EventEmitter }, Display: { Color: { HexStringToColor: value => ({ color: parseInt(value.slice(1), 16) }) } }, Math: { Clamp: (value,lower,upper)=>Math.min(upper,Math.max(lower,value)), Between: (lower,upper)=>lower, FloatBetween: (lower,upper)=>lower } };', resolveDir: root }));
  }}],
}).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

const patterns = ["sesame_fan", "triple_slam", "spatula_sweep", "sauce_ring"];
const windups = [1050, 1800, 1250, 1250];

async function fixture(phase = 1, kind = "final") {
  const api = await modules;
  api.EventBus.removeAllListeners();
  const world = new api.World();
  const playerId = api.createPlayer(world, 250, 0, 210, 100, 100);
  const runtime = { world, playerId, waveManager: new api.WaveManager(), scene: { cameras: { main: { shake() {} } } }, stats: { elapsedMs: 360000, kills: 0, bossKills: 0, gold: 0 } };
  const id = api.createMonster(world, api.ConfigManager.getMonster("delivery_box"), 0, 0, true);
  world.components.monsters.get(id).bossKind = kind;
  const health = world.components.health.get(id);
  health.current = health.max * (phase === 3 ? .25 : phase === 2 ? .55 : 1);
  const boss = new api.BossSystem();
  const aoe = new api.AoeWarningSystem();
  const events = [];
  api.EventBus.on("boss:phase", event => events.push(event));
  const tick = deltaMs => { boss.update(deltaMs, runtime); aoe.update(deltaMs, runtime); };
  return { ...api, world, runtime, playerId, id, boss, aoe, events, tick };
}

test('desert boss uses themed labels and emits a ground-impact visual at the true warning radius', async () => {
  const f = await fixture();
  f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
  const volleys = [], strikes = []; f.EventBus.on('hostile:volley', e => volleys.push(e));
  f.EventBus.on('hostile:impact', e => strikes.push(e));
  f.tick(1800);
  assert.match(f.events.at(-1).text, /沙/);
  f.tick(1050);
  assert.equal(volleys[0].style, 'sand');
  assert.ok(volleys[0].angles.every(angle => Math.abs(angle) >= .38), 'the visual fan must leave the gap clear');
  f.tick(1050); f.tick(1800); f.tick(1100);
  const blast = strikes[0];
  assert.ok(blast); assert.equal(blast.radius, 88); assert.equal(blast.style, 'sand');
  assert.match(f.getCampaignBeat(360000, 'desert').objective, /沙海/);
  assert.match(f.getCampaignBeat(0, 'desert').title, /沙/);
});

test('meadow slam warns the larger real hit area, then publishes exactly one matching impact', async () => {
  const f = await fixture();
  const strikes = []; f.EventBus.on('hostile:impact', e => strikes.push(e));
  f.tick(1800); f.tick(1050); f.tick(1050);
  const [id, warning] = [...f.world.components.aoeWarnings][0];
  const target = f.world.components.transforms.get(id);
  assert.equal(target.radius, 88);
  assert.equal(warning.impactStyle, 'slam');
  const player = f.world.components.transforms.get(f.playerId);
  player.x = target.x + 83; player.y = target.y;
  f.tick(1099); assert.equal(strikes.length, 0);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 84);
  assert.deepEqual(strikes.map(({ x, y, radius, style }) => [x, y, radius, style]), [[target.x, target.y, 88, 'slam']]);
  f.tick(1); assert.equal(strikes.length, 1);
});

test('the fryer bombardment uses its full 118-unit tell, even if the player safely dodges', async () => {
  const f = await fixture(1, 'intermediate');
  const strikes = []; f.EventBus.on('hostile:impact', e => strikes.push(e));
  f.tick(1500); f.tick(750); f.tick(800);
  const [id] = [...f.world.components.aoeWarnings.keys()];
  const target = f.world.components.transforms.get(id);
  assert.equal(target.radius, 118);
  f.world.components.transforms.get(f.playerId).x = target.x + 124;
  f.tick(1000);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  assert.equal(strikes[0]?.radius, 118);
  assert.equal(strikes[0]?.style, 'oil');
});

test('desert crystal fan leaves a dodgeable central lane instead of the meadow fan', async () => {
  const f = await fixture();
  f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
  f.tick(1800);
  assert.match(f.events.at(-1).text, /中央|中间/);
  f.tick(1049); assert.equal(f.world.components.enemyProjectiles.size, 0);
  f.tick(1);
  const angles = [...f.world.components.enemyProjectiles.keys()].map(id => {
    const velocity = f.world.components.velocities.get(id);
    return Math.atan2(velocity.y, velocity.x);
  });
  assert.equal(angles.length, 7);
  assert.ok(angles.some(angle => angle < -.35) && angles.some(angle => angle > .35));
  assert.ok(angles.every(angle => Math.abs(angle) >= .35), 'the marked central escape lane must not contain a projectile');
});

test('desert boss staggers sand impacts along its locked aim direction', async () => {
  const f = await fixture();
  f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
  f.tick(1800); f.tick(1050); f.tick(1050);
  const warnings = [...f.world.components.aoeWarnings];
  assert.deepEqual(warnings.map(([, warning]) => warning.totalMs), [1100, 1450, 1800]);
  assert.deepEqual(warnings.map(([id]) => {
    const p = f.world.components.transforms.get(id); return [p.x, p.y];
  }), [[250, 0], [100, 0], [400, 0]]);
  f.tick(1099); assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 84);
});

test('desert cross-sweep targets the locked player location with a clear warning', async () => {
  const f = await fixture();
  f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
  f.tick(1800); f.tick(1050); f.tick(1050);
  f.world.components.transforms.get(f.playerId).x = 1000;
  f.tick(1800); f.tick(1050);
  const warnings = [...f.world.components.aoeWarnings];
  assert.equal(warnings.length, 4);
  assert.deepEqual(warnings.map(([id]) => {
    const p = f.world.components.transforms.get(id); return [p.x, p.y];
  }), [[1000, -120], [1000, -40], [1000, 40], [1000, 120]]);
  f.tick(1249); assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 82);
});

test('desert sandburst warns around the target and rewards moving outside', async () => {
  async function enterStorm() {
    const f = await fixture();
    f.runtime.campaign = { stage: 'desert', spawnMultiplier: 1, ownBossCadence: true };
    f.tick(1800); f.tick(1050); f.tick(1050);
    f.world.components.transforms.get(f.playerId).x = 1000;
    f.tick(1800); f.tick(1050);
    f.world.components.transforms.get(f.playerId).y = 500;
    f.tick(1250); f.tick(1050);
    return f;
  }
  const hit = await enterStorm();
  const [warningId, warning] = [...hit.world.components.aoeWarnings][0];
  const position = hit.world.components.transforms.get(warningId);
  assert.deepEqual([position.x, position.y, position.radius, warning.safeRadius], [1000, 500, 150, undefined]);
  assert.match(warning.label, /离开/);
  hit.tick(1249); assert.equal(hit.world.components.health.get(hit.playerId).current, 100);
  hit.tick(1); assert.equal(hit.world.components.health.get(hit.playerId).current, 80);
  const dodged = await enterStorm();
  dodged.world.components.transforms.get(dodged.playerId).y += 151;
  dodged.tick(1250); assert.equal(dodged.world.components.health.get(dodged.playerId).current, 100);
});

test("campaign final boss gets its own identity, giant art, modest health bonus and objective", async () => {
  const api = await modules;
  const spawn = kind => {
    const scene = new api.GameScene();
    scene.playerId = api.createPlayer(scene.world, 0, 0, 210, 100, 100);
    scene.campaign = new api.CampaignDirector(42);
    scene.stats.elapsedMs = 360000;
    scene.spawnCampaignBoss(kind);
    const id = [...scene.world.components.monsters.keys()][0];
    return { scene, monster: scene.world.components.monsters.get(id), health: scene.world.components.health.get(id), render: scene.world.components.renders.get(id), transform: scene.world.components.transforms.get(id) };
  };
  const intermediate = spawn("intermediate");
  const final = spawn("final");
  assert.equal(final.monster.bossKind, "final");
  assert.equal(intermediate.monster.bossKind, "intermediate");
  assert.equal(final.render.assetId, "boss_burger_tyrant_v4");
  assert.equal(intermediate.render.assetId, api.ConfigManager.boss.assetId);
  assert.ok(final.render.size >= 145 && final.render.size <= 165);
  assert.ok(final.transform.radius > intermediate.transform.radius);
  assert.ok(final.health.max / intermediate.health.max >= 1.2 && final.health.max / intermediate.health.max <= 1.3);
  assert.equal(final.monster.damage, intermediate.monster.damage);
  assert.equal(final.monster.experienceValue, intermediate.monster.experienceValue);
  assert.match(api.getCampaignBeat(360000).objective, /堡垒暴君/);
});

async function stagedCampaignBoss(stage) {
  const api = await modules;
  api.EventBus.removeAllListeners();
  const scene = new api.GameScene();
  scene.runStage = stage;
  scene.playerId = api.createPlayer(scene.world, 250, 0, 210, 100, 100);
  scene.campaign = new api.CampaignDirector(42);
  scene.stats.elapsedMs = 180_000;
  scene.spawnCampaignBoss("final");
  const id = [...scene.world.components.monsters.keys()][0];
  const world = scene.world;
  world.components.transforms.get(id).x = 0;
  world.components.transforms.get(id).y = 0;
  const runtime = {
    world, playerId: scene.playerId, scene: { cameras: { main: { shake() {} } } },
    stats: scene.stats, waveManager: new api.WaveManager(stage),
    campaign: { stage, ownBossCadence: true, spawnMultiplier: 1 },
  };
  const events = [], boss = new api.BossSystem(), aoe = new api.AoeWarningSystem();
  api.EventBus.on("boss:phase", event => events.push(event));
  const tick = (ms) => { boss.update(ms, runtime); aoe.update(ms, runtime); };
  return { ...api, scene, world, id, events, tick, health: world.components.health.get(id) };
}

for (const [stage, attacks] of [
  ["meadow", [["sesame_fan"], ["spatula_sweep", "triple_slam"], ["sauce_ring"]]],
  ["desert", [["sesame_fan"], ["triple_slam", "spatula_sweep"], ["sauce_ring"]]],
]) test(`${stage} campaign boss cannot skip phased signature attacks under lethal burst`, async () => {
  const f = await stagedCampaignBoss(stage);
  const health = f.health;
  const assertCurrent = (lowerPercent, upperPercent) =>
    assert.ok(health.current >= lowerPercent * health.max && health.current <= upperPercent * health.max);
  const phaseNumbers = new Set();
  const transitions = [];
  assert.equal(f.scene.getBossHudData().phase?.current, 1);
  health.current -= health.max * 10;
  assertCurrent(.6, .61);
  for (let iteration = 0; iteration < 400 && health.current > 0; iteration += 1) {
    const hud = f.scene.getBossHudData();
    phaseNumbers.add(hud.phase.current);
    const beforeHit = health.current;
    health.current -= health.max * 10;
    if (hud.phase.transitioning) {
      transitions.push(hud.phase.current);
      assert.equal(health.current, beforeHit, "transition protects the next segment");
      assert.equal(f.world.components.aoeWarnings.size, 0, "the new phase gets a clean, readable beat");
    }
    f.tick(50);
  }
  assert.equal(health.current, 0, "normal damage can finish the fight once phase three's opener resolves");
  assert.deepEqual([...phaseNumbers], [1, 2, 3]);
  assert.deepEqual([...new Set(transitions)], [2, 3]);
  assert.deepEqual([2, 3].map(phase => transitions.filter(transition => transition === phase).length * 50), [900, 900]);
  assert.deepEqual(attacks, [1, 2, 3].map(phase => f.events.filter(e => e.phase === phase && e.pattern).map(e => e.pattern)));
});

test("staged boss HUD shows three distinct fills, empties only the active segment, and labels the phase", async () => {
  const f = await stagedCampaignBoss("desert");
  for (const [width, height] of [[390, 844], [1280, 720]]) {
    const { scene, objects } = displayScene(width, height);
    const layout = f.getUILayout(width, height).boss;
    const bar = new f.BossBarView(scene, layout);
    const hp = f.scene.getBossHudData();
    bar.update(hp);
    const phaseLabel = objects.find(o => o.kind === "text" && /阶段 1\/3/.test(o.text));
    assert.ok(phaseLabel, "show the stage number independently of color");
    assert.match(phaseLabel.text, /沙晶/);
    assert.ok(phaseLabel.width <= layout.width, "phase fits the boss frame");
    const name = objects.find(o => o.kind === "text" && o.text === "沙海堡垒之王");
    assert.ok(name.getBounds().x + name.width < phaseLabel.getBounds().x, "boss name and phase do not collide");
    const fills = objects.filter(o => o.kind === "rectangle" && o.visible && o.fillAlpha === 1).sort((a, b) => a.x - b.x);
    assert.equal(fills.length, 3);
    assert.equal(new Set(fills.map(o => o.fillColor)).size, 3);
    const widths = fills.map(o => o.width);
    bar.update({ ...hp, hp: hp.maxHp * .8 });
    assert.deepEqual(fills.slice(0, 2).map(o => o.width), widths.slice(0, 2));
    assert.ok(fills[2].width < widths[2]);
    bar.update({ ...hp, hp: hp.maxHp * .6, phase: { ...hp.phase, current: 2, transitioning: true } });
    assert.equal(fills[2].visible, false);
    assert.match(phaseLabel.text, /阶段 2\/3.*转阶段/);
  }
});

for (const phase of [1, 2, 3]) test(`final phase ${phase} cycles exactly four serial skills with complete windups and recovery`, async () => {
  const f = await fixture(phase);
  const recovery = phase === 1 ? 1050 : phase === 2 ? 850 : 700;
  f.tick(1799);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  f.tick(1);
  for (let index = 0; index < 4; index++) {
    const cast = f.events.filter(event => event.pattern).at(-1);
    assert.equal(cast.pattern, patterns[index]);
    assert.equal(cast.bossKind, "final");
    assert.equal(cast.windupMs, windups[index]);
    const warningIds = [...f.world.components.aoeWarnings.keys()];
    assert.ok(warningIds.length > 0);
    new f.MonsterAISystem().update(16, f.runtime);
    assert.deepEqual(f.world.components.velocities.get(f.id), { x: 0, y: 0 });
    f.world.components.transforms.get(f.playerId).y += 400;
    f.tick(windups[index] - 1);
    if (index === 0) assert.equal(f.world.components.enemyProjectiles.size, 0);
    f.tick(1);
    assert.equal(f.world.components.aoeWarnings.size, 0, "finished skill left pending hazards");
    if (index === 0) {
      assert.equal(f.world.components.enemyProjectiles.size, phase === 1 ? 7 : 9);
      for (const projectile of f.world.components.enemyProjectiles.keys()) {
        const velocity = f.world.components.velocities.get(projectile);
        assert.ok(velocity.x > 0, "sesame fan did not retain snapshot aim");
        assert.ok(Math.hypot(velocity.x, velocity.y) >= 195 && Math.hypot(velocity.x, velocity.y) <= 220);
      }
    }
    const casts = f.events.filter(event => event.pattern).length;
    f.tick(recovery - 1);
    assert.equal(f.world.components.aoeWarnings.size, 0);
    assert.equal(f.events.filter(event => event.pattern).length, casts);
    f.tick(1);
  }
  assert.deepEqual(f.events.filter(event => event.pattern).map(event => event.pattern), [...patterns, "sesame_fan"]);
});

test("triple slam is a finite snapshot cluster with three full staggered reaction windows", async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050); f.tick(1050);
  const warnings = [...f.world.components.aoeWarnings];
  assert.equal(warnings.length, 3);
  assert.deepEqual(warnings.map(([, warning]) => warning.totalMs), [1100, 1450, 1800]);
  assert.deepEqual(warnings.map(([, warning]) => Boolean(warning.label)), [true, false, false], "only announce the staggered attack once");
  const snapshots = warnings.map(([id]) => ({ ...f.world.components.transforms.get(id) }));
  for (const snapshot of snapshots) assert.equal(snapshot.radius, 88);
  for (let first = 0; first < 3; first++) for (let second = first + 1; second < 3; second++) {
    assert.ok(Math.hypot(snapshots[first].x - snapshots[second].x, snapshots[first].y - snapshots[second].y) >= snapshots[first].radius + snapshots[second].radius);
  }
  const player = f.world.components.transforms.get(f.playerId);
  const health = f.world.components.health.get(f.playerId);
  f.tick(1099); assert.equal(health.current, 100);
  f.tick(1); assert.equal(health.current, 84);
  Object.assign(player, { x: snapshots[1].x, y: snapshots[1].y });
  f.world.components.players.get(f.playerId).damageCooldownMs = 0;
  f.tick(349); assert.equal(health.current, 84);
  f.tick(1); assert.equal(health.current, 68);
  Object.assign(player, { x: snapshots[2].x, y: snapshots[2].y });
  f.world.components.players.get(f.playerId).damageCooldownMs = 0;
  f.tick(349); assert.equal(health.current, 68);
  f.tick(1); assert.equal(health.current, 52);
  assert.equal(f.world.components.aoeWarnings.size, 0);
});

test("spatula sweep is a locked directional strip, not an untelegraphed charge", async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050); f.tick(1050);
  f.world.components.transforms.get(f.playerId).x = 1000;
  f.tick(1800); f.tick(1050);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "spatula_sweep");
  const warnings = [...f.world.components.aoeWarnings];
  assert.ok(warnings.length >= 3 && warnings.length <= 5);
  assert.equal(warnings.filter(([, warning]) => warning.label).length, 1, "strip labels overlap");
  const centers = warnings.map(([id]) => ({ ...f.world.components.transforms.get(id) }));
  assert.ok(centers.every(center => center.y === 0 && center.x > 0));
  Object.assign(f.world.components.transforms.get(f.playerId), { x: centers[1].x, y: centers[1].y });
  f.tick(1249); assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 82);
  assert.deepEqual(f.world.components.transforms.get(f.id), { x: 0, y: 0, radius: f.world.components.transforms.get(f.id).radius });
  assert.deepEqual(f.world.components.velocities.get(f.id), { x: 0, y: 0 });
});

test("sauce ring preserves its safe center and bounded outer danger until full windup", async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050); f.tick(1050);
  f.world.components.transforms.get(f.playerId).x = 1000;
  f.tick(1800); f.tick(1050); f.tick(1250); f.tick(1050);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "sauce_ring");
  const [warningId, warning] = [...f.world.components.aoeWarnings][0];
  assert.equal(warning.safeRadius, 110);
  assert.equal(f.world.components.transforms.get(warningId).radius, 260);
  Object.assign(f.world.components.transforms.get(f.playerId), { x: 0, y: 0 });
  f.tick(1249); assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.tick(1); assert.equal(f.world.components.health.get(f.playerId).current, 100);
});

test("long frames cannot skip new warnings, repeat casts, or leave dead-source hazards", async () => {
  const f = await fixture();
  f.tick(20000);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  assert.equal(f.world.components.enemyProjectiles.size, 0);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 1050);
  f.tick(20000);
  assert.equal(f.world.components.enemyProjectiles.size, 7);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  f.tick(20000);
  assert.equal(f.world.components.aoeWarnings.size, 3);
  assert.ok([...f.world.components.aoeWarnings.values()].every(warning => warning.remainingMs >= 1100));
  f.world.components.health.get(f.id).current = 0;
  f.tick(20000);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  assert.equal(f.world.components.enemyProjectiles.size, 7);
});

test("final phase thresholds raise recovery pressure without changing intermediate boss skills", async () => {
  const final = await fixture();
  final.tick(1800);
  const finalHealth = final.world.components.health.get(final.id);
  finalHealth.current = finalHealth.max * .6;
  final.tick(1);
  assert.equal(final.events.at(-1).phase, 2);
  finalHealth.current = finalHealth.max * .3;
  final.tick(1);
  assert.equal(final.events.at(-1).phase, 3);
  assert.ok(final.events.every(event => !event.text.includes("炸锅")));
  const intermediate = await fixture(1, "intermediate");
  intermediate.tick(1500);
  assert.equal(intermediate.events.at(-1).pattern, "oil_fan");
  intermediate.tick(750);
  assert.equal(intermediate.world.components.enemyProjectiles.size, 5);
  intermediate.tick(800);
  assert.equal(intermediate.events.at(-1).pattern, "bombardment");
});

test("settling a run clears all pending boss warnings before terminal presentation", async () => {
  const api = await modules;
  const scene = new api.GameScene();
  scene.playerId = api.createPlayer(scene.world, 0, 0, 210, 100, 100);
  api.createAoeWarning(scene.world, 0, 0, 260, 20, 1250, 110);
  scene.endRun("defeat");
  assert.equal(scene.world.components.aoeWarnings.size, 0);
});

test("final damaging warnings cannot outrun the boss-owned staggered cast clock", async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050); f.tick(1050);
  f.aoe.update(20000, f.runtime);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  assert.equal(f.world.components.aoeWarnings.size, 3);
  f.boss.update(1099, f.runtime); f.aoe.update(0, f.runtime);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.boss.update(1, f.runtime); f.aoe.update(0, f.runtime);
  assert.equal(f.world.components.health.get(f.playerId).current, 84);
  assert.equal(f.world.components.aoeWarnings.size, 2);
});

test("full shared pellet capacity delays the whole final fan and preserves a fresh windup", async () => {
  const f = await fixture();
  const existing = Array.from({ length: 72 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1800);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.events.filter(event => event.pattern).length, 0);
  for (const id of existing.slice(0, 7)) f.world.destroyEntity(id);
  f.tick(0);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "sesame_fan");
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 1050);
  f.tick(1049); assert.equal(f.world.components.enemyProjectiles.size, 65);
  f.tick(1); assert.equal(f.world.components.enemyProjectiles.size, 72);
  f.tick(0); assert.equal(f.world.components.enemyProjectiles.size, 72);
});

test("full shared warning capacity delays even the one-marker final fan", async () => {
  const f = await fixture();
  const existing = Array.from({ length: 18 }, () => f.createAoeWarning(f.world, -1000, -1000, 20, 0, 100000));
  f.tick(1800);
  assert.equal(f.world.components.aoeWarnings.size, 18);
  assert.equal(f.events.filter(event => event.pattern).length, 0);
  f.world.destroyEntity(existing[0]);
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 18);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 7);
  assert.equal(f.world.components.aoeWarnings.size, 17);
});

for (const [pattern, count, priorCasts] of [["triple_slam", 3, 1], ["spatula_sweep", 4, 2]]) test(`${pattern} reserves its entire visible cluster before dealing any damage`, async () => {
  const f = await fixture();
  f.tick(1800); f.tick(1050);
  if (priorCasts === 2) {
    f.tick(1050);
    f.world.components.transforms.get(f.playerId).x = 1000;
    f.tick(1800);
  }
  const existing = Array.from({ length: 19 - count }, () => f.createAoeWarning(f.world, -1000, -1000, 20, 0, 100000));
  f.tick(1050);
  assert.equal(f.world.components.aoeWarnings.size, 19 - count, "part of the cluster exceeded the cap");
  assert.equal(f.events.filter(event => event.pattern).length, priorCasts);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.world.destroyEntity(existing[0]);
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 18);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, pattern);
  const sourceWarnings = [...f.world.components.aoeWarnings.values()].filter(warning => warning.sourceId === f.id);
  assert.equal(sourceWarnings.length, count);
  assert.ok(sourceWarnings.every(warning => warning.remainingMs === warning.totalMs));
});

test("new scatter enemies filling capacity during a final windup delay its complete fan instead of truncating it", async () => {
  const f = await fixture();
  Array.from({ length: 65 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1800);
  const beforeScatter = new Set(f.world.components.enemyProjectiles.keys());
  for (const position of [-80, 80]) {
    const id = f.createMonster(f.world, f.ConfigManager.getMonster("chili_scatter"), 100, position);
    f.world.components.monsters.get(id).behaviorTimerMs = 0;
  }
  new f.MonsterBehaviorSystem().update(0, f.runtime);
  assert.equal(f.world.components.enemyProjectiles.size, 71);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 71, "final fan overflowed the mixed shared budget");
  assert.equal(f.world.components.aoeWarnings.size, 1, "the promised fan lost its warning while blocked");
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  for (const id of f.world.components.enemyProjectiles.keys()) if (!beforeScatter.has(id)) f.world.destroyEntity(id);
  f.tick(0);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
});

test("two final bosses cannot overbook fan capacity and death releases the pending reservation", async () => {
  const f = await fixture();
  Array.from({ length: 65 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  const second = f.createMonster(f.world, f.ConfigManager.getMonster("delivery_box"), 0, 100, true);
  f.world.components.monsters.get(second).bossKind = "final";
  f.tick(1800);
  assert.equal(f.world.components.aoeWarnings.size, 1, "two pending fans overbooked the last seven slots");
  assert.equal(f.events.filter(event => event.pattern).length, 1);
  f.world.components.health.get(f.id).current = 0;
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 1);
  assert.equal([...f.world.components.aoeWarnings.values()][0].sourceId, second);
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 1050);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
});

for (const phase of [2, 3]) test(`phase ${phase} reserves all nine sesame pellets under the shared cap`, async () => {
  const f = await fixture(phase);
  const existing = Array.from({ length: 64 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1800);
  assert.equal(f.world.components.aoeWarnings.size, 0, "late fan was admitted with room for only eight pellets");
  f.world.destroyEntity(existing[0]);
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 1);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
});

test("legacy oil fan with seventy existing pellets waits for all five shared slots", async () => {
  const f = await fixture(1, "intermediate");
  const existing = Array.from({ length: 70 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1500);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.events.filter(event => event.pattern).length, 0);
  for (const id of existing.slice(0, 3)) f.world.destroyEntity(id);
  f.tick(0);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "oil_fan");
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 750);
  f.tick(749); assert.equal(f.world.components.enemyProjectiles.size, 67);
  f.tick(1); assert.equal(f.world.components.enemyProjectiles.size, 72);
  f.tick(0); assert.equal(f.world.components.enemyProjectiles.size, 72);
});

const legacyPatterns = ["oil_fan", "bombardment", "charge", "summon", "heat_ring"];
const legacyWindups = [750, 1000, 950, 750, 1200];
for (const [targetIndex, pattern] of legacyPatterns.entries()) test(`legacy ${pattern} reserves its one complete warning under the shared cap`, async () => {
  const f = await fixture(1, "intermediate");
  const health = f.world.components.health.get(f.id);
  health.current = health.max * .1;
  f.tick(1499);
  if (targetIndex > 0) {
    f.tick(1);
    for (let index = 0; index < targetIndex; index++) {
      f.world.components.transforms.get(f.playerId).x += 500;
      f.tick(legacyWindups[index]);
      if (legacyPatterns[index] === "charge") f.tick(650);
      if (index < targetIndex - 1) f.tick(800);
    }
  }
  const existing = Array.from({ length: 18 }, () => f.createAoeWarning(f.world, -1000, -1000, 20, 0, 100000));
  f.tick(targetIndex === 0 ? 1 : 800);
  assert.equal(f.world.components.aoeWarnings.size, 18, "legacy cast exceeded the shared warning cap");
  assert.equal(f.events.filter(event => event.pattern).length, targetIndex);
  assert.equal(f.world.components.health.get(f.playerId).current, 100);
  f.world.destroyEntity(existing[0]);
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 18);
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, pattern);
  const warning = [...f.world.components.aoeWarnings.values()].find(warning => warning.sourceId === f.id);
  assert.equal(warning.remainingMs, legacyWindups[targetIndex]);
  assert.equal(warning.armed, false);
  f.tick(legacyWindups[targetIndex] - 1);
  assert.equal(f.world.components.health.get(f.playerId).current, 100, "legacy cast hit before its complete warning");
  f.tick(1);
  if (pattern === "bombardment") assert.equal(f.world.components.health.get(f.playerId).current, 85);
});

test("actual scatter filling legacy windup capacity preserves its complete warned five-shot fan", async () => {
  const f = await fixture(1, "intermediate");
  Array.from({ length: 67 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  f.tick(1500);
  const beforeScatter = new Set(f.world.components.enemyProjectiles.keys());
  const scatter = f.createMonster(f.world, f.ConfigManager.getMonster("chili_scatter"), 100, 0);
  f.world.components.monsters.get(scatter).behaviorTimerMs = 0;
  new f.MonsterBehaviorSystem().update(0, f.runtime);
  assert.equal(f.world.components.enemyProjectiles.size, 70);
  f.tick(750);
  assert.equal(f.world.components.enemyProjectiles.size, 70, "legacy fan overflowed the mixed shared cap");
  assert.equal(f.world.components.aoeWarnings.size, 1);
  assert.equal([...f.world.components.aoeWarnings.values()][0].armed, false);
  for (const id of f.world.components.enemyProjectiles.keys()) if (!beforeScatter.has(id)) f.world.destroyEntity(id);
  f.tick(0);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
  assert.equal(f.world.components.aoeWarnings.size, 0);
  assert.equal(f.events.filter(event => event.pattern).length, 1);
});

test("legacy and final bosses share pending fan reservations and death releases the legacy slots", async () => {
  const f = await fixture(1, "intermediate");
  Array.from({ length: 65 }, () => f.createEnemyProjectile(f.world, -1000, -1000, 0, 0, 1));
  const final = f.createMonster(f.world, f.ConfigManager.getMonster("delivery_box"), 0, 100, true);
  f.world.components.monsters.get(final).bossKind = "final";
  f.tick(1800);
  assert.equal(f.world.components.aoeWarnings.size, 1, "legacy pending slots were not reserved against the final fan");
  assert.equal(f.events.filter(event => event.pattern).at(-1).pattern, "oil_fan");
  f.world.components.health.get(f.id).current = 0;
  f.tick(0);
  assert.equal(f.world.components.aoeWarnings.size, 1);
  assert.equal([...f.world.components.aoeWarnings.values()][0].sourceId, final);
  assert.equal([...f.world.components.aoeWarnings.values()][0].remainingMs, 1050);
  f.tick(1050);
  assert.equal(f.world.components.enemyProjectiles.size, 72);
});
