import { access, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const PNG_SIGNATURE = "89504e470d0a1a0a";

function findDuplicateIds(source) {
  const seen = new Set();
  const duplicates = new Set();
  const entryPattern = /^  "([^"]+)":\s*\{/gm;

  for (const match of source.matchAll(entryPattern)) {
    const assetId = match[1];
    if (seen.has(assetId)) {
      duplicates.add(assetId);
    }
    seen.add(assetId);
  }

  return [...duplicates];
}

async function readPngDimensions(filePath) {
  const bytes = await readFile(filePath);
  if (bytes.length < 24 || bytes.subarray(0, 8).toString("hex") !== PNG_SIGNATURE || bytes.subarray(12, 16).toString("ascii") !== "IHDR") {
    throw new Error("invalid PNG header");
  }

  return {
    width: bytes.readUInt32BE(16),
    height: bytes.readUInt32BE(20),
  };
}

export async function validateAssets({ rootDir = process.cwd() } = {}) {
  const manifestPath = path.join(rootDir, "src", "configs", "assets.json");
  const publicDir = path.join(rootDir, "public");
  const source = await readFile(manifestPath, "utf8");
  const assets = JSON.parse(source);
  const errors = [];
  let missing = 0;
  let dimensionMismatches = 0;

  for (const assetId of findDuplicateIds(source)) {
    errors.push(`duplicate asset id: ${assetId}`);
  }

  for (const [assetId, asset] of Object.entries(assets)) {
    if (!asset.path) {
      errors.push(`asset has no path: ${assetId}`);
      continue;
    }

    const filePath = path.resolve(publicDir, asset.path);
    if (filePath !== publicDir && !filePath.startsWith(`${publicDir}${path.sep}`)) {
      errors.push(`asset path escapes public/: ${assetId} -> ${asset.path}`);
      continue;
    }

    try {
      await access(filePath);
    } catch {
      missing += 1;
      errors.push(`missing asset: ${assetId} -> public/${asset.path}`);
      continue;
    }

    if (path.extname(filePath).toLowerCase() !== ".png" || !Number.isInteger(asset.width) || !Number.isInteger(asset.height)) {
      continue;
    }

    try {
      const actual = await readPngDimensions(filePath);
      if (actual.width !== asset.width || actual.height !== asset.height) {
        dimensionMismatches += 1;
        errors.push(
          `dimension mismatch: ${assetId} expected ${asset.width}x${asset.height}, actual ${actual.width}x${actual.height}`,
        );
      }
    } catch (error) {
      dimensionMismatches += 1;
      errors.push(`invalid PNG: ${assetId} -> ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  return {
    ok: errors.length === 0,
    errors,
    total: Object.keys(assets).length,
    missing,
    dimensionMismatches,
  };
}

async function main() {
  const result = await validateAssets();
  for (const error of result.errors) {
    console.error(`- ${error}`);
  }
  console.log(
    `Checked ${result.total} assets: ${result.missing} missing assets, ${result.dimensionMismatches} dimension mismatches.`,
  );
  if (!result.ok) {
    process.exitCode = 1;
  }
}

const isDirectRun = process.argv[1]
  ? pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url
  : fileURLToPath(import.meta.url) === "";

if (isDirectRun) {
  await main();
}
