import assert from "node:assert/strict";
import test from "node:test";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";
import { displayScene } from "./ui-runtime-helpers.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const optionalExport = (path, names) => existsSync(`${root}${path}`) ? `export { ${names.join(", ")} } from "./${path}";` : names.map(name => `export const ${name} = undefined;`).join("\n");
const modules = build({ stdin: { contents: `
export { SkillStatsCalculator } from "./src/managers/SkillStatsCalculator.ts";
export { SkillManager } from "./src/managers/SkillManager.ts";
export { ConfigManager } from "./src/managers/ConfigManager.ts";
export { CombatVfxSystem } from "./src/systems/CombatVfxSystem.ts";
export { RenderSystem } from "./src/systems/RenderSystem.ts";
export { AuraSystem } from "./src/systems/AuraSystem.ts";
export { World } from "./src/entities/World.ts";
export { EventBus } from "./src/managers/EventBus.ts";
export * from "./src/ui/UIModel.ts";
${optionalExport("src/systems/AreaVfxModel.ts", ["getAreaVfxFrame", "getAreaVfxSpec", "AREA_ART_DIAMETER_COVERAGE"])}
${optionalExport("src/systems/AreaVfxView.ts", ["AreaVfxView"])}
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
plugins: [{ name: "headless-area", setup(context) {
  context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless-area" }));
  context.onLoad({ filter: /.*/, namespace: "headless-area" }, () => ({ contents: `import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Scenes: { Events: { SHUTDOWN: "shutdown" } }, BlendModes: { NORMAL: 0, ADD: 1 }, Display: { Color: { HexStringToColor: value=>({color:parseInt(value.slice(1),16)}) } }, Math: { Clamp: (value,min,max)=>Math.min(max,Math.max(min,value)), Between: (min,max)=>(min+max)/2, FloatBetween: (min,max)=>(min+max)/2 } };`, resolveDir: root }));
}}] }).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

const areaIds = ["vfx_poison_area_v4", "vfx_ketchup_area_v4", "vfx_poison_puff_v4", "vfx_ketchup_splash_v4"];
const profile = (skillId, radius, vfxKind) => ({ skillId, radius, vfxKind, color: vfxKind === "poison" ? 0x80b918 : 0xef476f, name: skillId, tags: [], effects: [], damagePerSecond: 5, tickMs: 180 });

async function fixture({ loaded = true, placeholder = false } = {}) {
  const api = await modules; api.EventBus.removeAllListeners();
  const display = displayScene(1280, 720); const textures = new Map();
  if (loaded) for (const assetId of areaIds) {
    const key = `asset:${assetId}`;
    textures.set(key, { key: placeholder ? "__MISSING" : key, getSourceImage: () => ({ complete: true, naturalWidth: 512, naturalHeight: 512, width: 512, height: 512 }), get: () => ({ realWidth: 512, realHeight: 512 }) });
  }
  display.scene.textures = { exists: key => textures.has(key), get: key => textures.get(key), remove: key => textures.delete(key) };
  display.scene.cameras.main.worldView = { x: 0, y: 0, width: 1280, height: 720 };
  const world = new api.World(); const playerId = world.createEntity();
  world.components.transforms.set(playerId, { x: 300, y: 250, radius: 20 });
  world.components.players.set(playerId, { level: 5 });
  let profiles = [profile("toxic_tomato", 150, "poison"), profile("ketchup_aura", 156, "ketchup")];
  const runtime = { world, playerId, skillManager: { getAuraProfiles: () => profiles }, stats: { elapsedMs: 0 } };
  return { ...api, ...display, runtime, textures, setProfiles: value => { profiles = value; } };
}

test("every aura has exact 14%-of-base radius growth at levels 1 through 5, including area buffs", async () => {
  const { ConfigManager, SkillStatsCalculator } = await modules;
  for (const aura of ConfigManager.skills.filter(skill => skill.aura)) for (const areaLevel of [0, 3, 100]) for (let level = 1; level <= 5; level++) {
    const levels = new Map([[aura.id, level], ["spice_radius", areaLevel]]);
    const areaSkill = ConfigManager.skills.find(skill => skill.effects.some(effect => effect.type === "stat_modifier" && effect.stat === "areaMultiplier"));
    if (areaSkill) levels.set(areaSkill.id, areaLevel);
    const calculator = new SkillStatsCalculator({ getLevel: id => levels.get(id) ?? 0 });
    const stats = calculator.getCombatStats(); const actual = calculator.getAuraProfiles().find(item => item.skillId === aura.id);
    assert.equal(actual.radius, Math.min(520, aura.aura.radius * stats.areaMultiplier * (1 + .14 * (level - 1))), `${aura.id} Lv${level}, area Lv${areaLevel}`);
  }
});

test("combat damage and essential circular boundary use the same upgraded aura radius", async () => {
  const f = await fixture({ loaded: false });
  const manager = new f.SkillManager(); manager.levelUp("ketchup_aura"); manager.levelUp("ketchup_aura");
  f.runtime.skillManager = manager;
  f.runtime.world.components.transforms.get(f.runtime.playerId).x = 0;
  f.runtime.world.components.transforms.get(f.runtime.playerId).y = 0;
  const radius = manager.getAuraProfiles()[0].radius;
  for (const distance of [radius - 1, radius + 1]) {
    const entityId = f.runtime.world.createEntity();
    f.runtime.world.components.transforms.set(entityId, { x: distance, y: 0, radius: 1 });
    f.runtime.world.components.health.set(entityId, { current: 100, max: 100 });
    f.runtime.world.components.monsters.set(entityId, { behavior: "normal" });
  }
  new f.AuraSystem().update(16, f.runtime);
  const targets = [...f.runtime.world.components.monsters.keys()];
  assert.ok(f.runtime.world.components.health.get(targets[0]).current < 100);
  assert.equal(f.runtime.world.components.health.get(targets[1]).current, 100);
  const graphics = f.scene.add.graphics();
  f.RenderSystem.prototype.drawAura.call({ graphics }, f.runtime);
  assert.ok(graphics.calls.some(call => call[0] === "strokeCircle" && Math.abs(call[3] - radius) < .001));
});

test("upgrade benefit names the current and next base radius rather than only a range tag", async () => {
  const { getSkillUpgradeBenefit, ConfigManager } = await modules;
  assert.equal(typeof getSkillUpgradeBenefit, "function");
  const ketchup = ConfigManager.getSkill("ketchup_aura");
  assert.match(getSkillUpgradeBenefit(ketchup, 1), /半径\s*190\s*→\s*217/);
  assert.match(getSkillUpgradeBenefit(ketchup, 4), /半径\s*270\s*→\s*296/);
  assert.match(getSkillUpgradeBenefit(ketchup, 0), /半径\s*190/);
  const weapon = ConfigManager.getSkill("fire_potato");
  assert.equal(getSkillUpgradeBenefit(weapon, 1), weapon.description.split(/[。；]/)[0]);
});

test("area frame defines thin expanding waves, distinct palettes and six contained decorations", async () => {
  const { getAreaVfxFrame, getAreaVfxSpec, AREA_ART_DIAMETER_COVERAGE } = await modules;
  assert.equal(typeof getAreaVfxFrame, "function");
  const poison = getAreaVfxSpec("poison"), ketchup = getAreaVfxSpec("ketchup");
  assert.notEqual(poison.primaryColor, ketchup.primaryColor);
  assert.equal(poison.ringAssetId, undefined); assert.equal(ketchup.ringAssetId, undefined);
  for (const kind of ["poison", "ketchup"]) for (const elapsed of [0, 250, 3000, 90000]) {
    const frame = getAreaVfxFrame(kind, 156, elapsed, false);
    assert.equal(frame.diameter * AREA_ART_DIAMETER_COVERAGE, 312);
    assert.equal(frame.waves.length, 2);
    for (const wave of frame.waves) {
      assert.ok(wave.scale >= .32 && wave.scale <= 1);
      assert.ok(wave.alpha >= 0 && wave.alpha <= .65);
    }
    assert.equal(frame.puffs.length, 6);
    for (const puff of frame.puffs) assert.ok(Math.hypot(puff.x, puff.y) + puff.size / 2 <= 156 + .001);
  }
});

test("wave centers and upgraded radii follow hero on the next frame without allocating new objects", async () => {
  const f = await fixture(); assert.equal(typeof f.AreaVfxView, "function");
  const view = new f.AreaVfxView(f.scene); view.update(16, f.runtime);
  const rings = [...view.layers.values()].flatMap(layer => layer.waves.map(wave => wave.visual));
  assert.equal(rings.length, 4); assert.ok(f.objects.length <= 20);
  assert.equal(f.objects.filter(object => object.kind === "image").length, 0);
  for (const [index, ring] of rings.entries()) {
    const radius = index < 2 ? 150 : 156;
    assert.ok(ring.calls.some(call => call[0] === "strokeCircle" && call[3] === radius));
    assert.equal(ring.blendMode, 0); assert.ok(ring.depth < 1); assert.equal(ring.x, 300); assert.equal(ring.y, 250);
  }
  const count = f.objects.length;
  f.runtime.world.components.transforms.get(f.runtime.playerId).x = 410;
  f.setProfiles([profile("toxic_tomato", 200, "poison"), profile("ketchup_aura", 220, "ketchup")]);
  view.update(16, f.runtime);
  assert.equal(f.objects.length, count); assert.equal(f.tweens.length, 0);
  assert.ok(rings.every(ring => ring.x === 410));
  assert.ok(rings[0].calls.some(call => call[0] === "strokeCircle" && call[3] === 200));
  assert.ok(rings[2].calls.some(call => call[0] === "strokeCircle" && call[3] === 220));
  for (let frame = 0; frame < 360; frame++) view.update(16, f.runtime);
  assert.equal(f.objects.length, count);
  assert.equal(f.scene.cameras.main.shakes + f.scene.cameras.main.flashes, 0); view.destroy();
});

test("pause freezes wave phases while reduced effects keep one wave and two motes per area", async () => {
  const f = await fixture(); assert.equal(typeof f.AreaVfxView, "function");
  const view = new f.AreaVfxView(f.scene); view.update(150, f.runtime);
  const graphics = f.objects.filter(object => object.kind === "graphics"); const before = graphics.map(g => [g.x, g.y, g.rotation, g.alpha, g.scaleX]);
  view.update(0, f.runtime); assert.deepEqual(graphics.map(g => [g.x, g.y, g.rotation, g.alpha, g.scaleX]), before);
  view.setReducedEffects(true); view.update(16, f.runtime);
  assert.equal(graphics.filter(g => g.visible).length, 6);
  view.setReducedEffects(false); view.update(16, f.runtime);
  assert.equal(graphics.filter(g => g.visible).length, 16);
  view.destroy();
});

test("at most three persistent areas allocate 24 objects even with an oversized profile list", async () => {
  const f = await fixture();
  f.setProfiles(Array.from({ length: 12 }, (_, index) => profile(`area_${index}`, 150 + index * 10, index % 2 ? "ketchup" : "poison")));
  const view = new f.AreaVfxView(f.scene); view.update(16, f.runtime);
  for (let frame = 0; frame < 200; frame++) view.update(16, f.runtime);
  assert.equal(f.objects.length, 24);
  assert.equal(f.objects.filter(object => !object.destroyed).length, 24);
  view.destroy(); assert.ok(f.objects.every(object => object.destroyed));
});

for (const placeholder of [false, true]) test(`missing or placeholder area imagery keeps a circular fallback (${placeholder})`, async () => {
  const f = await fixture({ loaded: placeholder, placeholder }); assert.equal(typeof f.AreaVfxView, "function");
  const view = new f.AreaVfxView(f.scene); view.update(16, f.runtime);
  assert.equal(f.objects.filter(object => object.kind === "image").length, 0);
  assert.ok(f.objects.some(object => object.kind === "graphics" && object.calls.some(call => call[0] === "strokeCircle" && call[3] === 150)));
  assert.ok(f.objects.length <= 20); view.destroy();
});

test("skill loss, evolution replacement, missing hero and repeated destroy release all area resources", async () => {
  const f = await fixture(); assert.equal(typeof f.AreaVfxView, "function");
  const manager = new f.SkillManager({ enforceSlots: true });
  manager.levelUp("toxic_tomato"); manager.levelUp("toxic_burst_cloud");
  assert.equal(manager.getAuraProfiles().filter(item => item.vfxKind === "poison").length, 1);
  const view = new f.AreaVfxView(f.scene); view.update(16, f.runtime);
  f.setProfiles([profile("toxic_burst_cloud", 160, "poison")]); view.update(16, f.runtime);
  assert.ok(f.objects.filter(object => !object.destroyed).length <= 10);
  f.setProfiles([]); view.update(16, f.runtime); assert.ok(f.objects.every(object => object.destroyed));
  f.setProfiles([profile("toxic_tomato", 150, "poison")]); view.update(16, f.runtime);
  f.runtime.world.components.transforms.delete(f.runtime.playerId); view.update(16, f.runtime);
  assert.ok(f.objects.every(object => object.destroyed)); view.destroy(); view.destroy();
  assert.equal(f.textures.size, 4);
});

test("CombatVfxSystem updates persistent areas in reduced mode and suppresses repeating aura-tick ring bursts", async () => {
  const f = await fixture(); const system = new f.CombatVfxSystem(f.scene);
  f.EventBus.emit("presentation:preferences", { reducedEffects: true }); system.update(16, f.runtime);
  const graphics = f.objects.filter(object => object.kind === "graphics");
  assert.equal(graphics.length, 16);
  const count = f.objects.length, tweenCount = f.tweens.length;
  for (let tick = 0; tick < 60; tick++) f.EventBus.emit("aura:pulse", { x: 300, y: 250, radius: 150, color: 0x80b918, vfxKind: "poison" });
  assert.equal(f.objects.length, count); assert.equal(f.tweens.length, tweenCount);
  system.destroy(); assert.ok(graphics.every(g => g.destroyed));
});

test("terminal result releases wave fields even when combat updates stop", async () => {
  const f = await fixture(), system = new f.CombatVfxSystem(f.scene);
  system.update(160, f.runtime);
  const graphics = f.objects.filter(object => object.kind === "graphics");
  assert.equal(graphics.length, 16);
  f.EventBus.emit("game:over", { outcome: "defeat" });
  assert.ok(graphics.every(g => g.destroyed));
  system.update(160, f.runtime); assert.equal(f.objects.length, 16);
  system.destroy();
});
