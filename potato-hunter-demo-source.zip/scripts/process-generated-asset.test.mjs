import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import test from "node:test";

test("transparent exports preserve alpha, enclosed holes and opaque white details", async () => {
  const directory = await mkdtemp(join(tmpdir(), "potato-alpha-"));
  try {
    const source = join(directory, "source.png"), output = join(directory, "output.png");
    const create = spawnSync("python3", ["-c", "from PIL import Image,ImageDraw; import sys; im=Image.new('RGBA',(40,40),(235,235,235,0)); d=ImageDraw.Draw(im); d.rectangle((8,8,31,31),fill=(20,60,160,255)); d.rectangle((11,11,15,15),fill=(255,255,255,255)); d.rectangle((19,19,23,23),fill=(235,235,235,0)); im.save(sys.argv[1])", source]);
    assert.equal(create.status, 0, create.stderr.toString());
    const process = spawnSync("python3", ["scripts/process-generated-asset.py", source, output, "--size", "32"]);
    assert.equal(process.status, 0, process.stderr.toString());
    const inspect = spawnSync("python3", ["-c", "from PIL import Image; import sys; im=Image.open(sys.argv[1]); print(im.getpixel((0,0))[3], im.getpixel((17,17))[3], sum(1 for r,g,b,a in im.getdata() if r>240 and g>240 and b>240 and a>240))", output]);
    assert.equal(inspect.status, 0, inspect.stderr.toString());
    const [corner, hole, whites] = inspect.stdout.toString().trim().split(/\s+/).map(Number);
    assert.equal(corner, 0);
    assert.ok(hole < 20, `enclosed transparency became opaque (${hole})`);
    assert.ok(whites > 0, "opaque white eye highlights must remain");
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test("all-chroma mode removes enclosed magenta holes from character sprites", async () => {
  const directory = await mkdtemp(join(tmpdir(), "potato-chroma-"));
  const source = join(directory, "source.png");
  const output = join(directory, "output.png");

  try {
    const create = spawnSync("python3", [
      "-c",
      "from PIL import Image, ImageDraw; import sys; im=Image.new('RGB',(32,32),(255,0,255)); d=ImageDraw.Draw(im); d.rectangle((6,6,25,25),fill=(30,80,180)); d.rectangle((11,11,20,20),fill=(255,0,255)); im.save(sys.argv[1])",
      source,
    ]);
    assert.equal(create.status, 0, create.stderr.toString());

    const process = spawnSync("python3", [
      "scripts/process-generated-asset.py",
      source,
      output,
      "--size",
      "32",
      "--all-chroma",
    ]);
    assert.equal(process.status, 0, process.stderr.toString());

    const inspect = spawnSync("python3", [
      "-c",
      "from PIL import Image; import sys; im=Image.open(sys.argv[1]).convert('RGBA'); center=im.getpixel((16,16))[3]; fringe=sum(1 for r,g,b,a in im.getdata() if a>0 and r>165 and b>165 and g<115 and ((r+b)//2-g)>105); print(center, fringe)",
      output,
    ]);
    assert.equal(inspect.status, 0, inspect.stderr.toString());
    const [centerAlpha, fringePixels] = inspect.stdout.toString().trim().split(/\s+/).map(Number);
    assert.equal(centerAlpha, 0);
    assert.equal(fringePixels, 0);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});
