// Refine the existing AI-generated tile without overwriting the original.
import { createCanvas, loadImage } from '@napi-rs/canvas';
import { writeFile } from 'node:fs/promises';

const source = await loadImage(new URL('../public/assets/backgrounds/desert_tile-v1.webp', import.meta.url).pathname);
const small = createCanvas(96, 96);
const smallContext = small.getContext('2d');
smallContext.imageSmoothingEnabled = true;
smallContext.imageSmoothingQuality = 'high';
smallContext.drawImage(source, 0, 0, 96, 96);

const tile = createCanvas(512, 512);
const context = tile.getContext('2d');
context.imageSmoothingEnabled = true;
context.imageSmoothingQuality = 'high';
context.drawImage(small, 0, 0, 512, 512);
context.fillStyle = 'rgba(183, 163, 132, 0.42)';
context.fillRect(0, 0, 512, 512);

await writeFile(new URL('../public/assets/backgrounds/desert_tile-v2.webp', import.meta.url), await tile.encode('webp', 95));
