import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { access, readFile, stat } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

async function readJson(relativePath) {
  return JSON.parse(await readFile(new URL(relativePath, root), "utf8"));
}

test("every combat skill has a registered skill icon", async () => {
  const [{ skills }, assets] = await Promise.all([
    readJson("src/configs/skills.json"),
    readJson("src/configs/assets.json"),
  ]);

  const missingIcons = skills
    .filter((skill) => !skill.iconAssetId || assets[skill.iconAssetId]?.type !== "skill_icon")
    .map((skill) => skill.id);

  assert.deepEqual(missingIcons, []);

  await Promise.all(
    skills.map(async (skill) => {
      const iconPath = new URL(`public/${assets[skill.iconAssetId].path}`, root);
      await access(iconPath);
      assert.ok((await stat(iconPath)).size > 0, `${skill.id} icon is empty`);
    }),
  );
});

test("every projectile weapon has a registered projectile sprite", async () => {
  const [{ skills }, assets] = await Promise.all([
    readJson("src/configs/skills.json"),
    readJson("src/configs/assets.json"),
  ]);

  const missingProjectiles = skills
    .filter((skill) => skill.weapon)
    .filter((skill) => !skill.weapon.projectileAssetId || assets[skill.weapon.projectileAssetId]?.type !== "projectile")
    .map((skill) => skill.id);

  assert.deepEqual(missingProjectiles, []);
});

test("battlefield art uses the low-noise green grass tile", async () => {
  const assets = await readJson("src/configs/assets.json");
  const battlefield = assets.background_battlefield_grassland;

  assert.equal(battlefield?.type, "background");
  assert.equal(battlefield?.tileable, true);
  assert.equal(battlefield?.path, "assets/backgrounds/grassland_tile-v2.png");
});

test("battlefield grass stays dark, muted, and low texture", () => {
  const analysis = spawnSync("python3", [
    "-c",
    "from PIL import Image; import cv2,numpy as np,json,sys; rgb=np.asarray(Image.open(sys.argv[1]).convert('RGB')); hsv=cv2.cvtColor(rgb,cv2.COLOR_RGB2HSV); gray=cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY).astype(np.int16); texture=(np.abs(np.diff(gray,axis=0)).mean()+np.abs(np.diff(gray,axis=1)).mean())/2; print(json.dumps({'hue':float(hsv[:,:,0].mean()),'saturation':float(hsv[:,:,1].mean()),'value':float(hsv[:,:,2].mean()),'texture':float(texture)}))",
    "public/assets/backgrounds/grassland_tile-v2.png",
  ]);
  assert.equal(analysis.status, 0, analysis.stderr.toString());
  const metrics = JSON.parse(analysis.stdout.toString());

  assert.ok(metrics.hue >= 35 && metrics.hue <= 80, `grass hue is outside the green range: ${metrics.hue}`);
  assert.ok(metrics.saturation <= 145, `grass is too saturated: ${metrics.saturation}`);
  assert.ok(metrics.value >= 72 && metrics.value <= 150, `grass is not a readable dark green: ${metrics.value}`);
  assert.ok(metrics.texture <= 4, `grass texture is too busy: ${metrics.texture}`);
});

test("hero, enemy roster, and boss use the unified v2 art set", async () => {
  const assets = await readJson("src/configs/assets.json");
  const rosterIds = [
    "char_potato_hunter",
    "enemy_tomato_angry",
    "enemy_onion_cry",
    "enemy_corn_mold",
    "enemy_fries_soldier",
    "enemy_soda_slime",
    "boss_fryer_machine",
  ];

  for (const assetId of rosterIds) {
    const asset = assets[assetId];
    assert.ok(asset, `${assetId} is not registered`);
    assert.match(asset.path, /idle-v2\.png$/, `${assetId} still points to legacy art`);
  }

  assert.ok(assets.char_potato_hunter.displaySize >= 80, "hero should remain visually prominent against the swarm");
});
