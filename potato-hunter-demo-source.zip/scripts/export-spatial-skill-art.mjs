import { createCanvas, loadImage } from "@napi-rs/canvas";
import { writeFile } from "node:fs/promises";

// RemBg already supplies alpha. Normalize the sprite padding without redrawing the asset.
const size = 192;
for (const name of ["starch-spikes", "roast-turret"]) {
  const raw = await loadImage(`artifacts/spatial-skill-art-2026-11-20/${name}-cutout.png`);
  const context = createCanvas(raw.width, raw.height).getContext("2d");
  context.drawImage(raw, 0, 0);
  const { data } = context.getImageData(0, 0, raw.width, raw.height);
  let left = raw.width, top = raw.height, right = -1, bottom = -1;
  for (let y = 0; y < raw.height; y++) {
    for (let x = 0; x < raw.width; x++) {
      if (data[(y * raw.width + x) * 4 + 3] < 16) continue;
      left = Math.min(left, x); top = Math.min(top, y);
      right = Math.max(right, x); bottom = Math.max(bottom, y);
    }
  }
  if (right < left || bottom < top) throw new Error(`No visible subject: ${name}`);
  left = Math.max(0, left - 3); top = Math.max(0, top - 3);
  right = Math.min(raw.width - 1, right + 3); bottom = Math.min(raw.height - 1, bottom + 3);
  const w = right - left + 1, h = bottom - top + 1;
  if (w === raw.width && h === raw.height) throw new Error(`Expected an isolated subject: ${name}`);
  const ratio = (size - 16) / Math.max(w, h);
  const canvas = createCanvas(size, size);
  const out = canvas.getContext("2d");
  out.imageSmoothingQuality = "high";
  out.drawImage(raw, left, top, w, h, (size - w * ratio) / 2, size - 8 - h * ratio, w * ratio, h * ratio);
  await writeFile(`public/assets/icons/skills/${name}-sg-v1.png`, await canvas.encode("png"));
}
