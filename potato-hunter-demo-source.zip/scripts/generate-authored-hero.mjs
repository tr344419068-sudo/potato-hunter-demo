import {createCanvas,loadImage} from '@napi-rs/canvas';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {build} from 'esbuild';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const bundle=await build({entryPoints:[root+'src/systems/AuthoredHeroModel.ts'],bundle:true,platform:'node',format:'esm',write:false});
const {HERO_RIG,HERO_ACTIONS,getAuthoredHeroPose}=await import(`data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].text).toString('base64')}`);
const source='public/assets/characters/potato_hunter/idle-v2.png';
const original=await loadImage(root+source);
const out='public/assets/characters/potato_hunter/articulated-v3/';
const author='artifacts/source-character/';
await mkdir(root+out,{recursive:true});await mkdir(root+author+'clips',{recursive:true});
// The orange hem is one piece of the torso. Follow the top of each leather
// cuff rather than cutting a broad, moving strip across the hem.
const leftCuff=[[67,197],[98,197],[101,200],[109,202],[119,202],[126,200],[131,200]];
const rightCuff=[[160,204],[171,205],[181,205],[188,203],[192,200],[196,196],[225,196]];
const masks={
  left_arm:[[88,105],[105,117],[106,141],[92,166],[58,167],[47,146],[51,125],[51,85],[16,65],[12,38],[82,12],[93,60],[76,91]],
  right_arm:[[202,128],[219,137],[244,170],[248,192],[225,202],[205,184],[203,163]],
  // The cuffs and boots overlap only along the ankle to cover the hinge as
  // the sole rotates. Their masks do not duplicate the chest or center hem.
  left_thigh:[...leftCuff,[132,214],[116,220],[92,221],[85,213]],
  left_boot:[[67,218],[89,218],[99,215],[111,216],[124,214],[132,214],[132,251],[67,251]],
  right_thigh:[...rightCuff,[225,216],[206,218],[188,221],[174,221],[160,215]],
  right_boot:[[160,216],[174,216],[188,217],[202,214],[225,214],[225,251],[160,251]],
};
// Trim away the lower limbs from the body while retaining a few pixels at
// the cuff tops as hidden hip underlap. Keep the original outer hem contour.
const lowerBodyCut=[[0,198],...leftCuff.map(([x,y])=>[x,y+2]),[131,210],[160,210],...rightCuff.map(([x,y])=>[x,y+2]),[256,198],[256,256],[0,256]];
function polygon(ctx,points){ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.closePath();}
const layers={};
for(const id of Object.keys(HERO_RIG)){
 const c=createCanvas(256,256),ctx=c.getContext('2d');
 if(id==='body'){
  ctx.drawImage(original,0,0,256,256);
  ctx.globalCompositeOperation='destination-out';
  for(const arm of ['left_arm','right_arm']){polygon(ctx,masks[arm]);ctx.fill();}
  polygon(ctx,lowerBodyCut);ctx.fill();ctx.globalCompositeOperation='source-over';
  // Underlapping sleeve caps close the previously occluded shoulder region.
  const blue=ctx.createLinearGradient(82,116,106,151);blue.addColorStop(0,'#254b71');blue.addColorStop(.6,'#183348');blue.addColorStop(1,'#0f2438');ctx.fillStyle=blue;
  ctx.beginPath();ctx.ellipse(96,127,13,20,-.12,0,Math.PI*2);ctx.fill();
  const blueRight=ctx.createLinearGradient(193,135,211,160);blueRight.addColorStop(0,'#326a8d');blueRight.addColorStop(1,'#122b43');ctx.fillStyle=blueRight;ctx.beginPath();ctx.ellipse(203,148,8,16,-.45,0,Math.PI*2);ctx.fill();
 }else{ctx.save();polygon(ctx,masks[id]);ctx.clip();ctx.drawImage(original,0,0,256,256);ctx.restore();}
 layers[id]=c;await writeFile(root+out+id+'.png',await c.encode('png'));
}
function renderFrame(action,timeMs,phase,moving,attack){
 const c=createCanvas(320,320),ctx=c.getContext('2d');ctx.translate(32,26);
 const pose=getAuthoredHeroPose({action,timeMs,phase,moving,attack});
 for(const p of pose){const joint=HERO_RIG[p.id].joint;ctx.save();ctx.globalAlpha=p.alpha;ctx.translate(p.x,p.y);ctx.rotate(p.rotation);ctx.scale(p.scaleX,p.scaleY);ctx.drawImage(layers[p.id],-joint.x,-joint.y);ctx.restore();}
 return c;
}
const clips=[];
const contact=createCanvas(1600,6*128),cc=contact.getContext('2d');cc.fillStyle='#142b36';cc.fillRect(0,0,1600,768);
for(const [row,[action,config]] of Object.entries(HERO_ACTIONS).entries()){
 const sheet=createCanvas(320*config.frames,320),ctx=sheet.getContext('2d');
 for(let i=0;i<config.frames;i++){
  const ratio=i/(config.loop?config.frames:config.frames-1),c=renderFrame(action,ratio*config.durationMs,ratio*Math.PI*2,action==='run'||action==='attack',ratio);
  ctx.drawImage(c,i*320,0);cc.drawImage(c,i*100+4,row*128+15,100,100);
 }
 cc.fillStyle='#d7e5db';cc.font='11px sans-serif';cc.fillText(action,6,row*128+12);
 const path=author+'clips/'+action+'.png';await writeFile(root+path,await sheet.encode('png'));
 clips.push({action,path,durationMs:config.durationMs,loop:config.loop,frameCount:config.frames,frameWidth:320,frameHeight:320,directions:['right','left-mirrored'],pivot:{x:160/320,y:(26+256*.65)/320}});
}
await writeFile(root+author+'hero-v3-contact-sheet.png',await contact.encode('png'));
const manifest={version:3,method:'articulated-2d-source-layers',source,sourceSha256:createHash('sha256').update(await readFile(root+source)).digest('hex'),generator:'scripts/generate-authored-hero.mjs',runtime:'src/systems/AuthoredHeroModel.ts',note:'Original project illustration segmented into independently posed limbs. No AI generation, no UV deformation. Two-bone leg IK; authored weapon windup/contact/recovery. Runtime samples continuously and mirrors the rig.',parts:Object.entries(HERO_RIG).map(([id,bone])=>({id,path:out+id+'.png',pivot:{x:bone.joint.x/256,y:bone.joint.y/256},bone})),clips,masks};
await writeFile(root+author+'hero-v3-manifest.json',JSON.stringify(manifest,null,2)+'\n');
console.log(`Exported ${manifest.parts.length} original-source layers and ${clips.length} authored action clips; original preserved.`);
