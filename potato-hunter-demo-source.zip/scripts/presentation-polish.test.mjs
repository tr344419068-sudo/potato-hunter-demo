import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { build } from "esbuild";
import EventEmitter from "eventemitter3";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));
const modulesPromise = build({
  stdin: {
    contents: `
      export { World } from "./src/entities/World.ts";
      export { createPlayer, createMapEvent, createExperienceOrb } from "./src/entities/factories.ts";
      export { ConfigManager } from "./src/managers/ConfigManager.ts";
      export { AssetManager } from "./src/managers/AssetManager.ts";
      export { RenderSystem } from "./src/systems/RenderSystem.ts";
      export { CombatVfxSystem } from "./src/systems/CombatVfxSystem.ts";
      export { HUDView } from "./src/ui/HUDView.ts";
      export { getUILayout } from "./src/ui/UILayout.ts";
      export { EventBus } from "./src/managers/EventBus.ts";
    `,
    resolveDir: projectRoot, loader: "ts",
  },
  bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless-presentation", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({
      contents: 'import EventEmitter from "eventemitter3"; export default { Events: { EventEmitter }, Scenes: { Events: { SHUTDOWN: "shutdown" } }, Math: { Clamp: (x,a,b)=>Math.min(b,Math.max(a,x)), Between: (a,b)=>Math.round((a+b)/2), FloatBetween: (a,b)=>(a+b)/2 } };',
      resolveDir: projectRoot,
    }));
  }}],
}).then(result => import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString("base64")}`));

function makeScene() {
  const objects = [];
  const tweens = [];
  const killed = [];
  const add = new Proxy({}, { get(_owner, kind) { return (x, y, texture) => {
    const target = { scene, kind, x: x ?? 0, y: y ?? 0, texture, children: [], calls: [], destroyed: false };
    const proxy = new Proxy(target, { get(owner, property) {
      if (property in owner) return owner[property];
      return (...args) => {
        owner.calls.push([property, ...args]);
        if (property === "setPosition") [owner.x, owner.y] = args;
        if (property === "setTexture") owner.texture = args[0];
        if (property === "add") owner.children.push(...(Array.isArray(args[0]) ? args[0] : [args[0]]));
        if (property === "destroy") owner.destroyed = true;
        if (property === "on") owner[args[0]] = args[1];
        return proxy;
      };
    }});
    objects.push(proxy); return proxy;
  }; }});
  const scene = { add, objects, textures: { exists: () => true, get: () => ({ has: () => false }) }, events: new EventEmitter(), cameras: { main: { shake() {} } }, tweens: { add: config => tweens.push(config), killTweensOf: target => killed.push(target) }, tweenConfigs: tweens, killed };
  return scene;
}

test("all map pickups and experience orbs carry existing PNG art", async () => {
  const { World, createMapEvent, createExperienceOrb, ConfigManager } = await modulesPromise;
  const world = new World();
  for (const kind of ["supply", "heal", "magnet", "haste", "xp_burst"]) {
    const id = createMapEvent(world, { id: kind, kind, value: 1, radius: 22, color: 0xffffff, lifetimeMs: 1000 }, 50, 80);
    const assetId = world.components.renders.get(id).assetId;
    assert.ok(ConfigManager.assets[assetId]?.path.endsWith(".png"), `${kind} is still a geometric placeholder`);
  }
  const orb = createExperienceOrb(world, 20, 30, 2);
  assert.ok(ConfigManager.assets[world.components.renders.get(orb).assetId], "XP orb has no crystal image");
});

test("actual renderer keeps pickup textures alive and removes them after collection", async () => {
  const { World, createMapEvent, ConfigManager, RenderSystem } = await modulesPromise;
  const scene = makeScene();
  const world = new World();
  const id = createMapEvent(world, ConfigManager.mapEvents.events[0], 140, 180);
  const graphics = scene.add.graphics();
  const renderer = new RenderSystem(scene, graphics);
  const runtime = { scene, world, playerId: -1, stats: { elapsedMs: 500 }, skillManager: { getAuraProfiles: () => [] } };
  renderer.update(16, runtime);
  const sprite = scene.objects.find(item => item.kind === "image");
  assert.ok(sprite, "map events bypass texture rendering");
  assert.ok(sprite.texture.startsWith("asset:"));
  world.destroyEntity(id);
  renderer.update(16, runtime);
  assert.equal(sprite.destroyed, true);
});

test("foot metadata calibrates characters without moving their gameplay pivots", async () => {
  const { ConfigManager } = await modulesPromise;
  for (const [id, asset] of Object.entries(ConfigManager.assets)) {
    if (!["character", "enemy", "boss"].includes(asset.type)) continue;
    assert.ok(asset.footPoint?.y > asset.pivot.y, `${id} has no calibrated feet`);
    assert.ok(asset.footPoint.x > 0.35 && asset.footPoint.x < 0.7);
    assert.ok(asset.pivot.y <= 0.7, "gameplay pivot moved");
  }
});

test("shadow centers transform the actual foot point through scale, mirror, and rotation", async () => {
  const model = await import("../src/systems/ShadowProfileModel.ts");
  assert.equal(typeof model.getCharacterGroundPoint, "function", "shadows still use guessed offsets");
  const base = { x: 100, y: 200, visualSize: 100, pivot: { x: 0.5, y: 0.65 }, footPoint: { x: 0.57, y: 0.93 }, scaleX: 1, scaleY: 1, rotation: 0 };
  const right = model.getCharacterGroundPoint(base);
  assert.ok(Math.abs(right.x - 107) < 1e-8);
  assert.ok(Math.abs(right.y - 228) < 1e-8);
  const mirrored = model.getCharacterGroundPoint({ ...base, scaleX: -1 });
  assert.ok(Math.abs(mirrored.x - 93) < 1e-8);
  const rotated = model.getCharacterGroundPoint({ ...base, scaleY: 0.8, rotation: Math.PI / 2 });
  assert.ok(Math.abs(rotated.x - 77.6) < 1e-8);
  assert.ok(Math.abs(rotated.y - 207) < 1e-8);
});

test("shadow profile does not add a second offset to calibrated ground", async () => {
  const model = await import("../src/systems/ShadowProfileModel.ts");
  for (const kind of ["hero", "monster", "elite", "boss"]) {
    assert.equal(model.getCharacterShadowProfile(kind, 84, 0).groundOffsetY, 0);
  }
});

test("renderer uses foot metadata and excludes jumping lift from the ground plane", async () => {
  const source = await readFile(new URL("../src/systems/RenderSystem.ts", import.meta.url), "utf8");
  assert.ok(source.includes("getCharacterGroundPoint"), "renderer does not use foot transform");
  assert.ok(source.includes("getFootPoint"), "renderer does not read foot metadata");
  assert.ok(source.includes("Math.max(0, offsetY)"), "jumping lift is not excluded from ground");
});

test("actual dash HUD shows boots art and preserves cooldown and pointer input", async () => {
  const { HUDView, getUILayout, EventBus } = await modulesPromise;
  const scene = makeScene();
  const hud = new HUDView(scene, getUILayout(390, 844));
  const icon = scene.objects.find(item => item.texture === "asset:icon_skill_starch_boots");
  assert.ok(icon, "dash has no boots image");
  let requests = 0;
  const handler = () => requests++;
  EventBus.on("player:dash-request", handler);
  scene.objects.find(item => item.calls.some(call => call[0] === "on" && call[1] === "pointerdown"))?.pointerdown();
  EventBus.off("player:dash-request", handler);
  assert.equal(requests, 1);
  hud.update({ elapsedMs: 0, hp: 100, maxHp: 100, level: 1, experience: 0, experienceToNext: 14, kills: 0, gold: 0, skills: [], builds: [], difficulty: { level: 1 }, dashCooldownRatio: 0.5 });
  assert.ok(icon.calls.some(call => call[0] === "setAlpha" && call[1] < 1), "cooldown should dim dash image");
  hud.destroy();
});

test("exaggerated elemental envelopes remain bounded and critical impacts are stronger", async () => {
  const model = await import("../src/systems/CombatVfxModel.ts");
  assert.equal(typeof model.getCombatVfxEnvelope, "function");
  for (const kind of ["kinetic", "peeler", "fire", "frost", "lightning", "poison", "explosion", "ketchup"]) {
    const normal = model.getCombatVfxEnvelope(kind, false);
    const critical = model.getCombatVfxEnvelope(kind, true);
    assert.ok(normal.impactScale >= 1.25 && normal.impactScale <= 2);
    assert.ok(critical.impactScale > normal.impactScale && critical.impactScale <= 2.5);
    assert.ok(normal.secondaryDelayMs >= 45 && normal.secondaryDelayMs <= 110);
    assert.ok(normal.durationMs <= 480);
  }
});

test("hero effects draw family silhouettes and a delayed secondary burst", async () => {
  const source = await readFile(new URL("../src/systems/CombatVfxSystem.ts", import.meta.url), "utf8");
  for (const name of ["drawElementalSilhouette", "showSecondaryImpact", "secondaryDelayMs", "getCombatVfxEnvelope"]) {
    assert.ok(source.includes(name), `missing ${name}`);
  }
});

test("real VFX emits delayed secondary impacts with pooled cleanup for each family", async () => {
  const { CombatVfxSystem, EventBus } = await modulesPromise;
  const signatures = [];
  for (const kind of ["peeler", "fire", "frost", "lightning", "poison", "ketchup"]) {
    const scene = makeScene();
    const system = new CombatVfxSystem(scene);
    EventBus.emit("weapon:impact", { x: 50, y: 70, color: 0xffffff, radius: 16, vfxKind: kind });
    const delayed = scene.tweenConfigs.find(tween => typeof tween.onStart === "function" && tween.delay >= 45 && tween.delay <= 110);
    assert.ok(delayed, `${kind} has no secondary silhouette`);
    assert.equal(typeof delayed.onComplete, "function");
    signatures.push(JSON.stringify(delayed.targets.calls));
    delayed.onComplete();
    system.destroy();
  }
  assert.equal(new Set(signatures).size, signatures.length, "families should not all draw the same ring");
});

test("dash ghosts retain the hero image pivot and actual visual size", async () => {
  const { CombatVfxSystem, EventBus } = await modulesPromise;
  const scene = makeScene();
  const system = new CombatVfxSystem(scene);
  EventBus.emit("hero:dash", { x: 50, y: 70, directionX: 1, directionY: 0, assetId: "char_potato_hunter", size: 36 });
  const images = scene.objects.filter(item => item.kind === "image");
  assert.equal(images.length, 3);
  assert.ok(images.every(image => image.calls.some(call => call[0] === "setOrigin" && call[1] === 0.5 && call[2] === 0.65)), "dash ghosts ignore torso pivot");
  assert.ok(images.every(image => image.calls.some(call => call[0] === "setDisplaySize" && Math.abs(call[1]) === 84)), "dash ghosts use collision size instead of hero visual size");
  system.destroy();
});
