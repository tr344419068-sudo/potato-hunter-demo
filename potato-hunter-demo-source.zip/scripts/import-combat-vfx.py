import argparse
import hashlib
import io
import json
from pathlib import Path
import re
from zipfile import ZipFile

from PIL import Image, ImageChops


ROOT = Path(__file__).resolve().parents[1]
TILE_SIZE = 192
FRAME_COUNT = 8
SOURCES = {
    "kenney": {
        "archive": "kenney_particlePack.zip",
        "author": "Kenney",
        "source": "https://opengameart.org/content/particle-pack-80-sprites",
        "download": "https://opengameart.org/sites/default/files/kenney_particlePack.zip",
        "license": "CC0-1.0",
        "licenseEvidence": "Included original License.txt declares Creative Commons Zero (CC0).",
    },
    "spell": {
        "archive": "FX.zip",
        "author": "Mikodrak",
        "source": "https://opengameart.org/content/2d-spell-effects",
        "download": "https://opengameart.org/sites/default/files/FX.zip",
        "license": "CC0-1.0",
        "licenseEvidence": "Source publication declares CC0; archive has no separate license notice.",
    },
}
MASKS = {
    "glow": ("PNG/circle_05.png", 0),
    "ring": ("PNG/circle_01.png", 0),
    "slash": ("PNG/slash_01.png", 0),
    "trace": ("PNG/trace_01.png", 90),
    "flame": ("PNG/flame_02.png", 0),
    "smoke": ("PNG/smoke_03.png", 0),
    "arc": ("PNG/spark_07.png", 0),
    "crystal": ("PNG/star_05.png", 0),
    "motes": ("PNG/magic_03.png", 0),
    "chip": ("PNG/dirt_01.png", 0),
}
STRIPS = {
    "peeler_spell": "fx2_swordFire/",
    "fire_spell": "fx3_fireBall/",
    "energy_spell": "fx7_energyBall/",
    "lightning_spell": "fx8_lighteningBall/",
    "smoke_spell": "fx10_blackExplosion/",
}


def digest(contents):
    return hashlib.sha256(contents).hexdigest()


def read_png(archive, entry):
    image = Image.open(io.BytesIO(archive.read(entry)))
    image.load()
    return image.convert("RGBA")


def neutral_mask(image):
    alpha = ImageChops.multiply(image.convert("RGB").convert("L"), image.getchannel("A"))
    neutral = Image.new("RGBA", image.size, (255, 255, 255, 0))
    neutral.putalpha(alpha)
    return neutral


def neutral_spell(image):
    red, green, blue, alpha = image.split()
    brightness = ImageChops.lighter(ImageChops.lighter(red, green), blue)
    return Image.merge("RGBA", (brightness, brightness, brightness, alpha))


def centered_tile(image, scale):
    dimensions = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
    resized = image.resize(dimensions, Image.Resampling.LANCZOS)
    tile = Image.new("RGBA", (TILE_SIZE, TILE_SIZE), (0, 0, 0, 0))
    tile.alpha_composite(resized, ((TILE_SIZE - resized.width) // 2, (TILE_SIZE - resized.height) // 2))
    return tile


def import_assets(output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)
    archives = {}
    source_metadata = {}
    for source_id, metadata in SOURCES.items():
        path = ROOT / "artifacts/source-vfx" / metadata["archive"]
        archives[source_id] = ZipFile(path)
        source_metadata[source_id] = {**metadata, "archiveSha256": digest(path.read_bytes())}
    outputs = []

    def save_output(name, image, source_id, entries, transform):
        file_name = name.replace("_", "-") + ".png"
        path = output_dir / file_name
        image.save(path, format="PNG", optimize=False, compress_level=9)
        outputs.append({
            "assetId": "vfx_" + name,
            "path": "assets/vfx/" + file_name,
            **source_metadata[source_id],
            "entries": entries,
            "transform": transform,
            "outputSha256": digest(path.read_bytes()),
        })

    for name, (entry, rotation) in MASKS.items():
        original = read_png(archives["kenney"], entry)
        image = neutral_mask(original)
        if rotation:
            image = image.rotate(rotation, expand=True)
        scale = 168 / max(image.size)
        save_output(name, centered_tile(image, scale), "kenney", [entry], {
            "alpha": "luminance multiplied by original alpha; white RGB only where original luminance supplies coverage",
            "scale": scale,
            "rotationDegrees": rotation,
            "canvas": [TILE_SIZE, TILE_SIZE],
            "alignment": "centered with transparent 12px minimum border",
        })

    for name, folder in STRIPS.items():
        entries = sorted(
            [entry for entry in archives["spell"].namelist() if entry.startswith(folder) and entry.endswith(".png")],
            key=lambda entry: int(re.search(r"(\d+)\.png$", entry).group(1)),
        )
        originals = [read_png(archives["spell"], entry) for entry in entries]
        scale = 168 / max(max(image.size) for image in originals)
        indices = [round(index * (len(entries) - 1) / (FRAME_COUNT - 1)) for index in range(FRAME_COUNT)]
        strip = Image.new("RGBA", (TILE_SIZE * FRAME_COUNT, TILE_SIZE), (0, 0, 0, 0))
        for frame, source_index in enumerate(indices):
            tile = centered_tile(neutral_spell(originals[source_index]), scale)
            strip.alpha_composite(tile, (frame * TILE_SIZE, 0))
        save_output(name, strip, "spell", [entries[index] for index in indices], {
            "alpha": "original transparent alpha retained; maximum-channel grayscale retains light and dark smoke detail",
            "scale": scale,
            "canvas": [TILE_SIZE, TILE_SIZE],
            "alignment": "one common scale across every original frame, centered on a fixed canvas; no individual frame fitting",
            "sampleIndices": indices,
            "originalFrameCount": len(entries),
            "frameCount": FRAME_COUNT,
            "sequence": "opening through peak to final source fade, including both endpoints",
        })
    (output_dir / "Kenney-License.txt").write_bytes(archives["kenney"].read("License.txt"))
    manifest = {"schemaVersion": 1, "method": "Downloaded CC0 bitmap import, not AI-generated artwork", "outputs": outputs}
    (output_dir / "sources.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf8")
    for archive in archives.values():
        archive.close()
    print(f"Imported {len(outputs)} deterministic licensed combat VFX PNGs into {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=ROOT / "public/assets/vfx")
    import_assets(parser.parse_args().output_dir)
