import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { readFile } from "node:fs/promises";

const root = fileURLToPath(new URL("../", import.meta.url));
const modules = build({ stdin: { contents: `
  export { UIScene } from "./src/scenes/UIScene.ts";
  export { getUILayout } from "./src/ui/UILayout.ts";
  export { LEVEL_CHAPTERS } from "./src/managers/LevelChapterModel.ts";
`, resolveDir: root, loader: "ts" }, bundle: true, platform: "node", format: "esm", write: false,
  plugins: [{ name: "headless", setup(context) {
    context.onResolve({ filter: /^phaser$/ }, () => ({ path: "phaser", namespace: "headless" }));
    context.onLoad({ filter: /.*/, namespace: "headless" }, () => ({ contents: 'import EventEmitter from "eventemitter3"; export default { Scene: class {}, Events: { EventEmitter }, Display: { Color: { IntegerToColor: color => ({ rgba: `rgba(${color},1)` }) } }, Scale: { Events: { RESIZE: "resize" } } };', resolveDir: root }));
  }}],
}).then(output => import(`data:text/javascript;base64,${Buffer.from(output.outputFiles[0].text).toString("base64")}`));

const measure = (text, size) => Array.from(text).reduce((sum, character) => sum + size * (/\s/.test(character) ? 0.3 : /[\x00-\x7f]/.test(character) ? 0.58 : 1), 0);
const compactContent = text => text.replace(/\s/g, "");

async function fixture(width = 1280, height = 720) {
  const api = await modules;
  const scene = new api.UIScene();
  const objects = [], tweens = [], killedTweens = [];
  const make = (kind, x = 0, y = 0, value, style = {}) => {
    const object = { kind, x, y, text: kind === "text" ? value : "", style: { ...style }, children: [], calls: [], width: 0, height: 0, fontSize: parseFloat(style.fontSize ?? 24), lineSpacing: 0, scaleX: 1, scaleY: 1, destroyed: false };
    const refresh = () => {
      const lines = object.text.split("\n");
      object.width = Math.max(...lines.map(line => measure(line, object.fontSize))) + (object.style.strokeThickness ?? 0);
      object.height = lines.length * (object.fontSize + (object.style.strokeThickness ?? 0)) + Math.max(0, lines.length - 1) * object.lineSpacing;
    };
    object.context = { measureText: text => ({ width: measure(text, object.fontSize) }) };
    const proxy = new Proxy(object, { get(target, property) {
      if (property in target) return target[property];
      if (property === "getBounds") return () => ({ x: target.x - target.width / 2, y: target.y - target.height / 2, width: target.width, height: target.height });
      return (...args) => {
        target.calls.push([property, ...args]);
        if (property === "setPosition") [target.x, target.y] = args;
        if (property === "setY") target.y = args[0];
        if (property === "setAlpha") target.alpha = args[0];
        if (property === "setScale") { target.scaleX = args[0]; target.scaleY = args[1] ?? args[0]; }
        if (property === "setFontSize") { target.fontSize = args[0]; refresh(); }
        if (property === "setText") { target.text = args[0]; refresh(); }
        if (property === "setLineSpacing") { target.lineSpacing = args[0]; refresh(); }
        if (property === "setDisplaySize") [target.width, target.height] = args;
        if (property === "add") target.children.push(...(Array.isArray(args[0]) ? args[0] : [args[0]]));
        if (property === "clear") target.calls = [];
        if (property === "destroy") { target.destroyed = true; if (args[0]) for (const child of target.children) child.destroy(); }
        return proxy;
      };
    }});
    if (kind === "text") refresh();
    objects.push(proxy);
    return proxy;
  };
  scene.add = { container: (x, y) => make("container", x, y), graphics: () => make("graphics"), image: (x, y, value) => make("image", x, y, value), rectangle: (x, y) => make("rectangle", x, y), text: (x, y, value, style) => make("text", x, y, value, style) };
  scene.textures = { exists: () => true };
  scene.tweens = { add: config => { tweens.push(config); return config; }, killTweensOf: target => killedTweens.push(target) };
  scene.scale = { width, height, off() {} };
  scene.currentLayout = api.getUILayout(width, height);
  return { ...api, scene, objects, tweens, killedTweens };
}

test("notifications replace crowned raster frames with quiet dark strips and bold cream type", async () => {
  const { scene, objects, tweens } = await fixture();
  scene.showNotification("油弹扇射 · 留意空隙", 0xff5b4d, 950);
  assert.equal(objects.filter(item => item.kind === "image").length, 0, "notification still uses the crowned ribbon image");
  const { frame, text, container } = scene.notification;
  assert.equal(frame.kind, "graphics");
  assert.ok(!frame.calls.some(call => /stroke/.test(call[0])), "notification still has a decorative border");
  assert.equal(text.style.fontStyle, "900");
  assert.equal(text.style.stroke, "#211811");
  assert.ok(text.style.strokeThickness <= 3);
  assert.equal(container.scaleX, 1, "simple strip must not bounce from a shrunken ribbon");
  assert.equal(tweens[0].ease, "Sine.easeOut");
  assert.ok(tweens[0].duration <= 160);
  assert.equal(tweens[0].hold, 950);
});

test("authored Boss and chapter messages remain complete inside bounded desktop and portrait strips", async () => {
  const { LEVEL_CHAPTERS } = await modules;
  const bossSource = await readFile(new URL("../src/systems/BossSystem.ts", import.meta.url), "utf8");
  const patternLabels = [...bossSource.matchAll(/(?:oil_fan|bombardment|charge|summon|heat_ring): "([^"]+)"/g)].map(match => match[1]);
  assert.equal(patternLabels.length, 5);
  const messages = ["巨型炸薯机来袭！", "首领击破！", "护盾队长入场！", "疾速队长入场！", ...patternLabels, ...LEVEL_CHAPTERS.map(chapter => `${chapter.act} · ${chapter.title}\n${chapter.subtitle}`)];
  for (const [width, height] of [[1280, 720], [390, 844], [320, 480]]) {
    const { scene } = await fixture(width, height);
    for (const message of messages) {
      scene.showNotification(message, 0xff5b4d, 950);
      const layout = scene.currentLayout.notification;
      assert.ok(layout.height <= 112, `reserved ribbon is too tall at${width}`);
      const { frame, text } = scene.notification;
      assert.ok(text.fontSize >= 16 && text.fontSize <= 20, "notice typography is no longer quiet");
      assert.equal(compactContent(text.text), compactContent(message), `authored message was cut: ${message}`);
      assert.ok(text.width <= layout.width - 28, `${width}px text escaped horizontal padding: ${message}`);
      const rectangles = frame.calls.filter(call => call[0] === "fillRect");
      assert.ok(rectangles.length > 0);
      const drawnHeight = Math.max(...rectangles.map(call => call[4]));
      assert.ok(drawnHeight <= layout.height);
      assert.ok(text.height + 18 <= drawnHeight, "text escaped vertical padding");
      assert.ok(frame.y - drawnHeight / 2 >= scene.currentLayout.boss.y + scene.currentLayout.boss.height / 2 + 7, "strip covers the Boss health frame");
      assert.ok(text.text.split("\n").length <= 3);
      if (!message.includes("\n")) assert.ok(drawnHeight <= 72, `${width}px short notice still occupies a huge plaque: ${message}`);
    }
  }
});

test("resize reflows the original message without accumulating hard line breaks", async () => {
  const { scene } = await fixture();
  const message = "油弹扇射 · 留意空隙并及时横向闪避";
  scene.showNotification(message, 0xff5b4d, 950);
  const desktop = scene.notification.text.text;
  scene.scale.width = 320; scene.scale.height = 480; scene.handleResize();
  assert.ok(scene.notification.text.text.includes("\n"), "long Chinese notice did not wrap on narrow screens");
  assert.equal(compactContent(scene.notification.text.text), compactContent(message));
  scene.scale.width = 1280; scene.scale.height = 720; scene.handleResize();
  assert.equal(scene.notification.text.text, desktop);
});

test("replacing a notification kills its obsolete tween and ignores stale completion", async () => {
  const { scene, tweens, killedTweens } = await fixture();
  scene.showNotification("巨型炸薯机来袭！", 0xff5b4d, 1850);
  const old = scene.notification.container;
  scene.showNotification("油弹扇射 · 留意空隙", 0xff5b4d, 950);
  const replacement = scene.notification;
  assert.ok(old.destroyed);
  assert.ok(killedTweens.includes(old), "old notification tween still animates a destroyed container");
  tweens[0].onComplete();
  assert.equal(scene.notification, replacement);
  scene.shutdown();
  assert.equal(scene.notification, undefined);
  assert.ok(replacement.container.destroyed);
});

test("measured Unicode text fitting preserves authored text and bounds unexpected future overflow", async () => {
  const model = await import("../src/ui/NotificationModel.ts").catch(() => undefined);
  assert.ok(model?.fitNotificationText, "measured text-fitting model is missing");
  const message = "第三幕 · 外卖围猎\n三路压境 · 击破护盾队长";
  const fitted = model.fitNotificationText(message, 264, 24, 18, measure);
  assert.equal(compactContent(fitted.text), compactContent(message));
  assert.ok(fitted.lineCount <= 3);
  assert.ok(fitted.fontSize >= 18);
  for (const line of fitted.text.split("\n")) assert.ok(measure(line, fitted.fontSize) <= 264);
  const warning = model.fitNotificationText("环形热浪 · 绿色中心安全", 256, 24, 18, measure);
  assert.equal(warning.lineCount, 1, "a readable smaller font should keep short tactical warnings on one line");
  const overflow = model.fitNotificationText("超长警告".repeat(100), 264, 24, 18, measure);
  assert.equal(overflow.lineCount, 3);
  assert.ok(overflow.text.endsWith("…"));
  for (const line of overflow.text.split("\n")) assert.ok(measure(line, overflow.fontSize) <= 264);
});
