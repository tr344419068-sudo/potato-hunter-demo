# 沙海堡垒之王：专用特效素材

## 当前战斗版：逐帧素材

2026-11-24 从 ParticleFX Studio 以下效果页面导出官方透明 APNG。各页允许用于商业游戏；[官方使用条款](https://particlefx.studio/terms#your-effects)允许项目内使用导出文件，不允许重新销售或将素材库当作独立特效包分发。项目只使用重新采样、调色后的游戏内 WebP 图集，不附 APNG 原件、预设或其播放器。

| 游戏内用途 | 官方预设来源 | 导入图集 |
|---|---|---|
| 断岸沙浪主浪 | [Rolling Dust Cloud](https://particlefx.studio/effects/rolling-dust-cloud) | `wave.webp`，30 帧 |
| 游沙龙卷主体 | [Fire Tornado](https://particlefx.studio/effects/fire-tornado)，重新调为砂金色 | `cyclone.webp`，30 帧 |
| 游沙龙卷贴地风眼 | [Whirlwind](https://particlefx.studio/effects/whirlwind) | `whirl.webp`，18 帧 |
| 砂瀑落地和飞散 | [Sand Burst](https://particlefx.studio/effects/sand-burst) | `sandfall.webp`，24 帧 |
| 沙暴围城、地表流沙 | [Desert Sandstorm Overlay](https://particlefx.studio/effects/desert-sandstorm-overlay) | `storm.webp`，24 帧 |

`scripts/export-desert-boss-flipbooks.py` 将原帧按时间顺序抽样、统一裁切与调色，然后输出到 `public/assets/vfx/desert-sovereign-v2/`。它不插帧、不变形生成动作。战斗根据施法时间读取不同帧，暂停会同步停帧。世界坐标、缺口、背风区和危险边界仍使用与判定共用的几何。砂瀑保留已有 Brackeys 尘雾作为辅层。

## 上一版神工静态稿

`public/assets/vfx/desert-sovereign-v1/` 来自神工 GPT-Image-2.5-Sunburst 的 1024×1024 白底原稿和神工 RemBg 抠图，`scripts/export-desert-boss-art.py` 拆图。旧的沙浪、龙卷和砂瀑主体已从加载清单移除。只有安全走位标记 `wind.webp` 及来自神工砂岩围场的短风挡 `windbreak.webp` 保留在战斗中；风挡不阻挡玩家移动。

## 破土与挥击

`public/assets/bosses/desert_sultan/cleave-v2.webp` 使用已有的神工 Boss 立绘，通过 `scripts/export-desert-boss-arm.py` 分离前臂、补齐肩部，在固定肩点上制作七个挥击姿势。它是基于原画烘焙的角色动作图集，不是新生图，也不是整张立绘摇晃。平 A 的挥击闪光复用项目中的 Cethiel 序列帧；潜沙和破土用沙漩、喷沙和 Brackeys 尘土序列帧。半透明绿色和橙色区域是从命中数据绘制的矢量地面预警，不是技能主体特效。
