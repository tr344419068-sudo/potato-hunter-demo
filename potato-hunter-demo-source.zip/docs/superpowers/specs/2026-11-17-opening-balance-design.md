# Opening crowd and progression adjustment

Request: slightly lower difficulty, especially opening monster crowding and slow upgrades. Execute directly under the user's existing delegation.

## Diagnosis

- Opening waves currently start at 3 spawns / 900 ms (3.33 per second), with a 36-monster cap. The starter peeler deals 20 damage per 620 ms while basic fries have 24 HP: arrivals exceed unupgraded single-target clear speed.
- XP requirements jump from 14 to 73, then 131 and 205. Reducing arrivals alone would further slow XP supply.
- WaveManager already interpolates health pressure and blends incoming rosters. Preserve those continuity mechanisms, enemy stats, chapter captains, boss cadence, pickup behavior and manual upgrade credits.

## Adjustment

Keep groups of three to preserve the existing continuous spawn-interval contract. Set interval targets at 0/10/24/40/60 seconds to 1350/1230/820/650/460 ms, and base alive caps to 24/32/44/58/76. This cuts opening arrivals by one third, tapering to a 15% reduction at 60 seconds; existing targets from 105 seconds onward remain unchanged. The 24-second target was lowered further after the existing adjacent health-pressure growth budget caught an over-steep target; preserve that regression budget.

XP requirements at levels 1–5 become 12/28/50/78/112. Early levels use `3 * level² + 7 * level + 2`; smoothstep gradually blends back toward the established level curve between levels 5 and 12. Blend the minimum-growth guard over the same range, preventing a sharp handover or flat late-game requirements. No bonus XP sources or automated upgrade choices.

## Verification

- Regression tests for real runtime opening arrival rate/cap, paired reduced-spawn progression budget, exact early XP costs, monotonic progression and later curve continuity.
- Actual ExperienceSystem + GameScene test: 90 collected XP reaches level 4, yields three credits, leaves gameplay running and preserves XP remainder.
- Preserve all existing pressure/roster continuity, boss cadence, combat, UI and asset checks. Build/typecheck.
- If the local browser is available, exercise a fresh opening without XP/time/kill debug cheats; treat observations as smoke testing, not a measured balance study.
