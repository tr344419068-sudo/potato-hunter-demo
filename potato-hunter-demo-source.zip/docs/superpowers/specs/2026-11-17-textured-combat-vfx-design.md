# Textured combat VFX art pass

User approved the prior proposal to replace code-only light effects with licensed particle artwork, distinct spell animation and coordinated timing. Execute without another approval gate under the user's direct delegation. No AI generation is claimed or required for this pass.

## Scope and direction

Recommended: import selected CC0 bitmap masks and spell frames, normalize their alpha and neutralize colors, then tint and animate them within the existing bounded emitter. Pure procedural additions leave the requested art gap; an entirely new effect engine adds avoidable lifecycle and performance risk. Keep the existing graphics accents as a restrained complementary layer and missing-texture fallback.

Make six hero families visibly distinct: sweeping pale blade arcs; curling amber flame; cyan crystalline burst; branching electric arc; green smoke and motes; orange-white explosion with an expanding ring and smoky tail. Kinetic and ketchup effects must also use suitable imported assets. Ordinary shots remain brief and directional; critical hits and reactions get larger but bounded silhouettes. Do not obscure hostile projectiles, damage warnings or player footing. No full-screen flashes for ordinary attacks.

## Verified source inputs

- Kenney Particle Pack: page `https://opengameart.org/content/particle-pack-80-sprites`; author Kenney; page and included `License.txt` declare CC0. Download `https://opengameart.org/sites/default/files/kenney_particlePack.zip` retained in `artifacts/source-vfx/`.
- 2D Spell Effects: page `https://opengameart.org/content/2d-spell-effects`; author Mikodrak; page declares CC0. Download `https://opengameart.org/sites/default/files/FX.zip` retained in `artifacts/source-vfx/`.
- Source pages were retrieved locally on 2026-11-17 and inspected for author, license and exact attachment href. Kenney's main site rejected the direct request; use the author's OpenGameArt upload instead.
- Input sheets were visually inspected: `artifacts/qa/vfx-kenney-sources.jpg`, `vfx-spell-sources.jpg`.

Useful Kenney shapes: `circle_01`, `circle_05`, `slash_01`, `trace_01` (rotate to horizontal), `flame_02`, `smoke_03`, `spark_07`, `star_05`, `magic_03`, `dirt_01`.
Spell sequences: `fx2_swordFire` for directional blade strike, `fx3_fireBall` for fire, `fx7_energyBall` for frost/poison dissolution, `fx8_lighteningBall` for electric branching, `fx10_blackExplosion` for smoky aftermath. These sequences have differently sized frames: normalize with one common scale and centered anchor per sequence, never independently resize each trimmed frame to fill its slot.

## Architecture

1. A deterministic Python/Pillow importer reads only PNG entries from the two ZIPs, outputs a small curated set of white RGBA masks and 8-frame 192px strips under `public/assets/vfx/`. Kenney black-background additive images must become actual transparent masks: preserve luminance times original alpha; RGB may be neutral white. Spell alpha and temporal silhouette must remain intact, including dark explosion smoke. A source manifest records author/license/archive hash/entries/transformation per output; keep the original Kenney notice.
2. Extend asset config with VFX type and optional frame dimensions/count. AssetManager queues real spritesheets when metadata exists; existing images remain unchanged. Asset validation continues to cover complete PNG dimensions.
3. A focused `CombatVfxTextures.ts` describes family/form artwork and material motion. Prefer loaded `asset:vfx_*` keys, use actual frame progression (no looping) for strip bursts, preserve stable pivots and tint. Smoke uses NORMAL blending, lights use ADD. Cached global textures survive emitter shutdown; generated fallbacks retain their existing lease semantics.
4. Extend the existing `CombatParticleEmitter` to use those textures for muzzle/trail/impact/aura/reaction. Replace a few existing particles with larger artwork layers rather than creating a second unbounded emitter. Preserve 180 desktop / 100 compact caps and 36 heavy reserve, event counts, offscreen culling, pool ownership, shutdown, resize and finite lifetime. Every pooled reuse resets frame, tint, blend, rotation and transform. Impact rings expand; smoke grows/drifts/fades; energetic fragments streak away. Do not uniformly shrink all imported artwork.

## Acceptance

- Real downloaded PNG art is present, registered, preloaded and used by the production emitter. Six family profiles are not just differently colored circles.
- Actual frame animation plays and expires; no black rectangles, jittering anchors or stale pooled frame/tint/blend state.
- Existing fallback tests and texture ownership/cap/restart tests still pass. New integration tests cover loaded artwork, frame advancement, smoke blending, priority/resize and shared loaded textures.
- All combat/UI/assets suites, asset validator and TypeScript/Vite build pass. Opening-balance files remain byte-identical.
- Screenshot/short animation evidence renders the actual module with the downloaded textures; smoke-test the actual localhost game as available. Distinguish effect preview from natural gameplay. Never claim a preview is a balance test.

## Protected gameplay fingerprints

`src/configs/waves.json`: `5f9370b24ad67735993debb0274fcd2d5d2c0e17a118439ff3777856603114ba`
`src/configs/difficulty.json`: `3b9c3d5623c051583ba7c6d65f0741384abed0b0c307ae8008a01043cea18916`
`src/configs/monsters.json`: `97632ff3c3ddb92abd35ca0cfbffb4bc00a90d5345f78dbc39ed88572f6bc5e7`
`src/configs/skills.json`: `14bb27bcb32656869fae250464621f9edb51b7e9f6d5d0788552812daf33a801`
`src/managers/PacingModel.ts`: `8991750057bd1fa7ef6ca1c85e30b6076daa0379156a12ac66e4bc7db8c5f908`
