# Combat Depth and Juice Design

## Goal

Turn the current content-rich but mostly parallel skill set into an expressive combat system with active player agency, readable build synergies, and stronger climax moments.

## Assessment

The game already has seven active skills, seven passives, five evolutions, multiple enemy behaviors, elites, map events, and phased bosses. The depth gap comes from three places: skills rarely interact, the player has no active defensive action beyond walking, and strong outcomes reuse the same ring-and-spark presentation.

## Chosen design

### Elemental reactions

Existing statuses become setup tools. A later hit can consume a compatible status and trigger one of four reactions:

- Fire/explosion/ketchup + poison: Toxic Ignition, a green-orange damage burst.
- Lightning + freeze/slow: Superconduct, a cyan-yellow group shock.
- Peeler/kinetic + freeze: Shatter, a high single-target burst with crystal splash.
- Frost + burn: Thermal Shock, a dual-color radial burst.

Each reaction has a bounded bonus-damage multiplier, radius, splash multiplier, target cap, knockback, consumed status, label, and two-color palette. Reactions can be triggered by projectiles and auras, but cannot recurse because reaction damage does not invoke the resolver.

### Active dash

Space on desktop and a dedicated HUD button on touch devices trigger a 170 ms dash in the latest movement direction. Dash has a 2.2 second cooldown and temporary contact/projectile invulnerability. It creates a launch ring, directional streaks, and three tinted hero afterimages. The HUD button shows cooldown progress and remains visually consistent with the existing rounded blue/gold UI.

## Architecture

- `ElementalReactionModel.ts` owns pure reaction rules and balance data.
- `ElementalReactionSystem.ts` applies a resolved reaction to runtime entities and emits one presentation event.
- Projectile and aura systems call the reaction runtime entry point after their base damage and before replacing statuses.
- Player dash state remains in `PlayerComponent`; `InputSystem` owns requests and velocity, while collision systems only read invulnerability state.
- `CombatVfxSystem` renders reaction and dash events; `HUDView` renders the dash control and emits a request event.

## Performance and safety

Reaction splash is target-capped and uses existing particle pools. Dash afterimages are limited to three per activation. No reaction damage can recursively trigger another reaction. Cooldowns and invulnerability are clamped to zero every frame.

## Verification

Pure model tests cover every reaction, no-match behavior, bounded values, dash timing, and cooldown ratios. Integration source tests assert both projectile/aura wiring and both player-damage paths respecting dash invulnerability. Build, combat tests, UI tests, asset validation, desktop play, and portrait play are required before completion.
