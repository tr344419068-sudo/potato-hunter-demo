# Potato Hunter Combat Art and Pacing Design

## Goal

Turn the current UI-polished prototype into a visually coherent, immediately exciting survivor-style combat loop. The first minute must show escalating enemy pressure, distinct elemental attacks, at least one elite encounter, and a Boss climax while remaining readable on desktop and portrait mobile.

## Chosen approach

Use generated raster art for stable visual identity and Phaser graphics/tweens for motion:

- Generated assets: one seamless top-down food-wasteland battlefield, nine missing skill icons, and five transparent projectile sprites.
- Runtime effects: muzzle flashes, elemental trails, impact bursts, lightning arcs, poison bubbles, ice shards, shockwaves, hit stop, and restrained camera shake.
- Data-driven pacing: denser wave checkpoints in the first 75 seconds, difficulty scaling from the start, early elites, a 60-second recurring Boss, and fewer upgrade interruptions.

This is preferable to sprite-sheet VFX because it preserves responsiveness, scales to multiple projectile counts, and keeps the repository small.

## Art direction

- Original Western Q-style stylized 3D mobile-game art; chunky toy-like bevels and readable silhouettes.
- Royal blue, warm gold, tomato red, toxic lime, icy cyan, and deep navy shadows.
- Upper-left key light, cream highlights, thick friendly shapes, no text, no logos, no copied characters or trade dress.
- Skill icons remain legible at 32-64 px. Projectile sprites remain legible at 12-36 px.
- Battlefield is a seamless top-down dark food wasteland: cracked slate, ketchup stains, fry crumbs, tiny rivets, and sparse decorative debris. The center contrast stays low so enemies and projectiles remain readable.

## Missing asset coverage

Nine icons: ketchup aura, butter lubricant, fork splitter, magnet salt, starch boots, cheese armor, pickle critical, socket chain, salt spread.

Five projectile sprites: peeler blade, fire potato, frost chip, lightning potato, starch bomb.

One battlefield background tile.

All files are registered in `src/configs/assets.json` and validated for path and dimensions.

## Combat feedback

- `WeaponProfile` carries an optional projectile asset id and a visual family.
- `AutoAttackSystem` emits one fire event per volley and assigns the projectile asset.
- `RenderSystem` rotates projectiles along velocity and renders the generated battlefield behind translucent grid lines.
- `CombatVfxSystem` owns short-lived trails and uses fixed budgets to avoid runaway particles.
- `ProjectileCollisionSystem` emits typed impact events with the originating skill id.
- Existing status colors remain, but burn, frost, poison, chain, and explosion receive distinct shapes and motion.

## Pacing

- Opening 0-12 seconds: immediate five-enemy bursts and visible projectile feedback.
- Pressure 12-28 seconds: exploders enter; spawn rate rises.
- Rush 28-45 seconds: chargers and early elites enter.
- Pre-Boss 45-60 seconds: ranged units join and arena pressure peaks.
- 60 seconds: Boss, strong banner, camera pulse, and phased attacks.
- 75 seconds onward: summoners and higher density.
- Experience thresholds rise so upgrade choices feel meaningful instead of interrupting every few seconds.

## Validation

- Every skill config has an icon asset id.
- Every projectile weapon resolves a registered projectile asset.
- Pacing tests assert the early checkpoints and 60-second Boss cadence.
- Browser QA covers 1280x720 and 390x844, firing every weapon family, Boss arrival, upgrade selection, dynamic resize, and console errors.

## Success criteria

- No missing skill icon in upgrade cards or HUD.
- No plain square player projectile remains when its texture is available.
- The battlefield no longer looks like an empty debug grid.
- Fire, frost, lightning, poison/aura, peeler, and explosion attacks are distinguishable at a glance.
- The first minute contains at least three escalation beats and a Boss climax.
