# Simple combat notifications

User supplied two images: replace the ornate crowned ribbon with the second reference's quiet dark strip and prominent cream type. Earlier user instructions request direct execution without approval pauses. This is a scoped UI revision, not a combat redesign or new bitmap generation.

Use a translucent dark horizontal strip with softly fading ends, centered bold warm-cream text, a restrained dark outline and no crown, gold frame, ribbon folds or colored glow. Replace the elastic scale bounce with a short fade/6px slide. Preserve notification event routing, duration and single-notification ownership.

Notification bounds begin below the Boss bar with an8px gap. Desktop maximum width560px and reserved height112px; compact maximum width420px and reserved height104px. The visible strip follows actual text height rather than filling the entire reserved region. Text uses real canvas glyph measurements, begins at32px desktop/24px compact and can reduce to18px when needed. Short tactical warnings prefer one readable line; longer messages wrap Chinese and preserve explicit chapter lines. Current authored messages must remain complete and fit within three lines; extraordinarily long future messages receive a bounded three-line ellipsis rather than covering the battlefield. On resize, reflow the original message, not already wrapped text.

No gameplay values, attack effects, HUD counters, Boss bar art, other popup art or asset files change. Verify actual UIScene object creation/layout/lifecycle with minimal Phaser doubles; verify all authored notification strings and320/390/1280width layouts. Live GUI QA checks desktop and390×844, then restores the viewport and playable tab.
