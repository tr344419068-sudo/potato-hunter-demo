# Difficulty Curve Smoothing Design

## Goal

Make the opening two minutes feel fair and steadily escalating without removing the chapter climaxes at 24, 40, and 60 seconds. The player should have enough time to establish a build, understand each new enemy family, and recover from one mistake before the next pressure beat.

## Root cause before the fix

The current curve measures intensity through burst size and alive caps, but it is not calibrated against player clearing capacity or incoming-damage bounds.

- The starting peeler deals about 32 single-target damage per second.
- Enemy health enters the arena at about 148 HP per second at 0 seconds, 387 at 24 seconds, 567 at 40 seconds, and 906 at 60 seconds.
- Pressure changes as hard steps when a wave changes, so a chapter transition simultaneously adds tougher enemies, larger batches, a higher alive cap, and sometimes a captain.
- Contact damage uses a player hit cooldown, while ranged projectiles and exploders bypass it. Multiple hits can therefore stack within one frame and cause deaths that movement or dash timing cannot reasonably correct.
- A separate difficulty multiplier increased batch size at 75, 130, and 185 seconds. The first change from 3 to 4 monsters added 33% instantaneous spawn throughput even after the wave curve was smoothed.

The fundamental issue is therefore unbounded and discontinuous threat input, not insufficient player health.

## Considered approaches

1. **Reduce all monster damage.** This lowers deaths but leaves sudden crowd saturation and does not fix stacked projectile or explosion hits.
2. **Increase player damage and health.** This hides the opening imbalance and makes strong builds scale out of control later.
3. **Calibrate threat throughput and damage cadence (selected).** Reduce opening spawn throughput, interpolate pressure continuously between authored beats, and make every enemy damage source obey a shared recovery window.

## Pacing design

Keep chapter presentation and encounter nodes discrete, but interpolate the numeric pressure from one checkpoint toward the next using smoothstep easing. Pressure is measured as base enemy health entering the arena per second, not raw enemy count. At a roster boundary, the runtime blends the previous and new monster weights over six seconds, then converts the continuous health budget back into a spawn rate using that blended roster's weighted average health. Tougher rosters naturally arrive in smaller numbers while low-health rosters arrive in larger numbers. The alive cap grows in rounded integer slots rather than making wave-sized jumps.

All authored ordinary spawn batches contain three monsters. The separate difficulty bonus at 75, 130, and 185 seconds also ramps over six seconds; `SpawnSystem` releases the added throughput by shortening the interval rather than enlarging a batch.

Authored base-health targets are 80.00, 106.62, 203.51, 236.88, 408.28, 447.46, and 627.45 HP/second at 0, 10, 24, 40, 60, 105, and 165 seconds. These are wave budgets before difficulty HP multipliers, elites, summons, and separate captain/Boss encounters; they are not total runtime threat or player DPS requirements.

Rebalance the authored wave budgets so enemy health throughput rises in measured stages rather than multiplying every 10–20 seconds. The opening should begin above the base weapon's clear rate so movement still matters, but it must not fill the alive cap before the first meaningful upgrades.

Target shape:

- 0–10 seconds: readable warm-up, low crowd cap, first upgrade earned quickly.
- 10–24 seconds: mixed enemies enter without doubling total pressure.
- 24–40 seconds: charger captain creates a local spike while baseline pressure keeps rising gradually.
- 40–60 seconds: ranged crossfire adds execution difficulty, not unavoidable burst damage.
- 60 seconds onward: Boss and siege wave remain the first climax, with enough headroom to dodge and clear adds.

## Damage cadence

All hostile damage checks use one pure damage-gate model:

- Dashing rejects hostile damage.
- An active player hit cooldown rejects overlapping hits.
- Accepted contact, projectile, and explosion hits apply source-specific recovery windows.
- Projectiles and exploders are still consumed when blocked, so the player does not get hit again by the same attack after the grace window.
- Elite death bombs use the same gate and are removed even when blocked. Ordinary contact enemies remain alive.
- `PlayerStatsSystem` advances the shared recovery clock exactly once per frame, before all hostile damage systems; individual damage systems do not advance it.

Contact attacks preserve the existing 900ms recovery window; projectiles use 520ms; self-explosions, elite death bombs, and telegraphed Boss AOE use 700ms. The AOE safe center remains safe. This bounds damage cadence, not the damage of a single hit: a sufficiently strong accepted attack can still kill a low-health player.

## Architecture

- `PacingModel.ts` owns the pure easing and weighted threat-budget interpolation.
- `WaveManager.ts` blends roster weights, derives their weighted average health, and converts the continuous health budget to a spawn interval.
- `DifficultyManager.ts` eases extra spawn pressure; `SpawnSystem.ts` keeps ordinary batches fixed while consuming that bonus through interval changes.
- `PlayerDamageModel.ts` owns pure hostile-hit acceptance and grace durations.
- Contact, projectile, exploder, AOE, and elite-death-bomb systems consume the shared damage model instead of implementing inconsistent checks.
- `PlayerStatsSystem.ts` owns the shared recovery clock, before hostile systems in `GameScene.ts`.
- JSON remains the source of authored wave targets; no gameplay constants are hidden in rendering code.

## Validation

- A focused pacing test asserts bounded health-throughput growth, lower opening saturation, monotonic pressure, and continuity around every checkpoint.
- Focused damage tests execute all five real ECS damage paths, checking dash immunity, cooldown immunity, recovery windows, one-shot consumption, mixed-source and volley stacking, expiry, and AOE safe centers.
- Difficulty-spawn tests execute the real spawn system and verify fixed batches, continuous effective pressure at bonus nodes, and increased sustained throughput after the ramp.
- Existing combat, UI, asset, and production-build checks must remain green.
- Browser QA covers the first Boss on desktop and portrait viewports, with special attention to 24-, 40-, and 60-second transitions.

## Success criteria

- The player is not forced into a saturated arena before the first upgrades.
- Numeric pressure has no visible jump at wave boundaries.
- Ranged volleys and clustered exploders cannot deal multiple unavoidable hits in one frame.
- The first Boss remains a clear difficulty peak, but a healthy player can survive one mistake and recover.

## Verification record — November 17, 2026

- Full combat suite: 80/80 passed; UI suite: 11/11 passed.
- Asset validation: 69 checked, zero missing assets and zero dimension mismatches.
- Production build: TypeScript and Vite succeeded. The existing large-chunk warning remains.
- Desktop 1280×720 and portrait 390×844: upgrade selection, Boss entry/HUD, projectile and AOE presentation, results, and restart exercised without captured console errors. Portrait dash control visibly entered cooldown. Temporary viewport overrides were reset.
- Boss short-flow checks used debug time advancement and do not establish natural-run balance or a Boss victory. Natural opening samples reached the 24- and 40-second families, but did not establish reliable full-minute survival or recovery across builds. Long-run and build-specific tuning remain unverified.
- Non-blocking test limitation: mixed-source tests hand-code system order; actual `GameScene` ordering was reviewed, but no automated scene-order regression assertion is added in this change.
