# Player level growth and reliable sustain

User asks for planning assessment, proportional level-up healing, small HP-cap gains and basic stats. Execute directly under the standing preference not to wait for design approvals. The current source has 100 starting HP, no character-level stat rewards, a fixed heal first spawning at 43 seconds, and random supplies first spawning at 30 seconds. Purely increasing starting HP delays failure but does not create a recurring recovery loop; full healing at every level would erase too many mistakes. Choose modest permanent growth plus predictable partial recovery.

## Rules

- Lv1 has no growth reward. Each earned character level adds 5 maximum HP and 2 percentage points of base damage, linearly from the Lv1 baseline.
- After reaching Lv2–5, heal 20% of the new maximum HP; Lv6–10 heal 18%; Lv11+ heal 15%. Round the proportional heal upward to whole HP. Fill newly gained HP capacity separately, preserving existing wounds; cap current HP at the new maximum.
- Example: 40/100 at Lv1 becomes 66/105 at Lv2 (+5 capacity filled, +21 heal). Lv10 maximum is 145 and base-damage multiplier is 1.18 before skill-specific bonuses. Skills that add maximum HP remain additive and contribute to the proportional-heal base.
- Award HP and healing in ExperienceSystem when the character level actually increments, before opening choices. Delayed/cancelled/reopened/duplicate/debug skill-choice sessions never award it. Multiple earned levels each award once; dead or missing-health players cannot collect XP or be resurrected by upgrading.
- PlayerStatsSystem reconciles the combined HP maximum from character level and skill bonuses using health.max as the authoritative previous maximum, not a stale per-system cache. Repeated updates do not grant health repeatedly; a fresh run starts at Lv1.
- Base damage applies to projectile direct hits, aura ticks and newly applied burn/poison effects. Chain and explosion damage already derive from the scaled source hit, so must not multiply twice. Existing in-flight projectiles/statuses retain their cast-time snapshot. Attack speed, critical chance, move speed, skill ranks and skill choice rules stay unchanged.
- Earned growth must not cancel or accelerate a running burst. Its queue signature uses rounded loadout damage before character growth; later shots snapshot the current grown profile, while the original burst intervals and cycle cooldown stay intact. Intentional skill/loadout changes retain the old invalidation behavior.
- No extra overlay, camera feedback, VFX or XP/enemy/difficulty edits. Existing HUD automatically displays actual current/max HP. This turn does not add loot guarantees, rerolls, new chapters, win conditions or metaprogression.

## Architecture

Small PlayerLevelGrowthModel owns sanitized-level formulas and HP-cap reconciliation. ExperienceSystem uses it for actual earned-level healing. PlayerStatsSystem uses the same maximum formula each update. SkillManager/SkillStatsCalculator profile APIs accept optional character level (default 1 keeps callers compatible); AutoAttackSystem and AuraSystem pass the live player level. Growth is derived rather than stored in a second mutable accumulator.

## Planning priorities to report (not implement this turn)

1. Reliable recovery loop and baseline character growth (this turn).
2. Build completion reliability: help players find complementary upgrades; avoid unearned early complexity.
3. Threat/rest cadence and telegraph readability; survival should reward choices rather than random attrition.
4. Clear chapter completion/victory and next-run goals; gold currently has rewards/counts but no spend/progression loop in this source.
5. Balance evidence by run phase and damage source rather than repeatedly tuning from impressions.

## Verification

Test-first actual XP -> growth -> chooser flow; one/multiple levels, full/missing HP, no repeated reward, skill HP interactions, restart/fresh owner, dead guard, ratio boundaries, linear stat math, weapon/aura/DoT runtime effects and non-double-scaled explosion. Run UI/combat/assets checks and production build. Independently review final changes; local file snapshots substitute for Git since no repository is present. Protected enemy/difficulty/XP configs must remain byte-identical.
