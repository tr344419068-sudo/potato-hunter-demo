# Potato Hunter — producer quality release

Approved direction: a complete 6–8 minute single-player cartoon survivor, clear build choices, recovery windows, final boss victory, persistent gold/unlocks, authored animation and sound, followed by reproducible stability testing. The user explicitly authorizes continuous execution without approval pauses. Existing dark grass, readable Chinese typography, automatic upgrades, camera stability, imported licensed VFX and earned-level growth must remain intact.

## Deliverable sequence

1. Complete run: home/loadout/settings, encounter rhythm, final boss, victory/failure settlement, persistent wallet, starter unlocks and limited rerolls.
2. Presentation: authored sound families and adaptive music; genuine articulated hero actions rather than more whole-image bouncing; distinct role silhouettes and readable enemy danger over friendly VFX.
3. Reliability: deterministic run seed, per-source damage and phase snapshots, save validation/exact-once rewards, pause/background handling, browser and long-run regression, measured performance.

The first two systems below are independent; the root owns scene/UI integration. Do not edit protected skill, wave, monster, difficulty or XP curves merely to compensate for new systems. No network accounts, ads, payments, equipment grind or multiplayer.

## Run contract

The final boss enters at 360 seconds; normal play should finish around 6–8 minutes depending on build and execution. Victory requires killing that tracked boss, not waiting out a timer. Intermediate bosses enter at60,180,300 seconds. Existing first-minute warmup is retained. Later encounters alternate buildup, an elite/high-pressure beat, then18–20 seconds of reduced spawn pressure and a visible recovery opportunity. A low-health rescue pickup has a strict cooldown and spawn lifetime, does not resurrect and requires reaching it. Pausing, upgrade choices and the home screen stop simulation time. Bosses and hostile warnings do not execute while paused.

Home offers three starting identities: peeler free, pepper and lightning each90 banked gold. Unlocks change the starting weapon, not permanent HP/DPS. Default legacy SkillManager behavior stays peeler when no starter is supplied. Runtime only offers actual owned/default starter ranks; the chosen starter replaces the implicit peeler rather than stacking a free second weapon. Owned/evolved skills remain selectable, with a6-active/4-passive loadout capacity; replacing a component with its evolution does not consume an extra slot. Two rerolls per run retain the same XP credit and never re-award HP.

## Wallet/save contract

Store a version1 profile under `potato-hunter.profile.v1`, validate every numeric/enum/array field, tolerate blocked storage and malformed input, and never silently delete unrelated data. API returns an explicit persisted flag. Settlement is idempotent for the same run id; purchases deduct only when affordable and unlock only once. A run with under15 seconds and fewer than3 kills has no participation reward. Valid runs receive collected gold +10 +floor(seconds/20) +15 per boss +80 for victory. No hidden permanent combat stat purchases. Music/SFX volume, reduced-effects setting, selected loadout and unlocks persist.

## Sound/art direction

Blue enamel, warm ivory and restrained gold remain the menu/UI materials. Use the actual hero and skill PNGs rather than placeholder icons. Text uses the accepted ordinary Chinese stack, not display/art lettering. Home and settlement can be expressive; combat stays quiet except for meaningful action. No full-screen white flashes or routine camera shake.

Sound is original generated/produced audio, with provenance and reproducible scripts: weapon family launches, material-specific impacts, critical/破盾, dash, pickup, upgrade, boss cue, victory and defeat. Layer short percussive attacks with pitched/material tails, finite polyphony, event cooldowns, and BGM ducking for high-priority danger. Background score has calm/combat/boss layers. Muted/locked/unavailable audio never blocks play; unlock on explicit user input. No claim these are AI-generated or licensed third-party recordings.

Character production will preserve the potato hero's blue jacket/red band/peeler identity. Prefer independently articulated parts or an authored 3D-pre-render pipeline, save sources and export manifests. Inspect idle/run/attack/dash/hit/death at actual game size. Keep original imagery as a fallback, not silently replace it with a visibly poorer model. New audio/art must pass visual or auditory QA before wiring.

## Reliability and evidence

Tests cover profile corruption, blocked persistence, idempotent settlements, purchase rejection, final-boss tracking, dead-player behavior, rest timing, rerolls, starter compatibility, real GameScene transitions, pause and restart. Record seed, outcome, build, per-source damage, healing and periodic HP/level/entity snapshots. Use local live browser checks at desktop and portrait sizes; run full regressions and20-minute stability checks. Existing geometry/missing-art fallbacks are development safety nets, not release-ready assets. No success claim based only on code compilation or particle count.
