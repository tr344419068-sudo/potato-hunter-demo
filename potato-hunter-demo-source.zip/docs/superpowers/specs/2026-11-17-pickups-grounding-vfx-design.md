# Pickup Art, Foot Grounding, and Hero VFX

Scope: the user's three requested presentation changes; preserve gameplay, damage, spawn pacing, and the dark low-noise grass.

## Findings and selected approach

Dash is a text-only circle. Map events deliberately bypass sprite rendering, and experience orbs have no asset ID. Existing running-boots, magnet, heart, coin, and crystal PNG art can supply consistent images without a new art style or an external dependency. Use these for the dash button and five pickup families, with a grounded halo and bobbing icon; keep geometric drawing only as a missing-texture fallback.

Character sprites use torso pivots, while shadows use role-wide guessed offsets. Changing pivots would move the character relative to weapon/collision coordinates. Instead, retain gameplay pivots and add per-asset normalized foot points calibrated from visible soles (hero 0.574/0.930, ordinary enemies around 0.5/0.930, tracked Boss 0.482/0.852). Transform the foot point using current scale, facing, and rotation, leaving jumping lift out of the ground plane. Shadow center and death dust consume the same anchor. Dash ghosts retain the original sprite pivot.

Simply increasing particle count would hide hostile projectiles and cost more. Increase bounded visual silhouettes: longer thicker trails; peeler crescents, flame lobes, frost shards, forked lightning, poison bubbles, and sauce splashes. Add a short core flash, an expanding impact silhouette, and a delayed secondary burst. Keep the existing particle limits, pool reuse, enemy-projectile colors, and damage radii unchanged.

## Acceptance

- Dash shows running-boots art while retaining click/keyboard input and cooldown countdown.
- XP and every map-event kind have real available texture IDs; sprites and labels clean up on pickup/restart.
- Shadows follow calibrated feet through scale, flip, and rotation, without a second guessed vertical offset.
- VFX families visibly differ; critical hits are larger than ordinary hits, with bounded effect lifetimes and no increase to collision size.
- Focused regressions fail before fixes, then full combat/UI/assets/build pass. Desktop and portrait screenshots verify actual visuals.
