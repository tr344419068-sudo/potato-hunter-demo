# Boss patterns, role enemies, and attack-speed builds

User direction: execute autonomously. Preserve the prior pickup art, foot anchors, VFX, dark grass, and difficulty smoothing. This folder is not a Git checkout; no branches, commits, dependencies, or external publication.

## Chosen approach

Three viable scopes are config-only roster variants, a readable pattern/role/build expansion, or a new level/asset pipeline. Choose the middle scope: meaningful combat decisions within the current ECS and art system. No unrelated level rewrite. Reuse finished food PNGs with distinctive role cues/tints for enemy variants; do not describe these as newly AI-generated illustrations.

## Boss contract

Replace shared concurrent timers with independent per-boss state. Each boss follows windup → execute → recovery, with only one pending cast per boss. Health phases at 50% and 20% expand the sequence, not stack independent timers. Stage one has fan oil bullets and snapshot-targeted bombardment; stage two additionally has a locked-direction charge and a capped summon; stage three adds an annular heat blast with a green safe center. Use five named patterns in total. First cast waits at least 1.5 s. Every damaging attack gives at least 0.75 s readable warning; charge gives at least 0.95 s. Recovery is at least 0.8 s. Dead/despawned bosses cannot finish pending casts or retain telegraphs.

Bullets have deliberate gaps, moderate speed and finite lifetime. Bombardment records the player's location at windup, never tracks invisibly afterwards. Charge freezes aim during windup and uses a line/rectangle warning that matches travel direction/length; damage comes from normal contact, not an additional overlapping explosion. Summons use the existing alive budget and a small per-cast cap, and must not accelerate total pressure unboundedly. Existing damage grace/dash invulnerability apply to all hazards. Existing boss HP multipliers and global wave cadence are unchanged.

## Role enemy contract

Add three selectable wave entries with independent identity and role, not merely higher HP: `shield_guard` (armored fries, one-shot breakable shield and slow advance), `onion_flanker` (green/lime onion, circling approach and readable short lunge), `corn_bombardier` (orange corn, keeps distance and places a small delayed bomb at a snapshot position). Reuse PNG art plus clear role ornaments. Shield size/HP does not endlessly regenerate. Bomber cannot carpet the map: bounded range, at least 2.8 s cooldown, ≥0.9 s telegraph, small radius and single blast. Flanker is slower than the hero outside its brief attack, which has a warning and recovery.

Introduce roles progressively from 24, 40 and 60 seconds, replacing portions of the existing mixes. Keep spawn interval/count/maxAlive and difficulty settings. Preserve early chaff and runtime pressure-continuity tests. Existing ranged/summoner variants should not fire or summon while dead; normal summons also respect the alive budget. Bosses skip regular monster behavior to avoid duplicate skills.

## Attack-speed build contract

Add `pepper_gatling` (low-damage high-frequency accurate fire), `corn_burst` (three spaced shots, not three simultaneous spread shots), `pepper_motor` (permanent additive attack-speed bonus), `combo_gear` (confirmed-hit tempo stacks), and evolution `pepper_overdrive`. Existing `butter_lube` remains the cooldown support. A named attack-speed build, tags, upgrade hints, and reachable evolution requirements expose this path in the existing choices. Reuse available PNG icons/projectiles.

Keep calculations bounded: positive cooldown floor, capped tempo stacks, finite burst queue, finite projectile count and lifetime. New rapid weapons may opt out of the old extra-projectiles-every-two-levels rule. Permanent attack speed uses division by 1 + bonus, then dynamic tempo/buffs apply with the final floor. Tempo only increases on a real successful projectile collision; missing shots/firing do not stack it. Tempo decays after a hold window; pausing/restarting cannot leak it. Burst shots resolve current player/target positions at each shot, retarget valid living enemies, and do not discharge queued shots when no enemies remain. No giant backlog after a long frame or skill change.

HUD shows attack-speed bonus and tempo stacks without overlapping mobile controls. Existing skills and enemies retain their parameters unless needed for correctness. Existing impact/particle caps remain. No damage-radius changes for presentation.

## Verification

Test-first integration tests run actual production systems using minimal Phaser doubles. Cover boss windup/locked aim/serial recovery/phase cycles/dead cancellation/two bosses, role behavior and shield/damage/budget, burst timing/retarget/no target, confirmed-hit tempo/decay/caps/restart, and actual skill/build/evolution config reachability. Run all combat/UI/asset tests and TypeScript/Vite build. Browser QA uses only supported computer-use APIs: desktop + portrait, visual role cues, one boss pattern, an attack-speed skill, dash/pickups/grounding, console errors, saved screenshots, and restored viewport. Record what was actually observed separately from automated coverage.
