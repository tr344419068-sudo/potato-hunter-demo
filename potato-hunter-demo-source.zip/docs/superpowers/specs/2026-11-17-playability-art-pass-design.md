# Uninterrupted play and stronger art feedback

The user requests direct implementation of four linked fixes: stop unsolicited interruptions; larger upgrade icons, visible upgrade levels and coherent typography/layout; normal limb-based walking for hero/enemies; MOBA-like particle layering. Existing balance, Boss telegraphs, grass and foot calibration stay intact. This folder has no Git repository. No publishing, paid service or dependency installation.

## Interaction and cards

Earned upgrades accumulate run-local credits, not unsolicited modals. A small explicit HUD upgrade control (and U shortcut) opens choices on demand; only this deliberate choice pauses combat. Closing postpones selection without consuming a credit. Selecting a valid offered skill consumes exactly one credit; multiple earned credits survive. Restart clears credits; no stale or arbitrary skill selection applies. Ordinary chapters/cast messages no longer create transient announcements; keep only Boss arrival/defeat and real phase changes, with deduplication/rate limits, font16–20 and short unobtrusive lifetime. Ground attack warnings remain readable.

Use a compact consistent upgrade layout, not a full-screen gold blast. Icon takes about40–50% of card width on desktop with a clear band for title, current→next level, one concise benefit and up to3tags. New skills show NEW/Lv1; owned skills show LvN→LvN+1, rewards do not show fictitious skill levels. Titles use a rounded Chinese game type style; body uses readable Chinese sans. Match navy/gold/cream art but remove empty medal plaques and redundant overlapping frames. All texts measured and bounded at320×480,390×844,1280×720. HUD skill slots/icons also increase without colliding with dash/status.

## Walking

Current art is single idle PNGs. Implement honest2D articulated deformation of existing art, not claim new3D rigs. A normalized skinning model moves two feet/legs in alternating planted/swing phases and counter-swings hands around calibrated shoulders; hero weapon-hand adds bounded attack pose, torso stays almost level. Use original UV image/alpha on a modest triangulated grid so no rectangular cut seams or duplicate arms. Walking phase advances by real displacement/speed and stops at idle. Apply calibrated variant rigs to humanoid food enemies; slime can retain low smooth deformation, Boss retains machine motion. Keep collisions, sprite pivot, render alpha, status tint, foot shadows and death/dash art; mesh objects pruned on despawn/restart. Canvas fallback remains usable.

## VFX

Add actual runtime particles with bright core, colored glow, directional ribbons and family-specific debris (embers/ice shards/electric sparks/poison motes) rather than only scaled rings. Visible motion uses finite lifetimes, per-event count and global active cap, with cheaper rapid-fire trails and stronger critical/reaction accents. Ground residue sits below actors, airborne effects above; hostile warnings and player silhouette must stay readable. No damage/radius/attack-rate changes, no extra gameplay freeze/camera flash spam. Pools/emitters cleanly reset at scene shutdown.

## Verification

Test-first regressions for live upgrade lifecycle/selection/credits, reduced notification routing and font bounds, actual card level/icon layout; numeric limb swing/plant/idle and actual renderer mesh prune/tint; actual VFX emissions/lifetime/caps/shutdown. Independent spec then quality review. Full combat/UI/assets/build. GUI via CUA only, real pointer/keys, desktop/portrait screenshots and a walking frame sequence or preview; no hidden runtime state mutation.
