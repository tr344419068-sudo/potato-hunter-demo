# Battlefield Chapters Design

## Goal

Turn the current endless grass arena into a readable first-minute level with changing enemy formations, environmental art, movement objectives, elite set pieces, and a clear boss climax while preserving the fast survivor-like movement loop.

## Assessment

The project already has strong character, enemy, projectile, card, HUD, boss, reaction, and dash assets. The missing layer is orchestration: the battlefield remains visually static, the first wave is one repeated enemy, map rewards arrive too late, and textured enemies do not visibly communicate elite affixes.

## Considered approaches

1. **Pure art repaint:** add more background textures and particles. Fast, but the level would still play the same.
2. **Physical map obstacles:** build collision-aware props and lanes. Deeper, but it risks breaking movement, spawning, and the current horde readability.
3. **Chapter director (selected):** coordinate art direction, spawn formations, elite captains, and reward objectives through a tested time-based model. This gives the strongest perceived level progression without changing the core control scheme.

## First-minute chapter structure

| Start | Chapter | Formation | Art direction | Gameplay beat |
| --- | --- | --- | --- | --- |
| 0s | 青酱草甸 | loose ring | dark moss, pale grass tufts, stones | learn movement and dash |
| 10s | 番茄突袭 | two-sided pincer | restrained red sauce marks | first mixed enemy pressure |
| 24s | 外卖围猎 | three-lane wedge | crate debris and gold accents | shield captain + first objective |
| 40s | 汽水交火 | four-direction crossfire | cool cyan puddles and bottle shards | ranged captain + heal objective |
| 60s | 油锅终局 | siege ring | amber arena marks and scorched props | fryer boss climax |

## Architecture

`LevelChapterModel.ts` owns immutable chapter data, time selection, spawn-angle rules, and deterministic decoration selection. It has no Phaser dependency and is covered by Node tests.

`ChapterDirectorSystem.ts` observes chapter transitions, emits presentation events, and creates guaranteed elite captains at the two mid-level beats. `SpawnSystem` consumes the same model for formation-aware spawn positions.

`BattlefieldBackground.ts` remains responsible for the grass tile, but gains a single batched graphics layer for sparse world-space props, a restrained chapter tint, and the boss arena. Decorations are deterministic per grid cell, so they do not shimmer while the camera moves.

`RenderSystem.ts` adds readable elite-affix and map-object silhouettes using code-native graphics. `UIScene.ts` consumes chapter and boss-phase events through the existing Clash-style ribbon language.

## Visual direction

The battlefield stays dark, muted, and low-noise. Props use chunky silhouettes, thick dark edges, small saturated accents, and soft elliptical grounding consistent with the existing stylized 3D cartoon roster. Decoration density is capped so monsters and projectiles remain the visual priority.

No external generated bitmap is required for this pass: the missing art is systemic set dressing and telegraphing, which is better produced deterministically in Phaser graphics than as another flat full-screen texture.

## Balance and pacing

- Introduce the second enemy family at 10 seconds, chargers at 24 seconds, and ranged attackers at 40 seconds.
- Spawn one shield captain at 24 seconds and one haste/ranged captain at 40 seconds.
- Move map objectives into the first minute: magnet around 18 seconds, supply around 30 seconds, heal around 43 seconds.
- Keep the 60-second boss cadence and existing experience curve.
- Captains are pressure spikes, not bosses: about 2.2× health, 1.2× damage, and 2× experience.

## Quality bar

- Desktop and 390×844 portrait must keep HUD and chapter banners unobstructed.
- Spawn formations must be observably distinct and bounded.
- Decorations must be deterministic, sparse, and stay behind gameplay entities.
- Elite affixes and map objectives must be readable without relying on text.
- Combat, UI, asset validation, and production build must remain green.

