# Automatic experience upgrades

The user requests experience-triggered upgrade choices instead of requiring a
manual upgrade action. Their prior instruction is to execute directly without
plan-approval pauses. This replaces the default manual flow, not the recent art
or difficulty work.

## Interaction

- Crossing an experience threshold immediately opens the existing three-choice
  upgrade popup and pauses combat. No U press or HUD-button click is required.
- Each earned level adds exactly one choice credit. Several levels earned in
  one collection queue behind one visible popup, not parallel overlays.
- After a valid choice is applied, show the next queued choice with freshly
  generated options/levels. Resume combat only when the queue is exhausted.
- Preserve the existing explicit “稍后”/Escape postponement as an optional
  cancellation. It preserves credits and does not immediately nag/reopen; the
  existing U/button can reopen it, and the next newly earned level triggers the
  automatic flow again. Manual reopening is a fallback, not the default.
- Held number keys, duplicate/stale session selections, or one held pointer
  must never select additional upgrades accidentally. Keep pointer-consumption
  protection and add keyboard-repeat protection where needed.
- Restart clears credits and visible overlays; defeat cannot open upgrades.

## Approach

Keep ownership in GameScene: requestSkillChoice records a credit and invokes
the existing guarded opener. handleSkillSelected applies the selected reward
or skill before invoking the opener for remaining credits. No timer, new queue
service or second popup owner is needed. Existing session tokens remain the
authority for validating choices.

Alternatives rejected: keeping a manual-only flow contradicts the request;
removing all postponement/input pathways changes unrelated user controls.

## Verification and scope

Use real GameScene, ExperienceSystem and UpgradePopup runtime tests. Replace
manual-only expectations, cover pause/resume, multilevel XP, rewards, stale
selections, held input, postponement and restart. Update fixture listener order
to capture automatic events. Run UI/combat/assets suites, asset validation and
production build; smoke-test a naturally earned automatic popup without U.

No gameplay numbers, spawning, skill power, graphics assets or notification
frequency changes. No Git repository is present, so no branches, commits,
dependency installation or publishing are part of this task.
