# Readable card art and stable combat view

The user asks for a polished upgrade popup instead of plain colored blocks,
explicitly rejects decorative/art lettering, and reports whole-screen
dark/bright/shaking distractions. Execute directly under their standing request
not to pause for plan approvals. Keep XP-triggered automatic upgrades intact.

## Verified causes

- UpgradePopup draws flat opaque Graphics surfaces and outline frames rather
  than the registered `ui_v2_card_*` bitmap art. The 320×420 rare card frame has
  a transparent center, dimensional blue/silver rails and gold corners.
- UI_FONT uses ZCOOL KuaiLe throughout HUD, popup, results and notices; the
  startup loader/CSS explicitly load that face. Replace this lettering with
  standard readable Chinese sans-serif; the user overrides the design skill's
  general preference for display fonts.
- Normal kills, weapon impacts/criticals/explosions, reactions, enemy impacts,
  dash and boss deaths separately call camera.shake. ChapterDirector additionally
  calls camera.flash. These are independent of localized particle artwork.

## Card direction

Use the existing dimensional cartoon card frames with a restrained layered
surface: a cool, softly graded icon area and an ivory/light information plate,
clear dark lettering, inset highlights and quiet rarity color. This is an
original composition using existing repo art, not AI-generated artwork. Preserve
opaque fallback surfaces if textures are unavailable; don't replace readability
with a busy fire illustration. No crown banner or decorative title lettering.

Large skill icons, skill names, current→next level and benefit must fit inside
the actual frame's safe area. Secondary tags may be quieter, not illegibly small.
Provide a coherent horizontal compact card adaptation rather than stretching a
portrait image until borders/gems distort. Test 320×480, 390×844, the user's
approximately 722×794 portrait window, and 1280×720.

Use standard Chinese sans-serif globally for UI display/body text. Avoid bold
decorative strokes, shadows or fake lettering. HUD numbers, skill names and
instructions should remain easy to read. Reduce the popup backdrop from its
current 64% opacity so the battlefield isn't abruptly blacked out; keep it
constant while the chooser is open, not animated/pulsing.

## Stable combat camera

Disable the existing whole-camera shakes and full-screen chapter flashes at
their source. Keep all damage, spawn, warning, chapter, pickup and skill behavior
unchanged. Keep localized imported light textures, blades, smoke, debris,
character hit squash and warning shapes. Do not erase VFX to conceal the camera
problem, and do not add a settings panel, new shader or per-weapon balance pass.

## Verification

Test-first checks for standard font selection/loading, bitmap frame usage and
fallback, inset text bounds and readable contrast, stable input/lifecycle, and
zero camera effects across representative ordinary/heavy/hostile/chapter events.
Run focused suites then all UI/combat/assets checks and production build. Root
will inspect the actual rendered popup at desktop/compact sizes and a natural
automatic upgrade in an isolated background tab. No changes to XP tuning or
automatic-upgrade credit/session behavior are permitted.

Alternatives rejected: more flat outlines leave the art complaint unsolved;
restoring ornate type hurts legibility; busy full-card illustrations compete
with text. Frame art plus restrained material and conventional type balances
the requested game style with readability.
