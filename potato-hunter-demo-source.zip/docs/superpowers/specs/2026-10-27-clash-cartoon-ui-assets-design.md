# Potato Hunter Stylized Cartoon UI Asset Design

## Goal

Replace the prototype/debug presentation with a coherent, original, premium mobile-game UI asset system. The visual direction uses chunky beveled shapes, toy-like materials, warm rim lighting, saturated royal blue and gold, readable silhouettes, and playful potato-world motifs. It may evoke the broad quality bar of Western stylized 3D mobile games, but must not copy protected characters, logos, layouts, icons, or trade dress from any existing title.

## Chosen approach

Use a hybrid rendering system:

- Raster assets provide dimensional frames, ornamental shells, button surfaces, badges, and pictograms.
- Phaser text renders all localized labels and changing values.
- Phaser graphics render fill levels for health, XP, and Boss bars beneath generated frames.
- Layout remains code-driven so one asset set works on desktop and portrait mobile views.

This avoids baked-in text and makes responsive fixes possible without regenerating art.

## Scope

### HUD

- Top-center timer plaque.
- Top-left player health and XP frames.
- Compact gold, kill, level, and wave counters.
- Bottom skill-slot tray and reusable empty skill slot.
- Small pause/settings button shell.

### Combat and progression

- Boss health bar frame and Boss emblem.
- Reusable notification ribbon for wave, reward, evolution, and Boss messages.
- Universal common, rare, epic, and evolution upgrade-card frames.
- New, level-up, and evolution badge family.
- Missing active skill icons: peeler blade, thunder chain, toxic cloud.

### Run completion

- Game-over/results panel.
- Primary restart button and secondary button.
- Stat pictograms for time, kills, Boss kills, gold, and level.

### Reusable icon family

- Heart, XP crystal, coin, skull, crown/Boss, clock, wave, level star, pause, settings.

Character and enemy illustrations are excluded because they are gameplay sprites rather than UI assets.

## Asset rules

- No baked Chinese or English text except decorative, language-neutral symbols.
- Transparent PNG output with generous padding and clean alpha edges.
- Strong silhouette at 24-48 px for icons.
- Frames use symmetric construction suitable for nine-slice or proportional scaling.
- Consistent light from upper-left, warm highlight, cool lower shadow.
- Palette: royal blue, deep navy, warm gold, cream, orange-red accent, emerald reward accent.
- No watermark, no logos, no photorealism, no copied characters.

## File organization

Final assets live under `public/assets/ui/v2/` with subfolders:

- `hud/`
- `cards/`
- `panels/`
- `buttons/`
- `icons/`
- `ribbons/`

Skill icons live under `public/assets/icons/skills/` with `-v2` filenames. The registry in `src/configs/assets.json` owns paths and dimensions.

## Integration design

- Add asset registry entries without deleting the original entries.
- Update `UIScene` to compose generated shells with dynamic Phaser text and fills.
- Update `UpgradePopup` to use universal rarity frames where themed card art is unavailable.
- Preserve shape/text fallbacks when any image fails to load.
- Add resize-driven relayout so UI assets and hit targets stay aligned after viewport changes.
- Keep debug counters behind development mode.

## Validation

- Verify every declared asset exists and has alpha where required.
- Render-check desktop 1280x720 and mobile 390x844.
- Verify dynamic numbers remain readable and do not overlap frames.
- Verify every interactive visual has a matching hit target after resize.
- Run TypeScript build and an asset-registry consistency check.

## Success criteria

- No missing UI or currently referenced skill-icon file remains.
- All runtime HUD and overlays share one coherent visual language.
- UI remains readable on desktop and portrait mobile.
- The game builds successfully and preserves fallback behavior.
