# Player Level Growth Implementation Plan

> **For agentic workers:** Execute inline with test-driven-development and verification-before-completion; use requesting-code-review for a final independent review. Current source folder is not a Git repository; branch/worktree/commit steps do not apply. User requested direct execution without approval pauses.

**Goal:** Make earned levels supply modest permanent HP/damage growth and proportional healing without changing enemy or XP curves.

**Architecture:** Derive growth from live character level in a small pure model. Reconcile HP against health.max in both real XP and ordinary stat updates; only XP increments heal. Pass live level to existing weapon/aura profile generation for one application of damage growth.

**Tech Stack:** TypeScript, Phaser, esbuild/Node runtime tests, existing UI and combat systems.

### 1. HP growth and earned-level recovery

Files: create `src/managers/PlayerLevelGrowthModel.ts`, `scripts/player-level-growth.test.mjs`; modify `src/systems/ExperienceSystem.ts`, `src/systems/PlayerStatsSystem.ts`, `package.json`.

- [x] Write real-system tests before implementation: 40/100 at Lv1 +12 XP must become Lv2, 66/105 before the choices callback; +90 XP from 10/100 must become Lv4 with 91/115 and three credits; no XP consumption/choice/heal for a dead player; repeated stats updates cannot heal; HP skills are additive; a new player with the same stats-system object starts at100HP.
- [x] Run `node --test scripts/player-level-growth.test.mjs`, confirm expected assertion failures (not setup/import errors).
- [x] Implement model and XP/stat integration using these formulas:

```ts
const earned = Math.max(0, Math.floor(level) - 1);
const maxHpBonus = earned * 5;
const damageMultiplier = 1 + earned * 0.02;
const healRatio = earned === 0 ? 0 : level <= 5 ? 0.20 : level <= 10 ? 0.18 : 0.15;
// Only positive, living current HP receives added capacity or earned-level healing.
const nextMax = ConfigManager.player.maxHp + maxHpBonus + skillManager.getMaxHpBonus();
const gained = Math.max(0, nextMax - health.max);
health.max = nextMax;
health.current = Math.min(nextMax, health.current > 0 ? health.current + gained : health.current);
// ExperienceSystem only, once after incrementing level and reconciling max:
health.current = Math.min(health.max, health.current + Math.ceil(health.max * healRatio));
```

- [x] Run focused HP/growth tests to GREEN; register the test in test:combat.

### 2. Basic damage growth with skill synergy intact

Files: modify `src/managers/SkillManager.ts`, `SkillStatsCalculator.ts`, `SkillTypes.ts`, `src/systems/AutoAttackSystem.ts`, `AuraSystem.ts`; expand growth tests.

- [x] Add failing tests for default Lv1 compatibility, linear damage growth at Lv2/10, projectile direct and burn/poison DPS, aura direct and DoT damage, unchanged cooldown/movement/crit; actual AutoAttackSystem and AuraSystem must consume player level rather than just test an unused helper.
- [x] Run focused tests and confirm RED.
- [x] Extend profiles with optional `playerLevel = 1`; multiply pre-rounding weapon damage and aura/DoT damage by `getPlayerLevelGrowth(playerLevel).damageMultiplier`. Do not scale chain/explosion effect parameters a second time.

```ts
getWeaponProfiles(playerLevel = 1) { return this.statsCalculator.getWeaponProfiles(playerLevel); }
getAuraProfiles(playerLevel = 1) { return this.statsCalculator.getAuraProfiles(playerLevel); }
// runtime consumers:
const playerLevel = runtime.world.components.players.get(runtime.playerId)?.level ?? 1;
const weapons = runtime.skillManager.getWeaponProfiles(playerLevel);
const auras = runtime.skillManager.getAuraProfiles(playerLevel);
```

- [x] Run all focused cases and TypeScript to GREEN; inspect only task diffs against baseline snapshots.

### 3. Integration, review and planning handoff

- [x] Run fresh `npm run test:ui`, `npm run test:combat`, `npm run test:assets`, `npm run check:assets`, `npm run build`; verify protected config hashes.
- [x] Independent code review of scope, exact-once rewards, dead guard, linear stat stacking, derived-stat recomputation and restart state. Resolve important issues before handing off.
- [x] Record actual numbers, test evidence and limitations; answer the planning assessment with prioritized recommendations explicitly separate from implemented changes.

## Execution record

Spec and plan self-reviewed for formula consistency, earned-vs-selected event boundary and focused scope.

HP TDD: after repairing a test-fixture method name, 1/16 passed and 15 failed on the expected missing-growth/dead-guard assertions. HP integration then passed all16.

Damage TDD: expanded suite had18 passing and9 failing expected damage assertions before damage integration. The integrated suite passes all27. Production TypeScript and Vite build pass; existing large-bundle warning remains.

Independent review found a concrete burst regression: changing live character damage changed the existing queue signature and cancelled corn/overdrive shots. Two real-system regressions first failed; a third protects intentional rank-change invalidation. Added optional profile damageBeforePlayerGrowth and use it only for queue signature, retaining pre-rounding growth for actual damage. This avoids double profile generation. Re-review reports no remaining critical/important issues; growth plus combat-variety57/57 and TypeScript pass.

Final fresh checks after the fix: UI58/58; combat223/223 (including30 growth cases); assets2/2; all84 assets present with matching dimensions; production build passes. Existing bundle-size warning remains. Protected waves/difficulty/monsters/skills/PacingModel hashes match the baseline. The running localhost5173 server serves the new growth model.

Limits: verification uses actual headless runtime systems, not a new full-length playthrough. Recovery/drop guarantees, rerolls, win conditions, metaprogression, audio and balance telemetry remain planning recommendations, not implemented changes. No enemy/XP/config pressure changes or new UI/camera interruptions were added.
