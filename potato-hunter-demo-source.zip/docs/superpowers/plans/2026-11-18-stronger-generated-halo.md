# Stronger Generated Halo Implementation Plan

> **For agentic workers:** Use superpowers:subagent-driven-development for the single runtime task; controller prepares the asset and verifies browsers. Steps use checkbox syntax.

**Goal:** 将已经AI生成的空心细光晕接入两个范围技能，增强局部波峰但不遮住人物。

**Architecture:** Asset preparation preserves emitted light as a neutral white-alpha 512px texture. AreaVfxModel provides a localized glow envelope; AreaVfxView allocates one reusable ADD image per wave when real imagery is present. Combat simulation is unchanged.

**Tech Stack:** Python/Pillow for image preparation; TypeScript/Phaser; esbuild/node:test; Vite browser module preview.

### Task 1: 准备资源（controller）

- [x] 创建 `artifacts/generated-2026-11-18-halo-sample/prepare-runtime-halo.py`，读取已生成alpha原图，以alpha保持生成光丝，RGB设白；缩为512px，保存 `public/assets/vfx/halo-v1/halo-energy-generated-v1.png`。不覆盖原图。必须使用版本子目录，vfx根目录由CC0导入器拥有。
- [x] 检查RGBA、中心alpha0、外角低alpha，记录 `runtime-halo-verification.json`。保留来源/生成prompt并新增准备记录。

### Task 2: 唯一运行时任务（implementer）

Files: `src/systems/AreaVfxModel.ts`, `src/systems/AreaVfxView.ts`, `src/configs/assets.json`, `scripts/generated-halo-runtime.test.mjs`, `package.json`。

- [x] 使用现有esbuild + displayScene fixture，先写失败测试：加载有效新纹理时每wave一张image，ADD且depth<1；alpha在135ms有更强波峰（不低于.75、不高于1），900ms为0；中心发射位置随wave固定；pause/reduced/destroy/缺图/上限有覆盖。执行 `node --test scripts/generated-halo-runtime.test.mjs` 确认因功能未实现而失败。
- [x] 添加共享asset ID `vfx_halo_energy_v1`，512×512路径 `assets/vfx/halo-v1/halo-energy-generated-v1.png`；面积路径不依赖旧厚重V4素材。完整回归揭示旧CC0导入器重建所有根目录文件，故新生图放版本子目录，不修改或弱化旧导入器检查。
- [x] 在模型添加 `getAreaGlowFrame(radius,ageMs,reducedEffects)`：与现有scale/rotation同步，包络起止0、中段明显波峰、尾部淡出。整体图尺寸≤当前wave直径；reduced alpha0。保留getAreaWaveFrame原逻辑。
- [x] 在view的Emission添加可选image，真实texture存在且不是__MISSING/__DEFAULT时创建，ADD及depth.69；按wave snapshot及glow frame更新position/displaySize/rotation/alpha/visible。graphics还是fallback。最多3layer×(8graphics+2image)。release销毁可选image，不移除texture。
- [x] 新测试加到 `test:roster`；旧未加载新asset的wavefield测试继续验证无image fallback。执行 `npm run test:roster` 及 `npm run build`。
- [x] 两阶段review：先spec后quality，存在问题先修复，不用Git提交（项目不是仓库）。

### Task 3: 浏览器与发布验收（controller）

- [x] 在 `artifacts/generated-2026-11-18-moba/preview.ts` preload列表添加新asset；该预览继续使用生产AreaVfxView，不复制渲染逻辑。
- [x] 浏览器验证Lv1/Lv5，固定步进观察多帧，低特效模式不贴光环、pause冻结。保存新目录 `artifacts/generated-2026-11-18-halo-live/` 截图/GIF，不覆盖前轮录制。
- [x] 执行 `npm run test:release`，保存完整日志并确认测试、资源、构建输出；给出真实模块动画及正式接入状态，不冒充实战。
