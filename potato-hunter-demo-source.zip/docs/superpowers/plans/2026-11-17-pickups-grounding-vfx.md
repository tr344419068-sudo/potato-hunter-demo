# Pickup Art, Grounding, and Hero VFX Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans for inline execution. The user requested direct implementation without approval pauses; this directory is not a Git repository.

**Goal:** Fix the missing dash/drop imagery, align shadows with soles, and exaggerate hero VFX without changing balance.

**Architecture:** A pure pickup-presentation mapping supplies existing PNG texture IDs. A pure foot-point transform augments shadow profiles. Existing pooled VFX consume richer bounded recipes and family silhouettes.

**Tech Stack:** TypeScript, Phaser 3, Node tests, esbuild for headless production-system tests.

### 1. Art hookup

- [x] Add failing tests to `scripts/presentation-polish.test.mjs`: actual map-event and XP factories must assign usable texture IDs; the real render system must create and remove their sprites. HUD must add running-boots imagery and preserve dash input.
- [x] Add `src/systems/PickupPresentationModel.ts`; wire factories and `RenderSystem.ts`. Render a shadow/halo, bobbed texture, readable label, and sparkle, with fallback only when texture missing. Wire dash icon into `HUDView.ts`/`UITheme.ts`.
- [x] Run `node --test scripts/presentation-polish.test.mjs` and inspect pickup/dash visuals.

### 2. Grounding

- [x] Add failing numeric tests for transformed foot coordinates, mirrored facing, rotation, and ground-plane exclusion of jumping lift.
- [x] Add `footPoint` metadata and `AssetManager.getFootPoint`; implement `getCharacterGroundPoint` in `ShadowProfileModel.ts`. Replace guessed offset in `RenderSystem.ts` and death dust; keep sprite pivots and collision coordinates unchanged. Preserve the pivot in dash ghosts.
- [x] Verify numeric tests and compare idle/attack/moving silhouettes to shadow centers.

### 3. Richer hero effects

- [x] Add failing recipe and headless VFX tests for distinct family silhouettes, stronger bounded sizes, and delayed secondary impact cleanup.
- [x] Extend `CombatVfxModel.ts` with bounded presentation envelope and trail/impact profiles; add `drawElementalSilhouette` and a secondary burst to `CombatVfxSystem.ts`. Preserve particle caps and gameplay payload radii.
- [x] Run focused tests, then `npm run test:combat`, `npm run test:ui`, `npm run check:assets`, `npm run build`.

### 4. Visual QA

- [x] Reload and inspect dash, XP, map pickups, shadows, and at least two elemental attacks at desktop and portrait sizes; inspect console logs.
- [x] Save screenshot evidence, restore viewport, keep playable tab/server available, and record exact verification results.

## Evidence and continuation

Initial implementation: 11 new focused tests observed failing before the fixes, then passing. Full combat suite91/91, UI11/11, registered assets69 with0 missing and0 dimension mismatches, TypeScript/Vite build passed. Fresh continuation baseline on2026-11-17 again confirms combat91/91. Independent presentation review found no critical/important issue; the death-dust snapshot can drift finitely during squash/rotation (minor).

Visible checks: desktop fire/peeler effects, XP and magnet, hero/enemy feet; default-size aura/dash click and cooldown;390×844 boots control, peeler trail, supply coin and magnet pictures/labels/ground halos, hero soles/shadow, and complete vertical upgrade cards. Console error/warn query returned an empty array. Saved fresh `artifacts/qa/presentation-polish-portrait-upgrade.jpg` and `presentation-polish-portrait-pickups.jpg`. A dash screenshot taken after the run ended is not useful visual evidence. Supply deliberately reuses coin art; no new image generation occurred. All five map-event kinds have texture coverage in tests, but not all were individually sighted in live play.

Viewport restored and playable tab kept open. User expanded the request to Boss/roster/attack-speed gameplay before the remaining visual matrix finished; combined QA is now recorded in `2026-11-17-combat-variety.md`.

Final combined QA on2026-11-17 covered desktop1280×720 and portrait390×844: rapid/frost/peeler attacks, image-backed upgrades/XP/map pickups, dash input and cooldown, and foot-aligned hero/enemy shadows. Console error/warn query remained empty. Fresh evidence includes `artifacts/qa/combat-variety-desktop-battle.jpg`, `combat-variety-portrait-battle.jpg`, and `combat-variety-portrait-skills.jpg`, supplementing the earlier presentation screenshots. This closes the finite visual gate; not every pickup kind was individually collected in live play, while actual factory/render tests cover all registered map-event texture mappings. No new AI-generated asset or exhaustive animation walkthrough is claimed.

Final verification after the last combat/HUD change: combat118/118, UI11/11, assets2/2, registered assets69 with0 missing/0 dimension mismatches, TypeScript/Vite buildexit0 (existing large-bundle warning only), localhost HTTP200. Presentation review had no critical/important issue; minor finite death-dust snapshot drift remains documented. Existing presentation changes and combat particle caps are preserved.
