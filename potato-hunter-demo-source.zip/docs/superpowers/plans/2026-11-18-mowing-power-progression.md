# 割草威力与成长 Implementation Plan

> 当前会话内按用户授权执行；非Git目录，不建仓库/提交。测试先行、自查、窄范围复核与浏览器证据。

**Goal:** 更大初始圈、前期快速清杂兵、延长且有变化的技能成长。

**Architecture:** 配置给出基础半径/入圈伤害；SkillStatsCalculator统一养成、半径上限与里程碑；AuraSystem独立管理进圈重击状态。SkillChoiceSystem延长进化选卡，PacingModel平滑经验需求。

**Tech Stack:** TypeScript/Phaser，Node/esbuild测试，真实GameScene战役模拟与CUA。

### 1. 测试与配置/成长

- [x] 创建`scripts/mowing-power-progression.test.mjs`，导出真实SkillManager/AuraSystem/World/ConfigManager/AreaVfxView/经验模型，断言初始半径180/190、进圈32/36、上限12/8/6、进化仍可升级、XP后期有界增长、毒气4/8级减速与番茄4/8级击退。
- [x] `node --test scripts/mowing-power-progression.test.mjs`确认RED。
- [x] 修改`skills.json`配置；`SkillStatsCalculator`使用`effectiveRank = ownRank + max(0, strongestActivePrerequisiteRank - 2)`计算已进化武器/光环，统一`Math.min(520, baseRadius*areaMultiplier*(1+.14*(rank-1)))`；新增可选入圈字段，普通无字段技能保留旧行为。
- [x] 普通主动12级、被动8级、齿轮6级、进化6级；`SkillChoiceSystem`已有未满进化进入普通加权候选，初解锁保持优先；进化hint区分首次和强化。
- [x] `getNextExperienceRequirement`保留低级曲线，8→12级smoothstep将复利最低增长换成`currentRequirement + 6 + nextLevel*14`，维持单调。

### 2. 真实伤害

- [x] RED覆盖多个杂兵、Boss/盾、晚进圈、重入、升级、防重复、两个技能、长帧、world重开与技能移除。
- [x] `AuraSystem`增加每技能Map的`inside/readyAt`，逐帧检测进入；进入且冷却就绪时加profile.entryDamage并设置1500ms冷却，只在真入圈触发；DOT计时保持独立。生命为0直接跳过/回收，删除不存在技能/实体，world/player改变重置。
- [x] 番茄entryKnockback沿主角→目标归一化设置已有knockback组件；毒气里程碑通过profile.effects进入已有StatusEffect系统。
- [x] 输出入圈高亮数字而DOT维持isDot；真实DeathSystem负责死亡、掉落与计数，不自行删除敌人。入圈和DOT可同帧合并一次伤害。
- [x] 测试GREEN，再更新旧数值预期到新配置，不删除生命周期约束。

### 3. 验证

- [x] 加入`test:combat`；全量测试检查自动升级/全部长文卡片布局、战役长跑、对象预算与素材。
- [x] 浏览器检查初始/高等级毒气番茄范围与清杂兵画面，不写存档；归档截图/模拟结果，区分模拟和实战证据。
- [x] 窄范围独立复核，修复重要问题，最终`npm run test:release`退出0再交付。
