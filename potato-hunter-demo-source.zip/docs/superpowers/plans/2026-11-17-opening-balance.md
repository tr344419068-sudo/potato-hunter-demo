# Opening balance implementation plan

Design: `docs/superpowers/specs/2026-11-17-opening-balance-design.md`.

No Git repository is present; preserve the existing workspace and do not create a branch or publish changes.

1. Add/update tests in `scripts/pacing-model.test.mjs` for the approved replacement opening targets and XP progression, preserving pressure continuity checks.
2. Add an actual ExperienceSystem regression to `scripts/manual-upgrades.test.mjs` using its existing headless Phaser fixture. Observe expected failures before implementation.
3. Change only `src/configs/waves.json` opening interval/cap targets and `src/managers/PacingModel.ts` XP requirements. Run focused tests.
4. Run combat/UI/assets suites, asset validator and TypeScript/Vite build. Inspect numeric old/new arrival rates and kill-equivalent XP budgets.
5. Smoke-test the existing local game if reachable. Record evidence and remaining limitations here, then deliver the concrete balance changes.

## Execution record

- Completed steps 1–5.
- RED: focused tests failed on the old opening intervals/pressure, 14→73 XP cliff, and 90-XP level-four behavior (six expected failures). Existing continuity and manual-credit tests passed.
- First implementation exposed the existing adjacent health-pressure budget at 24 seconds (ratio 2.008, limit 1.95). Changed its proposed 780-ms interval to 820 ms rather than loosening the regression constraint.
- GREEN: all 23 focused tests pass. Full combat suite: 144/144; UI: 39/39; assets: 2/2; validator: 69 assets, zero missing or dimension mismatches. TypeScript and Vite build succeed; the pre-existing large bundle warning remains.
- Verified opening authored spawn-rate reductions at 0/10/24/40/60 seconds: 33.3%/33.3%/30.5%/19.2%/15.2%. 105/165-second targets unchanged. Runtime pressure and six-second roster-blend continuity still pass.
- Verified early XP requirements: 12/28/50/78/112. Reaching Lv4 costs 90 cumulative XP, previously 218. Actual ExperienceSystem regression confirms three saved credits with no automatic chooser or gameplay pause.
- Browser smoke test used the existing localhost tab and normal WASD movement, pickups and explicit U choices, with no XP/time/kill debug input. In the fresh actively controlled run: Lv2 at the 00:09 observation (100 HP), then Lv3 at 00:19 (85 HP) after choosing a first AoE skill. These are single-run observations, not guaranteed leveling times or a broad balance study.
- An earlier idle-heavy browser attempt ended at 25 seconds; it is not used as evidence of comfortable difficulty or compared against the actively controlled run.
- Screenshot: `artifacts/qa/opening-balance-natural-level3.jpg` (verified 722×794 JPEG). Existing tab retained at the intentional second-upgrade chooser to prevent idle combat damage before handoff. No viewport override was added.
