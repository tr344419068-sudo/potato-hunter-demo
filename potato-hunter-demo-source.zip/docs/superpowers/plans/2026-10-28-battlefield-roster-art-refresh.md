# Battlefield and Roster Art Refresh Implementation Plan

> **For agentic workers:** Execute inline in this session. Follow test-driven development for code and configuration changes; image generation outputs are validated after creation. This workspace is not a Git repository, so commit steps do not apply.

**Goal:** Replace the noisy battlefield and inconsistent roster art while guaranteeing that every upgrade card has a visible background and icon.

**Architecture:** Keep existing stable asset IDs and point them at versioned final images. Split upgrade-card presentation into a guaranteed programmatic surface plus an optional decorative frame, so transparent frame PNGs cannot produce empty cards. Keep battlefield ownership in `BattlefieldBackground` and remove the redundant grid overlay from `RenderSystem`.

**Tech Stack:** Phaser 3, TypeScript, JSON asset manifests, Node test runner, Vite, PNG assets generated with the authorized internal image tool.

---

### Task 1: Lock visual resource contracts with failing tests

**Files:**
- Modify: `scripts/combat-assets.test.mjs`
- Modify: `scripts/battlefield-background.test.mjs`
- Create: `scripts/upgrade-card-art.test.mjs`
- Modify: `package.json`

- [ ] Assert that the battlefield asset is `background_battlefield_grassland`, tileable, and points to `grassland_tile-v2.png`.
- [ ] Assert that hero, five enemy, and boss registrations point to versioned final PNGs.
- [ ] Assert that every skill icon file exists and has non-zero content.
- [ ] Assert that `UpgradePopup` creates a solid card surface before its decorative frame.
- [ ] Assert that `RenderSystem` no longer draws the old dark grid overlay.
- [ ] Run the focused tests and confirm they fail for the expected old-background, old-roster, transparent-card, and grid reasons.

### Task 2: Generate and process the new art set

**Files:**
- Create: `public/assets/backgrounds/grassland_tile-v2.png`
- Create: `public/assets/characters/potato_hunter/idle-v2.png`
- Create: `public/assets/enemies/*/idle-v2.png`
- Create: `public/assets/bosses/fryer_machine/idle-v2.png`

- [ ] Generate one seamless, low-detail green grass battlefield tile with no text, border, large cracks, or dominant props.
- [ ] Generate the hero, five enemies, and boss as separate centered transparent-background assets using one shared style specification.
- [ ] Process generated character files with `scripts/process-generated-asset.py` to clean false transparency and normalize size.
- [ ] Inspect alpha bounds and visual content; reject clipped, text-bearing, or mismatched outputs.

### Task 3: Wire assets and repair card/background rendering

**Files:**
- Modify: `src/configs/assets.json`
- Modify: `src/systems/BattlefieldBackground.ts`
- Modify: `src/systems/RenderSystem.ts`
- Modify: `src/ui/UpgradePopup.ts`

- [ ] Register the grass asset and update battlefield rendering to use it at full opacity.
- [ ] Point existing hero/enemy/boss IDs to the new versioned files, preserving gameplay references.
- [ ] Change card construction to add a filled `Graphics` surface first and a decorative image frame second.
- [ ] Keep procedural fallback borders and hover frames functional when a frame image is unavailable.
- [ ] Remove the obsolete dark grid draw call and implementation.
- [ ] Re-run focused tests until green.

### Task 4: Full verification and browser QA

**Files:**
- No production changes unless a verification failure identifies a defect.

- [ ] Run `npm run check:assets` and confirm all registered files and dimensions are valid.
- [ ] Run `npm run test:assets`, `npm run test:ui`, and `npm run test:combat` with zero failures.
- [ ] Run `npm run build` with exit code 0.
- [ ] Open the LAN build in desktop and 390×844 viewports; inspect grass readability, card fill, hero/enemy/boss style, VFX visibility, and console errors.

## Plan self-review

- Every design requirement maps to Tasks 1–4.
- No gameplay balance or controls are changed.
- Asset IDs stay stable except for the dedicated battlefield ID, which is explicitly covered by tests and the renderer change.
- No placeholders remain.
