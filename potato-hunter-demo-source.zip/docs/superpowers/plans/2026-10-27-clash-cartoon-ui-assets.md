# Stylized Cartoon UI Assets Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver and integrate a complete original stylized-3D cartoon UI asset family for Potato Hunter while keeping all dynamic text and values responsive in Phaser.

**Architecture:** Generated transparent PNG shells and icons are registered through `assets.json`; focused Phaser view classes compose those images with dynamic text and graphics. A single layout function recalculates placements for desktop and portrait mobile whenever Phaser emits a resize event.

**Tech Stack:** Phaser 3.90, TypeScript 5.8, Vite 6, PNG assets, Node.js asset validation.

---

### Task 1: Asset manifest and validation gate

**Files:**
- Create: `scripts/validate-assets.mjs`
- Modify: `package.json`
- Modify: `src/configs/assets.json`

- [ ] Create `scripts/validate-assets.mjs` to parse `src/configs/assets.json`, verify unique ids, confirm every `path` exists below `public/`, and read PNG headers to compare configured and actual width/height.
- [ ] Add `"check:assets": "node scripts/validate-assets.mjs"` to `package.json`.
- [ ] Run `npm run check:assets` and retain the existing eight missing-file failures as the red baseline.
- [ ] Add registry entries for every final v2 asset using stable `ui_v2_*` and `icon_skill_*_v2` ids.
- [ ] Re-run `npm run check:assets`; expected result after generation is `0 missing assets` and `0 dimension mismatches`.

### Task 2: Generate the raster foundation family

**Files:**
- Create: `public/assets/ui/v2/hud/hud-panel.png`
- Create: `public/assets/ui/v2/hud/timer-plaque.png`
- Create: `public/assets/ui/v2/hud/resource-pill.png`
- Create: `public/assets/ui/v2/hud/progress-frame.png`
- Create: `public/assets/ui/v2/hud/boss-bar-frame.png`
- Create: `public/assets/ui/v2/hud/skill-slot.png`
- Create: `public/assets/ui/v2/ribbons/notification-ribbon.png`
- Create: `public/assets/ui/v2/panels/results-panel.png`
- Create: `public/assets/ui/v2/buttons/button-primary.png`
- Create: `public/assets/ui/v2/buttons/button-secondary.png`

- [ ] Generate one transparent-background image per file with a shared art-direction prefix: original Western stylized 3D mobile-game UI, chunky toy-like bevels, royal blue lacquer, warm gold trim, cream highlights, upper-left key light, cool lower shadow, playful potato rivet motifs, no text, no logo, no watermark.
- [ ] Keep center regions visually quiet so Phaser text remains readable.
- [ ] Inspect every image for clean alpha, symmetry, consistent light direction, and recognizable silhouette at target display size.
- [ ] Save accepted outputs under the exact paths above; keep rejected variants outside the project.

### Task 3: Generate the icon family

**Files:**
- Create: `public/assets/ui/v2/icons/heart.png`
- Create: `public/assets/ui/v2/icons/xp-crystal.png`
- Create: `public/assets/ui/v2/icons/coin.png`
- Create: `public/assets/ui/v2/icons/skull.png`
- Create: `public/assets/ui/v2/icons/boss-crown.png`
- Create: `public/assets/ui/v2/icons/clock.png`
- Create: `public/assets/ui/v2/icons/wave.png`
- Create: `public/assets/ui/v2/icons/level-star.png`
- Create: `public/assets/ui/v2/icons/pause.png`
- Create: `public/assets/ui/v2/icons/settings.png`
- Create: `public/assets/icons/skills/peeler_blade-v2.png`
- Create: `public/assets/icons/skills/thunder_chain-v2.png`
- Create: `public/assets/icons/skills/toxic_cloud-v2.png`

- [ ] Generate each icon independently on a transparent background using the same material, lighting, camera, and outline rules as Task 2.
- [ ] Keep UI pictograms centered with at least 12% transparent padding and no embedded text.
- [ ] Make the three skill icons depict an original spinning peeler blade, a potato-powered lightning chain, and a bubbling toxic tomato cloud.
- [ ] Inspect at 32 px and 64 px; reject icons that lose their silhouette.

### Task 4: Generate universal rarity cards and badges

**Files:**
- Create: `public/assets/ui/v2/cards/card-common.png`
- Create: `public/assets/ui/v2/cards/card-rare.png`
- Create: `public/assets/ui/v2/cards/card-epic.png`
- Create: `public/assets/ui/v2/cards/card-evolution.png`
- Create: `public/assets/ui/v2/cards/badge-new.png`
- Create: `public/assets/ui/v2/cards/badge-level-up.png`
- Create: `public/assets/ui/v2/cards/badge-evolution.png`

- [ ] Generate a common card master with the same 320:420 aspect ratio as the existing card art and a quiet center.
- [ ] Generate rare, epic, and evolution variants with identical geometry and progressively stronger blue, purple, and orange-gold accents.
- [ ] Generate three language-neutral badges using symbols rather than baked words.
- [ ] Verify all four frames have consistent interior bounds so one code layout fits every rarity.

### Task 5: Add a reusable UI theme and responsive layout

**Files:**
- Create: `src/ui/UITheme.ts`
- Create: `src/ui/UILayout.ts`
- Create: `src/ui/HUDView.ts`
- Create: `src/ui/BossBarView.ts`
- Create: `src/ui/ResultsPopup.ts`
- Modify: `src/scenes/UIScene.ts`

- [ ] Define asset ids, typography, colors, depths, and display sizes in `UITheme.ts`.
- [ ] Implement `getUILayout(width, height)` with compact portrait and desktop branches; return positions and sizes for timer, bars, counters, skill tray, Boss bar, and overlays.
- [ ] Build `HUDView` from generated shells plus Phaser text and graphics fills; expose `update(payload)` and `layout(layout)`.
- [ ] Build `BossBarView` with the generated frame and dynamic fill; expose `update(boss?)` and `layout(layout)`.
- [ ] Build `ResultsPopup` with the generated panel, stat icons, dynamic values, and generated restart button.
- [ ] Replace raw HUD construction in `UIScene` with the three views.
- [ ] Subscribe to `Phaser.Scale.Events.RESIZE`; call each view's `layout` method and rebuild any active overlay hit targets.
- [ ] Hide entity/FX counters and debug key hints unless `import.meta.env.DEV` is true.

### Task 6: Integrate cards and skill icons

**Files:**
- Modify: `src/ui/UpgradePopup.ts`
- Modify: `src/configs/skills.json`

- [ ] Map rarity and evolution categories to the v2 universal frames while retaining existing fire, ice, and toxic themed art as optional high-priority variants.
- [ ] Replace text-only badge fallbacks with v2 badge images while keeping text fallback behavior for failed loads.
- [ ] Update peeler blade, thunder chain, and toxic cloud to the v2 icon asset ids.
- [ ] Add keyboard selection keys 1, 2, and 3 with the same `selectCard` path used by pointer input.
- [ ] Ensure `destroy()` removes pointer and keyboard listeners before destroying the root container.

### Task 7: Browser validation and final verification

**Files:**
- Modify only if failures are found in Tasks 1-6.

- [ ] Run `npm run check:assets`; expected exit code 0.
- [ ] Run `npm run build`; expected TypeScript and Vite exit code 0.
- [ ] Start Vite and inspect 1280x720: HUD shells, icons, text, upgrade cards, Boss bar, and results panel must be aligned.
- [ ] Inspect 390x844 after a fresh load and after resizing from desktop during an open upgrade popup.
- [ ] Confirm pointer and keyboard card selection still trigger exactly once.
- [ ] Check browser warning/error logs; expected no warnings caused by missing files and no uncaught errors.
- [ ] Render a final contact sheet from the accepted assets and save it as `public/assets/ui/v2/ui-v2-contact-sheet.png` for project review.

## Execution note

The workspace has no Git metadata, so commit steps are replaced with build-and-asset-validation checkpoints. Implementation runs inline in the current session because the user authorized autonomous execution and did not request subagents.
