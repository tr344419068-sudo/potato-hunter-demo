# Combat Variety Implementation Plan

> **For agentic workers:** Use the subagent-driven-development implementation/review workflow. User requested direct execution, so no design/plan approval pauses. One implementation task owns the shared ECS changes to avoid conflicting edits. No Git repository exists.

**Goal:** Add readable Boss patterns, three role enemies, and an attainable attack-speed build without undoing smooth pacing or presentation fixes.

**Architecture:** Dedicated pure combat models drive existing Phaser systems. Boss state is per-entity and serial. Role behavior reuses ECS velocity/warning/shield components. Burst scheduling and hit-based tempo augment the current weapon pipeline with bounded state.

**Tech Stack:** TypeScript, Phaser 3, JSON configs, Node test runner, existing esbuild headless harness. No new dependencies.

## Task 1: Combat expansion (single shared-state implementation)

Files: add focused `BossPatternModel.ts`, `AttackSpeedModel.ts` and/or a role model as needed; update `BossSystem.ts`, `MonsterBehaviorSystem.ts`, `MonsterAISystem.ts`, `AutoAttackSystem.ts`, `AoeWarningSystem.ts`, `ProjectileCollisionSystem.ts`, `RenderSystem.ts`, `ComponentTypes.ts`, factories and corresponding config types. Update skills/builds/evolutions/monster/wave JSON, `GameScene.ts`, `HUDView.ts` and upgrade tag labels. Preserve prior changes.

- [x] Add `scripts/combat-variety.test.mjs` exporting the actual systems through an esbuild entry, with a minimal Phaser EventEmitter/color/shuffle/math double. Construct real `World`/factory/runtime instances. Register it in `test:combat`.
- [x] Watch new assertions fail on the current implementation: stage-one variety; no charge movement before windup; snapshot direction; no phase overlap; two independent bosses; source-death cancellation; guard shield; flanker telegraph; bomber snapshot; summon cap; true burst spacing/retarget; actual-hit tempo and decay; reachable rapid skills/evolution. For pure models, initially assert exported functions exist so missing implementations produce clear assertion failures.
- [x] Implement Boss state and geometry. Example warning contract:

```ts
type WarningShape = { type: 'line'; angle: number; length: number; width: number };
// Optional sourceId cancels hostile casts when the caster is removed/dead.
// Circle warnings remain backwards compatible; line warning damage is zero for charge.
```

Use per-boss map entries, no global cast timers. Snapshot aim at windup. Execute one cast and schedule recovery rather than independently decrementing attack timers. Prune state and sourced warnings when the boss dies. Normal AI cannot overwrite a telegraphed charge. Skip ordinary behavior for bosses.

- [x] Implement new role entries and visual markers with existing PNGs; gradually substitute weights from 24/40/60 s. Do not change wave cadence/count/cap. All summoning observes `wave.maxAlive + difficulty.extraMaxAlive` and a small per-cast count. Do not heal a broken guard shield.
- [x] Implement rapid skill configs and calculators. Example compatibility fields:

```ts
// Optional WeaponConfig additions, with defaults preserving old weapons:
burstCount?: number;
burstIntervalMs?: number;
projectileCountPerTwoLevels?: number;
// Runtime profiles carry those values; rapid weapons use low damage and count-growth zero.
```

Use a finite per-skill scheduler. Fire one burst shot per due interval; no backlog on a missing target or long frame. Tempo state belongs to the run/player and is advanced by update delta. Confirmed projectile hits increase it, not weapon:fired events. Keep legacy cooling and old skill damage unchanged. New gear affects rapid-fire cadence visibly but safely.

- [x] Expose the attack-speed build and evolution; extend HUD and tag translations. Use actual existing icons so no empty cards. Add regressions for readable portrait state and no change to legacy skill profiles without new passives.
- [x] Run `node --test scripts/combat-variety.test.mjs`, then `npm run test:combat`, `npm run test:ui`, `npm run test:assets`, `npm run check:assets`, `npm run build`. Fix failures by their root cause; never loosen old pressure thresholds to hide a regression.
- [x] Self-review implementation and report changed files, exact test counts and concerns. Do not commit.

## Task 2: Independent review gates

- [x] Spec reviewer checks actual code against the design contracts, not implementation claims. Resolve missing requirements first.
- [x] Quality reviewer checks lifecycle, collision geometry, pacing, bounded queues/particles, stale targets, restart state and test fidelity. Resolve important issues and re-review.

## Task 3: User-facing QA and handoff

- [x] Test the live app on desktop and 390×844 through the supported UI API; inspect at least one Boss cast and an attack-speed skill. Also check previous dash/pickup/feet fixes. Capture fresh screenshots.
- [x] Inspect console, restore viewport, preserve playable tab, verify HTTP 200. Update both presentation and current plan evidence honestly, distinguishing automated coverage from visible checks.
- [x] Deliver a concise Chinese summary, quick build recipe, playable link, screenshot, and any remaining limitation (role art is reused with distinct cues, not fresh image generation).

## Final verification and review — 2026-11-17

Fresh primary-agent verification after the last source fix: focused combat-variety tests27/27; `npm run test:combat`118/118; `npm run test:ui`11/11; `npm run test:assets`2/2; `npm run check:assets`69 registered assets,0 missing and0 dimension mismatches; `npm run build`exit0. Vite retains its existing large-bundle warning (JS1,667.04kB, gzip393.28kB). HTTP HEAD to `http://localhost:5173/` returned200. No Git operations, dependencies, publishing or generated enemy images.

Spec review independently passed after test-first fixes to the bombardier's520-unit cast range, padded boss/flanker contact-warning envelope, and portrait status-row layout. Quality review found no critical/important issue. Its minor HUD mismatch was reproduced by an actual `GameScene.emitHud`/EventBus test: +40% permanent and +24% tempo emitted+64% instead of+73.6%. The display now compounds exactly like the production weapon pipeline; that regression was observed red then green, and scoped independent re-review passed27/27. Cooldown floors and temporary buffs can still alter weapon-specific effective rates. The review's optional composed actual-order40ms-clamped-frame test remains coverage hardening, not implemented or claimed here.

GUI checks used the supported CUA UI API at1280×720 and390×844: selected rapid-fire/burst/engine/gear upgrades, observed rapid attacks and Boss fan windup, bomber snapshot warning, role ornaments, frost/peeler impacts, image-backed upgrade cards and pickups, dash click/cooldown and grounded feet. Portrait tempo visibly advanced3→8stacks with +3%→+8% nominal speed, and status text no longer overlaps counters. Console error/warn query returned an empty array. Viewport was reset, tab reloaded, and GUI completion recorded. This is finite visual QA, not a complete manual traversal of all Boss phases or a long-run difficulty playtest; automated tests cover all five patterns. No difficulty changes were inferred from deaths during stationary tool use.

Fresh screenshot evidence: `artifacts/qa/combat-variety-desktop-battle.jpg`, `combat-variety-portrait-battle.jpg`, `combat-variety-desktop-skills.jpg`, and `combat-variety-portrait-skills.jpg`. The last source fix only corrects nominal HUD arithmetic; it does not change layout, art, or combat values. Existing food PNGs supply the new role sprites, with distinct markers/tints rather than newly generated pictures.
