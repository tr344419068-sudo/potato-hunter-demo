# Readable Card UI and Stable View Implementation Plan

> **For agentic workers:** Use superpowers:dispatching-parallel-agents for these two independent file domains. Implement test-first, then root reviews integration and visual evidence.

**Goal:** Refine upgrade-card artwork and Chinese text while stopping whole-screen flash/shake interruptions.

**Architecture:** Reuse registered card artwork and clear font tokens inside the existing popup; retain its automatic-upgrade and input ownership. Remove camera-only feedback calls from combat systems without altering gameplay or local particle layers.

**Tech Stack:** TypeScript, Phaser, existing PNG art, Node/esbuild runtime tests.

No Git repository; no worktrees, commits, installs, publishing or deletion of earlier art. User requested direct execution. Two agents have disjoint file ownership.

### Task 1: Card artwork and readable UI type

**Owned files:** `src/ui/UpgradePopup.ts`, `src/ui/UITheme.ts`, `src/ui/UIFontLoader.ts`, `src/styles.css`; relevant `scripts/upgrade-card-art.test.mjs`, `scripts/upgrade-layout-runtime.test.mjs`, `scripts/ui-font-loading.test.mjs`, and minimal display-fixture extensions in `scripts/ui-runtime-helpers.mjs`. A focused `src/ui/UpgradeCardArt.ts` helper/new UI-only tests may be added if needed. No combat-system files.

- [x] Add failing runtime assertions for registered card-frame use, standard non-ZCOOL font selection/loading, frame-safe text/icon bounds, readable benefit/level contrast, compact adaptation and missing-texture fallback. Preserve existing automatic chooser/held-input/pointer/lifecycle tests.

```js
assert.ok(objects.some(object => object.texture === 'asset:ui_v2_card_rare'));
assert.ok(!UI_FONT.includes('ZCOOL'));
assert.ok(name.getBounds().x >= -card.width / 2 + safeInset);
assert.ok(levelText.text.includes('→'));
```

- [x] Run the relevant tests to confirm expected RED before production edits.
- [x] Compose the existing dimensional bitmap frame over a graded material surface and a light readable information area. Keep text inset from rails/gems; use coherent compact framing and large icons. Use a constant lighter backdrop, no pulsing. Ensure fallback stays opaque.
- [x] Switch UI_FONT/body and loader/CSS away from the art font. Preserve bounded startup fallback; don't download a new font or delete old font assets/licenses.
- [x] Run UI/focused tests and TypeScript to GREEN, inspect the diff, self-review and return evidence for root visual QA. Root may request art refinements from actual screenshots.

### Task 2: Remove whole-camera interference

**Owned files:** `src/systems/ProjectileCollisionSystem.ts`, `ElementalReactionSystem.ts`, `DeathSystem.ts`, `AoeWarningSystem.ts`, `MonsterBehaviorSystem.ts`, `ChapterDirectorSystem.ts`, `CombatVfxSystem.ts`; focused new `scripts/stable-camera-feedback.test.mjs` and required existing combat-only assertions. Do not edit UI files/helper/package.

- [x] Reproduce ordinary kill/critical/explosion/chapter camera calls with actual runtime tests and expect zero shakes/flashes after the change. Include heavy/hostile/dash paths and ensure local effects/damage still emit.

```js
assert.equal(camera.shakes, 0);
assert.equal(camera.flashes, 0);
assert.ok(localEvents.length > 0);
```

- [x] Run RED before implementation. Investigate any non-camera brightness evidence before changing local VFX; no speculative blanket removal of light textures.
- [x] Remove camera.shake/flash call sites and camera-only unused throttling branches. Preserve damage/crit/XP/spawn/chapter state and all localized feedback event paths.
- [x] Run focused/combat tests and TypeScript to GREEN; inspect source for remaining camera effects and report exact changes/root cause. No new global options or camera service.

### Root integration and handoff

- [x] Register any new dedicated tests in package.json once agent changes are complete.
- [x] Review actual diffs against the snapshots; request independent UI and camera code reviews.
- [x] Run `npm run test:ui`, `npm run test:combat`, `npm run test:assets`, `npm run check:assets`, `npm run build`; verify protected configuration/XP fingerprints.
- [x] Render the real popup at desktop and compact sizes using an actual-module preview, inspect frame/material/text/icon composition, refine until readable and coherent. Verify automatic popup/select/resume in an isolated game tab. Capture and display real screenshots; don't claim preview screenshots are gameplay.
- [x] Record results and hand off without controlling the user's shared live tab or changing difficulty tuning.

## Execution record

Design and plan self-reviewed. UI and camera domains were implemented in disjoint domains without an approval pause under the user's delegation.

### Implementation and visual refinements

- UI initial focused RED: 8 passed / 7 failed; authored-copy/refinement RED: 15 passed / 4 failed; narrow-desktop boundary RED: 11 passed / 2 failed. Final focused GREEN: 19 passed.
- Existing bitmap rarity frames now surround graded icon material and an ivory information plate. UI typography uses conventional Chinese sans-serif, with no packaged art-font loading. The old font and license remain on disk.
- First actual desktop preview revealed crowded benefits and a stranded final character. Root requested 312–320px portrait cards, more benefit space, positive row gaps, and larger mid-screen type. Subsequent 800×600/900×650 checks identified insufficient portrait width; those dimensions now use adapted horizontal cards. Future unusually long copy is bounded at a readable font minimum.
- Camera RED: 27 failed specifically on existing shake/flash behavior; GREEN: 27 passed. Removed 12 shake call sites and one chapter flash, including the now-unused projectile camera-only cooldown. All localized particles and gameplay feedback remain.
- Camera independent review approved with no findings; it additionally reran the new cases against the old snapshot in memory and confirmed all 27 detect the former camera interference.
- UI independent review approved the target WebGL workflow and swept 266 viewport combinations without collisions, off-screen card bottoms, slice-clamping or growing live-object counts. Its minor Canvas-renderer finding was confirmed in installed Phaser source and fixed with a renderer-aware fallback to the existing visible Graphics frame. Desktop Canvas still uses bitmap art; accepted WebGL/unknown-renderer composition is unchanged. Fallback TDD: 5 passed / 1 expected failure, then 6 passed / 0 failed. Reviewer follow-up approved with 25 focused input/layout/font/art checks passing.

### Root verification

- `npm run test:ui`: 58 passed, zero failed, including the final Canvas fallback.
- `npm run test:combat`: 193 passed, zero failed.
- `npm run test:assets`: 2 passed, zero failed.
- `npm run check:assets`: 84 assets, zero missing files or dimension mismatches.
- `npm run build`: TypeScript and production build passed; existing large-bundle warning remains.
- The waves, difficulty, monsters, skills and PacingModel SHA-256 values match the protected baseline; no difficulty/XP tuning changes.

Actual-module layout preview: `artifacts/qa/readable-upgrade-preview.html`. Root visually checked 1280×720, 722×794, 390×844 and 320×480 using existing PNGs and actual Phaser rendering. Final evidence is `readable-upgrade-desktop.jpg`, `readable-upgrade-mid.jpg`, `readable-upgrade-phone.jpg`, `readable-upgrade-small.jpg` under `artifacts/qa/`; these are explicitly layout previews, not gameplay.

Natural isolated gameplay verification used only ordinary movement and pointer selection, with no U/HUD/debug shortcut: XP opened the new Lv2 chooser at 00:09; selecting produced the new skill and resumed the clock, followed by earned Lv3/Lv4 choices at 00:11/00:16. A final immediate capture at 00:16 shows no chooser, peeler Lv2 and newly acquired skills with a localized aura still active. Evidence: `artifacts/qa/readable-upgrade-in-game.jpg` and `readable-upgrade-resumed.jpg`. The user's existing tab was not controlled. No viewport override was set. GUI verification was completed through its completion summary.

No AI-generation claim: this pass reuses shipped bitmap art and code-native surface composition. No claim of exhaustive balance, performance/FPS or long-session testing; those are outside this visual/camera correction.

Final post-follow-up root verification reran all five package commands successfully and rechecked all protected fingerprints. Known non-blocking limitation: headless glyph measurements approximate real font metrics; actual WebGL browser screenshots complement them for this release. The Canvas fallback branch has runtime coverage and source-level reviewer verification, but was not visually exercised in a forced-Canvas browser. All implementation, review and targeted verification work is complete.
