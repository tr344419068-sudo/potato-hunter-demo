# Textured combat VFX implementation plan

> **For agentic workers:** Use superpowers:subagent-driven-development with one fresh implementation agent for this cohesive emitter/art-import task, then independent spec and quality reviews. Steps use checkbox syntax.

**Goal:** Ship licensed light and spell artwork in actual hero combat, with visible texture animation and bounded layered impact.

**Architecture:** Curated RGBA masks and 8-frame strips are preloaded by AssetManager and selected through a small texture-profile module inside the existing pooled emitter. Keep graphics fallback and all gameplay untouched.

**Tech Stack:** TypeScript, Phaser 3, Python/Pillow import, Node test runner/esbuild.

No Git repository exists. No branches, commits, worktree creation, publishing or dependency installation; preserve all unrelated files.

### Task 1: Curated art import and bounded runtime integration

**Files:**
- Create: `scripts/import-combat-vfx.py`, `scripts/textured-combat-vfx.test.mjs`, `src/systems/CombatVfxTextures.ts`, `public/assets/vfx/` PNGs, original license and sources manifest.
- Modify: `src/configs/assets.json`, `src/managers/ConfigManager.ts`, `src/managers/AssetManager.ts`, `src/systems/CombatParticleEmitter.ts`, `package.json` test list.
- Existing context: `scripts/combat-particles-runtime.test.mjs` has a headless Phaser fixture and actual lifecycle regression; reuse it or extend its texture/frame stubs minimally. `scripts/validate-assets.mjs` validates registered PNG sizes.

- [x] Add tests before production code. Asset tests enumerate selected VFX assets and assert RGBA alpha corners, nonempty silhouette, strip dimensions, distinct temporal frames and recorded CC0 provenance. Runtime tests load the real emitter via esbuild and pre-populate loaded texture keys, then emit normal/critical/reaction events for every family and inspect actual display image state. Examples:

```js
assert.ok(images.some(image => image.texture.startsWith('asset:vfx_')));
emitter.update(90);
assert.notEqual(animatedImage.frame, initialFrame);
assert.equal(smokeImage.blendMode, Phaser.BlendModes.NORMAL);
emitter.update(1500);
assert.equal(emitter.activeCount, 0);
emitter.destroy();
assert.ok(textures.exists('asset:vfx_smoke'));
```

Use existing fixture conventions for frame objects; assertions must observe production behavior, not merely configuration text. Existing generated-fallback tests must still run when imported keys are absent.

- [x] Run `node --test scripts/textured-combat-vfx.test.mjs scripts/combat-particles-runtime.test.mjs` and record expected RED (missing registered/imported artwork or loaded runtime textures), not a syntax error.
- [x] Implement the deterministic import. Read PNGs by explicit archive entry; normalize grayscale masks and common-scale centered frame strips; eight samples include the full sequence's opening and fade. Output 192px static tiles and 1536×192 sheets. Preserve original notice and SHA-256 provenance, do not ship full archives.
- [x] Implement type/loader metadata and texture profiles. The spritesheet loader uses:

```ts
scene.load.spritesheet(textureKey, asset.path, {
  frameWidth: asset.frameWidth,
  frameHeight: asset.frameHeight,
  endFrame: asset.frameCount - 1,
});
```

Require all three metadata values before taking this branch; ordinary images keep `scene.load.image`.
- [x] Integrate profile selection into existing pooled particles. Imported light/slash/trail/debris/strip/ring/smoke choices count against existing caps; loaded assets are non-owned and never removed by an emitter. Reset reused frame/blend/tint/transform and use finite one-shot frame timing. Smoke and rings have expanding motion; fragment/trail shapes remain directional.
- [x] Run focused tests to GREEN; record exact command/results and self-review. Independent spec reviewer reads production/importer/tests and verifies every requirement. Resolve issues, re-review, then independent code-quality reviewer checks frame/pool/lifecycle correctness.

### Final verification and visual handoff

- [x] Run `npm run test:combat`, `npm run test:ui`, `npm run test:assets`, `npm run check:assets`, `npm run build`.
- [x] Compare SHA-256 of protected gameplay files to the spec fingerprints.
- [x] Extend the existing actual-module VFX QA preview with loaded PNG masks/strips. Capture desktop and compact effects through browser UI, and a bounded animation if practical. Verify actual game startup and a natural hero attack, save screenshots.
- [x] Record review and test evidence here and keep the localhost game available at a safe intentional chooser or fresh restart for the user.

## Execution record

- Sources: Kenney's Particle Pack author upload and Mikodrak's 2D Spell Effects on OpenGameArt. Both source notices were checked as CC0; archives passed CRC and recorded SHA-256. This is sourced artwork, not AI-generated artwork.
- Importer outputs 15 transparent RGBA PNGs (10 static masks and five eight-frame strips), totaling 482,304 PNG bytes. Independent spec review regenerated byte-identical outputs and checked provenance, distinct frames and alpha. Full source archives remain QA inputs only, outside `public/`.
- Implementer RED: focused runtime/art tests reported 16 passing and 11 expected failures. GREEN: 28/28; with presentation polish, 39/39. A legacy fixture boundary discovered in the full suite was reproduced by an additional test and repaired.
- Root fresh verification after the final robustness fix: combat 166/166; UI 39/39; assets 2/2; registered assets 84, zero missing or dimension mismatches; TypeScript and Vite production build passed. The existing Vite large-chunk warning remains.
- All five protected gameplay SHA-256 fingerprints match the design document. No difficulty, spawning, XP, damage or cooldown changes in this pass.
- Independent spec review: compliant, no required fixes. Independent code-quality review: approved; one P3 robustness finding was repaired and re-reviewed as approved. The resolver now rejects partially specified or invalid strip metadata rather than squeezing a whole strip into one frame. RED resolver tests: one pass and nine expected failures; GREEN: 10/10. Final focused regression: 38/38, independently repeated by the reviewer with TypeScript passing. Static-image acceptance and loader fallback remain unchanged.
- Browser visual QA: actual emitter plus loaded assets, six labelled families; desktop 1280×720 (96 active particles) and compact 390×844 (86 active particles), both below their limits. Sixteen captured frames span 0–750ms; particles expire to zero. Frame strips advance visibly, lights blend additively, dark smoke retains transparency, and no black rectangles were observed.
- Evidence: `artifacts/qa/textured-vfx-desktop.jpg`, `textured-vfx-compact.jpg`, and `textured-vfx-animation.gif`. The GIF assembles actual captured browser frames and plays at half runtime speed; it is a module preview, not an actual combat recording.
- Actual game smoke test: fresh load/restart, normal WASD movement and basic attack, naturally earned lightning selection, then Lv3 upgrade chooser; saved `textured-vfx-restart-attack.jpg` and `textured-vfx-game-handoff.jpg`. After the final code change triggered a development reload, restarted again using the real result-screen button and stopped at a naturally earned Lv2 chooser at 00:08, with 90/100 HP. Temporary viewport override was reset, QA-only tab closed, game tab retained.
- Scope limits: this is not a new character-animation pass, a full-device performance profile, or a balance evaluation. Natural gameplay verified startup/event integration; the controlled module preview verified all six material families. `textured-vfx-live-lightning.jpg` captured a later defeat overlay and is not used as attack evidence.
