# Simple Notification Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans for inline execution. User requested direct work without design approval pauses; this folder is not a Git repository. No worktree, commit, new dependencies, image generation or unrelated delegation.

**Goal:** Replace crowded crowned notifications with readable reference-aligned dark strips.

**Architecture:** `NotificationModel.ts` fits measured text within bounded lines. Existing `UIScene` owns Graphics/Text and notification lifecycle. `UILayout` reserves a smaller notification region below the Boss bar.

**Tech Stack:** TypeScript, Phaser3 Graphics/Text, esbuild and Node test runner.

### Task1: Test-first banner replacement

Files: create `src/ui/NotificationModel.ts` and `scripts/notification-presentation.test.mjs`; modify `src/scenes/UIScene.ts`, `src/ui/UILayout.ts`, `package.json`.

- [x] Add actual UIScene tests: no image/crown/frame strokes; cream bold text with dark outline; bounded strip and text width at320/390/1280; complete authored messages; resize reflows original text; stale completion cannot destroy the replacement. Add pure measured text wrapping/overflow tests. Run `node --test scripts/notification-presentation.test.mjs` and observe the intended failures.
- [x] Implement `fitNotificationText(message, maxWidth, baseFontSize, minimumFontSize, measureWidth)` returning bounded text/font/lineCount. Wrap Unicode code points using `(text,fontSize)=>width`, preserve explicit newlines, prefer larger readable fonts and cap unexpected future overflow at3lines with ellipsis.
- [x] Replace the ribbon Image/fallback frame with dark Graphics, fading ends and fitted centered text. Draw height from actual text bounds plus20px padding. Start container atalpha0/y−6 and tween toalpha1/y0 over140ms usingSine.easeOut with existing hold/yoyo semantics. Keep generation-safe completion and kill obsolete container tweens on destroy.
- [x] Set notification width to`Math.min(width-24,420)` compact /`Math.min(width-48,560)` desktop; height104/112 andtop`boss.y+boss.height/2+8`. Register focused tests in`test:ui` and rerun focused tests.

### Task2: Verify and handoff

- [x] Run `npm run test:ui`, `npm run test:combat`, `npm run check:assets`, `npm run build`; inspect output and self-review scope/lifecycle/geometry. No commit or publishing.
- [x] Inspect live desktop and390×844 through supported CUA UI APIs, including a real Boss/chapter notification. Save fresh evidence, inspect console, reset viewport and preserve playable tab. Use no hidden runtime manipulation.
- [x] Record exact verification and deliver a concise Chinese summary and screenshot.

## Verification evidence —2026-11-17

The five new tests initially failed for the exact requested gaps: ribbon Image still created,168px reserved desktop plaque, Chinese text did not wrap on resize, obsolete tween not killed, measured-fitting helper missing. After implementation, the narrowest320px ring warning exposed an unnecessarily tall two-line notice; a focused one-line-preference assertion also failed before its fix. All five focused tests then passed. Self-review kept the cached canvas measurement font synchronized with the final displayed font.

Fresh final commands: UI16/16; combat118/118; registered assets69 with0 missing and0 dimension mismatches; TypeScript/Vite buildexit0. Existing large-bundle warning remains (JS1,667.91kB, gzip393.77kB); no added dependencies. HTTP HEAD tolocalhost5173returned200. Environment check confirms no Git repository, so no branch/worktree/commit/PR/cleanup workflow applies.

GUI QA used only supported CUA UI APIs, screenshots and actual upgrade/debug-key inputs. Desktop1280×720 visibly showed the new Boss fan strip and a complete Boss-arrival label; portrait390×844 showed the complete oil-fan label on one line with clear side padding below the Boss bar. After viewport reset, the fresh run showed the chapter title/instruction on two clean lines. Browser error/warn log query returned[]. Temporary viewport override was reset, page reloaded to a normal fresh run, tab marked deliverable and CUA completion recorded.

Valid saved evidence: `artifacts/qa/simple-notification-desktop.jpg` (Boss arrival) and `artifacts/qa/simple-notification-portrait.jpg` (oil fan). `simple-notification-desktop-cast.jpg` caught an intervening upgrade popup and is not used as proof. No complete manual walkthrough of every future notification or language is claimed; actual-system tests cover all currently authored Boss/chapter strings at320/390/1280widths.

Changes are limited to `NotificationModel.ts`, `UIScene.ts`, `UILayout.ts`, the focused test and test:ui registration, plus these docs. Existing ribbon bitmap remains on disk/registered for compatibility but is no longer drawn by notifications. Gameplay, other popup art and Boss-bar art are unchanged.
