# Battlefield Chapters Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a visually staged, formation-driven first-minute level with elite set pieces and early movement objectives.

**Architecture:** A pure chapter model defines timing, palettes, spawn formations, and deterministic decoration specs. Thin Phaser systems consume it for spawns, set dressing, elite captains, and UI presentation without coupling presentation to ECS mutation.

**Tech Stack:** TypeScript, Phaser 3, ECS maps, Node test runner, Vite.

---

### Task 1: Chapter and decoration model

**Files:**
- Create: `src/managers/LevelChapterModel.ts`
- Create: `scripts/level-chapter-model.test.mjs`

- [ ] Add failing tests that expect chapters at 0, 10, 24, 40, and 60 seconds; distinct formation IDs; bounded spawn angles; and deterministic sparse decorations.
- [ ] Run `node --test scripts/level-chapter-model.test.mjs` and confirm failure because the model does not exist.
- [ ] Implement immutable `LEVEL_CHAPTERS`, `getLevelChapter`, `getSpawnAngle`, and `getBattlefieldDecoration` exports.
- [ ] Re-run the focused test and confirm every model assertion passes.

### Task 2: Chapter director and formation-aware spawning

**Files:**
- Create: `src/systems/ChapterDirectorSystem.ts`
- Modify: `src/systems/SpawnSystem.ts`
- Modify: `src/scenes/GameScene.ts`
- Test: `scripts/level-chapter-model.test.mjs`

- [ ] Add failing wiring assertions for `level:chapter`, `getSpawnAngle`, and `ChapterDirectorSystem` registration.
- [ ] Implement one-shot chapter events and guaranteed elite captains at the 24- and 40-second transitions.
- [ ] Use chapter formation angles in regular spawn positioning while preserving distance jitter and max-alive limits.
- [ ] Run the focused test and TypeScript build.

### Task 3: Layered battlefield art

**Files:**
- Modify: `src/systems/BattlefieldBackground.ts`
- Modify: `src/scenes/GameScene.ts`
- Test: `scripts/battlefield-background.test.mjs`

- [ ] Add failing assertions for a batched decoration graphics layer, chapter tint, deterministic decoration consumption, and boss-arena rendering.
- [ ] Draw sparse grass, stones, sauce marks, crate debris, bottle shards, and scorch props behind gameplay entities.
- [ ] Tint the tile and screen overlay per chapter and draw the amber siege arena from 60 seconds onward.
- [ ] Run background tests and build.

### Task 4: Enemy and objective readability

**Files:**
- Modify: `src/systems/RenderSystem.ts`
- Modify: `src/configs/mapEvents.json`
- Modify: `src/configs/waves.json`
- Test: `scripts/pacing-model.test.mjs`
- Test: `scripts/projectile-presentation.test.mjs`

- [ ] Add failing assertions for first-minute wave timings, early map objectives, elite-affix telegraphs, and custom map-event drawing.
- [ ] Draw shield rings, haste chevrons, split sigils, death-bomb warnings, and boss grounding without obscuring sprites.
- [ ] Replace generic event squares with supply chest, heal, magnet, haste, and experience silhouettes.
- [ ] Update first-minute waves and event timings; re-run focused tests.

### Task 5: Chapter and boss-phase presentation

**Files:**
- Modify: `src/scenes/UIScene.ts`
- Test: `scripts/ui-overlay-controller.test.mjs`

- [ ] Add failing source assertions for `level:chapter` and `boss:phase` listeners with shutdown cleanup.
- [ ] Present chapter title/subtitle through the existing notification ribbon and surface boss phase callouts that were previously emitted but not displayed.
- [ ] Verify desktop and portrait banner placement manually.

### Task 6: Full verification

- [ ] Run `npm run test:combat` with zero failures.
- [ ] Run `npm run test:ui` with zero failures.
- [ ] Run `npm run check:assets` with zero missing or mismatched assets.
- [ ] Run `npm run build` successfully.
- [ ] Play desktop and 390×844 portrait through chapter transitions and confirm no console error or warning.

