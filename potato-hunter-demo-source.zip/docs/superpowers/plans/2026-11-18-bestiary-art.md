# Bestiary and Campaign Art Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development. Execute continuously under the user's autonomous authorization; no style or plan approval gate. Steps use checkbox syntax.

**Goal:** Generate eleven original bitmap assets on the user's authenticated 神工 website and ship a readable camp bestiary plus opening/victory/retry illustrations.

**Architecture:** Root owns website generation, alpha extraction, provenance, versioned image import and monster art mappings. One implementation worker owns a focused bestiary model and CampaignShell/styles integration, with independent spec then quality review. The bestiary is camp-only and never changes gameplay stats, storage, wave timing, rewards or upgrade lifecycle.

**Tech Stack:** TypeScript, Phaser, DOM UI, CSS, Node test runner/linkedom, existing PNG processing tools, authenticated website UI.

Workspace is not a Git repository (verified 2026-11-18); no worktree, commit or branch operation applies. Existing files and previous art are retained.

## Task 1 — Actual generated assets (root)

Files: create `public/assets/bestiary/v3/{delivery_box,drone_summoner,shield_guard,fries_cultist,ketchup_slug,cola_spitter,onion_flanker,corn_bombardier}.png`, `public/assets/ui/campaign-v3/{camp,victory,retry}.png`, and `artifacts/generated-2026-11-18/provenance.json` with original downloads.

- [x] Submit each independent prompt from `docs/superpowers/specs/2026-11-18-bestiary-art-intake.md` through the actual prompt editor. Use its current model GPT-Image-2.5-Sunburst, 1:1, two candidates. Preserve original hero identity and existing food types.
- [x] Inspect each candidate and choose coherent proportions and readable silhouette. Use website RemBg when the generated PNG is RGB or includes a painted checkerboard. Inspect real alpha and retained eyes/feet.
- [x] Export only observed result images using pageAssets inventory/bundle or the exact observed media element download. Record prompt, model, source URL, selected original, cutout output and processing. RemBg images absent from inventory were downloaded through their observed image elements.
- [x] Normalize selected real-alpha images to a padded square: PNG RGBA, max 512px for bestiary and 768px for campaign scenes. Keep original files and do not overwrite prior v2 art.
- [x] Register `enemy_delivery_box_v3`, `enemy_drone_summoner_v3`, `enemy_shield_guard_v3` in `src/configs/assets.json` and update only the three corresponding `assetId` fields in `src/configs/monsters.json`. Do not alter numeric fields.

## Task 2 — Camp bestiary and illustration integration (one worker)

Files: create `src/ui/BestiaryModel.ts`, `scripts/bestiary.test.mjs`; modify `src/ui/CampaignShell.ts`, `src/styles.css`, `scripts/campaign-shell.test.mjs`, package test command.

- [x] Write failing model tests for exact eight monster IDs, stable ordering, names derived from current config, per-monster identity images `/assets/bestiary/v3/${id}.png`, and meaningful role/attack/counterplay text. Run `node --test scripts/bestiary.test.mjs`; expect failure before implementation.
- [x] Implement typed immutable model entries derived from `monsters.json`. Keep behavior copy factual: rush delivery_box; shield shield_guard; flank onion_flanker; ranged cola_spitter; bombard corn_bombardier; summon drone_summoner; ordinary melee fries_cultist; close explosive ketchup_slug. Check current AI configuration for precision.
- [x] Write failing shell tests: camp entry opens eight-card bestiary, close/Escape return to camp, opening is rejected during active run, no campaign:start/pause emitted by opening, results use distinct victory/retry images, normal settings and Tab focus lifecycle unaffected.
- [x] Implement camp action `bestiary`, close action `close-bestiary`, a `bestiaryOpen` flag reset on lifecycle/render changes, `renderBestiary()` and Escape handling. Cards have normal readable Chinese text, role tag, large portrait, attack/counterplay descriptions; no interactive selection requiring battle pause.
- [x] Add `/assets/ui/campaign-v3/camp.png` only inside the home illustration region and victory/retry inside a dedicated result illustration region. Use decorative `alt=""` for scenes and meaningful names for portraits. Text and buttons must remain separate; images cannot intercept inputs. Remove the duplicate old hero from camp; contain the entire sole scene on both axes.
- [x] CSS: blue/cream/restrained gold toy-like aesthetic matching current game; current readable Chinese font kept; card grid 4/2/1 columns as space permits; bounded scroll dialog; focus-visible; reduced motion; mobile home/result height limits keep actions reachable. No full-screen flashes/shake.
- [x] Run `node --test scripts/bestiary.test.mjs scripts/campaign-shell.test.mjs`; all 19 pass after final composition polish. Add bestiary test to test:campaign. Run `npm run build`; TypeScript clean.

## Task 3 — Independent review and release evidence

- [x] Spec reviewer checks all Task 2 requirements against actual code/tests (not implementer claims). Final composition followup also compliant.
- [x] Quality reviewer after spec acceptance checks state transitions, injection escape, focus/keyboard, responsive layout and test reliability. No blocking issues; exact changed-ID regression assertion added after minor advisory.
- [x] Root runs fresh `npm run test:release` saving output to `artifacts/generated-2026-11-18/release-verification.log`; no failures and no missing image files.
- [x] Test real local browser desktop and portrait: camp art, open/close bestiary, keyboard focus, settings, starting a run, automatic chooser and real retry result. Inspect screenshots and browser errors; no hidden engine-state manipulation. Tested 1280×720, 390×844, 375×667. Victory branch/asset verified by runtime tests, not a full victorious playthrough.
- [x] Final independent review of full asset/config/UI implementation. Keep only verified selected assets in game; retain truthful provenance and actual screenshots. See `docs/superpowers/reviews/2026-11-18-bestiary-art-delivery.md` for evidence and limits.
