# Combat Depth and Juice Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add four elemental reactions and an active invulnerable dash with full combat/UI/VFX feedback.

**Architecture:** Pure models own balance and are tested without Phaser. Thin runtime adapters mutate ECS state and emit presentation events. Existing collision, aura, HUD, and VFX systems consume those interfaces without broad refactoring.

**Tech Stack:** TypeScript, Phaser 3, ECS maps, Node test runner, Vite.

---

### Task 1: Elemental reaction rules

**Files:**
- Create: `src/systems/ElementalReactionModel.ts`
- Test: `scripts/elemental-reaction-model.test.mjs`

- [x] Write tests for the four exact status/element pairings, consumed statuses, bounded splash, and unmatched inputs.
- [x] Run `node --test scripts/elemental-reaction-model.test.mjs` and confirm the missing export failure.
- [x] Implement `resolveElementalReaction(incomingKind, statuses)` with immutable reaction profiles.
- [x] Re-run the focused test and confirm all cases pass.

### Task 2: Reaction runtime and presentation

**Files:**
- Create: `src/systems/ElementalReactionSystem.ts`
- Modify: `src/systems/ProjectileCollisionSystem.ts`
- Modify: `src/systems/AuraSystem.ts`
- Modify: `src/systems/CombatVfxSystem.ts`
- Test: `scripts/elemental-reaction-model.test.mjs`

- [x] Add failing source-wiring assertions for projectile, aura, and VFX reaction events.
- [x] Run the focused test and confirm the wiring assertions fail.
- [x] Apply target bonus, capped splash, knockback, status consumption, camera feedback, and `combat:reaction` emission.
- [x] Render dual-color local-space rings, a reaction label, and pooled burst particles.
- [x] Re-run focused tests and `npm run build`.

### Task 3: Dash state and input

**Files:**
- Create: `src/systems/DashModel.ts`
- Modify: `src/components/ComponentTypes.ts`
- Modify: `src/entities/factories.ts`
- Modify: `src/systems/InputSystem.ts`
- Modify: `src/systems/MonsterContactSystem.ts`
- Modify: `src/systems/EnemyProjectileSystem.ts`
- Test: `scripts/dash-model.test.mjs`

- [x] Add failing tests for duration, cooldown, speed, direction fallback, and cooldown ratio.
- [x] Implement the pure dash model and run the focused tests green.
- [x] Add player dash state, Space/request handling, dash velocity, and damage-path invulnerability.
- [x] Add source-wiring assertions and re-run the focused tests.

### Task 4: Dash HUD and VFX

**Files:**
- Modify: `src/ui/UILayout.ts`
- Modify: `src/ui/HUDView.ts`
- Modify: `src/scenes/GameScene.ts`
- Modify: `src/systems/CombatVfxSystem.ts`
- Test: `scripts/ui-layout.test.mjs`
- Test: `scripts/dash-model.test.mjs`

- [x] Add failing assertions for a portrait-safe dash control and HUD payload cooldown state.
- [x] Add a rounded dash control that emits `player:dash-request` and shows cooldown progress.
- [x] Emit `hero:dash` and render a ring, streaks, camera kick, and three hero afterimages.
- [x] Run focused UI/dash tests and build.

### Task 5: Full verification

- [x] Run `npm run test:combat` and confirm zero failures.
- [x] Run `npm run test:ui` and confirm zero failures.
- [x] Run `npm run check:assets` and confirm zero missing or mismatched assets.
- [x] Run `npm run build` and confirm successful TypeScript/Vite output.
- [x] Play desktop and 390×844 portrait, verify reaction/dash presentation paths, and confirm no console errors.
