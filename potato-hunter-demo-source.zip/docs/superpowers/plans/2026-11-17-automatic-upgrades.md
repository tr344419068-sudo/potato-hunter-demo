# Automatic Upgrades Implementation Plan

> **For agentic workers:** Use superpowers:subagent-driven-development for one cohesive implementation task, followed by spec and quality review. Steps use checkbox syntax.

**Goal:** Automatically show the existing paused three-choice popup whenever XP earns an upgrade.

**Architecture:** Keep credit/session/overlay ownership in GameScene. Record and auto-open on earning; apply the chosen upgrade before automatically opening remaining credits. Preserve explicit postponement and guard repeated input.

**Tech Stack:** TypeScript, Phaser 3, esbuild and Node runtime tests.

No Git repository: no commits, branches, worktrees, installs or publishing. Preserve all unrelated edits. Execute directly under the user's delegation.

### Task 1: Automatic queue, input guards and runtime tests

**Files:**
- Modify `src/scenes/GameScene.ts` (earning/selection transitions only).
- Modify `src/ui/UpgradePopup.ts` (ignore repeated numeric-key events).
- Modify `scripts/manual-upgrades.test.mjs` (keep filename for package compatibility; update behavior tests).
- Modify `scripts/upgrade-pointer-gesture.test.mjs` (subscribe before earning in its fixture).
- Add or extend runtime cases in `scripts/upgrade-layout-runtime.test.mjs` if needed for held-key behavior.

- [x] Write failing tests before production edits. On an actual scene system requesting two choices, assert one visible popup, two credits, later combat-system updates skipped, and future elapsed time frozen. Observe `level:choices` before calling requestSkillChoice.

```js
scene.requestSkillChoice([]);
assert.equal(scene.choosingSkill, true);
assert.equal(popups.length, 1);
scene.requestSkillChoice([]);
const first = popups[0];
scene.handleSkillSelected({ skillId: first.choices[0].id, sessionId: first.sessionId });
assert.equal(scene.pendingUpgrades, 1);
assert.equal(scene.choosingSkill, true);
assert.equal(popups.length, 2);
assert.notEqual(popups[1].sessionId, first.sessionId);
```

- [x] Cover normal single-choice resume, several levels from actual XP collection, optional cancel without repeated reopening, fresh manual reopen, game-over rejection, reward-choice chaining, stale/duplicate selections, restart, pointer dismissal and repeated numeric-key protection. Keep ordinary HUD/starter skill assertions.
- [x] Run `node --test scripts/manual-upgrades.test.mjs scripts/upgrade-pointer-gesture.test.mjs scripts/upgrade-layout-runtime.test.mjs`; record expected behavior failures, not fixture/syntax errors.
- [x] Implement minimal state transitions. In `requestSkillChoice`, call `this.openUpgradeChoices()` after incrementing the credit. In `handleSkillSelected`, remove the early-return reward branch so all successful selections reach `this.openUpgradeChoices()` after reward/skill application. Keep game-over, session, offered-ID and empty-choice guards, and existing optional cancel behavior.
- [x] Add `if (event.repeat) return;` to the existing UpgradePopup keyboard handler after its destroyed/selected guard. Do not add a new timer or global input lock.
- [x] Run the focused command to GREEN, run TypeScript, inspect the diff and self-review. Obtain independent spec compliance then quality review; fix and re-review required issues.

### Final verification

- [x] Run `npm run test:ui`, `npm run test:combat`, `npm run test:assets`, `npm run check:assets`, `npm run build`.
- [x] Check the protected gameplay/art files are unchanged.
- [x] Through the actual browser UI, restart and use normal movement only, wait for earned XP to open choices without U, choose a card, and observe combat resume. Save screenshot evidence and restore temporary browser settings. Use an isolated temporary background tab rather than changing the user's shared live run.
- [x] Record exact results and review outcomes below, then report the restored automatic flow.

## Execution record

Design self-review complete: default automatic selection and optional explicit postponement are distinct; no art/balance changes.

- Only the five assigned files changed. Production diff is one opener call when earning, reward/skill application before opening the next queued credit, and one keyboard-repeat guard. Baselines are in `/tmp/potato-auto-upgrade-baseline.ct5J89` for read-only review; no Git operations.
- Focused RED before production edits: 24 tests, 11 pass, 13 expected assertion failures, exit 1. No fixture or syntax failures. Focused GREEN: 24/24, exit 0; TypeScript passed.
- Root fresh full regression: UI 48/48, combat 166/166, asset tests 2/2; validator reports 84 assets, zero missing or dimension mismatches. TypeScript/Vite production build passed; the pre-existing large-chunk warning remains.
- All five protected gameplay fingerprints still match the previous art-pass design. No configuration or art-file edits were made.
- Independent spec review: compliant, independently repeated focused 24/24. Independent final quality review: approved, no issues; repeated focused 24/24 and TypeScript passed. Additional reviewer check using actual UIScene/overlay ownership covered synchronous chaining, held keys, cancellation and restart without changing files.
- GUI smoke test in a fresh isolated background tab: no upgrade key or button used; naturally earned Lv2 at 00:09 automatically showed the three-choice popup. Selected the first card by pointer; combat and clock resumed to 00:11 and the selected skill appeared in the tray. This is a functionality test, not a balance measurement.
- Evidence: `artifacts/qa/automatic-upgrade-isolated.jpg` and `automatic-upgrade-resumed.jpg`. Initial observations in the shared live tab already had selected skills and were excluded as ambiguous input/state evidence; the isolated run verified the intended flow. No speculative production fix was made.
- No viewport overrides, no gameplay-debug keys and no persistent QA tab were used. The original user tab is left available; the unmarked temporary background tab is cleaned up by the browser when the turn ends.
