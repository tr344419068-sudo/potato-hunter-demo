# Difficulty Curve Smoothing Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace abrupt, unbounded opening difficulty with a calibrated continuous pressure curve and a consistent hostile-hit recovery model.

**Architecture:** Pure functions in `PacingModel.ts` interpolate base-health throughput and integer alive caps between authored wave targets. `WaveManager.ts` blends roster weights over six seconds. `PlayerDamageModel.ts` centralizes dash immunity, hit gating, and source-specific grace windows; `PlayerStatsSystem.ts` ticks the shared clock once before hostile systems. Separate difficulty bonuses ramp through interval changes, keeping ordinary batches at three.

**Tech Stack:** TypeScript, Phaser 3, ECS maps, Node test runner, Vite.

---

### Task 1: Continuous wave pressure model

**Files:**
- Modify: `src/managers/PacingModel.ts`
- Modify: `src/managers/WaveManager.ts`
- Modify: `scripts/pacing-model.test.mjs`

- [x] **Step 1: Write the failing interpolation tests**

Add tests that import `getWavePressure`, sample every second, assert monotonic spawn rate and alive cap, and compare values at `checkpoint - 1ms`, `checkpoint`, and `checkpoint + 1ms` with a tolerance of `0.02` enemies per second and one alive slot.

```js
const pressure = model.getWavePressure(config.waves, seconds * 1000);
assert.ok(pressure.spawnRatePerSecond >= previous.spawnRatePerSecond);
assert.ok(Math.abs(before.spawnRatePerSecond - at.spawnRatePerSecond) < 0.02);
assert.ok(Math.abs(after.spawnRatePerSecond - at.spawnRatePerSecond) < 0.02);
```

- [x] **Step 2: Run the focused test and confirm RED**

Run: `node --test scripts/pacing-model.test.mjs`

Expected: FAIL because `getWavePressure` is not defined.

- [x] **Step 3: Implement the pure pressure resolver**

Add `WavePressureTarget`, `WavePressure`, `getSpawnRatePerSecond`, `smoothstep`, and `getWavePressure` to `PacingModel.ts`. Select the current and next authored targets, ease normalized segment progress with `t * t * (3 - 2 * t)`, and interpolate spawn rate and max-alive.

```ts
export interface WavePressureTarget {
  startSeconds: number;
  spawnIntervalMs: number;
  spawnCount: number;
  maxAlive: number;
  pressurePerSpawn?: number;
}

export interface WavePressure {
  spawnRatePerSecond: number;
  pressurePerSecond: number;
  maxAlive: number;
}
```

- [x] **Step 4: Make `WaveManager` preserve encounter nodes while blending roster weights and consuming continuous pressure**

Resolve the current authored wave as before. Blend previous/new roster weights with smoothstep over six seconds, derive weighted base HP, and convert the interpolated health budget into a rate. Return a copy whose interval is derived from the fixed integer batch size.

```ts
const pressure = getWavePressure(this.pressureTargets, elapsedMs);
const spawnRatePerSecond = pressure.pressurePerSecond / getWeightedAverageMonsterHp(monsterMix);
return {
  ...current,
  monsterMix,
  spawnIntervalMs: (current.spawnCount / spawnRatePerSecond) * 1000,
  maxAlive: pressure.maxAlive,
};
```

- [x] **Step 5: Run the focused test and confirm GREEN**

Run: `node --test scripts/pacing-model.test.mjs`

Expected: interpolation and existing chapter/experience assertions all pass.

### Task 2: Recalibrate authored wave targets

**Files:**
- Modify: `src/configs/waves.json`
- Modify: `scripts/pacing-model.test.mjs`

- [x] **Step 1: Add throughput-budget assertions**

Calculate weighted average HP for each monster mix. Assert opening health input is between 60 and 95 HP/second, first-minute targets are monotonic, no adjacent target exceeds `1.95×`, and the 60-second target is below 450 HP/second.

```js
const hpPerSecond = spawnRate * weightedAverageHp;
assert.ok(openingHpPerSecond >= 60 && openingHpPerSecond <= 95);
assert.ok(nextHpPerSecond / previousHpPerSecond < 1.95);
assert.ok(sixtySecondHpPerSecond < 450);
```

- [x] **Step 2: Check the original targets against the budget**

The original opening of about 148 HP/second exceeds the 95 upper bound, and the original 60-second target of about 906 HP/second exceeds 450. Historical RED output is not preserved here; current GREEN evidence is recorded below.

- [x] **Step 3: Replace the wave numeric targets**

Use these batch/interval/cap targets while keeping chapter starts and enemy introductions:

```text
0s:   3 / 900ms, cap 36
10s:  3 / 820ms, cap 45
24s:  3 / 570ms, cap 58
40s:  3 / 525ms, cap 72
60s:  3 / 390ms, cap 90
105s: 3 / 354ms, cap 108
165s: 3 / 270ms, cap 132
```

Reduce the 40-second ranged weight from 3 to 2 so its introduction teaches projectile dodging before the siege wave restores the stronger ranged mix.

- [x] **Step 4: Run the pacing tests and confirm GREEN**

Run: `node --test scripts/pacing-model.test.mjs`

Expected: all pacing and throughput-budget assertions pass.

### Task 3: Shared hostile-damage gate

**Files:**
- Create: `src/systems/PlayerDamageModel.ts`
- Create: `scripts/player-damage-model.test.mjs`
- Modify: `src/systems/MonsterContactSystem.ts`
- Modify: `src/systems/EnemyProjectileSystem.ts`
- Modify: `src/systems/MonsterBehaviorSystem.ts`
- Modify: `src/systems/AoeWarningSystem.ts`
- Modify: `src/systems/DeathSystem.ts`
- Modify: `src/systems/PlayerStatsSystem.ts`
- Modify: `scripts/dash-model.test.mjs`
- Modify: `package.json`

- [x] **Step 1: Write pure-model and real ECS system tests**

Assert `canReceiveHostileDamage` rejects active dash/cooldown and accepts a ready player. Assert grace windows are bounded and ordered. Instantiate all five real damage systems and verify their behavior rather than relying only on import/source regular expressions.

```js
assert.equal(model.canReceiveHostileDamage({ dashRemainingMs: 1, damageCooldownMs: 0 }), false);
assert.equal(model.canReceiveHostileDamage({ dashRemainingMs: 0, damageCooldownMs: 1 }), false);
assert.equal(model.canReceiveHostileDamage({ dashRemainingMs: 0, damageCooldownMs: 0 }), true);
```

- [x] **Step 2: Exercise overlapping sources and attack consumption**

Cover same-frame volleys, clustered exploders, mixed damage kinds, dash/recovery rejection, one-shot removal, an accepted hit, exact recovery expiry, and the AOE safe center. Historical RED output is not preserved here; current GREEN evidence is recorded below.

- [x] **Step 3: Implement the pure model**

```ts
export type HostileDamageKind = "contact" | "projectile" | "explosion" | "aoe";

const HIT_GRACE_MS: Record<HostileDamageKind, number> = {
  contact: 900,
  projectile: 520,
  explosion: 700,
  aoe: 700,
};

export function canReceiveHostileDamage(state: { dashRemainingMs: number; damageCooldownMs: number }): boolean {
  return state.dashRemainingMs <= 0 && state.damageCooldownMs <= 0;
}

export function getHostileHitGraceMs(kind: HostileDamageKind): number {
  return HIT_GRACE_MS[kind];
}
```

- [x] **Step 4: Wire every hostile damage path and centralize the clock**

Each of contact, enemy projectile, self-explosion, Boss AOE, and elite death bomb checks `canReceiveHostileDamage` before subtracting health and sets source recovery immediately after a hit. One-shot attacks are consumed even when rejected; persistent contact enemies remain. Only `PlayerStatsSystem` advances the shared clock, before hostile systems in actual `GameScene` order.

- [x] **Step 5: Register and run the damage tests; update the dash regression**

Add `scripts/player-damage-model.test.mjs` to `test:combat`, then run it directly.

Run: `node --test scripts/player-damage-model.test.mjs`

Verified: 23 damage tests pass in the complete combat suite. The dash test now checks the shared gate rather than requiring the removed inline condition.

### Task 3b: Remove the separate difficulty-spawn staircase

**Files:** `src/managers/DifficultyManager.ts`, `src/systems/SpawnSystem.ts`, `scripts/difficulty-spawn-model.test.mjs`, `package.json`.

- [x] Ramp `extraSpawnCount` with six-second smoothstep at 75, 130, and 185 seconds.
- [x] Keep ordinary batches at three; consume the bonus via `wave.spawnIntervalMs * wave.spawnCount / (wave.spawnCount + difficulty.extraSpawnCount)`.
- [x] Run real ECS spawn tests covering count, interval, health-input continuity, and sustained post-ramp growth. All 4 pass in the complete suite.

### Task 4: Regression and browser verification

**Files:**
- Modify: `docs/superpowers/plans/2026-11-16-difficulty-curve-smoothing.md`

- [x] **Step 1: Run complete automated verification**

Run `npm run test:combat`, `npm run test:ui`, `npm run check:assets`, and `npm run build` as separate commands. Expected: zero failures, zero missing assets, and build exit code 0.

- [x] **Step 2: Exercise desktop opening and first-Boss short flow**

Natural opening samples reached the first upgrade and the 24-/40-second families. Debug time advancement exercised Boss entry, HUD, projectiles, short movement, and results/restart at 1280×720. Captured console errors/warnings: none. Pressure continuity and damage recovery are verified by real-system tests; a natural full-minute balance acceptance or Boss victory is not claimed.

- [x] **Step 3: Exercise portrait functional flow in 390×844**

Upgrade cards were visible/clickable, results/restart worked, and debug-assisted Boss entry/AOE/projectile presentation worked. Tapping dash visibly entered cooldown. Captured console errors/warnings: none. Temporary viewport overrides were reset. Continuous-movement difficulty across a natural run remains unverified.

- [x] **Step 4: Record completion evidence**

Mark each checkbox only after its command or browser observation has succeeded. This workspace is not a Git repository, so no commit steps are included.

## Evidence — November 17, 2026

- `npm run test:combat`: 80 passed, 0 failed (including pacing 13, damage 23, difficulty-spawn 4).
- `npm run test:ui`: 11 passed, 0 failed.
- `npm run check:assets`: 69 assets, 0 missing, 0 dimension mismatches.
- `npm run build`: exit 0; existing >500KB chunk warning remains.
- `curl -I http://localhost:5173/`: HTTP 200; Vite remains available for local play.
- Browser evidence: `artifacts/qa/difficulty-smoothing-portrait-upgrade.jpg`, `artifacts/qa/difficulty-smoothing-portrait-boss.jpg`, and `artifacts/qa/difficulty-smoothing-default.jpg`.
- Independent damage and spawn-pressure reviews found no Critical/Important issues. Non-blocking gap: tests hand-code damage-system order rather than locking actual scene assembly.

### Remaining balance acceptance (not part of completed regression claims)

- [ ] Repeated uninterrupted natural runs through the first Boss using several valid builds.
- [ ] Longer-run evaluation after 105/165 seconds, including elites, summons, recovery supplies, and objective choices.
- [ ] Establish first-Boss mistake/recovery and portrait-dodging acceptance from representative player sessions, not debug-jumped short flows.
