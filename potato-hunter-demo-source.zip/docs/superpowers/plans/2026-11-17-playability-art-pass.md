# Playability and Art Pass Implementation Plan

> **For agentic workers:** Use superpowers:subagent-driven-development with one implementation worker for UI/VFX and root owning animation. Review spec before quality. User requests direct execution without approval pauses; no Git/worktree/commit/PR.

**Goal:** Remove unsolicited pauses and improve upgrade clarity, limb locomotion and layered combat particles.

**Architecture:** Run-local pending upgrade credits in GameScene; intentional UI entry; focused card/notification models. Root adds calibrated UV mesh locomotion behind RenderSystem with original bitmaps. Separate capped particle layer in CombatVfxSystem or focused helper. Preserve physics/balance.

**Tech Stack:** TypeScript/Phaser3, existing esbuild/Node headless tests, existing bitmap art; no new dependency.

### Task1 — UI worker

- [x] Test-first actual GameScene/Experience lifecycle: earning upgrades cannot set choosingSkill or skip normal updates; manual open/cancel/select is validated, finite and resettable; queued credits survive, stale selections ignored.
- [x] Implement credits/HUD upgrade entry/U/cancel and deliberate pause only. Keep existing level curve and reward/evolution semantics. Avoid automatic popup chaining.
- [x] Test-first notification priority/dedupe; ordinary chapters/cast labels quiet, Boss key events short16–20px and noninteractive; preserve hostile ground warnings.
- [x] Rework UpgradePopup layout/fonts/icons/actual levels. Measured titles/benefits/tags and explicit level current→next; larger HUD skill icons; phone layouts bounded and click targets stable. Register tests without removing existing suite.

UI evidence: spec review caught FeedbackSystem's duplicate24pxBoss notices, repeatedUreopening and missing Chinese rounded glyphs. Production composed regressions now cover sole quiet notification routing, heldU, baselinepeelerHUDLv1→Lv2 and startupfontwait/fallback. Packaged ZCOOLKuaiLe.ttf/OFL has7053cmapglyphs and all authored Chinese names. Spec re-review passed35UI/126combat tests and build. Quality review caught pointer dismissal leaking into movement; selection/cancel now consume only their gesture until release, preserving keyboard/other touches. Independent quality re-review approved38UI/126combat/TypeScript/build, with outside-release/repress/shutdown checks. Root fresh UI38/38 and CUA held600ms selection followed by keyboard movement observed immediate resume. Desktop capture `art-pass-final-upgrade.jpg`; portrait `art-pass-portrait-upgrade.jpg`. Desktop icon ratio47%; portrait uses responsive horizontal cards with64–92pxicons, not a forced40%width at320×480.

### Task2 — root locomotion

- [x] Create failing `scripts/character-walk.test.mjs` for independent feet/counter-swing hands, idle stop, speed-scaled phase, bounded torso/mesh topology/tint/cleanup and calibrated assets.
- [x] Add focused `CharacterWalkModel.ts`/`CharacterMeshView.ts`; bind in RenderSystem, advance phase by displacement and remove full-image run hopping from SpriteJuiceSystem/CombatJuiceModel. Collision/pivot/ground unchanged.
- [x] Run focused/legacy pose tests; only replace old jumping assertions when they encode the explicitly rejected design, retaining grounded bounds. Capture preview of multiple actual mesh gait poses.

Animation evidence: initial missing-model tests red→green; production integration tests caught static Image and monster hopping; changed rejected torso-hop assertions red→green. Spec review found same-side hand/foot swing and facing reset; both reproduced then fixed. Exact production-grid tests cover both triangles, full attack and eight directions; independent review additionally swept16,465,920triangles without inversion. Quality review caught one-frame projection lag; actual installedPhaserVertex/Face/preUpdate regression failed then passed after view took exclusive projection ownership. UniqueUV/idle cache avoids repeated skinning. Spec and quality signoff passed, focused19/19 andTypeScriptgreen. Original assets rendered live in GameScene and shared WebGL helper rendered all five rigs in `artifacts/qa/character-walk-preview.html`; stepped screenshots `art-pass-walk-a/b/c.jpg`.

### Task3 — same UI worker after UI implementation, VFX-owned files only

- [x] Test-first actual particles with family silhouettes, direction/trails, finite life/event/global caps and shutdown; no payload mutation or new hitstop.
- [x] Implement focused pooled particle/emitter helper and wire existing muzzle/trail/impact/reaction events. Keep actor/hostile readability and rapid-fire budget.

Particle implementation evidence: actual runtime regressions red→green for generated textures and event wiring, bounded counts, offscreen allocation avoidance, texture leases, expiry/reuse, fair trails, ownership cleanup, and nonfinite hints. Spec review reproduced and worker test-first fixed: DisplayList→Feedback→VFX shutdown re-pools destroyedGraphics; ordinaryimpact/aura saturation consumes critical/reaction reserve; compact resize trims only totalcap and loses thatreserve. Actual installedPhaser destruction now produces3freshliveGraphics onrestart. Ordinaryspritecap144/64 preserves36heavy slots inside180/100total; accents28ordinary/36total and4reactionlabels. Resize ordinary-first preserves33heavy+64ordinary=97, thenalllifetimesexpire. Final independent spec passed16focused/142combat/TypeScript; fresh independentquality approved27focused/TypeScript with nofindings. Root independently freshcombat142/142,UI38/38,assets2/2 and69assetszeroissues,productionbuildpass (existinglargebundlewarning).

Visual evidence: root added QA-only `artifacts/qa/combat-particle-preview.html`, importing the actual production emitter. CUA WebGL observed six family silhouettes, bright muzzle ribbons and moving impact debris; exact screenshots saved as `art-pass-particle-families.jpg` and `particle-frame-00..09.jpg`. Derived10-frame `art-pass-particles-preview.gif` retains original captured pixels (7changing frame pairs; the ending holds after expiry). ActualGameScene multiskill sessions observed fire/frost/poison/reaction and a restart with lightning/corn/fire/nuke/aura,100HP desktop+portrait captures `art-pass-live-particles-desktop.jpg`/`art-pass-live-particles-portrait.jpg`. The earlier `art-pass-final-battle.jpg` captured a tool-idle death, not valid combat-art evidence; use the live captures. Current-version console has no newwarn/errors after05:28:37UTC. Desktop and390×844 final cards saved as `art-pass-final-upgrade.jpg`/`art-pass-final-portrait.jpg`; cancel/reopen retains credits.

### Task4 — review and verify

- [x] Spec review all tasks against actual code/tests; fix verified gaps. Then independent quality review lifecycle, queues, mesh render/tint/alpha/prune, font fit, particle budgets.
- [x] Full fresh `npm run test:combat`, `npm run test:ui`, `npm run test:assets`, `npm run check:assets`, `npm run build`; HTTP200.
- [x] CUA real-play desktop/390×844: no unsolicited upgrade pause, explicit upgrade/cancel, levels/icons, visible limb motion and particle families. Save screenshots, reset viewport, preserve playable tab, disclose2D deformation limitation.

Final integration review approved:46focused UI/upgrade/font/pointer/locomotion/particle tests andTypeScript passed; noverifiedcritical/importantcross-taskblockers. Root latestfullcombat142/142 andbuildgreen afterresizefix; UI38/38,assets2/2 and69checkedzeroissues,HTTP200. FinalCUA actualGameScene "再来一局" restored100HP/Lv1 withfresh visibleimpactdebris, image `art-pass-final-restart.jpg`; no newcurrent-versionwarn/errors. `art-pass-final-runtime.jpg` captures final-version lightning launch. Temporarypreviewtabclosed, viewportoverride reset, original localhosttabmarkedDeliverable. Locomotion is calibrated2DUV deformation oforiginalPNGs, notnew3Dboneanimation; original largebundlewarning remains.
