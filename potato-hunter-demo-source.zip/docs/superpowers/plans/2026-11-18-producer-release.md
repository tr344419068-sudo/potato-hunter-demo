# Producer quality release implementation plan

> **For agentic workers:** Use subagent-driven-development for isolated modules and root-owned integration, TDD and verification-before-completion. Spec and sequence are user-approved; do not pause for design/execution choices. This folder is not a Git repository, so Git/worktree/commit tasks do not apply. Each module receives independent spec then quality review before release.

**Goal:** Deliver a complete, polished 6–8 minute run and persistent replay loop, with authored sound/animation and verified runtime behavior.

**Architecture:** Keep existing Phaser/World/Systems. Add small profile/campaign/audio modules and a responsive DOM front-end shell. Scene owns run state and boss identity; presentation and statistics consume events. Legacy headless tests continue through default APIs.

**Tech Stack:** TypeScript, Phaser, esbuild/Node tests, Canvas/WebGL, existing PNGs, local versioned storage, original WAV/Web Audio output.

## Task1 — profile and reward model (isolated implementer)

Files: create `src/progression/ProgressionStore.ts`, `src/progression/RunRewardModel.ts`, `scripts/progression-store.test.mjs`.

Contracts:
```ts
type LoadoutId = "peeler" | "pepper" | "lightning";
type Preferences = { musicVolume:number; sfxVolume:number; reducedEffects:boolean };
type Profile = { version:1; gold:number; unlockedLoadouts:LoadoutId[]; selectedLoadout:LoadoutId; preferences:Preferences; totalRuns:number; victories:number; bestSeconds:number; rewardedRunIds:string[] };
interface StoragePort { getItem(key:string):string|null; setItem(key:string,value:string):void }
class ProgressionStore {
  constructor(storage?:StoragePort);
  getProfile():Profile;
  purchaseLoadout(id:LoadoutId):{ok:boolean;persisted:boolean;reason?:string};
  selectLoadout(id:LoadoutId):{ok:boolean;persisted:boolean};
  setPreferences(patch:Partial<Preferences>):{persisted:boolean};
  settleRun(runId:string,run:{outcome:"victory"|"defeat";elapsedMs:number;kills:number;bossKills:number;gold:number}):{awarded:number;duplicate:boolean;persisted:boolean;profile:Profile};
}
```
- [x] Tests first: default peeler/free wallet; corrupt/foreign JSON; negative/NaN/oversized values; deep-copy protection; purchase90 only affordable/once; locked selection rejected; reward formula; exact-once settlement after reconstructing store; failed reads/writes surfaced; preference clamping.
- [x] Run `node --test scripts/progression-store.test.mjs`, observe expected missing-feature RED; implement; re-run GREEN.
- [x] Independent spec and quality review; root integrates and registers package scripts.

## Task2 — campaign pacing and front-end (root)

Files: create `src/campaign/CampaignModel.ts`, `src/campaign/RunTelemetry.ts`, `src/campaign/AppState.ts`, `src/ui/CampaignShell.ts`; modify `src/main.ts`, `src/styles.css`, `src/scenes/GameScene.ts`, `src/scenes/UIScene.ts`, `src/systems/SpawnSystem.ts`, `src/managers/SkillManager.ts`, `src/managers/SkillStatsCalculator.ts`, `src/managers/SkillChoiceSystem.ts`, `src/components/ComponentTypes.ts`, `src/systems/SystemTypes.ts`; create `scripts/campaign-runtime.test.mjs`.

Core tested model:
```ts
const FINAL_BOSS_AT_MS=360000;
const INTERMEDIATE_BOSS_TIMES=[60000,180000,300000];
function getCampaignBeat(ms:number) {
 const t=Math.max(0,ms); const phase=t<60000?"warmup":t>=FINAL_BOSS_AT_MS?"finale":t%90000>=70000?"respite":t%90000>=55000?"pressure":"build";
 return {phase,spawnMultiplier:phase==="respite"?.38:phase==="pressure"?1.08:1,objective:phase==="finale"?"击败炸薯机，完成远征":phase==="respite"?"收集经验，寻找补给":"积累经验，完成构筑"};
}
```
- [x] Add failing tests for phases/boss cadence/final kill versus other boss kills/once-only result; real scene home→play→pause→resume→defeat/victory→retry; starter selection/rerolls/slot behavior/dead rescue guard/telemetry.
- [x] Integrate campaign optionally in runtime; preserve legacy default wave system for old tests. Suppress timed bosses while production campaign owns cadence. Track final entity id and victory after real death.
- [x] Build responsive home with hero PNG, 3 starter cards, wallet, mission description and settings; accessible pause/results controls. Keep combat objective compact and noninteractive outside toolbar.
- [x] Settle only once, show earned/banked gold and useful run summary, permit retry or returning home. Save failure is visible and never presented as durable success.
- [x] Actual browser QA, portrait and desktop; regression tests GREEN. Browser evidence covers short runs and lifecycle; actual full-duration browser victory remains unverified.

## Task3 — original sound and mix (isolated implementer afterTask1)

Files: create `src/audio/CombatAudioModel.ts`, `src/audio/GameAudio.ts`, `scripts/generate-game-audio.mjs`, `scripts/game-audio.test.mjs`, `public/assets/audio/*`, `public/assets/audio/provenance.json`; root integrates with shell and EventBus.

API: `new GameAudio(events,preferences)`, `unlock()`, `setPreferences(patch)`, `setState("home"|"combat"|"boss"|"paused"|"victory"|"defeat")`, `destroy()`. Add safe optional context/sink injection for headless tests, not test-only production methods.
- [x] Tests first: event mapping, launch/impact separation, priority reserve, cooldown/polyphony, mute, ducking/recovery, finite gains, locked/unavailable context, shutdown cleanup, WAV/provenance checks.
- [x] Create 26 original multilayer weapon/effect WAVs including three music loops; inspect files, provenance and mastering peaks; no downloaded copyrighted music.
- [x] Root connects real launch/impact/upgrade/dash/pickup/damage/boss/result events and persisted preferences; browser gesture path exercised; no routine camera effects.
- [ ] Human listening / speaker and subjective mix-quality review. Technical audio checks do not certify listening quality.

## Task4 — formal animation and role readability

Selected route: independently articulated 2D original-source layers; no Blender/open-scene mutation and no image API fallback. Files: `src/systems/AuthoredHeroModel.ts`, `AuthoredHeroView.ts`, `scripts/generate-authored-hero.mjs`, `scripts/authored-hero.test.mjs`, seven PNG layers in `public/assets/characters/potato_hunter/articulated-v3/`, source manifest/action sheets/contact sheet under `artifacts/source-character/`; integrate in RenderSystem/assets registry. Original idle-v2 remains fallback. Two-bone leg IK and authored arm action keys, not UV warping.
- [x] Confirm isolated original-source 2D authoring route without modifying the user's unrelated open Blender scene; no image API fallback.
- [x] Produce and inspect hero idle/run/attack/dash/hit/death; preserve identity, planted feet and clear weapon contact. Export source layers/actions with finite dimensions/pivots.
- [x] Test loader, frame selection, actual renderer, pause/restart/Canvas fallback, attack synchronization; inspect real-size desktop/portrait animation.
- [x] Retain existing enemy danger/role presentation and muted field; refine articulated hero and quiet HUD. This pass does not claim a complete new enemy-animation asset library.

## Task5 — release reliability

- [x] Register all new tests; final full release 433/433 tests, 91 assets, TypeScript and production build pass.
- [x] Seeded battle reproduction and damage/health/build snapshots; validate corrupted saves and unavailable audio/storage do not block play.
- [x] Headless long-run/peak-wave checks, repeat restart, pause/background/resize/input tests; compare protected gameplay configs against baseline (unchanged hashes).
- [x] Independent spec review followed by independent code-quality review; resolve all important findings, perform desktop/portrait browser visual and lifecycle checks.
- [ ] Measured real low-end/mobile GPU FPS, complete browser victory and continuous 20-minute browser soak. 25.67 simulated minutes are not a browser/FPS certification.

## Execution record

- [x] Approved producer direction captured; no new user-confirmation gates.
- [x] Task1 profile/reward — 23 focused tests; independent spec and quality review passed, read-failure overwrite regression fixed. Documented single-writer scope.
- [x] Task2 campaign/front-end — implementation and short-run desktop/portrait browser acceptance; final-kill same-step arbitration and independent Boss HUD modal regressions included.
- [x] Task3 sound — original assets, runtime bridge and fault cleanup reviewed; human listening qualification above remains open.
- [x] Task4 authored animation — seven independent original-source layers, six actions, release/contact and slow-frame regressions; no unrelated Blender changes.
- [x] Task5 local-delivery reliability — fresh full release plus independent spec/quality approved. Empirical commercial/device certifications above remain open.

Detailed evidence and limitations: `docs/superpowers/reviews/2026-11-18-producer-release-acceptance.md`.
