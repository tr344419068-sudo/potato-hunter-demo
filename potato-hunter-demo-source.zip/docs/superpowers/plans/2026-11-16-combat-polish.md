# Combat Polish Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Upgrade character motion, grounding shadows, enemy projectile readability, and player skill impact into a cohesive premium cartoon combat presentation.

**Architecture:** Keep timing and visual budgets in pure model functions, compose motion in `SpriteJuiceSystem`, draw grounding and projectile silhouettes in `RenderSystem`, and orchestrate transient effects in `CombatVfxSystem`. Reuse Phaser Graphics, tweens, and existing pools so no new runtime dependency is required.

**Tech Stack:** TypeScript, Phaser 3.90, Node test runner, Vite.

---

### Task 1: Motion and shadow models

**Files:**
- Modify: `scripts/combat-juice-model.test.mjs`
- Create: `src/systems/ShadowProfileModel.ts`
- Modify: `src/systems/CombatJuiceModel.ts`

- [x] Add failing tests asserting a three-phase attack pose, alternating running weight, and bounded two-layer shadow profiles for hero, monster, elite, and boss.
- [x] Run `node --test scripts/combat-juice-model.test.mjs` and confirm the new attack and shadow assertions fail because the model API is missing.
- [x] Add `phase`, `smear`, and stronger-but-bounded offsets to `getPlayerAttackPose`; add `getCharacterShadowProfile(kind, visualSize, liftRatio)` returning ambient and contact ellipse values.
- [x] Re-run the focused test and confirm it passes.

### Task 2: Element-specific VFX recipes

**Files:**
- Modify: `scripts/combat-vfx-model.test.mjs`
- Modify: `src/systems/CombatVfxModel.ts`

- [x] Add failing tests for `getCombatVfxRecipe`, requiring bounded but distinct trail length, core scale, ray count, debris count, and residue duration for every VFX family.
- [x] Run `node --test scripts/combat-vfx-model.test.mjs` and confirm failure because the recipe function does not exist.
- [x] Implement the typed recipe table and retain the existing palette and impact APIs.
- [x] Re-run the focused test and confirm it passes.

### Task 3: Grounding and projectile silhouettes

**Files:**
- Modify: `scripts/projectile-presentation.test.mjs`
- Modify: `src/systems/RenderSystem.ts`

- [x] Add failing source-level integration assertions for `drawCharacterShadow`, `drawEnemyProjectile`, a white core, dark outline, and directional velocity trail.
- [x] Run `node --test scripts/projectile-presentation.test.mjs` and verify the new assertions fail.
- [x] Replace the hero-only shadow with model-driven double-layer shadows for player and monsters; render enemy projectiles as outlined comet shapes and keep map objectives grounded.
- [x] Re-run the integration test and `npm run build`.

### Task 4: Hero action composition

**Files:**
- Modify: `src/systems/SpriteJuiceSystem.ts`
- Modify: `src/systems/CombatJuiceModel.ts`

- [x] Use the tested three-phase pose in `SpriteJuiceSystem`, extend attack duration to 230 ms, and combine smear, facing, stride, landing compression, and shadow lift without mutating the base transform.
- [x] Run `node --test scripts/combat-juice-model.test.mjs` and `npm run build`.

### Task 5: Four-stage player skill effects

**Files:**
- Modify: `scripts/combat-vfx-model.test.mjs`
- Modify: `src/systems/CombatVfxSystem.ts`

- [x] Add failing source integration assertions that the runtime consumes VFX recipes in muzzle, directional trail, impact, and residue paths.
- [x] Run the focused VFX test and confirm failure at the runtime wiring assertions.
- [x] Add direction-oriented muzzle arcs, layered projectile streaks, impact core flashes, recipe-driven rays and debris, and family-specific residue marks; throttle camera response and preserve particle caps.
- [x] Re-run focused tests and `npm run build`.

### Task 6: Death motion and full verification

**Files:**
- Modify: `src/systems/SpriteJuiceSystem.ts`
- Modify: `scripts/combat-juice-model.test.mjs`

- [x] Add a failing integration assertion for a squash, upward pop, rotation, and dust-ring death tween.
- [x] Upgrade sprite death motion and emit a pooled dust ring without exceeding the shared graphics budget.
- [x] Run `npm run test:combat`, `npm run test:ui`, `npm run check:assets`, and `npm run build`.
- [x] Reload the running game, inspect desktop and 390×844 portrait, verify player/enemy projectiles and shadows, check browser warnings/errors, reset the viewport, and preserve the playable tab.

