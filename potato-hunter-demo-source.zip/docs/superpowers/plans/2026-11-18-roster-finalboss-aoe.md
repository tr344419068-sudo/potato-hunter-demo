# Roster, Final Boss and AoE Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development. Independent monster / boss ownership permits dispatching-parallel-agents; shared type/config/art writes belong only to root. User has authorized autonomous implementation.

**Goal:** Add four real combat enemy types, a distinct four-skill final boss, generated poison/ketchup area artwork and visible level-scaled radii.

**Architecture:** Preserve existing ECS, old intermediate boss, startup difficulty and progression storage. New enemy roles have bounded snapshot telegraphs; final boss is selected by a run-owned identity; persistent AoE renderer consumes the same profiles as damage. Generated bitmap art is retained with provenance.

**Tech Stack:** TypeScript / Phaser, JSON configs, esbuild headless test fixtures, authenticated 神工 UI, PNG RGBA normalization.

No Git repository: no commit/worktree actions apply.

## Task 1 — Root shared contracts and generation

- [x] Extend mechanical type contracts with `hexer | scatter | sniper | jumper`, optional bossKind; ConfigManager behavior uses MonsterComponent['behavior']; finalBossAssetId optional on BossConfig. New runtime paths validated through failing-then-passing worker tests; type-only contracts were introduced before worker runtime RED.
- [x] Generate four enemy silhouettes, burger final boss and poison / ketchup area + puff textures separately on website; inspect alternatives, extract real alpha, normalize 512/768, retain prompts/results/originals. Register versioned assets; old art retained.

## Task 2 — Four real enemy behaviors (worker)

- [x] Write `scripts/new-enemy-roster.test.mjs`: exact new configs / registered asset identities, snapshot telegraphs before damage, distinct finite output per role, cancel on death, no catch-up burst, no out-of-range attacks; run RED.
- [x] Implement role logic in `src/systems/NewEnemyRoleSystem.ts` delegated by MonsterBehaviorSystem, extend MonsterAISystem spacing as required. Use component-owned cast state, finite range/cooldown and existing warnings/projectiles. Avoid independent clocks advancing after death; no hidden engine/global RNG overrides.
- [x] Append four monster configs at balanced durability, substitute weights only >=105s, preserve opening and spawn totals; update BestiaryModel / camp count to12 and factual descriptions. Update old exact8 invariants for old+new roster, not by deleting assertions.
- [x] Run new tests plus combat-variety / bestiary / campaign-shell tests GREEN, typecheck. Root later registers art, so note temporary absent final files distinctly.

## Task 3 — Distinct final boss (worker)

- [x] Write `scripts/final-boss.test.mjs`: only final identity picks new pattern model / art / larger size; exactly four patterns in every phase; complete telegraph delays, frozen aim, serial casts, death cancels all pending warnings, no warning/pellet budgets exceeded, intermediate behavior unchanged. Run RED.
- [x] Implement `FinalBossPatternModel.ts` / final routing in BossSystem and GameScene. Four exact patterns: `sesame_fan | triple_slam | spatula_sweep | sauce_ring`. Keep old pattern methods for intermediate unchanged. Bounded higher pressure at low HP, full reaction time, safety zone; final HP increase modest and explicit.
- [x] Update CampaignModel / UI result objective labels to 堡垒暴君. Do not mutate saves/rewards. Root handles shared Shell text conflicts. Run new+campaign+combat tests GREEN.

## Task 4 — Root generated AoE runtime

- [x] Write `scripts/area-vfx.test.mjs` failing on 14% radius progression and generated poison / ketchup layers; real update syncs correct radius / hero position, supports reduce / cleanup / missing assets. Run RED.
- [x] Add `AreaVfxModel.ts`, `AreaVfxView.ts`; persistent, bounded normal-blended texture rings at actual radius under actors, orbiting local puffs above low ground layer. VFXSystem updates/destroys view; RenderSystem keeps essential boundary fallback; do not add full-screen flashes/shakes.
- [x] Change aura radius formula to base×area×(1+0.14×(level−1)), keep base1; add clear skill hints. Reduce old per-tick graphic rings for authored aura so they do not obscure new textures.
- [x] Run area runtime, particles/textured/level growth tests GREEN; wire all new tests into package.

## Task 5 — Review / verification / handoff

- [x] Spec then quality reviews for each work area, fix substantive findings, final overall independent review.
- [x] Fresh `npm run test:release` with captured output, assets check, build. Check real RGBA alpha/dimensions/safe margins and reliable source records.
- [x] Real browser verifies12-card bestiary/loaded images, camp and realAreaVfxView Lv1/Lv5/reduced-effects preview. Headless real GameScene/UpgradePopup tests verify normal start/automatic upgrades; normal seeded simulation verifies role appearances and final four attacks/victory possible. Capture real screens and generated montage; no claim of a manual full-playthrough.

## Final acceptance — 2026-11-18

Independent spec and quality rechecks approved. Fresh `npm run test:release` exited0: 520 tests passing; 111 assets, zero missing/dimension mismatches; TypeScript/Vite production build passed. Vite retains the existing large-bundle warning (Phaser bundle 1.76MB), not a build failure.

Latest final state: seed7 actual victory at385s; seed42 did not kill the final before the480s simulation ceiling and was explicitly abandoned (player still alive), not a natural defeat or victory. Four fresh seed7 runs reproduce a further25.7 simulated minutes. Exact boss spawn times60/180/300/360s; actualfinal death and surviving player gate victory. Both samples observe all four new roles and all four final skills; hostile-projectile/warning limits are asserted every simulated frame (peaks26/7 for seed7,40/14 for seed42). Source/lifecycle/UI/stat regressions remain passing. Logs and source/art/browser evidence are retained under `artifacts/generated-2026-11-18-roster/`.
