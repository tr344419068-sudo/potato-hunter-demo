# User Poison Halo Implementation Plan

> **For agentic workers:** Inline execution; material processing and runtime integration form one dependent slice, no parallel delegation. Use test-driven-development and verification-before-completion.

**Goal:** 将用户提供的绿青流光气泡环替换毒气技能的柔光材质，保留原扩散及番茄暖金。

**Architecture:** 本地图像背景提取保留彩色发光结构，生成512pxRGBA版本资源。生产AreaVfxView按技能种类选择贴图，毒气优先用户素材并使用白色tint，缺失时回退已有生成光晕；不改变时间模型、伤害、范围、层级、存档。

**Tech Stack:** Pillow/numpy；Phaser/TypeScript；node:test；浏览器实际模块检视。

## 已明确的设计

用户在同意现有生图+代码方向后主动发来新图，按此前交付约定直接处理接入，无重复确认。RGB原图带绘入的灰色棋盘，不能当作RGBA；保留1024px原图及SHA256。选择本地去灰色底，保持绿青双色及气泡，不上传文件、不调用新生图、不承诺恢复出不存在的原始alpha。单色化会丢失这张的双色细节，整图不处理会铺灰格，两者不采用。

## Task 1: 背景处理

- [x] 创建 `scripts/process-user-halo.test.py`。先测试可调用处理器存在、灰色棋盘alpha0、绿光保色/白亮点保留、真正透明输入不变，再用已归档实际原图检查中心留空。
- [x] 运行 `python3 scripts/process-user-halo.test.py`，确认失败是处理器缺失。
- [x] 创建 `scripts/process-user-halo.py`，读取源图：有真实alpha时保留；RGB时用颜色差提取发光，柔和抑制灰色噪声并单独保留高亮白点，构造直通RGBA。保持原图光丝轮廓，不绘制新图案。
- [x] 归档源图至 `artifacts/user-poison-halo-2026-11-18/source-original.png`，生成透明1024px准备图、512px生产图 `public/assets/vfx/halo-user-v1/poison-halo.png` 和黑底QA图。
- [x] 运行处理器测试；检查中心/角落alpha0、软透明像素与完整光丝。保存处理方式和来源/哈希，说明RGB去底为近似提取。

## Task 2: 生产接入

- [x] 扩展 `scripts/generated-halo-runtime.test.mjs` fixture支持用户贴图：先测试毒气选择用户图且tint白、番茄仍选择旧图、用户图占位时回退、配置图尺寸/透明中心；执行该文件确认新需求失败。
- [x] 在 `src/configs/assets.json` 注册 `vfx_poison_halo_user_v1`。AreaVfxView只修改层创建时的贴图选择（毒气先用户图后通用图），真实frame检查/复用/生命周期沿用旧逻辑；用户图tint0xffffff。
- [x] 现有已用2图/技能、30对象上限、900ms扩散及位置锁定不变。原图造型只作为扩散波上的材质，不常亮贴人。
- [x] 把新图预加载加入 `artifacts/generated-2026-11-18-moba/preview.ts`；为发布测试增加处理器单元测试调用。

## Task 3: 验收

- [x] 正常/减少特效、Lv1/Lv5使用真实模块浏览器截图和120ms步进16帧GIF；确认棋盘无残留、角色可见，说明是模块检视非实战录像。
- [x] `npm run test:release` 退出0，资源无缺失，构建成功。保存日志和最终接入说明。
- [x] 保留旧素材和用户原图可回退；项目非Git，不创建仓库或做Git提交。
