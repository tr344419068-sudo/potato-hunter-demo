# 清透波场与伤害数字实施计划

> Inline execution following executing-plans; user requests autonomous execution. No Git repository, no branch/commit actions.

Goal: replace attached heavy aura artwork with expanding fading thin wavefields; make damage digits readable without changing combat numbers.
Architecture: AreaVfxModel defines deterministic expansion/envelopes; AreaVfxView owns fixed wave/mote pools and sampled world origins. DamageNumberModel defines typography/animation; FeedbackSystem owns bounded pooled text and updates on game delta.
Tech: Phaser TypeScript, esbuild headless fixtures, CUA browser visual verification.

## 1 — Wavefield TDD

- [x] Add scripts/moba-wavefield.test.mjs tests against real AreaVfxView/Model. RED on no thick textures, changing scale/alpha, snapshot centers and outward particles, budgets/reduced/pause/no catchup. Preserve aura actual radius+level tests.
- [x] Rewrite AreaVfxModel with getAreaWaveFrame(radius,ageMs,reducedEffects) => wave radius .32R→R, alpha attack / brief crest / fade; getAreaMoteFrame => six outward rays. AreaVfxView two waveGraphics+six motes/layer; lock origin per cycle and fixed snapshot maxradius. Normal blend; thin line core+lowalpha rim arcs; no fillCircle for large fields.
- [x] Quiet RenderSystem.drawAura guide (no fill, thin lowalpha line), keeping exactradius. Run focused tests and update superseded thick-image invariants, retaining actual damage/pause/cleanup guarantees.

## 2 — Digit TDD

- [x] Add scripts/damage-number-presentation.test.mjs: normal font>=20/stroke>=3, brightpalette, hold>=220ms, scaleattack, same-target lane differences, malformedreject, allcrit<=48, offscreen/pause/cleanup/reuse. Run RED againstFeedbackSystem.
- [x] Add DamageNumberModel, integrateFeedbackSystem fixed lifecycle interpolation not tweens. Track active text pool; 22/28px, darkstroke4, hold thenfade. Add targetId to projectile/aura/status damage payloads. No actualdamage modifications.
- [x] Run damagefeedback/oldpool/camera/pause tests GREEN and typecheck. Register tests in package.json.

## 3 — Visual acceptance & release

- [x] Extend diagnostic preview with realHero art, monster group, actualFeedbackSystem and newAreaVfxView; movement andwavefield snapshots. Capture multiple browser frames/GIF. Nohiddenengine/storage manipulation.
- [x] Read requesting-code-review and verification-before-completion; independent bounded review if required byskill, fix substantivefindings.
- [x] npm run test:release exits0 with preservedlog; trueimages/GIF inline and explicitmanual-playthrough boundary. Mark plan completed only after freshpassing evidence.

## 验收结果

2026-11-18 最终 `npm run test:release` 退出 0：541 tests / 0 failures（UI 65、combat 235、roster 90、campaign 101、audio 34、art 7、assets 9）。111 assets / 0 missing / 0 dimension mismatches；tsc + Vite production build通过，原有Phaser大包提醒仍在。日志：`artifacts/generated-2026-11-18-moba/release-validation.log`。

本轮32项范围/数字回归涵盖：world-locked扩散/alpha/scale、薄边可见波峰、不填充中心、断续能量弧、数量封顶、暂停、缩减模式、结算释放、护盾与HP分开、敌我类别、连续暴击字间距。新测试均先观察RED再实施，旧厚图的四项不适用断言替换为实际新波场断言，伤害边界与成长验证保留。

浏览器保存Lv1/Lv5/reduced场景与16帧120ms步进GIF，未捕获error/warn；生成脚本验证16帧和尺寸。检视使用真实模块和资产，但移动/命中事件为示例，不声称实战通关或操控游戏存档。最初边缘太淡，视觉QA后提亮薄边并增加轻微起伏的短能量弧；连续数字通道增加间隔避免文字挤压。只改显示，不改战斗计算、半径、成长和难度。

独立代码审查的终局清理、敌我颜色、护盾数字混合问题已补回归并修复，复查无Critical/Important遗留项。
