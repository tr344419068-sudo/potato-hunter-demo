# 主角跟随与番茄光环 Implementation Plan

> 执行：本次按用户自主执行授权在当前会话内执行；不建立Git仓库或工作树。

**Goal:** 毒气和番茄圈心逐帧跟随主角，番茄使用用户红色透明液体环。

**Architecture:** `AreaVfxView`同步当前位置/半径，只用独立时间控制扩散。用户素材沿现有资产加载路径与本地确定性导入器接入。

**Tech Stack:** TypeScript/Phaser、Node test/esbuild、Python/Pillow、CUA浏览器检视。

### 1. 跟随修复

- [x] 修改`moba-wavefield.test.mjs`、`generated-halo-runtime.test.mjs`中旧坐标锁定预期；断言移动下一帧所有波/图与角色相等，粒子位置为角色坐标加当前散射偏移，零delta只冻结相位。
- [x] 用`node --test scripts/moba-wavefield.test.mjs scripts/generated-halo-runtime.test.mjs scripts/area-vfx.test.mjs`观察坐标预期失败。
- [x] `AreaVfxView`去掉`cycle`并把`snapshot`替换为同步采样：`emission.x=x; emission.y=y; emission.radius=radius; return time % period;`。`AreaVfxModel`注释同步更新。
- [x] 上述命令GREEN，确认范围升级下一帧生效、对象数量不变。

### 2. 用户番茄素材

- [x] 归档原图到`artifacts/user-ketchup-halo-2026-11-18/source-original.png`（原始字节复制）。
- [x] 写失败测试：`vfx_ketchup_halo_user_v1`选中且白色tint/NORMAL混合/峰值alpha0.65；占位图回退；RGBA红色/高光/空心；`--name ketchup`导入可重复并记录真实alpha来源。
- [x] 导入器新增`--name`选项`poison|ketchup`，默认poison保持旧输出；有alpha原图不做提取，用源图复制与Lanczos缩图，报告`preserved source RGBA; Lanczos resize only`。
- [x] 导入并注册`assets/vfx/halo-user-v1/ketchup-halo.png`。`AreaVfxView`候选`['vfx_ketchup_halo_user_v1','vfx_halo_energy_v1']`，两用户图白色tint；只有用户番茄图NORMAL且alpha乘`0.65/0.9`。`getAreaVfxSpec('ketchup')`使用`0xff5646/0xff9273/0xfff0b3`。
- [x] 测试GREEN，既有毒图字节不变。

### 3. 检视与交付

- [x] 更新正式模块检视页preload、文本与明显往返路径，加入不读写存档的可见冲刺步进控制（一次140px位移），用截图确认即时跟随。
- [x] 浏览器观察Lv1/Lv5、正常/减少特效、暂停/单步/冲刺，录制动态证据。
- [x] 更新素材来源与旧毒气文档后续变更说明，自查生命周期/兜底/范围/图层。
- [x] `npm run test:release`完整通过，交付动态检视与实际测试数量。

最终：571项Node测试、6项嵌套Python测试、114项资源与构建通过。独立复核无重要问题。动态证据`artifacts/user-ketchup-halo-2026-11-18/following-poison-ketchup-live.gif`18帧、120ms/帧；同相位140px位移前后截图确认即时跟随。非Git目录保留原地，不建立分支/提交/PR或删除任何素材。
