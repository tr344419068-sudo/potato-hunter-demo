# Combat Art and Pacing Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Complete the missing combat art, add distinctive real-time skill VFX, and make the first minute build through rush waves to a 60-second Boss.

**Architecture:** Generated PNGs provide icons, projectiles, and a seamless arena tile. Pure pacing and VFX-style helpers are tested independently; Phaser systems consume them without embedding balance decisions in rendering code.

**Tech Stack:** Phaser 3.90, TypeScript 5.8, Vite 6, PNG assets, Node test runner.

---

### Task 1: Asset coverage contract

**Files:**
- Create: `scripts/combat-assets.test.mjs`
- Modify: `src/configs/assets.json`
- Modify: `src/configs/skills.json`

- [ ] Write a failing test that asserts every skill has a registered icon and every weapon has a registered projectile asset.
- [ ] Generate nine missing icons, five projectile sprites, and one battlefield tile with the approved art direction.
- [ ] Register all assets and update skill records.
- [ ] Run `npm run check:assets` and the new contract test; expect zero missing paths and dimensions.

### Task 2: Pacing model

**Files:**
- Create: `src/managers/PacingModel.ts`
- Create: `scripts/pacing-model.test.mjs`
- Modify: `src/configs/waves.json`
- Modify: `src/configs/difficulty.json`
- Modify: `src/entities/factories.ts`
- Modify: `src/systems/ExperienceSystem.ts`

- [ ] Write failing assertions for wave checkpoints at 0, 12, 28, 45, and 75 seconds and a 60-second Boss cadence.
- [ ] Implement pure checkpoint selection and validate increasing pressure.
- [ ] Apply the wave/difficulty values and raise initial XP requirements from 6 to 14 with a slower level curve.
- [ ] Re-run pacing tests and build.

### Task 3: Projectile rendering contract

**Files:**
- Modify: `src/managers/ConfigManager.ts`
- Modify: `src/managers/SkillTypes.ts`
- Modify: `src/managers/SkillStatsCalculator.ts`
- Modify: `src/entities/factories.ts`
- Modify: `src/systems/AutoAttackSystem.ts`
- Modify: `src/systems/RenderSystem.ts`

- [ ] Add optional `projectileAssetId` and `vfxKind` fields through config and weapon profiles.
- [ ] Pass the asset id into projectile render components.
- [ ] Rotate projectile sprites from velocity and emit one `weapon:fired` event per volley.
- [ ] Build and verify there are no plain squares for configured weapons.

### Task 4: Elemental combat effects

**Files:**
- Create: `src/systems/CombatVfxModel.ts`
- Create: `src/systems/CombatVfxSystem.ts`
- Create: `scripts/combat-vfx-model.test.mjs`
- Modify: `src/systems/ProjectileCollisionSystem.ts`
- Modify: `src/systems/AuraSystem.ts`
- Modify: `src/scenes/GameScene.ts`

- [ ] Write failing tests for fire, frost, lightning, peeler, poison, and explosion style resolution plus particle budgets.
- [ ] Implement the pure resolver and particle budget.
- [ ] Render muzzle flashes, trails, impact bursts, aura bubbles, and upgraded chain arcs.
- [ ] Emit impacts from collision and aura systems, then insert `CombatVfxSystem` into the game loop.

### Task 5: Battlefield presentation

**Files:**
- Create: `src/systems/BattlefieldBackground.ts`
- Modify: `src/scenes/GameScene.ts`
- Modify: `src/systems/RenderSystem.ts`

- [ ] Add a camera-following tile sprite behind gameplay.
- [ ] Reduce the debug grid to a subtle translucent navigation texture.
- [ ] Relayout the background on Phaser resize and destroy it on scene shutdown.

### Task 6: Verification

**Files:**
- Modify only if a failure is found.

- [ ] Run all Node tests, asset validation, and `npm run build`.
- [ ] Browser-check desktop and portrait mobile.
- [ ] Verify all weapon families, first-minute pacing, Boss arrival, upgrade icons, resize, and console output.
- [ ] Keep the correct LAN preview URL open for the user.

## Execution note

The user explicitly requested autonomous implementation and the workspace has no Git metadata. Work executes inline with test and browser checkpoints instead of commits or subagent dispatch.
