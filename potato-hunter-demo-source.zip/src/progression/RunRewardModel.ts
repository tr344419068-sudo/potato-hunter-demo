export type RunOutcome = "victory" | "defeat";

export interface RunSummary {
  outcome: RunOutcome;
  elapsedMs: number;
  kills: number;
  bossKills: number;
  gold: number;
}

export const MAX_PROFILE_GOLD = 1_000_000_000;
export const MAX_RUN_SECONDS = 86_400;
export const MAX_RUN_KILLS = 1_000_000;
export const RUN_REWARD_POLICY = "Malformed or zero-time runs are rejected; positive elapsed time is required. Valid early runs retain collected gold, but survival, boss, and victory bonuses require 15 seconds or 3 kills.";

function isBoundedInteger(value: unknown, maximum: number): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && value <= maximum;
}

export function isValidRunSummary(run: unknown): run is RunSummary {
  if (typeof run !== "object" || run === null || Array.isArray(run)) return false;
  const candidate = run as Record<string, unknown>;
  return (candidate.outcome === "victory" || candidate.outcome === "defeat")
    && typeof candidate.elapsedMs === "number"
    && Number.isFinite(candidate.elapsedMs)
    && candidate.elapsedMs > 0
    && candidate.elapsedMs <= MAX_RUN_SECONDS * 1000
    && isBoundedInteger(candidate.kills, MAX_RUN_KILLS)
    && isBoundedInteger(candidate.bossKills, MAX_RUN_KILLS)
    && candidate.bossKills <= candidate.kills
    && isBoundedInteger(candidate.gold, MAX_PROFILE_GOLD);
}

export function isRunRewardEligible(run: RunSummary): boolean {
  return isValidRunSummary(run) && (run.elapsedMs >= 15_000 || run.kills >= 3);
}

export function calculateRunReward(run: RunSummary): number {
  if (!isValidRunSummary(run)) return 0;
  const bonus = isRunRewardEligible(run)
    ? 10 + Math.floor(run.elapsedMs / 20_000) + 15 * run.bossKills + (run.outcome === "victory" ? 80 : 0)
    : 0;
  return run.gold + bonus;
}
