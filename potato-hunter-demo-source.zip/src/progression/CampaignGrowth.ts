export type TrainingId = 'attack' | 'health' | 'pickup';

export interface CampaignProgress {
  selectedStage: StageId;
  clearedStages: StageId[];
  training: Record<TrainingId, number>;
  stageSelectionConfirmed?: true;
}

export const TRAINING_COSTS = [20, 40, 70, 110, 160] as const;
export const STAGES = [
  { id: 'meadow', name: '青酱草甸', bossName: '堡垒暴君', ground: 'background_battlefield_grassland', firstClearGold: 40, finaleMs: 180_000, eliteMs: [60_000, 110_000, 150_000] },
  { id: 'desert', name: '香料沙海', bossName: '沙海堡垒之王', ground: 'background_battlefield_desert', firstClearGold: 80, finaleMs: 180_000, eliteMs: [60_000, 110_000, 150_000] },
  { id: 'snow', name: '霜炉峡谷', bossName: '霜炉重锤王', ground: 'background_battlefield_snow', firstClearGold: 120, finaleMs: 240_000, eliteMs: [55_000, 116_000, 184_000] },
] as const;
export type StageId = (typeof STAGES)[number]['id'];

export function isStageId(value: unknown): value is StageId {
  return STAGES.some(({ id }) => id === value);
}
export const getCampaignStage = (stage: StageId = 'meadow') => STAGES.find(({ id }) => id === stage) ?? STAGES[0];
export const nextCampaignStage = (stage: StageId): StageId | undefined => STAGES[STAGES.findIndex(({ id }) => id === stage) + 1]?.id;
export function getBattlefieldAssetId(stage?: StageId): string {
  return getCampaignStage(stage).ground;
}
export function isTrainingId(value: unknown): value is TrainingId {
  return value === 'attack' || value === 'health' || value === 'pickup';
}
export function stageUnlocked(progress: CampaignProgress, stage: StageId): boolean {
  const index = STAGES.findIndex(({ id }) => id === stage);
  return index >= 0 && STAGES.slice(0, index).every(({ id }) => progress.clearedStages.includes(id));
}
export function normalizeCampaignProgress(value: unknown, legacyVictories: number): CampaignProgress {
  const saved = typeof value === 'object' && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : undefined;
  const rawTraining = typeof saved?.training === 'object' && saved.training !== null && !Array.isArray(saved.training) ? saved.training as Record<string, unknown> : {};
  const rank = (id: TrainingId): number => {
    const v = rawTraining[id];
    return typeof v === 'number' && Number.isSafeInteger(v) && v >= 0 && v <= TRAINING_COSTS.length ? v : 0;
  };
  const cleared = Array.isArray(saved?.clearedStages) ? saved.clearedStages.filter(isStageId) : legacyVictories > 0 ? ['meadow' as const] : [];
  const result: CampaignProgress = { selectedStage: 'meadow', clearedStages: [], training: { attack: rank('attack'), health: rank('health'), pickup: rank('pickup') } };
  for (const { id } of STAGES) {
    if (!cleared.includes(id)) break;
    result.clearedStages.push(id);
  }
  if (isStageId(saved?.selectedStage) && stageUnlocked(result, saved.selectedStage)) result.selectedStage = saved.selectedStage;
  if (saved?.stageSelectionConfirmed === true) result.stageSelectionConfirmed = true;
  // Legacy saves cannot tell whether meadow was selected deliberately. Nudge
  // once toward the unlocked, uncleared stage; an explicit choice is persisted.
  if (!result.stageSelectionConfirmed && result.clearedStages.includes('meadow') && !result.clearedStages.includes('desert')) result.selectedStage = 'desert';
  return result;
}

export function getTrainingBonuses(training: CampaignProgress['training']): { damageMultiplier: number; maxHp: number; pickupRadius: number } {
  return { damageMultiplier: 1 + training.attack * .04, maxHp: training.health * 8, pickupRadius: training.pickup * 12 };
}
