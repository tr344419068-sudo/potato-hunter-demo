export type StageId = 'meadow' | 'desert';
export type TrainingId = 'attack' | 'health' | 'pickup';

export interface CampaignProgress {
  selectedStage: StageId;
  clearedStages: StageId[];
  training: Record<TrainingId, number>;
  stageSelectionConfirmed?: true;
}

export const TRAINING_COSTS = [20, 40, 70, 110, 160] as const;
export const STAGES = [
  { id: 'meadow', name: '青酱草甸', firstClearGold: 40 },
  { id: 'desert', name: '香料沙海', firstClearGold: 80 },
] as const;

export function isStageId(value: unknown): value is StageId {
  return value === 'meadow' || value === 'desert';
}
export function getBattlefieldAssetId(stage?: StageId): string {
  return stage === 'desert' ? 'background_battlefield_desert' : 'background_battlefield_grassland';
}
export function isTrainingId(value: unknown): value is TrainingId {
  return value === 'attack' || value === 'health' || value === 'pickup';
}
export function stageUnlocked(progress: CampaignProgress, stage: StageId): boolean {
  return stage === 'meadow' || progress.clearedStages.includes('meadow');
}
export function normalizeCampaignProgress(value: unknown, legacyVictories: number): CampaignProgress {
  const saved = typeof value === 'object' && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : undefined;
  const rawTraining = typeof saved?.training === 'object' && saved.training !== null && !Array.isArray(saved.training) ? saved.training as Record<string, unknown> : {};
  const rank = (id: TrainingId): number => {
    const v = rawTraining[id];
    return typeof v === 'number' && Number.isSafeInteger(v) && v >= 0 && v <= TRAINING_COSTS.length ? v : 0;
  };
  const cleared = Array.isArray(saved?.clearedStages) ? saved.clearedStages.filter(isStageId) : legacyVictories > 0 ? ['meadow' as const] : [];
  const validClears = cleared.includes('meadow') ? cleared : cleared.filter(stage => stage !== 'desert');
  const result: CampaignProgress = { selectedStage: 'meadow', clearedStages: [...new Set(validClears)], training: { attack: rank('attack'), health: rank('health'), pickup: rank('pickup') } };
  if (isStageId(saved?.selectedStage) && stageUnlocked(result, saved.selectedStage)) result.selectedStage = saved.selectedStage;
  if (saved?.stageSelectionConfirmed === true) result.stageSelectionConfirmed = true;
  // Legacy saves cannot tell whether meadow was selected deliberately. Nudge
  // once toward the unlocked, uncleared stage; an explicit choice is persisted.
  if (!result.stageSelectionConfirmed && result.clearedStages.includes('meadow') && !result.clearedStages.includes('desert')) result.selectedStage = 'desert';
  return result;
}

export function getTrainingBonuses(training: CampaignProgress['training']): { damageMultiplier: number; maxHp: number; pickupRadius: number } {
  return { damageMultiplier: 1 + training.attack * .04, maxHp: training.health * 8, pickupRadius: training.pickup * 12 };
}
