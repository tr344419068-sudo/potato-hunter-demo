import { calculateRunReward, isRunRewardEligible, isValidRunSummary, MAX_PROFILE_GOLD, MAX_RUN_SECONDS, type RunSummary } from "./RunRewardModel";

export type LoadoutId = "peeler" | "pepper" | "lightning";

export interface Preferences {
  musicVolume: number;
  sfxVolume: number;
  reducedEffects: boolean;
}

export interface Profile {
  version: 1;
  gold: number;
  unlockedLoadouts: LoadoutId[];
  selectedLoadout: LoadoutId;
  preferences: Preferences;
  totalRuns: number;
  victories: number;
  bestSeconds: number;
  rewardedRunIds: string[];
}

export interface StoragePort {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

export interface LoadoutDescriptor {
  id: LoadoutId;
  name: string;
  description: string;
  price: number;
  starterSkillId: string;
  iconPath: string;
}

export interface PurchaseResult {
  ok: boolean;
  persisted: boolean;
  reason?: "invalid-loadout" | "insufficient-gold";
}

export interface SettlementResult {
  awarded: number;
  duplicate: boolean;
  persisted: boolean;
  profile: Profile;
}

export const LOADOUTS: ReadonlyArray<Readonly<LoadoutDescriptor>> = Object.freeze([
  Object.freeze({ id: "peeler", name: "削皮刀", description: "可靠的基础弹道，均衡提升伤害、射速和数量。", price: 0, starterSkillId: "peeler_blade", iconPath: "assets/icons/skills/peeler_blade-v2.png" } as const),
  Object.freeze({ id: "pepper", name: "胡椒加特林", description: "高速精准连射，以攻速压制单体目标。", price: 90, starterSkillId: "pepper_gatling", iconPath: "assets/icons/skills/fries_storm.png" } as const),
  Object.freeze({ id: "lightning", name: "雷电土豆链", description: "雷电在敌群之间连锁跳跃。", price: 90, starterSkillId: "thunder_potato", iconPath: "assets/icons/skills/thunder_chain-v2.png" } as const),
]);

export const PROFILE_STORAGE_KEY = "potato-hunter.profile.v1";
export const MAX_REWARDED_RUN_IDS = 10_000;
export const PROFILE_RECEIPT_POLICY = "Retain every accepted run receipt. At 10,000 receipts, reject new settlements rather than evict an old exact-once receipt.";
export const PROFILE_STORAGE_POLICY = "Assume one live writer in the same tab; cross-tab and concurrent-store coordination are outside this contract. An initial storage read failure disables persistence for that store lifetime; construct a fresh store after access recovers.";
const MAX_PROFILE_COUNTER = 1_000_000_000;
const MAX_SERIALIZED_PROFILE_LENGTH = 2_000_000;
const DEFAULT_PREFERENCES: Readonly<Preferences> = Object.freeze({ musicVolume: 0.28, sfxVolume: 0.65, reducedEffects: false });
const PROFILE_FIELDS: ReadonlyArray<keyof Profile> = ["version", "gold", "unlockedLoadouts", "selectedLoadout", "preferences", "totalRuns", "victories", "bestSeconds", "rewardedRunIds"];

function createDefaultProfile(): Profile {
  return {
    version: 1,
    gold: 0,
    unlockedLoadouts: ["peeler"],
    selectedLoadout: "peeler",
    preferences: { ...DEFAULT_PREFERENCES },
    totalRuns: 0,
    victories: 0,
    bestSeconds: 0,
    rewardedRunIds: [],
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isLoadoutId(value: unknown): value is LoadoutId {
  return value === "peeler" || value === "pepper" || value === "lightning";
}

function isRunId(value: unknown): value is string {
  return typeof value === "string" && value.length <= 128 && /^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(value);
}

function sanitizeInteger(value: unknown, maximum: number): number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && value <= maximum ? value : 0;
}

function sanitizeSeconds(value: unknown): number {
  return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= MAX_RUN_SECONDS ? value : 0;
}

function sanitizeVolume(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) ? Math.min(1, Math.max(0, value)) : fallback;
}

function sanitizePreferences(value: unknown, fallback: Readonly<Preferences>): Preferences {
  const candidate = isRecord(value) ? value : {};
  return {
    musicVolume: sanitizeVolume(candidate.musicVolume, fallback.musicVolume),
    sfxVolume: sanitizeVolume(candidate.sfxVolume, fallback.sfxVolume),
    reducedEffects: typeof candidate.reducedEffects === "boolean" ? candidate.reducedEffects : fallback.reducedEffects,
  };
}

function sanitizeProfile(value: unknown): Profile {
  if (!isRecord(value) || value.version !== 1 || !PROFILE_FIELDS.every((field) => Object.prototype.hasOwnProperty.call(value, field))) return createDefaultProfile();
  if (!Array.isArray(value.unlockedLoadouts) || value.unlockedLoadouts.length > 32
    || !Array.isArray(value.rewardedRunIds) || value.rewardedRunIds.length > MAX_REWARDED_RUN_IDS) return createDefaultProfile();
  const unlockedLoadouts: LoadoutId[] = ["peeler", ...value.unlockedLoadouts.filter(isLoadoutId).filter((loadoutId) => loadoutId !== "peeler")];
  const uniqueLoadouts = [...new Set(unlockedLoadouts)];
  const totalRuns = sanitizeInteger(value.totalRuns, MAX_PROFILE_COUNTER);
  return {
    version: 1,
    gold: sanitizeInteger(value.gold, MAX_PROFILE_GOLD),
    unlockedLoadouts: uniqueLoadouts,
    selectedLoadout: isLoadoutId(value.selectedLoadout) && uniqueLoadouts.includes(value.selectedLoadout) ? value.selectedLoadout : "peeler",
    preferences: sanitizePreferences(value.preferences, DEFAULT_PREFERENCES),
    totalRuns,
    victories: Math.min(totalRuns, sanitizeInteger(value.victories, MAX_PROFILE_COUNTER)),
    bestSeconds: sanitizeSeconds(value.bestSeconds),
    rewardedRunIds: [...new Set(value.rewardedRunIds.filter(isRunId))],
  };
}

function getBrowserStorage(): StoragePort | undefined {
  try {
    const storage = globalThis.localStorage;
    return storage && typeof storage.getItem === "function" && typeof storage.setItem === "function" ? storage : undefined;
  } catch {
    return undefined;
  }
}

export class ProgressionStore {
  private readonly storage: StoragePort | undefined;
  private profile: Profile;
  private initializationReadFailed = false;

  constructor(storage?: StoragePort) {
    this.storage = storage ?? getBrowserStorage();
    this.profile = this.readProfile();
  }

  getProfile(): Profile {
    return {
      ...this.profile,
      unlockedLoadouts: [...this.profile.unlockedLoadouts],
      preferences: { ...this.profile.preferences },
      rewardedRunIds: [...this.profile.rewardedRunIds],
    };
  }

  purchaseLoadout(loadoutId: LoadoutId): PurchaseResult {
    const loadout = LOADOUTS.find((candidate) => candidate.id === loadoutId);
    if (!loadout) return { ok: false, persisted: false, reason: "invalid-loadout" };
    if (this.profile.unlockedLoadouts.includes(loadoutId)) return { ok: true, persisted: this.persistProfile() };
    if (this.profile.gold < loadout.price) return { ok: false, persisted: false, reason: "insufficient-gold" };
    this.profile.gold -= loadout.price;
    this.profile.unlockedLoadouts.push(loadoutId);
    return { ok: true, persisted: this.persistProfile() };
  }

  selectLoadout(loadoutId: LoadoutId): { ok: boolean; persisted: boolean } {
    if (!isLoadoutId(loadoutId) || !this.profile.unlockedLoadouts.includes(loadoutId)) return { ok: false, persisted: false };
    this.profile.selectedLoadout = loadoutId;
    return { ok: true, persisted: this.persistProfile() };
  }

  setPreferences(patch: Partial<Preferences>): { persisted: boolean } {
    this.profile.preferences = sanitizePreferences(patch, this.profile.preferences);
    return { persisted: this.persistProfile() };
  }

  settleRun(runId: string, run: RunSummary): SettlementResult {
    if (!isRunId(runId)) return this.settlementResult(0, false, false);
    if (this.profile.rewardedRunIds.includes(runId)) return this.settlementResult(0, true, this.persistProfile());
    if (!isValidRunSummary(run) || this.profile.rewardedRunIds.length >= MAX_REWARDED_RUN_IDS) return this.settlementResult(0, false, false);
    const awarded = Math.min(MAX_PROFILE_GOLD - this.profile.gold, calculateRunReward(run));
    this.profile.gold += awarded;
    this.profile.totalRuns = Math.min(MAX_PROFILE_COUNTER, this.profile.totalRuns + 1);
    if (run.outcome === "victory" && isRunRewardEligible(run)) this.profile.victories = Math.min(this.profile.totalRuns, this.profile.victories + 1);
    this.profile.bestSeconds = Math.max(this.profile.bestSeconds, run.elapsedMs / 1000);
    this.profile.rewardedRunIds.push(runId);
    return this.settlementResult(awarded, false, this.persistProfile());
  }

  private settlementResult(awarded: number, duplicate: boolean, persisted: boolean): SettlementResult {
    return { awarded, duplicate, persisted, profile: this.getProfile() };
  }

  private readProfile(): Profile {
    let serialized: string | null | undefined;
    try {
      serialized = this.storage?.getItem(PROFILE_STORAGE_KEY);
    } catch {
      this.initializationReadFailed = true;
      return createDefaultProfile();
    }
    if (typeof serialized !== "string" || serialized.length > MAX_SERIALIZED_PROFILE_LENGTH) return createDefaultProfile();
    try {
      return sanitizeProfile(JSON.parse(serialized));
    } catch {
      return createDefaultProfile();
    }
  }

  private persistProfile(): boolean {
    if (!this.storage || this.initializationReadFailed) return false;
    try {
      this.storage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(this.profile));
      return true;
    } catch {
      return false;
    }
  }
}
