export function distanceSquared(ax: number, ay: number, bx: number, by: number): number {
  const dx = bx - ax;
  const dy = by - ay;
  return dx * dx + dy * dy;
}

export function normalize(x: number, y: number): { x: number; y: number } {
  const length = Math.hypot(x, y);
  if (length <= 0.0001) {
    return { x: 0, y: 0 };
  }

  return { x: x / length, y: y / length };
}

export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

/** First normalized time a moving point touches a circle, including an initial overlap. */
export function sweepTime(from: { x: number; y: number }, to: { x: number; y: number }, target: { x: number; y: number }, r: number): number | undefined {
  const x = target.x - from.x, y = target.y - from.y;
  const dx = to.x - from.x, dy = to.y - from.y;
  const c = x * x + y * y - r * r;
  if (c <= 0) return 0;
  const a = dx * dx + dy * dy;
  const b = x * dx + y * dy;
  const d = b * b - a * c;
  if (a <= 0 || d < 0) return undefined;
  const time = (b - Math.sqrt(d)) / a;
  return time >= 0 && time <= 1 ? time : undefined;
}
