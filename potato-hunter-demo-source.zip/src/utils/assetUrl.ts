const base = (() => {
  const viteBase = import.meta.env?.BASE_URL;
  const candidate = typeof viteBase === "string" && viteBase.length > 0 ? viteBase : "/";
  return candidate.endsWith("/") ? candidate : `${candidate}/`;
})();

/** Resolves public assets for localhost, GitHub Pages, and non-Vite test bundles. */
export function assetUrl(path: string): string {
  return `${base}${path.replace(/^\/+/, "")}`;
}
