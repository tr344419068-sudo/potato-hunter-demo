export interface RunSnapshot { elapsedMs: number; level: number; hp: number; maxHp: number; entities: number }
export interface RunReport { seed: number; damageBySource: Record<string, number>; healing: number; snapshots: RunSnapshot[] }
export class RunTelemetry {
  private readonly damageBySource: Record<string, number> = {};
  private healing = 0;
  private nextSnapshotAt = 0;
  private readonly snapshots: RunSnapshot[] = [];
  constructor(private readonly seed: number) {}
  recordHealthChange(before: number, after: number, source: string): void {
    if (!Number.isFinite(before) || !Number.isFinite(after) || before <= 0) return;
    const delta = Math.max(0, after) - before;
    if (delta < 0) this.damageBySource[source] = (this.damageBySource[source] ?? 0) - delta;
    else this.healing += delta;
  }
  snapshot(snapshot: RunSnapshot): void {
    if (!Object.values(snapshot).every(Number.isFinite) || snapshot.elapsedMs < this.nextSnapshotAt) return;
    this.nextSnapshotAt = snapshot.elapsedMs + 10_000;
    this.snapshots.push({ ...snapshot });
    if (this.snapshots.length > 256) this.snapshots.shift();
  }
  getReport(): RunReport { return { seed: this.seed, damageBySource: { ...this.damageBySource }, healing: this.healing, snapshots: this.snapshots.map(s => ({ ...s })) }; }
}
