import { isStageId, type StageId } from "../progression/CampaignGrowth";
import { ProgressionStore } from "../progression/ProgressionStore";

function browserStorage(): Storage | undefined {
  try { return typeof window !== "undefined" ? window.localStorage : undefined; } catch { return undefined; }
}
function readBossTestStage(): StageId | undefined {
  if (typeof window === "undefined") return;
  const stage = new URLSearchParams(window.location.search).get("boss-test");
  return isStageId(stage) ? stage : undefined;
}

export const bossTestStage = import.meta.env?.DEV ? readBossTestStage() : undefined;
const practiceStorage = new Map<string, string>();
export const progression = new ProgressionStore(bossTestStage ? {
  getItem: key => practiceStorage.get(key) ?? browserStorage()?.getItem(key) ?? null,
  setItem: (key, value) => { practiceStorage.set(key, value); },
} : browserStorage());
export function createRunIdentity(seed?: number): { seed: number; runId: string } {
  const nextSeed = seed === undefined ? Math.floor(Math.random() * 0xffffffff) : seed >>> 0;
  const nonce = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return { seed: nextSeed, runId: `run-${nonce}` };
}
