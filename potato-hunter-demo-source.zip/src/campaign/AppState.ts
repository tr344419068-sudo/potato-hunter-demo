import { ProgressionStore } from "../progression/ProgressionStore";

function browserStorage(): Storage | undefined {
  try { return typeof window !== "undefined" ? window.localStorage : undefined; } catch { return undefined; }
}
export const progression = new ProgressionStore(browserStorage());
export function createRunIdentity(seed?: number): { seed: number; runId: string } {
  const nextSeed = seed === undefined ? Math.floor(Math.random() * 0xffffffff) : seed >>> 0;
  const nonce = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return { seed: nextSeed, runId: `run-${nonce}` };
}
