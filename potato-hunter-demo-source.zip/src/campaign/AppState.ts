import { isStageId, type StageId } from "../progression/CampaignGrowth";
import { ProgressionStore } from "../progression/ProgressionStore";

function browserStorage(): Storage | undefined {
  try { return typeof window !== "undefined" ? window.localStorage : undefined; } catch { return undefined; }
}
function readTestStage(param: string): StageId | undefined {
  if (typeof window === "undefined") return;
  const stage = new URLSearchParams(window.location.search).get(param);
  return isStageId(stage) ? stage : undefined;
}

export const bossTestStage = import.meta.env?.DEV ? readTestStage("boss-test") : undefined;
export function readCrescentTestRank(search: string): number | undefined {
  const rank = new URLSearchParams(search).get("crescent-test");
  return rank && /^[1-5]$/.test(rank) ? Number(rank) : undefined;
}
export const crescentTestRank = import.meta.env?.DEV && !bossTestStage && typeof window !== "undefined" ? readCrescentTestRank(window.location.search) : undefined;
export const stageTestStage = import.meta.env?.DEV && !bossTestStage ? crescentTestRank ? "meadow" : readTestStage("stage-test") : undefined;
const practiceStorage = new Map<string, string>();
export const progression = new ProgressionStore(bossTestStage || stageTestStage ? {
  getItem: key => practiceStorage.get(key) ?? browserStorage()?.getItem(key) ?? null,
  setItem: (key, value) => { practiceStorage.set(key, value); },
} : browserStorage());
export function createRunIdentity(seed?: number): { seed: number; runId: string } {
  const nextSeed = seed === undefined ? Math.floor(Math.random() * 0xffffffff) : seed >>> 0;
  const nonce = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return { seed: nextSeed, runId: `run-${nonce}` };
}
