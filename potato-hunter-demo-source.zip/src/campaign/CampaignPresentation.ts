import { GameAudio, type AudioEventPort, type GameAudioOptions } from "../audio/GameAudio";
import type { AudioState } from "../audio/CombatAudioModel";
import type { Preferences } from "../progression/ProgressionStore";

interface PresentationEvents extends AudioEventPort { emit(event: string, payload?: unknown): unknown }

/** Bridges run state and persisted preferences without making gameplay depend on audio. */
export class CampaignPresentation {
  private readonly audio: GameAudio;
  private readonly subscriptions: Array<[string, (payload?: any) => void]> = [];
  private atHome = true;
  private paused = false;
  private choosing = false;
  private bossActive = false;
  private ended = false;
  private destroyed = false;

  constructor(private readonly events: PresentationEvents, private preferences: Preferences, options: GameAudioOptions = {}) {
    // Register the chooser pause before GameAudio's cue listener: silence combat, then play the upgrade chime.
    this.subscribe("campaign:ready", ({ atHome }) => {
      this.atHome = atHome; this.paused = false; this.choosing = false; this.bossActive = false; this.ended = false;
      this.publishPreferences(); this.updateState();
    });
    this.subscribe("campaign:status", (status) => {
      if (this.ended) return;
      this.paused = Boolean(status.paused); this.choosing = Boolean(status.choosing); this.bossActive = Boolean(status.bossActive);
      this.updateState();
    });
    this.subscribe("campaign:paused", (paused) => { this.paused = Boolean(paused); this.updateState(); });
    this.subscribe("level:choices", () => { this.choosing = true; this.updateState(); });
    this.subscribe("game:over", (result) => { if (result.campaign) this.ended = true; });
    this.audio = new GameAudio(events, preferences, options);
  }
  unlockAudio = (): Promise<void> => this.audio.unlock();
  setPreferences = (preferences: Preferences): void => {
    if (this.destroyed) return;
    this.preferences = { ...preferences }; this.audio.setPreferences(preferences); this.publishPreferences();
  };
  getSnapshot(): ReturnType<GameAudio["getSnapshot"]> { return this.audio.getSnapshot(); }
  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    for (const [event, fn] of this.subscriptions) this.events.off(event, fn);
    this.subscriptions.length = 0; this.audio.destroy();
  }
  private subscribe(event: string, listener: (payload?: any) => void): void {
    this.events.on(event, listener); this.subscriptions.push([event, listener]);
  }
  private publishPreferences(): void { this.events.emit("presentation:preferences", { ...this.preferences }); }
  private updateState(): void {
    if (this.ended || this.destroyed) return;
    const state: AudioState = this.atHome ? "home" : this.paused || this.choosing ? "paused" : this.bossActive ? "boss" : "combat";
    this.audio.setState(state);
  }
}
