export const FINAL_BOSS_AT_MS = 360_000;
export const INTERMEDIATE_BOSS_TIMES = [60_000, 180_000, 300_000] as const;
export type RunOutcome = "victory" | "defeat";
export type BossKind = "intermediate" | "final";
export type CampaignPhase = "warmup" | "build" | "pressure" | "respite" | "finale";

export function getCampaignBeat(elapsedMs: number): { phase: CampaignPhase; spawnMultiplier: number; objective: string; title: string } {
  const t = Number.isFinite(elapsedMs) ? Math.max(0, elapsedMs) : 0;
  const cycle = t % 90_000;
  const phase = t < 60_000 ? "warmup" : t >= FINAL_BOSS_AT_MS ? "finale" : cycle >= 70_000 ? "respite" : cycle >= 55_000 ? "pressure" : "build";
  const labels = {
    warmup: ["青酱草甸", "积累经验，找到你的核心技能"],
    build: ["构筑成长", "收集经验，补齐流派组件"],
    pressure: ["精英挑战", "保持退路，优先击破危险怪"],
    respite: ["补给窗口", "收集经验，寻找补给"],
    finale: ["最终首领", "击败堡垒暴君，完成远征"],
  };
  return { phase, spawnMultiplier: phase === "respite" ? .38 : phase === "pressure" ? 1.08 : phase === "finale" ? .65 : 1, title: labels[phase][0], objective: labels[phase][1] };
}

/** Run-owned randomness; never modifies the browser's global Math.random. */
export class CampaignDirector {
  private randomState: number;
  private readonly spawnedTimes = new Set<number>();
  private finalBossId?: number;
  private finalSpawned = false;
  private rescueAt = 20_000;
  outcome?: RunOutcome;
  constructor(readonly seed: number) { this.randomState = (Number.isFinite(seed) ? seed : 1) >>> 0; }
  random(): number {
    let value = this.randomState += 0x6d2b79f5;
    value = Math.imul(value ^ value >>> 15, value | 1);
    value ^= value + Math.imul(value ^ value >>> 7, value | 61);
    return ((value ^ value >>> 14) >>> 0) / 4294967296;
  }
  nextBoss(elapsedMs: number): BossKind | undefined {
    if (this.outcome || this.finalSpawned) return;
    if (elapsedMs >= FINAL_BOSS_AT_MS) { this.finalSpawned = true; return "final"; }
    const time = INTERMEDIATE_BOSS_TIMES.find(t => elapsedMs >= t && !this.spawnedTimes.has(t));
    if (time !== undefined) { this.spawnedTimes.add(time); return "intermediate"; }
  }
  registerBoss(id: number, kind: BossKind): void { if (kind === "final") this.finalBossId = id; }
  onMonsterDefeated(id: number, playerAlive: boolean): boolean { return !this.outcome && playerAlive && id === this.finalBossId; }
  finish(outcome: RunOutcome): boolean { if (this.outcome) return false; this.outcome = outcome; return true; }
  shouldRescue(elapsedMs: number, healthRatio: number): boolean {
    if (this.outcome || !Number.isFinite(healthRatio) || healthRatio <= 0 || healthRatio > .35 || elapsedMs < this.rescueAt) return false;
    this.rescueAt = elapsedMs + 75_000;
    return true;
  }
}
