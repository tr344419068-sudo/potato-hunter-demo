import { getCampaignStage, type StageId } from '../progression/CampaignGrowth';

export const FINAL_BOSS_AT_MS = getCampaignStage('meadow').finaleMs;
export const INTERMEDIATE_BOSS_TIMES = getCampaignStage('meadow').eliteMs;
export const getFinalBossAtMs = (stage?: StageId): number => getCampaignStage(stage).finaleMs;
export type RunOutcome = "victory" | "defeat";
export type BossKind = "intermediate" | "final";
export type CampaignPhase = "warmup" | "build" | "pressure" | "respite" | "finale";

export function getCampaignBeat(elapsedMs: number, stage: StageId = "meadow"): { phase: CampaignPhase; spawnMultiplier: number; objective: string; title: string } {
  const t = Number.isFinite(elapsedMs) ? Math.max(0, elapsedMs) : 0;
  const { name, bossName, finaleMs } = getCampaignStage(stage);
  if (stage === 'snow') {
    if (t >= finaleMs) return { phase: 'finale', spawnMultiplier: 0, title: '霜炉决战', objective: `击败${bossName}，完成远征` };
    if (t >= 228_000) return { phase: 'respite', spawnMultiplier: .28, title: '雪崩前夕', objective: '收集经验，准备迎战' };
    if (t >= 192_000) return { phase: 'pressure', spawnMultiplier: 1.18, title: '峡谷夹击', objective: '利用冰岩挡雪针，引滚兽撞岩' };
    if (t >= 55_000) return { phase: 'build', spawnMultiplier: 1.04, title: '霜盾进逼', objective: '绕开正面盾牌，优先清除投手' };
    return { phase: 'warmup', spawnMultiplier: 1, title: name, objective: '绕开冰岩走位，借冰岩挡雪针' };
  }
  const cycle = t % 90_000;
  const phase = t < 60_000 ? "warmup" : t >= finaleMs ? "finale" : cycle >= 70_000 ? "respite" : cycle >= 55_000 ? "pressure" : "build";
  const labels = {
    warmup: [name, "积累经验，找到你的核心技能"],
    build: ["构筑成长", "收集经验，补齐流派组件"],
    pressure: ["精英挑战", "保持退路，优先击破危险怪"],
    respite: ["补给窗口", "收集经验，寻找补给"],
    finale: ["最终首领", `击败${bossName}，完成远征`],
  };
  return { phase, spawnMultiplier: phase === "respite" ? .38 : phase === "pressure" ? 1.08 : phase === "finale" ? .65 : 1, title: labels[phase][0], objective: labels[phase][1] };
}

/** Run-owned randomness; never modifies the browser's global Math.random. */
export class CampaignDirector {
  private randomState: number;
  private readonly spawnedTimes = new Set<number>();
  private finalBossId?: number;
  private finalSpawned = false;
  private finalDefeated = false;
  private openingEliteId?: number;
  private eliteRespiteUntil = 0;
  private rescueAt = 20_000;
  outcome?: RunOutcome;
  constructor(readonly seed: number, private readonly stage: StageId = 'meadow') { this.randomState = (Number.isFinite(seed) ? seed : 1) >>> 0; }
  random(): number {
    let value = this.randomState += 0x6d2b79f5;
    value = Math.imul(value ^ value >>> 15, value | 1);
    value ^= value + Math.imul(value ^ value >>> 7, value | 61);
    return ((value ^ value >>> 14) >>> 0) / 4294967296;
  }
  nextBoss(elapsedMs: number): BossKind | undefined {
    if (this.outcome || this.finalSpawned) return;
    const { finaleMs, eliteMs } = getCampaignStage(this.stage);
    if (elapsedMs >= finaleMs) { this.finalSpawned = true; return "final"; }
    const time = eliteMs.find(t => elapsedMs >= t && !this.spawnedTimes.has(t));
    if (time !== undefined) { this.spawnedTimes.add(time); return "intermediate"; }
  }
  registerBoss(id: number, kind: BossKind): void {
    if (kind === "final") this.finalBossId = id;
    else if (this.spawnedTimes.size === 1 && this.openingEliteId === undefined) this.openingEliteId = id;
  }
  recordOpeningEliteDefeat(id: number, playerAlive: boolean, elapsedMs: number, stage?: StageId): boolean {
    if (stage !== "meadow" || this.outcome || !playerAlive || id !== this.openingEliteId || this.eliteRespiteUntil || elapsedMs >= FINAL_BOSS_AT_MS) return false;
    this.eliteRespiteUntil = elapsedMs + 9_000;
    return true;
  }
  getBeat(elapsedMs: number, stage: StageId = this.stage): ReturnType<typeof getCampaignBeat> {
    const beat = getCampaignBeat(elapsedMs, stage);
    if (stage !== "meadow" || this.outcome || elapsedMs >= this.eliteRespiteUntil || beat.phase === "finale") return beat;
    return { phase: "respite", spawnMultiplier: .38, title: "精英击破", objective: "清理余怪，收集经验" };
  }
  isFinalBoss(id: number): boolean { return id === this.finalBossId; }
  hasDefeatedFinalBoss(): boolean { return this.finalDefeated; }
  onMonsterDefeated(id: number, playerAlive: boolean, remainingMonsters = 0): boolean {
    if (this.outcome || !playerAlive) return false;
    if (this.isFinalBoss(id)) this.finalDefeated = true;
    return this.finalDefeated && remainingMonsters === 0;
  }
  finish(outcome: RunOutcome): boolean { if (this.outcome) return false; this.outcome = outcome; return true; }
  shouldRescue(elapsedMs: number, healthRatio: number): boolean {
    if (this.outcome || !Number.isFinite(healthRatio) || healthRatio <= 0 || healthRatio > .35 || elapsedMs < this.rescueAt) return false;
    this.rescueAt = elapsedMs + 75_000;
    return true;
  }
}
