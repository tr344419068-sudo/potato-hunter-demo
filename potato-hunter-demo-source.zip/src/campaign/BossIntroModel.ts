const COUNTDOWN_MS = 3000;
const START_CAPTION_MS = 650;
export const BOSS_INTRO_MS = COUNTDOWN_MS + START_CAPTION_MS;

export type BossIntroFrame = { text: "3" | "2" | "1" | "对决开始"; progress: number };

export function getBossIntroFrame(elapsedMs: number): BossIntroFrame {
  if (elapsedMs >= COUNTDOWN_MS) {
    return { text: "对决开始", progress: (elapsedMs - COUNTDOWN_MS) / START_CAPTION_MS };
  }
  const beat = Math.floor(elapsedMs / 1000);
  return { text: (["3", "2", "1"] as const)[beat], progress: (elapsedMs % 1000) / 1000 };
}
