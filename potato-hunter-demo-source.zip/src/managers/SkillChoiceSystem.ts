import Phaser from "phaser";
import { ConfigManager, type SkillConfig } from "./ConfigManager";
import type { SkillChoiceHint, SkillLevelsReader } from "./SkillTypes";
import { BuildHintSystem } from "./BuildHintSystem";
import { UPGRADE_REWARD_CHOICES } from "./RewardManager";
import { SkillEvolutionSystem } from "./SkillEvolutionSystem";

export class SkillChoiceSystem {
  private readonly evolutionSystem: SkillEvolutionSystem;
  private readonly buildHintSystem: BuildHintSystem;

  constructor(private readonly skills: SkillLevelsReader) {
    this.evolutionSystem = new SkillEvolutionSystem(skills);
    this.buildHintSystem = new BuildHintSystem(skills);
  }

  getChoices(count: number, excludedIds: ReadonlySet<string> = new Set()): SkillConfig[] {
    const evolutionChoices = ConfigManager.skillEvolutions
      .filter((evolution) => this.evolutionSystem.canUnlockEvolution(evolution.resultSkillId))
      .map((evolution) => ConfigManager.getSkill(evolution.resultSkillId));
    const activeChoices = ConfigManager.skills.filter((skill) => skill.category === "active" && this.canOffer(skill.id) && this.skills.getLevel(skill.id) < skill.maxLevel);

    this.shuffle(activeChoices);
    this.shuffle(evolutionChoices);

    const earlyActiveAnchor = this.skills.getKnownSkills().filter((skill) => skill.category === "active").length < 2
      ? activeChoices.slice(0, 1)
      : [];
    const normalChoices = ConfigManager.skills.filter((skill) => {
      if (skill.category === "evolution" && !this.skills.hasSkill(skill.id)) {
        return false;
      }
      if (earlyActiveAnchor.some((choice) => choice.id === skill.id)) {
        return false;
      }
      return this.canOffer(skill.id) && this.skills.getLevel(skill.id) < skill.maxLevel;
    });

    const weightedChoices = this.getWeightedChoices(normalChoices);
    return this.fillChoices([...evolutionChoices, ...earlyActiveAnchor, ...weightedChoices], count, excludedIds);
  }

  getChoiceHints(choices: SkillConfig[]): SkillChoiceHint[] {
    return choices.map((choice) => {
      if (choice.category === "reward") {
        return {
          skillId: choice.id,
          buildHints: ["即时补给"],
          progressHints: [],
        };
      }

      return {
        skillId: choice.id,
        buildHints: this.buildHintSystem.getBuildHints(choice),
        evolutionHint: this.evolutionSystem.getEvolutionHint(choice),
        progressHints: this.evolutionSystem.getProgressHints(choice),
      };
    });
  }

  private fillChoices(choices: SkillConfig[], count: number, excludedIds: ReadonlySet<string>): SkillConfig[] {
    const result: SkillConfig[] = [];
    for (const choice of choices) {
      if (excludedIds.has(choice.id) || result.some((selected) => selected.id === choice.id)) {
        continue;
      }
      result.push(choice);
      if (result.length >= count) {
        return result;
      }
    }

    const fallbackRewards = [...UPGRADE_REWARD_CHOICES];
    this.shuffle(fallbackRewards);
    for (const reward of fallbackRewards) {
      if (excludedIds.has(reward.id) || result.some((selected) => selected.id === reward.id)) {
        continue;
      }
      result.push(reward);
      if (result.length >= count) {
        return result;
      }
    }

    for (const choice of [...choices, ...fallbackRewards]) {
      if (result.some((selected) => selected.id === choice.id)) {
        continue;
      }
      result.push(choice);
      if (result.length >= count) {
        return result;
      }
    }

    return result;
  }

  private getWeightedChoices(choices: SkillConfig[]): SkillConfig[] {
    const ownedTags = this.getOwnedTags();
    const weighted: SkillConfig[] = [];

    for (const choice of choices) {
      const affinity = choice.tags.filter((tag) => ownedTags.has(tag)).length;
      const buildAffinity = this.getBuildAffinity(choice, ownedTags);
      const weight = 1 + Math.min(2, affinity + buildAffinity);

      for (let index = 0; index < weight; index += 1) {
        weighted.push(choice);
      }
    }

    this.shuffle(weighted);
    const result: SkillConfig[] = [];
    for (const choice of weighted) {
      if (result.some((selected) => selected.id === choice.id)) {
        continue;
      }
      result.push(choice);
    }
    return result;
  }

  private getBuildAffinity(choice: SkillConfig, ownedTags: Set<string>): number {
    return ConfigManager.builds.some((build) => {
      const choiceFitsBuild = choice.tags.some((tag) => build.tags.includes(tag)) || build.coreSkills.includes(choice.id);
      const playerHasBuildTag = build.tags.some((tag) => ownedTags.has(tag));
      return choiceFitsBuild && playerHasBuildTag;
    }) ? 1 : 0;
  }

  private getOwnedTags(): Set<string> {
    const tags = new Set<string>();
    for (const skill of ConfigManager.skills) {
      if (this.skills.getLevel(skill.id) <= 0) {
        continue;
      }

      for (const tag of skill.tags) {
        tags.add(tag);
      }
    }
    return tags;
  }

  private canOffer(id: string): boolean { return this.skills.canLearnSkill?.(id) ?? true; }
  private shuffle<T>(items: T[]): void {
    const random = this.skills.getRandom?.();
    if (!random) { Phaser.Utils.Array.Shuffle(items); return; }
    for (let i = items.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [items[i], items[j]] = [items[j], items[i]]; }
  }
}
