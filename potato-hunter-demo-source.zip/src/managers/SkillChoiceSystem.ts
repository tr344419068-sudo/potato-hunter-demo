import Phaser from "phaser";
import { ConfigManager, type SkillConfig } from "./ConfigManager";
import type { SkillChoiceHint, SkillLevelsReader } from "./SkillTypes";
import { BuildHintSystem } from "./BuildHintSystem";
import { UPGRADE_REWARD_CHOICES } from "./RewardManager";
import { SkillEvolutionSystem } from "./SkillEvolutionSystem";

const MEADOW_INTRO_SKILLS = new Set(["pepper_gatling", "hot_oil_flask", "skewer_javelin"]);

export class SkillChoiceSystem {
  private readonly evolutionSystem: SkillEvolutionSystem;
  private readonly buildHintSystem: BuildHintSystem;
  private readonly guidedAt = new Map<string, number>();
  private draftSequence = 0;
  private regularDrafts = 0;
  private readonly shownShowcase = new Set<string>();

  constructor(private readonly skills: SkillLevelsReader, private readonly meadowIntro = false) {
    this.evolutionSystem = new SkillEvolutionSystem(skills);
    this.buildHintSystem = new BuildHintSystem(skills);
  }

  getChoices(count: number, excludedIds: ReadonlySet<string> = new Set()): SkillConfig[] {
    const evolutionChoices = ConfigManager.skillEvolutions
      .filter((evolution) => this.canOffer(evolution.resultSkillId) && this.evolutionSystem.canUnlockEvolution(evolution.resultSkillId))
      .map((evolution) => ConfigManager.getSkill(evolution.resultSkillId));
    const activeChoices = ConfigManager.skills.filter((skill) => skill.category === "active" && this.canOffer(skill.id) && this.skills.getLevel(skill.id) < skill.maxLevel);

    this.shuffle(activeChoices);
    this.shuffle(evolutionChoices);

    const earlyActiveAnchor = this.skills.getKnownSkills().filter((skill) => skill.category === "active").length < 2
      ? activeChoices.slice(0, 1)
      : [];
    const normalChoices = ConfigManager.skills.filter((skill) => {
      if (skill.category === "evolution" && !this.skills.hasSkill(skill.id)) {
        return false;
      }
      if (earlyActiveAnchor.some((choice) => choice.id === skill.id)) {
        return false;
      }
      return this.canOffer(skill.id) && this.skills.getLevel(skill.id) < skill.maxLevel;
    });

    const weightedChoices = this.getWeightedChoices(normalChoices);
    // In the meadow, passing on a ready evolution must not strand the build
    // the player is investing in. The ready evolution still takes first place.
    const progressionChoice = count >= 3 && (this.meadowIntro || evolutionChoices.every(choice => excludedIds.has(choice.id)))
      ? this.getRecipeProgressChoice(excludedIds) : undefined;
    const draft = count === 3 && excludedIds.size === 0 ? ++this.regularDrafts : 0;
    const isShowcase = (skill: SkillConfig) => this.meadowIntro ? MEADOW_INTRO_SKILLS.has(skill.id) : skill.earlyShowcase;
    const introducesRoute = this.meadowIntro ? draft > 0 && draft <= MEADOW_INTRO_SKILLS.size : draft === 2 || draft === 4;
    const introduction = introducesRoute ? activeChoices.find(skill =>
      isShowcase(skill) && !this.skills.hasSkill(skill.id) && !this.shownShowcase.has(skill.id)) : undefined;
    const introSlot = introduction ? [introduction] : [];
    const choices = this.fillChoices([...evolutionChoices, ...earlyActiveAnchor,
      ...(progressionChoice ? [progressionChoice.skill] : []), ...introSlot, ...weightedChoices], count, excludedIds);
    for (const skill of choices) if (isShowcase(skill)) this.shownShowcase.add(skill.id);
    if (progressionChoice && choices.some(skill => skill.id === progressionChoice.skill.id)) {
      this.guidedAt.set(progressionChoice.recipeId, ++this.draftSequence);
    }
    return choices;
  }

  private getRecipeProgressChoice(excludedIds: ReadonlySet<string>): { skill: SkillConfig; recipeId: string } | undefined {
    const starter = this.skills.getStarterSkillId?.();
    const candidates: Array<{ skill: SkillConfig; recipeId: string; missingRanks: number; activeRank: number; lane: number }> = [];
    for (const recipe of ConfigManager.skillEvolutions) {
      if (!recipe.guideAfterActiveLevel || !this.canOffer(recipe.resultSkillId) || this.skills.hasSkill(recipe.resultSkillId)) continue;
      const requirements = recipe.requiredSkills ?? [];
      const active = requirements.find(required => ConfigManager.getSkill(required.id).category === "active");
      if (!active) continue;
      const activeRank = this.skills.getLevel(active.id);
      const hasCompanion = requirements.some(required => required.id !== active.id && this.skills.getLevel(required.id) >= required.level);
      if (activeRank < recipe.guideAfterActiveLevel && !hasCompanion) continue;
      const missing = requirements.filter(required => this.skills.getLevel(required.id) < required.level);
      const valid = missing.filter(required => !excludedIds.has(required.id) && this.canOffer(required.id));
      if (!valid.length || missing.some(required => !this.canOffer(required.id))) continue;
      const next = (activeRank <= 1 ? valid.find(required => required.id === active.id) : valid.find(required => required.id !== active.id)) ?? valid[0];
      // Invested active > a chosen companion > an untouched starter.
      const lane = activeRank === 0 ? 1 : active.id === starter && activeRank === 1 && !hasCompanion ? 2 : 0;
      candidates.push({ skill: ConfigManager.getSkill(next.id), recipeId: recipe.id, activeRank, lane,
        missingRanks: missing.reduce((sum, required) => sum + required.level - this.skills.getLevel(required.id), 0) });
    }
    return candidates.sort((a, b) => a.lane - b.lane
      // Repeatedly passing on one invested route should not block all the others.
      || (this.guidedAt.get(a.recipeId) ?? 0) - (this.guidedAt.get(b.recipeId) ?? 0)
      || a.missingRanks - b.missingRanks || b.activeRank - a.activeRank)[0];
  }

  getChoiceHints(choices: SkillConfig[]): SkillChoiceHint[] {
    return choices.map((choice) => {
      if (choice.category === "reward") {
        return {
          skillId: choice.id,
          buildHints: ["即时补给"],
          progressHints: [],
        };
      }

      return {
        skillId: choice.id,
        buildHints: this.buildHintSystem.getBuildHints(choice),
        evolutionHint: this.evolutionSystem.getEvolutionHint(choice),
        progressHints: this.evolutionSystem.getProgressHints(choice),
        ...this.evolutionSystem.getCardRecipe(choice),
      };
    });
  }

  private fillChoices(choices: SkillConfig[], count: number, excludedIds: ReadonlySet<string>): SkillConfig[] {
    const result: SkillConfig[] = [];
    for (const choice of choices) {
      if (excludedIds.has(choice.id) || result.some((selected) => selected.id === choice.id)) {
        continue;
      }
      result.push(choice);
      if (result.length >= count) {
        return result;
      }
    }

    const fallbackRewards = [...UPGRADE_REWARD_CHOICES];
    this.shuffle(fallbackRewards);
    for (const reward of fallbackRewards) {
      if (excludedIds.has(reward.id) || result.some((selected) => selected.id === reward.id)) {
        continue;
      }
      result.push(reward);
      if (result.length >= count) {
        return result;
      }
    }

    for (const choice of [...choices, ...fallbackRewards]) {
      if (result.some((selected) => selected.id === choice.id)) {
        continue;
      }
      result.push(choice);
      if (result.length >= count) {
        return result;
      }
    }

    return result;
  }

  private getWeightedChoices(choices: SkillConfig[]): SkillConfig[] {
    const ownedTags = this.getOwnedTags();
    const weighted: SkillConfig[] = [];

    for (const choice of choices) {
      const affinity = choice.tags.filter((tag) => ownedTags.has(tag)).length;
      const buildAffinity = this.getBuildAffinity(choice, ownedTags);
      const weight = 1 + Math.min(2, affinity + buildAffinity);

      for (let index = 0; index < weight; index += 1) {
        weighted.push(choice);
      }
    }

    this.shuffle(weighted);
    const result: SkillConfig[] = [];
    for (const choice of weighted) {
      if (result.some((selected) => selected.id === choice.id)) {
        continue;
      }
      result.push(choice);
    }
    return result;
  }

  private getBuildAffinity(choice: SkillConfig, ownedTags: Set<string>): number {
    return ConfigManager.builds.some((build) => {
      const choiceFitsBuild = choice.tags.some((tag) => build.tags.includes(tag)) || build.coreSkills.includes(choice.id);
      const playerHasBuildTag = build.tags.some((tag) => ownedTags.has(tag));
      return choiceFitsBuild && playerHasBuildTag;
    }) ? 1 : 0;
  }

  private getOwnedTags(): Set<string> {
    const tags = new Set<string>();
    for (const skill of ConfigManager.skills) {
      if (this.skills.getLevel(skill.id) <= 0) {
        continue;
      }

      for (const tag of skill.tags) {
        tags.add(tag);
      }
    }
    return tags;
  }

  private canOffer(id: string): boolean {
    return ConfigManager.getSkill(id).choicePoolEnabled !== false && (this.skills.canLearnSkill?.(id) ?? true);
  }
  private shuffle<T>(items: T[]): void {
    const random = this.skills.getRandom?.();
    if (!random) { Phaser.Utils.Array.Shuffle(items); return; }
    for (let i = items.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [items[i], items[j]] = [items[j], items[i]]; }
  }
}
