import { ConfigManager, type BuildConfig, type SkillConfig } from "./ConfigManager";
import type { SkillLevelsReader } from "./SkillTypes";

export class BuildHintSystem {
  constructor(private readonly skills: SkillLevelsReader) {}

  getActiveBuilds(): BuildConfig[] {
    const ownedTags = this.getOwnedTags();
    return ConfigManager.builds.filter((build) => build.tags.every((tag) => ownedTags.has(tag)));
  }

  getBuildHints(skill: SkillConfig): string[] {
    if (skill.category === "reward") {
      return ["即时补给"];
    }

    const ownedSkillIds = new Set(this.skills.getKnownSkills().map((knownSkill) => knownSkill.id));
    const ownedTags = this.getOwnedTags();
    const nextTags = new Set([...ownedTags, ...skill.tags]);
    const hints = ConfigManager.builds
      .map((build) => {
        const isCore = build.coreSkills.includes(skill.id);
        const matchingTags = build.tags.filter((tag) => nextTags.has(tag)).length;
        const ownedCoreCount = build.coreSkills.filter((skillId) => ownedSkillIds.has(skillId) || skillId === skill.id).length;
        return {
          build,
          score: (isCore ? 3 : 0) + matchingTags + ownedCoreCount,
          isCore,
          ownedCoreCount,
        };
      })
      .filter((item) => item.score >= 2)
      .sort((a, b) => b.score - a.score)
      .slice(0, 2)
      .map((item) => {
        if (item.isCore) {
          return `${item.build.name}核心 ${item.ownedCoreCount}/${item.build.coreSkills.length}`;
        }
        if (item.ownedCoreCount > 0) {
          return `补强${item.build.name} ${item.ownedCoreCount}/${item.build.coreSkills.length}`;
        }
        return `${item.build.name}组件`;
      });

    return hints.length > 0 ? hints : [`${this.getPrimaryTagLabel(skill)}组件`];
  }

  private getOwnedTags(): Set<string> {
    const tags = new Set<string>();
    for (const skill of ConfigManager.skills) {
      if (this.skills.getLevel(skill.id) <= 0) {
        continue;
      }

      for (const tag of skill.tags) {
        tags.add(tag);
      }
    }
    return tags;
  }

  private getPrimaryTagLabel(skill: SkillConfig): string {
    const labels: Record<string, string> = {
      attack_speed: "攻速",
      burst: "连发",
      tempo: "连击",
      projectile: "弹幕",
      fire: "火焰",
      ice: "冰控",
      lightning: "雷链",
      aoe: "范围",
      defense: "生存",
      growth: "成长",
      crit: "暴击",
      poison: "毒伤",
      trail: "路径陷阱",
      turret: "定点炮台",
      move_speed: "移动",
    };
    const tag = skill.tags.find((candidate) => labels[candidate]);
    return tag ? labels[tag] : "Build";
  }
}
