import type { EntityId } from "../components/ComponentTypes";
import type { World } from "../entities/World";

const projectilePools = new WeakMap<World, EntityId[]>();
const expOrbPools = new WeakMap<World, EntityId[]>();
const damageTextPools = new WeakMap<Phaser.Scene, Phaser.GameObjects.Text[]>();
const graphicsPools = new WeakMap<Phaser.Scene, Phaser.GameObjects.Graphics[]>();

function getPool(map: WeakMap<World, EntityId[]>, world: World): EntityId[] {
  let pool = map.get(world);
  if (!pool) {
    pool = [];
    map.set(world, pool);
  }
  return pool;
}

export const EntityPools = {
  acquireProjectile(world: World): EntityId {
    return getPool(projectilePools, world).pop() ?? world.createEntity();
  },

  releaseProjectile(world: World, entityId: EntityId): void {
    world.clearComponents(entityId);
    getPool(projectilePools, world).push(entityId);
  },

  acquireExpOrb(world: World): EntityId {
    return getPool(expOrbPools, world).pop() ?? world.createEntity();
  },

  releaseExpOrb(world: World, entityId: EntityId): void {
    world.clearComponents(entityId);
    getPool(expOrbPools, world).push(entityId);
  },

  acquireDamageText(scene: Phaser.Scene): Phaser.GameObjects.Text {
    const pool = getScenePool(damageTextPools, scene);
    const text = pool.pop() ?? scene.add.text(0, 0, "", {
      fontFamily: "system-ui, sans-serif",
    });
    text.setActive(true);
    text.setVisible(true);
    text.setAlpha(1);
    text.setScale(1);
    return text;
  },

  releaseDamageText(scene: Phaser.Scene, text: Phaser.GameObjects.Text): void {
    text.setVisible(false);
    text.setActive(false);
    getScenePool(damageTextPools, scene).push(text);
  },

  acquireGraphics(scene: Phaser.Scene): Phaser.GameObjects.Graphics {
    const pool = getScenePool(graphicsPools, scene);
    const graphics = pool.pop() ?? scene.add.graphics();
    graphics.setActive(true);
    graphics.setVisible(true);
    graphics.setAlpha(1);
    graphics.setPosition(0, 0);
    graphics.setScale(1);
    graphics.setRotation(0);
    graphics.setDepth(0);
    graphics.clear();
    return graphics;
  },

  releaseGraphics(scene: Phaser.Scene, graphics: Phaser.GameObjects.Graphics): void {
    graphics.clear();
    graphics.setPosition(0, 0);
    graphics.setScale(1);
    graphics.setRotation(0);
    graphics.setVisible(false);
    graphics.setActive(false);
    getScenePool(graphicsPools, scene).push(graphics);
  },

  clearScene(scene: Phaser.Scene): void {
    damageTextPools.delete(scene);
    graphicsPools.delete(scene);
  },
};

function getScenePool<T>(map: WeakMap<Phaser.Scene, T[]>, scene: Phaser.Scene): T[] {
  let pool = map.get(scene);
  if (!pool) {
    pool = [];
    map.set(scene, pool);
  }
  return pool;
}
