import type { SkillEffect } from "../components/ComponentTypes";
import type { CombatVfxKind } from "../systems/CombatVfxModel";

export interface SkillLevelsReader {
  getLevel(skillId: string): number;
  hasSkill(skillId: string): boolean;
  getKnownSkills(): Array<{ id: string; name: string; level: number; category: string }>;
  getStarterSkillId?(): string;
  isSkillSuppressed?(id: string): boolean;
  canLearnSkill?(id: string): boolean;
  getRandom?(): (() => number) | undefined;
}

export interface CombatStats {
  cooldownMultiplier: number;
  projectileCountBonus: number;
  pierceBonus: number;
  critChance: number;
  critMultiplier: number;
  moveSpeedBonus: number;
  pickupRadiusBonus: number;
  maxHpBonus: number;
  regenPerSecond: number;
  areaMultiplier: number;
  dotDamageMultiplier: number;
  fireDamageMultiplier: number;
  lightningDamageMultiplier: number;
  chainJumpsBonus: number;
  attackSpeedBonus: number;
}

export interface WeaponProfile {
  skillId: string;
  name: string;
  color: number;
  tags: string[];
  cooldownMs: number;
  damage: number;
  /** Loadout damage before character growth, used to preserve an active burst across XP levels. */
  damageBeforePlayerGrowth?: number;
  projectileSpeed: number;
  projectileCount: number;
  pierce: number;
  lifetimeMs: number;
  size: number;
  spread: number;
  effects: SkillEffect[];
  critChance: number;
  critMultiplier: number;
  projectileAssetId?: string;
  burstCount?: number;
  burstIntervalMs?: number;
  minCooldownMs?: number;
  vfxKind: CombatVfxKind;
}

export interface AuraProfile {
  skillId: string;
  name: string;
  color: number;
  tags: string[];
  radius: number;
  entryDamage?: number;
  entryKnockback?: number;
  damagePerSecond: number;
  tickMs: number;
  effects: SkillEffect[];
  vfxKind: CombatVfxKind;
}

export interface SkillChoiceHint {
  skillId: string;
  auraPreview?: { currentRadius: number; nextRadius: number };
  buildHints: string[];
  evolutionHint?: string;
  progressHints: string[];
}
