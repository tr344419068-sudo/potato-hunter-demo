export interface PacingCheckpoint {
  startSeconds: number;
  label: "warmup" | "rush" | "bruisers" | "crossfire" | "siege";
}

export interface WavePressureTarget {
  startSeconds: number;
  spawnIntervalMs: number;
  spawnCount: number;
  maxAlive: number;
  pressurePerSpawn?: number;
}

export interface WavePressure {
  spawnRatePerSecond: number;
  pressurePerSecond: number;
  maxAlive: number;
}

export function getSpawnRatePerSecond(target: WavePressureTarget): number {
  return (target.spawnCount * 1000) / target.spawnIntervalMs;
}

export function smoothstep(t: number): number {
  return t * t * (3 - 2 * t);
}

function getPressurePerSpawn(target: WavePressureTarget): number {
  const pressurePerSpawn = target.pressurePerSpawn ?? 1;
  if (!Number.isFinite(pressurePerSpawn) || pressurePerSpawn <= 0) {
    throw new Error("Wave pressurePerSpawn must be a positive finite number");
  }
  return pressurePerSpawn;
}

export const OPENING_PACING_CHECKPOINTS: readonly PacingCheckpoint[] = [
  { startSeconds: 0, label: "warmup" },
  { startSeconds: 10, label: "rush" },
  { startSeconds: 24, label: "bruisers" },
  { startSeconds: 40, label: "crossfire" },
  { startSeconds: 60, label: "siege" },
  { startSeconds: 105, label: "crossfire" },
  { startSeconds: 165, label: "siege" },
];

export const INITIAL_EXPERIENCE_REQUIREMENT = 12;

export function getPacingCheckpoint(elapsedMs: number): PacingCheckpoint {
  const elapsedSeconds = Math.max(0, elapsedMs) / 1000;
  for (let index = OPENING_PACING_CHECKPOINTS.length - 1; index >= 0; index -= 1) {
    const checkpoint = OPENING_PACING_CHECKPOINTS[index];
    if (elapsedSeconds >= checkpoint.startSeconds) {
      return checkpoint;
    }
  }
  return OPENING_PACING_CHECKPOINTS[0];
}

export function getWavePressure(
  targets: readonly WavePressureTarget[],
  elapsedMs: number,
): WavePressure {
  if (targets.length === 0) {
    throw new Error("Wave pressure requires at least one target");
  }

  const targetPressures = targets.map((target) => {
    const pressurePerSpawn = getPressurePerSpawn(target);
    return {
      pressurePerSpawn,
      pressurePerSecond: getSpawnRatePerSecond(target) * pressurePerSpawn,
    };
  });
  const toPressure = (index: number): WavePressure => ({
    spawnRatePerSecond: targetPressures[index].pressurePerSecond / targetPressures[index].pressurePerSpawn,
    pressurePerSecond: targetPressures[index].pressurePerSecond,
    maxAlive: Math.round(targets[index].maxAlive),
  });
  const elapsedSeconds = Math.max(0, elapsedMs) / 1000;

  if (elapsedSeconds <= targets[0].startSeconds) {
    return toPressure(0);
  }

  for (let index = 0; index < targets.length - 1; index += 1) {
    const current = targets[index];
    const next = targets[index + 1];
    if (elapsedSeconds < next.startSeconds) {
      const t = (elapsedSeconds - current.startSeconds) / (next.startSeconds - current.startSeconds);
      const easedProgress = smoothstep(t);
      const currentPressure = targetPressures[index];
      const nextPressure = targetPressures[index + 1];
      const pressurePerSecond =
        currentPressure.pressurePerSecond
        + (nextPressure.pressurePerSecond - currentPressure.pressurePerSecond) * easedProgress;
      return {
        spawnRatePerSecond: pressurePerSecond / currentPressure.pressurePerSpawn,
        pressurePerSecond,
        maxAlive: Math.round(current.maxAlive + (next.maxAlive - current.maxAlive) * easedProgress),
      };
    }
  }

  return toPressure(targets.length - 1);
}

export function getNextExperienceRequirement(currentRequirement: number, nextLevel: number): number {
  const level = Math.max(2, nextLevel);
  // Give the opening build room to form, then gradually restore the established
  // curve and growth guard from Lv5 to Lv12 instead of introducing a cost cliff.
  const lateGameBlend = smoothstep(Math.min(1, Math.max(0, (level - 5) / 7)));
  const earlyCurve = 3 * level * level + 7 * level + 2;
  const establishedCurve = 14 + 18 * Math.pow(level, 1.7);
  const levelCurve = earlyCurve + (establishedCurve - earlyCurve) * lateGameBlend;
  const exponentialGrowth = Math.max(INITIAL_EXPERIENCE_REQUIREMENT, currentRequirement)
    * (1.18 + 0.07 * lateGameBlend) + 6 + 10 * lateGameBlend;
  const steadyGrowth = Math.max(INITIAL_EXPERIENCE_REQUIREMENT, currentRequirement) + 6 + level * 14;
  const steadyBlend = smoothstep(Math.min(1, Math.max(0, (level - 8) / 4)));
  const minimumGrowth = exponentialGrowth + (steadyGrowth - exponentialGrowth) * steadyBlend;
  return Math.ceil(Math.max(levelCurve, minimumGrowth));
}
