import { ConfigManager, type BuildConfig, type SkillConfig } from "./ConfigManager";
import { BuildHintSystem } from "./BuildHintSystem";
import { SkillChoiceSystem } from "./SkillChoiceSystem";
import { SkillStatsCalculator } from "./SkillStatsCalculator";
import { getSkillMilestone } from "./SkillProgressionModel";
import type { AuraProfile, CombatStats, SkillChoiceHint, SkillLevelsReader, SpatialSkillProfile, WeaponProfile } from "./SkillTypes";

export type { AuraProfile, CombatStats, SkillChoiceHint, WeaponProfile } from "./SkillTypes";

export class SkillManager implements SkillLevelsReader {
  private readonly levels = new Map<string, number>();
  private readonly choiceSystem = new SkillChoiceSystem(this);
  private readonly statsCalculator = new SkillStatsCalculator(this);
  private readonly buildHintSystem = new BuildHintSystem(this);

  constructor(private readonly options: { starterSkillId?: string; enforceSlots?: boolean; random?: () => number; permanentDamageMultiplier?: number } = {}) {
    if (options.starterSkillId && ConfigManager.skills.some(s => s.id === options.starterSkillId && s.weapon)) this.levels.set(options.starterSkillId, 1);
  }
  getStarterSkillId(): string { return this.options.starterSkillId ?? "peeler_blade"; }
  getRandom(): (() => number) | undefined { return this.options.random; }
  getPermanentDamageMultiplier(): number { return this.options.permanentDamageMultiplier ?? 1; }
  isSkillSuppressed(id: string): boolean {
    return Boolean(this.options.enforceSlots && ConfigManager.skillEvolutions.some(e => this.hasSkill(e.resultSkillId) && (e.requiredSkills ?? []).some(s => s.id === id && ConfigManager.getSkill(id).category === "active")));
  }
  canLearnSkill(id: string): boolean {
    const skill = ConfigManager.skills.find(s => s.id === id);
    if (!skill || this.isSkillSuppressed(id)) return false;
    if (!this.options.enforceSlots || this.hasSkill(id) || skill.category === "evolution") return true;
    const known = this.getKnownSkills();
    return skill.category === "active" ? known.filter(s => s.category === "active" || s.category === "evolution").length < 6 : skill.category === "passive" ? known.filter(s => s.category === "passive").length < 4 : true;
  }

  getLevel(skillId: string): number {
    return this.levels.get(skillId) ?? 0;
  }

  hasSkill(skillId: string): boolean {
    return this.getLevel(skillId) > 0;
  }

  levelUp(skillId: string): number {
    const skill = ConfigManager.skills.find((candidate) => candidate.id === skillId);
    if (!skill || !this.canLearnSkill(skillId)) {
      return 0;
    }

    const nextLevel = Math.min(this.getLevel(skillId) + 1, skill.maxLevel);
    this.levels.set(skillId, nextLevel);
    return nextLevel;
  }

  getChoices(count: number, excludedIds: ReadonlySet<string> = new Set()): SkillConfig[] {
    return this.choiceSystem.getChoices(count, excludedIds);
  }

  getChoiceHints(choices: SkillConfig[], playerLevel = 1): SkillChoiceHint[] {
    return this.choiceSystem.getChoiceHints(choices).map(hint => ({
      ...hint, auraPreview: this.statsCalculator.getAuraUpgradePreview(hint.skillId),
      upgradeBenefit: this.getUpgradeBenefit(hint.skillId, playerLevel),
    }));
  }

  private getUpgradeBenefit(id: string, playerLevel: number): string | undefined {
    const skill = ConfigManager.skills.find(candidate => candidate.id === id);
    const rank = this.getLevel(id);
    if (!skill || rank === 0 || rank >= skill.maxLevel || !this.canLearnSkill(id)) return;
    // Use the same profiles as combat. The projection neither takes an RNG roll nor
    // modifies slot occupancy, mastery, training, or the live choice session.
    const projected = new SkillManager(this.options);
    for (const [skillId, level] of this.levels) projected.levels.set(skillId, level);
    projected.levelUp(id);
    const diff = (label: string, before: number, after: number) =>
      before !== after ? `${label} ${before} → ${after}` : undefined;
    const milestone = getSkillMilestone(id, rank + 1);
    const line = (primary?: string, secondary?: string) => [primary, milestone ?? secondary].filter(Boolean).join(" · ") || undefined;
    if (skill.weapon) {
      const before = this.getWeaponProfiles(playerLevel).find(profile => profile.skillId === id);
      const after = projected.getWeaponProfiles(playerLevel).find(profile => profile.skillId === id);
      if (before && after) return line(diff("单发伤害", before.damage, after.damage), diff("弹数", before.projectileCount, after.projectileCount));
    }
    if (skill.aura) {
      const before = this.getAuraProfiles(playerLevel).find(profile => profile.skillId === id);
      const after = projected.getAuraProfiles(playerLevel).find(profile => profile.skillId === id);
      if (before && after) return line(diff("半径", Math.round(before.radius), Math.round(after.radius)),
        diff("每秒伤害", Math.round(before.damagePerSecond), Math.round(after.damagePerSecond)));
    }
    if (skill.spatial) {
      const before = this.getSpatialProfiles(playerLevel).find(profile => profile.skillId === id);
      const after = projected.getSpatialProfiles(playerLevel).find(profile => profile.skillId === id);
      if (before && after && skill.spatial.kind === "oil") return line(diff("每跳伤害", before.damage, after.damage),
        diff("火区半径", Math.round(before.radius), Math.round(after.radius)));
      if (before && after) return line(diff(skill.spatial.kind === "turret" ? "炮击伤害" : "路径伤害", before.damage, after.damage));
    }
  }

  getKnownSkills(): Array<{ id: string; name: string; level: number; category: string }> {
    return ConfigManager.skills
      .map((skill) => ({ id: skill.id, name: skill.name, level: this.getLevel(skill.id), category: skill.category }))
      .filter((skill) => skill.level > 0 && !this.isSkillSuppressed(skill.id));
  }

  getActiveBuilds(): BuildConfig[] {
    return this.buildHintSystem.getActiveBuilds();
  }

  getCombatStats(): CombatStats {
    return this.statsCalculator.getCombatStats();
  }

  getWeaponProfiles(playerLevel = 1): WeaponProfile[] {
    return this.statsCalculator.getWeaponProfiles(playerLevel);
  }

  getAuraProfiles(playerLevel = 1): AuraProfile[] {
    return this.statsCalculator.getAuraProfiles(playerLevel);
  }

  getSpatialProfiles(playerLevel = 1): SpatialSkillProfile[] {
    return this.statsCalculator.getSpatialProfiles(playerLevel);
  }

  getMoveSpeedBonus(): number {
    return this.getCombatStats().moveSpeedBonus;
  }

  getPickupRadiusBonus(): number {
    return this.getCombatStats().pickupRadiusBonus;
  }

  getMaxHpBonus(): number {
    return this.getCombatStats().maxHpBonus;
  }

  getRegenPerSecond(): number {
    return this.getCombatStats().regenPerSecond;
  }
}
