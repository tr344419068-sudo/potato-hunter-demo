import { ConfigManager, type BuildConfig, type SkillConfig } from "./ConfigManager";
import { BuildHintSystem } from "./BuildHintSystem";
import { SkillChoiceSystem } from "./SkillChoiceSystem";
import { SkillStatsCalculator } from "./SkillStatsCalculator";
import type { AuraProfile, CombatStats, SkillChoiceHint, SkillLevelsReader, WeaponProfile } from "./SkillTypes";

export type { AuraProfile, CombatStats, SkillChoiceHint, WeaponProfile } from "./SkillTypes";

export class SkillManager implements SkillLevelsReader {
  private readonly levels = new Map<string, number>();
  private readonly choiceSystem = new SkillChoiceSystem(this);
  private readonly statsCalculator = new SkillStatsCalculator(this);
  private readonly buildHintSystem = new BuildHintSystem(this);

  constructor(private readonly options: { starterSkillId?: string; enforceSlots?: boolean; random?: () => number } = {}) {
    if (options.starterSkillId && ConfigManager.skills.some(s => s.id === options.starterSkillId && s.weapon)) this.levels.set(options.starterSkillId, 1);
  }
  getStarterSkillId(): string { return this.options.starterSkillId ?? "peeler_blade"; }
  getRandom(): (() => number) | undefined { return this.options.random; }
  isSkillSuppressed(id: string): boolean {
    return Boolean(this.options.enforceSlots && ConfigManager.skillEvolutions.some(e => this.hasSkill(e.resultSkillId) && (e.requiredSkills ?? []).some(s => s.id === id && ConfigManager.getSkill(id).category === "active")));
  }
  canLearnSkill(id: string): boolean {
    const skill = ConfigManager.skills.find(s => s.id === id);
    if (!skill || this.isSkillSuppressed(id)) return false;
    if (!this.options.enforceSlots || this.hasSkill(id) || skill.category === "evolution") return true;
    const known = this.getKnownSkills();
    return skill.category === "active" ? known.filter(s => s.category === "active" || s.category === "evolution").length < 6 : skill.category === "passive" ? known.filter(s => s.category === "passive").length < 4 : true;
  }

  getLevel(skillId: string): number {
    return this.levels.get(skillId) ?? 0;
  }

  hasSkill(skillId: string): boolean {
    return this.getLevel(skillId) > 0;
  }

  levelUp(skillId: string): number {
    const skill = ConfigManager.skills.find((candidate) => candidate.id === skillId);
    if (!skill || !this.canLearnSkill(skillId)) {
      return 0;
    }

    const nextLevel = Math.min(this.getLevel(skillId) + 1, skill.maxLevel);
    this.levels.set(skillId, nextLevel);
    return nextLevel;
  }

  getChoices(count: number, excludedIds: ReadonlySet<string> = new Set()): SkillConfig[] {
    return this.choiceSystem.getChoices(count, excludedIds);
  }

  getChoiceHints(choices: SkillConfig[]): SkillChoiceHint[] {
    return this.choiceSystem.getChoiceHints(choices).map(hint => ({
      ...hint, auraPreview: this.statsCalculator.getAuraUpgradePreview(hint.skillId),
    }));
  }

  getKnownSkills(): Array<{ id: string; name: string; level: number; category: string }> {
    return ConfigManager.skills
      .map((skill) => ({ id: skill.id, name: skill.name, level: this.getLevel(skill.id), category: skill.category }))
      .filter((skill) => skill.level > 0 && !this.isSkillSuppressed(skill.id));
  }

  getActiveBuilds(): BuildConfig[] {
    return this.buildHintSystem.getActiveBuilds();
  }

  getCombatStats(): CombatStats {
    return this.statsCalculator.getCombatStats();
  }

  getWeaponProfiles(playerLevel = 1): WeaponProfile[] {
    return this.statsCalculator.getWeaponProfiles(playerLevel);
  }

  getAuraProfiles(playerLevel = 1): AuraProfile[] {
    return this.statsCalculator.getAuraProfiles(playerLevel);
  }

  getMoveSpeedBonus(): number {
    return this.getCombatStats().moveSpeedBonus;
  }

  getPickupRadiusBonus(): number {
    return this.getCombatStats().pickupRadiusBonus;
  }

  getMaxHpBonus(): number {
    return this.getCombatStats().maxHpBonus;
  }

  getRegenPerSecond(): number {
    return this.getCombatStats().regenPerSecond;
  }
}
