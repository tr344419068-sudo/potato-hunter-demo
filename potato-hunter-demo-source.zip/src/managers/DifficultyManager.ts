import type { EntityId } from "../components/ComponentTypes";
import type { World } from "../entities/World";
import { ConfigManager } from "./ConfigManager";
import { smoothstep } from "./PacingModel";

const EXTRA_SPAWN_RAMP_SECONDS = 6;

export interface DifficultyState {
  level: number;
  hpMultiplier: number;
  damageMultiplier: number;
  speedMultiplier: number;
  eliteChance: number;
  extraSpawnCount: number;
  extraMaxAlive: number;
}

export class DifficultyManager {
  getState(elapsedMs: number): DifficultyState {
    const config = ConfigManager.difficulty;
    const elapsedSeconds = elapsedMs / 1000;
    const scaledSeconds = Math.max(0, elapsedSeconds - config.scalingStartSeconds);
    const minutes = scaledSeconds / 60;
    const completedSpawnSteps = Math.floor(scaledSeconds / config.extraSpawnEverySeconds);
    const spawnRampProgress = Math.min(1, (scaledSeconds - completedSpawnSteps * config.extraSpawnEverySeconds) / EXTRA_SPAWN_RAMP_SECONDS);
    const extraSpawnCount = completedSpawnSteps === 0 ? 0 : completedSpawnSteps - 1 + smoothstep(spawnRampProgress);

    return {
      level: Math.floor(minutes) + 1,
      hpMultiplier: 1 + minutes * config.hpPerMinute,
      damageMultiplier: 1 + minutes * config.damagePerMinute,
      speedMultiplier: 1 + Math.min(config.maxSpeedBonus, minutes * config.speedPerMinute),
      eliteChance: Math.min(config.maxEliteChance, minutes * config.eliteChancePerMinute),
      extraSpawnCount,
      extraMaxAlive: Math.floor(minutes * config.extraMaxAlivePerMinute),
    };
  }

  applyToMonster(world: World, entityId: EntityId, elapsedMs: number, random = Math.random): void {
    const state = this.getState(elapsedMs);
    const monster = world.components.monsters.get(entityId);
    const health = world.components.health.get(entityId);
    const render = world.components.renders.get(entityId);

    if (!monster || !health) {
      return;
    }

    const bossSpawnIndex = monster.isBoss ? Math.floor(elapsedMs / (ConfigManager.waves.bossEverySeconds * 1000)) : 0;
    const bossHpMultiplier = monster.isBoss ? 1 + bossSpawnIndex * ConfigManager.difficulty.bossExtraHpPerSpawn : 1;
    const elite = !monster.isBoss && random() < state.eliteChance;
    const eliteHpMultiplier = elite ? ConfigManager.difficulty.eliteHpMultiplier : 1;
    const eliteDamageMultiplier = elite ? ConfigManager.difficulty.eliteDamageMultiplier : 1;
    const eliteSpeedMultiplier = elite ? ConfigManager.difficulty.eliteSpeedMultiplier : 1;

    health.max = Math.ceil(health.max * state.hpMultiplier * bossHpMultiplier * eliteHpMultiplier);
    health.current = health.max;
    monster.damage = Math.ceil(monster.damage * state.damageMultiplier * eliteDamageMultiplier);
    monster.speedMultiplier *= state.speedMultiplier * eliteSpeedMultiplier;
    monster.isElite = elite;

    if (!elite) {
      return;
    }

    monster.eliteAffix = this.pickEliteAffix(elapsedMs, random);
    monster.experienceValue = Math.ceil(monster.experienceValue * 1.7);

    if (monster.eliteAffix === "haste") {
      monster.speedMultiplier *= 1.22;
    }
    if (monster.eliteAffix === "shield") {
      monster.shieldHp = Math.ceil(health.max * 0.34);
    }
    if (monster.eliteAffix === "death_bomb") {
      monster.damage = Math.ceil(monster.damage * 1.1);
    }

    if (render) {
      render.color = this.getEliteColor(monster.eliteAffix);
      render.size *= 1.22;
    }

    const transform = world.components.transforms.get(entityId);
    if (transform) {
      transform.radius *= 1.22;
    }
  }

  private pickEliteAffix(elapsedMs: number, random = Math.random): "haste" | "split" | "shield" | "death_bomb" {
    const elapsedSeconds = elapsedMs / 1000;
    const pool: Array<"haste" | "split" | "shield" | "death_bomb"> =
      elapsedSeconds < 180 ? ["haste", "shield"] : elapsedSeconds < 270 ? ["haste", "shield", "split"] : ["haste", "shield", "split", "death_bomb"];
    return pool[Math.floor(random() * pool.length)];
  }

  private getEliteColor(affix?: "haste" | "split" | "shield" | "death_bomb"): number {
    switch (affix) {
      case "haste":
        return 0xffd166;
      case "split":
        return 0x4cc9f0;
      case "shield":
        return 0xc77dff;
      case "death_bomb":
        return 0xff4800;
      default:
        return 0xffca3a;
    }
  }
}
