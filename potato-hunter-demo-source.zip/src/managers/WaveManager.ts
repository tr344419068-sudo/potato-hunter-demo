import { ConfigManager, type WaveConfig } from "./ConfigManager";
import { getWavePressure, smoothstep } from "./PacingModel";
import type { StageId } from "../progression/CampaignGrowth";

type MonsterMixEntry = NonNullable<WaveConfig["monsterMix"]>[number];

const ROSTER_TRANSITION_SECONDS = 6;
const MIN_MONSTER_WEIGHT = 1e-9;

function normalizeMonsterMix(entries: readonly MonsterMixEntry[]): MonsterMixEntry[] {
  const weightsByMonsterId = new Map<string, number>();
  for (const entry of entries) {
    weightsByMonsterId.set(
      entry.monsterId,
      (weightsByMonsterId.get(entry.monsterId) ?? 0) + entry.weight,
    );
  }
  const totalWeight = [...weightsByMonsterId.values()].reduce((sum, weight) => sum + weight, 0);
  return [...weightsByMonsterId]
    .map(([monsterId, weight]) => ({ monsterId, weight: weight / totalWeight }))
    .filter((entry) => entry.weight > MIN_MONSTER_WEIGHT);
}

function getTargetMonsterMix(wave: WaveConfig): MonsterMixEntry[] {
  const entries = wave.monsterMix && wave.monsterMix.length > 0
    ? wave.monsterMix
    : [{ monsterId: wave.monsterId, weight: 1 }];
  return normalizeMonsterMix(entries);
}

function blendMonsterMix(from: readonly MonsterMixEntry[], to: readonly MonsterMixEntry[], progress: number): MonsterMixEntry[] {
  const fromMix = new Map(from.map((entry) => [entry.monsterId, entry.weight]));
  const toMix = new Map(to.map((entry) => [entry.monsterId, entry.weight]));
  const monsterIds = new Set([...fromMix.keys(), ...toMix.keys()]);
  return normalizeMonsterMix([...monsterIds].map((monsterId) => ({
    monsterId,
    weight:
      (fromMix.get(monsterId) ?? 0) * (1 - progress)
      + (toMix.get(monsterId) ?? 0) * progress,
  })));
}

function getWeightedAverageMonsterHp(monsterMix: readonly MonsterMixEntry[], includeShields = false): number {
  return monsterMix.reduce((sum, entry) => {
    const monster = ConfigManager.getMonster(entry.monsterId);
    return sum + (monster.hp + (includeShields ? monster.shieldHp ?? 0 : 0)) * entry.weight;
  }, 0);
}

function getCurrentIndex(beats: readonly { startSeconds: number }[], elapsedSeconds: number): number {
  for (let index = beats.length - 1; index > 0; index -= 1) {
    if (elapsedSeconds >= beats[index].startSeconds) return index;
  }
  return 0;
}

function getCurrentRoster(
  beats: readonly { startSeconds: number; mix: readonly MonsterMixEntry[] }[],
  elapsedSeconds: number,
  index = getCurrentIndex(beats, elapsedSeconds),
): readonly MonsterMixEntry[] {
  const current = beats[index];
  const progress = Math.min(1, (elapsedSeconds - current.startSeconds) / ROSTER_TRANSITION_SECONDS);
  return index === 0 || progress >= 1
    ? current.mix
    : blendMonsterMix(beats[index - 1].mix, current.mix, smoothstep(progress));
}

/** The previous desert schedule traded up to 22% of the shared roster for higher-HP specialists. */
function getBudgetRoster(baseline: readonly MonsterMixEntry[], stage: StageId, elapsedSeconds: number): readonly MonsterMixEntry[] {
  if (stage !== "desert" || elapsedSeconds <= 10) return baseline;
  const specialistWeight = smoothstep(Math.min(1, (elapsedSeconds - 10) / 8)) * 0.22;
  const scorpionShare = smoothstep(Math.min(1, Math.max(0, (elapsedSeconds - 55) / 15)));
  return [
    ...baseline.map((entry) => ({ ...entry, weight: entry.weight * (1 - specialistWeight) })),
    { monsterId: "desert_cactus", weight: specialistWeight * (1 - scorpionShare) },
    { monsterId: "desert_scorpion", weight: specialistWeight * scorpionShare },
  ];
}

export class WaveManager {
  private readonly pacingBeats = ConfigManager.waves.waves.map((wave) => ({
    ...wave,
    mix: getTargetMonsterMix(wave),
  }));
  private readonly pressureTargets = this.pacingBeats.map((beat) => ({
    ...beat,
    pressurePerSpawn: getWeightedAverageMonsterHp(beat.mix),
  }));
  private readonly rosterBeats;

  constructor(private readonly stage: StageId = "meadow") {
    this.rosterBeats = ConfigManager.waves.rosters[stage].map(({ startSeconds, weights }) => ({
      startSeconds,
      mix: normalizeMonsterMix(Object.entries(weights).map(([monsterId, weight]) => ({ monsterId, weight }))),
    }));
  }

  private nextBossAtMs = ConfigManager.waves.bossEverySeconds * 1000;

  getCurrentWave(elapsedMs: number): WaveConfig {
    const elapsedSeconds = elapsedMs / 1000;
    const currentIndex = getCurrentIndex(this.pacingBeats, elapsedSeconds);
    const current = ConfigManager.waves.waves[currentIndex];
    const budgetMix = getBudgetRoster(getCurrentRoster(this.pacingBeats, elapsedSeconds, currentIndex), this.stage, elapsedSeconds);
    const monsterMix = getCurrentRoster(this.rosterBeats, elapsedSeconds);
    const pressure = getWavePressure(this.pressureTargets, elapsedMs);
    const baselineRate = pressure.pressurePerSecond / getWeightedAverageMonsterHp(budgetMix);
    // Replacements budget live shields as well as HP. A lighter mix must not
    // spawn faster to spend the surplus; a heavier one stretches its interval.
    const effectiveHpBudget = baselineRate * getWeightedAverageMonsterHp(budgetMix, true);
    const spawnRatePerSecond = Math.min(baselineRate, effectiveHpBudget / getWeightedAverageMonsterHp(monsterMix, true));

    return {
      ...current,
      monsterMix: monsterMix.map((entry) => ({ ...entry })),
      spawnIntervalMs: (current.spawnCount / spawnRatePerSecond) * 1000,
      maxAlive: pressure.maxAlive,
    };
  }

  shouldSpawnBoss(elapsedMs: number): boolean {
    if (elapsedMs < this.nextBossAtMs) {
      return false;
    }

    this.nextBossAtMs += ConfigManager.waves.bossEverySeconds * 1000;
    return true;
  }
}
