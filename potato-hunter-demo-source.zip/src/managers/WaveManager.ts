import { ConfigManager, type WaveConfig } from "./ConfigManager";
import { getWavePressure, smoothstep } from "./PacingModel";

type MonsterMixEntry = NonNullable<WaveConfig["monsterMix"]>[number];

const ROSTER_TRANSITION_SECONDS = 6;
const MIN_MONSTER_WEIGHT = 1e-9;

function normalizeMonsterMix(entries: readonly MonsterMixEntry[]): MonsterMixEntry[] {
  const weightsByMonsterId = new Map<string, number>();
  for (const entry of entries) {
    weightsByMonsterId.set(
      entry.monsterId,
      (weightsByMonsterId.get(entry.monsterId) ?? 0) + entry.weight,
    );
  }
  const totalWeight = [...weightsByMonsterId.values()].reduce((sum, weight) => sum + weight, 0);
  return [...weightsByMonsterId]
    .map(([monsterId, weight]) => ({ monsterId, weight: weight / totalWeight }))
    .filter((entry) => entry.weight > MIN_MONSTER_WEIGHT);
}

function getTargetMonsterMix(wave: WaveConfig): MonsterMixEntry[] {
  const entries = wave.monsterMix && wave.monsterMix.length > 0
    ? wave.monsterMix
    : [{ monsterId: wave.monsterId, weight: 1 }];
  return normalizeMonsterMix(entries);
}

function blendMonsterMix(fromWave: WaveConfig, toWave: WaveConfig, progress: number): MonsterMixEntry[] {
  const fromMix = new Map(getTargetMonsterMix(fromWave).map((entry) => [entry.monsterId, entry.weight]));
  const toMix = new Map(getTargetMonsterMix(toWave).map((entry) => [entry.monsterId, entry.weight]));
  const monsterIds = new Set([...fromMix.keys(), ...toMix.keys()]);
  return normalizeMonsterMix([...monsterIds].map((monsterId) => ({
    monsterId,
    weight:
      (fromMix.get(monsterId) ?? 0) * (1 - progress)
      + (toMix.get(monsterId) ?? 0) * progress,
  })));
}

function getWeightedAverageMonsterHp(monsterMix: readonly MonsterMixEntry[]): number {
  return monsterMix.reduce(
    (sum, entry) => sum + ConfigManager.getMonster(entry.monsterId).hp * entry.weight,
    0,
  );
}

export class WaveManager {
  private readonly pressureTargets = ConfigManager.waves.waves.map((wave) => ({
    ...wave,
    pressurePerSpawn: getWeightedAverageMonsterHp(getTargetMonsterMix(wave)),
  }));

  private nextBossAtMs = ConfigManager.waves.bossEverySeconds * 1000;

  getCurrentWave(elapsedMs: number): WaveConfig {
    const elapsedSeconds = elapsedMs / 1000;
    let currentIndex = 0;
    for (let index = ConfigManager.waves.waves.length - 1; index >= 0; index -= 1) {
      if (elapsedSeconds >= ConfigManager.waves.waves[index].startSeconds) {
        currentIndex = index;
        break;
      }
    }
    const current = ConfigManager.waves.waves[currentIndex];
    const transitionProgress = currentIndex === 0
      ? 1
      : Math.min(1, Math.max(0, (elapsedSeconds - current.startSeconds) / ROSTER_TRANSITION_SECONDS));
    const monsterMix = currentIndex === 0
      ? getTargetMonsterMix(current)
      : blendMonsterMix(
        ConfigManager.waves.waves[currentIndex - 1],
        current,
        smoothstep(transitionProgress),
      );
    const pressure = getWavePressure(this.pressureTargets, elapsedMs);
    const spawnRatePerSecond = pressure.pressurePerSecond / getWeightedAverageMonsterHp(monsterMix);

    return {
      ...current,
      monsterMix,
      spawnIntervalMs: (current.spawnCount / spawnRatePerSecond) * 1000,
      maxAlive: pressure.maxAlive,
    };
  }

  shouldSpawnBoss(elapsedMs: number): boolean {
    if (elapsedMs < this.nextBossAtMs) {
      return false;
    }

    this.nextBossAtMs += ConfigManager.waves.bossEverySeconds * 1000;
    return true;
  }
}
