/** Shared by combat and upgrade cards: radius is a real targeting distance. */
export const MAX_AURA_RADIUS = 520;

export function getAuraRadius(baseRadius: number, rank: number, areaMultiplier = 1): number {
  return Math.min(MAX_AURA_RADIUS, baseRadius * areaMultiplier * (1 + Math.max(0, rank - 1) * 0.14));
}

export function getSkillMilestone(skillId: string | undefined, rank: number): string | undefined {
  if (skillId === "toxic_tomato" && rank === 4) return "解锁进圈减速";
  if (skillId === "toxic_tomato" && rank === 8) return "减速强化至35%";
  if (skillId === "ketchup_aura" && rank === 4) return "解锁进圈击退";
  if (skillId === "ketchup_aura" && rank === 8) return "重击+40% · 击退强化";
  if (skillId === "peeler_blade" && rank % 4 === 0) return "穿透+1";
  if (skillId === "pepper_gatling" && (rank === 8 || rank === 12)) return "穿透+1";
  if (skillId === "corn_burst" && rank === 6) return "升级为四连发";
  return undefined;
}
