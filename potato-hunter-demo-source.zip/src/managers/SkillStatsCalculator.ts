import Phaser from "phaser";
import type { SkillEffect } from "../components/ComponentTypes";
import { ConfigManager } from "./ConfigManager";
import type { AuraProfile, CombatStats, SkillLevelsReader, WeaponProfile } from "./SkillTypes";
import { resolveCombatVfxKind } from "../systems/CombatVfxModel";
import { getPlayerLevelGrowth } from "./PlayerLevelGrowthModel";
import { getAuraRadius } from "./SkillProgressionModel";

export class SkillStatsCalculator {
  constructor(private readonly skills: SkillLevelsReader) {}

  getCombatStats(): CombatStats {
    const stats: CombatStats = {
      cooldownMultiplier: 1,
      projectileCountBonus: 0,
      pierceBonus: 0,
      critChance: 0,
      critMultiplier: 1.6,
      moveSpeedBonus: 0,
      pickupRadiusBonus: 0,
      maxHpBonus: 0,
      regenPerSecond: 0,
      areaMultiplier: 1,
      dotDamageMultiplier: 1,
      fireDamageMultiplier: 1,
      lightningDamageMultiplier: 1,
      chainJumpsBonus: 0,
      attackSpeedBonus: 0,
    };

    for (const skill of ConfigManager.skills) {
      const level = this.skills.getLevel(skill.id);
      if (level <= 0) {
        continue;
      }

      for (const effect of skill.effects) {
        if (effect.type !== "stat_modifier") {
          continue;
        }

        const value = effect.value * level;
        switch (effect.stat) {
          case "attackSpeedBonus":
            stats.attackSpeedBonus += value;
            break;
          case "cooldownMultiplier":
            stats.cooldownMultiplier += value;
            break;
          case "projectileCount":
            stats.projectileCountBonus += value;
            break;
          case "pierce":
            stats.pierceBonus += value;
            break;
          case "pickupRadius":
            stats.pickupRadiusBonus += value;
            break;
          case "moveSpeed":
            stats.moveSpeedBonus += value;
            break;
          case "maxHp":
            stats.maxHpBonus += value;
            break;
          case "regen":
            stats.regenPerSecond += value;
            break;
          case "critChance":
            stats.critChance += value;
            break;
          case "critMultiplier":
            stats.critMultiplier += value;
            break;
          case "areaMultiplier":
            stats.areaMultiplier += value;
            break;
          case "dotDamage":
            stats.dotDamageMultiplier += value;
            break;
          case "fireDamage":
            stats.fireDamageMultiplier += value;
            break;
          case "lightningDamage":
            stats.lightningDamageMultiplier += value;
            break;
          case "chainJumps":
            stats.chainJumpsBonus += value;
            break;
        }
      }
    }

    stats.cooldownMultiplier = Math.max(0.35, stats.cooldownMultiplier);
    stats.critChance = Math.min(0.75, stats.critChance);
    stats.attackSpeedBonus = Math.min(1, Math.max(0, stats.attackSpeedBonus));
    return stats;
  }

  getWeaponProfiles(playerLevel = 1): WeaponProfile[] {
    const stats = this.getCombatStats();
    const damageMultiplier = getPlayerLevelGrowth(playerLevel).damageMultiplier;
    return ConfigManager.skills
      .filter((skill) => skill.weapon && !this.skills.isSkillSuppressed?.(skill.id) && (this.skills.getLevel(skill.id) > 0 || skill.id === (this.skills.getStarterSkillId?.() ?? "peeler_blade")))
      .map((skill) => {
        const level = this.getEffectiveRank(skill.id, Math.max(skill.id === (this.skills.getStarterSkillId?.() ?? "peeler_blade") ? 1 : 0, this.skills.getLevel(skill.id)));
        const masteryRank = Math.max(level, this.getInheritedActiveRank(skill.id));
        const weapon = skill.weapon!;
        const tagDamage = this.getTagDamageMultiplier(skill.tags, stats);
        const evolutionMultiplier = skill.category === "evolution" ? 1.25 : 1;
        const levelDamage = 1 + (level - 1) * 0.28;
        const loadoutDamage = weapon.damage * levelDamage * tagDamage * evolutionMultiplier;
        const countFromLevel = Math.floor((level - 1) / 2) * (weapon.projectileCountPerTwoLevels ?? 1);

        return {
          skillId: skill.id,
          name: skill.name,
          color: Phaser.Display.Color.HexStringToColor(skill.color).color,
          tags: skill.tags,
          cooldownMs: Math.max(weapon.minCooldownMs ?? 120, weapon.cooldownMs * stats.cooldownMultiplier * (1 - (level - 1) * 0.025) / (1 + stats.attackSpeedBonus)),
          damage: Math.ceil(loadoutDamage * damageMultiplier),
          damageBeforePlayerGrowth: Math.ceil(loadoutDamage),
          projectileSpeed: weapon.projectileSpeed * (1 + (level - 1) * 0.025),
          projectileCount: Math.min(16, Math.max(1, Math.floor(weapon.projectileCount + countFromLevel + stats.projectileCountBonus))),
          pierce: Math.max(0, Math.floor(weapon.pierce + stats.pierceBonus + this.getEffectValue(skill.effects, "pierce")
            + (skill.id === "peeler_blade" ? Math.floor(level / 4)
              : (skill.id === "pepper_gatling" || skill.id === "pepper_overdrive") && masteryRank >= 8 ? 1 + Math.floor((masteryRank - 8) / 4) : 0))),
          lifetimeMs: weapon.lifetimeMs,
          size: weapon.size,
          spread: weapon.spread,
          effects: this.scaleEffects(skill.effects, level, stats, skill.tags, damageMultiplier),
          critChance: stats.critChance,
          critMultiplier: stats.critMultiplier,
          projectileAssetId: weapon.projectileAssetId,
          burstCount: Math.min(4, Math.max(1, (weapon.burstCount ?? 1) + (skill.id === "corn_burst" && level >= 6 ? 1 : 0))),
          burstIntervalMs: Math.max(60, weapon.burstIntervalMs ?? 75),
          minCooldownMs: weapon.minCooldownMs,
          vfxKind: resolveCombatVfxKind(skill.tags, skill.effects, skill.vfxKind),
        };
      });
  }

  getAuraProfiles(playerLevel = 1): AuraProfile[] {
    const stats = this.getCombatStats();
    const damageMultiplier = getPlayerLevelGrowth(playerLevel).damageMultiplier;
    return ConfigManager.skills
      .filter((skill) => skill.aura && !this.skills.isSkillSuppressed?.(skill.id) && this.skills.getLevel(skill.id) > 0)
      .map((skill) => {
        const level = this.getEffectiveRank(skill.id, this.skills.getLevel(skill.id));
        const masteryRank = Math.max(level, this.getInheritedActiveRank(skill.id));
        const aura = skill.aura!;
        const tagDamage = this.getTagDamageMultiplier(skill.tags, stats);
        return {
          skillId: skill.id,
          name: skill.name,
          color: Phaser.Display.Color.HexStringToColor(skill.color).color,
          tags: skill.tags,
          radius: getAuraRadius(aura.radius, level, stats.areaMultiplier),
          entryDamage: (aura.entryDamage ?? 0) * tagDamage * (1 + (level - 1) * 0.28) * damageMultiplier
            * (skill.id === "ketchup_aura" && level >= 8 ? 1.4 : 1),
          entryKnockback: skill.id === "ketchup_aura" && level >= 4 ? (level >= 8 ? 160 : 100) : 0,
          damagePerSecond: aura.damagePerSecond * tagDamage * (1 + (level - 1) * 0.26) * damageMultiplier,
          tickMs: Math.max(80, aura.tickMs * stats.cooldownMultiplier),
          effects: [...this.scaleEffects(skill.effects, level, stats, skill.tags, damageMultiplier),
            ...((skill.id === "toxic_tomato" || skill.id === "toxic_burst_cloud") && masteryRank >= 4
              ? [{ type: "slow" as const, durationMs: 700, slowMultiplier: masteryRank >= 8 ? 0.65 : 0.82 }] : [])],
          vfxKind: resolveCombatVfxKind(skill.tags, skill.effects, skill.vfxKind),
        };
      });
  }

  private getEffectiveRank(skillId: string, ownRank: number): number {
    return ownRank + Math.max(0, this.getInheritedActiveRank(skillId) - 2);
  }

  private getInheritedActiveRank(skillId: string): number {
    const recipe = ConfigManager.skillEvolutions.find(evolution => evolution.resultSkillId === skillId);
    if (!recipe) return 0;
    return Math.max(0, ...(recipe.requiredSkills ?? [])
      .filter(required => ConfigManager.getSkill(required.id).category === "active")
      .map(required => this.skills.getLevel(required.id)));
  }

  getAuraUpgradePreview(skillId: string): { currentRadius: number; nextRadius: number } | undefined {
    const skill = ConfigManager.skills.find(candidate => candidate.id === skillId);
    if (!skill?.aura) return undefined;
    const ownRank = this.skills.getLevel(skillId);
    const stats = this.getCombatStats();
    return {
      currentRadius: getAuraRadius(skill.aura.radius, this.getEffectiveRank(skillId, Math.max(1, ownRank)), stats.areaMultiplier),
      nextRadius: getAuraRadius(skill.aura.radius, this.getEffectiveRank(skillId, Math.min(skill.maxLevel, ownRank + 1)), stats.areaMultiplier),
    };
  }

  private getEffectValue(effects: SkillEffect[], type: "pierce"): number {
    return effects
      .filter((effect): effect is Extract<SkillEffect, { type: "pierce" }> => effect.type === type)
      .reduce((sum, effect) => sum + effect.value, 0);
  }

  private getTagDamageMultiplier(tags: string[], stats: CombatStats): number {
    let multiplier = 1;
    if (tags.includes("fire")) {
      multiplier *= stats.fireDamageMultiplier;
    }
    if (tags.includes("lightning")) {
      multiplier *= stats.lightningDamageMultiplier;
    }
    if (tags.includes("dot")) {
      multiplier *= stats.dotDamageMultiplier;
    }
    return multiplier;
  }

  private scaleEffects(effects: SkillEffect[], level: number, stats: CombatStats, tags: string[], damageMultiplier: number): SkillEffect[] {
    const tagDamage = this.getTagDamageMultiplier(tags, stats);

    return effects
      .filter((effect) => effect.type !== "stat_modifier" && effect.type !== "damage")
      .map((effect) => {
        if (effect.type === "burn" || effect.type === "poison") {
          return {
            ...effect,
            durationMs: effect.durationMs + (level - 1) * 180,
            damagePerSecond: effect.damagePerSecond * tagDamage * (1 + (level - 1) * 0.18) * damageMultiplier,
          };
        }
        if (effect.type === "freeze" || effect.type === "slow") {
          return {
            ...effect,
            durationMs: effect.durationMs + (level - 1) * 120,
          };
        }
        if (effect.type === "chain") {
          return {
            ...effect,
            jumps: Math.floor(effect.jumps + stats.chainJumpsBonus + Math.floor((level - 1) / 2)),
            radius: effect.radius * stats.areaMultiplier,
          };
        }
        if (effect.type === "explosion") {
          return {
            ...effect,
            radius: effect.radius * stats.areaMultiplier,
          };
        }
        return effect;
      });
  }
}
