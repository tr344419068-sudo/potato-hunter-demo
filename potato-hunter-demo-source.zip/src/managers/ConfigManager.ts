import difficultyJson from "../configs/difficulty.json";
import assetsJson from "../configs/assets.json";
import buildsJson from "../configs/builds.json";
import gameConfigJson from "../configs/gameConfig.json";
import monstersJson from "../configs/monsters.json";
import mapEventsJson from "../configs/mapEvents.json";
import skillEvolutionsJson from "../configs/skillEvolutions.json";
import playerJson from "../configs/player.json";
import skillsJson from "../configs/skills.json";
import wavesJson from "../configs/waves.json";
import type { MonsterComponent, SkillEffect } from "../components/ComponentTypes";
import type { CombatVfxKind } from "../systems/CombatVfxModel";

export interface GameConfig {
  width: number;
  height: number;
  backgroundColor: string;
  debugPhysics: boolean;
}

export interface PlayerConfig {
  id: string;
  moveSpeed: number;
  maxHp: number;
  pickupRadius: number;
  assetId?: string;
}

export interface MonsterConfig {
  id: string;
  name: string;
  assetId?: string;
  hp: number;
  speed: number;
  damage: number;
  radius: number;
  color: number;
  shape: "circle" | "square";
  experienceValue: number;
  behavior?: MonsterComponent["behavior"];
  shieldHp?: number;
}

export interface BossConfig {
  assetId?: string;
  finalBossAssetId?: string;
}

export interface SkillConfig {
  id: string;
  name: string;
  description: string;
  iconAssetId?: string;
  category: "active" | "passive" | "evolution" | "reward";
  maxLevel: number;
  color: string;
  tags: string[];
  rarity?: "common" | "rare" | "epic";
  vfxKind?: CombatVfxKind;
  effects: SkillEffect[];
  weapon?: {
    cooldownMs: number;
    damage: number;
    projectileSpeed: number;
    projectileCount: number;
    pierce: number;
    lifetimeMs: number;
    size: number;
    spread: number;
    projectileAssetId?: string;
    burstCount?: number;
    burstIntervalMs?: number;
    projectileCountPerTwoLevels?: number;
    minCooldownMs?: number;
  };
  aura?: {
    radius: number;
    entryDamage?: number;
    damagePerSecond: number;
    tickMs: number;
  };
}

export interface SkillEvolutionConfig {
  id: string;
  resultSkillId: string;
  requiredSkills?: Array<{ id: string; level: number }>;
  requiredTags?: string[];
  name: string;
}

export interface BuildConfig {
  id: string;
  name: string;
  tags: string[];
  coreSkills: string[];
  description: string;
}

export interface WaveConfig {
  startSeconds: number;
  monsterId: string;
  monsterMix?: Array<{ monsterId: string; weight: number }>;
  spawnIntervalMs: number;
  spawnCount: number;
  maxAlive: number;
}

export interface WavesConfig {
  bossEverySeconds: number;
  waves: WaveConfig[];
}

export interface DifficultyConfig {
  scalingStartSeconds: number;
  hpPerMinute: number;
  damagePerMinute: number;
  speedPerMinute: number;
  maxSpeedBonus: number;
  extraSpawnEverySeconds: number;
  extraMaxAlivePerMinute: number;
  eliteChancePerMinute: number;
  maxEliteChance: number;
  eliteHpMultiplier: number;
  eliteDamageMultiplier: number;
  eliteSpeedMultiplier: number;
  bossExtraHpPerSpawn: number;
}

export interface AssetConfig {
  type: "character" | "character_part" | "enemy" | "boss" | "skill_icon" | "projectile" | "background" | "ui" | "vfx";
  name: string;
  path: string;
  width: number;
  height: number;
  frameWidth?: number;
  frameHeight?: number;
  frameCount?: number;
  displaySize?: number;
  pivot?: { x: number; y: number };
  footPoint?: { x: number; y: number };
  tileable?: boolean;
}

export type AssetRegistry = Record<string, AssetConfig>;

export interface MapEventConfig {
  id: string;
  name: string;
  kind: "heal" | "xp_burst" | "haste" | "magnet" | "supply";
  value: number;
  durationMs?: number;
  radius: number;
  color: number;
  spawnAfterSeconds: number;
  intervalSeconds: number;
  lifetimeMs: number;
}

export interface MapEventsConfig {
  events: MapEventConfig[];
}

export const ConfigManager = {
  game: gameConfigJson as GameConfig,
  assets: assetsJson as AssetRegistry,
  player: playerJson as PlayerConfig,
  boss: (monstersJson as { boss?: BossConfig }).boss ?? {},
  monsters: (monstersJson as { monsters: MonsterConfig[] }).monsters,
  skills: (skillsJson as { skills: SkillConfig[] }).skills,
  skillEvolutions: (skillEvolutionsJson as { evolutions: SkillEvolutionConfig[] }).evolutions,
  builds: (buildsJson as { builds: BuildConfig[] }).builds,
  waves: wavesJson as WavesConfig,
  mapEvents: mapEventsJson as MapEventsConfig,
  difficulty: difficultyJson as DifficultyConfig,

  getMonster(monsterId: string): MonsterConfig {
    const monster = this.monsters.find((candidate) => candidate.id === monsterId);
    if (!monster) {
      throw new Error(`Missing monster config: ${monsterId}`);
    }

    return monster;
  },

  getSkill(skillId: string): SkillConfig {
    const skill = this.skills.find((candidate) => candidate.id === skillId);
    if (!skill) {
      throw new Error(`Missing skill config: ${skillId}`);
    }

    return skill;
  },
};
