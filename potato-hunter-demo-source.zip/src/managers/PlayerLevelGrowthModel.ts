import type { HealthComponent } from "../components/ComponentTypes";

/** Character growth is linear and independent of individual skill ranks. */
export function getPlayerLevelGrowth(playerLevel = 1): {
  maxHpBonus: number;
  damageMultiplier: number;
  healRatio: number;
} {
  const level = Number.isFinite(playerLevel) ? Math.max(1, Math.floor(playerLevel)) : 1;
  const earnedLevels = level - 1;
  return {
    maxHpBonus: earnedLevels * 5,
    damageMultiplier: 1 + earnedLevels * 0.02,
    healRatio: level === 1 ? 0 : level <= 5 ? 0.2 : level <= 10 ? 0.18 : 0.15,
  };
}

/** Fill only new capacity; normal stat updates must not heal existing wounds. */
export function reconcilePlayerMaxHp(health: HealthComponent, nextMaxHp: number): void {
  const gained = Math.max(0, nextMaxHp - health.max);
  health.max = nextMaxHp;
  health.current = Math.min(nextMaxHp, health.current > 0 ? health.current + gained : health.current);
}
