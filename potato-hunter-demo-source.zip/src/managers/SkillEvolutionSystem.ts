import { ConfigManager, type SkillConfig } from "./ConfigManager";
import type { SkillLevelsReader } from "./SkillTypes";

export class SkillEvolutionSystem {
  constructor(private readonly skills: SkillLevelsReader) {}

  canUnlockEvolution(resultSkillId: string): boolean {
    if (this.skills.hasSkill(resultSkillId)) {
      return false;
    }

    const evolution = ConfigManager.skillEvolutions.find((candidate) => candidate.resultSkillId === resultSkillId);
    if (!evolution) {
      return false;
    }

    const skillsReady = (evolution.requiredSkills ?? []).every((requiredSkill) => this.skills.getLevel(requiredSkill.id) >= requiredSkill.level);
    const tags = this.getOwnedTags();
    const tagsReady = (evolution.requiredTags ?? []).every((tag) => tags.has(tag));
    return skillsReady && tagsReady;
  }

  getEvolutionHint(skill: SkillConfig): string | undefined {
    if (skill.category === "reward") {
      return undefined;
    }

    if (skill.category === "evolution") {
      return this.skills.hasSkill(skill.id) ? "进化武器继续强化" : "已满足进化条件";
    }

    const best = this.getRelatedEvolutions(skill)[0];
    if (!best) {
      return undefined;
    }

    return best.missing.length === 0 ? `可进化: ${best.resultSkill.name}` : `通向: ${best.resultSkill.name}`;
  }

  getProgressHints(skill: SkillConfig): string[] {
    if (skill.category === "reward") {
      return [];
    }

    if (skill.category === "evolution") {
      return [this.skills.hasSkill(skill.id) ? "保留原技能养成，继续提升威力" : "继承原技能养成，获得质变武器"];
    }

    return this.getRelatedEvolutions(skill)
      .map((evolution) => {
        if (evolution.missing.length === 0) {
          return "选择后可满足进化条件";
        }

        return `还差: ${evolution.missing.slice(0, 2).join(" + ")}`;
      })
      .slice(0, 1);
  }

  getCardRecipe(skill: SkillConfig): { recipeProgress?: string; replacesSkill?: string } {
    const recipes = ConfigManager.skillEvolutions;
    if (skill.category === "evolution") {
      const replaced = recipes.find(recipe => recipe.resultSkillId === skill.id)?.requiredSkills
        ?.filter(requirement => ConfigManager.getSkill(requirement.id).category === "active");
      return !this.skills.hasSkill(skill.id) && replaced?.length
        ? { replacesSkill: replaced.map(r => ConfigManager.getSkill(r.id).name).join("、") } : {};
    }
    // Visible recipe copy need not compete for a guaranteed progression slot.
    const recipe = recipes.find(candidate => (candidate.showRecipeOnCard || candidate.guideAfterActiveLevel !== undefined)
      && !this.skills.hasSkill(candidate.resultSkillId)
      && ConfigManager.getSkill(candidate.resultSkillId).choicePoolEnabled !== false
      && candidate.requiredSkills?.some(requirement => requirement.id === skill.id));
    if (!recipe) return {};
    const requirements = recipe.requiredSkills ?? [];
    const projectedRank = (id: string) => this.skills.getLevel(id) + Number(id === skill.id);
    const missing = requirements.filter(req => projectedRank(req.id) < req.level);
    const name = ConfigManager.getSkill(recipe.resultSkillId).name;
    const tags = this.getOwnedTags();
    for (const tag of skill.tags) tags.add(tag);
    const extraTags = (recipe.requiredTags ?? []).some(tag => !tags.has(tag));
    const remaining = missing.find(req => req.id !== skill.id) ?? missing[0];
    const progress = remaining ? `缺 ${ConfigManager.getSkill(remaining.id).name} ${projectedRank(remaining.id)}/${remaining.level}`
      : extraTags ? "尚缺流派标签" : "选后可进化";
    return { recipeProgress: `配方 ${name} · ${progress}` };
  }

  private getRelatedEvolutions(skill: SkillConfig): Array<{ resultSkill: SkillConfig; missing: string[]; readiness: number }> {
    return ConfigManager.skillEvolutions
      .filter((evolution) => {
        const resultSkill = ConfigManager.getSkill(evolution.resultSkillId);
        if (resultSkill.choicePoolEnabled === false) return false;
        const skillIsRequired = (evolution.requiredSkills ?? []).some((requiredSkill) => requiredSkill.id === skill.id);
        const tagIsRelevant = resultSkill.tags.some((tag) => skill.tags.includes(tag));
        return skillIsRequired || tagIsRelevant;
      })
      .map((evolution) => {
        const resultSkill = ConfigManager.getSkill(evolution.resultSkillId);
        const missing = (evolution.requiredSkills ?? [])
          .filter((requiredSkill) => {
            const projectedLevel = requiredSkill.id === skill.id ? this.skills.getLevel(skill.id) + 1 : this.skills.getLevel(requiredSkill.id);
            return projectedLevel < requiredSkill.level;
          })
          .map((requiredSkill) => `${ConfigManager.getSkill(requiredSkill.id).name}Lv.${requiredSkill.level}`);

        return {
          resultSkill,
          missing,
          readiness: missing.length,
          direct: (evolution.requiredSkills ?? []).some(required => required.id === skill.id),
        };
      })
      .sort((a, b) => Number(b.direct) - Number(a.direct) || a.readiness - b.readiness);
  }

  private getOwnedTags(): Set<string> {
    const tags = new Set<string>();
    for (const skill of ConfigManager.skills) {
      if (this.skills.getLevel(skill.id) <= 0) {
        continue;
      }

      for (const tag of skill.tags) {
        tags.add(tag);
      }
    }
    return tags;
  }
}
