import Phaser from "phaser";
import { ConfigManager, type AssetConfig } from "./ConfigManager";

const TEXTURE_PREFIX = "asset:";
const ON_DEMAND_ASSETS = new Set([
  "background_battlefield_food_wasteland",
  "campaign_camp_v3",
  "campaign_victory_v3",
  "campaign_retry_v3",
  "ui_upgrade_glow_gold_center",
]);

export class AssetManager {
  private static readonly failedAssetIds = new Set<string>();
  private static loadErrorHooked = false;

  static async loadAvailable(scene: Phaser.Scene, onComplete: () => void): Promise<void> {
    this.hookLoadErrors(scene);
    const loadableAssets = this.getLoadableAssets(scene);

    for (const [assetId, asset] of loadableAssets) {
      const textureKey = this.getTextureKey(assetId);
      const { frameWidth, frameHeight, frameCount } = asset;
      if ([frameWidth, frameHeight, frameCount].every(value => Number.isInteger(value) && Number.isFinite(value) && (value ?? 0) > 0)
        && frameWidth! <= asset.width && frameHeight! <= asset.height && frameCount! <= Math.floor(asset.width / frameWidth!) * Math.floor(asset.height / frameHeight!)) {
        scene.load.spritesheet(textureKey, asset.path, { frameWidth: frameWidth!, frameHeight: frameHeight!, endFrame: frameCount! - 1 });
      } else {
        scene.load.image(textureKey, asset.path);
      }
    }

    if (loadableAssets.length === 0) {
      onComplete();
      return;
    }

    scene.load.once(Phaser.Loader.Events.COMPLETE, onComplete);
    scene.load.start();
  }

  static getAsset(assetId?: string): AssetConfig | undefined {
    if (!assetId) {
      return undefined;
    }

    return ConfigManager.assets[assetId];
  }

  static getTextureKey(assetId: string): string {
    return `${TEXTURE_PREFIX}${assetId}`;
  }

  static hasTexture(scene: Phaser.Scene, assetId?: string): boolean {
    if (!assetId || this.failedAssetIds.has(assetId)) {
      return false;
    }

    return scene.textures.exists(this.getTextureKey(assetId));
  }

  static getDisplaySize(assetId: string | undefined, fallbackSize: number): number {
    return this.getAsset(assetId)?.displaySize ?? fallbackSize;
  }

  static getPivot(assetId?: string): { x: number; y: number } {
    return this.getAsset(assetId)?.pivot ?? { x: 0.5, y: 0.5 };
  }

  static getFootPoint(assetId?: string): { x: number; y: number } {
    return this.getAsset(assetId)?.footPoint ?? { x: 0.5, y: 1 };
  }

  private static hookLoadErrors(scene: Phaser.Scene): void {
    if (this.loadErrorHooked) {
      return;
    }

    scene.load.on("loaderror", (file: Phaser.Loader.File) => {
      if (typeof file.key !== "string" || !file.key.startsWith(TEXTURE_PREFIX)) {
        return;
      }

      this.failedAssetIds.add(file.key.slice(TEXTURE_PREFIX.length));
    });
    this.loadErrorHooked = true;
  }

  private static getLoadableAssets(scene: Phaser.Scene): Array<[string, AssetConfig]> {
    return Object.entries(ConfigManager.assets).filter(([assetId, asset]) =>
      Boolean(asset.path) && !ON_DEMAND_ASSETS.has(assetId)
      // Portraits are requested by the DOM only when the bestiary is opened.
      && !asset.path.startsWith("assets/bestiary/")
      && !scene.textures.exists(this.getTextureKey(assetId)) && !this.failedAssetIds.has(assetId),
    );
  }
}
