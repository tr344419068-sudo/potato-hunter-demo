export type LevelChapterId = "moss_meadow" | "tomato_ambush" | "delivery_hunt" | "soda_crossfire" | "fryer_siege";
export type SpawnFormation = "ring" | "pincer" | "wedge" | "crossfire" | "siege";
export type BattlefieldDecorationKind = "grass" | "stone" | "sauce" | "crate" | "shard" | "puddle" | "scorch";
export type EliteAffix = "haste" | "shield" | "split" | "death_bomb";

export interface LevelChapter {
  id: LevelChapterId;
  startSeconds: number;
  act: string;
  title: string;
  subtitle: string;
  formation: SpawnFormation;
  primaryColor: number;
  secondaryColor: number;
  groundTint: number;
  overlayColor: number;
  decorationDensity: number;
  decorationKinds: readonly BattlefieldDecorationKind[];
  captain?: { monsterId: string; affix: EliteAffix };
}

export interface BattlefieldDecoration {
  kind: BattlefieldDecorationKind;
  color: number;
  secondaryColor: number;
  offsetX: number;
  offsetY: number;
  rotation: number;
  scale: number;
}

export const LEVEL_CHAPTERS: readonly Readonly<LevelChapter>[] = Object.freeze([
  Object.freeze({
    id: "moss_meadow",
    startSeconds: 0,
    act: "第一幕",
    title: "青酱草甸",
    subtitle: "别被薯条包围",
    formation: "ring",
    primaryColor: 0x91b35d,
    secondaryColor: 0xd8d09a,
    groundTint: 0xd9ead3,
    overlayColor: 0x173f2a,
    decorationDensity: 0.38,
    decorationKinds: Object.freeze(["grass", "stone"] as const),
  }),
  Object.freeze({
    id: "tomato_ambush",
    startSeconds: 10,
    act: "第二幕",
    title: "番茄突袭",
    subtitle: "双翼夹击 · 留出退路",
    formation: "pincer",
    primaryColor: 0xef476f,
    secondaryColor: 0xffbd69,
    groundTint: 0xf4d6c8,
    overlayColor: 0x7b2f35,
    decorationDensity: 0.44,
    decorationKinds: Object.freeze(["grass", "stone", "sauce"] as const),
  }),
  Object.freeze({
    id: "delivery_hunt",
    startSeconds: 24,
    act: "第三幕",
    title: "外卖围猎",
    subtitle: "三路压境 · 击破护盾队长",
    formation: "wedge",
    primaryColor: 0xffca3a,
    secondaryColor: 0x8d6e3f,
    groundTint: 0xf0dfb1,
    overlayColor: 0x705522,
    decorationDensity: 0.48,
    decorationKinds: Object.freeze(["grass", "stone", "crate"] as const),
    captain: Object.freeze({ monsterId: "delivery_box", affix: "shield" as const }),
  }),
  Object.freeze({
    id: "soda_crossfire",
    startSeconds: 40,
    act: "第四幕",
    title: "汽水交火",
    subtitle: "四向弹幕 · 用冲刺穿过火线",
    formation: "crossfire",
    primaryColor: 0x69e8ff,
    secondaryColor: 0x9f86c0,
    groundTint: 0xc9e6e3,
    overlayColor: 0x214a5c,
    decorationDensity: 0.48,
    decorationKinds: Object.freeze(["grass", "shard", "puddle"] as const),
    captain: Object.freeze({ monsterId: "cola_spitter", affix: "haste" as const }),
  }),
  Object.freeze({
    id: "fryer_siege",
    startSeconds: 60,
    act: "终幕",
    title: "油锅围城",
    subtitle: "巨型炸薯机来袭",
    formation: "siege",
    primaryColor: 0xff9f1c,
    secondaryColor: 0x5b2b20,
    groundTint: 0xe6c493,
    overlayColor: 0x6e351b,
    decorationDensity: 0.52,
    decorationKinds: Object.freeze(["stone", "crate", "scorch"] as const),
  }),
]);

const DESERT_CHAPTERS: readonly Readonly<LevelChapter>[] = LEVEL_CHAPTERS.map((chapter, index) => ({
  ...chapter,
  title: ["香料沙海", "辣椒伏击", "沙丘围猎", "玉米炮阵", "沙海终战"][index],
  subtitle: ["穿过沙丘，留心远处火枪", "避开扇形弹幕", "突破前方包围", "观察落点，冲出轰炸区", "击败首领，带回战利品"][index],
  groundTint: 0xffffff,
  overlayColor: 0xa56b25,
  primaryColor: 0xf5be61,
  secondaryColor: 0x9c6036,
  decorationDensity: .16,
  decorationKinds: ["stone", "scorch"] as const,
}));

export function getLevelChapter(elapsedMs: number, stage: "meadow" | "desert" = "meadow"): Readonly<LevelChapter> {
  const elapsedSeconds = Math.max(0, elapsedMs) / 1000;
  const chapters = stage === "desert" ? DESERT_CHAPTERS : LEVEL_CHAPTERS;
  for (let index = chapters.length - 1; index >= 0; index -= 1) {
    if (elapsedSeconds >= chapters[index].startSeconds) {
      return chapters[index];
    }
  }
  return chapters[0];
}

function normalizeAngle(angle: number): number {
  const circle = Math.PI * 2;
  return ((angle % circle) + circle) % circle;
}

export function getSpawnAngle(
  chapter: Readonly<LevelChapter>,
  index: number,
  count: number,
  random01 = Math.random(),
): number {
  const safeCount = Math.max(1, count);
  const jitter = (Math.min(1, Math.max(0, random01)) - 0.5);

  switch (chapter.formation) {
    case "pincer":
      return normalizeAngle((index % 2) * Math.PI + jitter * 0.72 + Math.floor(index / 2) * 0.08);
    case "wedge":
      return normalizeAngle((index % 3) * (Math.PI * 2 / 3) + jitter * 0.48 + Math.floor(index / 3) * 0.06);
    case "crossfire":
      return normalizeAngle(Math.PI / 4 + (index % 4) * (Math.PI / 2) + jitter * 0.3 + Math.floor(index / 4) * 0.05);
    case "siege":
      return normalizeAngle((index / safeCount) * Math.PI * 2 + jitter * 0.18 + (index % 2) * 0.08);
    default:
      return normalizeAngle((index / safeCount) * Math.PI * 2 + random01 * 0.82);
  }
}

function hashCell(x: number, y: number, salt: number): number {
  let value = Math.imul(x ^ salt, 0x45d9f3b) ^ Math.imul(y + salt, 0x27d4eb2d);
  value = Math.imul(value ^ (value >>> 16), 0x45d9f3b);
  return (value ^ (value >>> 16)) >>> 0;
}

export function getBattlefieldDecoration(
  cellX: number,
  cellY: number,
  chapter: Readonly<LevelChapter>,
): BattlefieldDecoration | undefined {
  const chapterIndex = LEVEL_CHAPTERS.findIndex((candidate) => candidate.id === chapter.id);
  const base = hashCell(cellX, cellY, 101 + Math.max(0, chapterIndex) * 977);
  const roll = (base & 0xffff) / 0xffff;
  if (roll > chapter.decorationDensity) {
    return undefined;
  }

  const detail = hashCell(cellX, cellY, 809 + Math.max(0, chapterIndex) * 313);
  const kind = chapter.decorationKinds[detail % chapter.decorationKinds.length];
  return {
    kind,
    color: chapter.primaryColor,
    secondaryColor: chapter.secondaryColor,
    offsetX: ((detail >>> 4) % 121) - 60,
    offsetY: ((detail >>> 12) % 121) - 60,
    rotation: (((detail >>> 20) % 628) / 100) - Math.PI,
    scale: 0.65 + ((detail >>> 8) % 71) / 100,
  };
}
