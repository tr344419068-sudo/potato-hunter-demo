import Phaser from "phaser";
import type { PlayerBuffComponent } from "../components/ComponentTypes";
import { createExperienceOrb } from "../entities/factories";
import type { SkillConfig } from "./ConfigManager";
import { ConfigManager } from "./ConfigManager";
import { EventBus } from "./EventBus";
import type { GameRuntime } from "../systems/SystemTypes";

export type RewardKind = "heal" | "attack_speed" | "magnet" | "gold" | "xp_burst";

export interface RewardSkillConfig extends SkillConfig {
  category: "reward";
  rewardKind: RewardKind;
  rewardValue: number;
  durationMs?: number;
}

interface RuntimeReward {
  kind: RewardKind;
  value: number;
  durationMs?: number;
  id: string;
  text: string;
}

export const UPGRADE_REWARD_CHOICES: RewardSkillConfig[] = [
  {
    id: "reward_heal",
    name: "薯条急救包",
    description: "立即回复生命",
    category: "reward",
    maxLevel: 1,
    color: "#9bde7e",
    tags: ["reward", "heal", "defense"],
    rarity: "common",
    effects: [],
    rewardKind: "heal",
    rewardValue: 40,
  },
  {
    id: "reward_attack_speed",
    name: "热油超频",
    description: "15秒内攻速+20%",
    category: "reward",
    maxLevel: 1,
    color: "#ff9f1c",
    tags: ["reward", "attack_speed", "projectile"],
    rarity: "rare",
    effects: [],
    rewardKind: "attack_speed",
    rewardValue: 0.2,
    durationMs: 15000,
  },
  {
    id: "reward_magnet",
    name: "磁吸优惠券",
    description: "15秒内磁吸范围+50%",
    category: "reward",
    maxLevel: 1,
    color: "#4cc9f0",
    tags: ["reward", "magnet", "growth"],
    rarity: "rare",
    effects: [],
    rewardKind: "magnet",
    rewardValue: 0.5,
    durationMs: 15000,
  },
  {
    id: "reward_gold",
    name: "薯币红包",
    description: "立即获得金币",
    category: "reward",
    maxLevel: 1,
    color: "#ffca3a",
    tags: ["reward", "gold", "growth"],
    rarity: "common",
    effects: [],
    rewardKind: "gold",
    rewardValue: 50,
  },
];

const SUPPLY_REWARDS: RuntimeReward[] = [
  { id: "supply_heal", kind: "heal", value: 36, text: "补给：回复生命" },
  { id: "supply_attack_speed", kind: "attack_speed", value: 0.2, durationMs: 15000, text: "补给：攻速+20%" },
  { id: "supply_magnet", kind: "magnet", value: 0.5, durationMs: 15000, text: "补给：磁吸+50%" },
  { id: "supply_gold", kind: "gold", value: 35, text: "补给：金币+35" },
];

export class RewardManager {
  static getUpgradeRewardChoice(skillId: string): RewardSkillConfig | undefined {
    return UPGRADE_REWARD_CHOICES.find((reward) => reward.id === skillId);
  }

  static isUpgradeRewardChoice(skillId: string): boolean {
    return Boolean(this.getUpgradeRewardChoice(skillId));
  }

  static applyUpgradeReward(runtime: GameRuntime, skillId: string): boolean {
    const reward = this.getUpgradeRewardChoice(skillId);
    if (!reward) {
      return false;
    }

    this.applyReward(runtime, {
      id: reward.id,
      kind: reward.rewardKind,
      value: reward.rewardValue,
      durationMs: reward.durationMs,
      text: reward.name,
    });
    return true;
  }

  static applyRandomSupplyReward(runtime: GameRuntime, x: number, y: number): void {
    const reward = runtime.random
      ? SUPPLY_REWARDS[Math.floor(runtime.random() * SUPPLY_REWARDS.length)]
      : Phaser.Utils.Array.GetRandom(SUPPLY_REWARDS);
    this.applyReward(runtime, reward, x, y);
  }

  static applyReward(runtime: GameRuntime, reward: RuntimeReward, x?: number, y?: number): void {
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    if (!playerHealth || !playerTransform || playerHealth.current <= 0) {
      return;
    }

    const fxX = x ?? playerTransform.x;
    const fxY = y ?? playerTransform.y;
    const color = this.getRewardColor(reward.kind);

    if (reward.kind === "heal") {
      playerHealth.current = Math.min(playerHealth.max, playerHealth.current + reward.value);
      EventBus.emit("combat:damage", { x: playerTransform.x, y: playerTransform.y, value: reward.value, color: "#9bde7e" });
    }

    if (reward.kind === "attack_speed") {
      this.addBuff(runtime, {
        id: reward.id,
        remainingMs: reward.durationMs ?? 15000,
        cooldownMultiplier: 1 - reward.value,
      });
    }

    if (reward.kind === "magnet") {
      this.addBuff(runtime, {
        id: reward.id,
        remainingMs: reward.durationMs ?? 15000,
        pickupRadiusBonus: ConfigManager.player.pickupRadius * reward.value,
      });
    }

    if (reward.kind === "gold") {
      runtime.stats.gold += Math.round(reward.value);
      EventBus.emit("combat:damage", { x: playerTransform.x, y: playerTransform.y, value: Math.round(reward.value), color: "#ffca3a" });
    }

    if (reward.kind === "xp_burst") {
      this.spawnExperienceBurst(runtime, fxX, fxY, reward.value);
    }

    EventBus.emit("boss:phase", { text: reward.text });
    EventBus.emit("reward:collected", { kind: reward.kind, value: reward.value });
    EventBus.emit("fx:sparks", { x: fxX, y: fxY, color, count: 18, size: 8 });
  }

  private static spawnExperienceBurst(runtime: GameRuntime, x: number, y: number, value: number): void {
    for (let index = 0; index < 8; index += 1) {
      const angle = (Math.PI * 2 * index) / 8;
      createExperienceOrb(runtime.world, x + Math.cos(angle) * 32, y + Math.sin(angle) * 32, Math.ceil(value / 8));
    }
  }

  private static addBuff(runtime: GameRuntime, buff: PlayerBuffComponent): void {
    const buffs = (runtime.world.components.playerBuffs.get(runtime.playerId) ?? []).filter((candidate) => candidate.id !== buff.id);
    runtime.world.components.playerBuffs.set(runtime.playerId, [...buffs, buff]);
  }

  private static getRewardColor(kind: RewardKind): number {
    if (kind === "heal") {
      return 0x9bde7e;
    }
    if (kind === "magnet" || kind === "xp_burst") {
      return 0x4cc9f0;
    }
    return 0xffca3a;
  }
}
