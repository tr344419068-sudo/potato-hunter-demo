import Phaser from "phaser";
import { createMapEvent, createMonster, createPlayer } from "../entities/factories";
import { World } from "../entities/World";
import { ConfigManager, type SkillConfig } from "../managers/ConfigManager";
import { DifficultyManager } from "../managers/DifficultyManager";
import { EventBus } from "../managers/EventBus";
import { getNextExperienceRequirement } from "../managers/PacingModel";
import { RewardManager, UPGRADE_REWARD_CHOICES } from "../managers/RewardManager";
import { SkillManager, type SkillChoiceHint } from "../managers/SkillManager";
import { WaveManager } from "../managers/WaveManager";
import { AuraSystem } from "../systems/AuraSystem";
import { AoeWarningSystem } from "../systems/AoeWarningSystem";
import { AutoAttackSystem } from "../systems/AutoAttackSystem";
import { PalmStrikeSystem } from "../systems/PalmStrikeSystem";
import { SpatialSkillSystem } from "../systems/SpatialSkillSystem";
import { BossSystem } from "../systems/BossSystem";
import { clearBossDuel, DUEL_BOSS_DISTANCE, getBossDuel, startBossDuel } from "../systems/BossDuelArena";
import { clearDesertCast } from "../systems/DesertBossEncounter";
import { canShowDesertAttack } from "../systems/DesertBossView";
import { createFinalBossHealth, DESERT_BOSS_HEALTH_BANDS, DESERT_BOSS_HP_SCALE, FINAL_BOSS_ASSET_ID, FINAL_BOSS_HP_MULTIPLIER, FINAL_BOSS_VISUAL_SIZE, getCampaignFinalBossPhase } from "../systems/FinalBossPatternModel";
import { getTempoSpeedBonus } from "../systems/AttackTempoModel";
import { DeathSystem } from "../systems/DeathSystem";
import { DebugHotkeySystem } from "../systems/DebugHotkeySystem";
import { EnemyProjectileSystem } from "../systems/EnemyProjectileSystem";
import { ExperienceSystem } from "../systems/ExperienceSystem";
import { FeedbackSystem } from "../systems/FeedbackSystem";
import { HitFeedbackSystem } from "../systems/HitFeedbackSystem";
import { InputSystem } from "../systems/InputSystem";
import { KnockbackSystem } from "../systems/KnockbackSystem";
import { LifetimeSystem } from "../systems/LifetimeSystem";
import { MapEventSystem } from "../systems/MapEventSystem";
import { MonsterAISystem } from "../systems/MonsterAISystem";
import { MonsterBehaviorSystem } from "../systems/MonsterBehaviorSystem";
import { MonsterContactSystem } from "../systems/MonsterContactSystem";
import { MovementSystem } from "../systems/MovementSystem";
import { PlayerStatsSystem } from "../systems/PlayerStatsSystem";
import { ProjectileCollisionSystem } from "../systems/ProjectileCollisionSystem";
import { RenderSystem } from "../systems/RenderSystem";
import { SpawnSystem } from "../systems/SpawnSystem";
import { SpriteJuiceSystem } from "../systems/SpriteJuiceSystem";
import { StatusEffectSystem } from "../systems/StatusEffectSystem";
import { CombatVfxSystem } from "../systems/CombatVfxSystem";
import { BattlefieldBackground } from "../systems/BattlefieldBackground";
import { ChapterDirectorSystem } from "../systems/ChapterDirectorSystem";
import type { GameRuntime, RunStats, System } from "../systems/SystemTypes";
import { getDashCooldownRatio } from "../systems/DashModel";
import { CampaignDirector, FINAL_BOSS_AT_MS, getCampaignBeat, type BossKind, type RunOutcome } from "../campaign/CampaignModel";
import { RunTelemetry } from "../campaign/RunTelemetry";
import { bossTestStage, createRunIdentity, progression } from "../campaign/AppState";
import { LOADOUTS } from "../progression/ProgressionStore";
import { getTrainingBonuses, type StageId } from "../progression/CampaignGrowth";
import type { BossHudData } from "../ui/HUDView";

export class GameScene extends Phaser.Scene {
  private world = new World();
  private skillManager = new SkillManager();
  private waveManager = new WaveManager();
  private difficultyManager = new DifficultyManager();
  private playerId = 0;
  private systems: System[] = [];
  private renderSystem?: RenderSystem;
  private feedbackSystem?: FeedbackSystem;
  private battlefieldBackground?: BattlefieldBackground;
  private stats: RunStats = { elapsedMs: 0, kills: 0, bossKills: 0, gold: 0 };
  private choosingSkill = false;
  private pendingUpgrades = 0;
  private upgradeSessionId = 0;
  private offeredUpgradeIds = new Set<string>();
  private pendingOffer?: SkillConfig[];
  private gameOver = false;
  private hudTimerMs = 0;
  private atHome = false;
  private paused = false;
  private campaign?: CampaignDirector;
  private telemetry?: RunTelemetry;
  private runId = "";
  private rerollsRemaining = 2;
  private phase = "";
  private nextRestSupplyAt = 0;
  private processingSystem = false;
  private pendingOutcome?: RunOutcome;
  private finalBossDiedThisStep = false;
  private runStage?: StageId;
  private bossTestStage?: StageId;
  private trainingBonuses = { damageMultiplier: 1, maxHp: 0, pickupRadius: 0 };

  constructor() {
    super("GameScene");
  }

  create(data: { startRun?: boolean; seed?: number } = {}): void {
    this.world = new World();
    this.atHome = !data.startRun;
    this.paused = false;
    this.bossTestStage = data.startRun ? bossTestStage : undefined;
    // A repeatable opening position below the HUD even on narrow phones.
    const identity = createRunIdentity(data.seed ?? (this.bossTestStage ? 15 : undefined));
    this.runId = identity.runId;
    this.campaign = data.startRun ? new CampaignDirector(identity.seed) : undefined;
    this.telemetry = data.startRun ? new RunTelemetry(identity.seed) : undefined;
    const campaignProgress = progression.getCampaignProgress();
    this.runStage = data.startRun ? this.bossTestStage ?? campaignProgress.selectedStage : undefined;
    this.trainingBonuses = data.startRun && !this.bossTestStage ? getTrainingBonuses(campaignProgress.training) : { damageMultiplier: 1, maxHp: 0, pickupRadius: 0 };
    const selected = LOADOUTS.find(l => l.id === progression.getProfile().selectedLoadout) ?? LOADOUTS[0];
    const starterSkillId = this.bossTestStage ? "pepper_gatling" : selected.starterSkillId;
    this.skillManager = data.startRun ? new SkillManager({ stage: this.runStage, starterSkillId, enforceSlots: true, random: this.campaign?.random.bind(this.campaign), permanentDamageMultiplier: this.trainingBonuses.damageMultiplier }) : new SkillManager();
    this.waveManager = new WaveManager(this.runStage);
    this.difficultyManager = new DifficultyManager();
    this.stats = { elapsedMs: 0, kills: 0, bossKills: 0, gold: 0 };
    this.choosingSkill = false;
    this.pendingUpgrades = 0;
    this.offeredUpgradeIds.clear();
    this.pendingOffer = undefined;
    this.hudTimerMs = 0;
    this.gameOver = false;
    this.rerollsRemaining = 2;
    this.phase = "";
    this.nextRestSupplyAt = 0;
    this.processingSystem = false;
    this.pendingOutcome = undefined;
    this.finalBossDiedThisStep = false;
    this.syncPresentationPause();

    this.playerId = createPlayer(
      this.world,
      0,
      0,
      ConfigManager.player.moveSpeed,
      ConfigManager.player.maxHp + this.trainingBonuses.maxHp,
      ConfigManager.player.pickupRadius + this.trainingBonuses.pickupRadius,
      ConfigManager.player.assetId,
    );
    if (this.bossTestStage) {
      for (const [skillId, rank] of [["pepper_gatling", 6], ["hot_oil_flask", 5], ["skewer_javelin", 4]] as const) {
        for (let n = this.skillManager.getLevel(skillId); n < rank; n++) this.skillManager.levelUp(skillId);
      }
      const player = this.world.components.players.get(this.playerId)!;
      while (player.level < 15) player.experienceToNext = getNextExperienceRequirement(player.experienceToNext, ++player.level);
    }

    const graphics = this.add.graphics();
    this.battlefieldBackground = new BattlefieldBackground(this, this.runStage);
    this.renderSystem = new RenderSystem(this, graphics);
    this.feedbackSystem = new FeedbackSystem(this);
    this.systems = [
      new InputSystem(this, this.playerId),
      ...(!this.campaign && !this.atHome ? [new DebugHotkeySystem(this, this.playerId)] : []),
      new PlayerStatsSystem(),
      ...(this.bossTestStage ? [] : [new ChapterDirectorSystem(), new SpawnSystem()]),
      new MonsterAISystem(),
      new MonsterBehaviorSystem(),
      new BossSystem(),
      new AoeWarningSystem(),
      ...(this.bossTestStage ? [] : [new MapEventSystem()]),
      new AutoAttackSystem(),
      new PalmStrikeSystem(),
      new AuraSystem(),
      new StatusEffectSystem(),
      new MovementSystem(),
      new KnockbackSystem(),
      new SpatialSkillSystem(),
      new ProjectileCollisionSystem(),
      new EnemyProjectileSystem(),
      new DeathSystem(),
      new ExperienceSystem(),
      new MonsterContactSystem(),
      new HitFeedbackSystem(),
      new SpriteJuiceSystem(this),
      new CombatVfxSystem(this),
      this.feedbackSystem,
      new LifetimeSystem(),
    ];

    this.cameras.main.setBackgroundColor(ConfigManager.game.backgroundColor);
    this.cameras.main.setZoom(1);

    EventBus.emit("ui:clear");
    EventBus.on("skill:selected", this.handleSkillSelected, this);
    EventBus.on("upgrade:open", this.openUpgradeChoices, this);
    EventBus.on("upgrade:cancel", this.cancelUpgradeChoices, this);
    this.input.keyboard?.on("keydown-U", this.openUpgradeChoices, this);
    EventBus.on("run:restart", this.handleRestart, this);
    EventBus.on("campaign:start", this.beginCampaignRun, this);
    EventBus.on("campaign:home", this.returnHome, this);
    EventBus.on("campaign:pause", this.setCampaignPaused, this);
    EventBus.on("campaign:abandon", this.abandonCampaign, this);
    EventBus.on("upgrade:reroll", this.rerollUpgradeChoices, this);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      EventBus.off("skill:selected", this.handleSkillSelected, this);
      EventBus.off("upgrade:open", this.openUpgradeChoices, this);
      EventBus.off("upgrade:cancel", this.cancelUpgradeChoices, this);
      this.input.keyboard?.off("keydown-U", this.openUpgradeChoices, this);
      EventBus.off("run:restart", this.handleRestart, this);
      EventBus.off("campaign:start", this.beginCampaignRun, this);
      EventBus.off("campaign:home", this.returnHome, this);
      EventBus.off("campaign:pause", this.setCampaignPaused, this);
      EventBus.off("campaign:abandon", this.abandonCampaign, this);
      EventBus.off("upgrade:reroll", this.rerollUpgradeChoices, this);
    });
    EventBus.emit("campaign:ready", { atHome: this.atHome, seed: this.campaign?.seed });
    if (this.bossTestStage) this.spawnCampaignBoss("final");
  }

  update(_time: number, deltaMs: number): void {
    this.syncPresentationPause();
    // Short visible slow frames catch up in safe slices; long stalls never teleport combat.
    const clampedDelta = Number.isFinite(deltaMs) ? Math.max(0, Math.min(deltaMs, 250)) : 0;
    const runtime = this.createRuntime();

    let remainingMs = clampedDelta;
    while (remainingMs > 0 && !this.atHome && !this.paused && !this.choosingSkill && !this.gameOver) {
      const stepMs = Math.min(remainingMs, 40);
      remainingMs -= stepMs;
      this.finalBossDiedThisStep = false;
      this.stats.elapsedMs += stepMs;
      if (this.campaign) this.updateCampaign(runtime);

      const player = this.world.components.players.get(this.playerId);
      runtime.hostileProtectionAtStepStart = player && { dashRemainingMs: player.dashRemainingMs, damageCooldownMs: player.damageCooldownMs };
      for (const system of this.systems) {
        const beforeHp = this.world.components.health.get(this.playerId)?.current;
        this.processingSystem = true;
        try { system.update(stepMs, runtime); } finally { this.processingSystem = false; }
        const afterHp = this.world.components.health.get(this.playerId)?.current;
        if (beforeHp !== undefined && afterHp !== undefined) {
          const source = system.telemetrySource ?? "OtherSystem";
          this.telemetry?.recordHealthChange(beforeHp, afterHp, source);
          if (afterHp < beforeHp) EventBus.emit("player:damaged", { value: beforeHp - afterHp, source });
        }
        if (this.pendingOutcome === "defeat") this.endRun("defeat");
        // A final kill is provisional until later hostile systems resolve this same step.
        // An XP chooser cannot bypass that damage by pausing midway through the terminal step.
        if ((this.choosingSkill && this.pendingOutcome !== "victory" && !this.finalBossDiedThisStep) || this.gameOver) {
          break;
        }
      }
      if (this.pendingOutcome === "victory") this.endRun("victory");
    }

    this.updateCamera();
    const playerTransform = this.world.components.transforms.get(this.playerId);
    this.battlefieldBackground?.update(this.stats.elapsedMs, playerTransform?.x ?? 0, playerTransform?.y ?? 0, Boolean(getBossDuel(this.world)));
    this.renderSystem?.update(this.gameOver || (!this.atHome && !this.paused && !this.choosingSkill) ? clampedDelta : 0, runtime);
    this.emitHud(clampedDelta);
    if (this.campaign && !this.atHome) {
      const player = this.world.components.players.get(this.playerId), health = this.world.components.health.get(this.playerId);
      if (player && health) this.telemetry?.snapshot({ elapsedMs: this.stats.elapsedMs, level: player.level, hp: health.current, maxHp: health.max, entities: this.world.entityCount });
      EventBus.emit("campaign:status", { ...this.campaign.getBeat(this.stats.elapsedMs, this.runStage), elapsedMs: this.stats.elapsedMs, paused: this.paused, choosing: this.choosingSkill, bossActive: [...this.world.components.monsters.values()].some(m => m.isBoss), finalBossDefeated: this.campaign.hasDefeatedFinalBoss(), rerollsRemaining: this.rerollsRemaining });
    }
  }

  private createRuntime(): GameRuntime {
    return {
      scene: this,
      world: this.world,
      playerId: this.playerId,
      skillManager: this.skillManager,
      waveManager: this.waveManager,
      stats: this.stats,
      canShowDesertAttack: this.renderSystem ? pattern => canShowDesertAttack(this, pattern) : undefined,
      requestSkillChoice: (choices, hints) => this.requestSkillChoice(choices, hints),
      endRun: (outcome) => this.endRun(outcome),
      campaign: this.campaign ? { stage: this.runStage, spawnMultiplier: this.campaign.getBeat(this.stats.elapsedMs, this.runStage).spawnMultiplier, ownBossCadence: true, finalBossDefeated: this.campaign.hasDefeatedFinalBoss(), training: { maxHp: this.trainingBonuses.maxHp, pickupRadius: this.trainingBonuses.pickupRadius } } : undefined,
      random: this.campaign?.random.bind(this.campaign),
      onMonsterDefeated: this.campaign ? (id, isBoss) => {
        if (this.campaign?.isFinalBoss(id)) this.finalBossDiedThisStep = true;
        const health = this.world.components.health.get(this.playerId);
        const alive = (health?.current ?? 0) > 0;
        if (isBoss) this.campaign?.recordOpeningEliteDefeat(id, alive, this.stats.elapsedMs, this.runStage);
        if (this.campaign?.onMonsterDefeated(id, alive, this.world.components.monsters.size)) this.endRun("victory");
      } : undefined,
      spawnBossNow: () => this.spawnBossNow(),
      addDebugTime: (milliseconds) => this.addDebugTime(milliseconds),
      clearMonsters: () => this.clearMonsters(),
    };
  }

  private requestSkillChoice(_choices: SkillConfig[], _hints?: SkillChoiceHint[]): void {
    if (this.gameOver) {
      return;
    }
    this.pendingUpgrades += 1;
    this.hudTimerMs = 0;
    this.openUpgradeChoices();
  }

  private openUpgradeChoices(event?: KeyboardEvent): void {
    if (event?.repeat || this.pendingUpgrades <= 0 || this.choosingSkill || this.gameOver || this.paused) return;
    const normalizedChoices = this.pendingOffer ?? this.ensureChoiceCount(this.skillManager.getChoices(3), 3);
    if (normalizedChoices.length === 0) return;
    this.choosingSkill = true;
    this.hudTimerMs = 0;
    this.syncPresentationPause();
    this.pendingOffer = [...normalizedChoices];
    this.upgradeSessionId += 1;
    this.offeredUpgradeIds = new Set(normalizedChoices.map(choice => choice.id));
    EventBus.emit("level:choices", {
      choices: normalizedChoices,
      hints: this.skillManager.getChoiceHints(normalizedChoices, this.world.components.players.get(this.playerId)?.level),
      levels: Object.fromEntries(normalizedChoices.map((choice) => [choice.id, Math.max(!this.campaign && choice.id === "peeler_blade" ? 1 : 0, this.skillManager.getLevel(choice.id))])),
      sessionId: this.upgradeSessionId,
      rerollsRemaining: this.rerollsRemaining,
    });
  }

  private cancelUpgradeChoices(): void {
    if (!this.choosingSkill || this.paused) return;
    this.choosingSkill = false;
    this.syncPresentationPause();
    this.offeredUpgradeIds.clear();
    EventBus.emit("upgrade:closed");
  }

  private rerollUpgradeChoices(): void {
    if (!this.choosingSkill || this.pendingUpgrades <= 0 || this.rerollsRemaining <= 0 || this.gameOver || this.paused) return;
    const excludedIds = this.offeredUpgradeIds;
    const normalizedChoices = this.ensureChoiceCount(this.skillManager.getChoices(3, excludedIds), 3, excludedIds);
    if (normalizedChoices.length === 0) return;
    this.rerollsRemaining -= 1;
    this.pendingOffer = [...normalizedChoices];
    this.upgradeSessionId += 1;
    this.offeredUpgradeIds = new Set(normalizedChoices.map(choice => choice.id));
    EventBus.emit("level:choices", {
      choices: normalizedChoices,
      hints: this.skillManager.getChoiceHints(normalizedChoices, this.world.components.players.get(this.playerId)?.level),
      levels: Object.fromEntries(normalizedChoices.map((choice) => [choice.id, Math.max(!this.campaign && choice.id === "peeler_blade" ? 1 : 0, this.skillManager.getLevel(choice.id))])),
      sessionId: this.upgradeSessionId,
      rerollsRemaining: this.rerollsRemaining,
    });
  }

  private beginCampaignRun(): void { this.scene.restart({ startRun: true }); }
  private returnHome(): void { this.scene.restart({ startRun: false }); }
  private abandonCampaign(): void { if (this.campaign && !this.atHome) this.endRun("defeat"); }
  private setCampaignPaused(value: boolean): void {
    if (this.atHome || this.gameOver) return;
    this.paused = Boolean(value);
    this.syncPresentationPause();
    EventBus.emit("campaign:paused", this.paused);
  }
  private syncPresentationPause(): void {
    const stopped = !this.gameOver && (this.atHome || this.paused || this.choosingSkill);
    if (this.tweens) {
      // The manager uses wall time; discard the paused interval without updating targets.
      if (this.tweens.paused && !stopped) this.tweens.getDelta?.(false);
      this.tweens.paused = stopped;
    }
    if (this.time) this.time.paused = stopped;
  }

  private updateCampaign(runtime: GameRuntime): void {
    if (!this.campaign || this.bossTestStage) return;
    const beat = this.campaign.getBeat(this.stats.elapsedMs, this.runStage);
    if (runtime.campaign) runtime.campaign.spawnMultiplier = beat.spawnMultiplier;
    const kind = this.campaign.nextBoss(this.stats.elapsedMs);
    if (kind) this.spawnCampaignBoss(kind);
    const health = this.world.components.health.get(this.playerId);
    // The elite's breather is only a spawn change; regular supplies retain their own cadence.
    const restSupply = this.stats.elapsedMs >= this.nextRestSupplyAt && getCampaignBeat(this.stats.elapsedMs, this.runStage).phase === "respite";
    const rescue = health && this.campaign.shouldRescue(this.stats.elapsedMs, health.current / health.max);
    if (health && health.current > 0 && (restSupply || rescue)) {
      if (restSupply) this.nextRestSupplyAt = this.stats.elapsedMs + 70_000;
      const player = this.world.components.transforms.get(this.playerId);
      const angle = this.campaign.random() * Math.PI * 2;
      createMapEvent(this.world, { id: "campaign_rescue", name: "战地急救", kind: "heal", value: Math.ceil(health.max * .25), radius: 22, color: 0x93d378, lifetimeMs: 20_000, spawnAfterSeconds: 0, intervalSeconds: 0 }, (player?.x ?? 0) + Math.cos(angle) * 180, (player?.y ?? 0) + Math.sin(angle) * 180);
      EventBus.emit("campaign:supply", { rescue: Boolean(rescue) });
    }
    if (beat.phase !== this.phase) { this.phase = beat.phase; EventBus.emit("campaign:phase", beat); }
  }

  private spawnCampaignBoss(kind: BossKind): void {
    if (!this.campaign) return;
    const player = this.world.components.transforms.get(this.playerId);
    const angle = this.campaign.random() * Math.PI * 2;
    const bossAsset = kind === "final" && this.runStage === "desert" ? "boss_desert_sultan" : kind === "final" ? ConfigManager.boss.finalBossAssetId ?? FINAL_BOSS_ASSET_ID : ConfigManager.boss.assetId;
    const distance = kind === "final" ? DUEL_BOSS_DISTANCE : 460;
    const originX = player?.x ?? 0, originY = player?.y ?? 0;
    const id = createMonster(this.world, ConfigManager.getMonster("delivery_box"), originX + Math.cos(angle) * distance, originY + Math.sin(angle) * distance, true, bossAsset);
    this.world.components.monsters.get(id)!.bossKind = kind;
    this.difficultyManager.applyToMonster(this.world, id, this.bossTestStage ? FINAL_BOSS_AT_MS : this.stats.elapsedMs, this.campaign.random.bind(this.campaign));
    if (kind === "final") {
      const monster = this.world.components.monsters.get(id)!;
      const maxHp = Math.ceil(this.world.components.health.get(id)!.max * FINAL_BOSS_HP_MULTIPLIER * (this.runStage === "desert" ? DESERT_BOSS_HP_SCALE : 1));
      monster.finalBossEncounter = { phase: 1, completedCasts: 0, transitioning: false };
      this.world.components.health.set(id, createFinalBossHealth(maxHp, monster.finalBossEncounter, this.runStage ?? "meadow"));
      this.world.components.transforms.get(id)!.radius *= 1.25;
      this.world.components.renders.get(id)!.size = FINAL_BOSS_VISUAL_SIZE;
      startBossDuel(this.world, { x: originX, y: originY, bossId: id, stage: this.runStage ?? "meadow", startedAt: this.stats.elapsedMs });
      for (const threat of this.world.components.aoeWarnings.keys()) this.world.destroyEntity(threat);
      for (const shot of this.world.components.enemyProjectiles.keys()) this.world.destroyEntity(shot);
      for (const [otherId, other] of this.world.components.monsters) {
        if (otherId === id) continue;
        other.controlledMotion = false; other.controlledMotionRemainingMs = undefined;
        other.roleState = undefined; other.jumpProgress = undefined; other.stateTimerMs = 0;
        this.world.components.knockbacks.delete(otherId);
      }
    }
    this.campaign.registerBoss(id, kind);
    EventBus.emit("boss:spawned", { entityId: id, final: kind === "final", stage: this.runStage });
  }

  private ensureChoiceCount(choices: SkillConfig[], count: number, excludedIds: ReadonlySet<string> = new Set()): SkillConfig[] {
    const result: SkillConfig[] = [];
    for (const choice of choices) {
      if (excludedIds.has(choice.id) || result.some((selected) => selected.id === choice.id)) {
        continue;
      }
      result.push(choice);
      if (result.length >= count) {
        return result;
      }
    }

    const rewards = [...UPGRADE_REWARD_CHOICES];
    const random = this.skillManager.getRandom() ?? this.campaign?.random.bind(this.campaign);
    if (random) {
      for (let index = rewards.length - 1; index > 0; index--) {
        const target = Math.floor(random() * (index + 1));
        [rewards[index], rewards[target]] = [rewards[target], rewards[index]];
      }
    } else {
      Phaser.Utils.Array.Shuffle(rewards);
    }
    for (const reward of rewards) {
      if (excludedIds.has(reward.id) || result.some((selected) => selected.id === reward.id)) {
        continue;
      }
      result.push(reward);
      if (result.length >= count) {
        return result;
      }
    }

    for (const choice of [...choices, ...rewards]) {
      if (result.some((selected) => selected.id === choice.id)) {
        continue;
      }
      result.push(choice);
      if (result.length >= count) {
        return result;
      }
    }

    return result;
  }

  private handleSkillSelected(selection: { skillId: string; sessionId: number }): void {
    if (!selection || !this.choosingSkill || this.pendingUpgrades <= 0 || this.gameOver || this.paused
      || selection.sessionId !== this.upgradeSessionId || !this.offeredUpgradeIds.has(selection.skillId)) {
      return;
    }
    const skillId = selection.skillId;
    this.pendingOffer = undefined;
    this.offeredUpgradeIds.clear();
    this.pendingUpgrades -= 1;
    this.choosingSkill = false;
    this.syncPresentationPause();
    this.hudTimerMs = 0;
    EventBus.emit("upgrade:closed");
    const beforeHp = this.world.components.health.get(this.playerId)?.current;
    if (!RewardManager.applyUpgradeReward(this.createRuntime(), skillId)) {
      const skill = ConfigManager.getSkill(skillId);
      if (!this.campaign && skillId === "peeler_blade" && this.skillManager.getLevel(skillId) === 0) this.skillManager.levelUp(skillId);
      this.skillManager.levelUp(skillId);
      if (skill.category === "evolution") {
        EventBus.emit("evolution:unlocked", { name: skill.name, color: skill.color });
      }
    }
    const afterHp = this.world.components.health.get(this.playerId)?.current;
    if (beforeHp !== undefined && afterHp !== undefined) this.telemetry?.recordHealthChange(beforeHp, afterHp, "UpgradeReward");
    this.openUpgradeChoices();
  }

  private endRun(outcome: RunOutcome = "defeat"): void {
    if (this.gameOver) {
      return;
    }
    if (this.processingSystem) { if (outcome === "defeat" || !this.pendingOutcome) this.pendingOutcome = outcome; return; }
    if (outcome === "victory" && (this.world.components.health.get(this.playerId)?.current ?? 0) <= 0) outcome = "defeat";

    this.pendingOutcome = undefined;
    this.choosingSkill = false;
    this.pendingUpgrades = 0;
    this.pendingOffer = undefined;
    this.offeredUpgradeIds.clear();
    this.hudTimerMs = 0;
    this.gameOver = true;
    clearBossDuel(this.world);
    clearDesertCast(this.world);
    for (const warningId of this.world.components.aoeWarnings.keys()) this.world.destroyEntity(warningId);
    this.syncPresentationPause();
    this.campaign?.finish(outcome);
    const settlement = this.campaign && !this.bossTestStage ? progression.settleRun(this.runId, { ...this.stats, outcome }, this.runStage) : undefined;
    EventBus.emit("upgrade:closed");
    EventBus.emit("game:over", {
      elapsedMs: this.stats.elapsedMs,
      kills: this.stats.kills,
      bossKills: this.stats.bossKills,
      gold: this.stats.gold,
      level: this.world.components.players.get(this.playerId)?.level ?? 1,
      outcome,
      stage: this.runStage,
      campaign: Boolean(this.campaign),
      settlement,
      telemetry: this.telemetry?.getReport(),
      build: this.skillManager.getActiveBuilds().map(b => b.name),
    });
  }

  private handleRestart(): void {
    this.pendingOffer = undefined;
    this.pendingUpgrades = 0;
    this.choosingSkill = false;
    this.offeredUpgradeIds.clear();
    EventBus.emit("ui:clear");
    this.scene.restart(this.campaign ? { startRun: true } : undefined);
  }

  private spawnBossNow(): void {
    if (this.campaign || this.atHome) return;
    const wave = this.waveManager.getCurrentWave(this.stats.elapsedMs);
    const monsterConfig = ConfigManager.getMonster(wave.monsterId);
    const playerTransform = this.world.components.transforms.get(this.playerId);
    const angle = Phaser.Math.FloatBetween(0, Math.PI * 2);
    const x = (playerTransform?.x ?? 0) + Math.cos(angle) * 520;
    const y = (playerTransform?.y ?? 0) + Math.sin(angle) * 520;

    const bossId = createMonster(this.world, monsterConfig, x, y, true, ConfigManager.boss.assetId);
    this.difficultyManager.applyToMonster(this.world, bossId, this.stats.elapsedMs);
    EventBus.emit("boss:spawned");
  }

  private addDebugTime(milliseconds: number): void {
    if (this.campaign || this.atHome) return;
    this.stats.elapsedMs += milliseconds;
  }

  private clearMonsters(): void {
    if (this.campaign || this.atHome) return;
    for (const entityId of [...this.world.components.monsters.keys()]) {
      this.world.destroyEntity(entityId);
    }
  }

  private updateCamera(): void {
    const transform = this.world.components.transforms.get(this.playerId);
    if (!transform) {
      return;
    }

    this.cameras.main.scrollX = transform.x - this.cameras.main.width / 2;
    this.cameras.main.scrollY = transform.y - this.cameras.main.height / 2;
  }

  private emitHud(deltaMs: number): void {
    this.hudTimerMs -= deltaMs;
    if (this.hudTimerMs > 0) {
      return;
    }

    const player = this.world.components.players.get(this.playerId);
    const health = this.world.components.health.get(this.playerId);
    const wave = this.waveManager.getCurrentWave(this.stats.elapsedMs);
    const hudSkills = this.skillManager.getKnownSkills();
    const starterId = this.skillManager.getStarterSkillId();
    if (!hudSkills.some(skill => skill.id === starterId) && !this.skillManager.isSkillSuppressed(starterId)) {
      const starterSkill = ConfigManager.getSkill(starterId);
      hudSkills.unshift({ id: starterSkill.id, name: starterSkill.name, level: 1, category: starterSkill.category });
    }

    EventBus.emit("hud:update", {
      elapsedMs: this.stats.elapsedMs,
      kills: this.stats.kills,
      bossKills: this.stats.bossKills,
      gold: this.stats.gold,
      level: player?.level ?? 1,
      pendingUpgrades: this.pendingUpgrades,
      choosingUpgrade: this.choosingSkill,
      experience: player?.experience ?? 0,
      experienceToNext: player?.experienceToNext ?? 1,
      hp: health?.current ?? 0,
      maxHp: health?.max ?? 1,
      healthAtFeet: Boolean(this.campaign),
      aliveMonsters: this.world.components.monsters.size,
      waveMonsterId: wave.monsterId,
      waveLabel: this.bossTestStage ? "首领对决" : undefined,
      skills: hudSkills,
      builds: this.skillManager.getActiveBuilds().map((build) => build.name),
      boss: this.getBossHudData(),
      difficulty: this.difficultyManager.getState(this.bossTestStage ? FINAL_BOSS_AT_MS : this.stats.elapsedMs),
      dashCooldownRatio: getDashCooldownRatio(player?.dashCooldownMs ?? 0),
      // Nominal bonuses compound; weapon cooldown floors and temporary buffs can alter effective rates.
      attackSpeedBonus: (1 + this.skillManager.getCombatStats().attackSpeedBonus) * (1 + getTempoSpeedBonus(player, this.skillManager.getLevel("combo_gear"))) - 1,
      tempoStacks: player?.tempo?.stacks ?? 0,
      debug: !this.campaign && !this.atHome ? {
        entities: this.world.entityCount,
        sparks: this.feedbackSystem?.getActiveSparkCount() ?? 0,
      } : undefined,
    });
    this.hudTimerMs = 120;
  }

  private getBossHudData(): BossHudData | undefined {
    let boss: BossHudData | undefined;

    for (const [entityId, monster] of this.world.components.monsters) {
      if (!monster.isBoss) {
        continue;
      }

      const health = this.world.components.health.get(entityId);
      if (!health || health.current <= 0) {
        continue;
      }

      if (monster.bossKind === "final") {
        const encounter = monster.finalBossEncounter;
        const armor = encounter?.sandArmor;
        return {
          hp: health.current, maxHp: health.max,
          name: this.runStage === "desert" ? "沙海堡垒之王" : "堡垒暴君",
          phase: encounter && {
            current: encounter.phase,
            label: getCampaignFinalBossPhase(this.runStage ?? "meadow", encounter.phase).label,
            transitioning: encounter.transitioning,
            ...(this.runStage === "desert" ? { bands: DESERT_BOSS_HEALTH_BANDS } : {}),
          },
          ...(armor && armor.hp > 0 ? { shield: { current: armor.hp, max: armor.max } } : {}),
        };
      }
      boss ??= { hp: health.current, maxHp: health.max, name: "巨型炸薯机" };
    }

    return boss;
  }
}
