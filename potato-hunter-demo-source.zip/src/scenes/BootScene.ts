import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import { EventBus } from "../managers/EventBus";

export class BootScene extends Phaser.Scene {
  constructor() {
    super("BootScene");
  }

  create(): void {
    let failed = 0;
    let progress = 0;
    const reportProgress = (value: number): void => {
      progress = value;
      EventBus.emit("campaign:loading", { progress, failed });
    };
    const reportFailure = (): void => {
      failed += 1;
      reportProgress(progress);
    };
    this.load.on(Phaser.Loader.Events.PROGRESS, reportProgress);
    this.load.on(Phaser.Loader.Events.FILE_LOAD_ERROR, reportFailure);
    void AssetManager.loadAvailable(this, () => {
      this.load.off(Phaser.Loader.Events.PROGRESS, reportProgress);
      this.load.off(Phaser.Loader.Events.FILE_LOAD_ERROR, reportFailure);
      this.scene.launch("UIScene");
      this.scene.start("GameScene");
    });
  }
}
