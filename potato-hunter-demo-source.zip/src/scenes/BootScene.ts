import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";

export class BootScene extends Phaser.Scene {
  constructor() {
    super("BootScene");
  }

  create(): void {
    void AssetManager.loadAvailable(this, () => {
      this.scene.launch("UIScene");
      this.scene.start("GameScene");
    });
  }
}
