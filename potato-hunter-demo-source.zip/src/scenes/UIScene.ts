import Phaser from "phaser";
import type { SkillConfig } from "../managers/ConfigManager";
import { EventBus } from "../managers/EventBus";
import { UPGRADE_REWARD_CHOICES } from "../managers/RewardManager";
import type { SkillChoiceHint } from "../managers/SkillManager";
import { BossBarView } from "../ui/BossBarView";
import { HUDView, type HudPayload } from "../ui/HUDView";
import { fitNotificationText } from "../ui/NotificationModel";
import { getUILayout, type UILayout } from "../ui/UILayout";
import { UIOverlayController } from "../ui/UIOverlayController";
import { ResultsPopup, type GameOverPayload } from "../ui/ResultsPopup";
import { UI_COLORS, UI_DEPTHS, UI_FONT } from "../ui/UITheme";
import { UpgradePopup } from "../ui/UpgradePopup";
import { getCampaignStage, type StageId } from "../progression/CampaignGrowth";
import type { BossIntroFrame } from "../campaign/BossIntroModel";

interface SkillChoicePayload {
  choices: SkillConfig[];
  hints: SkillChoiceHint[];
  levels?: Record<string, number>;
  sessionId?: number;
}

interface BossPhasePayload {
  text: string;
}

interface NotificationView {
  container: Phaser.GameObjects.Container;
  frame: Phaser.GameObjects.Graphics;
  text: Phaser.GameObjects.Text;
  message: string;
}

export class UIScene extends Phaser.Scene {
  private hud?: HUDView;
  private bossBar?: BossBarView;
  private currentLayout?: UILayout;
  private readonly overlays = new UIOverlayController<UILayout>();
  private notification?: NotificationView;
  private bossIntro?: Phaser.GameObjects.Text;
  private lastOrdinaryNoticeAt = -Infinity;
  private readonly recentNotices = new Map<string, number>();
  private campaignPaused = false;
  private choosing = false;
  private atHome = false;

  constructor() {
    super("UIScene");
  }

  create(): void {
    this.currentLayout = getUILayout(this.scale.width, this.scale.height);
    this.hud = new HUDView(this, this.currentLayout);
    this.bossBar = new BossBarView(this, this.currentLayout.boss);

    EventBus.on("hud:update", this.updateHud, this);
    EventBus.on("level:choices", this.showSkillChoices, this);
    EventBus.on("upgrade:closed", this.closeUpgradeChoices, this);
    EventBus.on("game:over", this.showGameOver, this);
    EventBus.on("boss:spawned", this.flashBossWarning, this);
    EventBus.on("boss:intro", this.showBossIntro, this);
    EventBus.on("boss:defeated", this.showBossDefeated, this);
    EventBus.on("boss:phase", this.showBossPhase, this);
    EventBus.on("evolution:unlocked", this.showEvolutionUnlocked, this);
    EventBus.on("ui:clear", this.clearOverlay, this);
    EventBus.on("campaign:paused", this.setCampaignPaused, this);
    EventBus.on("campaign:ready", this.setCampaignReady, this);
    this.scale.on(Phaser.Scale.Events.RESIZE, this.handleResize, this);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.shutdown, this);
  }

  private updateHud(payload: HudPayload): void {
    this.hud?.update(payload);
    this.bossBar?.update(payload.boss);
  }

  private showSkillChoices(payload: SkillConfig[] | SkillChoicePayload): void {
    if (!this.currentLayout) {
      return;
    }
    const choices = this.ensurePopupChoiceCount(Array.isArray(payload) ? payload : payload.choices, 3);
    const hints = Array.isArray(payload) ? [] : payload.hints;
    const levels = Array.isArray(payload) ? {} : payload.levels ?? {};
    const sessionId = Array.isArray(payload) ? 0 : payload.sessionId;
    this.choosing = true; this.syncPresentationPause();
    this.overlays.replace(new UpgradePopup(this, { choices, hints, levels, sessionId }));
  }

  private showGameOver(payload: GameOverPayload): void {
    this.showBossIntro();
    if ((payload as GameOverPayload & { campaign?: boolean }).campaign) { this.overlays.clear(); return; }
    if (!this.currentLayout) {
      return;
    }
    const popup = new ResultsPopup(this, payload, () => {
      this.overlays.clear();
      EventBus.emit("run:restart");
    }, this.currentLayout);
    this.overlays.replace(popup);
  }

  private ensurePopupChoiceCount(choices: SkillConfig[], count: number): SkillConfig[] {
    const result: SkillConfig[] = [];
    for (const choice of choices) {
      if (result.some((selected) => selected.id === choice.id)) {
        continue;
      }
      result.push(choice);
      if (result.length >= count) {
        return result;
      }
    }

    const rewards = [...UPGRADE_REWARD_CHOICES];
    Phaser.Utils.Array.Shuffle(rewards);
    for (const reward of rewards) {
      if (result.some((selected) => selected.id === reward.id)) {
        continue;
      }
      result.push(reward);
      if (result.length >= count) {
        return result;
      }
    }

    return result;
  }

  private flashBossWarning(payload?: { final?: boolean; stage?: StageId; afterIntro?: boolean }): void {
    if (payload?.afterIntro) return;
    const name = payload?.final ? getCampaignStage(payload.stage).bossName : payload?.stage === "snow" ? "裂冰车长" : "巨型炸薯机";
    this.routeNotification(`${name}来袭！`, 1100, true);
  }

  private showBossIntro(frame?: BossIntroFrame): void {
    if (!frame) {
      this.bossIntro?.destroy();
      this.bossIntro = undefined;
      return;
    }
    if (!this.bossIntro) {
      this.destroyNotification();
      this.bossIntro = this.add.text(0, 0, "", {
        fontFamily: UI_FONT, fontStyle: "bold", color: UI_COLORS.cream,
        stroke: "#251910", strokeThickness: 5, align: "center",
      }).setOrigin(0.5).setDepth(UI_DEPTHS.notification).setScrollFactor(0)
        .setShadow(0, 3, "#20150d", 4, false, true);
    }
    if (this.bossIntro.text !== frame.text) {
      this.bossIntro.setText(frame.text).setColor(frame.text === "对决开始" ? UI_COLORS.gold : UI_COLORS.cream);
      this.layoutBossIntro();
    }
    const settle = Math.max(0, 1 - frame.progress * 4);
    this.bossIntro.setScale(1 + 0.16 * settle ** 2)
      .setAlpha(Math.min(1, 0.8 + frame.progress * 8, (1 - frame.progress) * 8));
  }

  private layoutBossIntro(): void {
    if (!this.bossIntro || !this.currentLayout) return;
    const { width, height, campaignToolbar } = this.currentLayout;
    const fontSize = this.bossIntro.text === "对决开始" ? 42 : 64;
    this.bossIntro.setFontSize(Math.min(fontSize, width * .16))
      .setPosition(width / 2, Math.max(height * .34, campaignToolbar.y + campaignToolbar.height / 2 + 42));
  }

  private showBossDefeated(): void {
    this.routeNotification("首领击破！", 1000);
  }

  private showBossPhase(payload: BossPhasePayload): void {
    if (!payload?.text || !/^炸锅[二三]阶段/.test(payload.text)) {
      return;
    }
    this.routeNotification(payload.text, 850);
  }

  private showEvolutionUnlocked(payload: { name: string }): void {
    this.routeNotification(`进化完成 · ${payload.name}`, 1000);
  }

  private routeNotification(message: string, duration: number, highPriority = false): void {
    if (this.bossIntro) return;
    const now = this.time.now;
    if (now - (this.recentNotices.get(message) ?? -Infinity) < 8000) return;
    if (!highPriority && now - this.lastOrdinaryNoticeAt < 8000) return;
    this.recentNotices.set(message, now);
    if (!highPriority) this.lastOrdinaryNoticeAt = now;
    this.showNotification(message, UI_COLORS.boss, duration);
  }

  private showNotification(message: string, _color: number, duration: number): void {
    if (!this.currentLayout) {
      return;
    }
    this.destroyNotification();

    const container = this.add.container(0, 0).setDepth(UI_DEPTHS.notification).setScrollFactor(0);
    const frame = this.add.graphics();
    const text = this.add.text(0, 0, message, {
      color: "#ffe8d8",
      fontFamily: UI_FONT,
      fontStyle: "900",
      fontSize: "18px",
      stroke: "#211811",
      strokeThickness: 2,
      align: "center",
    }).setOrigin(0.5).setLineSpacing(4).setShadow(0, 2, "#0e0c09", 2, false, true);
    container.add([frame, text]);
    this.notification = { container, frame, text, message };
    this.layoutNotification();

    container.setAlpha(0).setY(-6);
    this.tweens.add({
      targets: container,
      alpha: 1,
      y: 0,
      duration: 140,
      ease: "Sine.easeOut",
      hold: duration,
      yoyo: true,
      onComplete: () => this.destroyNotification(container),
    });
  }

  private layoutNotification(): void {
    if (!this.notification || !this.currentLayout) {
      return;
    }
    const layout = this.currentLayout.notification;
    const { text, frame, message } = this.notification;
    const minimumFontSize = 16;
    let measuringFont = -1;
    const measureWidth = (value: string, fontSize: number): number => {
      if (measuringFont !== fontSize) {
        text.setFontSize(fontSize);
        measuringFont = fontSize;
      }
      return text.context.measureText(value).width;
    };
    const fit = (baseFontSize: number): number => {
      const fitted = fitNotificationText(message, layout.width - 40, baseFontSize, minimumFontSize, measureWidth);
      text.setFontSize(fitted.fontSize).setText(fitted.text);
      measuringFont = fitted.fontSize;
      return fitted.fontSize;
    };
    let fontSize = fit(this.currentLayout.compact ? 18 : 20);
    while (text.height > layout.height - 20 && fontSize > minimumFontSize) fontSize = fit(fontSize - 1);
    const stripHeight = text.height + 20;
    const centerY = layout.y - layout.height / 2 + stripHeight / 2;
    text.setPosition(layout.x, centerY);

    frame.clear().setPosition(layout.x, centerY);
    const edgeWidth = Math.min(40, layout.width * 0.1);
    frame.fillStyle(0x17130f, 0.58).fillRect(-layout.width / 2 + edgeWidth, -stripHeight / 2, layout.width - edgeWidth * 2, stripHeight);
    const slices = 8;
    for (let index = 0; index < slices; index++) {
      const sliceWidth = edgeWidth / slices;
      frame.fillStyle(0x17130f, 0.58 * (index + 0.5) / slices);
      frame.fillRect(-layout.width / 2 + index * sliceWidth, -stripHeight / 2, sliceWidth, stripHeight);
      frame.fillRect(layout.width / 2 - (index + 1) * sliceWidth, -stripHeight / 2, sliceWidth, stripHeight);
    }
  }

  private destroyNotification(expectedContainer?: Phaser.GameObjects.Container): void {
    if (!this.notification || (expectedContainer && this.notification.container !== expectedContainer)) {
      return;
    }
    this.tweens.killTweensOf(this.notification.container);
    this.notification.container.destroy(true);
    this.notification = undefined;
  }

  private clearOverlay(): void {
    this.choosing = false; this.syncPresentationPause();
    this.overlays.clear();
    this.destroyNotification();
    this.showBossIntro();
    this.lastOrdinaryNoticeAt = -Infinity;
    this.recentNotices.clear();
    this.hud?.updatePendingUpgrades(0);
  }

  private closeUpgradeChoices(): void {
    this.choosing = false; this.syncPresentationPause();
    this.overlays.clear();
  }
  private setCampaignPaused(paused: boolean): void { this.campaignPaused = paused; this.syncPresentationPause(); }
  private setCampaignReady({ atHome }: { atHome: boolean }): void { this.atHome = atHome; this.campaignPaused = false; this.choosing = false; this.syncPresentationPause(); }
  private syncPresentationPause(): void {
    const stopped = this.atHome || this.campaignPaused || this.choosing;
    this.bossBar?.setSuppressed(this.choosing);
    if (this.tweens) {
      if (this.tweens.paused && !stopped) this.tweens.getDelta?.(false);
      this.tweens.paused = stopped;
    }
    if (this.time) this.time.paused = stopped;
  }

  private handleResize(): void {
    this.currentLayout = getUILayout(this.scale.width, this.scale.height);
    this.hud?.layout(this.currentLayout);
    this.bossBar?.layout(this.currentLayout.boss);
    this.overlays.layout(this.currentLayout);
    this.layoutNotification();
    this.layoutBossIntro();
  }

  private shutdown(): void {
    EventBus.off("hud:update", this.updateHud, this);
    EventBus.off("level:choices", this.showSkillChoices, this);
    EventBus.off("upgrade:closed", this.closeUpgradeChoices, this);
    EventBus.off("game:over", this.showGameOver, this);
    EventBus.off("boss:spawned", this.flashBossWarning, this);
    EventBus.off("boss:intro", this.showBossIntro, this);
    EventBus.off("boss:defeated", this.showBossDefeated, this);
    EventBus.off("boss:phase", this.showBossPhase, this);
    EventBus.off("evolution:unlocked", this.showEvolutionUnlocked, this);
    EventBus.off("ui:clear", this.clearOverlay, this);
    EventBus.off("campaign:paused", this.setCampaignPaused, this);
    EventBus.off("campaign:ready", this.setCampaignReady, this);
    this.scale.off(Phaser.Scale.Events.RESIZE, this.handleResize, this);
    this.overlays.clear();
    this.destroyNotification();
    this.showBossIntro();
    this.hud?.destroy();
    this.bossBar?.destroy();
    this.hud = undefined;
    this.bossBar = undefined;
    this.currentLayout = undefined;
  }
}
