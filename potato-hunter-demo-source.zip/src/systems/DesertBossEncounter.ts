import type { FinalBossPhase } from "../components/ComponentTypes";
import type { World } from "../entities/World";
import { EventBus } from "../managers/EventBus";
import { confineDuelActor, getBossDuel } from "./BossDuelArena";
import { canReceiveHostileDamage, getHostileHitGraceMs } from "./PlayerDamageModel";
import type { GameRuntime } from "./SystemTypes";

export type DesertPattern = "dune_wave" | "sand_cyclone" | "sandfall" | "sand_siege" | "sand_burrow" | "sand_cleave";
type Point = { x: number; y: number };
type Arena = Point & { radius: number };
type Shelter = Point & { radius: number };

export const DESERT_ROTATIONS: Record<FinalBossPhase, readonly DesertPattern[]> = {
  1: ["dune_wave"],
  2: ["sand_cyclone", "sandfall", "dune_wave"],
  3: ["sand_siege", "sand_burrow", "dune_wave", "sandfall", "sand_cyclone"],
};

export const DESERT_CAST_LABELS: Record<DesertPattern, string> = {
  dune_wave: "断岸沙浪 · 穿过沙浪缺口",
  sand_cyclone: "游沙龙卷 · 离开风轨",
  sandfall: "砂瀑塌陷 · 横移离开沙脊",
  sand_siege: "沙暴围城 · 进入背风区",
  sand_burrow: "地脉伏击 · 远离破土点",
  sand_cleave: "沙刃挥砍",
};

export const DESERT_CLEAVE_REACH = 166;
export const DESERT_BURROW_SINK_MS = 290;

const clamp = (value: number, min: number, max: number): number => Math.min(max, Math.max(min, value));
const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
const distance = (a: Point, b: Point): number => Math.hypot(a.x - b.x, a.y - b.y);

type Wave = { kind: "dune_wave"; gapX: number; gapHalf: number; direction: 1 | -1; halfDepth: number };
type Cyclone = { kind: "sand_cyclone"; from: Point; bend: Point; to: Point; radius: number };
type Fall = { kind: "sandfall"; center: Point; angle: number; halfLength: number; halfWidth: number };
type Siege = { kind: "sand_siege"; shelters: readonly [Shelter, Shelter]; direction: 1 | -1 };
type Cleave = { kind: "sand_cleave"; origin: Point; angle: number; halfAngle: number; radius: number };
type Burrow = { kind: "sand_burrow"; origin: Point; center: Point; radius: number };
export type DesertStrikeShape = Cleave | Burrow;

export interface DesertCast {
  readonly bossId: number;
  readonly arena: Arena;
  readonly shape: Wave | Cyclone | Fall | Siege | DesertStrikeShape;
  readonly tellMs: number;
  readonly activeMs: number;
  readonly recoveryMs: number;
  readonly damageRatio: number;
  readonly readable: boolean;
  elapsedMs: number;
  hit: boolean;
}

const activeCasts = new WeakMap<World, DesertCast>();

export function getDesertCast(world: World): DesertCast | undefined {
  const cast = activeCasts.get(world);
  return cast && getBossDuel(world)?.bossId === cast.bossId ? cast : undefined;
}

export function clearDesertCast(world: World): void { activeCasts.delete(world); }

function inside(point: Point, arena: Arena, inset: number): Point {
  const length = distance(point, arena);
  const limit = arena.radius - inset;
  if (length <= limit) return { x: point.x, y: point.y };
  return { x: arena.x + (point.x - arena.x) * limit / length, y: arena.y + (point.y - arena.y) * limit / length };
}

export function startDesertCast(world: World, bossId: number, arena: Arena, kind: DesertPattern, phase: FinalBossPhase, hero: Point, boss: Point, turn: number, readable = true): DesertCast {
  const { x, y, radius } = arena;
  const side = hero.x >= x ? 1 : -1;
  const direction = hero.y >= y ? 1 : -1;
  const tempo = phase - 1;
  let shape: DesertCast["shape"], tellMs: number, activeMs: number, recoveryMs: number, damageRatio: number;
  switch (kind) {
    case "dune_wave":
      shape = { kind, direction, gapX: x + clamp(hero.x - x - side * (104 + (turn % 2) * 32), -.46 * radius, .46 * radius), gapHalf: 73 - 5 * tempo, halfDepth: 31 };
      tellMs = 1000 - tempo * 85; activeMs = 1430 - tempo * 110; recoveryMs = 670 - tempo * 80; damageRatio = .50 + tempo * .035;
      break;
    case "sand_cyclone":
      shape = { kind, from: inside(boss, arena, 85), bend: { x: x + side * radius * 1.08, y: y - direction * radius * .14 }, to: { x: x + side * radius * .23, y: y + direction * radius * .70 }, radius: 58 + 5 * tempo };
      tellMs = 910 - tempo * 65; activeMs = 1750 - tempo * 140; recoveryMs = 620 - tempo * 70; damageRatio = .46 + tempo * .04;
      break;
    case "sandfall":
      shape = { kind, center: inside(hero, arena, 136), angle: hero.x >= x ? -.72 : .72, halfLength: 157, halfWidth: 44 + 4 * tempo };
      tellMs = 980 - tempo * 75; activeMs = 1260; recoveryMs = 530 - tempo * 55; damageRatio = .52 + tempo * .025;
      break;
    case "sand_siege": {
      const lane = y + clamp((hero.y - y) * .45, -radius * .34, radius * .34);
      const shelter = (sign: number): Shelter => ({ x: x + sign * radius * .39, y: lane + sign * 22, radius: 104 });
      shape = { kind, shelters: [shelter(-1), shelter(1)], direction };
      tellMs = 2050; activeMs = 630; recoveryMs = 1480; damageRatio = .66;
      break;
    }
    case "sand_cleave":
      shape = { kind, origin: { x: boss.x, y: boss.y }, angle: Math.atan2(hero.y - boss.y, hero.x - boss.x), halfAngle: 1.04, radius: DESERT_CLEAVE_REACH };
      tellMs = 490 - 45 * tempo; activeMs = 230; recoveryMs = 280; damageRatio = .22 + .045 * tempo;
      break;
    case "sand_burrow":
      shape = { kind, origin: { x: boss.x, y: boss.y }, center: inside(hero, arena, 75), radius: 139 };
      tellMs = 1210; activeMs = 430; recoveryMs = 1040; damageRatio = .72;
      break;
  }
  const cast: DesertCast = { bossId, arena: { x, y, radius }, shape, tellMs, activeMs, recoveryMs, damageRatio, readable, elapsedMs: 0, hit: false };
  activeCasts.set(world, cast);
  return cast;
}

export function getWaveY(cast: DesertCast & { shape: Wave }, progress: number): number {
  const reach = cast.arena.radius + cast.shape.halfDepth;
  return cast.arena.y + cast.shape.direction * lerp(-reach, reach, clamp(progress, 0, 1));
}

export function getCyclonePoint(shape: Cyclone, progress: number): Point {
  const t = clamp(progress, 0, 1);
  return {
    x: lerp(lerp(shape.from.x, shape.bend.x, t), lerp(shape.bend.x, shape.to.x, t), t),
    y: lerp(lerp(shape.from.y, shape.bend.y, t), lerp(shape.bend.y, shape.to.y, t), t),
  };
}

export function isInsideSandfall(shape: Fall, point: Point): boolean {
  const dx = point.x - shape.center.x, dy = point.y - shape.center.y;
  const c = Math.cos(shape.angle), s = Math.sin(shape.angle);
  return Math.hypot(Math.max(0, Math.abs(dx * c + dy * s) - shape.halfLength), -dx * s + dy * c) <= shape.halfWidth;
}

export function isInsideDesertStrike(shape: DesertStrikeShape, point: Point, padding = 0): boolean {
  if (shape.kind === "sand_burrow") return distance(shape.center, point) <= shape.radius + padding;
  const dx = point.x - shape.origin.x, dy = point.y - shape.origin.y;
  const range = Math.hypot(dx, dy);
  return range <= shape.radius + padding && (range < 1 || (dx * Math.cos(shape.angle) + dy * Math.sin(shape.angle)) / range >= Math.cos(shape.halfAngle) - padding / Math.max(range, 1));
}

/** Test hero and hazard on the same timeline. Sandfall and siege strike once, on release. */
function findContact(cast: DesertCast, fromMs: number, toMs: number, heroAt: (at: number) => Point, vulnerableAt: (at: number) => boolean): Point | undefined {
  const { shape } = cast;
  const first = Math.max(fromMs, cast.tellMs), last = Math.min(toMs, cast.tellMs + cast.activeMs);
  if (first > last) return;
  if (shape.kind === "sandfall" || shape.kind === "sand_siege" || shape.kind === "sand_cleave" || shape.kind === "sand_burrow") {
    if (fromMs >= cast.tellMs || !vulnerableAt(cast.tellMs)) return;
    const point = heroAt(cast.tellMs);
    if (distance(point, cast.arena) > cast.arena.radius) return;
    const hit = shape.kind === "sandfall" ? isInsideSandfall(shape, point)
      : shape.kind === "sand_siege" ? shape.shelters.every(shelter => distance(point, shelter) > shelter.radius)
      : isInsideDesertStrike(shape, point);
    return hit ? point : undefined;
  }
  // Runtime slices are at most 40 ms; this resolves a moving edge and hero at <= 4 ms intervals.
  const steps = Math.max(1, Math.ceil((last - first) / 4));
  for (let n = 0; n <= steps; n++) {
    const at = lerp(first, last, n / steps);
    if (!vulnerableAt(at)) continue;
    const point = heroAt(at);
    if (distance(point, cast.arena) > cast.arena.radius) continue;
    const progress = (at - cast.tellMs) / cast.activeMs;
    if (shape.kind === "dune_wave"
      ? Math.abs(point.x - shape.gapX) > shape.gapHalf && Math.abs(point.y - getWaveY({ ...cast, shape }, progress)) <= shape.halfDepth
      : distance(point, getCyclonePoint(shape, progress)) <= shape.radius) return point;
  }
}

/** Returns true after the last active frame. Each cast can damage this player at most once. */
export function advanceDesertCast(cast: DesertCast, deltaMs: number, runtime: GameRuntime): boolean {
  const { world, playerId } = runtime;
  const previous = cast.elapsedMs;
  cast.elapsedMs += Math.max(0, deltaMs);
  const point = world.components.transforms.get(playerId);
  const player = world.components.players.get(playerId);
  const hp = world.components.health.get(playerId);
  if (cast.readable && !cast.hit && point && player && hp && hp.current > 0 && cast.elapsedMs >= cast.tellMs) {
    const velocity = world.components.velocities.get(playerId);
    const duel = getBossDuel(world);
    // Boss AI runs before MovementSystem. Sample the movement already resolved by InputSystem.
    const heroAt = (at: number): Point => {
      const seconds = (at - previous) / 1000;
      const projected = { ...point, x: point.x + (velocity?.x ?? 0) * seconds, y: point.y + (velocity?.y ?? 0) * seconds };
      confineDuelActor(duel, playerId, playerId, projected);
      return projected;
    };
    const prior = runtime.hostileProtectionAtStepStart;
    const protectionUntil = (before: number, now: number): number => now <= Math.max(0, before - deltaMs) ? before : now > 0 ? deltaMs + now : 0;
    const dashUntil = prior ? protectionUntil(prior.dashRemainingMs, player.dashRemainingMs) : 0;
    const graceUntil = prior ? protectionUntil(prior.damageCooldownMs, player.damageCooldownMs) : 0;
    const hit = findContact(cast, previous, cast.elapsedMs, heroAt, at => prior
      ? canReceiveHostileDamage({ dashRemainingMs: dashUntil - (at - previous), damageCooldownMs: graceUntil - (at - previous) })
      : canReceiveHostileDamage(player));
    if (hit) {
      const damage = Math.ceil(hp.max * cast.damageRatio - 1e-6);
      cast.hit = true;
      hp.current -= damage;
      player.damageCooldownMs = getHostileHitGraceMs("aoe");
      EventBus.emit("combat:damage", { x: hit.x, y: hit.y, targetId: playerId, value: damage, color: "#ffb45c", isCrit: true, category: "incoming" });
    }
  }
  return cast.elapsedMs >= cast.tellMs + cast.activeMs;
}

export function getDesertMovementScale(world: World, point: Point, dashing: boolean): number {
  if (dashing) return 1;
  const cast = getDesertCast(world);
  if (!cast?.readable || cast.shape.kind !== "sandfall" || cast.elapsedMs < cast.tellMs + 200 || !isInsideSandfall(cast.shape, point)) return 1;
  return .68;
}
