export interface DamageNumberInput {
    x: number;
    y: number;
    value: number;
    color: string;
    isCrit?: boolean;
    targetId?: number;
    isDot?: boolean;
    category?: 'outgoing' | 'incoming' | 'shield';
}
export const MAX_DAMAGE_NUMBERS = 48;
export function getDamageNumberPresentation(payload: DamageNumberInput) {
    const critical = payload.isCrit === true;
    const red = payload.category === 'incoming' || (payload.category === undefined && ['#ff4800', '#ff6b6b', '#ff3030', '#ff595e', '#ff4d6d', '#9f86c0', '#ef476f'].includes(payload.color.toLowerCase()));
    const shield = payload.category === 'shield' || ['#89cfff', '#c77dff'].includes(payload.color.toLowerCase());
    const color = red ? '#ff9292' : shield ? '#c7f7ff' : critical ? '#fff17b' : payload.isDot ? (payload.color === '#ff6b35' ? '#ffd2a3' : '#d8ffb1') : '#fffdf1';
    return { color, fontSize: critical ? 28 : payload.isDot ? 19 : 22, stroke: '#16241d', strokeThickness: 4, holdMs: critical ? 280 : 250, durationMs: critical ? 820 : 700, initialScale: critical ? 1.42 : 1.23 };
}
export function formatDamageValue(value: number): string | undefined {
    if (!Number.isFinite(value) || value <= 0)
        return undefined;
    return String(Math.round(value * 10) / 10 || .1);
}
export function getDamageNumberFrame(ageMs: number, critical: boolean) {
    const spec = getDamageNumberPresentation({ x: 0, y: 0, value: 1, color: '#fff', isCrit: critical });
    const age = Math.max(0, ageMs), attack = Math.min(1, age / 100), fade = Math.max(0, Math.min(1, (age - spec.holdMs) / (spec.durationMs - spec.holdMs)));
    return { scale: 1 + (spec.initialScale - 1) * (1 - attack) ** 2, alpha: 1 - fade ** 1.4, lift: 34 * (1 - (1 - Math.min(1, age / spec.durationMs)) ** 1.6), expired: age >= spec.durationMs };
}
export function getDamageNumberLane(ordinal: number) {
    const lane = ordinal % 3;
    return { x: [-10, 12, 0][lane], y: [-29, -89, -149][lane] };
}
