import type { EntityId } from "../components/ComponentTypes";
import { EntityPools } from "../managers/EntityPools";
import type { GameRuntime, System } from "./SystemTypes";

export class LifetimeSystem implements System {
  update(deltaMs: number, runtime: GameRuntime): void {
    const expired: EntityId[] = [];

    for (const [entityId, lifetime] of runtime.world.components.lifetimes) {
      lifetime.remainingMs -= deltaMs;
      const render = runtime.world.components.renders.get(entityId);
      if (render) {
        render.alpha = Math.max(0, lifetime.remainingMs / lifetime.totalMs);
      }
      if (lifetime.remainingMs <= 0) {
        expired.push(entityId);
      }
    }

    for (const entityId of expired) {
      if (runtime.world.components.projectiles.has(entityId)) {
        EntityPools.releaseProjectile(runtime.world, entityId);
      } else {
        runtime.world.destroyEntity(entityId);
      }
    }
  }
}
