export type BossPattern = "oil_fan" | "bombardment" | "charge" | "summon" | "heat_ring";

export function getBossPhase(hpRatio: number): number {
  return hpRatio <= 0.2 ? 3 : hpRatio <= 0.5 ? 2 : 1;
}

export function getBossPatterns(phase: number): BossPattern[] {
  const patterns: BossPattern[] = ["oil_fan", "bombardment"];
  if (phase >= 2) patterns.push("charge", "summon");
  if (phase >= 3) patterns.push("heat_ring");
  return patterns;
}

export function getBossWindupMs(pattern: BossPattern): number {
  return pattern === "charge" ? 950 : pattern === "heat_ring" ? 1200 : pattern === "bombardment" ? 1000 : 750;
}

export const BOSS_FIRST_CAST_MS = 1500;
export const BOSS_RECOVERY_MS = 800;
export const BOSS_CHARGE_SPEED = 420;
export const BOSS_CHARGE_MS = 650;
