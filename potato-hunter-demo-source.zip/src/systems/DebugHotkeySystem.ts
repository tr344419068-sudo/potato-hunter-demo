import Phaser from "phaser";
import type { EntityId } from "../components/ComponentTypes";
import type { GameRuntime, System } from "./SystemTypes";
import { getNextExperienceRequirement } from "../managers/PacingModel";

export class DebugHotkeySystem implements System {
  private readonly bossKey: Phaser.Input.Keyboard.Key;
  private readonly levelKey: Phaser.Input.Keyboard.Key;
  private readonly timeKey: Phaser.Input.Keyboard.Key;
  private readonly clearKey: Phaser.Input.Keyboard.Key;

  constructor(scene: Phaser.Scene, private readonly playerId: EntityId) {
    if (!scene.input.keyboard) {
      throw new Error("Keyboard input is not available.");
    }

    this.bossKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.B);
    this.levelKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.L);
    this.timeKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.T);
    this.clearKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.K);
  }

  update(_deltaMs: number, runtime: GameRuntime): void {
    if (Phaser.Input.Keyboard.JustDown(this.bossKey)) {
      runtime.spawnBossNow();
    }

    if (Phaser.Input.Keyboard.JustDown(this.levelKey)) {
      const player = runtime.world.components.players.get(this.playerId);
      if (!player) {
        return;
      }

      player.level += 1;
      player.experience = 0;
      player.experienceToNext = getNextExperienceRequirement(player.experienceToNext, player.level);
      const choices = runtime.skillManager.getChoices(3);
      runtime.requestSkillChoice(choices, runtime.skillManager.getChoiceHints(choices));
    }

    if (Phaser.Input.Keyboard.JustDown(this.timeKey)) {
      runtime.addDebugTime(60_000);
    }

    if (Phaser.Input.Keyboard.JustDown(this.clearKey)) {
      runtime.clearMonsters();
    }
  }
}
