import { EntityPools } from "../managers/EntityPools";
import { EventBus } from "../managers/EventBus";
import { distanceSquared, normalize } from "../utils/math";
import type { EntityId, SkillEffect } from "../components/ComponentTypes";
import { triggerElementalReaction } from "./ElementalReactionSystem";
import type { GameRuntime, System } from "./SystemTypes";
import { confirmTempoHit } from "./AttackTempoModel";

export class ProjectileCollisionSystem implements System {
  update(_deltaMs: number, runtime: GameRuntime): void {
    const projectilesToDestroy: EntityId[] = [];

    for (const [projectileId, projectile] of runtime.world.components.projectiles) {
      const projectileTransform = runtime.world.components.transforms.get(projectileId);
      if (!projectileTransform) {
        continue;
      }

      for (const monsterId of runtime.world.components.monsters.keys()) {
        if (projectile.hitEntities.has(monsterId)) {
          continue;
        }

        const monsterTransform = runtime.world.components.transforms.get(monsterId);
        const monsterHealth = runtime.world.components.health.get(monsterId);
        if (!monsterTransform || !monsterHealth || monsterHealth.current <= 0) {
          continue;
        }

        const hitRadius = projectileTransform.radius + monsterTransform.radius;
        if (distanceSquared(projectileTransform.x, projectileTransform.y, monsterTransform.x, monsterTransform.y) > hitRadius * hitRadius) {
          continue;
        }

        const isCrit = (runtime.random ?? Math.random)() < projectile.critChance;
        const damage = Math.ceil(projectile.damage * (isCrit ? projectile.critMultiplier : 1));
        const vfxKind = projectile.vfxKind ?? "kinetic";
        this.applyDamage(runtime, monsterId, damage, isCrit ? "#ffca3a" : "#f4f1de", isCrit);
        const player = runtime.world.components.players.get(runtime.playerId);
        if (player) confirmTempoHit(player, runtime.skillManager.getLevel("combo_gear"));
        triggerElementalReaction(runtime, monsterId, vfxKind, damage);
        projectile.hitEntities.add(monsterId);
        this.applyProjectileEffects(runtime, projectile.effects, monsterId, projectileTransform.x, projectileTransform.y, damage);
        const projectileRender = runtime.world.components.renders.get(projectileId);
        const projectileVelocity = runtime.world.components.velocities.get(projectileId);
        EventBus.emit("weapon:impact", {
          x: monsterTransform.x,
          y: monsterTransform.y,
          color: projectileRender?.color ?? 0xffffff,
          radius: Math.max(18, projectileTransform.radius + monsterTransform.radius),
          vfxKind,
          directionX: projectileVelocity?.x ?? 1,
          directionY: projectileVelocity?.y ?? 0,
          critical: isCrit,
        });

        if (projectile.hitEntities.size > projectile.pierce) {
          projectilesToDestroy.push(projectileId);
          break;
        }
      }
    }

    for (const entityId of projectilesToDestroy) {
      EntityPools.releaseProjectile(runtime.world, entityId);
    }
  }

  private applyProjectileEffects(
    runtime: GameRuntime,
    effects: SkillEffect[],
    targetId: EntityId,
    hitX: number,
    hitY: number,
    sourceDamage: number,
  ): void {
    const targetTransform = runtime.world.components.transforms.get(targetId);
    if (!targetTransform) {
      return;
    }

    for (const effect of effects) {
      if (effect.type === "burn" || effect.type === "freeze" || effect.type === "slow" || effect.type === "poison") {
        const currentStatuses = (runtime.world.components.statuses.get(targetId) ?? []).filter((status) => status.type !== effect.type);
        runtime.world.components.statuses.set(targetId, [
          ...currentStatuses,
          {
            type: effect.type,
            remainingMs: effect.durationMs,
            totalMs: effect.durationMs,
            damagePerSecond: "damagePerSecond" in effect ? effect.damagePerSecond : 0,
            slowMultiplier: "slowMultiplier" in effect ? effect.slowMultiplier : 1,
          },
        ]);
        EventBus.emit("combat:vfx", {
          kind: effect.type,
          x: targetTransform.x,
          y: targetTransform.y,
          color: effect.type === "burn" ? 0xff8c2a : effect.type === "poison" ? 0x80b918 : 0x9ad7ff,
          radius: effect.type === "freeze" ? 34 : 24,
        });
      }

      if (effect.type === "knockback") {
        const direction = normalize(targetTransform.x - hitX, targetTransform.y - hitY);
        runtime.world.components.knockbacks.set(targetId, {
          x: direction.x * effect.force,
          y: direction.y * effect.force,
          remainingMs: 150,
        });
      }

      if (effect.type === "explosion") {
        this.explode(runtime, targetTransform.x, targetTransform.y, effect.radius, sourceDamage * effect.damageMultiplier);
      }

      if (effect.type === "chain") {
        this.chain(runtime, targetId, effect.jumps, effect.radius, sourceDamage * effect.damageMultiplier);
      }
    }

    runtime.world.components.hitFlashes.set(targetId, { remainingMs: 90, totalMs: 90 });
    EventBus.emit("fx:sparks", { x: targetTransform.x, y: targetTransform.y, color: 0xf4f1de, count: 3, size: 6 });
  }

  private applyDamage(runtime: GameRuntime, targetId: EntityId, damage: number, color: string, isCrit = false): void {
    const health = runtime.world.components.health.get(targetId);
    const transform = runtime.world.components.transforms.get(targetId);
    if (!health || !transform || health.current <= 0) {
      return;
    }

    const monster = runtime.world.components.monsters.get(targetId);
    let healthDamage = damage;
    if (monster?.shieldHp && monster.shieldHp > 0) {
      const absorbed = Math.min(monster.shieldHp, damage);
      monster.shieldHp -= absorbed;
      const remainingDamage = damage - absorbed;
      healthDamage = remainingDamage;
      EventBus.emit("combat:damage", {
        x: transform.x,
        y: transform.y,
        value: absorbed,
        targetId,
        category: "shield",
        color: monster.behavior === "guard" ? "#89cfff" : "#c77dff",
      });
      runtime.world.components.hitFlashes.set(targetId, { remainingMs: 110, totalMs: 110 });
      if (remainingDamage <= 0) {
        return;
      }
      health.current -= remainingDamage;
    } else {
      health.current -= damage;
    }

    runtime.world.components.hitFlashes.set(targetId, { remainingMs: isCrit ? 140 : 90, totalMs: isCrit ? 140 : 90 });
    EventBus.emit("combat:damage", {
      x: transform.x,
      y: transform.y,
      value: healthDamage,
      targetId,
      category: "outgoing",
      color,
      isCrit,
    });
  }

  private explode(runtime: GameRuntime, x: number, y: number, radius: number, damage: number): void {
    const radiusSquared = radius * radius;
    const isNuke = radius >= 220;
    EventBus.emit("combat:vfx", { kind: "explosion", x, y, color: 0xffca3a, radius });

    EventBus.emit("fx:sparks", { x, y, color: 0xffca3a, count: isNuke ? 42 : 16, size: isNuke ? 12 : 9 });

    for (const entityId of runtime.world.components.monsters.keys()) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform || distanceSquared(x, y, transform.x, transform.y) > radiusSquared) {
        continue;
      }

      this.applyDamage(runtime, entityId, Math.ceil(damage), "#ffca3a");
      const direction = normalize(transform.x - x, transform.y - y);
      runtime.world.components.knockbacks.set(entityId, {
        x: direction.x * (isNuke ? 540 : 360),
        y: direction.y * (isNuke ? 540 : 360),
        remainingMs: isNuke ? 230 : 170,
      });
    }
  }

  private chain(runtime: GameRuntime, firstTargetId: EntityId, jumps: number, radius: number, damage: number): void {
    let currentTargetId = firstTargetId;
    const hit = new Set<EntityId>([firstTargetId]);

    for (let jump = 0; jump < jumps; jump += 1) {
      const currentTransform = runtime.world.components.transforms.get(currentTargetId);
      if (!currentTransform) {
        return;
      }

      let nextTargetId: EntityId | undefined;
      let nextDistance = Number.POSITIVE_INFINITY;
      const radiusSquared = radius * radius;

      for (const candidateId of runtime.world.components.monsters.keys()) {
        if (hit.has(candidateId)) {
          continue;
        }

        const candidateTransform = runtime.world.components.transforms.get(candidateId);
        if (!candidateTransform) {
          continue;
        }

        const distance = distanceSquared(currentTransform.x, currentTransform.y, candidateTransform.x, candidateTransform.y);
        if (distance <= radiusSquared && distance < nextDistance) {
          nextTargetId = candidateId;
          nextDistance = distance;
        }
      }

      if (!nextTargetId) {
        return;
      }

      hit.add(nextTargetId);
      currentTargetId = nextTargetId;
      this.applyDamage(runtime, nextTargetId, Math.ceil(damage), "#fff3b0");
      const targetTransform = runtime.world.components.transforms.get(nextTargetId);
      if (targetTransform) {
        EventBus.emit("combat:vfx", { kind: "chain", x: currentTransform.x, y: currentTransform.y, x2: targetTransform.x, y2: targetTransform.y, color: 0xfff3b0 });
        EventBus.emit("fx:sparks", { x: targetTransform.x, y: targetTransform.y, color: 0xfff3b0, count: 2, size: 8 });
      }
    }
  }
}
