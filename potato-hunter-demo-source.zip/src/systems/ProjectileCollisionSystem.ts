import { EntityPools } from "../managers/EntityPools";
import { EventBus } from "../managers/EventBus";
import { distanceSquared, normalize, sweepTime } from "../utils/math";
import type { EntityId, SkillEffect } from "../components/ComponentTypes";
import { triggerElementalReaction } from "./ElementalReactionSystem";
import type { GameRuntime, System } from "./SystemTypes";
import { confirmTempoHit } from "./AttackTempoModel";
import { getWeaponContact, isLongSkewer, isPepperWeapon } from "./WeaponPresentationModel";
import { absorbMonsterShield } from "./MonsterShield";
import { getMovementSweepOrigins } from "./MovementSystem";
import { applyHealthDamage } from "./HealthDamage";
import { getAttackableMonsterIds } from "./BossDuelArena";
import { CRESCENT_SKILL_ID, sweepCrescent } from "./CrescentModel";

export class ProjectileCollisionSystem implements System {
  update(_deltaMs: number, runtime: GameRuntime): void {
    const projectilesToDestroy: EntityId[] = [];

    for (const [projectileId, projectile] of runtime.world.components.projectiles) {
      const projectileTransform = runtime.world.components.transforms.get(projectileId);
      if (!projectileTransform) {
        continue;
      }
      if (projectile.returnFlight && projectile.hitEntities.size > projectile.pierce) continue;

      const from = projectile.sweepOrigin;
      projectile.sweepOrigin = undefined;
      const targetOrigins = from ? getMovementSweepOrigins(runtime.world) : undefined;
      const monsters = getAttackableMonsterIds(runtime.world);
      const render = runtime.world.components.renders.get(projectileId);
      const velocity = runtime.world.components.velocities.get(projectileId);
      const crescent = projectile.skillId === CRESCENT_SKILL_ID && render && velocity ? { width: render.size, velocity } : undefined;
      const candidates = from ? [...monsters].flatMap(id => {
        const t = runtime.world.components.transforms.get(id);
        if (!t || projectile.hitEntities.has(id) || (runtime.world.components.health.get(id)?.current ?? 0) <= 0) return [];
        const start = targetOrigins?.get(id) ?? t;
        const travel = { x: (t.x - start.x) * from.stepFraction, y: (t.y - start.y) * from.stepFraction };
        const to = { x: projectileTransform.x - travel.x, y: projectileTransform.y - travel.y };
        const time = crescent ? sweepCrescent(from, to, start, crescent.velocity, crescent.width, t.radius)
          : sweepTime(from, to, start, projectileTransform.radius + t.radius);
        return time === undefined ? [] : [{ id, time }];
      }).sort((a, b) => a.time - b.time) : monsters;
      for (const candidate of candidates) {
        const monsterId = typeof candidate === "number" ? candidate : candidate.id;
        if (projectile.hitEntities.has(monsterId)) {
          continue;
        }

        const monsterTransform = runtime.world.components.transforms.get(monsterId);
        const monsterHealth = runtime.world.components.health.get(monsterId);
        if (!monsterTransform || !monsterHealth || monsterHealth.current <= 0) {
          continue;
        }

        const hitRadius = projectileTransform.radius + monsterTransform.radius;
        if (!from && (crescent || distanceSquared(projectileTransform.x, projectileTransform.y, monsterTransform.x, monsterTransform.y) > hitRadius * hitRadius)) {
          continue;
        }

        const isCrit = (runtime.random ?? Math.random)() < projectile.critChance;
        const damage = Math.ceil(projectile.damage * (isCrit ? projectile.critMultiplier : 1));
        const vfxKind = projectile.vfxKind ?? "kinetic";
        const monster = runtime.world.components.monsters.get(monsterId);
        const beforeHp = monsterHealth.current;
        let shielded = (monster?.shieldHp ?? 0) > 0;
        this.applyDamage(runtime, monsterId, damage, isCrit ? "#ffca3a" : "#f4f1de", isCrit);
        shielded ||= Boolean(monster?.finalBossEncounter && monsterHealth.current === beforeHp);
        const player = runtime.world.components.players.get(runtime.playerId);
        if (player) confirmTempoHit(player, runtime.skillManager.getLevel("combo_gear"));
        triggerElementalReaction(runtime, monsterId, vfxKind, damage);
        projectile.hitEntities.add(monsterId);
        const time = typeof candidate === "number" ? 1 : candidate.time;
        const contactShot = from ? {
          x: from.x + (projectileTransform.x - from.x) * time,
          y: from.y + (projectileTransform.y - from.y) * time,
        } : projectileTransform;
        const beginTarget = targetOrigins?.get(monsterId);
        const contactTarget = from && beginTarget ? {
          x: beginTarget.x + (monsterTransform.x - beginTarget.x) * time * from.stepFraction,
          y: beginTarget.y + (monsterTransform.y - beginTarget.y) * time * from.stepFraction,
          radius: monsterTransform.radius,
        } : monsterTransform;
        this.applyProjectileEffects(runtime, projectile.effects, monsterId, contactShot.x, contactShot.y, damage);
        const pilotWeapon = crescent || isPepperWeapon(projectile.skillId) || isLongSkewer(projectile.skillId) || projectile.skillId === "peeler_blade" || Boolean(projectile.returnFlight);
        const contact = pilotWeapon ? getWeaponContact(contactTarget, contactShot, velocity ?? { x: 1, y: 0 }) : monsterTransform;
        EventBus.emit("weapon:impact", {
          x: contact.x,
          y: contact.y,
          skillId: projectile.skillId,
          material: shielded ? "shield" : "body",
          color: render?.color ?? 0xffffff,
          radius: Math.max(18, projectileTransform.radius + monsterTransform.radius),
          vfxKind,
          directionX: velocity?.x ?? 1,
          directionY: velocity?.y ?? 0,
          critical: isCrit,
        });

        if (projectile.hitEntities.size > projectile.pierce) {
          if (!projectile.returnFlight) projectilesToDestroy.push(projectileId);
          break;
        }
      }
    }

    for (const entityId of projectilesToDestroy) {
      EntityPools.releaseProjectile(runtime.world, entityId);
    }
  }

  private applyProjectileEffects(
    runtime: GameRuntime,
    effects: SkillEffect[],
    targetId: EntityId,
    hitX: number,
    hitY: number,
    sourceDamage: number,
  ): void {
    const targetTransform = runtime.world.components.transforms.get(targetId);
    if (!targetTransform) {
      return;
    }

    for (const effect of effects) {
      if (effect.type === "burn" || effect.type === "freeze" || effect.type === "slow" || effect.type === "poison") {
        const currentStatuses = (runtime.world.components.statuses.get(targetId) ?? []).filter((status) => status.type !== effect.type);
        runtime.world.components.statuses.set(targetId, [
          ...currentStatuses,
          {
            type: effect.type,
            remainingMs: effect.durationMs,
            totalMs: effect.durationMs,
            damagePerSecond: "damagePerSecond" in effect ? effect.damagePerSecond : 0,
            slowMultiplier: "slowMultiplier" in effect ? effect.slowMultiplier : 1,
          },
        ]);
        EventBus.emit("combat:vfx", {
          kind: effect.type,
          x: targetTransform.x,
          y: targetTransform.y,
          color: effect.type === "burn" ? 0xff8c2a : effect.type === "poison" ? 0x80b918 : 0x9ad7ff,
          radius: effect.type === "freeze" ? 34 : 24,
        });
      }

      if (effect.type === "knockback") {
        const direction = normalize(targetTransform.x - hitX, targetTransform.y - hitY);
        runtime.world.components.knockbacks.set(targetId, {
          x: direction.x * effect.force,
          y: direction.y * effect.force,
          remainingMs: 150,
        });
      }

      if (effect.type === "explosion") {
        this.explode(runtime, targetTransform.x, targetTransform.y, effect.radius, sourceDamage * effect.damageMultiplier);
      }

      if (effect.type === "chain") {
        this.chain(runtime, targetId, effect.jumps, effect.radius, sourceDamage * effect.damageMultiplier);
      }
    }

    runtime.world.components.hitFlashes.set(targetId, { remainingMs: 90, totalMs: 90 });
    EventBus.emit("fx:sparks", { x: targetTransform.x, y: targetTransform.y, color: 0xf4f1de, count: 3, size: 6 });
  }

  private applyDamage(runtime: GameRuntime, targetId: EntityId, damage: number, color: string, isCrit = false): void {
    const health = runtime.world.components.health.get(targetId);
    const transform = runtime.world.components.transforms.get(targetId);
    if (!health || !transform || health.current <= 0) {
      return;
    }

    const monster = runtime.world.components.monsters.get(targetId);
    let healthDamage = damage;
    if (monster?.shieldHp && monster.shieldHp > 0) {
      const absorbed = absorbMonsterShield(monster, transform, damage);
      const remainingDamage = damage - absorbed;
      healthDamage = remainingDamage;
      EventBus.emit("combat:damage", {
        x: transform.x,
        y: transform.y,
        value: absorbed,
        targetId,
        category: "shield",
        color: monster.behavior === "guard" ? "#89cfff" : "#c77dff",
      });
      runtime.world.components.hitFlashes.set(targetId, { remainingMs: 110, totalMs: 110 });
      if (remainingDamage <= 0) {
        return;
      }
    }

    healthDamage = applyHealthDamage(health, healthDamage);
    if (healthDamage <= 0) return;

    runtime.world.components.hitFlashes.set(targetId, { remainingMs: isCrit ? 140 : 90, totalMs: isCrit ? 140 : 90 });
    EventBus.emit("combat:damage", {
      x: transform.x,
      y: transform.y,
      value: healthDamage,
      targetId,
      category: "outgoing",
      color,
      isCrit,
    });
  }

  private explode(runtime: GameRuntime, x: number, y: number, radius: number, damage: number): void {
    const radiusSquared = radius * radius;
    const isNuke = radius >= 220;
    EventBus.emit("combat:vfx", { kind: "explosion", x, y, color: 0xffca3a, radius });

    EventBus.emit("fx:sparks", { x, y, color: 0xffca3a, count: isNuke ? 42 : 16, size: isNuke ? 12 : 9 });

    for (const entityId of getAttackableMonsterIds(runtime.world)) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform || distanceSquared(x, y, transform.x, transform.y) > radiusSquared) {
        continue;
      }

      this.applyDamage(runtime, entityId, Math.ceil(damage), "#ffca3a");
      const direction = normalize(transform.x - x, transform.y - y);
      runtime.world.components.knockbacks.set(entityId, {
        x: direction.x * (isNuke ? 540 : 360),
        y: direction.y * (isNuke ? 540 : 360),
        remainingMs: isNuke ? 230 : 170,
      });
    }
  }

  private chain(runtime: GameRuntime, firstTargetId: EntityId, jumps: number, radius: number, damage: number): void {
    let currentTargetId = firstTargetId;
    const hit = new Set<EntityId>([firstTargetId]);

    for (let jump = 0; jump < jumps; jump += 1) {
      const currentTransform = runtime.world.components.transforms.get(currentTargetId);
      if (!currentTransform) {
        return;
      }

      let nextTargetId: EntityId | undefined;
      let nextDistance = Number.POSITIVE_INFINITY;
      const radiusSquared = radius * radius;

      for (const candidateId of getAttackableMonsterIds(runtime.world)) {
        if (hit.has(candidateId)) {
          continue;
        }

        const candidateTransform = runtime.world.components.transforms.get(candidateId);
        if (!candidateTransform) {
          continue;
        }

        const distance = distanceSquared(currentTransform.x, currentTransform.y, candidateTransform.x, candidateTransform.y);
        if (distance <= radiusSquared && distance < nextDistance) {
          nextTargetId = candidateId;
          nextDistance = distance;
        }
      }

      if (!nextTargetId) {
        return;
      }

      hit.add(nextTargetId);
      currentTargetId = nextTargetId;
      this.applyDamage(runtime, nextTargetId, Math.ceil(damage), "#fff3b0");
      const targetTransform = runtime.world.components.transforms.get(nextTargetId);
      if (targetTransform) {
        EventBus.emit("combat:vfx", { kind: "chain", x: currentTransform.x, y: currentTransform.y, x2: targetTransform.x, y2: targetTransform.y, color: 0xfff3b0 });
        EventBus.emit("fx:sparks", { x: targetTransform.x, y: targetTransform.y, color: 0xfff3b0, count: 2, size: 8 });
      }
    }
  }
}
