import { EventBus } from "../managers/EventBus";
import { distanceSquared } from "../utils/math";
import type { EntityId } from "../components/ComponentTypes";
import { canReceiveHostileDamage, getHostileHitGraceMs } from "./PlayerDamageModel";
import type { GameRuntime, System } from "./SystemTypes";

export class EnemyProjectileSystem implements System {
  readonly telemetrySource = "EnemyProjectileSystem";
  update(_deltaMs: number, runtime: GameRuntime): void {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    const player = runtime.world.components.players.get(runtime.playerId);
    if (!playerTransform || !playerHealth || !player) {
      return;
    }

    const hitProjectiles: EntityId[] = [];
    for (const [entityId, projectile] of runtime.world.components.enemyProjectiles) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform) {
        continue;
      }

      const hitRadius = transform.radius + playerTransform.radius;
      if (distanceSquared(transform.x, transform.y, playerTransform.x, playerTransform.y) > hitRadius * hitRadius) {
        continue;
      }

      hitProjectiles.push(entityId);
      if (player.dashRemainingMs > 0) {
        EventBus.emit("fx:sparks", { x: transform.x, y: transform.y, color: 0x69e8ff, count: 5, size: 7 });
        continue;
      }
      if (!canReceiveHostileDamage(player)) {
        continue;
      }

      playerHealth.current -= projectile.damage;
      player.damageCooldownMs = getHostileHitGraceMs("projectile");
      EventBus.emit("combat:damage", { x: playerTransform.x, y: playerTransform.y, value: projectile.damage, color: "#9f86c0", targetId: runtime.playerId, category: "incoming" });
    }

    for (const entityId of hitProjectiles) {
      runtime.world.destroyEntity(entityId);
    }
  }
}
