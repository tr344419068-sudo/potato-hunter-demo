import { EventBus } from "../managers/EventBus";
import { sweepTime } from "../utils/math";
import type { EntityId } from "../components/ComponentTypes";
import { canReceiveHostileDamage, getHostileHitGraceMs } from "./PlayerDamageModel";
import { getMovementSweepOrigins } from "./MovementSystem";
import { emitEnemyProjectileAccent } from "./EnemyProjectileModel";
import type { GameRuntime, System } from "./SystemTypes";

export class EnemyProjectileSystem implements System {
  readonly telemetrySource = "EnemyProjectileSystem";
  update(deltaMs: number, runtime: GameRuntime): void {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    const player = runtime.world.components.players.get(runtime.playerId);
    if (!playerTransform || !playerHealth || !player) {
      return;
    }

    const playerStart = getMovementSweepOrigins(runtime.world)?.get(runtime.playerId) ?? playerTransform;
    const hitProjectiles: { entityId: EntityId; damage: number; x: number; y: number; at: number }[] = [];
    for (const [entityId, projectile] of runtime.world.components.enemyProjectiles) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform) {
        continue;
      }

      const from = projectile.sweepOrigin;
      projectile.sweepOrigin = undefined;
      const start = from ? playerStart : playerTransform;
      const fraction = from?.stepFraction ?? 1;
      const relativeEnd = {
        x: transform.x - (playerTransform.x - start.x) * fraction,
        y: transform.y - (playerTransform.y - start.y) * fraction,
      };
      const shotStart = from ?? transform;
      const time = sweepTime(shotStart, relativeEnd, start, transform.radius + playerTransform.radius);
      if (time === undefined) continue;
      hitProjectiles.push({ entityId, damage: projectile.damage, at: from ? time * fraction * deltaMs : deltaMs,
        x: shotStart.x + (transform.x - shotStart.x) * time, y: shotStart.y + (transform.y - shotStart.y) * time });
    }

    // The first arriving round wins the grace period, not the oldest entity ID.
    hitProjectiles.sort((a, b) => a.at - b.at);
    const prior = runtime.hostileProtectionAtStepStart;
    // Input and stats tick before flight. Preserve protection granted this step
    // by a new dash or by another damage system that already ran.
    const dashUntil = prior && player.dashRemainingMs <= Math.max(0, prior.dashRemainingMs - deltaMs)
      ? prior.dashRemainingMs : player.dashRemainingMs > 0 ? deltaMs + player.dashRemainingMs : 0;
    let graceUntil = prior && player.damageCooldownMs <= Math.max(0, prior.damageCooldownMs - deltaMs)
      ? prior.damageCooldownMs : player.damageCooldownMs > 0 ? deltaMs + player.damageCooldownMs : 0;
    for (const { entityId, damage, x, y, at } of hitProjectiles) {
      const render = runtime.world.components.renders.get(entityId);
      const velocity = runtime.world.components.velocities.get(entityId);
      runtime.world.destroyEntity(entityId);
      const protectionAtContact = { dashRemainingMs: dashUntil - at, damageCooldownMs: graceUntil - at };
      if (!canReceiveHostileDamage(protectionAtContact)) {
        if (protectionAtContact.dashRemainingMs > 0) EventBus.emit("fx:sparks", { x, y, color: 0x69e8ff, count: 5, size: 7 });
        continue;
      }

      playerHealth.current -= damage;
      graceUntil = (prior ? at : deltaMs) + getHostileHitGraceMs("projectile");
      player.damageCooldownMs = Math.max(0, graceUntil - deltaMs);
      emitEnemyProjectileAccent(x, y, Math.atan2(velocity?.y ?? 0, velocity?.x ?? 1), render?.color ?? 0xffa565, "impact");
      EventBus.emit("combat:damage", { x: playerTransform.x, y: playerTransform.y, value: damage, color: "#ff9292", targetId: runtime.playerId, category: "incoming" });
    }
  }
}
