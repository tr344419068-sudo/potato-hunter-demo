import type { SnowState } from "./SnowEnemySystem";

type PoseState = Pick<SnowState, "role" | "phase" | "remainingMs" | "durationMs" | "angle" | "guardHp">;

/** Aimed poses follow the same locked lane as their hitbox. These sprites are authored facing left. */
export function getSnowEnemyPose(state: PoseState, facing: number) {
  const { role, phase, angle, guardHp } = state;
  const elapsed = state.durationMs - state.remainingMs;
  const recoil = role === "needle" && phase === "recover" && elapsed < 155;
  const posed = (phase === "guard" && guardHp > 0) || phase === "tell" || phase === "roll" || recoil;
  const dx = Math.cos(angle);
  const turn = posed && Math.abs(dx) > .1 ? (dx < 0 ? 1 : -1) : facing;
  return {
    facing: turn,
    assetId: posed ? `enemy_snow_${role}_pose` : undefined,
    rotation: role === "roller" && phase === "roll" ? -turn * elapsed * .014
      : recoil ? turn * .2 * (1 - elapsed / 155)
      : role === "elite" && phase === "roll" ? turn * .11 : 0,
  };
}
