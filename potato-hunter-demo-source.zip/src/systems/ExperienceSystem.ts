import { distanceSquared, normalize } from "../utils/math";
import { EntityPools } from "../managers/EntityPools";
import { getNextExperienceRequirement } from "../managers/PacingModel";
import { ConfigManager } from "../managers/ConfigManager";
import { getPlayerLevelGrowth, reconcilePlayerMaxHp } from "../managers/PlayerLevelGrowthModel";
import type { EntityId } from "../components/ComponentTypes";
import type { GameRuntime, System } from "./SystemTypes";
import { EventBus } from "../managers/EventBus";

export class ExperienceSystem implements System {
  update(_deltaMs: number, runtime: GameRuntime): void {
    const player = runtime.world.components.players.get(runtime.playerId);
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const health = runtime.world.components.health.get(runtime.playerId);
    if (!player || !playerTransform || !health || health.current <= 0) {
      return;
    }

    const collectedOrbs: EntityId[] = [];

    for (const [orbId, orb] of runtime.world.components.experienceOrbs) {
      const transform = runtime.world.components.transforms.get(orbId);
      const velocity = runtime.world.components.velocities.get(orbId);
      if (!transform || !velocity) {
        continue;
      }

      const pickupRadiusSquared = player.pickupRadius * player.pickupRadius;
      const distance = distanceSquared(playerTransform.x, playerTransform.y, transform.x, transform.y);

      if (distance <= pickupRadiusSquared) {
        const direction = normalize(playerTransform.x - transform.x, playerTransform.y - transform.y);
        const distanceFactor = Math.max(0, 1 - Math.sqrt(distance) / player.pickupRadius);
        const speed = 360 + distanceFactor * 520;
        velocity.x = direction.x * speed;
        velocity.y = direction.y * speed;
      }

      const collectRadius = playerTransform.radius + transform.radius + 4;
      if (distance <= collectRadius * collectRadius) {
        player.experience += orb.value;
        collectedOrbs.push(orbId);
      }
    }

    for (const orbId of collectedOrbs) {
      EntityPools.releaseExpOrb(runtime.world, orbId);
    }

    if (collectedOrbs.length > 0) {
      EventBus.emit("reward:collected", { kind: "experience", count: collectedOrbs.length });
      this.processLevelUps(runtime);
    }
  }

  private processLevelUps(runtime: GameRuntime): void {
    const player = runtime.world.components.players.get(runtime.playerId);
    const health = runtime.world.components.health.get(runtime.playerId);
    if (!player || !health) {
      return;
    }

    while (health.current > 0 && player.experience >= player.experienceToNext) {
      player.experience -= player.experienceToNext;
      player.level += 1;
      player.experienceToNext = getNextExperienceRequirement(player.experienceToNext, player.level);
      const growth = getPlayerLevelGrowth(player.level);
      reconcilePlayerMaxHp(health, ConfigManager.player.maxHp + growth.maxHpBonus + runtime.skillManager.getMaxHpBonus());
      health.current = Math.min(health.max, health.current + Math.ceil(health.max * growth.healRatio));
      runtime.requestSkillChoice([]);
    }
  }
}
