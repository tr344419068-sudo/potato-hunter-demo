import type Phaser from "phaser";
import type { AoeWarningComponent, TransformComponent } from "../components/ComponentTypes";
import { AssetManager } from "../managers/AssetManager";

const SWEEP = "vfx_duel_sweep_tell";
const RING = "vfx_halo_energy_v1";
const DANGER = 0xff6558;
const SAFE = 0x86efa9;

/** Bitmap telegraphs only; the collision geometry remains in AoeWarningSystem. */
export class HostileWarningView {
  private readonly layers = new Map<number, { border: Phaser.GameObjects.Image; safe?: Phaser.GameObjects.Image }>();

  constructor(private readonly scene: Phaser.Scene) {}

  draw(id: number, warning: AoeWarningComponent, { x, y, radius }: TransformComponent, progress: number): void {
    const sweep = warning.shape === "capsule";
    const asset = sweep && AssetManager.hasTexture(this.scene, SWEEP) ? SWEEP : RING;
    if (!AssetManager.hasTexture(this.scene, asset)) return;
    const key = AssetManager.getTextureKey(asset);
    let layer = this.layers.get(id);
    if (!layer) {
      layer = { border: this.scene.add.image(x, y, key).setDepth(1.3) };
      this.layers.set(id, layer);
    }
    const diameter = radius * 2;
    // Alpha rim includes stray sparks; match the continuous core to the hit envelope.
    const scaleX = asset === SWEEP ? 1.065 : 1.16;
    const scaleY = asset === SWEEP ? 1.39 : 1.16;
    const tint = asset === SWEEP ? 0xffffff : warning.damage === 0 ? 0xffb965 : DANGER;
    layer.border.setPosition(x, y).setRotation(sweep ? warning.angle ?? 0 : 0)
      .setDisplaySize((diameter + (sweep ? warning.length ?? 0 : 0)) * scaleX, diameter * scaleY)
      .setTint(tint).setAlpha(.52 + Math.min(1, progress) * .43);
    if (warning.safeRadius !== undefined && AssetManager.hasTexture(this.scene, RING)) {
      layer.safe ??= this.scene.add.image(x, y, AssetManager.getTextureKey(RING)).setDepth(1.31);
      const size = warning.safeRadius * 2.32;
      layer.safe.setPosition(x, y).setDisplaySize(size, size).setTint(SAFE).setAlpha(.70);
    }
  }

  prune(active: ReadonlyMap<number, AoeWarningComponent>): void {
    for (const [id, layer] of this.layers) {
      if (active.has(id)) continue;
      layer.border.destroy(); layer.safe?.destroy(); this.layers.delete(id);
    }
  }
}
