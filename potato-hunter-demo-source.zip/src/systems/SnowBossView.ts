import type Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import { UI_FONT } from "../ui/UITheme";
import { getBossDuel } from "./BossDuelArena";
import { getSnowCast, getSnowPunishWindow, getSnowSafePaths, SNOW_CAST_LABELS, SNOW_PULSE_EFFECT_MS, SNOW_PULSE_INTERVAL_MS, type SnowCast, type SnowPattern, type SnowShape } from "./SnowBossEncounter";
import type { GameRuntime } from "./SystemTypes";

const SWING = "boss_snow_hammer_swing";
const SPIKES = "vfx_snow_ice_spikes";
const AVALANCHE = "vfx_snow_avalanche";
const SHATTER = "vfx_snow_ice_shatter";
const SHIELD = "vfx_boss_static_ring";
const DANGER_FLOOR = 0x812842;
const DANGER_EDGE = 0xffa77b;
const SAFE_FLOOR = 0x126858;
const SAFE_EDGE = 0x85ffe0;
const DARK = 0x281e39;

type Point = { x: number; y: number };
type Arena = SnowCast["arena"];
type Lane = Extract<SnowShape, { kind: "ice_spikes" | "glacier_charge" }>;
const progress = (elapsed: number, duration: number): number => Math.max(0, Math.min(1, elapsed / Math.max(1, duration)));
const aim = (origin: Point, angle: number, distance: number): Point => ({ x: origin.x + Math.cos(angle) * distance, y: origin.y + Math.sin(angle) * distance });

export function canShowSnowAttack(scene: Phaser.Scene, pattern: SnowPattern): boolean {
  const has = (asset: string): boolean => AssetManager.hasTexture(scene, asset);
  switch (pattern) {
    case "hammer_swing": return has(SWING) && has(SHATTER);
    case "ice_spikes": return has(SPIKES);
    case "glacier_charge": return has(SWING) && has(SHATTER);
    case "avalanche": return has(AVALANCHE);
  }
}

function clipToRing(arena: Arena, point: Point): Point {
  const dx = point.x - arena.x, dy = point.y - arena.y;
  const ratio = Math.min(1, arena.radius / Math.max(1, Math.hypot(dx, dy)));
  return { x: arena.x + dx * ratio, y: arena.y + dy * ratio };
}

function sector(arena: Arena, shape: Extract<SnowShape, { kind: "hammer_swing" }>): Point[] {
  const { origin, radius, angle, halfAngle } = shape;
  return [origin, ...Array.from({ length: 25 }, (_, i) => {
    const heading = angle + (i / 12 - 1) * halfAngle;
    const dx = origin.x - arena.x, dy = origin.y - arena.y;
    const dot = dx * Math.cos(heading) + dy * Math.sin(heading);
    const reach = Math.sqrt(Math.max(0, dot * dot + arena.radius ** 2 - dx * dx - dy * dy)) - dot;
    return aim(origin, heading, Math.min(radius, Math.max(0, reach)));
  })];
}

function capsule(arena: Arena, shape: Lane): Point[] {
  return [shape.end, shape.origin].flatMap((point, end) => Array.from({ length: 13 }, (_, i) => {
    const angle = shape.angle + (i / 12 - .5 + end) * Math.PI;
    return clipToRing(arena, aim(point, angle, shape.radius));
  }));
}

function slab(arena: Arena, minX: number, maxX: number): Point[] {
  const arc = Array.from({ length: 21 }, (_, i) => {
    const x = minX + (maxX - minX) * i / 20;
    const half = Math.sqrt(Math.max(0, arena.radius ** 2 - (x - arena.x) ** 2));
    return { x, top: arena.y - half, bottom: arena.y + half };
  });
  return [...arc.map(p => ({ x: p.x, y: p.top })), ...arc.reverse().map(p => ({ x: p.x, y: p.bottom }))];
}

/** Only ground geometry is procedural. The impact, armor and plume layers are sprite art. */
export class SnowBossView {
  private readonly ground: Phaser.GameObjects.Graphics;
  private readonly layers: Phaser.GameObjects.Image[] = [];
  private hint?: Phaser.GameObjects.Text;
  private used = 0;

  constructor(private readonly scene: Phaser.Scene) {
    this.ground = scene.add.graphics().setDepth(1.57);
  }

  draw(runtime: GameRuntime): void {
    this.ground.clear();
    this.used = 0;
    this.hint?.setVisible(false);
    const { world, playerId } = runtime;
    const duel = getBossDuel(world);
    if (duel?.stage === "snow") {
      const monster = world.components.monsters.get(duel.bossId);
      const boss = world.components.transforms.get(duel.bossId);
      const armor = monster?.finalBossEncounter?.sandArmor;
      if (boss && armor && armor.hp > 0) {
        const ratio = armor.hp / armor.max;
        const frameCount = AssetManager.getAsset(SHIELD)?.frameCount ?? 1;
        this.image(SHIELD, { x: boss.x, y: boss.y + 6 }, 194, 128, 0, .65 + ratio * .29,
          Math.floor(armor.remainingMs / 72) % frameCount, .5, 0x8cdcff, 1.61);
      }
      const cast = getSnowCast(world);
      const hero = world.components.transforms.get(playerId);
      if (cast) this.drawCast(cast, hero, boss);
      else if (hero) {
        const punish = getSnowPunishWindow(world);
        if (punish) this.showHint(hero, punish === "pillar" ? "冰岩碎裂 · 破盾反击" : "雪崩已停 · 趁势反击", "#a6ffe0");
      }
    }
    for (let i = this.used; i < this.layers.length; i++) this.layers[i].setVisible(false);
  }

  destroy(): void {
    this.ground.destroy();
    this.hint?.destroy();
    for (const layer of this.layers) layer.destroy();
    this.layers.length = 0;
  }

  private drawCast(cast: SnowCast, hero: Point | undefined, boss: Point | undefined): void {
    const { shape, arena, elapsedMs, tellMs } = cast;
    const age = elapsedMs - tellMs;
    const warning = age < 0;
    const windup = progress(elapsedMs, tellMs);
    if (shape.kind === "avalanche") {
      for (let index = 0; index < shape.pulses.length; index++) {
        const pulse = shape.pulses[index];
        const { minX, maxX } = pulse;
        const beat = elapsedMs - pulse.impactMs;
        const warningMs = index === 0 ? tellMs : SNOW_PULSE_INTERVAL_MS;
        if (beat < 0 && beat >= -warningMs) {
          const tension = 1 + beat / warningMs;
          this.zone(slab(arena, minX, maxX), tension, false);
          for (const safe of getSnowSafePaths(arena, pulse)) this.zone(slab(arena, safe.minX, safe.maxX), tension, true);
          if (hero) this.showHint(hero, `雪崩 ${index + 1}/3 · 走青色路线`);
        } else if (beat >= 0 && beat < SNOW_PULSE_EFFECT_MS) {
          const impact = progress(beat, SNOW_PULSE_EFFECT_MS);
          const width = maxX - minX, x = (minX + maxX) / 2;
          const chord = Math.sqrt(Math.max(0, arena.radius ** 2 - (x - arena.x) ** 2));
          const rows = Math.max(1, Math.ceil(chord * 2 / 113));
          for (let j = 0; j < rows; j++) {
            const plume = Math.min(.999, .13 + impact * .86 + (j % 3) * .028);
            const y = arena.y + chord * (2 * (j + .5) / rows - 1) + (impact - .35) * 25;
            this.image(AVALANCHE, { x, y }, width * 1.02, 244, 0, 1 - impact ** 1.9 * .74,
              this.frame(AVALANCHE, plume), .44, 0xffffff, 1.74, j % 2 === 1);
          }
        }
      }
      return;
    }
    if (warning) {
      const points = shape.kind === "hammer_swing" ? sector(arena, shape) : capsule(arena, shape);
      this.zone(points, windup, false);
      if (hero && shape.kind !== "hammer_swing") this.showHint(hero, cast.readable ? SNOW_CAST_LABELS[shape.kind] : "无伤演示");
      if (shape.kind === "glacier_charge") {
        const length = Math.hypot(shape.end.x - shape.origin.x, shape.end.y - shape.origin.y);
        this.ground.lineStyle(4, 0xffd6ab, .58 + .4 * windup);
        for (let along = 41; along + 16 < length; along += 47) {
          const tip = aim(shape.origin, shape.angle, along + 15);
          const start = aim(shape.origin, shape.angle, along);
          for (const side of [-1, 1]) {
            const wing = aim(start, shape.angle + side * Math.PI / 2, 12);
            this.ground.lineBetween(wing.x, wing.y, tip.x, tip.y);
          }
        }
      }
      return;
    }
    if (shape.kind === "hammer_swing") {
      const point = aim(shape.origin, shape.angle, shape.radius * .64);
      this.image(SHATTER, clipToRing(arena, point), 158, 122, 0, .99,
        this.frame(SHATTER, Math.max(.09, progress(age, 270))), .76, 0xffffff, 1.79);
    } else if (shape.kind === "ice_spikes") {
      const length = Math.hypot(shape.end.x - shape.origin.x, shape.end.y - shape.origin.y);
      const count = Math.max(2, Math.ceil(length / 62));
      const raise = progress(age, cast.durationMs - tellMs);
      for (let i = 0; i < count; i++) {
        const loc = aim(shape.origin, shape.angle, length * (i + .55) / count);
        this.image(SPIKES, loc, shape.radius * 2.06, 146, Math.cos(shape.angle) * .13,
          1 - raise ** 2 * .6, this.frame(SPIKES, Math.max(.10, raise)), .83, 0xffffff, 1.78, i % 2 === 1);
      }
    } else if (boss) {
      const remaining = progress(age, shape.travelMs);
      this.zone(capsule(arena, { ...shape, origin: boss }), .88, false);
      const point = aim(boss, shape.angle, -45);
      this.image(SHATTER, point, 143, 100, 0, .68, this.frame(SHATTER, .20 + .55 * remaining), .76, 0x9dd6ff, 1.70);
    }
  }

  private zone(points: Point[], intensity: number, safe: boolean): void {
    const edge = safe ? SAFE_EDGE : DANGER_EDGE, floor = safe ? SAFE_FLOOR : DANGER_FLOOR;
    this.ground.fillStyle(floor, (safe ? .20 : .27) + .23 * intensity).fillPoints(points, true)
      .lineStyle(safe ? 6 : 8, DARK, .89).strokePoints(points, true)
      .lineStyle(safe ? 3 : 4, edge, .85 + intensity * .14).strokePoints(points, true);
  }

  private showHint(hero: Point, text: string, color = "#ffe5d6"): void {
    this.hint ??= this.scene.add.text(0, 0, "", {
      fontFamily: UI_FONT, fontSize: "19px", fontStyle: "bold", stroke: "#16243a", strokeThickness: 5,
    }).setOrigin(.5, .5).setDepth(4.25);
    this.hint.setPosition(hero.x, hero.y + 77).setText(text).setColor(color).setVisible(true);
  }

  private frame(asset: string, normalized: number): number {
    const count = AssetManager.getAsset(asset)?.frameCount ?? 1;
    return Math.min(count - 1, Math.floor(normalized * count));
  }

  private image(asset: string, point: Point, width: number, height: number, rotation: number, alpha: number, frame: number,
    originY: number, tint: number, depth: number, flip = false): void {
    if (!AssetManager.hasTexture(this.scene, asset)) return;
    const key = AssetManager.getTextureKey(asset);
    const index = this.used++;
    const layer = this.layers[index] ?? (this.layers[index] = this.scene.add.image(point.x, point.y, key));
    layer.setTexture(key, frame).setOrigin(.5, originY).setPosition(point.x, point.y).setDisplaySize(width, height)
      .setRotation(rotation).setAlpha(alpha).setTint(tint).setDepth(depth).setFlipX(flip).setVisible(true);
  }
}
