import Phaser from 'phaser';
import { AssetManager } from '../managers/AssetManager';
import type { AuraProfile } from '../managers/SkillTypes';
import type { CombatVfxKind } from './CombatVfxModel';
import { AREA_MOTE_PERIOD_MS, AREA_WAVE_PERIOD_MS, getAreaGlowFrame, getAreaMoteFrame, getAreaWaveFrame, getAreaVfxSpec, MAX_AREA_LAYERS } from './AreaVfxModel';
import type { GameRuntime } from './SystemTypes';
import { getExpandingAuraSamples } from './ExpandingAuraPulse';
interface Emission {
    visual: Phaser.GameObjects.Graphics;
    glow?: Phaser.GameObjects.Image;
    glowAlphaMultiplier: number;
    x: number;
    y: number;
    radius: number;
}
interface AreaLayer {
    kind: CombatVfxKind;
    waves: Emission[];
    motes: Emission[];
    fieldGlow?: Phaser.GameObjects.Image;
}
/** Hollow wavefronts expand around the current hero, matching aura damage. */
export class AreaVfxView {
    private readonly layers = new Map<string, AreaLayer>();
    private elapsedMs = 0;
    private reducedEffects = false;
    private destroyed = false;
    constructor(private readonly scene: Phaser.Scene) { }
    setReducedEffects(value: boolean): void { this.reducedEffects = value; }
    hasKind(kind: CombatVfxKind): boolean { return [...this.layers.values()].some(layer => layer.kind === kind); }
    update(deltaMs: number, runtime: GameRuntime): void {
        if (this.destroyed)
            return;
        const transform = runtime.world.components.transforms.get(runtime.playerId);
        const profiles = transform && runtime.skillManager?.getAuraProfiles
            ? runtime.skillManager.getAuraProfiles(runtime.world.components.players.get(runtime.playerId)?.level).filter(p => Number.isFinite(p.radius) && p.radius > 0).slice(0, MAX_AREA_LAYERS) : [];
        const ids = new Set(profiles.map(p => p.skillId));
        const pulses = getExpandingAuraSamples(runtime.world);
        for (const [id, layer] of this.layers)
            if (!ids.has(id)) {
                this.release(layer);
                this.layers.delete(id);
            }
        if (!transform)
            return;
        this.elapsedMs += Number.isFinite(deltaMs) ? Math.max(0, deltaMs) : 0;
        for (const profile of profiles) {
            let layer = this.layers.get(profile.skillId);
            if (layer && layer.kind !== profile.vfxKind) {
                this.release(layer);
                this.layers.delete(profile.skillId);
                layer = undefined;
            }
            if (!layer) {
                const candidates = profile.vfxKind === 'poison' ? ['vfx_poison_halo_user_v1', 'vfx_halo_energy_v1']
                    : profile.vfxKind === 'ketchup' ? ['vfx_ketchup_halo_user_v1', 'vfx_halo_energy_v1'] : ['vfx_halo_energy_v1'];
                const validAsset = (assetId: string): boolean => {
                    const candidateKey = AssetManager.getTextureKey(assetId);
                    const texture = this.scene.textures.exists(candidateKey) && typeof this.scene.textures.get === 'function' ? this.scene.textures.get(candidateKey) : undefined;
                    const frame = texture?.key === candidateKey && typeof texture.get === 'function' ? texture.get() : undefined;
                    return Boolean(frame && Number.isFinite(frame.realWidth) && frame.realWidth > 0 && Number.isFinite(frame.realHeight) && frame.realHeight > 0);
                };
                const glowAssetId = candidates.find(validAsset);
                const key = glowAssetId ? AssetManager.getTextureKey(glowAssetId) : '';
                const isKetchupArt = glowAssetId === 'vfx_ketchup_halo_user_v1';
                // Preserve user hues and highlights; normal blending keeps sauce
                // red on green grass rather than washing it into additive yellow.
                const glowTint = glowAssetId === 'vfx_poison_halo_user_v1' || isKetchupArt ? 0xffffff : getAreaVfxSpec(profile.vfxKind).primaryColor;
                const make = (wave = false): Emission => ({
                    visual: this.scene.add.graphics().setDepth(.68).setBlendMode(Phaser.BlendModes.NORMAL),
                    glow: wave && glowAssetId ? this.scene.add.image(transform.x, transform.y, key).setDepth(.69).setBlendMode(isKetchupArt ? Phaser.BlendModes.NORMAL : Phaser.BlendModes.ADD).setTint(glowTint) : undefined,
                    glowAlphaMultiplier: isKetchupArt ? .65 / .9 : 1,
                    x: transform.x, y: transform.y, radius: profile.radius,
                });
                const fieldGlow = validAsset('vfx_halo_energy_v1')
                    ? this.scene.add.image(transform.x, transform.y, AssetManager.getTextureKey('vfx_halo_energy_v1'))
                        .setDepth(.685).setBlendMode(Phaser.BlendModes.ADD).setTint(getAreaVfxSpec(profile.vfxKind).primaryColor)
                    : undefined;
                layer = { kind: profile.vfxKind, waves: [make(true), make(true)], motes: Array.from({ length: 6 }, () => make()), fieldGlow };
                this.layers.set(profile.skillId, layer);
            }
            if (profile.pulseExpansionMs) {
                const pulse = pulses.get(profile.skillId);
                this.updateExpandingPulse(layer, transform.x, transform.y, pulse ?? { radius: 0, fade: 0 });
            } else this.updateLayer(layer, profile, transform.x, transform.y);
        }
    }
    destroy(): void {
        if (this.destroyed) return;
        this.destroyed = true;
        for (const layer of this.layers.values()) this.release(layer);
        this.layers.clear();
    }
    private syncFrame(emission: Emission, time: number, period: number, x: number, y: number, radius: number): number {
        // Aura damage moves with the hero. Only phase is cyclic; origins and
        // upgraded radii must never wait for a new emission, including dashes.
        emission.x = x;
        emission.y = y;
        emission.radius = radius;
        return time % period;
    }
    private updateLayer(layer: AreaLayer, profile: AuraProfile, x: number, y: number): void {
        const colors = getAreaVfxSpec(layer.kind);
        if (layer.fieldGlow) {
            const alpha = this.reducedEffects ? 0 : .58 + .08 * Math.sin(this.elapsedMs / 720);
            layer.fieldGlow.setPosition(x, y).setDisplaySize(profile.radius * 2, profile.radius * 2)
                .setRotation(this.elapsedMs * .00012).setAlpha(alpha).setVisible(alpha > 0);
        }
        for (const [index, wave] of layer.waves.entries()) {
            const age = this.syncFrame(wave, this.elapsedMs + index * 450, AREA_WAVE_PERIOD_MS, x, y, profile.radius);
            const frame = getAreaWaveFrame(wave.radius, age, this.reducedEffects);
            const g = wave.visual;
            g.clear();
            // Reuse the first wave's graphics for a stable, hollow light field.
            // Its inverse scale keeps the band aligned with the actual damage
            // radius while the separate wavefront expands and fades over it.
            const visualAlpha = index === 0 ? Math.max(frame.alpha, this.reducedEffects ? .2 : .34) : frame.alpha;
            const waveOpacity = visualAlpha ? frame.alpha / visualAlpha : 0;
            if (index === 0) {
                const invScale = 1 / frame.scale;
                const pulse = this.reducedEffects ? .62 : .9 + .1 * Math.sin(this.elapsedMs / 550);
                const bandRadius = wave.radius * .78 * invScale;
                for (const [width, opacity] of [[.4, .018], [.32, .025], [.24, .032], [.16, .04], [.09, .055], [.04, .09]]) {
                    g.lineStyle(wave.radius * width * invScale, colors.primaryColor, opacity * pulse / visualAlpha).strokeCircle(0, 0, bandRadius);
                }
                g.lineStyle(1.7 * invScale, colors.accentColor, .22 * pulse / visualAlpha).strokeCircle(0, 0, wave.radius * .6 * invScale);
                g.lineStyle(1.8 * invScale, colors.edgeColor, .24 * pulse / visualAlpha).strokeCircle(0, 0, wave.radius * .94 * invScale);
                // Moving highlights travel around the band without obscuring
                // the hero or introducing new per-frame display objects.
                for (let arc = 0; arc < 4; arc++) {
                    const start = arc * Math.PI / 2 + this.elapsedMs * .00032 - frame.rotation;
                    g.lineStyle(3 * invScale, colors.edgeColor, .30 * pulse / visualAlpha).beginPath().arc(0, 0, bandRadius, start, start + .42).strokePath();
                }
            }
            // Expanding wavefront and disconnected glints retain their own fade.
            g.lineStyle(4.5, colors.primaryColor, .17 * waveOpacity).strokeCircle(0, 0, wave.radius);
            g.lineStyle(frame.lineWidth, colors.accentColor, .95 * waveOpacity).strokeCircle(0, 0, wave.radius);
            for (let arc = 0; arc < 3; arc++) {
                const start = arc * Math.PI * 2 / 3 + index * .7;
                g.lineStyle(3.8, colors.edgeColor, waveOpacity).beginPath().arc(0, 0, wave.radius * .982, start, start + .15).strokePath();
                // Broken, lightly undulating ribbons move with the wave phase.
                // They add a moving crest without painting over the ground or hero.
                g.lineStyle(2.2, colors.edgeColor, .94 * waveOpacity).beginPath();
                for (let point = 0; point <= 12; point++) {
                    const angle = start + .24 + point * .72 / 12;
                    const radius = wave.radius * (.91 + .035 * Math.sin(point * .8 + frame.rotation * 20 + arc));
                    const px = Math.cos(angle) * radius, py = Math.sin(angle) * radius;
                    if (point === 0) g.moveTo(px, py); else g.lineTo(px, py);
                }
                g.strokePath();
            }
            g.setPosition(wave.x, wave.y).setRotation(frame.rotation).setScale(frame.scale).setAlpha(visualAlpha).setVisible(!this.reducedEffects || index === 0);
            if (wave.glow) {
                const glowFrame = getAreaGlowFrame(wave.radius, age, this.reducedEffects);
                wave.glow.setPosition(wave.x, wave.y).setDisplaySize(glowFrame.displaySize, glowFrame.displaySize).setRotation(glowFrame.rotation).setAlpha(glowFrame.alpha * wave.glowAlphaMultiplier).setVisible(!this.reducedEffects && glowFrame.alpha > 0);
            }
        }
        for (const [index, mote] of layer.motes.entries()) {
            const age = this.syncFrame(mote, this.elapsedMs + index * 120, AREA_MOTE_PERIOD_MS, x, y, profile.radius);
            const frame = getAreaMoteFrame(mote.radius, age, index, this.reducedEffects), g = mote.visual;
            g.clear().fillStyle(colors.primaryColor, .12).fillCircle(0, 0, frame.size * .72);
            g.lineStyle(1.2, colors.accentColor, 1).lineBetween(-frame.size * .35, 0, frame.size * .35, 0);
            g.lineBetween(0, -frame.size * .2, 0, frame.size * .2);
            g.setPosition(mote.x + frame.x, mote.y + frame.y).setRotation(frame.rotation).setAlpha(frame.alpha).setVisible(frame.visible);
        }
    }
    private updateExpandingPulse(layer: AreaLayer, x: number, y: number, pulse: { radius: number; fade: number }): void {
        const colors = getAreaVfxSpec(layer.kind);
        const [front, echo] = layer.waves;
        const alpha = pulse.fade * (this.reducedEffects ? .55 : .9);
        const r = pulse.radius;
        layer.fieldGlow?.setVisible(false);
        for (const mote of layer.motes) mote.visual.setVisible(false);
        echo.visual.setVisible(false); echo.glow?.setVisible(false);
        const g = front.visual.clear().setPosition(x, y).setRotation(0).setScale(1).setAlpha(alpha).setVisible(alpha > 0);
        g.lineStyle(this.reducedEffects ? 3 : 9, colors.primaryColor, .25).strokeCircle(0, 0, r);
        g.lineStyle(2, colors.accentColor, .82).strokeCircle(0, 0, r);
        if (!this.reducedEffects) for (let arc = 0; arc < 5; arc++) {
            const start = arc * Math.PI * 2 / 5 + this.elapsedMs * .0005;
            g.lineStyle(4, colors.edgeColor, .84).beginPath().arc(0, 0, r, start, start + .27).strokePath();
        }
        front.glow?.setPosition(x, y).setDisplaySize(r * 2, r * 2).setRotation(this.elapsedMs * .0003)
            .setAlpha(alpha * .48).setVisible(!this.reducedEffects && alpha > 0);
    }
    private release(layer: AreaLayer): void {
        layer.fieldGlow?.destroy();
        for (const emission of [...layer.waves, ...layer.motes]) {
            emission.visual.destroy();
            emission.glow?.destroy();
        }
    }
}
