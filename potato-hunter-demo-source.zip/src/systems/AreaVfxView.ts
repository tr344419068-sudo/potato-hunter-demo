import Phaser from 'phaser';
import { AssetManager } from '../managers/AssetManager';
import type { AuraProfile } from '../managers/SkillTypes';
import type { CombatVfxKind } from './CombatVfxModel';
import { AREA_MOTE_PERIOD_MS, AREA_WAVE_PERIOD_MS, getAreaGlowFrame, getAreaMoteFrame, getAreaWaveFrame, getAreaVfxSpec, MAX_AREA_LAYERS } from './AreaVfxModel';
import type { GameRuntime } from './SystemTypes';
interface Emission {
    visual: Phaser.GameObjects.Graphics;
    glow?: Phaser.GameObjects.Image;
    glowAlphaMultiplier: number;
    x: number;
    y: number;
    radius: number;
}
interface AreaLayer {
    kind: CombatVfxKind;
    waves: Emission[];
    motes: Emission[];
}
/** Hollow wavefronts expand around the current hero, matching aura damage. */
export class AreaVfxView {
    private readonly layers = new Map<string, AreaLayer>();
    private elapsedMs = 0;
    private reducedEffects = false;
    private destroyed = false;
    constructor(private readonly scene: Phaser.Scene) { }
    setReducedEffects(value: boolean): void { this.reducedEffects = value; }
    hasKind(kind: CombatVfxKind): boolean { return [...this.layers.values()].some(layer => layer.kind === kind); }
    update(deltaMs: number, runtime: GameRuntime): void {
        if (this.destroyed)
            return;
        const transform = runtime.world.components.transforms.get(runtime.playerId);
        const profiles = transform && runtime.skillManager?.getAuraProfiles
            ? runtime.skillManager.getAuraProfiles(runtime.world.components.players.get(runtime.playerId)?.level).filter(p => Number.isFinite(p.radius) && p.radius > 0).slice(0, MAX_AREA_LAYERS) : [];
        const ids = new Set(profiles.map(p => p.skillId));
        for (const [id, layer] of this.layers)
            if (!ids.has(id)) {
                this.release(layer);
                this.layers.delete(id);
            }
        if (!transform)
            return;
        this.elapsedMs += Number.isFinite(deltaMs) ? Math.max(0, deltaMs) : 0;
        for (const profile of profiles) {
            let layer = this.layers.get(profile.skillId);
            if (layer && layer.kind !== profile.vfxKind) {
                this.release(layer);
                this.layers.delete(profile.skillId);
                layer = undefined;
            }
            if (!layer) {
                const candidates = profile.vfxKind === 'poison' ? ['vfx_poison_halo_user_v1', 'vfx_halo_energy_v1']
                    : profile.vfxKind === 'ketchup' ? ['vfx_ketchup_halo_user_v1', 'vfx_halo_energy_v1'] : ['vfx_halo_energy_v1'];
                const glowAssetId = candidates.find(assetId => {
                    const candidateKey = AssetManager.getTextureKey(assetId);
                    const texture = this.scene.textures.exists(candidateKey) && typeof this.scene.textures.get === 'function' ? this.scene.textures.get(candidateKey) : undefined;
                    const frame = texture?.key === candidateKey && typeof texture.get === 'function' ? texture.get() : undefined;
                    return frame && Number.isFinite(frame.realWidth) && frame.realWidth > 0 && Number.isFinite(frame.realHeight) && frame.realHeight > 0;
                });
                const key = glowAssetId ? AssetManager.getTextureKey(glowAssetId) : '';
                const isKetchupArt = glowAssetId === 'vfx_ketchup_halo_user_v1';
                // Preserve user hues and highlights; normal blending keeps sauce
                // red on green grass rather than washing it into additive yellow.
                const glowTint = glowAssetId === 'vfx_poison_halo_user_v1' || isKetchupArt ? 0xffffff : getAreaVfxSpec(profile.vfxKind).primaryColor;
                const make = (wave = false): Emission => ({
                    visual: this.scene.add.graphics().setDepth(.68).setBlendMode(Phaser.BlendModes.NORMAL),
                    glow: wave && glowAssetId ? this.scene.add.image(transform.x, transform.y, key).setDepth(.69).setBlendMode(isKetchupArt ? Phaser.BlendModes.NORMAL : Phaser.BlendModes.ADD).setTint(glowTint) : undefined,
                    glowAlphaMultiplier: isKetchupArt ? .65 / .9 : 1,
                    x: transform.x, y: transform.y, radius: profile.radius,
                });
                layer = { kind: profile.vfxKind, waves: [make(true), make(true)], motes: Array.from({ length: 6 }, () => make()) };
                this.layers.set(profile.skillId, layer);
            }
            this.updateLayer(layer, profile, transform.x, transform.y);
        }
    }
    destroy(): void {
        if (this.destroyed) return;
        this.destroyed = true;
        for (const layer of this.layers.values()) this.release(layer);
        this.layers.clear();
    }
    private syncFrame(emission: Emission, time: number, period: number, x: number, y: number, radius: number): number {
        // Aura damage moves with the hero. Only phase is cyclic; origins and
        // upgraded radii must never wait for a new emission, including dashes.
        emission.x = x;
        emission.y = y;
        emission.radius = radius;
        return time % period;
    }
    private updateLayer(layer: AreaLayer, profile: AuraProfile, x: number, y: number): void {
        const colors = getAreaVfxSpec(layer.kind);
        for (const [index, wave] of layer.waves.entries()) {
            const age = this.syncFrame(wave, this.elapsedMs + index * 450, AREA_WAVE_PERIOD_MS, x, y, profile.radius);
            const frame = getAreaWaveFrame(wave.radius, age, this.reducedEffects);
            const g = wave.visual;
            g.clear();
            // Empty center; only thin outlines and disconnected glints carry energy.
            g.lineStyle(4.5, colors.primaryColor, .17).strokeCircle(0, 0, wave.radius);
            g.lineStyle(frame.lineWidth, colors.accentColor, .95).strokeCircle(0, 0, wave.radius);
            for (let arc = 0; arc < 3; arc++) {
                const start = arc * Math.PI * 2 / 3 + index * .7;
                g.lineStyle(3.8, colors.edgeColor, 1).beginPath().arc(0, 0, wave.radius * .982, start, start + .15).strokePath();
                // Broken, lightly undulating ribbons move with the wave phase.
                // They add a moving crest without painting over the ground or hero.
                g.lineStyle(2.2, colors.edgeColor, .94).beginPath();
                for (let point = 0; point <= 12; point++) {
                    const angle = start + .24 + point * .72 / 12;
                    const radius = wave.radius * (.91 + .035 * Math.sin(point * .8 + frame.rotation * 20 + arc));
                    const px = Math.cos(angle) * radius, py = Math.sin(angle) * radius;
                    if (point === 0) g.moveTo(px, py); else g.lineTo(px, py);
                }
                g.strokePath();
            }
            g.setPosition(wave.x, wave.y).setRotation(frame.rotation).setScale(frame.scale).setAlpha(frame.alpha).setVisible(!this.reducedEffects || index === 0);
            if (wave.glow) {
                const glowFrame = getAreaGlowFrame(wave.radius, age, this.reducedEffects);
                wave.glow.setPosition(wave.x, wave.y).setDisplaySize(glowFrame.displaySize, glowFrame.displaySize).setRotation(glowFrame.rotation).setAlpha(glowFrame.alpha * wave.glowAlphaMultiplier).setVisible(!this.reducedEffects && glowFrame.alpha > 0);
            }
        }
        for (const [index, mote] of layer.motes.entries()) {
            const age = this.syncFrame(mote, this.elapsedMs + index * 120, AREA_MOTE_PERIOD_MS, x, y, profile.radius);
            const frame = getAreaMoteFrame(mote.radius, age, index, this.reducedEffects), g = mote.visual;
            g.clear().fillStyle(colors.primaryColor, .12).fillCircle(0, 0, frame.size * .72);
            g.lineStyle(1.2, colors.accentColor, 1).lineBetween(-frame.size * .35, 0, frame.size * .35, 0);
            g.lineBetween(0, -frame.size * .2, 0, frame.size * .2);
            g.setPosition(mote.x + frame.x, mote.y + frame.y).setRotation(frame.rotation).setAlpha(frame.alpha).setVisible(frame.visible);
        }
    }
    private release(layer: AreaLayer): void {
        for (const emission of [...layer.waves, ...layer.motes]) {
            emission.visual.destroy();
            emission.glow?.destroy();
        }
    }
}
