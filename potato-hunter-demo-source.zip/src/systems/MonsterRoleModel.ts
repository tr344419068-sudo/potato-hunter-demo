import { DifficultyManager } from "../managers/DifficultyManager";
import type { GameRuntime } from "./SystemTypes";
import type { AoeWarningComponent } from "../components/ComponentTypes";

type ChargeWarningGeometry = Pick<AoeWarningComponent, "angle" | "length" | "width" | "contactPadding">;

export function getChargeWarningEnvelope(x: number, y: number, warning: ChargeWarningGeometry): { travelLength: number; points: Array<{ x: number; y: number }> } {
  const directionX = Math.cos(warning.angle ?? 0);
  const directionY = Math.sin(warning.angle ?? 0);
  const halfWidth = (warning.width ?? 40) / 2;
  const length = warning.length ?? 100;
  const padding = Math.max(0, warning.contactPadding ?? 0);
  const startX = x - directionX * padding;
  const startY = y - directionY * padding;
  const endX = x + directionX * (length + padding);
  const endY = y + directionY * (length + padding);
  return {
    travelLength: length,
    points: [
      { x: startX - directionY * halfWidth, y: startY + directionX * halfWidth },
      { x: endX - directionY * halfWidth, y: endY + directionX * halfWidth },
      { x: endX + directionY * halfWidth, y: endY - directionX * halfWidth },
      { x: startX + directionY * halfWidth, y: startY - directionX * halfWidth },
    ],
  };
}

export function isPointInChargeWarning(pointX: number, pointY: number, x: number, y: number, warning: ChargeWarningGeometry): boolean {
  const directionX = Math.cos(warning.angle ?? 0);
  const directionY = Math.sin(warning.angle ?? 0);
  const along = (pointX - x) * directionX + (pointY - y) * directionY;
  const across = (pointX - x) * -directionY + (pointY - y) * directionX;
  const padding = Math.max(0, warning.contactPadding ?? 0);
  return along >= -padding - 1e-6 && along <= (warning.length ?? 100) + padding + 1e-6 && Math.abs(across) <= (warning.width ?? 40) / 2 + 1e-6;
}

export function getSummonAllowance(runtime: GameRuntime, castCap: number): number {
  const wave = runtime.waveManager.getCurrentWave(runtime.stats.elapsedMs);
  const difficulty = new DifficultyManager().getState(runtime.stats.elapsedMs);
  return Math.max(0, Math.min(castCap, wave.maxAlive + difficulty.extraMaxAlive - runtime.world.components.monsters.size));
}

export function getRoleVelocity(behavior: string, directionX: number, directionY: number, distance: number, speed: number): { x: number; y: number } {
  if (behavior === "bombardier") {
    const advance = distance > 330 ? 1 : distance < 230 ? -0.7 : 0;
    return { x: directionX * speed * advance, y: directionY * speed * advance };
  }
  if (behavior === "flanker") {
    return { x: (directionX * 0.6 - directionY * 0.7) * speed, y: (directionY * 0.6 + directionX * 0.7) * speed };
  }
  return { x: directionX * speed, y: directionY * speed };
}
