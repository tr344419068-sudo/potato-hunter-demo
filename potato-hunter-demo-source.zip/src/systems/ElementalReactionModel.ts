import type { CombatVfxKind } from "./CombatVfxModel";

export type ElementalReactionKind = "toxic_ignition" | "superconduct" | "shatter" | "thermal_shock";
export type ReactionStatus = "burn" | "freeze" | "slow" | "poison";

export interface ElementalReactionProfile {
  kind: ElementalReactionKind;
  label: string;
  consumeStatus: ReactionStatus;
  bonusDamageMultiplier: number;
  splashDamageMultiplier: number;
  radius: number;
  maxSplashTargets: number;
  knockbackForce: number;
  primaryColor: number;
  secondaryColor: number;
}

const REACTIONS: Readonly<Record<ElementalReactionKind, Readonly<ElementalReactionProfile>>> = Object.freeze({
  toxic_ignition: Object.freeze({
    kind: "toxic_ignition",
    label: "剧毒点燃",
    consumeStatus: "poison",
    bonusDamageMultiplier: 0.6,
    splashDamageMultiplier: 0.35,
    radius: 100,
    maxSplashTargets: 8,
    knockbackForce: 160,
    primaryColor: 0xff9f1c,
    secondaryColor: 0x70e000,
  }),
  superconduct: Object.freeze({
    kind: "superconduct",
    label: "超导",
    consumeStatus: "freeze",
    bonusDamageMultiplier: 0.45,
    splashDamageMultiplier: 0.28,
    radius: 140,
    maxSplashTargets: 6,
    knockbackForce: 80,
    primaryColor: 0x69e8ff,
    secondaryColor: 0xffd166,
  }),
  shatter: Object.freeze({
    kind: "shatter",
    label: "碎冰",
    consumeStatus: "freeze",
    bonusDamageMultiplier: 0.75,
    splashDamageMultiplier: 0.2,
    radius: 80,
    maxSplashTargets: 4,
    knockbackForce: 260,
    primaryColor: 0xdff8eb,
    secondaryColor: 0x3a86ff,
  }),
  thermal_shock: Object.freeze({
    kind: "thermal_shock",
    label: "冷热冲击",
    consumeStatus: "burn",
    bonusDamageMultiplier: 0.55,
    splashDamageMultiplier: 0.3,
    radius: 100,
    maxSplashTargets: 6,
    knockbackForce: 180,
    primaryColor: 0x8ee8ff,
    secondaryColor: 0xe63946,
  }),
});

export function resolveElementalReaction(
  incomingKind: CombatVfxKind,
  statuses: readonly string[],
): Readonly<ElementalReactionProfile> | undefined {
  if ((incomingKind === "fire" || incomingKind === "explosion" || incomingKind === "ketchup") && statuses.includes("poison")) {
    return REACTIONS.toxic_ignition;
  }
  if (incomingKind === "lightning" && (statuses.includes("freeze") || statuses.includes("slow"))) {
    return statuses.includes("freeze")
      ? REACTIONS.superconduct
      : Object.freeze({ ...REACTIONS.superconduct, consumeStatus: "slow" as const });
  }
  if ((incomingKind === "peeler" || incomingKind === "kinetic") && statuses.includes("freeze")) {
    return REACTIONS.shatter;
  }
  if (incomingKind === "frost" && statuses.includes("burn")) {
    return REACTIONS.thermal_shock;
  }
  return undefined;
}
