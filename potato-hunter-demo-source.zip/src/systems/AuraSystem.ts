import { EventBus } from "../managers/EventBus";
import { distanceSquared, normalize } from "../utils/math";
import type { EntityId } from "../components/ComponentTypes";
import type { GameRuntime, System } from "./SystemTypes";
import { triggerElementalReaction } from "./ElementalReactionSystem";

export class AuraSystem implements System {
  private readonly tickTimers = new Map<string, number>();
  private readonly entries = new Map<string, Map<EntityId, { inside: boolean; readyAt: number }>>();
  private ownerWorld?: GameRuntime["world"];
  private ownerPlayer?: EntityId;
  private elapsedMs = 0;

  update(deltaMs: number, runtime: GameRuntime): void {
    if (this.ownerWorld !== runtime.world || this.ownerPlayer !== runtime.playerId) {
      this.tickTimers.clear();
      this.entries.clear();
      this.elapsedMs = 0;
      this.ownerWorld = runtime.world;
      this.ownerPlayer = runtime.playerId;
    }
    const safeDelta = Number.isFinite(deltaMs) ? Math.max(0, deltaMs) : 0;
    this.elapsedMs += safeDelta;
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    if (!playerTransform || (runtime.world.components.health.get(runtime.playerId)?.current ?? 1) <= 0) {
      this.tickTimers.clear();
      this.entries.clear();
      return;
    }

    const player = runtime.world.components.players.get(runtime.playerId);
    const profiles = runtime.skillManager.getAuraProfiles(player?.level);
    const activeIds = new Set(profiles.map(aura => aura.skillId));
    for (const id of this.tickTimers.keys()) if (!activeIds.has(id)) this.tickTimers.delete(id);
    for (const id of this.entries.keys()) if (!activeIds.has(id)) this.entries.delete(id);
    for (const aura of profiles) {
      const timer = (this.tickTimers.get(aura.skillId) ?? 0) - safeDelta;
      this.tickTimers.set(aura.skillId, timer);
      const tickDue = timer <= 0;
      let entries = this.entries.get(aura.skillId);
      if (!entries) { entries = new Map(); this.entries.set(aura.skillId, entries); }
      for (const id of entries.keys()) {
        if (!runtime.world.components.monsters.has(id) || !runtime.world.components.transforms.has(id)
          || (runtime.world.components.health.get(id)?.current ?? 0) <= 0) entries.delete(id);
      }

      const radiusSquared = aura.radius * aura.radius;
      const tickDamage = tickDue ? aura.damagePerSecond * (aura.tickMs / 1000) : 0;

      for (const entityId of runtime.world.components.monsters.keys()) {
        const transform = runtime.world.components.transforms.get(entityId);
        const health = runtime.world.components.health.get(entityId);
        if (!transform || !health || health.current <= 0) {
          continue;
        }

        if (distanceSquared(playerTransform.x, playerTransform.y, transform.x, transform.y) > radiusSquared) {
          const state = entries.get(entityId);
          if (state) {
            state.inside = false;
            if (state.readyAt <= this.elapsedMs) entries.delete(entityId);
          }
          continue;
        }

        let state = entries.get(entityId);
        if (!state) { state = { inside: false, readyAt: 0 }; entries.set(entityId, state); }
        const entered = !state.inside && state.readyAt <= this.elapsedMs && (aura.entryDamage ?? 0) > 0;
        state.inside = true;
        if (entered) state.readyAt = this.elapsedMs + 1500;
        const damage = tickDamage + (entered ? aura.entryDamage ?? 0 : 0);
        if (!tickDue && !entered) continue;

        const monster = runtime.world.components.monsters.get(entityId);
        const absorbed = Math.min(monster?.shieldHp ?? 0, damage);
        if (monster && absorbed > 0) monster.shieldHp = Math.max(0, (monster.shieldHp ?? 0) - absorbed);
        health.current -= damage - absorbed;
        const flashMs = entered ? 90 : 45;
        runtime.world.components.hitFlashes.set(entityId, { remainingMs: flashMs, totalMs: flashMs });
        triggerElementalReaction(runtime, entityId, aura.vfxKind, damage);
        if (entered && (aura.entryKnockback ?? 0) > 0 && !monster?.isBoss) {
          const direction = normalize(transform.x - playerTransform.x, transform.y - playerTransform.y);
          runtime.world.components.knockbacks.set(entityId, {
            x: direction.x * aura.entryKnockback!, y: direction.y * aura.entryKnockback!, remainingMs: 170,
          });
        }
        for (const effect of aura.effects) {
          if (effect.type === "burn" || effect.type === "freeze" || effect.type === "slow" || effect.type === "poison") {
            const currentStatuses = (runtime.world.components.statuses.get(entityId) ?? []).filter((status) => status.type !== effect.type);
            runtime.world.components.statuses.set(entityId, [
              ...currentStatuses,
              {
                type: effect.type,
                remainingMs: effect.durationMs,
                totalMs: effect.durationMs,
                damagePerSecond: "damagePerSecond" in effect ? effect.damagePerSecond : 0,
                slowMultiplier: "slowMultiplier" in effect ? effect.slowMultiplier : 1,
              },
            ]);
          }
        }
        if (absorbed > 0) {
          EventBus.emit("combat:damage", { x: transform.x, y: transform.y, value: absorbed, color: "#89cfff", targetId: entityId, category: "shield" });
        }
        if (damage > absorbed) {
          EventBus.emit("combat:damage", { x: transform.x, y: transform.y, value: damage - absorbed, color: entered ? (aura.vfxKind === "ketchup" ? "#ffe0a1" : "#d0ff9b") : "#9ad1d4", targetId: entityId, isDot: !entered, category: "outgoing" });
        }
      }

      if (!tickDue) continue;
      EventBus.emit("aura:pulse", {
        x: playerTransform.x,
        y: playerTransform.y,
        color: aura.color,
        radius: aura.radius,
        vfxKind: aura.vfxKind,
      });

      this.tickTimers.set(aura.skillId, aura.tickMs);
    }
  }
}
