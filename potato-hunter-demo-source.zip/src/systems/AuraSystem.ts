import { EventBus } from "../managers/EventBus";
import { absorbMonsterShield } from "./MonsterShield";
import { applyHealthDamage } from "./HealthDamage";
import { getAttackableMonsterIds } from "./BossDuelArena";
import { distanceSquared, normalize } from "../utils/math";
import type { EntityId } from "../components/ComponentTypes";
import type { GameRuntime, System } from "./SystemTypes";
import { triggerElementalReaction } from "./ElementalReactionSystem";
import { advanceExpandingAuraPulse, getExpandingAuraSamples, type PulseClock } from "./ExpandingAuraPulse";

type AuraContact = { inside: boolean; readyAt: number; pulseIndex?: number };
const FIELD_IGNITION_INTERVAL_MS = 900;
const FIELD_IGNITION_DAMAGE_CAP = 6;

export class AuraSystem implements System {
  private readonly tickTimers = new Map<string, number>();
  private readonly entries = new Map<string, Map<EntityId, AuraContact>>();
  private readonly pulseClocks = new Map<string, PulseClock>();
  private ketchupIgnitionReadyAt = 0;
  private ownerWorld?: GameRuntime["world"];
  private ownerPlayer?: EntityId;
  private elapsedMs = 0;

  update(deltaMs: number, runtime: GameRuntime): void {
    if (this.ownerWorld !== runtime.world || this.ownerPlayer !== runtime.playerId) {
      this.tickTimers.clear();
      this.entries.clear();
      this.pulseClocks.clear();
      this.ketchupIgnitionReadyAt = 0;
      this.elapsedMs = 0;
      this.ownerWorld = runtime.world;
      this.ownerPlayer = runtime.playerId;
    }
    const safeDelta = Number.isFinite(deltaMs) ? Math.max(0, deltaMs) : 0;
    this.elapsedMs += safeDelta;
    const pulses = getExpandingAuraSamples(runtime.world);
    pulses.clear();
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    if (!playerTransform || (runtime.world.components.health.get(runtime.playerId)?.current ?? 1) <= 0) {
      this.tickTimers.clear();
      this.entries.clear();
      this.pulseClocks.clear();
      this.ketchupIgnitionReadyAt = 0;
      return;
    }

    const player = runtime.world.components.players.get(runtime.playerId);
    const profiles = runtime.skillManager.getAuraProfiles(player?.level);
    const activeIds = new Set(profiles.map(aura => aura.skillId));
    for (const id of this.tickTimers.keys()) if (!activeIds.has(id)) this.tickTimers.delete(id);
    for (const id of this.entries.keys()) if (!activeIds.has(id)) this.entries.delete(id);
    for (const id of this.pulseClocks.keys()) if (!activeIds.has(id)) this.pulseClocks.delete(id);
    for (const aura of profiles) {
      const timer = (this.tickTimers.get(aura.skillId) ?? 0) - safeDelta;
      this.tickTimers.set(aura.skillId, timer);
      const pulse = advanceExpandingAuraPulse(aura, this.pulseClocks.get(aura.skillId), safeDelta);
      const wave = pulse?.sample;
      if (pulse) { this.pulseClocks.set(aura.skillId, pulse.clock); pulses.set(aura.skillId, pulse.sample); }
      const tickDue = !wave && timer <= 0;
      let entries = this.entries.get(aura.skillId);
      if (!entries) { entries = new Map(); this.entries.set(aura.skillId, entries); }
      for (const id of entries.keys()) {
        if (!runtime.world.components.monsters.has(id) || !runtime.world.components.transforms.has(id)
          || (runtime.world.components.health.get(id)?.current ?? 0) <= 0) entries.delete(id);
      }

      const radius = wave?.radius ?? aura.radius;
      const radiusSquared = radius * radius;
      const tickDamage = (tickDue || wave) ? aura.damagePerSecond * ((wave?.periodMs ?? aura.tickMs) / 1000) : 0;

      if (wave && !wave.sweeping) continue;

      for (const entityId of getAttackableMonsterIds(runtime.world)) {
        const transform = runtime.world.components.transforms.get(entityId);
        const health = runtime.world.components.health.get(entityId);
        if (!transform || !health || health.current <= 0) {
          continue;
        }

        if (distanceSquared(playerTransform.x, playerTransform.y, transform.x, transform.y) > radiusSquared) {
          const state = entries.get(entityId);
          if (state) {
            state.inside = false;
            if (!wave && state.readyAt <= this.elapsedMs) entries.delete(entityId);
          }
          continue;
        }

        let state = entries.get(entityId);
        if (!state) { state = { inside: false, readyAt: 0 }; entries.set(entityId, state); }
        const entered = wave ? state.pulseIndex !== wave.index : !state.inside && state.readyAt <= this.elapsedMs && (aura.entryDamage ?? 0) > 0;
        if (wave && !entered) continue;
        if (wave) state.pulseIndex = wave.index;
        state.inside = true;
        if (entered) state.readyAt = this.elapsedMs + 1500;
        const damage = tickDamage + (entered ? aura.entryDamage ?? 0 : 0);
        if (!tickDue && !entered) continue;

        const monster = runtime.world.components.monsters.get(entityId);
        const absorbed = absorbMonsterShield(monster, transform, damage);
        const dealt = applyHealthDamage(health, damage - absorbed);
        const flashMs = entered ? 90 : 45;
        runtime.world.components.hitFlashes.set(entityId, { remainingMs: flashMs, totalMs: flashMs });
        // Two passive fields may still ignite, but each ignition already splashes
        // the pack. Only the ketchup fields share this limit; aimed attacks do not.
        const isKetchup = aura.vfxKind === "ketchup";
        if (!isKetchup || this.ketchupIgnitionReadyAt <= this.elapsedMs) {
          const reaction = triggerElementalReaction(runtime, entityId, aura.vfxKind, isKetchup ? Math.min(damage, FIELD_IGNITION_DAMAGE_CAP) : damage);
          if (isKetchup && reaction?.kind === "toxic_ignition") this.ketchupIgnitionReadyAt = this.elapsedMs + FIELD_IGNITION_INTERVAL_MS;
        }
        if (entered && (aura.entryKnockback ?? 0) > 0 && !monster?.isBoss) {
          const direction = normalize(transform.x - playerTransform.x, transform.y - playerTransform.y);
          runtime.world.components.knockbacks.set(entityId, {
            x: direction.x * aura.entryKnockback!, y: direction.y * aura.entryKnockback!, remainingMs: 170,
          });
        }
        for (const effect of aura.effects) {
          if (effect.type === "burn" || effect.type === "freeze" || effect.type === "slow" || effect.type === "poison") {
            const currentStatuses = (runtime.world.components.statuses.get(entityId) ?? []).filter((status) => status.type !== effect.type);
            runtime.world.components.statuses.set(entityId, [
              ...currentStatuses,
              {
                type: effect.type,
                remainingMs: effect.durationMs,
                totalMs: effect.durationMs,
                damagePerSecond: "damagePerSecond" in effect ? effect.damagePerSecond : 0,
                slowMultiplier: "slowMultiplier" in effect ? effect.slowMultiplier : 1,
              },
            ]);
          }
        }
        if (absorbed > 0) {
          EventBus.emit("combat:damage", { x: transform.x, y: transform.y, value: absorbed, color: "#89cfff", targetId: entityId, category: "shield" });
        }
        if (dealt > 0) {
          EventBus.emit("combat:damage", { x: transform.x, y: transform.y, value: dealt, color: entered ? (aura.vfxKind === "ketchup" ? "#ffe0a1" : "#d0ff9b") : "#9ad1d4", targetId: entityId, isDot: !entered, category: "outgoing" });
        }
      }

      if (!tickDue) continue;
      EventBus.emit("aura:pulse", {
        x: playerTransform.x,
        y: playerTransform.y,
        color: aura.color,
        radius: aura.radius,
        vfxKind: aura.vfxKind,
      });

      this.tickTimers.set(aura.skillId, aura.tickMs);
    }
  }
}
