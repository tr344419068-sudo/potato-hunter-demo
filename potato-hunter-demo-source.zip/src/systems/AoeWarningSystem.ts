import { EventBus } from "../managers/EventBus";
import { distanceSquared } from "../utils/math";
import type { EntityId } from "../components/ComponentTypes";
import { canReceiveHostileDamage, getHostileHitGraceMs } from "./PlayerDamageModel";
import type { GameRuntime, System } from "./SystemTypes";

export class AoeWarningSystem implements System {
  readonly telemetrySource = "AoeWarningSystem";
  update(deltaMs: number, runtime: GameRuntime): void {
    const expired: EntityId[] = [];
    const elapsedMs = Math.max(0, deltaMs);

    for (const [entityId, warning] of runtime.world.components.aoeWarnings) {
      const transform = runtime.world.components.transforms.get(entityId);
      const sourceAlive = warning.sourceId === undefined || (runtime.world.components.monsters.has(warning.sourceId) && (runtime.world.components.health.get(warning.sourceId)?.current ?? 0) > 0);
      if (!transform || !sourceAlive) {
        expired.push(entityId);
        continue;
      }

      if (warning.skipNextTick) { warning.skipNextTick = false; continue; }
      if (warning.triggered && warning.zone) {
        const zone = warning.zone;
        zone.remainingMs = Math.max(0, zone.remainingMs - elapsedMs);
        if (zone.remainingMs <= 0) {
          expired.push(entityId);
          continue;
        }
        zone.tickRemainingMs = Math.max(0, zone.tickRemainingMs - elapsedMs);
        if (zone.tickRemainingMs <= 0 && zone.ticksRemaining > 0) {
          zone.ticksRemaining -= 1;
          zone.tickRemainingMs = zone.tickIntervalMs;
          this.damagePlayer(runtime, entityId, zone.tickDamage);
        }
        continue;
      }
      warning.remainingMs = Math.max(0, warning.remainingMs - elapsedMs);
      if (warning.remainingMs > 0 || warning.armed === false) {
        continue;
      }

      if (!warning.triggered) {
        if (warning.zone) warning.color = warning.zone.color;
        if (warning.damage > 0) {
          EventBus.emit("fx:sparks", { x: transform.x, y: transform.y, color: warning.color ?? 0xff4800, count: 26, size: 10 });
          this.damagePlayer(runtime, entityId, warning.damage);
        }
        warning.triggered = true;
        if (warning.zone) continue;
      }

      expired.push(entityId);
    }

    for (const entityId of expired) {
      runtime.world.destroyEntity(entityId);
    }
  }

  private damagePlayer(runtime: GameRuntime, warningId: EntityId, damage: number): void {
    const warning = runtime.world.components.aoeWarnings.get(warningId)!;
    const transform = runtime.world.components.transforms.get(warningId)!;
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    const player = runtime.world.components.players.get(runtime.playerId);
    const playerDistance = playerTransform ? distanceSquared(transform.x, transform.y, playerTransform.x, playerTransform.y) : Number.POSITIVE_INFINITY;
    const inOuterAoe = playerDistance <= transform.radius * transform.radius;
    const inSafeZone = warning.safeRadius !== undefined && playerDistance <= warning.safeRadius * warning.safeRadius;
    if (playerTransform && playerHealth && player && inOuterAoe && !inSafeZone && canReceiveHostileDamage(player)) {
      playerHealth.current -= damage;
      player.damageCooldownMs = getHostileHitGraceMs("aoe");
      const color = warning.color === undefined ? "#ff4800" : `#${warning.color.toString(16).padStart(6, "0")}`;
      EventBus.emit("combat:damage", { x: playerTransform.x, y: playerTransform.y, value: damage, color, isCrit: true, targetId: runtime.playerId, category: "incoming" });
    }
  }
}
