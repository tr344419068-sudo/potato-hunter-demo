import { EventBus } from "../managers/EventBus";
import { distanceSquared } from "../utils/math";
import type { EntityId } from "../components/ComponentTypes";
import { canReceiveHostileDamage, getHostileHitGraceMs } from "./PlayerDamageModel";
import type { GameRuntime, System } from "./SystemTypes";
import type { HostileStrike } from "./HostileStrikePresentation";

export class AoeWarningSystem implements System {
  readonly telemetrySource = "AoeWarningSystem";
  update(deltaMs: number, runtime: GameRuntime): void {
    const expired: EntityId[] = [];
    const elapsedMs = Math.max(0, deltaMs);

    for (const [entityId, warning] of runtime.world.components.aoeWarnings) {
      const transform = runtime.world.components.transforms.get(entityId);
      const sourceAlive = warning.sourceId === undefined || (runtime.world.components.monsters.has(warning.sourceId) && (runtime.world.components.health.get(warning.sourceId)?.current ?? 0) > 0);
      if (!transform || !sourceAlive) {
        expired.push(entityId);
        continue;
      }

      const consumed = warning.consumeSource ? warning.sourceId : undefined;
      const source = consumed === undefined ? undefined : runtime.world.components.transforms.get(consumed);
      if (source) { transform.x = source.x; transform.y = source.y; }
      if (warning.skipNextTick) { warning.skipNextTick = false; continue; }
      if (warning.triggered && warning.zone) {
        const zone = warning.zone;
        zone.remainingMs = Math.max(0, zone.remainingMs - elapsedMs);
        if (zone.remainingMs <= 0) {
          expired.push(entityId);
          continue;
        }
        zone.tickRemainingMs = Math.max(0, zone.tickRemainingMs - elapsedMs);
        if (zone.tickRemainingMs <= 0 && zone.ticksRemaining > 0) {
          zone.ticksRemaining -= 1;
          zone.tickRemainingMs = zone.tickIntervalMs;
          this.damagePlayer(runtime, entityId, zone.tickDamage);
        }
        continue;
      }
      warning.remainingMs = Math.max(0, warning.remainingMs - elapsedMs);
      if (warning.remainingMs > 0 || warning.armed === false) {
        continue;
      }

      if (!warning.triggered) {
        if (warning.zone) warning.color = warning.zone.color;
        if (warning.damage > 0) {
          if (warning.impactStyle) EventBus.emit("hostile:impact", { x: transform.x, y: transform.y, radius: transform.radius, safeRadius: warning.safeRadius, style: warning.impactStyle, art: warning.impactArt,
            ...(warning.bossPhase === undefined ? {} : { bossPhase: warning.bossPhase, bossFinisher: warning.bossFinisher }) } satisfies HostileStrike);
          else EventBus.emit("fx:sparks", { x: transform.x, y: transform.y, color: warning.color ?? 0xff4800, count: 26, size: 10 });
          this.damagePlayer(runtime, entityId, warning.damage);
        }
        if (consumed !== undefined) {
          const render = runtime.world.components.renders.get(consumed);
          if (render && source) EventBus.emit("juice:death", { x: source.x, y: source.y, render: { ...render } });
          runtime.world.destroyEntity(consumed);
        }
        warning.triggered = true;
        if (warning.zone) continue;
      }

      expired.push(entityId);
    }

    for (const entityId of expired) {
      runtime.world.destroyEntity(entityId);
    }
  }

  private damagePlayer(runtime: GameRuntime, warningId: EntityId, damage: number): void {
    const warning = runtime.world.components.aoeWarnings.get(warningId)!;
    const transform = runtime.world.components.transforms.get(warningId)!;
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    const player = runtime.world.components.players.get(runtime.playerId);
    let nearestX = transform.x, nearestY = transform.y;
    if (playerTransform && warning.shape === "capsule") {
      const dx = Math.cos(warning.angle ?? 0), dy = Math.sin(warning.angle ?? 0);
      const half = (warning.length ?? 0) / 2;
      const along = (playerTransform.x - nearestX) * dx + (playerTransform.y - nearestY) * dy;
      const offset = Math.max(-half, Math.min(half, along));
      nearestX += dx * offset; nearestY += dy * offset;
    }
    const playerDistance = playerTransform ? distanceSquared(nearestX, nearestY, playerTransform.x, playerTransform.y) : Number.POSITIVE_INFINITY;
    const inOuterAoe = playerDistance <= transform.radius * transform.radius;
    const inSafeZone = warning.safeRadius !== undefined && playerDistance <= warning.safeRadius * warning.safeRadius;
    if (playerTransform && playerHealth && player && inOuterAoe && !inSafeZone && canReceiveHostileDamage(player)) {
      playerHealth.current -= damage;
      player.damageCooldownMs = getHostileHitGraceMs("aoe");
      const color = warning.color === undefined ? "#ff4800" : `#${warning.color.toString(16).padStart(6, "0")}`;
      EventBus.emit("combat:damage", { x: playerTransform.x, y: playerTransform.y, value: damage, color, isCrit: true, targetId: runtime.playerId, category: "incoming" });
    }
  }
}
