export type HeroAction = "idle" | "run" | "attack" | "dash" | "hit" | "death";
export const HERO_ATTACK_CONTACT = .52;
export const HERO_ACTIONS = {
  idle: { durationMs: 1600, frames: 12, loop: true },
  run: { durationMs: 620, frames: 16, loop: true },
  attack: { durationMs: 230, frames: 12, loop: false },
  dash: { durationMs: 190, frames: 8, loop: false },
  hit: { durationMs: 190, frames: 8, loop: false },
  death: { durationMs: 520, frames: 12, loop: false },
} as const;
interface Point { x: number; y: number }
export const HERO_RIG = {
  right_thigh: { joint: {x:174,y:198}, end:{x:182,y:219} },
  right_boot: { joint: {x:182,y:219}, end:{x:185,y:241} },
  left_thigh: { joint: {x:110,y:195}, end:{x:103,y:218} },
  left_boot: { joint: {x:103,y:218}, end:{x:100,y:241} },
  body: { joint: {x:145,y:196}, end:{x:145,y:85} },
  right_arm: { joint: {x:201,y:139}, end:{x:229,y:184} },
  left_arm: { joint: {x:92,y:123}, end:{x:70,y:141} },
} as const;
export type HeroPart = keyof typeof HERO_RIG;
export interface HeroPartPose { id: HeroPart; x:number; y:number; rotation:number; scaleX:number; scaleY:number; alpha:number }
export interface HeroPoseInput { action: HeroAction; timeMs:number; phase:number; moving:boolean; attack:number; feet?:Partial<Record<'left_boot'|'right_boot',Point>>; hipDrop?:number; releaseContact?:number; releaseRecoil?:number }
const clamp = (v:number,min:number,max:number) => Math.max(min,Math.min(max,v));
const finite = (v:number) => Number.isFinite(v) ? v : 0;
function turn(p:Point, joint:Point, angle:number): Point { const x=p.x-joint.x,y=p.y-joint.y;return {x:joint.x+x*Math.cos(angle)-y*Math.sin(angle),y:joint.y+x*Math.sin(angle)+y*Math.cos(angle)}; }
function keyCurve(t:number, keys: readonly [number,number][]):number {
  for(let i=1;i<keys.length;i++)if(t<=keys[i][0]) {const a=keys[i-1],b=keys[i];const u=clamp((t-a[0])/(b[0]-a[0]),0,1),s=u*u*(3-2*u);return a[1]+(b[1]-a[1])*s;}
  return keys[keys.length-1][1];
}
/** Two-bone IK: stance heel remains on the ground; swing foot bends at the knee. */
function leg(upper:HeroPart,lower:HeroPart,phase:number,moving:boolean,footTarget?:Point,hipDrop=0):HeroPartPose[] {
  const thigh=HERO_RIG[upper],boot=HERO_RIG[lower],h={x:thigh.joint.x,y:thigh.joint.y+hipDrop},k={x:boot.joint.x,y:boot.joint.y+hipDrop},f={x:boot.end.x,y:boot.end.y+hipDrop};
  const target=footTarget?{x:finite(footTarget.x),y:finite(footTarget.y)}:{x:f.x+(moving?Math.sin(phase)*7:0),y:f.y-(moving?Math.max(0,Math.cos(phase))*8:0)};
  const l1=Math.hypot(k.x-h.x,k.y-h.y),l2=Math.hypot(f.x-k.x,f.y-k.y);
  const d=clamp(Math.hypot(target.x-h.x,target.y-h.y),Math.abs(l1-l2)+.01,l1+l2-.005);
  const base=Math.atan2(target.y-h.y,target.x-h.x), bend=Math.acos(clamp((l1*l1+d*d-l2*l2)/(2*l1*d),-1,1));
  // Preserve the source's outward knees on the resting pose.
  const sign=upper==='left_thigh'?1:-1;
  const upperAngle=base+sign*bend;
  let knee={x:h.x+Math.cos(upperAngle)*l1,y:h.y+Math.sin(upperAngle)*l1};
  const foot={x:h.x+Math.cos(base)*d,y:h.y+Math.sin(base)*d};
  const cuff={x:k.x-h.x,y:k.y-h.y},sole={x:f.x-k.x,y:f.y-k.y};
  let rotation=upperAngle-Math.atan2(cuff.y,cuff.x),scaleX=1,scaleY=1;
  const soleAngle=Math.atan2(foot.y-knee.y,foot.x-knee.x)-Math.atan2(sole.y,sole.x);
  const lowerRotation=clamp(soleAngle,-.6,.6);
  if(lowerRotation!==soleAngle){
    // Keep the painted sole readable without shifting the IK heel off the
    // planted point. Re-fit just the leather cuff to the adjusted ankle.
    const offset=turn(sole,{x:0,y:0},lowerRotation);
    knee={x:foot.x-offset.x,y:foot.y-offset.y};
    const dx=knee.x-h.x,dy=knee.y-h.y,distance=Math.hypot(dx,dy);
    if(distance<=Math.abs(cuff.x))scaleX=scaleY=distance/l1;
    else scaleY=Math.sqrt(distance*distance-cuff.x*cuff.x)/cuff.y;
    rotation=Math.atan2(dy,dx)-Math.atan2(cuff.y*scaleY,cuff.x*scaleX);
  }
  return [{id:upper,x:h.x,y:h.y,rotation,scaleX,scaleY,alpha:1},{id:lower,x:knee.x,y:knee.y,rotation:lowerRotation,scaleX:1,scaleY:1,alpha:1}];
}
export function getAuthoredHeroPose(input:HeroPoseInput):HeroPartPose[] {
  const phase=finite(input.phase),t=Math.max(0,finite(input.timeMs));
  const moving=input.moving && input.action!=='death';
  const hipDrop=clamp(finite(input.hipDrop??0),0,12);
  const poses=[...leg('right_thigh','right_boot',phase+Math.PI,moving,input.feet?.right_boot,hipDrop),...leg('left_thigh','left_boot',phase,moving,input.feet?.left_boot,hipDrop)];
  const root=HERO_RIG.body.joint;
  let bodyRotation=moving?Math.sin(phase)*.012:Math.sin(t/1600*Math.PI*2)*.003;
  let bodyY=hipDrop+(moving?0:Math.sin(t/1600*Math.PI*2)*.45);
  let armAttack=0,alpha=1;
  if(input.action==='attack')armAttack=keyCurve(clamp(finite(input.attack),0,1),[[0,0],[.25,-.24],[.52,.32],[.7,.17],[1,0]]);
  if(input.action==='dash'){bodyRotation=-.1;armAttack=-.16;}
  if(input.action==='hit'){const p=clamp(t/HERO_ACTIONS.hit.durationMs,0,1);bodyRotation=Math.sin(p*Math.PI)*.07;armAttack=-Math.sin(p*Math.PI)*.09;}
  if(input.action==='death'){const p=clamp(t/HERO_ACTIONS.death.durationMs,0,1);bodyRotation=keyCurve(p,[[0,0],[.2,-.08],[.65,.72],[1,1.12]]);bodyY=p*10;alpha=1-p*.48;}
  const releaseContact=input.action==='death'?0:clamp(finite(input.releaseContact??0),0,1);
  armAttack=armAttack*(1-releaseContact)+(.32+clamp(finite(input.releaseRecoil??0),-.016,.016))*releaseContact;
  poses.push({id:'body',x:root.x,y:root.y+bodyY,rotation:bodyRotation,scaleX:1,scaleY:1,alpha});
  for(const id of ['right_arm','left_arm'] as const) {
    const joint=turn(HERO_RIG[id].joint,root,bodyRotation);
    poses.push({id,x:joint.x,y:joint.y+bodyY,rotation:bodyRotation+(id==='left_arm'?armAttack+ (moving?Math.sin(phase)*.08*(1-releaseContact):0):(moving?-Math.sin(phase)*.14:Math.sin(t/1600*Math.PI*2)*.01)),scaleX:1,scaleY:1,alpha});
  }
  if(input.action==='death')for(const p of poses.slice(0,4)){const at=turn({x:p.x,y:p.y},root,bodyRotation);p.x=at.x;p.y=at.y+bodyY;p.rotation+=bodyRotation;p.alpha=alpha;}
  return poses;
}
