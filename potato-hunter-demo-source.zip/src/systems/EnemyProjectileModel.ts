import { EventBus } from "../managers/EventBus";

// The bitmap head is centered on the unchanged 7-unit collision radius.
// The trailing glow is presentation only and does not participate in hits.
export const ENEMY_PROJECTILE_ART = {
  cola:   { assetId: "projectile_hostile_cola",   color: 0xff9f59 },
  ember:  { assetId: "projectile_hostile_ember",  color: 0xff704b },
  cactus: { assetId: "projectile_hostile_cactus", color: 0x80f9cd },
  sniper: { assetId: "projectile_hostile_sniper", color: 0xffd971 },
  oil:    { assetId: "projectile_hostile_oil",    color: 0xffb347 },
  sauce:  { assetId: "projectile_hostile_sauce",  color: 0xffe4a1 },
  sand:   { assetId: "projectile_hostile_sand",   color: 0x7ee8ed },
} as const;

export type EnemyProjectileStyle = keyof typeof ENEMY_PROJECTILE_ART;

export interface EnemyProjectileAccent {
  x: number;
  y: number;
  angle: number;
  color: number;
  phase: "muzzle" | "impact";
}

export function emitEnemyProjectileAccent(x: number, y: number, angle: number, color: number, phase: EnemyProjectileAccent["phase"]): void {
  EventBus.emit("hostile:shot-fx", { x, y, angle, color, phase } satisfies EnemyProjectileAccent);
}

export function emitEnemyMuzzle(x: number, y: number, angle: number, style: EnemyProjectileStyle): void {
  emitEnemyProjectileAccent(x + Math.cos(angle) * 14, y + Math.sin(angle) * 14, angle, ENEMY_PROJECTILE_ART[style].color, "muzzle");
}
