import type { EntityId, MonsterComponent, TransformComponent, VelocityComponent } from '../components/ComponentTypes';
import { createEnemyProjectile } from '../entities/factories';
import type { World } from '../entities/World';
import { EventBus } from '../managers/EventBus';
import { sweepTime } from '../utils/math';
import { getBossDuel } from './BossDuelArena';
import { emitEnemyProjectileAccent } from './EnemyProjectileModel';
import { HOSTILE_PROJECTILE_CAP } from './HostileHazardBudget';
import { breakIceCover, markIceBlockableProjectile, sweepIceCover, updateIceTerrain } from './IceTerrain';
import { canReceiveHostileDamage, getHostileHitGraceMs } from './PlayerDamageModel';
import type { GameRuntime, System } from './SystemTypes';

const ROLLER_SPEED = 484;
const ROLLER_MS = 520;
const NEEDLE_SPEED = 395;
const NEEDLE_LIFETIME_MS = 1080;
const NEEDLE_COLOR = 0x9bf1ff;
const MAX_SNOW_TELLS = 4;

export const SNOW_GUARD_ANGLE = Math.PI / 3;
export const SNOW_ROLL_RANGE = ROLLER_SPEED * ROLLER_MS / 1000;
export const SNOW_ELITE_ROLL_RANGE = SNOW_ROLL_RANGE * 1.22;
export const SNOW_NEEDLE_RANGE = NEEDLE_SPEED * NEEDLE_LIFETIME_MS / 1000;
export const SNOW_NEEDLE_ASSET = 'projectile_snow_needle';

type SnowRole = 'guard' | 'needle' | 'roller' | 'elite';
type Phase = 'ready' | 'guard' | 'tell' | 'roll' | 'stagger' | 'recover';
export type SnowState = {
  readonly role: SnowRole;
  phase: Phase;
  remainingMs: number;
  durationMs: number;
  angle: number;
  hit: boolean;
  guardHp: number;
  appliedGuardHp: number;
  baseShieldHp: number;
  wantsCharge: boolean;
};

const roles = new WeakMap<World, Map<EntityId, SnowState>>();
const noRoles: ReadonlyMap<EntityId, SnowState> = new Map();

export function getSnowEnemies(world: World): ReadonlyMap<EntityId, SnowState> { return roles.get(world) ?? noRoles; }

function getRole(id: string): SnowRole | undefined {
  switch (id) {
    case 'snow_guard': return 'guard';
    case 'snow_needle': return 'needle';
    case 'snow_roller': return 'roller';
    case 'snow_elite': return 'elite';
    default: return undefined;
  }
}

function enter(state: SnowState, phase: Phase, ms: number): void {
  state.phase = phase;
  state.remainingMs = state.durationMs = ms;
}

/** Keeps the ordinary contact system from duplicating the roll hit inside its locked lane. */
export function ownsSnowEnemyContact(world: World, id: EntityId): boolean {
  const state = roles.get(world)?.get(id);
  return Boolean(state && (state.role === 'roller' || state.role === 'elite') && state.phase !== 'ready');
}

function syncGuardShield(monster: MonsterComponent, state: SnowState, front: boolean): void {
  // Ordinary elite shields sit underneath this directional layer and persist after it lowers.
  const total = monster.shieldHp ?? 0;
  const spent = Math.max(0, state.baseShieldHp + state.appliedGuardHp - total);
  const guarded = Math.min(state.appliedGuardHp, spent);
  state.guardHp = Math.max(0, state.guardHp - guarded);
  state.baseShieldHp = Math.max(0, total - state.appliedGuardHp + guarded);
  state.appliedGuardHp = front ? state.guardHp : 0;
  monster.shieldHp = state.baseShieldHp + state.appliedGuardHp;
}

export function clearSnowEnemies(world: World): void {
  const states = roles.get(world);
  if (!states) return;
  for (const [id, state] of states) {
    const monster = world.components.monsters.get(id);
    if (!monster) continue;
    if (state.phase === 'guard') syncGuardShield(monster, state, false);
    if (state.phase !== 'ready') monster.controlledMotion = false;
  }
  roles.delete(world);
}

function stop(velocity: VelocityComponent): void { velocity.x = velocity.y = 0; }

/** Run after generic AI/behavior and before MovementSystem. No player velocity or status is changed. */
export class SnowEnemySystem implements System {
  readonly telemetrySource = 'SnowEnemySystem';

  update(deltaMs: number, runtime: GameRuntime): void {
    const { world, playerId } = runtime;
    let states = roles.get(world);
    const hero = world.components.transforms.get(playerId);
    updateIceTerrain(deltaMs, world, hero);
    const heroHealth = world.components.health.get(playerId);
    if (!hero || !heroHealth || heroHealth.current <= 0 || getBossDuel(world)) {
      clearSnowEnemies(world);
      return;
    }

    let activeTells = 0;
    if (states) for (const [id, state] of states) {
      if (!world.components.monsters.has(id) || (world.components.health.get(id)?.current ?? 0) <= 0) states.delete(id);
      else if (state.phase === 'tell') activeTells++;
    }

    for (const [id, monster] of world.components.monsters) {
      if (monster.isBoss && monster.bossKind !== 'intermediate') continue;
      const role = getRole(monster.monsterId);
      if (!role) continue;
      const transform = world.components.transforms.get(id);
      const velocity = world.components.velocities.get(id);
      const health = world.components.health.get(id);
      if (!transform || !velocity || !health || health.current <= 0) continue;
      if (!states) { states = new Map(); roles.set(world, states); }
      let state = states.get(id);
      if (!state) {
        state = { role, phase: 'ready', remainingMs: 980 + (id % 5) * 90, durationMs: 1, angle: 0, hit: false, guardHp: 0, appliedGuardHp: 0, baseShieldHp: 0, wantsCharge: false };
        states.set(id, state);
      }

      const dx = hero.x - transform.x, dy = hero.y - transform.y;
      const distance = Math.hypot(dx, dy), angle = Math.atan2(dy, dx);
      const previousRemaining = state.remainingMs;
      state.remainingMs = Math.max(0, previousRemaining - deltaMs);
      if (state.phase === 'ready') {
        if (role === 'needle') {
          // Keep the firing volley at range. Leave chase and any debuff scaling to generic AI.
          if (distance >= 225 && distance <= 345) stop(velocity);
          else if (distance < 225) { velocity.x *= -.66; velocity.y *= -.66; }
        }
        const rolling = role === 'roller' || (role === 'elite' && state.wantsCharge);
        const range = role === 'needle' ? 370 : rolling ? (role === 'elite' ? 286 : 232) : 170;
        if (distance > range || state.remainingMs > 0) continue;
        if (role === 'guard' || (role === 'elite' && !rolling)) {
          enter(state, 'guard', role === 'elite' ? 1130 : 900);
          if (role === 'elite') state.wantsCharge = true;
          state.guardHp = Math.ceil(health.max * (role === 'elite' ? .43 : .34));
          state.baseShieldHp = monster.shieldHp ?? 0;
          syncGuardShield(monster, state, true);
        } else {
          if (activeTells >= MAX_SNOW_TELLS) continue;
          enter(state, 'tell', role === 'elite' ? 680 : rolling ? 720 : 610);
          if (role === 'elite') state.wantsCharge = false;
          activeTells++;
        }
        state.angle = angle;
        state.hit = false;
        monster.controlledMotion = true;
        stop(velocity);
        continue;
      }
      stop(velocity);

      if (state.phase === 'guard') {
        if (state.remainingMs <= 0) {
          syncGuardShield(monster, state, false);
          enter(state, 'recover', role === 'elite' ? 390 : 520);
        } else {
          syncGuardShield(monster, state, Math.cos(angle - state.angle) >= Math.cos(SNOW_GUARD_ANGLE));
        }
      } else if (state.phase === 'tell' && state.remainingMs <= 0) {
        activeTells--;
        if (role === 'roller' || role === 'elite') {
          enter(state, 'roll', ROLLER_MS);
          EventBus.emit('hostile:lunge', { x: transform.x, y: transform.y, angle: state.angle });
        } else {
          this.releaseNeedle(world, transform, monster.damage, state.angle);
          enter(state, 'recover', 390);
        }
      } else if (state.phase === 'roll') {
        this.advanceRoll(runtime, state, transform, hero, monster.damage, Math.min(deltaMs, previousRemaining), deltaMs);
        if (state.phase === 'roll' && state.remainingMs <= 0) enter(state, 'recover', 400);
      } else if ((state.phase === 'recover' || state.phase === 'stagger') && state.remainingMs <= 0) {
        enter(state, 'ready', role === 'guard' || role === 'elite' ? 1500 : 2300);
        monster.controlledMotion = false;
      }
    }
  }

  private releaseNeedle(world: World, transform: TransformComponent, damage: number, angle: number): void {
    if (world.components.enemyProjectiles.size >= HOSTILE_PROJECTILE_CAP) return;
    const x = Math.cos(angle), y = Math.sin(angle);
    const shot = createEnemyProjectile(world, transform.x, transform.y, x * NEEDLE_SPEED, y * NEEDLE_SPEED, damage, NEEDLE_LIFETIME_MS);
    Object.assign(world.components.renders.get(shot)!, { assetId: SNOW_NEEDLE_ASSET, color: NEEDLE_COLOR });
    markIceBlockableProjectile(world, shot);
    emitEnemyProjectileAccent(transform.x + x * 16, transform.y + y * 16, angle, NEEDLE_COLOR, 'muzzle');
  }

  private advanceRoll(runtime: GameRuntime, state: SnowState, actor: TransformComponent, hero: TransformComponent, damage: number, ms: number, deltaMs: number): void {
    const { world, playerId } = runtime;
    const distance = ROLLER_SPEED * (state.role === 'elite' ? 1.22 : 1) * ms / 1000;
    const dx = Math.cos(state.angle) * distance, dy = Math.sin(state.angle) * distance;
    const end = { x: actor.x + dx, y: actor.y + dy };
    const ice = sweepIceCover(world, actor, end, actor.radius);
    const heroStep = world.components.velocities.get(playerId);
    if (!state.hit) {
      const relativeEnd = { x: end.x - (heroStep?.x ?? 0) * ms / 1000, y: end.y - (heroStep?.y ?? 0) * ms / 1000 };
      const at = sweepTime(actor, relativeEnd, hero, actor.radius + hero.radius);
      if (at !== undefined && (!ice || at < ice.time)) {
        state.hit = true;
        const player = world.components.players.get(playerId), health = world.components.health.get(playerId);
        const prior = runtime.hostileProtectionAtStepStart;
        if (player && health) {
          const dash = prior && player.dashRemainingMs <= Math.max(0, prior.dashRemainingMs - deltaMs) ? prior.dashRemainingMs - at * ms : player.dashRemainingMs;
          const grace = prior && player.damageCooldownMs <= Math.max(0, prior.damageCooldownMs - deltaMs) ? prior.damageCooldownMs - at * ms : player.damageCooldownMs;
          if (canReceiveHostileDamage({ dashRemainingMs: dash, damageCooldownMs: grace })) {
            health.current -= damage;
            player.damageCooldownMs = getHostileHitGraceMs('contact');
            EventBus.emit('combat:damage', { x: hero.x, y: hero.y, value: damage, color: '#ff9292', targetId: playerId, category: 'incoming' });
          }
        }
      }
    }
    actor.x += dx * (ice?.time ?? 1);
    actor.y += dy * (ice?.time ?? 1);
    if (ice) {
      breakIceCover(world, ice.cover.id);
      enter(state, 'stagger', 1150);
    }
  }
}
