import type { EntityId } from "../components/ComponentTypes";
import type { GameRuntime, System } from "./SystemTypes";

export class KnockbackSystem implements System {
  update(deltaMs: number, runtime: GameRuntime): void {
    const expired: EntityId[] = [];
    const deltaSeconds = deltaMs / 1000;

    for (const [entityId, knockback] of runtime.world.components.knockbacks) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform) {
        expired.push(entityId);
        continue;
      }
      if (runtime.world.components.monsters.get(entityId)?.controlledMotion) {
        expired.push(entityId);
        continue;
      }

      const strength = Math.max(0, knockback.remainingMs / 150);
      transform.x += knockback.x * strength * deltaSeconds;
      transform.y += knockback.y * strength * deltaSeconds;
      knockback.remainingMs -= deltaMs;

      if (knockback.remainingMs <= 0) {
        expired.push(entityId);
      }
    }

    for (const entityId of expired) {
      runtime.world.components.knockbacks.delete(entityId);
    }
  }
}
