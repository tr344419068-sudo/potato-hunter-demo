import type { HealthComponent } from "../components/ComponentTypes";

/** Keep normal damage feedback, but honor health gates that clamp the assignment. */
export function applyHealthDamage(health: HealthComponent, requested: number): number {
  const before = health.current;
  const next = before - requested;
  health.current = next;
  return health.current === next ? requested : Math.max(0, before - health.current);
}
