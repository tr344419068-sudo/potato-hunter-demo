import type Phaser from "phaser";
import type { HealthComponent } from "../components/ComponentTypes";
import { AssetManager } from "../managers/AssetManager";
import { getBossDuel } from "./BossDuelArena";
import { getCharacterGroundPoint } from "./ShadowProfileModel";
import type { GameRuntime } from "./SystemTypes";

const EMBER = "vfx_boss_ember_ring";
const STATIC = "vfx_boss_static_ring";
const PHASE_COLORS = [0xffc04c, 0xa1cfff, 0xe5a2ff] as const;
const SNOW_PHASE_COLORS = [0x9cdfff, 0xa4a7ff, 0xf5abff] as const;

/** Authored art stays on the ground plane: never tint the character or the camera. */
export class BossDuelView {
  private readonly halos = new Map<number, Phaser.GameObjects.Image>();
  private fence?: Phaser.GameObjects.Image;
  constructor(private readonly scene: Phaser.Scene) {}

  draw(runtime: GameRuntime): void {
    const { world, stats: {elapsedMs} } = runtime;
    const duel = getBossDuel(world);
    if (duel) {
      const { x, y, radius } = duel;
      const art = `duel_fence_${duel.stage}`;
      const diameter = radius * (duel.stage === "snow" ? 1 / .44 : 2.16);
      if (AssetManager.hasTexture(this.scene, art)) {
        this.fence ??= this.scene.add.image(x, y, AssetManager.getTextureKey(art)).setDepth(.72);
        this.fence.setTexture(AssetManager.getTextureKey(art)).setPosition(x, y)
          .setDisplaySize(diameter, diameter)
          .setAlpha(.57 + .43 * Math.min(1, Math.max(0, (elapsedMs - duel.startedAt) / 310)));
      }
    } else if (this.fence) { this.fence.destroy(); this.fence = undefined; }

    for (const [id, monster] of world.components.monsters) {
      if (!monster.isBoss || monster.finalBossEncounter?.burrowed || (duel && id !== duel.bossId) || (world.components.health.get(id)?.current ?? 0) <= 0) continue;
      const point = world.components.transforms.get(id), render = world.components.renders.get(id);
      if (!point || !render) continue;
      const phase = monster.finalBossEncounter?.phase ?? 1;
      const snow = duel?.stage === "snow";
      const tint = (snow ? SNOW_PHASE_COLORS : PHASE_COLORS)[phase - 1];
      const asset = snow || phase >= 2 ? STATIC : EMBER;
      const size = Math.max(100, point.radius * (monster.bossKind === "final" ? 3.9 : 3.4));
      const foot = getCharacterGroundPoint({ x: point.x, y: point.y, visualSize: render.size,
        pivot: AssetManager.getPivot(render.assetId), footPoint: AssetManager.getFootPoint(render.assetId), scaleX: 1, scaleY: 1, rotation: 0 });
      if (!AssetManager.hasTexture(this.scene, asset)) continue;
      const key = AssetManager.getTextureKey(asset), frame = Math.floor(elapsedMs / 72) % 12;
      let image = this.halos.get(id);
      if (!image) {
        image = this.scene.add.image(foot.x, foot.y, key, frame).setDepth(1.15);
        this.halos.set(id, image);
      }
      const pulse = 1 + .06 * Math.sin(elapsedMs / 185 + id);
      image.setTexture(key, frame).setPosition(foot.x, foot.y - 8).setTint(tint)
        .setDisplaySize(size * pulse, size * .55 * pulse).setAlpha(monster.finalBossEncounter?.transitioning ? .98 : .76);
    }
    for (const [id, image] of this.halos) {
      if ((!duel || id === duel.bossId) && !world.components.monsters.get(id)?.finalBossEncounter?.burrowed && (world.components.health.get(id)?.current ?? 0) > 0) continue;
      image.destroy(); this.halos.delete(id);
    }
  }

  destroy(): void {
    this.fence?.destroy(); this.fence = undefined;
    for (const image of this.halos.values()) image.destroy();
    this.halos.clear();
  }
}

export function drawHeroHealthAtFeet(graphics: Phaser.GameObjects.Graphics, x: number, footY: number, visualSize: number, health: HealthComponent): void {
  if (health.current <= 0 || health.max <= 0) return;
  const width = Math.max(50, Math.min(76, visualSize * .90));
  const left = x - width / 2, y = footY + 11;
  const ratio = Math.max(0, Math.min(1, health.current / health.max));
  graphics.fillStyle(0x1d1117, .97).fillRoundedRect(left, y, width, 9, 4);
  graphics.fillStyle(0x532229, .94).fillRoundedRect(left + 2, y + 2, width - 4, 5, 2);
  const fillWidth = (width - 4) * ratio;
  graphics.fillStyle(ratio <= .25 ? 0xff8f65 : 0xeb514d, 1).fillRoundedRect(left + 2, y + 2, fillWidth, 5, Math.min(2, fillWidth / 2));
}
