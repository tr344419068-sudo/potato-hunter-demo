import type { PlayerComponent } from "../components/ComponentTypes";

export const MAX_TEMPO_STACKS = 8;
export const TEMPO_HOLD_MS = 1500;
export const TEMPO_DECAY_MS = 160;

export function confirmTempoHit(player: PlayerComponent, level: number): void {
  if (level <= 0) return;
  player.tempo = { stacks: Math.min(MAX_TEMPO_STACKS, (player.tempo?.stacks ?? 0) + 1), holdRemainingMs: TEMPO_HOLD_MS, decayElapsedMs: 0 };
}

export function updateAttackTempo(player: PlayerComponent, deltaMs: number, level: number): void {
  if (!player.tempo) return;
  if (level <= 0) { player.tempo = undefined; return; }
  const decayDelta = Math.max(0, deltaMs - player.tempo.holdRemainingMs);
  player.tempo.holdRemainingMs = Math.max(0, player.tempo.holdRemainingMs - deltaMs);
  player.tempo.decayElapsedMs += decayDelta;
  const lostStacks = Math.floor(player.tempo.decayElapsedMs / TEMPO_DECAY_MS);
  player.tempo.stacks = Math.max(0, player.tempo.stacks - lostStacks);
  player.tempo.decayElapsedMs %= TEMPO_DECAY_MS;
}

export function getTempoSpeedBonus(player: PlayerComponent | undefined, level: number): number {
  return Math.min(MAX_TEMPO_STACKS, player?.tempo?.stacks ?? 0) * 0.01 * Math.min(6, Math.max(0, level));
}

export function getAttackCooldown(baseMs: number, minimumMs: number, tempoBonus: number, buffMultiplier: number): number {
  return Math.max(minimumMs, baseMs * Math.max(0.35, buffMultiplier) / (1 + Math.min(1, Math.max(0, tempoBonus))));
}
