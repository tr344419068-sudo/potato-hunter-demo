import type { FinalBossEncounter, FinalBossPhase, HealthComponent } from "../components/ComponentTypes";
import type { StageId } from "../progression/CampaignGrowth";
import { HOSTILE_PROJECTILE_CAP, HOSTILE_WARNING_CAP } from "./HostileHazardBudget";

export type FinalBossPattern = "sesame_fan" | "triple_slam" | "spatula_sweep" | "sauce_ring";
export type SnowPattern = "hammer_swing" | "ice_spikes" | "glacier_charge" | "avalanche";

export const FINAL_BOSS_ASSET_ID = "boss_burger_tyrant_v4";
export const FINAL_BOSS_FIRST_CAST_MS = 1800;
export const FINAL_BOSS_HP_MULTIPLIER = 1.95;
export const DESERT_BOSS_HP_SCALE = 1.5;
export const SNOW_BOSS_HP_SCALE = 2.05;
export const FINAL_BOSS_VISUAL_SIZE = 150;
export const FINAL_BOSS_PROJECTILE_CAP = HOSTILE_PROJECTILE_CAP;
export const FINAL_BOSS_WARNING_CAP = HOSTILE_WARNING_CAP;
export const FINAL_BOSS_PATTERNS: readonly FinalBossPattern[] = ["sesame_fan", "triple_slam", "spatula_sweep", "sauce_ring"];
export const FINAL_BOSS_SLAM_DELAYS: readonly number[] = [1100, 1450, 1800];
export const FINAL_BOSS_TRANSITION_MS = 900;
export const FINAL_BOSS_HEALTH_BANDS = [0, .3, .6, 1] as const;
export const DESERT_BOSS_HEALTH_BANDS = [0, .19, .38, .54, .70, .85, 1] as const;
export const SNOW_BOSS_HEALTH_BANDS = [0, .17, .35, .52, .69, .845, 1] as const;

export const FINAL_DUEL_FIRST_CAST_MS = 800;
export const FINAL_DUEL_RUSH_MS = 260;
export const FINAL_DUEL_STANDOFF = 130;
const FINAL_DUEL_PRESSURE = [
  { recoveryMs: 490, chaseSpeed: 265, rushDistance: 310, sweepTellMs: 660, fanTellMs: 710, slamDelays: [700, 970, 1240], shotSpeed: 310, shotHpRatio: .50, slamRadius: 106, slamHpRatio: .52, sweepRadius: 84, sweepHpRatio: .54, shockRadius: 355, sandRadius: 185, finisherHpRatio: .60 },
  { recoveryMs: 330, chaseSpeed: 295, rushDistance: 340, sweepTellMs: 610, fanTellMs: 640, slamDelays: [650, 890, 1130], shotSpeed: 338, shotHpRatio: .52, slamRadius: 113, slamHpRatio: .55, sweepRadius: 91, sweepHpRatio: .58, shockRadius: 375, sandRadius: 195, finisherHpRatio: .64 },
  { recoveryMs: 240, chaseSpeed: 325, rushDistance: 370, sweepTellMs: 550, fanTellMs: 590, slamDelays: [620, 820, 1020], shotSpeed: 365, shotHpRatio: .55, slamRadius: 120, slamHpRatio: .58, sweepRadius: 98, sweepHpRatio: .62, shockRadius: 395, sandRadius: 205, finisherHpRatio: .68 },
] as const;

export function getFinalDuelPressure(phase: number) {
  return FINAL_DUEL_PRESSURE[phase >= 3 ? 2 : phase >= 2 ? 1 : 0];
}

export function getFinalDuelTellMs(pattern: FinalBossPattern, phase: number): number {
  const timing = getFinalDuelPressure(phase);
  if (pattern === "spatula_sweep") return timing.sweepTellMs;
  if (pattern === "sesame_fan") return timing.fanTellMs;
  if (pattern === "triple_slam") return timing.slamDelays[2];
  // The largest attack still leaves enough time to clear the danger area.
  return 1100;
}

export function getDuelHitDamage(maxHp: number, hpRatio: number): number {
  return Math.ceil(maxHp * hpRatio - 1e-6);
}

interface EncounterPhase<Pattern = FinalBossPattern> {
  label: string;
  rotation: readonly Pattern[];
  requiredCasts: number;
}

const CAMPAIGN_PHASES: { meadow: Record<FinalBossPhase, EncounterPhase>; desert: Record<FinalBossPhase, EncounterPhase>; snow: Record<FinalBossPhase, EncounterPhase<SnowPattern>> } = {
  meadow: {
    1: { label: "芝麻火线", rotation: ["sesame_fan", "triple_slam", "spatula_sweep"], requiredCasts: 1 },
    2: { label: "锅铲重压", rotation: ["spatula_sweep", "triple_slam", "sesame_fan"], requiredCasts: 2 },
    3: { label: "震荡围城", rotation: ["sauce_ring", "spatula_sweep", "sesame_fan", "triple_slam"], requiredCasts: 1 },
  },
  desert: {
    1: { label: "断岸沙浪", rotation: ["sesame_fan", "triple_slam", "spatula_sweep"], requiredCasts: 1 },
    2: { label: "流沙封路", rotation: ["triple_slam", "spatula_sweep", "sesame_fan"], requiredCasts: 2 },
    3: { label: "地脉暴君", rotation: ["sauce_ring", "sesame_fan", "spatula_sweep", "triple_slam"], requiredCasts: 2 },
  },
  snow: {
    1: { label: "霜锋破地", rotation: ["ice_spikes"], requiredCasts: 1 },
    2: { label: "冰甲冲锋", rotation: ["glacier_charge", "ice_spikes"], requiredCasts: 2 },
    3: { label: "裂谷雪崩", rotation: ["avalanche", "ice_spikes", "glacier_charge"], requiredCasts: 2 },
  },
};

export function getCampaignFinalBossPhase(stage: "snow", phase: FinalBossPhase): EncounterPhase<SnowPattern>;
export function getCampaignFinalBossPhase(stage: "meadow" | "desert", phase: FinalBossPhase): EncounterPhase;
export function getCampaignFinalBossPhase(stage: StageId, phase: FinalBossPhase): EncounterPhase<FinalBossPattern | SnowPattern>;
export function getCampaignFinalBossPhase(stage: StageId, phase: FinalBossPhase): EncounterPhase<FinalBossPattern | SnowPattern> {
  return CAMPAIGN_PHASES[stage][phase];
}

export function getFinalBossPhaseFloor(maxHp: number, phase: FinalBossPhase, stage: StageId = "meadow"): number {
  if (stage === "snow") return maxHp * SNOW_BOSS_HEALTH_BANDS[(3 - phase) * 2];
  return maxHp * (stage === "desert" ? DESERT_BOSS_HEALTH_BANDS[(3 - phase) * 2] : FINAL_BOSS_HEALTH_BANDS[3 - phase]);
}

/** All player damage paths write current HP; only campaign finales have a damage gate. */
export function createFinalBossHealth(max: number, encounter: FinalBossEncounter, stage: StageId): HealthComponent {
  let current = max;
  return {
    max,
    get current() { return current; },
    set current(value: number) {
      const { phase, completedCasts, transitioning, sandArmor } = encounter;
      if (encounter.burrowed && value < current) return;
      if (!transitioning && value < current && sandArmor && sandArmor.hp > 0) {
        const absorbed = Math.min(sandArmor.hp, current - value);
        sandArmor.hp -= absorbed;
        value += absorbed;
      }
      const minimum = transitioning
        ? getFinalBossPhaseFloor(this.max, (phase - 1) as FinalBossPhase, stage)
        : phase === 3 && completedCasts < getCampaignFinalBossPhase(stage, phase).requiredCasts
          ? stage === "snow" ? this.max * .08 : 1
          : getFinalBossPhaseFloor(this.max, phase, stage);
      current = Math.max(minimum, value);
    },
  };
}

export const FINAL_BOSS_PATTERN_LABELS: Record<FinalBossPattern, string> = {
  sesame_fan: "芝麻扇射 · 穿过弹隙",
  triple_slam: "三重堡垒震击 · 依次避开标记",
  spatula_sweep: "锅铲横扫 · 离开红色长带",
  sauce_ring: "酱汁围城 · 绿色中心安全",
};

export const DESERT_BOSS_PATTERN_LABELS: Record<FinalBossPattern, string> = {
  sesame_fan: "沙晶分流 · 中央留有弹隙",
  triple_slam: "流沙连震 · 避开沿途标记",
  spatula_sweep: "沙刃横扫 · 离开红色长带",
  sauce_ring: "落沙爆发 · 离开圆形范围",
};

export function getFinalBossPhase(hpRatio: number): number {
  return hpRatio <= .3 ? 3 : hpRatio <= .6 ? 2 : 1;
}

export function getFinalBossWindupMs(pattern: FinalBossPattern): number {
  return pattern === "sesame_fan" ? 1050 : pattern === "triple_slam" ? 1800 : 1250;
}

export function getFinalBossRecoveryMs(phase: number): number {
  return phase >= 3 ? 700 : phase >= 2 ? 850 : 1050;
}

export function getFinalBossCastRequirements(pattern: FinalBossPattern, phase: number): { projectiles: number; warnings: number } {
  return { projectiles: pattern === "sesame_fan" ? phase === 1 ? 7 : 9 : 0, warnings: pattern === "triple_slam" ? 3 : 1 };
}
