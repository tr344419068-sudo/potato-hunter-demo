import { HOSTILE_PROJECTILE_CAP, HOSTILE_WARNING_CAP } from "./HostileHazardBudget";

export type FinalBossPattern = "sesame_fan" | "triple_slam" | "spatula_sweep" | "sauce_ring";

export const FINAL_BOSS_ASSET_ID = "boss_burger_tyrant_v4";
export const FINAL_BOSS_FIRST_CAST_MS = 1800;
export const FINAL_BOSS_HP_MULTIPLIER = 1.25;
export const FINAL_BOSS_VISUAL_SIZE = 150;
export const FINAL_BOSS_PROJECTILE_CAP = HOSTILE_PROJECTILE_CAP;
export const FINAL_BOSS_WARNING_CAP = HOSTILE_WARNING_CAP;
export const FINAL_BOSS_PATTERNS: readonly FinalBossPattern[] = ["sesame_fan", "triple_slam", "spatula_sweep", "sauce_ring"];
export const FINAL_BOSS_SLAM_DELAYS: readonly number[] = [1100, 1450, 1800];

export const FINAL_BOSS_PATTERN_LABELS: Record<FinalBossPattern, string> = {
  sesame_fan: "芝麻扇射 · 穿过弹隙",
  triple_slam: "三重堡垒震击 · 依次避开标记",
  spatula_sweep: "锅铲横扫 · 离开红色长带",
  sauce_ring: "酱汁围城 · 绿色中心安全",
};

export function getFinalBossPhase(hpRatio: number): number {
  return hpRatio <= .3 ? 3 : hpRatio <= .6 ? 2 : 1;
}

export function getFinalBossWindupMs(pattern: FinalBossPattern): number {
  return pattern === "sesame_fan" ? 1050 : pattern === "triple_slam" ? 1800 : 1250;
}

export function getFinalBossRecoveryMs(phase: number): number {
  return phase >= 3 ? 700 : phase >= 2 ? 850 : 1050;
}

export function getFinalBossCastRequirements(pattern: FinalBossPattern, phase: number): { projectiles: number; warnings: number } {
  return { projectiles: pattern === "sesame_fan" ? phase === 1 ? 7 : 9 : 0, warnings: pattern === "triple_slam" ? 3 : pattern === "spatula_sweep" ? 4 : 1 };
}
