import type { FinalBossEncounter, FinalBossPhase, HealthComponent } from "../components/ComponentTypes";
import type { StageId } from "../progression/CampaignGrowth";
import { HOSTILE_PROJECTILE_CAP, HOSTILE_WARNING_CAP } from "./HostileHazardBudget";

export type FinalBossPattern = "sesame_fan" | "triple_slam" | "spatula_sweep" | "sauce_ring";

export const FINAL_BOSS_ASSET_ID = "boss_burger_tyrant_v4";
export const FINAL_BOSS_FIRST_CAST_MS = 1800;
export const FINAL_BOSS_HP_MULTIPLIER = 1.25;
export const FINAL_BOSS_VISUAL_SIZE = 150;
export const FINAL_BOSS_PROJECTILE_CAP = HOSTILE_PROJECTILE_CAP;
export const FINAL_BOSS_WARNING_CAP = HOSTILE_WARNING_CAP;
export const FINAL_BOSS_PATTERNS: readonly FinalBossPattern[] = ["sesame_fan", "triple_slam", "spatula_sweep", "sauce_ring"];
export const FINAL_BOSS_SLAM_DELAYS: readonly number[] = [1100, 1450, 1800];
export const FINAL_BOSS_TRANSITION_MS = 900;
export const FINAL_BOSS_HEALTH_BANDS = [0, .3, .6, 1] as const;

interface EncounterPhase {
  label: string;
  rotation: readonly FinalBossPattern[];
  requiredCasts: number;
}

const CAMPAIGN_PHASES: Record<StageId, Record<FinalBossPhase, EncounterPhase>> = {
  meadow: {
    1: { label: "芝麻火线", rotation: ["sesame_fan", "triple_slam"], requiredCasts: 1 },
    2: { label: "锅铲重压", rotation: ["spatula_sweep", "triple_slam", "sesame_fan"], requiredCasts: 2 },
    3: { label: "酱汁围城", rotation: ["sauce_ring", "spatula_sweep", "sesame_fan", "triple_slam"], requiredCasts: 1 },
  },
  desert: {
    1: { label: "沙晶试探", rotation: ["sesame_fan", "triple_slam"], requiredCasts: 1 },
    2: { label: "流沙连震", rotation: ["triple_slam", "spatula_sweep", "sesame_fan"], requiredCasts: 2 },
    3: { label: "落沙风暴", rotation: ["sauce_ring", "sesame_fan", "spatula_sweep", "triple_slam"], requiredCasts: 1 },
  },
};

export function getCampaignFinalBossPhase(stage: StageId, phase: FinalBossPhase): EncounterPhase {
  return CAMPAIGN_PHASES[stage][phase];
}

export function getFinalBossPhaseFloor(maxHp: number, phase: FinalBossPhase): number {
  return maxHp * FINAL_BOSS_HEALTH_BANDS[3 - phase];
}

/** All player damage paths write current HP; only campaign finales have a damage gate. */
export function createFinalBossHealth(max: number, encounter: FinalBossEncounter, stage: StageId): HealthComponent {
  let current = max;
  return {
    max,
    get current() { return current; },
    set current(value: number) {
      const { phase, completedCasts, transitioning } = encounter;
      const minimum = transitioning
        ? this.max * FINAL_BOSS_HEALTH_BANDS[4 - phase]
        : phase === 3 && completedCasts < getCampaignFinalBossPhase(stage, phase).requiredCasts
          ? 1
          : getFinalBossPhaseFloor(this.max, phase);
      current = Math.max(minimum, value);
    },
  };
}

export const FINAL_BOSS_PATTERN_LABELS: Record<FinalBossPattern, string> = {
  sesame_fan: "芝麻扇射 · 穿过弹隙",
  triple_slam: "三重堡垒震击 · 依次避开标记",
  spatula_sweep: "锅铲横扫 · 离开红色长带",
  sauce_ring: "酱汁围城 · 绿色中心安全",
};

export const DESERT_BOSS_PATTERN_LABELS: Record<FinalBossPattern, string> = {
  sesame_fan: "沙晶分流 · 中央留有弹隙",
  triple_slam: "流沙连震 · 避开沿途标记",
  spatula_sweep: "沙刃横扫 · 离开红色长带",
  sauce_ring: "落沙爆发 · 离开圆形范围",
};

export function getFinalBossPhase(hpRatio: number): number {
  return hpRatio <= .3 ? 3 : hpRatio <= .6 ? 2 : 1;
}

export function getFinalBossWindupMs(pattern: FinalBossPattern): number {
  return pattern === "sesame_fan" ? 1050 : pattern === "triple_slam" ? 1800 : 1250;
}

export function getFinalBossRecoveryMs(phase: number): number {
  return phase >= 3 ? 700 : phase >= 2 ? 850 : 1050;
}

export function getFinalBossCastRequirements(pattern: FinalBossPattern, phase: number): { projectiles: number; warnings: number } {
  return { projectiles: pattern === "sesame_fan" ? phase === 1 ? 7 : 9 : 0, warnings: pattern === "triple_slam" ? 3 : pattern === "spatula_sweep" ? 4 : 1 };
}
