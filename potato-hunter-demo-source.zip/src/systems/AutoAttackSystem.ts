import { createProjectile } from "../entities/factories";
import type { WeaponProfile } from "../managers/SkillManager";
import { distanceSquared, normalize } from "../utils/math";
import type { EntityId } from "../components/ComponentTypes";
import type { GameRuntime, System } from "./SystemTypes";
import { EventBus } from "../managers/EventBus";
import { getAttackCooldown, getTempoSpeedBonus, updateAttackTempo } from "./AttackTempoModel";
import { HERO_ACTIONS, HERO_ATTACK_CONTACT } from "./AuthoredHeroModel";

export class AutoAttackSystem implements System {
  private readonly cooldowns = new Map<string, number>();
  private readonly bursts = new Map<string, { remaining: number; timerMs: number; signature: string }>();
  private ownerId?: EntityId;
  private ownerWorld?: GameRuntime["world"];

  update(deltaMs: number, runtime: GameRuntime): void {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    if (!playerTransform) {
      return;
    }

    if (this.ownerId !== runtime.playerId || this.ownerWorld !== runtime.world) {
      this.cooldowns.clear(); this.bursts.clear(); this.ownerId = runtime.playerId; this.ownerWorld = runtime.world;
    }
    const player = runtime.world.components.players.get(runtime.playerId);
    const tempoLevel = runtime.skillManager.getLevel("combo_gear");
    if (player) updateAttackTempo(player, deltaMs, tempoLevel);
    const weapons = runtime.skillManager.getWeaponProfiles(player?.level);
    const activeSkills = new Set(weapons.map(weapon => weapon.skillId));
    for (const id of this.cooldowns.keys()) if (!activeSkills.has(id)) this.cooldowns.delete(id);
    for (const id of this.bursts.keys()) if (!activeSkills.has(id)) this.bursts.delete(id);

    for (const weapon of weapons) {
      const cooldown = (this.cooldowns.get(weapon.skillId) ?? 0) - deltaMs;
      this.cooldowns.set(weapon.skillId, cooldown);

      const signature = `${weapon.damageBeforePlayerGrowth ?? weapon.damage}:${weapon.projectileCount}:${weapon.burstCount}`;
      const burst = this.bursts.get(weapon.skillId);
      if (burst && burst.signature !== signature) this.bursts.delete(weapon.skillId);
      else if (burst) {
        burst.timerMs -= deltaMs;
        if (burst.timerMs <= 0) {
          if (!this.fireAtLivingTarget(runtime, weapon)) this.bursts.delete(weapon.skillId);
          else {
            burst.remaining -= 1; burst.timerMs = weapon.burstIntervalMs ?? 75;
            if (burst.remaining <= 0) this.bursts.delete(weapon.skillId);
          }
        }
        if (this.bursts.has(weapon.skillId)) continue;
        if (burst.timerMs <= 0 || burst.remaining <= 0) continue;
      }

      if (cooldown > 0) {
        if (cooldown <= HERO_ACTIONS.attack.durationMs * HERO_ATTACK_CONTACT) {
          const targetId = this.findNearestMonster(runtime, playerTransform.x, playerTransform.y);
          const target = targetId === undefined ? undefined : runtime.world.components.transforms.get(targetId);
          if (target) {
            const direction = normalize(target.x - playerTransform.x, target.y - playerTransform.y);
            EventBus.emit("weapon:windup", { skillId: weapon.skillId, remainingMs: cooldown, directionX: direction.x, directionY: direction.y, playerId: runtime.playerId, world: runtime.world });
          }
        }
        continue;
      }

      if (!this.fireAtLivingTarget(runtime, weapon)) continue;
      this.cooldowns.set(weapon.skillId, getAttackCooldown(weapon.cooldownMs, weapon.minCooldownMs ?? 0, getTempoSpeedBonus(player, tempoLevel), this.getBuffCooldownMultiplier(runtime)));
      if ((weapon.burstCount ?? 1) > 1) this.bursts.set(weapon.skillId, { remaining: (weapon.burstCount ?? 1) - 1, timerMs: weapon.burstIntervalMs ?? 75, signature });
    }
  }

  private fireAtLivingTarget(runtime: GameRuntime, weapon: WeaponProfile): boolean {
    const player = runtime.world.components.transforms.get(runtime.playerId);
    if (!player) return false;
    const targetId = this.findNearestMonster(runtime, player.x, player.y);
    const target = targetId === undefined ? undefined : runtime.world.components.transforms.get(targetId);
    if (!target) return false;
    this.fireWeapon(runtime, weapon, player.x, player.y, target.x, target.y);
    return true;
  }

  private fireWeapon(runtime: GameRuntime, weapon: WeaponProfile, x: number, y: number, targetX: number, targetY: number): void {
    const baseDirection = normalize(targetX - x, targetY - y);
    const spreadStep = weapon.projectileCount > 1 ? weapon.spread : 0;
    const spreadStart = -spreadStep * (weapon.projectileCount - 1) * 0.5;

    for (let index = 0; index < weapon.projectileCount; index += 1) {
      const angle = Math.atan2(baseDirection.y, baseDirection.x) + spreadStart + spreadStep * index;
      createProjectile(
        runtime.world,
        x,
        y,
        Math.cos(angle) * weapon.projectileSpeed,
        Math.sin(angle) * weapon.projectileSpeed,
        weapon.skillId,
        weapon.damage,
        weapon.pierce,
        weapon.lifetimeMs,
        weapon.color,
        weapon.size,
        weapon.effects,
        weapon.critChance,
        weapon.critMultiplier,
        weapon.projectileAssetId,
        weapon.vfxKind,
      );
    }

    EventBus.emit("weapon:fired", {
      playerId: runtime.playerId,
      world: runtime.world,
      skillId: weapon.skillId,
      x,
      y,
      directionX: baseDirection.x,
      directionY: baseDirection.y,
      color: weapon.color,
      size: weapon.size,
      projectileCount: weapon.projectileCount,
      vfxKind: weapon.vfxKind,
    });
  }

  private findNearestMonster(runtime: GameRuntime, x: number, y: number): EntityId | undefined {
    let nearestEntity: EntityId | undefined;
    let nearestDistance = Number.POSITIVE_INFINITY;

    for (const entityId of runtime.world.components.monsters.keys()) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform || (runtime.world.components.health.get(entityId)?.current ?? 0) <= 0) {
        continue;
      }

      const distance = distanceSquared(x, y, transform.x, transform.y);
      if (distance < nearestDistance) {
        nearestEntity = entityId;
        nearestDistance = distance;
      }
    }

    return nearestEntity;
  }

  private getBuffCooldownMultiplier(runtime: GameRuntime): number {
    const buffs = runtime.world.components.playerBuffs.get(runtime.playerId) ?? [];
    return Math.max(0.35, buffs.reduce((multiplier, buff) => multiplier * (buff.cooldownMultiplier ?? 1), 1));
  }
}
