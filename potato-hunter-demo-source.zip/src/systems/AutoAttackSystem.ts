import { createProjectile } from "../entities/factories";
import type { WeaponProfile } from "../managers/SkillManager";
import { distanceSquared, normalize } from "../utils/math";
import type { EntityId } from "../components/ComponentTypes";
import type { GameRuntime, System } from "./SystemTypes";
import { EventBus } from "../managers/EventBus";
import { getAttackCooldown, getTempoSpeedBonus, updateAttackTempo } from "./AttackTempoModel";
import { HERO_ACTIONS, HERO_ATTACK_CONTACT } from "./AuthoredHeroModel";
import { getPepperCastOrigin, getPepperLaunchVisual, isPepperWeapon } from "./WeaponPresentationModel";

export class AutoAttackSystem implements System {
  private readonly cooldowns = new Map<string, number>();
  private readonly bursts = new Map<string, { remaining: number; timerMs: number; signature: string }>();
  private ownerId?: EntityId;
  private ownerWorld?: GameRuntime["world"];

  update(deltaMs: number, runtime: GameRuntime): void {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    if (!playerTransform) {
      return;
    }

    if (this.ownerId !== runtime.playerId || this.ownerWorld !== runtime.world) {
      this.cooldowns.clear(); this.bursts.clear(); this.ownerId = runtime.playerId; this.ownerWorld = runtime.world;
    }
    const player = runtime.world.components.players.get(runtime.playerId);
    const tempoLevel = runtime.skillManager.getLevel("combo_gear");
    if (player) updateAttackTempo(player, deltaMs, tempoLevel);
    const weapons = runtime.skillManager.getWeaponProfiles(player?.level);
    const activeSkills = new Set(weapons.map(weapon => weapon.skillId));
    for (const id of this.cooldowns.keys()) if (!activeSkills.has(id)) this.cooldowns.delete(id);
    for (const id of this.bursts.keys()) if (!activeSkills.has(id)) this.bursts.delete(id);

    for (const weapon of weapons) {
      const cooldown = (this.cooldowns.get(weapon.skillId) ?? 0) - deltaMs;
      this.cooldowns.set(weapon.skillId, cooldown);

      const signature = `${weapon.damageBeforePlayerGrowth ?? weapon.damage}:${weapon.projectileCount}:${weapon.burstCount}`;
      const burst = this.bursts.get(weapon.skillId);
      if (burst && burst.signature !== signature) this.bursts.delete(weapon.skillId);
      else if (burst) {
        burst.timerMs -= deltaMs;
        if (burst.timerMs <= 0) {
          if (!this.fireAtLivingTarget(runtime, weapon)) this.bursts.delete(weapon.skillId);
          else {
            burst.remaining -= 1; burst.timerMs = weapon.burstIntervalMs ?? 75;
            if (burst.remaining <= 0) this.bursts.delete(weapon.skillId);
          }
        }
        if (this.bursts.has(weapon.skillId)) continue;
        if (burst.timerMs <= 0 || burst.remaining <= 0) continue;
      }

      if (cooldown > 0) {
        if (cooldown <= HERO_ACTIONS.attack.durationMs * HERO_ATTACK_CONTACT) {
          const targetId = this.findWeaponTarget(runtime, weapon, playerTransform.x, playerTransform.y);
          const target = targetId === undefined ? undefined : runtime.world.components.transforms.get(targetId);
          if (target) {
            const direction = normalize(target.x - playerTransform.x, target.y - playerTransform.y);
            EventBus.emit("weapon:windup", { skillId: weapon.skillId, remainingMs: cooldown, directionX: direction.x, directionY: direction.y, playerId: runtime.playerId, world: runtime.world });
          }
        }
        continue;
      }

      if (!this.fireAtLivingTarget(runtime, weapon)) continue;
      this.cooldowns.set(weapon.skillId, getAttackCooldown(weapon.cooldownMs, weapon.minCooldownMs ?? 0, getTempoSpeedBonus(player, tempoLevel), this.getBuffCooldownMultiplier(runtime)));
      if ((weapon.burstCount ?? 1) > 1) this.bursts.set(weapon.skillId, { remaining: (weapon.burstCount ?? 1) - 1, timerMs: weapon.burstIntervalMs ?? 75, signature });
    }
  }

  private fireAtLivingTarget(runtime: GameRuntime, weapon: WeaponProfile): boolean {
    const player = runtime.world.components.transforms.get(runtime.playerId);
    if (!player) return false;
    const targetId = this.findWeaponTarget(runtime, weapon, player.x, player.y);
    const target = targetId === undefined ? undefined : runtime.world.components.transforms.get(targetId);
    if (!target) return false;
    this.fireWeapon(runtime, weapon, player.x, player.y, target);
    return true;
  }

  private fireWeapon(runtime: GameRuntime, weapon: WeaponProfile, x: number, y: number, target: { x: number; y: number; radius: number }): void {
    const baseDirection = normalize(target.x - x, target.y - y);
    const facing = runtime.world.components.spriteJuices.get(runtime.playerId)?.facingX ?? 1;
    const muzzle = isPepperWeapon(weapon.skillId) ? getPepperCastOrigin(x, y, baseDirection.x, facing) : undefined;
    const launchVisual = muzzle ? getPepperLaunchVisual({ x, y }, muzzle, target, weapon.projectileSpeed) : undefined;
    const spreadStep = weapon.projectileCount > 1 ? weapon.spread : 0;
    const spreadStart = -spreadStep * (weapon.projectileCount - 1) * 0.5;

    for (let index = 0; index < weapon.projectileCount; index += 1) {
      const angle = Math.atan2(baseDirection.y, baseDirection.x) + spreadStart + spreadStep * index;
      createProjectile(
        runtime.world,
        x,
        y,
        Math.cos(angle) * weapon.projectileSpeed,
        Math.sin(angle) * weapon.projectileSpeed,
        weapon.skillId,
        weapon.damage,
        weapon.pierce,
        weapon.lifetimeMs,
        weapon.color,
        weapon.size,
        weapon.effects,
        weapon.critChance,
        weapon.critMultiplier,
        weapon.projectileAssetId,
        weapon.vfxKind,
        launchVisual,
        weapon.returnAfterMs,
      );
    }

    EventBus.emit("weapon:fired", {
      playerId: runtime.playerId,
      world: runtime.world,
      skillId: weapon.skillId,
      x,
      y,
      directionX: baseDirection.x,
      directionY: baseDirection.y,
      color: weapon.color,
      size: weapon.size,
      projectileCount: weapon.projectileCount,
      vfxKind: weapon.vfxKind,
      muzzle,
      closeRange: launchVisual && "hideMs" in launchVisual,
    });
  }

  private findWeaponTarget(runtime: GameRuntime, weapon: WeaponProfile, x: number, y: number): EntityId | undefined {
    let nearestEntity: EntityId | undefined;
    let nearestDistance = weapon.bossPriorityRange !== undefined ? weapon.bossPriorityRange ** 2 : Number.POSITIVE_INFINITY;
    let priority = -1;

    for (const [entityId, monster] of runtime.world.components.monsters) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform || (runtime.world.components.health.get(entityId)?.current ?? 0) <= 0) {
        continue;
      }

      const distance = distanceSquared(x, y, transform.x, transform.y);
      if (weapon.bossPriorityRange !== undefined && distance > weapon.bossPriorityRange ** 2) continue;
      const candidatePriority = weapon.bossPriorityRange !== undefined && monster.isBoss ? monster.bossKind === "final" ? 2 : 1 : 0;
      if (candidatePriority > priority || (candidatePriority === priority && distance < nearestDistance)) {
        nearestEntity = entityId;
        nearestDistance = distance;
        priority = candidatePriority;
      }
    }

    return nearestEntity;
  }

  private getBuffCooldownMultiplier(runtime: GameRuntime): number {
    const buffs = runtime.world.components.playerBuffs.get(runtime.playerId) ?? [];
    return Math.max(0.35, buffs.reduce((multiplier, buff) => multiplier * (buff.cooldownMultiplier ?? 1), 1));
  }
}
