import type { EntityId } from '../components/ComponentTypes';
import type { World } from '../entities/World';
import { sweepTime } from '../utils/math';

type Point = { readonly x: number; readonly y: number };
export type IceCover = Point & { readonly id: string; readonly radius: number };
export const ICE_SHATTER_MS = 420;

type Shatter = { readonly cover: IceCover; remainingMs: number };
type Roaming = { origin: Point; opening: IceCover[]; broken: Set<string>; cellX: number; cellY: number };
type IceField = { covers: IceCover[]; shatters: Shatter[]; roaming?: Roaming };
const terrain = new WeakMap<World, IceField>();
const blockableShots = new WeakSet<object>();
const CELL_SIZE = 360;
const PLAYER_FOOT_DEPTH = .65;
const CONTACT_GAP = .01;
const ORIGIN = { x: 0, y: 0 };

export function setIceCover(world: World, covers: readonly IceCover[]): void {
  terrain.set(world, { covers: covers.map(cover => ({ ...cover })), shatters: [] });
}

/** A few authored opening pillars lead into stable, world-space cover across the canyon. */
export function setupSnowIceTerrain(world: World, origin: Point): void {
  setIceCover(world, [
    { id: 'north-crag', x: origin.x - 83, y: origin.y - 152, radius: 26 },
    { id: 'east-crag', x: origin.x + 149, y: origin.y - 52, radius: 28 },
    { id: 'west-crag', x: origin.x - 166, y: origin.y + 74, radius: 30 },
    { id: 'south-crag', x: origin.x + 96, y: origin.y + 132, radius: 27 },
  ]);
  const field = terrain.get(world)!;
  field.roaming = { origin: { ...origin }, opening: field.covers.slice(), broken: new Set(), cellX: NaN, cellY: NaN };
  updateIceTerrain(0, world, origin);
}

/** Re-anchor cover so a freshly spawned final boss always has an ice-lined approach. */
export function setupDuelIceTerrain(world: World, origin: Point, boss: Point): void {
  const angle = Math.atan2(boss.y - origin.y, boss.x - origin.x);
  const x = Math.cos(angle), y = Math.sin(angle);
  const pillar = (id: string, forward: number, lateral: number, radius: number): IceCover => ({
    id, x: origin.x + x * forward - y * lateral, y: origin.y + y * forward + x * lateral, radius,
  });
  setIceCover(world, [pillar('duel-near', 116, 0, 30), pillar('duel-left', -25, -143, 33), pillar('duel-right', -59, 147, 31)]);
}

export function clearIceTerrain(world: World): void { terrain.delete(world); }

export function getIceCover(world: World): readonly IceCover[] { return terrain.get(world)?.covers ?? []; }

export function getIceCoverShatters(world: World): readonly Shatter[] { return terrain.get(world)?.shatters ?? []; }

export function updateIceTerrain(deltaMs: number, world: World, focus?: Point): void {
  const field = terrain.get(world);
  const roaming = field?.roaming;
  if (field && roaming && focus) {
    const { origin, broken, opening } = roaming;
    const cellX = Math.floor((focus.x - origin.x) / CELL_SIZE + .5);
    const cellY = Math.floor((focus.y - origin.y) / CELL_SIZE + .5);
    if (cellX !== roaming.cellX || cellY !== roaming.cellY) {
      Object.assign(roaming, { cellX, cellY });
      field.covers = Math.max(Math.abs(cellX), Math.abs(cellY)) <= 3 ? opening.filter(cover => !broken.has(cover.id)) : [];
      for (let y = cellY - 3; y <= cellY + 3; y++) for (let x = cellX - 3; x <= cellX + 3; x++) {
        if (x === 0 && y === 0) continue;
        const id = `crag:${x}:${y}`;
        if (broken.has(id)) continue;
        const noise = (Math.imul(x, 1640531527) ^ Math.imul(y, 1434869437)) >>> 0;
        const jitterX = (noise & 127) - 63, jitterY = ((noise >>> 13) & 127) - 63;
        field.covers.push({ id, x: origin.x + x * CELL_SIZE + jitterX, y: origin.y + y * CELL_SIZE + jitterY, radius: 25 + (noise >>> 26) % 8 });
      }
    }
  }
  const shatters = field?.shatters;
  if (!shatters?.length) return;
  for (let i = shatters.length - 1; i >= 0; i--) {
    shatters[i].remainingMs -= deltaMs;
    if (shatters[i].remainingMs <= 0) shatters.splice(i, 1);
  }
}

/** Sweep the hero against the base of each intact crag, then slide along the contact. */
export function movePlayerAroundIce(world: World, hero: { x: number; y: number; radius: number }, dx: number, dy: number): void {
  const covers = terrain.get(world)?.covers;
  if (!covers?.length) { hero.x += dx; hero.y += dy; return; }

  for (let contact = 0; contact < 3 && (dx !== 0 || dy !== 0); contact++) {
    const endX = hero.x + dx, endY = hero.y + dy;
    let first: { cover: IceCover; time: number; rx: number; ry: number } | undefined;
    for (const cover of covers) {
      const rx = cover.radius + hero.radius, ry = cover.radius * PLAYER_FOOT_DEPTH + hero.radius;
      if (cover.x < Math.min(hero.x, endX) - rx || cover.x > Math.max(hero.x, endX) + rx ||
          cover.y < Math.min(hero.y, endY) - ry || cover.y > Math.max(hero.y, endY) + ry) continue;
      // Scaling to a unit circle lets a fast dash use the same sweep as a projectile.
      const from = { x: (hero.x - cover.x) / rx, y: (hero.y - cover.y) / ry };
      const to = { x: (endX - cover.x) / rx, y: (endY - cover.y) / ry };
      const time = sweepTime(from, to, ORIGIN, 1);
      if (time !== undefined && (!first || time < first.time)) first = { cover, time, rx, ry };
    }
    if (!first) { hero.x = endX; hero.y = endY; return; }

    const { cover, time, rx, ry } = first;
    const offsetX = hero.x + dx * time - cover.x, offsetY = hero.y + dy * time - cover.y;
    // If a reposition put the hero inside a crag, eject to the base boundary.
    // At its center, use the player's intended direction to choose the exit.
    const radialX = offsetX || offsetY ? offsetX / rx : dx / rx;
    const radialY = offsetX || offsetY ? offsetY / ry : dy / ry;
    const radialLength = Math.hypot(radialX, radialY);
    const normalX = radialX / rx, normalY = radialY / ry;
    const normalLength = Math.hypot(normalX, normalY);
    const nx = normalX / normalLength, ny = normalY / normalLength;
    hero.x = cover.x + radialX / radialLength * rx + nx * CONTACT_GAP;
    hero.y = cover.y + radialY / radialLength * ry + ny * CONTACT_GAP;

    dx *= 1 - time;
    dy *= 1 - time;
    const inward = Math.min(0, dx * nx + dy * ny);
    dx -= inward * nx;
    dy -= inward * ny;
  }
}

/** Entry time is shared by projectiles and rolls so each can compare the hero contact first. */
export function sweepIceCover(world: World, from: Point, to: Point, padding = 0): { cover: IceCover; time: number } | undefined {
  const field = terrain.get(world);
  if (!field) return undefined;
  let first: IceCover | undefined, time = Infinity;
  for (const cover of field.covers) {
    const entry = sweepTime(from, to, cover, cover.radius + padding);
    if (entry !== undefined && entry < time) { first = cover; time = entry; }
  }
  return first ? { cover: first, time } : undefined;
}

export function hitIceCover(world: World, from: Point, to: Point, padding = 0): IceCover | undefined {
  return sweepIceCover(world, from, to, padding)?.cover;
}

export function breakIceCover(world: World, id: string): boolean {
  const field = terrain.get(world);
  const index = field?.covers.findIndex(cover => cover.id === id) ?? -1;
  if (!field || index < 0) return false;
  const [cover] = field.covers.splice(index, 1);
  field.roaming?.broken.add(id);
  field.shatters.push({ cover, remainingMs: ICE_SHATTER_MS });
  return true;
}

// Tag the projectile component itself; removal/reuse of an ECS ID can't inherit the tag.
export function markIceBlockableProjectile(world: World, projectileId: EntityId): void {
  const shot = world.components.enemyProjectiles.get(projectileId);
  if (shot) blockableShots.add(shot);
}

export function isIceBlockableProjectile(world: World, projectileId: EntityId): boolean {
  const shot = world.components.enemyProjectiles.get(projectileId);
  return shot !== undefined && blockableShots.has(shot);
}
