import type Phaser from "phaser";
import { getAuthoredHeroPose, HERO_ACTIONS, HERO_RIG, type HeroAction, type HeroPart, type HeroPartPose } from "./AuthoredHeroModel";

interface Point { x: number; y: number }
type Foot = "left_boot" | "right_boot";
interface HeroInput {
  entityId: number; assetId: string; x: number; y: number; worldX: number; worldY: number;
  visualSize: number; pivot: Point; facingX: number; alpha: number; deltaMs: number;
  attack: number; attackSequence?: number; attackProgress?: number; weaponReleaseSequence?: number;
  dead: boolean; dashing: boolean; hit: boolean; tint?: number;
}
interface FootState { world: Point; anchor: Point; planted: boolean; cycle: number; released: boolean }
interface Actor {
  images: Map<HeroPart, Phaser.GameObjects.Image>; phase: number; clock: number; action: HeroAction;
  actionTime: number; lastX: number; lastY: number; lastAttack: number; lastSequence: number;
  pose: HeroPartPose[]; moving: boolean; facingX: number; hipDrop: number;
  lastReleaseSequence: number; releaseRemainingMs: number; releaseRecoil: number;
  feet: Record<Foot, FootState>;
}

const FEET: readonly Foot[] = ["left_boot", "right_boot"];
const hipFor = (foot: Foot) => HERO_RIG[foot === "left_boot" ? "left_thigh" : "right_thigh"].joint;
const toWorld = (point: Point, input: HeroInput): Point => ({
  x: input.worldX + (point.x / 256 - input.pivot.x) * input.visualSize * input.facingX,
  y: input.worldY + (point.y / 256 - input.pivot.y) * input.visualSize,
});
const toLocal = (point: Point, input: HeroInput): Point => ({
  x: (point.x - input.worldX) / input.visualSize * 256 * input.facingX + input.pivot.x * 256,
  y: (point.y - input.worldY) / input.visualSize * 256 + input.pivot.y * 256,
});

export class AuthoredHeroView {
  private readonly actors = new Map<number, Actor>();
  constructor(private readonly scene: Phaser.Scene) { scene.events?.once("shutdown", () => this.prune(new Set())); }

  supports(assetId: string): boolean {
    return assetId === "char_potato_hunter" && Object.keys(HERO_RIG).every(id => this.scene.textures.exists(`asset:hero_part_${id}`));
  }

  draw(input: HeroInput): boolean {
    if (!this.supports(input.assetId)) return false;
    let actor = this.actors.get(input.entityId);
    if (!actor) {
      const images = new Map<HeroPart, Phaser.GameObjects.Image>();
      for (const [index, id] of (Object.keys(HERO_RIG) as HeroPart[]).entries()) {
        const joint = HERO_RIG[id].joint;
        images.set(id, this.scene.add.image(0, 0, `asset:hero_part_${id}`).setOrigin(joint.x / 256, joint.y / 256).setDepth(2 + index * .001));
      }
      const footState = (foot: Foot): FootState => {
        const world = toWorld(HERO_RIG[foot].end, input);
        return { world, anchor: { ...world }, planted: true, cycle: 0, released: false };
      };
      actor = { images, phase: 0, clock: 0, action: "idle", actionTime: 0, lastX: input.worldX, lastY: input.worldY,
        lastAttack: 0, lastSequence: 0, pose: [], moving: false, facingX: input.facingX, hipDrop: 0,
        feet: { left_boot: footState("left_boot"), right_boot: footState("right_boot") }, lastReleaseSequence: 0, releaseRemainingMs: 0, releaseRecoil: 0 };
      this.actors.set(input.entityId, actor);
    }
    if (input.deltaMs > 0 || actor.pose.length === 0 || (input.weaponReleaseSequence ?? 0) > actor.lastReleaseSequence) this.advance(actor, input);
    for (const pose of actor.pose) {
      const image = actor.images.get(pose.id)!;
      image.setScale(input.visualSize / 256 * pose.scaleX * input.facingX, input.visualSize / 256 * pose.scaleY)
        .setPosition(input.x + (pose.x / 256 - input.pivot.x) * input.visualSize * input.facingX,
          input.y + (pose.y / 256 - input.pivot.y) * input.visualSize)
        .setRotation(pose.rotation * input.facingX).setAlpha(pose.alpha * input.alpha).setVisible(true);
      if (input.tint !== undefined) image.setTint(input.tint); else image.clearTint();
    }
    actor.lastReleaseSequence = input.weaponReleaseSequence ?? actor.lastReleaseSequence;
    return true;
  }

  private advance(actor: Actor, input: HeroInput): void {
    const deltaMs = Math.max(0, Math.min(input.deltaMs, 100));
    if ((input.weaponReleaseSequence ?? 0) > actor.lastReleaseSequence) {
      actor.releaseRemainingMs = 64;
      actor.releaseRecoil = (input.weaponReleaseSequence! % 2 === 0 ? -1 : 1) * .016;
    } else actor.releaseRemainingMs = Math.max(0, actor.releaseRemainingMs - deltaMs);
    const travelX = input.worldX - actor.lastX, travelY = input.worldY - actor.lastY;
    const distance = Math.hypot(travelX, travelY);
    if (input.facingX !== actor.facingX) {
      [actor.feet.left_boot, actor.feet.right_boot] = [actor.feet.right_boot, actor.feet.left_boot];
      actor.phase += .5;
      actor.facingX = input.facingX;
    }
    actor.phase += Math.min(14, distance) / Math.max(16, input.visualSize * .46);
    actor.clock += deltaMs;
    actor.actionTime += deltaMs;
    actor.moving = distance > .05 && !input.dead;
    const rising = input.attackSequence === undefined ? input.attack > actor.lastAttack + .1 : input.attackSequence > actor.lastSequence;
    const attacking = actor.action === "attack" && (input.attackProgress === undefined ? actor.actionTime < HERO_ACTIONS.attack.durationMs : input.attackProgress < 1);
    const next: HeroAction = input.dead ? "death" : input.dashing ? "dash" : input.hit ? "hit" :
      rising && (actor.action !== "attack" || actor.actionTime > 125) ? "attack" : attacking ? "attack" : actor.moving ? "run" : "idle";
    if (next !== actor.action || next === "attack" && rising && actor.actionTime > 125) { actor.action = next; actor.actionTime = 0; }
    if (actor.action === "attack" && input.attackProgress !== undefined) actor.actionTime = Math.max(0, Math.min(1, input.attackProgress)) * HERO_ACTIONS.attack.durationMs;
    const feet = input.dead ? undefined : this.advanceFeet(actor, input, travelX, travelY, distance, deltaMs);
    actor.pose = getAuthoredHeroPose({ action: actor.action, timeMs: actor.action === "idle" || actor.action === "run" ? actor.clock : actor.actionTime,
      phase: actor.phase * Math.PI * 2, moving: actor.moving, attack: actor.actionTime / HERO_ACTIONS.attack.durationMs,
      feet, hipDrop: input.dead ? 0 : actor.hipDrop, releaseContact: Math.min(1, actor.releaseRemainingMs / 32), releaseRecoil: actor.releaseRecoil * actor.releaseRemainingMs / 64 });
    if (!input.dead) for (const foot of FEET) {
      const pose = actor.pose.find(part => part.id === foot)!, bone = HERO_RIG[foot];
      const localX = bone.end.x - bone.joint.x, localY = bone.end.y - bone.joint.y;
      actor.feet[foot].world = toWorld({ x: pose.x + Math.cos(pose.rotation) * localX - Math.sin(pose.rotation) * localY,
        y: pose.y + Math.sin(pose.rotation) * localX + Math.cos(pose.rotation) * localY }, input);
    }
    actor.lastAttack = input.attack; actor.lastSequence = input.attackSequence ?? actor.lastSequence;
    actor.lastX = input.worldX; actor.lastY = input.worldY;
  }

  private advanceFeet(actor: Actor, input: HeroInput, travelX: number, travelY: number, distance: number, deltaMs: number): Record<Foot, Point> {
    const targets = {} as Record<Foot, Point>;
    const directionX = distance > 0 ? travelX / distance : 0, directionY = distance > 0 ? travelY / distance : 0;
    // These short cuffs only need a small amount of leg slack. A deeper
    // crouch folds both soles edge-on, especially during vertical travel.
    if (actor.moving) actor.hipDrop = 6;
    const stance = .36 - Math.abs(directionY) * .18;
    const reach = Math.max(16, input.visualSize * .46) * stance * .5 / input.visualSize * 256;
    const maxFootTravel = distance * 1.7 + deltaMs * .04;
    for (const foot of FEET) {
      const state = actor.feet[foot], hip = hipFor(foot);
      if (!actor.moving) {
        const groundY = toWorld(HERO_RIG[foot].end, input).y;
        const world = { x: state.world.x, y: state.world.y + Math.max(-deltaMs * .08, Math.min(deltaMs * .08, groundY - state.world.y)) };
        targets[foot] = toLocal(world, input);
        state.anchor = world; state.planted = true; state.released = false;
        continue;
      }
      const step = actor.phase + (foot === "right_boot" ? .5 : 0), cycle = Math.floor(step), phase = step - cycle;
      if (cycle !== state.cycle) { state.cycle = cycle; state.released = false; state.planted = false; }
      const contact = phase < stance;
      const swing = Math.max(0, (phase - stance) / (1 - stance));
      const sweep = contact ? 1 - phase / stance * 2 : -Math.cos(swing * Math.PI);
      const heel = HERO_RIG[foot].end;
      const desired = { x: heel.x + directionX * input.facingX * reach * sweep,
        y: heel.y + directionY * reach * sweep - (contact ? 0 : Math.sin(swing * Math.PI) * 4) };
      if (contact && !state.planted && !state.released) {
        const landing = toWorld(desired, input);
        if (Math.hypot(landing.x - state.world.x, landing.y - state.world.y) <= maxFootTravel) { state.anchor = landing; state.planted = true; }
        else state.released = true;
      }
      if (!contact) state.planted = false;
      const anchor = toLocal(state.anchor, input), thigh = HERO_RIG[foot === "left_boot" ? "left_thigh" : "right_thigh"], boot = HERO_RIG[foot];
      const length = Math.hypot(thigh.end.x - thigh.joint.x, thigh.end.y - thigh.joint.y) + Math.hypot(boot.end.x - boot.joint.x, boot.end.y - boot.joint.y);
      if (state.planted && Math.hypot(anchor.x - hip.x, anchor.y - hip.y - actor.hipDrop) > length - .02) { state.planted = false; state.released = true; }
      if (state.planted) targets[foot] = anchor;
      else {
        const world = toWorld(desired, input), blend = Math.min(1, deltaMs / 16);
        const travel = Math.hypot(world.x - state.world.x, world.y - state.world.y);
        const step = Math.min(blend, maxFootTravel / Math.max(.001, travel));
        targets[foot] = toLocal({ x: state.world.x + (world.x - state.world.x) * step, y: state.world.y + (world.y - state.world.y) * step }, input);
      }
    }
    return targets;
  }

  prune(active: ReadonlySet<number>): void {
    for (const [id, actor] of this.actors) if (!active.has(id)) {
      for (const image of actor.images.values()) image.destroy();
      this.actors.delete(id);
    }
  }
}
