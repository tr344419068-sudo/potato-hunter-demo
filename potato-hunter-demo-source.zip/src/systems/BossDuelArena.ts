import type { EntityId, TransformComponent } from "../components/ComponentTypes";
import type { World } from "../entities/World";
import type { StageId } from "../progression/CampaignGrowth";

export const DUEL_RADIUS = 450;
export const DUEL_BOSS_DISTANCE = 240;

interface BossDuel {
  readonly x: number;
  readonly y: number;
  readonly bossId: EntityId;
  readonly radius: number;
  readonly stage: StageId;
  readonly startedAt: number;
}

const duels = new WeakMap<World, BossDuel>();

export function startBossDuel(world: World, duel: Omit<BossDuel, "radius">): void {
  duels.set(world, { ...duel, radius: DUEL_RADIUS });
}

export function getBossDuel(world: World): BossDuel | undefined {
  const duel = duels.get(world);
  if (duel && (world.components.health.get(duel.bossId)?.current ?? 0) > 0) return duel;
  return undefined;
}

export function clearBossDuel(world: World): void { duels.delete(world); }

/** Intersect the locked dash ray with the boundary for the Boss's center. */
export function getBossDuelRushDistance(duel: BossDuel, origin: TransformComponent, angle: number, requested: number): number {
  const x = origin.x - duel.x, y = origin.y - duel.y;
  const boundary = Math.max(0, duel.radius - origin.radius);
  const projected = x * Math.cos(angle) + y * Math.sin(angle);
  const remaining = Math.sqrt(Math.max(0, projected * projected + boundary * boundary - x * x - y * y)) - projected;
  return Math.min(requested, Math.max(0, remaining));
}

/** Target selection and hit detection share the same whitelist during the duel. */
export function getAttackableMonsterIds(world: World): Iterable<EntityId> {
  const duel = getBossDuel(world);
  return duel ? (world.components.monsters.get(duel.bossId)?.finalBossEncounter?.burrowed ? [] : [duel.bossId]) : world.components.monsters.keys();
}

/** A neutral, non-damaging wall. The collision radius stays inside the visible rim. */
export function confineDuelActor(duel: BossDuel | undefined, id: EntityId, playerId: EntityId, point: TransformComponent): void {
  if (!duel || (id !== playerId && id !== duel.bossId)) return;
  const dx = point.x - duel.x, dy = point.y - duel.y;
  const distance = Math.hypot(dx, dy);
  const limit = Math.max(0, duel.radius - point.radius);
  if (distance <= limit) return;
  point.x = duel.x + dx / distance * limit;
  point.y = duel.y + dy / distance * limit;
}
