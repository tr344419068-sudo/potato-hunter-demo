import Phaser from "phaser";
import { EntityPools } from "../managers/EntityPools";
import { EventBus } from "../managers/EventBus";
import { formatDamageValue, getDamageNumberFrame, getDamageNumberLane, getDamageNumberPresentation, MAX_DAMAGE_NUMBERS, type DamageNumberInput } from "./DamageNumberModel";
import type { System, GameRuntime } from "./SystemTypes";
type DamagePayload = DamageNumberInput;
interface ActiveDamageNumber {
    text: Phaser.GameObjects.Text;
    ageMs: number;
    x: number;
    y: number;
    critical: boolean;
    targetKey: string;
    lane: number;
}
interface CombatVfxPayload {
    kind: string;
    x: number;
    y: number;
    x2?: number;
    y2?: number;
    color?: number;
    radius?: number;
}
interface SparksPayload {
    x: number;
    y: number;
    color: number;
    count?: number;
    size?: number;
}
export class FeedbackSystem implements System {
    private floatingTextCount = 0;
    private activeSparkCount = 0;
    private readonly damageNumbers = new Set<ActiveDamageNumber>();
    private destroyed = false;
    constructor(private readonly scene: Phaser.Scene) {
        EventBus.on("combat:damage", this.showDamageNumber, this);
        EventBus.on("combat:vfx", this.showCombatVfx, this);
        EventBus.on("fx:sparks", this.showSparks, this);
        EventBus.on("game:over", this.destroy, this);
        scene.events.once(Phaser.Scenes.Events.SHUTDOWN, () => this.destroy());
    }
    update(deltaMs: number, _runtime: GameRuntime): void {
        if (this.destroyed || !Number.isFinite(deltaMs) || deltaMs <= 0)
            return;
        for (const number of this.damageNumbers) {
            number.ageMs += deltaMs;
            const frame = getDamageNumberFrame(number.ageMs, number.critical);
            if (frame.expired) {
                this.releaseNumber(number);
                continue;
            }
            number.text.setPosition(number.x, number.y - frame.lift).setScale(frame.scale).setAlpha(frame.alpha);
        }
    }
    getActiveSparkCount(): number {
        return this.activeSparkCount;
    }
    destroy(): void {
        if (this.destroyed)
            return;
        this.destroyed = true;
        EventBus.off("combat:damage", this.showDamageNumber, this);
        EventBus.off("combat:vfx", this.showCombatVfx, this);
        EventBus.off("fx:sparks", this.showSparks, this);
        EventBus.off("game:over", this.destroy, this);
        for (const number of this.damageNumbers)
            this.releaseNumber(number);
        EntityPools.clearScene(this.scene);
    }
    private showDamageNumber(payload: DamagePayload): void {
        if (this.destroyed || !Number.isFinite(payload.x) || !Number.isFinite(payload.y))
            return;
        const value = formatDamageValue(payload.value);
        if (!value)
            return;
        const view = this.scene.cameras.main.worldView;
        if (view && (payload.x < view.x - 48 || payload.y < view.y - 72 || payload.x > view.x + view.width + 48 || payload.y > view.y + view.height + 48))
            return;
        if (this.damageNumbers.size >= MAX_DAMAGE_NUMBERS) {
            if (!payload.isCrit)
                return;
            const ordinary = [...this.damageNumbers].find(number => !number.critical);
            if (!ordinary)
                return;
            this.releaseNumber(ordinary);
        }
        const targetKey = payload.targetId === undefined ? `${Math.round(payload.x / 24)},${Math.round(payload.y / 24)}` : String(payload.targetId);
        const occupied = new Set([...this.damageNumbers].filter(n => n.targetKey === targetKey).map(n => n.lane));
        let lane = [0, 1, 2].find(index => !occupied.has(index));
        if (lane === undefined) {
            const oldest = [...this.damageNumbers].find(n => n.targetKey === targetKey && (!n.critical || payload.isCrit));
            if (!oldest)
                return;
            lane = oldest.lane;
            this.releaseNumber(oldest);
        }
        const chosenLane = lane ?? 0;
        const offset = getDamageNumberLane(chosenLane);
        const spec = getDamageNumberPresentation(payload);
        const text = EntityPools.acquireDamageText(this.scene);
        text.setText(value);
        text.setStyle({
            color: spec.color, fontSize: `${spec.fontSize}px`, fontStyle: "900",
            fontFamily: 'Arial, "PingFang SC", sans-serif',
            stroke: spec.stroke, strokeThickness: spec.strokeThickness,
        });
        text.setShadow(0, 2, '#07120e', 2, true, true);
        text.setPosition(payload.x + offset.x, payload.y + offset.y).setOrigin(0.5).setDepth(24).setScale(spec.initialScale).setAlpha(1);
        this.damageNumbers.add({ text, ageMs: 0, x: payload.x + offset.x, y: payload.y + offset.y, critical: payload.isCrit === true, targetKey, lane: chosenLane });
        this.floatingTextCount = this.damageNumbers.size;
    }
    private releaseNumber(number: ActiveDamageNumber): void {
        this.damageNumbers.delete(number);
        EntityPools.releaseDamageText(this.scene, number.text);
        this.floatingTextCount = this.damageNumbers.size;
    }
    private showCombatVfx(payload: CombatVfxPayload): void {
        const graphics = EntityPools.acquireGraphics(this.scene);
        const color = payload.color ?? 0xffffff;
        const radius = payload.radius ?? 32;
        const isLargeRing = radius >= 160;
        graphics.setPosition(payload.x, payload.y);
        graphics.setDepth(10);
        if (payload.kind === "chain" && payload.x2 !== undefined && payload.y2 !== undefined) {
            const points = [{ x: 0, y: 0 }];
            const dx = payload.x2 - payload.x;
            const dy = payload.y2 - payload.y;
            const length = Math.max(1, Math.hypot(dx, dy));
            const normalX = -dy / length;
            const normalY = dx / length;
            const segments = 7;
            for (let index = 1; index < segments; index += 1) {
                const progress = index / segments;
                const jitter = Phaser.Math.FloatBetween(-12, 12) * Math.sin(progress * Math.PI);
                points.push({
                    x: dx * progress + normalX * jitter,
                    y: dy * progress + normalY * jitter,
                });
            }
            points.push({ x: dx, y: dy });
            graphics.lineStyle(9, 0x4cc9f0, 0.16);
            graphics.beginPath();
            graphics.moveTo(points[0].x, points[0].y);
            points.slice(1).forEach((point) => graphics.lineTo(point.x, point.y));
            graphics.strokePath();
            graphics.lineStyle(3, color, 0.96);
            graphics.beginPath();
            graphics.moveTo(points[0].x, points[0].y);
            points.slice(1).forEach((point) => graphics.lineTo(point.x, point.y));
            graphics.strokePath();
        }
        else {
            graphics.lineStyle(isLargeRing ? 5 : 3, color, isLargeRing ? 0.72 : 0.55);
            graphics.strokeCircle(0, 0, radius);
            if (isLargeRing) {
                graphics.lineStyle(2, color, 0.28);
                graphics.strokeCircle(0, 0, radius * 0.62);
            }
        }
        this.scene.tweens.add({
            targets: graphics,
            alpha: 0,
            duration: isLargeRing ? 360 : 180,
            onComplete: () => EntityPools.releaseGraphics(this.scene, graphics),
        });
    }
    private showSparks(payload: SparksPayload): void {
        const requestedCount = payload.count ?? 6;
        const allowedCount = Math.max(0, Math.min(requestedCount, 180 - this.activeSparkCount));
        if (allowedCount <= 0) {
            return;
        }
        for (let index = 0; index < allowedCount; index += 1) {
            this.activeSparkCount += 1;
            const spark = EntityPools.acquireGraphics(this.scene);
            const size = payload.size ?? 7;
            const angle = Phaser.Math.FloatBetween(0, Math.PI * 2);
            const distance = Phaser.Math.Between(18, 54);
            const targetX = payload.x + Math.cos(angle) * distance;
            const targetY = payload.y + Math.sin(angle) * distance;
            spark.setPosition(payload.x, payload.y);
            spark.setDepth(9);
            spark.fillStyle(payload.color, 0.88);
            spark.fillRect(-size / 2, -size / 2, size, size);
            this.scene.tweens.add({
                targets: spark,
                x: targetX,
                y: targetY,
                alpha: 0,
                duration: Phaser.Math.Between(180, 320),
                ease: "Quad.easeOut",
                onComplete: () => {
                    spark.setPosition(0, 0);
                    this.activeSparkCount = Math.max(0, this.activeSparkCount - 1);
                    EntityPools.releaseGraphics(this.scene, spark);
                },
            });
        }
    }
}
