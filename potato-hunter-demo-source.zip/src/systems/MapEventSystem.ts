import Phaser from "phaser";
import type { PlayerBuffComponent } from "../components/ComponentTypes";
import { createMapEvent } from "../entities/factories";
import { ConfigManager, type MapEventConfig } from "../managers/ConfigManager";
import { EventBus } from "../managers/EventBus";
import { RewardManager } from "../managers/RewardManager";
import { distanceSquared } from "../utils/math";
import type { GameRuntime, System } from "./SystemTypes";

export class MapEventSystem implements System {
  private readonly nextSpawnAtMs = new Map<string, number>();

  update(deltaMs: number, runtime: GameRuntime): void {
    this.updateBuffs(deltaMs, runtime);
    this.spawnEvents(runtime);
    this.collectEvents(runtime);
  }

  private updateBuffs(deltaMs: number, runtime: GameRuntime): void {
    const buffs = runtime.world.components.playerBuffs.get(runtime.playerId);
    if (!buffs) {
      return;
    }

    const activeBuffs = buffs
      .map((buff) => ({ ...buff, remainingMs: buff.remainingMs - deltaMs }))
      .filter((buff) => buff.remainingMs > 0);

    if (activeBuffs.length > 0) {
      runtime.world.components.playerBuffs.set(runtime.playerId, activeBuffs);
    } else {
      runtime.world.components.playerBuffs.delete(runtime.playerId);
    }
  }

  private spawnEvents(runtime: GameRuntime): void {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    if (!playerTransform) {
      return;
    }

    for (const eventConfig of ConfigManager.mapEvents.events) {
      const firstSpawnAtMs = eventConfig.spawnAfterSeconds * 1000;
      const nextSpawnAtMs = this.nextSpawnAtMs.get(eventConfig.id) ?? firstSpawnAtMs;
      if (runtime.stats.elapsedMs < nextSpawnAtMs) {
        continue;
      }

      const angle = runtime.random ? runtime.random() * Math.PI * 2 : Phaser.Math.FloatBetween(0, Math.PI * 2);
      const distance = runtime.random ? 180 + Math.floor(runtime.random() * 181) : Phaser.Math.Between(180, 360);
      createMapEvent(
        runtime.world,
        eventConfig,
        playerTransform.x + Math.cos(angle) * distance,
        playerTransform.y + Math.sin(angle) * distance,
      );
      this.nextSpawnAtMs.set(eventConfig.id, runtime.stats.elapsedMs + eventConfig.intervalSeconds * 1000);
      EventBus.emit("boss:phase", { text: `${eventConfig.name} 出现` });
    }
  }

  private collectEvents(runtime: GameRuntime): void {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    if (!playerTransform || !playerHealth || playerHealth.current <= 0) {
      return;
    }

    const collected: number[] = [];
    for (const [entityId, event] of runtime.world.components.mapEvents) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform) {
        collected.push(entityId);
        continue;
      }

      const collectRadius = playerTransform.radius + transform.radius + 8;
      if (distanceSquared(playerTransform.x, playerTransform.y, transform.x, transform.y) > collectRadius * collectRadius) {
        continue;
      }

      this.applyEvent(runtime, event.eventId, event.kind, event.value, event.durationMs, transform.x, transform.y);
      collected.push(entityId);
    }

    for (const entityId of collected) {
      runtime.world.destroyEntity(entityId);
    }
  }

  private applyEvent(
    runtime: GameRuntime,
    eventId: string,
    kind: MapEventConfig["kind"],
    value: number,
    durationMs: number | undefined,
    x: number,
    y: number,
  ): void {
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    if (!playerHealth || !playerTransform) {
      return;
    }

    if (kind === "supply") {
      RewardManager.applyRandomSupplyReward(runtime, x, y);
      return;
    }

    if (kind === "xp_burst") {
      RewardManager.applyReward(runtime, { id: eventId, kind: "xp_burst", value, text: "经验爆米花" }, x, y);
      return;
    }

    if (kind === "heal") {
      RewardManager.applyReward(runtime, { id: eventId, kind: "heal", value, text: "补给：回复生命" }, x, y);
      return;
    }

    if (kind === "haste") {
      this.addBuff(runtime, { id: eventId, remainingMs: durationMs ?? 8000, moveSpeedBonus: value });
      EventBus.emit("boss:phase", { text: "临时加速！" });
    }

    if (kind === "magnet") {
      this.addBuff(runtime, { id: eventId, remainingMs: durationMs ?? 8000, pickupRadiusBonus: value });
      EventBus.emit("boss:phase", { text: "临时磁吸！" });
    }

    EventBus.emit("fx:sparks", { x, y, color: kind === "magnet" ? 0x4cc9f0 : 0xffca3a, count: 18, size: 8 });
  }

  private addBuff(runtime: GameRuntime, buff: PlayerBuffComponent): void {
    const buffs = (runtime.world.components.playerBuffs.get(runtime.playerId) ?? []).filter((candidate) => candidate.id !== buff.id);
    runtime.world.components.playerBuffs.set(runtime.playerId, [...buffs, buff]);
  }
}
