import type Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import { getCyclonePoint, getDesertCast, getWaveY, type DesertCast, type DesertPattern, type DesertStrikeShape } from "./DesertBossEncounter";
import { getBossDuel } from "./BossDuelArena";
import type { GameRuntime } from "./SystemTypes";

const WAVE = "vfx_desert_wave_flipbook";
const CYCLONE = "vfx_desert_cyclone_flipbook";
const FALL = "vfx_desert_sandfall_flipbook";
const STORM = "vfx_desert_storm_flipbook";
const WIND = "vfx_desert_wind";
const WINDBREAK = "vfx_desert_windbreak";
const STRIKE = "vfx_enemy_sweep";
const ARMOR = "vfx_boss_ember_ring";
const RING = "vfx_halo_energy_v1";
const DUST = "vfx_boss_dust_flipbook";
const WHIRL = "vfx_desert_whirl_flipbook";
const TELL = "vfx_duel_sweep_tell";
const SAFE = 0xa3f5bb;
const SAFE_EDGE = 0xc4ffad;
const SAFE_FLOOR = 0x23883c;
const DANGER_EDGE = 0xffac71;
const AMBER = 0xffcc8b;

type SpriteOptions = { alpha?: number; angle?: number; tint?: number; depth?: number; frame?: number; originY?: number; flip?: boolean };
const progressOf = (age: number, duration: number): number => Math.min(1, Math.max(0, age / duration));
const chord = (radius: number, ordinate: number): number => Math.sqrt(Math.max(0, radius ** 2 - ordinate ** 2));
function loopFrame(asset: string, ageMs: number, framesPerSecond: number, offset = 0): number {
  return (Math.floor(Math.max(0, ageMs) * framesPerSecond / 1000) + offset) % (AssetManager.getAsset(asset)?.frameCount ?? 1);
}

/** Only make a cast hostile when both the danger and the route to safety can be shown. */
export function canShowDesertAttack(scene: Phaser.Scene, pattern: DesertPattern): boolean {
  const has = (asset: string): boolean => AssetManager.hasTexture(scene, asset);
  switch (pattern) {
    case "dune_wave": return has(WAVE);
    case "sand_cyclone": return has(RING) && has(CYCLONE);
    case "sandfall": return has(TELL) && has(STORM) && has(FALL);
    case "sand_siege": return has(STORM);
    case "sand_burrow": return has(FALL) || has(DUST);
    case "sand_cleave": return has("boss_desert_swing") || has(STRIKE);
  }
}

/** Bounded reusable bitmap layers. Telegraphs, safe spaces and hit shapes share one cast snapshot. */
export class DesertBossView {
  private readonly layers: Phaser.GameObjects.Image[] = [];
  private readonly marks: Phaser.GameObjects.Graphics;
  private used = 0;

  constructor(private readonly scene: Phaser.Scene) {
    this.marks = scene.add.graphics().setDepth(1.59);
  }

  draw(runtime: GameRuntime): void {
    this.marks.clear();
    this.used = 0;
    const duel = getBossDuel(runtime.world);
    if (duel?.stage === "desert") {
      const boss = runtime.world.components.monsters.get(duel.bossId)?.finalBossEncounter;
      const center = runtime.world.components.transforms.get(duel.bossId);
      if (!boss?.burrowed && center && boss?.sandArmor && boss.sandArmor.hp > 0) {
        const ratio = boss.sandArmor.hp / boss.sandArmor.max;
        this.drawImage(ARMOR, center.x, center.y + 22, 181, 92,
          { frame: loopFrame(ARMOR, runtime.stats.elapsedMs, 17), tint: 0xffd782, alpha: .55 + .4 * ratio, depth: 1.56 });
        this.marks.lineStyle(3, 0xffdc7f, .53 + .39 * ratio).strokeEllipse(center.x, center.y + 21, 151, 77);
      }
    }
    const cast = getDesertCast(runtime.world);
    if (!cast) {
      for (let i = this.used; i < this.layers.length; i++) this.layers[i].setVisible(false);
      return;
    }
    const age = cast.elapsedMs - cast.tellMs;
    const active = age >= 0;
    const progress = active ? progressOf(age, cast.activeMs) : progressOf(cast.elapsedMs, cast.tellMs);
    const { shape, arena } = cast;
    if (shape.kind === "dune_wave") this.wave(cast, shape, progress, active);
    else if (shape.kind === "sand_cyclone") this.cyclone(shape, progress, active, age);
    else if (shape.kind === "sandfall") this.sandfall(shape, progress, active, age);
    else if (shape.kind === "sand_siege") this.storm(shape, arena, progress, active, cast.elapsedMs);
    else this.strike(shape, progress, active, age, cast.arena);
    for (let i = this.used; i < this.layers.length; i++) this.layers[i].setVisible(false);
  }

  private strike(shape: DesertStrikeShape, p: number, active: boolean, age: number, arena: DesertCast["arena"]): void {
    const opacity = active ? .24 * (1 - p) : .2 + .13 * p;
    this.marks.fillStyle(0xbb341e, opacity).lineStyle(active ? 4 : 3, DANGER_EDGE, active ? .9 * (1 - p) : .92);
    if (shape.kind === "sand_cleave") {
      const { origin, angle, halfAngle, radius } = shape;
      const points = [origin, ...Array.from({ length: 25 }, (_, i) => {
        const a = angle - halfAngle + 2 * halfAngle * i / 24;
        const dx = origin.x - arena.x, dy = origin.y - arena.y, ux = Math.cos(a), uy = Math.sin(a);
        const dot = dx * ux + dy * uy;
        const limit = Math.max(0, -dot + Math.sqrt(Math.max(0, dot * dot + arena.radius ** 2 - dx * dx - dy * dy)));
        const reach = Math.min(radius, limit);
        return { x: origin.x + ux * reach, y: origin.y + uy * reach };
      })];
      this.marks.fillPoints(points, true).strokePoints(points, true);
      if (active) this.drawImage(STRIKE, origin.x + Math.cos(angle) * 72, origin.y + Math.sin(angle) * 72, 204, 177,
        { frame: Math.min(5, Math.floor(p * 6)), angle, alpha: 1 - p * .41, tint: 0xffdf9b, depth: 1.9 });
      return;
    }
    const { origin, center, radius } = shape;
    this.marks.fillCircle(center.x, center.y, radius).strokeCircle(center.x, center.y, radius);
    if (!active) {
      this.marks.lineStyle(3, 0xffba76, .84).strokeCircle(center.x, center.y, Math.max(6, radius * p));
      const path = Math.min(1, Math.max(0, (p - .13) / .78));
      this.drawImage(WHIRL, origin.x + (center.x - origin.x) * path, origin.y + (center.y - origin.y) * path, 148, 86,
        { frame: loopFrame(WHIRL, 1210 + age, 24), alpha: .88, depth: 1.64 });
    } else {
      this.drawImage(FALL, center.x, center.y + 37, radius * 2.9, radius * 2.47,
        { frame: Math.min(23, 6 + Math.floor(p * 17)), alpha: 1 - p * .35, originY: .86, depth: 1.79 });
      this.drawImage(DUST, center.x, center.y + 18, radius * (1.8 + p), radius * 1.31,
        { frame: Math.min(24, 3 + Math.floor(p * 20)), alpha: .94 * (1 - p), tint: AMBER, depth: 1.66 });
    }
  }

  private drawImage(asset: string, x: number, y: number, width: number, height: number, options: SpriteOptions = {}): void {
    if (width < 5 || height < 5 || !AssetManager.hasTexture(this.scene, asset)) return;
    const key = AssetManager.getTextureKey(asset);
    const index = this.used++;
    const image = this.layers[index] ?? (this.layers[index] = this.scene.add.image(x, y, key));
    image.setVisible(true).setTexture(key, options.frame).setPosition(x, y).setOrigin(.5, options.originY ?? .5)
      .setDisplaySize(width, height).setDepth(options.depth ?? 1.64).setAlpha(options.alpha ?? 1)
      .setRotation(options.angle ?? 0).setTint(options.tint ?? 0xffffff).setFlipX(options.flip ?? false);
  }

  private wave(cast: DesertCast, shape: Extract<DesertCast["shape"], { kind: "dune_wave" }>, p: number, active: boolean): void {
    const { x, y, radius } = cast.arena;
    const waveY = getWaveY({ ...cast, shape }, active ? p : .15 + p * .035);
    const span = chord(radius, waveY - y);
    const gapLeft = shape.gapX - shape.gapHalf, gapRight = shape.gapX + shape.gapHalf;
    const lo = 0.98 * Math.sqrt(Math.max(0, radius ** 2 - Math.min(Math.abs(gapLeft - x), Math.abs(gapRight - x)) ** 2));
    const edges = Array.from({ length: 33 }, (_, i) => {
      const row = y + (i / 16 - 1) * lo;
      const half = chord(radius, row - y);
      return { row, left: Math.max(gapLeft, x - half), right: Math.min(gapRight, x + half) };
    }).filter(edge => edge.right > edge.left);
    const lane = [...edges.map(e => ({ x: e.left, y: e.row })), ...edges.reverse().map(e => ({ x: e.right, y: e.row }))];
    this.marks.fillStyle(SAFE_FLOOR, active ? .25 : .30).fillPoints(lane, true)
      .lineStyle(4, SAFE_EDGE, .91).strokePoints(lane, true);
    // Breadcrumbs visibly connect the opening to a traversable lane, without laying a solid green stripe over the ground.
    for (let i = -3; i <= 3; i++) {
      const markerY = y + i * radius * .215;
      if (active && (markerY - waveY) * shape.direction < -55) continue;
      if (Math.abs(shape.gapX - x) + 23 < chord(radius, markerY - y)) {
        if (AssetManager.hasTexture(this.scene, WIND)) {
          this.drawImage(WIND, shape.gapX, markerY, 52, 23, { angle: -shape.direction * Math.PI / 2, tint: SAFE, alpha: active ? .67 : .48 + .33 * p, depth: 1.23 });
        } else {
          this.drawImage(RING, shape.gapX, markerY, 35, 17, { tint: SAFE, alpha: .58, depth: 1.23 });
        }
      }
    }
    const banks = [[x - span, Math.min(x + span, gapLeft)], [Math.max(x - span, gapRight), x + span]];
    for (const [left, right] of banks) {
      if (right <= left) continue;
      const width = right - left, cx = (left + right) / 2;
      const flip = cx > shape.gapX;
      const height = Math.min(active ? 196 : 112, width * (active ? .78 : .52));
      const waveClock = active ? cast.elapsedMs - cast.tellMs * (1 - 15 / 26) : cast.elapsedMs;
      const frame = loopFrame(WAVE, waveClock, active ? 26 : 15, flip ? 12 : 0);
      this.drawImage(WAVE, cx, waveY + shape.direction * 19, width, height,
        { frame, alpha: active ? 1 : .28 + .57 * p, originY: .76, depth: 1.75, flip });
      if (active) this.drawImage(STORM, cx, waveY - shape.direction * 22, width, shape.halfDepth * 2.5,
        { frame: loopFrame(STORM, cast.elapsedMs, 24, flip ? 9 : 0), alpha: .82, depth: 1.54, flip: !flip });
    }
    const cleftY = active ? waveY : y;
    if (Math.abs(shape.gapX - x) + shape.gapHalf < chord(radius, cleftY - y)) {
      this.drawImage(RING, shape.gapX, cleftY, shape.gapHalf * 1.96, 39,
        { tint: SAFE, alpha: active ? .91 : .49 + .33 * p, depth: 1.48 });
    }
  }

  private cyclone(shape: Extract<DesertCast["shape"], { kind: "sand_cyclone" }>, p: number, active: boolean, age: number): void {
    for (let i = 0; i <= 8; i++) {
      const step = i / 8;
      if (active && step < p) continue;
      const point = getCyclonePoint(shape, step);
      this.drawImage(RING, point.x, point.y, shape.radius * 2.25, shape.radius * 2.25,
        { tint: i % 2 === 0 ? 0xff8b58 : AMBER, alpha: active ? .21 : .24 + p * .28, depth: 1.28 });
    }
    const { x, y } = getCyclonePoint(shape, active ? p : 0);
    const fade = active ? Math.min(1, (1 - p) * 8 + .28) : .18 + p * .57;
    const motion = Math.max(0, age);
    this.drawImage(WHIRL, x, y, shape.radius * 2.98, shape.radius * 1.8,
      { frame: loopFrame(WHIRL, active ? motion + 690 : p * 690, 26), alpha: fade * .99, depth: 1.51 });
    this.drawImage(CYCLONE, x, y + 22, shape.radius * 2.95, shape.radius * 3.68,
      { frame: loopFrame(CYCLONE, active ? age : p * 900, active ? 26 : 20), alpha: fade, originY: .92, depth: 1.85 });
    if (active) this.drawImage(DUST, x, y + 8, shape.radius * 1.96, shape.radius * 1.40,
      { frame: 3 + Math.floor(motion / 51) % 15, tint: AMBER, alpha: fade * .62, depth: 1.68 });
  }

  private sandfall(shape: Extract<DesertCast["shape"], { kind: "sandfall" }>, p: number, active: boolean, age: number): void {
    const { center: { x, y }, angle, halfLength, halfWidth } = shape;
    const w = 2 * (halfLength + halfWidth), h = halfWidth * 2;
    this.drawImage(TELL, x, y, w * 1.065, h * 1.39, { angle, alpha: active ? .46 * (1 - p) : .53 + p * .42, depth: 1.28 });
    const dx = Math.cos(angle), dy = Math.sin(angle);
    for (let i = -1; i <= 1; i++) {
      const px = x + dx * i * halfLength * .74, py = y + dy * i * halfLength * .74;
      if (!active) {
        this.drawImage(STORM, px, py, w * .37, h * .51, { frame: loopFrame(STORM, p * 840, 19, (i + 1) * 7), angle, alpha: .28 + .5 * p, depth: 1.53, flip: true });
        continue;
      }
      const beat = Math.max(0, age - Math.abs(i) * 60);
      const impact = progressOf(beat, 790);
      if (impact < 1) {
        const count = AssetManager.getAsset(FALL)?.frameCount ?? 1;
        this.drawImage(FALL, px, py + 19, w * .61, 175 + halfWidth * 1.25,
          { frame: Math.min(count - 1, Math.floor(impact * count)), angle: angle * .32, originY: .91, alpha: .99, depth: 1.75, flip: i < 0 });
        this.drawImage(DUST, px, py + 11, w * (.30 + .16 * impact), h * 1.04,
          { frame: Math.min(24, 3 + Math.floor(beat / 21)), alpha: .72 * (1 - impact), tint: AMBER, depth: 1.68 });
      }
      this.drawImage(STORM, px, py, w * .42, h, { frame: loopFrame(STORM, age, 23, (i + 1) * 7), alpha: .76 - .35 * p, angle, depth: 1.44, flip: i < 0 });
    }
  }

  private storm(shape: Extract<DesertCast["shape"], { kind: "sand_siege" }>, arena: DesertCast["arena"], p: number, active: boolean, age: number): void {
    const { x, y, radius } = arena;
    // Cut the wind strips using the gameplay shelter positions, so clear pockets remain visibly clear.
    for (let i = -4; i <= 4; i++) {
      const sy = y + i * radius * .19 + Math.sin(i * 2.16) * 17 + shape.direction * (active ? p * 116 : p * 38);
      const half = chord(radius, sy - y);
      if (half < 24) continue;
      const height = active ? 142 : 88;
      let left = x - half;
      const paint = (a: number, b: number): void => {
        if (b - a < 17) return;
        const segments = Math.ceil((b - a) / 287);
        const span = (b - a) / segments;
        for (let n = 0; n < segments; n++) {
          const variation = .84 + .16 * Math.sin(i * 1.8 + n * 3.7);
          const opacity = (active ? .98 * (1 - p ** 3) : .16 + .43 * p) * variation;
          this.drawImage(STORM, a + span * (n + .5), sy, span, height,
            { frame: loopFrame(STORM, age, 26, (i + 4) * 7 + n * 3), alpha: opacity, flip: shape.direction < 0, depth: 1.40 });
        }
      };
      for (const shelter of shape.shelters) {
        const hole = chord(shelter.radius + 12, Math.max(0, Math.abs(sy - shelter.y) - height / 2));
        if (hole <= 0) continue;
        paint(left, Math.min(x + half, shelter.x - hole));
        left = Math.max(left, shelter.x + hole);
      }
      paint(left, x + half);
    }
    for (const safe of shape.shelters) {
      const width = safe.radius * 2.32;
      this.marks.fillStyle(SAFE_FLOOR, active ? .30 : .34).fillCircle(safe.x, safe.y, safe.radius)
        .lineStyle(4, SAFE_EDGE, .98).strokeCircle(safe.x, safe.y, safe.radius);
      this.drawImage(RING, safe.x, safe.y, width, width, { tint: SAFE, alpha: active ? .96 - p * .45 : .62 + .34 * p, depth: 1.60 });
      this.drawImage(WINDBREAK, safe.x, safe.y - shape.direction * (safe.radius + 6), 154, 51,
        { alpha: active ? .96 - p * .70 : .50 + .46 * p, depth: 1.69 });
    }
  }
}
