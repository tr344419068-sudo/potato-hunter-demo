import { createAoeWarning, createEnemyProjectile, createMonster } from "../entities/factories";
import { ConfigManager } from "../managers/ConfigManager";
import { EventBus } from "../managers/EventBus";
import { distanceSquared, normalize } from "../utils/math";
import type { EntityId } from "../components/ComponentTypes";
import { canReceiveHostileDamage, getHostileHitGraceMs } from "./PlayerDamageModel";
import type { GameRuntime, System } from "./SystemTypes";
import { getSummonAllowance } from "./MonsterRoleModel";
import { isNewEnemyRole, NewEnemyRoleSystem } from "./NewEnemyRoleSystem";
import { HOSTILE_PROJECTILE_CAP, HOSTILE_WARNING_CAP } from "./HostileHazardBudget";
import { emitEnemyMuzzle } from "./EnemyProjectileModel";

export class MonsterBehaviorSystem implements System {
  readonly telemetrySource = "MonsterBehaviorSystem";
  private readonly newEnemyRoles = new NewEnemyRoleSystem();
  update(deltaMs: number, runtime: GameRuntime): void {
    this.newEnemyRoles.update(deltaMs, runtime);
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    if (!playerTransform || !playerHealth) {
      return;
    }

    const monsters = [...runtime.world.components.monsters.entries()];
    for (const [entityId, monster] of monsters) {
      const transform = runtime.world.components.transforms.get(entityId);
      const velocity = runtime.world.components.velocities.get(entityId);
      if (!transform || !velocity || monster.isBoss || isNewEnemyRole(monster.behavior) || (runtime.world.components.health.get(entityId)?.current ?? 0) <= 0) {
        continue;
      }

      monster.behaviorTimerMs -= deltaMs;
      monster.stateTimerMs = Math.max(0, monster.stateTimerMs - deltaMs);

      if (monster.behavior === "flanker") this.updateFlanker(deltaMs, runtime, entityId, playerTransform.x, playerTransform.y);
      if (monster.behavior === "bombardier" && monster.behaviorTimerMs <= 0 && runtime.world.components.aoeWarnings.size < HOSTILE_WARNING_CAP && distanceSquared(transform.x, transform.y, playerTransform.x, playerTransform.y) <= 520 * 520) {
        const warningId = createAoeWarning(runtime.world, playerTransform.x, playerTransform.y, 62, monster.damage, 900);
        const warning = runtime.world.components.aoeWarnings.get(warningId)!;
        warning.sourceId = entityId; warning.label = "玉米投弹 · 离开橙圈"; warning.skipNextTick = true;
        warning.impactStyle = "bomb";
        monster.behaviorTimerMs = 3200;
      }

      if (monster.behavior === "charger") {
        this.updateCharger(monster.behaviorTimerMs <= 0, runtime, entityId, playerTransform.x, playerTransform.y);
      }

      if (monster.behavior === "exploder") {
        this.updateExploder(runtime, entityId, playerTransform.x, playerTransform.y);
      }

      if (monster.behavior === "ranged") {
        this.updateRanged(monster.behaviorTimerMs <= 0, runtime, entityId, playerTransform.x, playerTransform.y);
      }

      if (monster.behavior === "summoner") {
        this.updateSummoner(monster.behaviorTimerMs <= 0, runtime, entityId);
      }
    }
  }

  private updateFlanker(deltaMs: number, runtime: GameRuntime, entityId: EntityId, playerX: number, playerY: number): void {
    const monster = runtime.world.components.monsters.get(entityId)!;
    const transform = runtime.world.components.transforms.get(entityId)!;
    const velocity = runtime.world.components.velocities.get(entityId)!;
    const state = monster.roleState;
    if (state) {
      state.remainingMs -= deltaMs;
      if (state.stage !== "lunge") { velocity.x = 0; velocity.y = 0; }
      if (state.remainingMs > 0) return;
      if (state.stage === "windup") {
        if (state.warningId !== undefined) runtime.world.destroyEntity(state.warningId);
        state.stage = "lunge"; state.remainingMs = 250;
        monster.controlledMotionRemainingMs = 250;
        velocity.x = state.directionX * 290; velocity.y = state.directionY * 290;
        EventBus.emit("hostile:lunge", { x: transform.x, y: transform.y, angle: Math.atan2(state.directionY, state.directionX) });
      } else if (state.stage === "lunge") {
        state.stage = "recovery"; state.remainingMs = 650;
        monster.controlledMotionRemainingMs = undefined;
        velocity.x = 0; velocity.y = 0;
      } else {
        monster.roleState = undefined; monster.controlledMotion = false; monster.behaviorTimerMs = 2600;
      }
      return;
    }
    if (monster.behaviorTimerMs > 0 || runtime.world.components.aoeWarnings.size >= HOSTILE_WARNING_CAP || distanceSquared(transform.x, transform.y, playerX, playerY) > 240 * 240) return;
    const direction = normalize(playerX - transform.x, playerY - transform.y);
    const warningId = createAoeWarning(runtime.world, transform.x, transform.y, 28, 0, 800);
    const contactPadding = transform.radius + runtime.world.components.transforms.get(runtime.playerId)!.radius;
    const label = runtime.world.components.renders.get(entityId)?.assetId === "enemy_desert_scorpion" ? "沙蝎侧袭 · 即将突进" : "洋葱侧袭 · 即将突进";
    Object.assign(runtime.world.components.aoeWarnings.get(warningId)!, { sourceId: entityId, shape: "rectangle", angle: Math.atan2(direction.y, direction.x), length: 72.5, width: contactPadding * 2, contactPadding, label, skipNextTick: true });
    monster.roleState = { stage: "windup", remainingMs: 800, directionX: direction.x, directionY: direction.y, warningId };
    monster.controlledMotion = true; velocity.x = 0; velocity.y = 0;
  }

  private updateCharger(ready: boolean, runtime: GameRuntime, entityId: EntityId, playerX: number, playerY: number): void {
    const monster = runtime.world.components.monsters.get(entityId);
    const transform = runtime.world.components.transforms.get(entityId);
    const velocity = runtime.world.components.velocities.get(entityId);
    if (!monster || !transform || !velocity) {
      return;
    }

    if (monster.stateTimerMs > 0) {
      return;
    }

    if (!ready || distanceSquared(transform.x, transform.y, playerX, playerY) > 520 * 520) {
      return;
    }

    const direction = normalize(playerX - transform.x, playerY - transform.y);
    velocity.x = direction.x * 420;
    velocity.y = direction.y * 420;
    monster.stateTimerMs = 360;
    monster.behaviorTimerMs = 2200;
    runtime.world.components.hitFlashes.set(entityId, { remainingMs: 130, totalMs: 130 });
  }

  private updateExploder(runtime: GameRuntime, entityId: EntityId, playerX: number, playerY: number): void {
    const transform = runtime.world.components.transforms.get(entityId);
    const monster = runtime.world.components.monsters.get(entityId);
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    const player = runtime.world.components.players.get(runtime.playerId);
    if (!transform || !monster || !playerHealth || !player) {
      return;
    }

    if (distanceSquared(transform.x, transform.y, playerX, playerY) > 58 * 58) {
      return;
    }

    if (canReceiveHostileDamage(player)) {
      playerHealth.current -= monster.damage * 2.2;
      player.damageCooldownMs = getHostileHitGraceMs("explosion");
      EventBus.emit("combat:damage", { x: playerX, y: playerY, value: Math.ceil(monster.damage * 2.2), color: "#ef476f", isCrit: true, targetId: runtime.playerId, category: "incoming" });
    }
    EventBus.emit("fx:sparks", { x: transform.x, y: transform.y, color: 0xef476f, count: 18, size: 9 });
    const render = runtime.world.components.renders.get(entityId);
    if (render) {
      EventBus.emit("juice:death", { x: transform.x, y: transform.y, render: { ...render } });
    }
    runtime.world.destroyEntity(entityId);
  }

  private updateRanged(ready: boolean, runtime: GameRuntime, entityId: EntityId, playerX: number, playerY: number): void {
    const transform = runtime.world.components.transforms.get(entityId);
    const monster = runtime.world.components.monsters.get(entityId);
    if (!ready || !transform || !monster || runtime.world.components.enemyProjectiles.size >= HOSTILE_PROJECTILE_CAP) {
      return;
    }

    if (distanceSquared(transform.x, transform.y, playerX, playerY) > 640 * 640) {
      return;
    }

    const angle = Math.atan2(playerY - transform.y, playerX - transform.x);
    createEnemyProjectile(runtime.world, transform.x, transform.y, Math.cos(angle) * 240, Math.sin(angle) * 240, monster.damage, 1800, "cola");
    emitEnemyMuzzle(transform.x, transform.y, angle, "cola");
    monster.behaviorTimerMs = 1800;
  }

  private updateSummoner(ready: boolean, runtime: GameRuntime, entityId: EntityId): void {
    const transform = runtime.world.components.transforms.get(entityId);
    const monster = runtime.world.components.monsters.get(entityId);
    if (!ready || !transform || !monster) {
      return;
    }

    const config = ConfigManager.getMonster("fries_cultist");
    const count = getSummonAllowance(runtime, 2);
    for (let index = 0; index < count; index += 1) {
      const angle = (runtime.random ?? Math.random)() * Math.PI * 2;
      createMonster(runtime.world, config, transform.x + Math.cos(angle) * 42, transform.y + Math.sin(angle) * 42);
    }
    runtime.world.components.hitFlashes.set(entityId, { remainingMs: 150, totalMs: 150 });
    monster.behaviorTimerMs = 3600;
  }
}
