import type Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import { getHeroFilmGroundOffset, HERO_FILM, HeroFilmMotion, K1_FOOT, K1_DISPLAY_SCALE, heroFilmAsset, type HeroFilmAction, type HeroFilmAim } from "./HeroFilmModel";

interface HeroFilmInput {
  entityId: number; x: number; y: number; worldY: number; visualSize: number;
  facingX: -1 | 1; alpha: number; deltaMs: number;
  dashRemainingMs: number; dashDirectionX: number; hp: number;
  windup?: HeroFilmAim; release?: HeroFilmAim;
}
const actions = Object.keys(HERO_FILM) as HeroFilmAction[];

export function supportsHeroFilm(scene: Phaser.Scene | undefined, assetId?: string): boolean {
  // A coherent look: never swap back to the old hero in the middle of one action.
  return assetId === "char_potato_hunter" && Boolean(scene?.textures?.getFrame && actions.every(action => {
    const id = heroFilmAsset(action);
    const last = HERO_FILM[action].frameMs.length - 1;
    return AssetManager.hasTexture(scene, id) && String(scene.textures.getFrame(AssetManager.getTextureKey(id), last)?.name) === String(last);
  }));
}

export function getHeroFilmGroundY(y: number, assetId: string | undefined, size: number): number {
  return y + (AssetManager.getFootPoint(assetId).y - AssetManager.getPivot(assetId).y) * size;
}

export class HeroFilmView {
  private image?: Phaser.GameObjects.Image;
  private model = new HeroFilmMotion();
  private entityId?: number;
  private previous?: { x: number; y: number };
  private previousHp?: number;

  constructor(private readonly scene: Phaser.Scene) {
    scene.events?.once("shutdown", () => this.clear());
  }

  draw(input: HeroFilmInput): void {
    if (this.entityId !== input.entityId) this.clear();
    this.entityId = input.entityId;
    const speed = input.deltaMs > 0 && this.previous
      ? Math.hypot(input.x - this.previous.x, input.worldY - this.previous.y) * 1000 / input.deltaMs : 0;
    this.previous = { x: input.x, y: input.worldY };
    const hit = this.previousHp !== undefined && input.hp < this.previousHp;
    if (input.deltaMs > 0 || this.previousHp === undefined) this.previousHp = input.hp;
    const pose = this.model.update({ ...input, hit, dead: input.hp <= 0, speed });
    const texture = AssetManager.getTextureKey(heroFilmAsset(pose.action));
    const sprite = this.image ??= this.scene.add.image(input.x, input.y, texture, pose.frame).setOrigin(K1_FOOT.x, K1_FOOT.y).setDepth(2.01);
    if (sprite.texture.key !== texture) sprite.setTexture(texture, pose.frame);
    else if (String(sprite.frame.name) !== String(pose.frame)) sprite.setFrame(pose.frame);
    const size = input.visualSize * K1_DISPLAY_SCALE;
    const soleY = input.y + getHeroFilmGroundOffset(pose.action, pose.frame) * size;
    sprite.setPosition(input.x, soleY).setDisplaySize(size, size).setFlipX(pose.facingX > 0).setAlpha(input.alpha);
  }

  clear(): void {
    if (!this.image && this.entityId === undefined) return;
    this.image?.destroy();
    this.image = undefined;
    this.entityId = undefined;
    this.previous = undefined;
    this.previousHp = undefined;
    this.model = new HeroFilmMotion();
  }
}
