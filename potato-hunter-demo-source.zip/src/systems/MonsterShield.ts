import type { MonsterComponent, TransformComponent } from "../components/ComponentTypes";
import { EventBus } from "../managers/EventBus";

/** Returns absorbed damage; the visual fires exactly once when a shield reaches zero. */
export function absorbMonsterShield(monster: MonsterComponent | undefined, transform: TransformComponent, damage: number): number {
  if (!monster?.shieldHp || monster.shieldHp <= 0 || damage <= 0) return 0;
  const absorbed = Math.min(monster.shieldHp, damage);
  monster.shieldHp -= absorbed;
  if (monster.shieldHp === 0) EventBus.emit("combat:shield-break", { x: transform.x, y: transform.y, radius: transform.radius });
  return absorbed;
}
