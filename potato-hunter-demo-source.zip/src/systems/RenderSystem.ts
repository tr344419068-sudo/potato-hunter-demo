import Phaser from "phaser";
import type { MapEventComponent, RenderComponent, TransformComponent, VelocityComponent } from "../components/ComponentTypes";
import { AssetManager } from "../managers/AssetManager";
import { getCharacterGroundPoint, getCharacterShadowProfile, type CharacterShadowKind } from "./ShadowProfileModel";
import { getPickupPresentation } from "./PickupPresentationModel";
import { getChargeWarningEnvelope } from "./MonsterRoleModel";
import { CharacterMeshView } from "./CharacterMeshView";
import { AuthoredHeroView } from "./AuthoredHeroView";
import { getProjectileDrawPoint, isLongSkewer, isPepperWeapon } from "./WeaponPresentationModel";
import { SpatialSkillView } from "./SpatialSkillView";
import { HostileWarningView } from "./HostileWarningView";
import { BossDuelView, drawHeroHealthAtFeet } from "./BossDuelView";
import { DesertBossView } from "./DesertBossView";
import { DESERT_BURROW_SINK_MS, getDesertCast } from "./DesertBossEncounter";
import { getBossDuel } from "./BossDuelArena";
import { ELITE_DEATH_BOMB_RADIUS } from "./EliteHazardModel";
import type { GameRuntime, System } from "./SystemTypes";

export class RenderSystem implements System {
  private readonly overlayGraphics: Phaser.GameObjects.Graphics;
  private readonly sprites = new Map<number, Phaser.GameObjects.Image>();
  private readonly pickupLabels = new Map<number, Phaser.GameObjects.Text>();
  private readonly roleLabels = new Map<number, Phaser.GameObjects.Text>();
  private readonly warningLabels = new Map<number, Phaser.GameObjects.Text>();
  private readonly characterMeshes: CharacterMeshView;
  private readonly authoredHero: AuthoredHeroView;
  private readonly spatialSkills: SpatialSkillView;
  private readonly duel: BossDuelView;
  private readonly desertDuel: DesertBossView;
  private readonly hostileWarnings: HostileWarningView;

  constructor(private readonly scene: Phaser.Scene, private readonly graphics: Phaser.GameObjects.Graphics) {
    this.graphics.setDepth(1);
    this.overlayGraphics = scene.add.graphics();
    this.overlayGraphics.setDepth(4);
    this.characterMeshes = new CharacterMeshView(scene);
    this.authoredHero = new AuthoredHeroView(scene);
    this.spatialSkills = new SpatialSkillView(scene);
    this.duel = new BossDuelView(scene);
    this.desertDuel = new DesertBossView(scene);
    this.hostileWarnings = new HostileWarningView(scene);
  }

  update(deltaMs: number, runtime: GameRuntime): void {
    this.graphics.clear();
    this.overlayGraphics.clear();
    this.duel.draw(runtime);
    this.desertDuel.draw(runtime);
    this.drawAoeWarnings(runtime);
    if (!getBossDuel(runtime.world)) this.drawPickupRadius(runtime);
    this.drawAura(runtime);
    this.spatialSkills.draw(this.graphics, runtime.world, this.overlayGraphics);
    const activeSpriteEntities = new Set<number>();
    const activeMeshEntities = new Set<number>();
    const activeAuthoredHeroes = new Set<number>();
    const activePickupLabels = new Set<number>();
    const arena = getBossDuel(runtime.world);
    const desert = getDesertCast(runtime.world);

    for (const [entityId, render] of runtime.world.components.renders) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform) {
        continue;
      }

      if (runtime.world.components.enemyProjectiles.has(entityId)) {
        const velocity = runtime.world.components.velocities.get(entityId);
        const remainingMs = runtime.world.components.lifetimes.get(entityId)?.remainingMs ?? 120;
        if (this.drawEnemyProjectile(entityId, transform, render, velocity, remainingMs)) activeSpriteEntities.add(entityId);
        continue;
      }

      const mapEvent = runtime.world.components.mapEvents.get(entityId);
      const orb = runtime.world.components.experienceOrbs.get(entityId);
      if (mapEvent || orb) {
        const pickup = mapEvent ? getPickupPresentation(mapEvent.kind) : undefined;
        const size = mapEvent ? Math.max(46, render.size * 1.18) : Math.min(24, render.size + Math.max(0, (orb?.value ?? 1) - 1));
        const bob = Math.sin(runtime.stats.elapsedMs * 0.005 + entityId * 0.7) * (mapEvent ? 2.8 : 1.2);
        const spriteY = transform.y - (mapEvent ? 12 : 5) - bob;
        this.drawPickupGround(transform.x, transform.y, size, pickup?.color ?? 0x69e8ff, runtime.stats.elapsedMs, entityId, Boolean(mapEvent));
        if (AssetManager.hasTexture(runtime.scene, render.assetId)) {
          activeSpriteEntities.add(entityId);
          this.drawSprite(entityId, render.assetId!, transform.x, spriteY, size, 1, 1, 0, undefined, 1);
        } else {
          this.hideSprite(entityId);
          if (mapEvent) {
            this.drawMapEvent(mapEvent.kind, transform.x, transform.y, render.size, runtime.stats.elapsedMs);
          } else {
            this.graphics.fillStyle(0x69e8ff, 1);
            this.graphics.fillCircle(transform.x, spriteY, 5);
          }
        }
        if (pickup) {
          activePickupLabels.add(entityId);
          this.drawPickupLabel(entityId, pickup.label, transform.x, transform.y + size * 0.64);
        }
        continue;
      }

      const flash = runtime.world.components.hitFlashes.get(entityId);
      const flashRatio = flash ? Math.max(0, flash.remainingMs / flash.totalMs) : 0;
      const statusColor = this.getStatusColor(runtime, entityId);
      const drawColor = flashRatio > 0 ? 0xffffff : statusColor ?? render.color;
      const drawSize = render.size * (1 + flashRatio * 0.18);
      const role = runtime.world.components.monsters.get(entityId);
      const swing = role?.finalBossEncounter;
      if (swing?.burrowed) continue;
      const burrow = desert?.bossId === entityId && desert.shape.kind === "sand_burrow" ? desert : undefined;
      const sink = burrow && burrow.elapsedMs < DESERT_BURROW_SINK_MS ? burrow.elapsedMs / DESERT_BURROW_SINK_MS : 0;
      const emerge = burrow && burrow.elapsedMs >= burrow.tellMs ? Math.max(0, 1 - (burrow.elapsedMs - burrow.tellMs) / 190) : 0;
      const waitingOutside = Boolean(arena && role && entityId !== arena.bossId);
      const alpha = (render.alpha ?? 1) * (waitingOutside ? .45 : 1) * (1 - sink * .92);
      const hasRoleTint = !role?.isBoss && render.assetId !== "enemy_desert_scorpion" && ["guard", "flanker", "bombardier"].includes(role?.behavior ?? "");
      const spriteTint = flashRatio > 0 || statusColor !== undefined ? drawColor : hasRoleTint ? render.color : undefined;
      const juice = runtime.world.components.spriteJuices.get(entityId);
      const offsetX = juice?.offsetX ?? 0;
      const offsetY = (juice?.offsetY ?? 0) + sink * 49 - emerge * 24;
      const scaleX = juice?.scaleX ?? 1;
      const scaleY = (juice?.scaleY ?? 1) * (1 - sink * .68 + emerge * .11);
      const swingAsset = render.assetId === "boss_desert_sultan" ? "boss_desert_swing" : render.assetId === "boss_burger_tyrant_v4" ? "boss_meadow_swing" : undefined;
      const useSwingFrame = swing?.swingFrame !== undefined && AssetManager.hasTexture(runtime.scene, swingAsset);
      const facingX = swing?.swingFacing ?? juice?.facingX ?? 1;
      const velocity = runtime.world.components.velocities.get(entityId);
      const projectile = runtime.world.components.projectiles.get(entityId);
      const projectileRotation = projectile && velocity
        ? Math.atan2(velocity.y, velocity.x)
        : 0;
      const rotation = projectileRotation + (isPepperWeapon(projectile?.skillId) || isLongSkewer(projectile?.skillId) ? 0 : juice?.rotation ?? 0);
      const visual = projectile ? getProjectileDrawPoint(transform, projectile, runtime.world.components.lifetimes.get(entityId)?.remainingMs ?? 0) : transform;
      if (!visual) { this.hideSprite(entityId); continue; }
      const drawX = visual.x + offsetX;
      const drawY = visual.y + offsetY;
      const hasTexture = AssetManager.hasTexture(runtime.scene, render.assetId);
      const articulatedHero = hasTexture && this.authoredHero.supports(render.assetId!);

      if (!waitingOutside) this.drawMonsterGroundCue(runtime, entityId, drawX, drawY, drawSize);

      const monster = runtime.world.components.monsters.get(entityId);
      if (runtime.world.components.players.has(entityId) || monster) {
        const visualSize = hasTexture ? AssetManager.getDisplaySize(render.assetId, render.size) : render.size;
        const shadowKind: CharacterShadowKind = runtime.world.components.players.has(entityId)
          ? "hero"
          : monster?.isBoss
            ? "boss"
            : monster?.isElite
              ? "elite"
              : "monster";
        const ground = getCharacterGroundPoint({
          x: articulatedHero ? transform.x : drawX,
          y: articulatedHero ? transform.y : transform.y + Math.max(0, offsetY),
          visualSize,
          pivot: hasTexture ? AssetManager.getPivot(render.assetId) : { x: 0.5, y: 0.5 },
          footPoint: hasTexture ? AssetManager.getFootPoint(render.assetId) : { x: 0.5, y: 1 },
          scaleX: (articulatedHero ? 1 : scaleX) * facingX,
          scaleY: articulatedHero ? 1 : scaleY,
          rotation: articulatedHero ? 0 : rotation,
        });
        this.drawCharacterShadow(
          ground.x,
          ground.y,
          visualSize,
          shadowKind,
          articulatedHero ? 0 : Math.max(0, -offsetY / Math.max(1, visualSize * 0.09)),
          articulatedHero ? 1 : juice?.shadowScaleX ?? 1,
          articulatedHero ? 1 : juice?.shadowScaleY ?? 1,
        );
        const health = runtime.world.components.health.get(entityId);
        if (entityId === runtime.playerId && runtime.campaign && health) {
          drawHeroHealthAtFeet(this.overlayGraphics, transform.x, ground.y, visualSize, health);
        }
      }

      if (hasTexture) {
        const heroDrawn = this.authoredHero.draw({
          entityId, assetId: render.assetId!, x: transform.x, y: transform.y,
          worldX: transform.x, worldY: transform.y, visualSize: AssetManager.getDisplaySize(render.assetId, render.size),
          pivot: AssetManager.getPivot(render.assetId), facingX, alpha: render.alpha ?? 1, deltaMs,
          attack: juice?.limbAttack ?? 0, attackSequence: juice?.attackSequence, attackProgress: juice?.attackProgress, weaponReleaseSequence: juice?.weaponReleaseSequence, tint: spriteTint,
          dead: (runtime.world.components.health.get(entityId)?.current ?? 1) <= 0,
          dashing: (runtime.world.components.players.get(entityId)?.dashRemainingMs ?? 0) > 0,
          hit: Boolean(flash),
        });
        if (heroDrawn) { activeAuthoredHeroes.add(entityId); this.hideSprite(entityId); continue; }
        const meshDrawn = this.characterMeshes.draw({
          entityId, assetId: render.assetId!, textureKey: AssetManager.getTextureKey(render.assetId!),
          x: drawX, y: drawY, worldX: transform.x, worldY: transform.y,
          visualSize: AssetManager.getDisplaySize(render.assetId, drawSize), pivot: AssetManager.getPivot(render.assetId),
          scaleX: scaleX * facingX, scaleY, rotation, tint: spriteTint, alpha,
          deltaMs, attack: juice?.limbAttack,
        });
        if (meshDrawn) {
          activeMeshEntities.add(entityId);
          this.hideSprite(entityId);
        } else {
          activeSpriteEntities.add(entityId);
          this.drawSprite(entityId, useSwingFrame ? swingAsset! : render.assetId!, drawX, drawY, drawSize, scaleX * facingX, scaleY, rotation, spriteTint, alpha, useSwingFrame ? swing?.swingFrame : undefined);
        }
      } else {
        this.hideSprite(entityId);
        this.graphics.fillStyle(drawColor, alpha);

        if (render.shape === "square") {
          this.graphics.fillRect(drawX - (drawSize * scaleX) / 2, drawY - (drawSize * scaleY) / 2, drawSize * scaleX, drawSize * scaleY);
        } else {
          this.graphics.fillEllipse(drawX, drawY, drawSize * scaleX, drawSize * scaleY);
        }
      }

      if (waitingOutside) { this.roleLabels.get(entityId)?.setVisible(false); continue; }
      this.drawEliteAffix(runtime, entityId, drawX, drawY, drawSize);
      this.drawRoleMarker(runtime, entityId, drawX, drawY, AssetManager.getDisplaySize(render.assetId, drawSize));

      const health = runtime.world.components.health.get(entityId);
      if (health && health.current < health.max && arena?.bossId !== entityId && !runtime.world.components.players.has(entityId)) {
        const barWidth = render.size;
        const percent = Math.max(0, health.current / health.max);
        this.overlayGraphics.fillStyle(0x161a20, 0.9);
        this.overlayGraphics.fillRect(transform.x - barWidth / 2, transform.y - render.size / 2 - 9, barWidth, 4);
        this.overlayGraphics.fillStyle(0x9bde7e, 1);
        this.overlayGraphics.fillRect(transform.x - barWidth / 2, transform.y - render.size / 2 - 9, barWidth * percent, 4);
      }
    }

    this.destroyInactiveSprites(activeSpriteEntities);
    this.characterMeshes.prune(activeMeshEntities);
    this.authoredHero.prune(activeAuthoredHeroes);
    for (const [entityId, label] of this.pickupLabels) {
      if (!activePickupLabels.has(entityId)) {
        label.destroy();
        this.pickupLabels.delete(entityId);
      }
    }
    for (const [entityId, label] of this.roleLabels) {
      if (!runtime.world.components.monsters.has(entityId)) { label.destroy(); this.roleLabels.delete(entityId); }
    }
  }

  private drawRoleMarker(runtime: GameRuntime, entityId: number, x: number, y: number, size: number): void {
    const monster = runtime.world.components.monsters.get(entityId);
    if (!monster || monster.isBoss || !["guard", "flanker", "bombardier"].includes(monster.behavior)) return;
    const color = monster.behavior === "guard" ? 0x89cfff : monster.behavior === "flanker" ? 0xb4f46d : 0xffb34d;
    const markerY = y - size * 0.53;
    const labelText = monster.behavior === "guard" ? (monster.shieldHp ? "冰盾" : "破盾") : monster.behavior === "flanker" ? "侧袭" : "投弹";
    let label = this.roleLabels.get(entityId);
    if (!label) {
      label = this.scene.add.text(0, 0, labelText, { fontFamily: '"PingFang SC", sans-serif', fontSize: "10px", color: "#f3f8ee", stroke: "#10233f", strokeThickness: 3 }).setOrigin(0.5).setDepth(4);
      this.roleLabels.set(entityId, label);
    }
    label.setVisible(true).setText(labelText).setPosition(x, markerY - 9);
    this.overlayGraphics.lineStyle(2, color, 0.9);
    if (monster.behavior === "guard" && (monster.shieldHp ?? 0) > 0) {
      this.overlayGraphics.fillStyle(color, 0.16);
      this.overlayGraphics.fillRoundedRect(x + size * 0.17, y - size * 0.29, size * 0.3, size * 0.37, 6);
      this.overlayGraphics.strokeRoundedRect(x + size * 0.17, y - size * 0.29, size * 0.3, size * 0.37, 6);
    } else if (monster.behavior === "flanker") {
      this.overlayGraphics.lineBetween(x - 9, markerY + 1, x - 3, markerY + 5);
      this.overlayGraphics.lineBetween(x + 9, markerY + 1, x + 3, markerY + 5);
    } else if (monster.behavior === "bombardier") {
      this.overlayGraphics.strokeCircle(x, markerY + 6, 5);
      this.overlayGraphics.lineBetween(x + 2, markerY + 1, x + 7, markerY - 3);
    }
  }

  private drawPickupGround(x: number, y: number, size: number, color: number, elapsedMs: number, entityId: number, major: boolean): void {
    const floorY = y + size * 0.22;
    this.graphics.fillStyle(0x020805, major ? 0.34 : 0.2);
    this.graphics.fillEllipse(x, floorY, size * 0.82, size * 0.18);
    const pulse = 1 + Math.sin(elapsedMs * 0.005 + entityId) * 0.08;
    this.graphics.fillStyle(color, major ? 0.12 : 0.09);
    this.graphics.fillEllipse(x, floorY, size * 1.38 * pulse, size * 0.45 * pulse);
    if (major) {
      this.graphics.lineStyle(2, color, 0.58);
      this.graphics.strokeEllipse(x, floorY, size * 1.2 * pulse, size * 0.36 * pulse);
      this.graphics.lineStyle(7, color, 0.065);
      this.graphics.lineBetween(x, floorY, x, y - size * 0.8);
      const sparkleX = x + Math.cos(elapsedMs * 0.002 + entityId) * size * 0.5;
      const sparkleY = y - size * 0.38;
      this.overlayGraphics.lineStyle(2, 0xfff5d6, 0.68);
      this.overlayGraphics.lineBetween(sparkleX - 4, sparkleY, sparkleX + 4, sparkleY);
      this.overlayGraphics.lineBetween(sparkleX, sparkleY - 4, sparkleX, sparkleY + 4);
    }
  }

  private drawPickupLabel(entityId: number, text: string, x: number, y: number): void {
    let label = this.pickupLabels.get(entityId);
    if (!label) {
      label = this.scene.add.text(x, y, text, {
        fontFamily: "Arial Rounded MT Bold, Trebuchet MS, sans-serif",
        fontSize: "11px", fontStyle: "bold", color: "#fff5d6", stroke: "#10233f", strokeThickness: 3,
      }).setOrigin(0.5).setDepth(3);
      this.pickupLabels.set(entityId, label);
    }
    label.setPosition(x, y);
  }

  private drawMonsterGroundCue(runtime: GameRuntime, entityId: number, x: number, y: number, size: number): void {
    const monster = runtime.world.components.monsters.get(entityId);
    if (!monster || monster.isBoss) {
      return;
    }

    const pulse = 1 + Math.sin(runtime.stats.elapsedMs * 0.006 + entityId) * 0.06;
    if (!monster.isElite || !monster.eliteAffix) {
      return;
    }

    const colors: Record<NonNullable<typeof monster.eliteAffix>, number> = {
      shield: 0xc77dff,
      haste: 0xffd166,
      split: 0x4cc9f0,
      death_bomb: 0xff5a36,
    };
    const color = colors[monster.eliteAffix];
    this.graphics.lineStyle(7, color, 0.12);
    this.graphics.strokeCircle(x, y + size * 0.08, size * 0.62 * pulse);
    this.graphics.lineStyle(2, color, 0.54);
    this.graphics.strokeCircle(x, y + size * 0.08, size * 0.62 * pulse);
  }

  private drawEliteAffix(runtime: GameRuntime, entityId: number, x: number, y: number, size: number): void {
    const monster = runtime.world.components.monsters.get(entityId);
    if (!monster?.isElite || !monster.eliteAffix) {
      return;
    }

    const pulse = 1 + Math.sin(runtime.stats.elapsedMs * 0.01 + entityId * 0.7) * 0.08;
    const radius = size * 0.58 * pulse;
    switch (monster.eliteAffix) {
      case "shield": {
        const shieldRatio = Phaser.Math.Clamp((monster.shieldHp ?? 0) / Math.max(1, runtime.world.components.health.get(entityId)?.max ?? 1), 0, 1);
        this.overlayGraphics.lineStyle(5, 0xc77dff, 0.34 + shieldRatio * 0.42);
        this.overlayGraphics.strokeCircle(x, y, radius);
        this.overlayGraphics.lineStyle(2, 0xf1dcff, 0.82);
        this.overlayGraphics.strokeCircle(x, y, radius - 5);
        this.overlayGraphics.fillStyle(0xf1dcff, 0.92);
        this.overlayGraphics.fillTriangle(x - 6, y - radius - 7, x + 6, y - radius - 7, x, y - radius + 4);
        break;
      }
      case "haste":
        this.overlayGraphics.lineStyle(4, 0xffd166, 0.92);
        for (let index = 0; index < 3; index += 1) {
          const arrowX = x - radius - 10 - index * 7;
          const arrowY = y + 6 + index * 5;
          this.overlayGraphics.lineBetween(arrowX - 8, arrowY - 6, arrowX, arrowY);
          this.overlayGraphics.lineBetween(arrowX - 8, arrowY + 6, arrowX, arrowY);
        }
        break;
      case "split":
        this.overlayGraphics.lineStyle(3, 0x9bf6ff, 0.9);
        this.overlayGraphics.strokeCircle(x - 7, y - radius - 6, 6);
        this.overlayGraphics.strokeCircle(x + 7, y - radius - 6, 6);
        this.overlayGraphics.lineBetween(x, y - radius, x, y - radius + 11);
        break;
      case "death_bomb": {
        const center = runtime.world.components.transforms.get(entityId);
        if (center) {
          // Static perimeter, not a windup. The marker follows the gameplay transform.
          for (let i = 0; i < 4; i++) {
            const angle = Math.PI * (.25 + .5 * i);
            this.overlayGraphics.lineStyle(4, 0x311318, .6).beginPath()
              .arc(center.x, center.y, ELITE_DEATH_BOMB_RADIUS, angle - .13, angle + .13).strokePath();
            this.overlayGraphics.lineStyle(2, 0xff8359, .78).beginPath()
              .arc(center.x, center.y, ELITE_DEATH_BOMB_RADIUS, angle - .13, angle + .13).strokePath();
          }
        }
        this.overlayGraphics.lineStyle(4, 0xff5a36, 0.8);
        this.overlayGraphics.strokeCircle(x, y, radius + 4);
        this.overlayGraphics.fillStyle(0xffead6, 0.96);
        this.overlayGraphics.fillTriangle(x - 7, y - radius - 12, x + 7, y - radius - 12, x, y - radius + 2);
        this.overlayGraphics.fillStyle(0x7a1d12, 1);
        this.overlayGraphics.fillCircle(x, y - radius - 7, 2.2);
        break;
      }
    }
  }

  private drawMapEvent(
    kind: MapEventComponent["kind"],
    x: number,
    y: number,
    size: number,
    elapsedMs: number,
  ): void {
    const pulse = 1 + Math.sin(elapsedMs * 0.008 + x * 0.01) * 0.08;
    const radius = Math.max(22, size * 0.58) * pulse;
    const graphics = this.overlayGraphics;

    this.graphics.fillStyle(0x071b13, 0.3);
    this.graphics.fillEllipse(x, y + radius * 0.78, radius * 1.7, radius * 0.48);
    this.graphics.fillStyle(0xffd166, 0.08);
    this.graphics.fillCircle(x, y, radius * 1.45);
    this.graphics.lineStyle(3, 0xffe29a, 0.48);
    this.graphics.strokeCircle(x, y, radius * 1.22);

    switch (kind) {
      case "supply":
        graphics.fillStyle(0x5b351d, 1);
        graphics.fillRoundedRect(x - radius * 0.74, y - radius * 0.38, radius * 1.48, radius * 1.02, 6);
        graphics.fillStyle(0xd99536, 1);
        graphics.fillRoundedRect(x - radius * 0.68, y - radius * 0.54, radius * 1.36, radius * 0.5, 7);
        graphics.lineStyle(3, 0xffdc73, 1);
        graphics.strokeRoundedRect(x - radius * 0.68, y - radius * 0.54, radius * 1.36, radius * 1.18, 7);
        graphics.fillStyle(0xffdc73, 1);
        graphics.fillRoundedRect(x - radius * 0.14, y - radius * 0.1, radius * 0.28, radius * 0.42, 3);
        break;
      case "heal":
        graphics.fillStyle(0xd94255, 1);
        graphics.fillCircle(x, y, radius * 0.72);
        graphics.lineStyle(3, 0x741f2d, 1);
        graphics.strokeCircle(x, y, radius * 0.72);
        graphics.fillStyle(0xfff3dd, 1);
        graphics.fillRoundedRect(x - radius * 0.11, y - radius * 0.43, radius * 0.22, radius * 0.86, 3);
        graphics.fillRoundedRect(x - radius * 0.43, y - radius * 0.11, radius * 0.86, radius * 0.22, 3);
        break;
      case "magnet":
        graphics.lineStyle(Math.max(6, radius * 0.28), 0x5ce1e6, 1);
        graphics.lineBetween(x - radius * 0.48, y - radius * 0.46, x - radius * 0.48, y + radius * 0.3);
        graphics.lineBetween(x + radius * 0.48, y - radius * 0.46, x + radius * 0.48, y + radius * 0.3);
        graphics.lineStyle(Math.max(5, radius * 0.22), 0x5ce1e6, 1);
        graphics.strokeEllipse(x, y + radius * 0.24, radius * 0.96, radius * 0.82);
        graphics.fillStyle(0xff6b6b, 1);
        graphics.fillRoundedRect(x - radius * 0.64, y - radius * 0.66, radius * 0.32, radius * 0.32, 3);
        graphics.fillRoundedRect(x + radius * 0.32, y - radius * 0.66, radius * 0.32, radius * 0.32, 3);
        break;
      case "haste":
        graphics.fillStyle(0xffca3a, 1);
        graphics.fillTriangle(x - radius * 0.72, y - radius * 0.42, x + radius * 0.05, y, x - radius * 0.72, y + radius * 0.42);
        graphics.fillTriangle(x - radius * 0.05, y - radius * 0.42, x + radius * 0.72, y, x - radius * 0.05, y + radius * 0.42);
        break;
      case "xp_burst":
        graphics.fillStyle(0x4cc9f0, 1);
        graphics.fillTriangle(x, y - radius * 0.8, x - radius * 0.62, y, x, y + radius * 0.8);
        graphics.fillStyle(0x9bf6ff, 1);
        graphics.fillTriangle(x, y - radius * 0.8, x + radius * 0.62, y, x, y + radius * 0.8);
        graphics.lineStyle(3, 0xe9fbff, 0.9);
        graphics.strokeTriangle(x, y - radius * 0.8, x - radius * 0.62, y, x, y + radius * 0.8);
        break;
    }
  }

  private drawSprite(
    entityId: number,
    assetId: string,
    x: number,
    y: number,
    fallbackSize: number,
    scaleX: number,
    scaleY: number,
    rotation: number,
    tint: number | undefined,
    alpha: number,
    frame?: number,
  ): void {
    const textureKey = AssetManager.getTextureKey(assetId);
    const sprite = this.getSprite(entityId, textureKey);
    const displaySize = AssetManager.getDisplaySize(assetId, fallbackSize);
    const pivot = AssetManager.getPivot(assetId);

    sprite.setTexture(textureKey, frame);
    sprite.setPosition(x, y);
    sprite.setOrigin(pivot.x, pivot.y);
    sprite.setDisplaySize(displaySize * scaleX, displaySize * scaleY);
    sprite.setRotation(rotation);
    sprite.setAlpha(alpha);
    sprite.setDepth(2);

    if (tint !== undefined) {
      sprite.setTint(tint);
    } else {
      sprite.clearTint();
    }
  }

  private getSprite(entityId: number, textureKey: string): Phaser.GameObjects.Image {
    let sprite = this.sprites.get(entityId);
    if (!sprite) {
      sprite = this.scene.add.image(0, 0, textureKey);
      this.sprites.set(entityId, sprite);
    }
    sprite.setVisible(true);
    return sprite;
  }

  private drawCharacterShadow(
    x: number,
    groundY: number,
    visualSize: number,
    kind: CharacterShadowKind,
    liftRatio: number,
    shadowScaleX: number,
    shadowScaleY: number,
  ): void {
    const profile = getCharacterShadowProfile(kind, visualSize, liftRatio);
    const y = groundY + profile.groundOffsetY;
    this.graphics.fillStyle(0x07160f, profile.ambientAlpha);
    this.graphics.fillEllipse(
      x,
      y + visualSize * 0.018,
      profile.ambientWidth * shadowScaleX,
      profile.ambientHeight * shadowScaleY,
    );
    this.graphics.fillStyle(0x020805, profile.contactAlpha);
    this.graphics.fillEllipse(x, y, profile.contactWidth * shadowScaleX, profile.contactHeight * shadowScaleY);
  }

  private drawEnemyProjectile(
    entityId: number,
    { x, y, radius }: TransformComponent,
    render: RenderComponent,
    velocity: VelocityComponent | undefined,
    remainingMs: number,
  ): boolean {
    const asset = AssetManager.getAsset(render.assetId);
    if (render.assetId && asset && AssetManager.hasTexture(this.scene, render.assetId)) {
      const angle = Math.atan2(velocity?.y ?? 0, velocity?.x ?? 1);
      const alpha = 0.72 + 0.28 * Phaser.Math.Clamp(remainingMs / 110, 0, 1);
      this.drawSprite(entityId, render.assetId, x, y, render.size, 1, asset.height / asset.width, angle, undefined, alpha);
      this.sprites.get(entityId)?.setDepth(3.8);
      return true;
    }

    // Failed textures must still show the damaging core. No decorative tail in fallback.
    this.hideSprite(entityId);
    this.overlayGraphics.fillStyle(0x302526, 0.94);
    this.overlayGraphics.fillCircle(x, y, radius + 1);
    this.overlayGraphics.fillStyle(render.color, 1);
    this.overlayGraphics.fillCircle(x, y, Math.max(1, radius - 1));
    return false;
  }

  private hideSprite(entityId: number): void {
    this.sprites.get(entityId)?.setVisible(false);
  }

  private destroyInactiveSprites(activeSpriteEntities: Set<number>): void {
    for (const [entityId, sprite] of this.sprites) {
      if (activeSpriteEntities.has(entityId)) {
        continue;
      }

      sprite.destroy();
      this.sprites.delete(entityId);
    }
  }

  private drawPickupRadius(runtime: GameRuntime): void {
    const transform = runtime.world.components.transforms.get(runtime.playerId);
    const player = runtime.world.components.players.get(runtime.playerId);
    if (!transform || !player) {
      return;
    }

    this.graphics.lineStyle(1, 0x4cc9f0, 0.18);
    this.graphics.strokeCircle(transform.x, transform.y, player.pickupRadius);
  }

  private drawAura(runtime: GameRuntime): void {
    const transform = runtime.world.components.transforms.get(runtime.playerId);
    if (!transform) {
      return;
    }

    for (const aura of runtime.skillManager.getAuraProfiles()) {
      // Quiet damage boundary; animated wavefronts live below actors elsewhere.
      this.graphics.lineStyle(1, aura.color, 0.13);
      this.graphics.strokeCircle(transform.x, transform.y, aura.radius);
    }
  }

  private drawAoeWarnings(runtime: GameRuntime): void {
    this.hostileWarnings.prune(runtime.world.components.aoeWarnings);
    for (const [entityId, label] of this.warningLabels) {
      if (!runtime.world.components.aoeWarnings.has(entityId)) { label.destroy(); this.warningLabels.delete(entityId); }
    }
    for (const [entityId, warning] of runtime.world.components.aoeWarnings) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform) {
        continue;
      }

      const percent = Phaser.Math.Clamp(1 - warning.remainingMs / warning.totalMs, 0, 1);
      const color = warning.color ?? (warning.label?.includes("玉米") ? 0xff9c38 : warning.damage === 0 ? 0xffca3a : 0xff3030);
      if (warning.impactStyle && warning.shape !== "rectangle") {
        this.hostileWarnings.draw(entityId, warning, transform, percent);
      } else if (warning.shape === "rectangle") {
        this.graphics.fillStyle(color, .08 + percent * .12);
        this.graphics.lineStyle(3 + percent * 3, color, .48 + percent * .38);
        const directionX = Math.cos(warning.angle ?? 0); const directionY = Math.sin(warning.angle ?? 0);
        const { points, travelLength: length } = getChargeWarningEnvelope(transform.x, transform.y, warning);
        this.graphics.fillPoints(points, true);
        this.graphics.strokePoints(points, true);
        this.graphics.lineBetween(transform.x, transform.y, transform.x + directionX * length, transform.y + directionY * length);
      } else {
        this.graphics.fillStyle(color, .08 + percent * .12);
        this.graphics.lineStyle(3 + percent * 3, color, .48 + percent * .38);
        this.graphics.fillCircle(transform.x, transform.y, transform.radius);
        this.graphics.strokeCircle(transform.x, transform.y, transform.radius);
      }
      if (warning.safeRadius !== undefined && !warning.impactStyle) {
        this.graphics.fillStyle(0x122d19, 0.94);
        this.graphics.fillCircle(transform.x, transform.y, warning.safeRadius);
        this.graphics.fillStyle(0x9bde7e, 0.25 + percent * 0.12);
        this.graphics.fillCircle(transform.x, transform.y, warning.safeRadius);
        this.graphics.lineStyle(3, 0x9bde7e, 0.62);
        this.graphics.strokeCircle(transform.x, transform.y, warning.safeRadius);
      }
      if (warning.label) {
        let label = this.warningLabels.get(entityId);
        if (!label) {
          label = this.scene.add.text(0, 0, warning.label, { fontFamily: '"PingFang SC", sans-serif', fontSize: "11px", color: "#fff3cc", stroke: "#211911", strokeThickness: 4 }).setOrigin(0.5).setDepth(4);
          this.warningLabels.set(entityId, label);
        }
        label.setPosition(transform.x, transform.y - (warning.shape === "rectangle" ? (warning.width ?? 40) / 2 : transform.radius) - 14);
      }
    }
  }

  private getStatusColor(runtime: GameRuntime, entityId: number): number | undefined {
    const statuses = runtime.world.components.statuses.get(entityId);
    if (!statuses || statuses.length === 0) {
      return undefined;
    }
    if (statuses.some((status) => status.type === "freeze" || status.type === "slow")) {
      return 0x9ad7ff;
    }
    if (statuses.some((status) => status.type === "burn")) {
      return 0xff8c2a;
    }
    if (statuses.some((status) => status.type === "poison")) {
      return 0x80b918;
    }
    return undefined;
  }
}
