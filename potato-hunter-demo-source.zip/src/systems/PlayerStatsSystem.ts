import { ConfigManager } from "../managers/ConfigManager";
import { getPlayerLevelGrowth, reconcilePlayerMaxHp } from "../managers/PlayerLevelGrowthModel";
import type { GameRuntime, System } from "./SystemTypes";

export class PlayerStatsSystem implements System {
  update(deltaMs: number, runtime: GameRuntime): void {
    const player = runtime.world.components.players.get(runtime.playerId);
    if (player) {
      player.damageCooldownMs = Math.max(0, player.damageCooldownMs - deltaMs);
    }
    const health = runtime.world.components.health.get(runtime.playerId);
    if (!health) {
      return;
    }

    const growth = getPlayerLevelGrowth(player?.level);
    const nextMaxHp = ConfigManager.player.maxHp + (runtime.campaign?.training?.maxHp ?? 0) + growth.maxHpBonus + runtime.skillManager.getMaxHpBonus();
    reconcilePlayerMaxHp(health, nextMaxHp);

    const regen = runtime.skillManager.getRegenPerSecond();
    if (regen > 0 && health.current > 0) {
      health.current = Math.min(health.max, health.current + regen * (deltaMs / 1000));
    }
  }
}
