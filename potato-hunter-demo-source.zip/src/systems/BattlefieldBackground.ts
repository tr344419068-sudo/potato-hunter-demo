import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import {
  getBattlefieldDecoration,
  getLevelChapter,
  type BattlefieldDecoration,
  type LevelChapterId,
} from "../managers/LevelChapterModel";

const BATTLEFIELD_ASSET_ID = "background_battlefield_grassland";

export class BattlefieldBackground {
  private readonly background: Phaser.GameObjects.TileSprite;
  private readonly decorationGraphics: Phaser.GameObjects.Graphics;
  private readonly chapterOverlay: Phaser.GameObjects.Rectangle;
  private chapterId?: LevelChapterId;
  private cameraCellX = Number.NaN;
  private cameraCellY = Number.NaN;
  private arenaCenter?: { x: number; y: number };
  private static readonly DECORATION_CELL_SIZE = 190;

  constructor(private readonly scene: Phaser.Scene) {
    this.background = scene.add.tileSprite(
      0,
      0,
      Math.max(1, scene.scale.width),
      Math.max(1, scene.scale.height),
      AssetManager.getTextureKey(BATTLEFIELD_ASSET_ID),
    );
    this.background.setOrigin(0, 0);
    this.background.setScrollFactor(0);
    this.background.setDepth(-20);
    this.background.setAlpha(1);
    this.decorationGraphics = scene.add.graphics().setDepth(-18);
    this.chapterOverlay = scene.add.rectangle(
      0,
      0,
      Math.max(1, scene.scale.width),
      Math.max(1, scene.scale.height),
      0x173f2a,
      0.045,
    ).setOrigin(0, 0).setScrollFactor(0).setDepth(-15);

    scene.scale.on(Phaser.Scale.Events.RESIZE, this.relayout, this);
    scene.events.once(Phaser.Scenes.Events.SHUTDOWN, this.destroy, this);
  }

  update(elapsedMs = 0, focusX = 0, focusY = 0): void {
    const camera = this.scene.cameras.main;
    this.background.tilePositionX = camera.scrollX * 0.82;
    this.background.tilePositionY = camera.scrollY * 0.82;

    const chapter = getLevelChapter(elapsedMs);
    const cameraCellX = Math.floor(camera.scrollX / BattlefieldBackground.DECORATION_CELL_SIZE);
    const cameraCellY = Math.floor(camera.scrollY / BattlefieldBackground.DECORATION_CELL_SIZE);
    const chapterChanged = chapter.id !== this.chapterId;
    if (chapterChanged) {
      this.chapterId = chapter.id;
      this.background.setTint(chapter.groundTint);
      this.chapterOverlay.setFillStyle(chapter.overlayColor, chapter.id === "fryer_siege" ? 0.08 : 0.045);
      if (chapter.id === "fryer_siege") {
        this.arenaCenter = { x: focusX, y: focusY };
      }
    }

    if (chapterChanged || cameraCellX !== this.cameraCellX || cameraCellY !== this.cameraCellY) {
      this.cameraCellX = cameraCellX;
      this.cameraCellY = cameraCellY;
      this.redrawDecorations(chapter, camera);
    }
  }

  destroy(): void {
    this.scene.scale.off(Phaser.Scale.Events.RESIZE, this.relayout, this);
    this.background.destroy();
    this.decorationGraphics.destroy();
    this.chapterOverlay.destroy();
  }

  private relayout(): void {
    this.background.setSize(Math.max(1, this.scene.scale.width), Math.max(1, this.scene.scale.height));
    this.chapterOverlay.setSize(Math.max(1, this.scene.scale.width), Math.max(1, this.scene.scale.height));
    this.cameraCellX = Number.NaN;
    this.cameraCellY = Number.NaN;
  }

  private redrawDecorations(chapter: ReturnType<typeof getLevelChapter>, camera: Phaser.Cameras.Scene2D.Camera): void {
    const graphics = this.decorationGraphics;
    graphics.clear();
    const cellSize = BattlefieldBackground.DECORATION_CELL_SIZE;
    const minCellX = Math.floor(camera.scrollX / cellSize) - 2;
    const maxCellX = Math.ceil((camera.scrollX + camera.width) / cellSize) + 2;
    const minCellY = Math.floor(camera.scrollY / cellSize) - 2;
    const maxCellY = Math.ceil((camera.scrollY + camera.height) / cellSize) + 2;

    for (let cellX = minCellX; cellX <= maxCellX; cellX += 1) {
      for (let cellY = minCellY; cellY <= maxCellY; cellY += 1) {
        const decoration = getBattlefieldDecoration(cellX, cellY, chapter);
        if (!decoration) {
          continue;
        }
        this.drawDecoration(
          graphics,
          cellX * cellSize + cellSize / 2 + decoration.offsetX,
          cellY * cellSize + cellSize / 2 + decoration.offsetY,
          decoration,
        );
      }
    }

    if (chapter.id === "fryer_siege" && this.arenaCenter) {
      this.drawBossArena(graphics, this.arenaCenter.x, this.arenaCenter.y, chapter.primaryColor, chapter.secondaryColor);
    }
  }

  private drawDecoration(
    graphics: Phaser.GameObjects.Graphics,
    x: number,
    y: number,
    decoration: BattlefieldDecoration,
  ): void {
    const size = 18 * decoration.scale;
    const cos = Math.cos(decoration.rotation);
    const sin = Math.sin(decoration.rotation);

    if (decoration.kind === "grass") {
      graphics.lineStyle(Math.max(2, size * 0.15), 0x1c3f2a, 0.42);
      for (const offset of [-0.65, 0, 0.62]) {
        graphics.beginPath();
        graphics.moveTo(x + offset * size * 0.52, y + size * 0.3);
        graphics.lineTo(x + (offset * 0.2 + sin * 0.18) * size, y - size * (0.42 + Math.abs(offset) * 0.2));
        graphics.strokePath();
      }
      return;
    }

    if (decoration.kind === "stone") {
      graphics.fillStyle(0x263d34, 0.34);
      graphics.fillEllipse(x + 2, y + 4, size * 1.45, size * 0.62);
      graphics.fillStyle(decoration.secondaryColor, 0.24);
      graphics.fillEllipse(x, y, size * 1.24, size * 0.72);
      graphics.lineStyle(2, 0x1b3028, 0.38);
      graphics.strokeEllipse(x, y, size * 1.24, size * 0.72);
      return;
    }

    if (decoration.kind === "sauce") {
      graphics.fillStyle(decoration.color, 0.16);
      graphics.fillEllipse(x, y, size * 1.75, size * 0.62);
      graphics.fillCircle(x - size * 0.65, y - size * 0.12, size * 0.22);
      graphics.fillCircle(x + size * 0.62, y + size * 0.08, size * 0.16);
      return;
    }

    if (decoration.kind === "crate") {
      graphics.fillStyle(0x211d17, 0.28);
      graphics.fillRoundedRect(x - size * 0.62 + 3, y - size * 0.48 + 4, size * 1.24, size * 0.96, 4);
      graphics.fillStyle(0x8d6e3f, 0.5);
      graphics.fillRoundedRect(x - size * 0.62, y - size * 0.48, size * 1.24, size * 0.96, 4);
      graphics.lineStyle(2, 0x4b3421, 0.58);
      graphics.strokeRoundedRect(x - size * 0.62, y - size * 0.48, size * 1.24, size * 0.96, 4);
      graphics.lineBetween(x - cos * size * 0.5, y - sin * size * 0.38, x + cos * size * 0.5, y + sin * size * 0.38);
      return;
    }

    if (decoration.kind === "shard") {
      graphics.fillStyle(decoration.color, 0.22);
      graphics.fillTriangle(x - size * 0.55, y + size * 0.25, x - size * 0.1, y - size * 0.72, x + size * 0.15, y + size * 0.38);
      graphics.fillStyle(decoration.secondaryColor, 0.2);
      graphics.fillTriangle(x + size * 0.08, y + size * 0.35, x + size * 0.52, y - size * 0.4, x + size * 0.7, y + size * 0.3);
      return;
    }

    if (decoration.kind === "puddle") {
      graphics.fillStyle(decoration.color, 0.09);
      graphics.fillEllipse(x, y, size * 2.2, size * 0.7);
      graphics.lineStyle(2, decoration.secondaryColor, 0.13);
      graphics.strokeEllipse(x, y, size * 1.7, size * 0.48);
      return;
    }

    graphics.fillStyle(0x2d1b15, 0.18);
    graphics.fillEllipse(x, y, size * 2.15, size * 0.82);
    graphics.lineStyle(2, decoration.color, 0.13);
    for (let index = 0; index < 5; index += 1) {
      const angle = decoration.rotation + index * Math.PI * 0.4;
      graphics.lineBetween(x + Math.cos(angle) * size * 0.25, y + Math.sin(angle) * size * 0.12, x + Math.cos(angle) * size, y + Math.sin(angle) * size * 0.4);
    }
  }

  private drawBossArena(graphics: Phaser.GameObjects.Graphics, x: number, y: number, primaryColor: number, secondaryColor: number): void {
    graphics.lineStyle(18, secondaryColor, 0.12);
    graphics.strokeCircle(x, y, 520);
    graphics.lineStyle(5, primaryColor, 0.22);
    graphics.strokeCircle(x, y, 520);
    graphics.lineStyle(2, primaryColor, 0.14);
    graphics.strokeCircle(x, y, 430);
    for (let index = 0; index < 12; index += 1) {
      const angle = index * Math.PI / 6;
      const inner = 486;
      const outer = 548;
      graphics.lineStyle(index % 2 === 0 ? 5 : 3, primaryColor, 0.2);
      graphics.lineBetween(x + Math.cos(angle) * inner, y + Math.sin(angle) * inner, x + Math.cos(angle) * outer, y + Math.sin(angle) * outer);
    }
  }
}
