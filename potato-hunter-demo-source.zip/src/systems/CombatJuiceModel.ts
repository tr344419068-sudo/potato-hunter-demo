import type { CombatVfxKind } from "./CombatVfxModel";

export interface PlayerAttackPose {
  phase: "anticipation" | "strike" | "recovery";
  smear: number;
  offsetX: number;
  offsetY: number;
  scaleX: number;
  scaleY: number;
  rotation: number;
}

export interface ProjectileMotion {
  scaleX: number;
  scaleY: number;
  rotation: number;
  trailIntervalMs: number;
}

export interface HitSquashPose {
  scaleX: number;
  scaleY: number;
  rotation: number;
}

export interface HeroLocomotionPose {
  offsetX: number;
  offsetY: number;
  scaleX: number;
  scaleY: number;
  rotation: number;
  facingX: -1 | 1;
  shadowScaleX: number;
  shadowScaleY: number;
  shadowAlpha: number;
}

export interface MonsterJumpPose {
  offsetY: number;
  shadowScaleX: number;
  shadowScaleY: number;
  shadowAlpha: number;
}

export function getMonsterJumpPose(progress: number): MonsterJumpPose {
  const lift = Math.sin(clamp(progress, 0, 1) * Math.PI);
  return {
    offsetY: lift === 0 ? 0 : -42 * lift,
    shadowScaleX: 1 - lift * 0.16,
    shadowScaleY: 1 - lift * 0.16,
    shadowAlpha: 0.22 * (1 - lift * 0.46),
  };
}

export function getPlayerAttackPose(progress: number, directionX: number, directionY: number): PlayerAttackPose {
  const normalizedProgress = clamp(progress, 0, 1);
  const length = Math.max(0.001, Math.hypot(directionX, directionY));
  const x = directionX / length;
  const y = directionY / length;

  if (normalizedProgress < 0.28) {
    const phaseProgress = normalizedProgress / 0.28;
    const anticipation = Math.sin(phaseProgress * Math.PI * 0.5);
    return {
      phase: "anticipation",
      smear: anticipation * 0.16,
      offsetX: -x * anticipation * 10,
      offsetY: -y * anticipation * 6 + anticipation * 1.4,
      scaleX: 1 - anticipation * 0.13,
      scaleY: 1 + anticipation * 0.16,
      rotation: x * -anticipation * 0.11,
    };
  }

  if (normalizedProgress < 0.58) {
    const phaseProgress = (normalizedProgress - 0.28) / 0.3;
    const strike = Math.sin(phaseProgress * Math.PI);
    return {
      phase: "strike",
      smear: 0.38 + strike * 0.62,
      offsetX: x * (4.6 + strike * 3.2),
      offsetY: y * (2.4 + strike * 2.2) - strike * 1.8,
      scaleX: 1 + strike * 0.14,
      scaleY: 1 - strike * 0.12,
      rotation: x * (0.045 + strike * 0.055),
    };
  }

  const phaseProgress = (normalizedProgress - 0.58) / 0.42;
  const recovery = Math.max(0, 1 - phaseProgress);
  const settle = Math.sin(phaseProgress * Math.PI) * 0.018;
  return {
    phase: "recovery",
    smear: recovery * 0.22,
    offsetX: x * recovery * 4.2,
    offsetY: y * recovery * 1.8 + Math.sin(phaseProgress * Math.PI) * 1.2,
    scaleX: 1 + recovery * 0.06 - settle,
    scaleY: 1 - recovery * 0.07 + settle,
    rotation: x * recovery * 0.035,
  };
}

export function getProjectileMotion(kind: CombatVfxKind, elapsedMs: number, entityId: number, speed: number): ProjectileMotion {
  const speedFactor = clamp(speed / 560, 0.65, 1.2);
  const pulse = Math.sin(elapsedMs * 0.022 + entityId * 1.37);

  switch (kind) {
    case "fire":
    case "explosion":
      return { scaleX: 1.13 + pulse * 0.055, scaleY: 0.84 - pulse * 0.035, rotation: pulse * 0.045, trailIntervalMs: 28 };
    case "frost":
      return { scaleX: 1.03 + pulse * 0.035, scaleY: 1.03 - pulse * 0.025, rotation: elapsedMs * 0.008 + entityId * 0.16, trailIntervalMs: 32 };
    case "lightning":
      return { scaleX: 1.2 + pulse * 0.06, scaleY: 0.77 - pulse * 0.04, rotation: pulse * 0.12, trailIntervalMs: 24 };
    case "peeler":
      return { scaleX: 1.08, scaleY: 1.08, rotation: elapsedMs * 0.018 + entityId * 0.2, trailIntervalMs: 30 };
    case "poison":
      return { scaleX: 1.06 + pulse * 0.045, scaleY: 0.98 - pulse * 0.025, rotation: pulse * 0.05, trailIntervalMs: 30 };
    case "ketchup":
      return { scaleX: 1.08 + pulse * 0.04, scaleY: 0.92 - pulse * 0.03, rotation: pulse * 0.06, trailIntervalMs: 30 };
    default:
      return {
        scaleX: 1.02 + speedFactor * 0.05 + pulse * 0.025,
        scaleY: 0.98 - speedFactor * 0.025,
        rotation: pulse * 0.025,
        trailIntervalMs: 36,
      };
  }
}

export function getHitSquashPose(remainingRatio: number, entityId: number): HitSquashPose {
  const strength = clamp(remainingRatio, 0, 1);
  return {
    scaleX: 1 + strength * 0.14,
    scaleY: 1 - strength * 0.1,
    rotation: Math.sin(entityId * 1.83) * strength * 0.038,
  };
}

export function getHeroLocomotionPose(
  elapsedMs: number,
  velocityX: number,
  velocityY: number,
  currentFacingX: -1 | 1,
): HeroLocomotionPose {
  const speed = Math.hypot(velocityX, velocityY);
  if (speed <= 8) {
    const breath = Math.sin(elapsedMs * 0.0042);
    const sway = Math.sin(elapsedMs * 0.0017 + 0.8);
    return {
      offsetX: sway * 0.42,
      offsetY: -breath * 0.9,
      scaleX: 1 - breath * 0.012,
      scaleY: 1 + breath * 0.022,
      rotation: sway * 0.008,
      facingX: currentFacingX,
      shadowScaleX: 1 - breath * 0.018,
      shadowScaleY: 1 + breath * 0.012,
      shadowAlpha: 0.22,
    };
  }

  const directionX = velocityX / speed;
  const directionY = velocityY / speed;
  const speedRatio = clamp(speed / 220, 0.35, 1);
  const stride = Math.sin(elapsedMs * 0.0175);
  const facingX = Math.abs(velocityX) > 20 ? (velocityX < 0 ? -1 : 1) : currentFacingX;
  const normalX = -directionY;

  return {
    // The UV rig carries the stride. The torso stays level instead of jumping.
    offsetX: normalX * stride * 0.65 * speedRatio,
    offsetY: -Math.cos(elapsedMs * 0.035) * 0.32 * speedRatio,
    scaleX: 1 + stride * 0.006 * speedRatio,
    scaleY: 1 - stride * 0.006 * speedRatio,
    rotation: directionX * 0.025 + stride * 0.008,
    facingX,
    shadowScaleX: 1 + stride * 0.008 * speedRatio,
    shadowScaleY: 1,
    shadowAlpha: 0.23,
  };
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}
