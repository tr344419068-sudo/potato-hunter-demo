import type { EntityId } from "../components/ComponentTypes";
import type { GameRuntime, System } from "./SystemTypes";

export class HitFeedbackSystem implements System {
  update(deltaMs: number, runtime: GameRuntime): void {
    const expired: EntityId[] = [];

    for (const [entityId, flash] of runtime.world.components.hitFlashes) {
      flash.remainingMs -= deltaMs;
      if (flash.remainingMs <= 0) {
        expired.push(entityId);
      }
    }

    for (const entityId of expired) {
      runtime.world.components.hitFlashes.delete(entityId);
    }
  }
}
