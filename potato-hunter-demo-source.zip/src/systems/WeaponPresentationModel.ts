import type { ProjectileComponent } from "../components/ComponentTypes";
import { HERO_RIG } from "./AuthoredHeroModel";

type Point = { x: number; y: number };
export type PepperWeapon = "pepper_gatling" | "pepper_overdrive";
export type WeaponLaunchVisual = { offset: Point; settleMs: number } | { hideMs: number };

export const PEPPER_WEAPONS = {
  pepper_gatling: { core: 0xfff7bd, color: 0xfca64c, accent: 0xe56428 },
  pepper_overdrive: { core: 0xfff4d5, color: 0xff8354, accent: 0xf24059 },
} as const;

export function isPepperWeapon(skillId?: string): skillId is PepperWeapon {
  return skillId === "pepper_gatling" || skillId === "pepper_overdrive";
}

export function isLongSkewer(skillId?: string): boolean {
  return skillId === "skewer_javelin" || skillId === "thunder_skewer";
}

/** Visual emission point near the authored hand, rather than the end of a held prop. */
export function getPepperCastOrigin(x: number, y: number, directionX: number, fallbackFacing: -1 | 1,
  size = 84, pivot: Point = { x: .5, y: .65 }): Point {
  const facing: -1 | 1 = Math.abs(directionX) > .001 ? directionX < 0 ? -1 : 1 : fallbackFacing;
  const hand = HERO_RIG.right_arm.end;
  return { x: x + (hand.x / 256 - pivot.x) * size * facing, y: y + (hand.y / 256 - pivot.y) * size };
}

export function getPepperLaunchVisual(origin: Point, muzzle: Point, target: Point & { radius: number }, speed: number): WeaponLaunchVisual {
  const dx = target.x - origin.x, dy = target.y - origin.y;
  const distance = Math.hypot(dx, dy);
  const offset = { x: muzzle.x - origin.x, y: muzzle.y - origin.y };
  const projectedOffset = (offset.x * dx + offset.y * dy) / Math.max(1, distance);
  const contactDistance = distance - target.radius - 8; // Allow for the projectile's collision radius and motion before render.
  if (contactDistance < projectedOffset + 16) {
    // No space for a legible tracer before contact. A piercing shot may still become visible beyond the muzzle.
    return { hideMs: (Math.hypot(offset.x, offset.y) + 6) / Math.max(1, speed) * 1000 };
  }
  return { offset, settleMs: Math.min(240, contactDistance / Math.max(1, speed) * 1000) };
}

/** Render-only offset; no writes to the physics transform or lifetime. */
export function getProjectileDrawPoint(transform: Point, projectile: ProjectileComponent, remainingMs: number): Point | undefined {
  const launch = projectile.launchVisual;
  if (!launch) return transform;
  const ageMs = Math.max(0, projectile.lifetimeMs - remainingMs);
  if ("hideMs" in launch) return ageMs < launch.hideMs ? undefined : transform;
  const blend = Math.max(0, 1 - ageMs / launch.settleMs);
  return blend > 0 ? { x: transform.x + launch.offset.x * blend, y: transform.y + launch.offset.y * blend } : transform;
}

export function getWeaponContact(target: Point & { radius: number }, projectile: Point, velocity: Point): Point {
  const rx = projectile.x - target.x, ry = projectile.y - target.y;
  const speed = Math.hypot(velocity.x, velocity.y);
  if (speed < .01) {
    const length = Math.hypot(rx, ry);
    return length > .01 ? { x: target.x + rx / length * target.radius, y: target.y + ry / length * target.radius } : target;
  }
  // Find the entry point along the incoming ray, even if this simulation frame overshot the center.
  const ux = velocity.x / speed, uy = velocity.y / speed;
  const across = Math.max(-target.radius, Math.min(target.radius, rx * -uy + ry * ux));
  const along = Math.sqrt(Math.max(0, target.radius ** 2 - across ** 2));
  return { x: target.x - uy * across - ux * along, y: target.y + ux * across - uy * along };
}
