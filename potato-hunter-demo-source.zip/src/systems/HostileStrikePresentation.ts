import type Phaser from "phaser";
import type { AoeWarningComponent } from "../components/ComponentTypes";

type StrikeStyle = NonNullable<AoeWarningComponent["impactStyle"]>;
export interface HostileStrike {
  x: number;
  y: number;
  radius: number;
  safeRadius?: number;
  style: StrikeStyle;
  art?: AoeWarningComponent["impactArt"];
  bossPhase?: number;
  bossFinisher?: boolean;
}

const COLORS: Record<StrikeStyle, { hot: number; core: number; shadow: number }> = {
  oil:   { hot: 0xff6429, core: 0xffdf8c, shadow: 0x512016 },
  slam:  { hot: 0xff532b, core: 0xffedbe, shadow: 0x5c2419 },
  sweep: { hot: 0xff944d, core: 0xfff5db, shadow: 0x442323 },
  sauce: { hot: 0xff5763, core: 0xffc692, shadow: 0x581632 },
  sand:  { hot: 0xfac56f, core: 0xc3faff, shadow: 0x433129 },
  bomb:  { hot: 0xff922e, core: 0xffe3a4, shadow: 0x593019 },
  lightning: { hot: 0x7bc4ff, core: 0xd9f5ff, shadow: 0x2e3a64 },
  shockwave: { hot: 0xc881f5, core: 0xffd5ff, shadow: 0x402348 },
};

const SAFE_EDGE = 0xaceda7;
type Graphics = Phaser.GameObjects.Graphics;

/** A short gameplay confirmation at the true hit boundary, independent of the art assets. */
export function drawHostileContact(graphics: Graphics, strike: HostileStrike): void {
  const { radius, safeRadius, style } = strike;
  const colors = COLORS[style];
  graphics.lineStyle(5, colors.shadow, .84).strokeCircle(0, 0, radius);
  graphics.lineStyle(2, colors.core, .92).strokeCircle(0, 0, radius);
  if (safeRadius !== undefined) graphics.lineStyle(2, SAFE_EDGE, .88).strokeCircle(0, 0, safeRadius);
}
