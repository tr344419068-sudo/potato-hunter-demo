import type Phaser from "phaser";
import type { AoeWarningComponent } from "../components/ComponentTypes";

type StrikeStyle = NonNullable<AoeWarningComponent["impactStyle"]>;
export interface HostileStrike {
  x: number;
  y: number;
  radius: number;
  safeRadius?: number;
  style: StrikeStyle;
  art?: AoeWarningComponent["impactArt"];
}

const COLORS: Record<StrikeStyle, { hot: number; core: number; shadow: number }> = {
  oil:   { hot: 0xff6429, core: 0xffdf8c, shadow: 0x512016 },
  slam:  { hot: 0xff532b, core: 0xffedbe, shadow: 0x5c2419 },
  sweep: { hot: 0xff944d, core: 0xfff5db, shadow: 0x442323 },
  sauce: { hot: 0xff5763, core: 0xffc692, shadow: 0x581632 },
  sand:  { hot: 0xfac56f, core: 0xc3faff, shadow: 0x433129 },
  bomb:  { hot: 0xff922e, core: 0xffe3a4, shadow: 0x593019 },
};

const TAU = Math.PI * 2;
const DANGER_EDGE = 0xff765b;
const SAFE_EDGE = 0xaceda7;
type Graphics = Phaser.GameObjects.Graphics;

export function drawHostileTell(floor: Graphics, rim: Graphics, strike: HostileStrike, progress: number): void {
  const { x, y, radius, safeRadius, style } = strike;
  const palette = COLORS[style];
  const inner = safeRadius ?? 0;
  if (inner > 0) {
    const band = radius - inner;
    floor.lineStyle(band, palette.shadow, .18 + progress * .13).strokeCircle(x, y, inner + band / 2);
  } else {
    floor.fillStyle(palette.shadow, .17 + progress * .13).fillCircle(x, y, radius);
    floor.fillStyle(palette.hot, .08 + progress * .07).fillCircle(x, y, radius);
  }

  // Opaque contrast only in the thin rim. The floor always remains translucent.
  rim.lineStyle(6, 0x2c131b, .84).strokeCircle(x, y, radius);
  rim.lineStyle(2.4, DANGER_EDGE, .86).strokeCircle(x, y, radius);
  if (inner > 0) {
    rim.lineStyle(5, 0x102820, .9).strokeCircle(x, y, inner);
    rim.lineStyle(2, SAFE_EDGE, .88).strokeCircle(x, y, inner);
  }

  // A perimeter fuse brightens in place and never implies an expanding hitbox.
  const segments = radius >= 200 ? 12 : 8;
  const track = Math.max(inner + 4, radius - 9);
  for (let i = 0; i < segments; i++) {
    const start = (i / segments - .25) * TAU;
    const lit = i < progress * segments;
    rim.lineStyle(lit ? 3 : 1.5, lit ? palette.core : DANGER_EDGE, lit ? .88 : .28);
    rim.beginPath().arc(x, y, track, start + .065, start + TAU / segments - .065).strokePath();
  }
}

/** A short gameplay confirmation at the true hit boundary, independent of the art assets. */
export function drawHostileContact(graphics: Graphics, strike: HostileStrike): void {
  const { radius, safeRadius, style } = strike;
  const colors = COLORS[style];
  graphics.lineStyle(5, colors.shadow, .84).strokeCircle(0, 0, radius);
  graphics.lineStyle(2, colors.core, .92).strokeCircle(0, 0, radius);
  if (safeRadius !== undefined) graphics.lineStyle(2, SAFE_EDGE, .88).strokeCircle(0, 0, safeRadius);
}
