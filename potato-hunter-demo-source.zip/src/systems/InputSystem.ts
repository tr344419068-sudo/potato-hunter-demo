import Phaser from "phaser";
import type { EntityId } from "../components/ComponentTypes";
import { ConfigManager } from "../managers/ConfigManager";
import { EventBus } from "../managers/EventBus";
import { normalize } from "../utils/math";
import { createDashState, DASH_SPEED, tickDashState } from "./DashModel";
import type { System, GameRuntime } from "./SystemTypes";

export class InputSystem implements System {
  private readonly cursors: Phaser.Types.Input.Keyboard.CursorKeys;
  private readonly keys: Record<"w" | "a" | "s" | "d", Phaser.Input.Keyboard.Key>;
  private readonly dashKey: Phaser.Input.Keyboard.Key;
  private dashRequested = false;
  private lastMoveDirection = { x: 1, y: 0 };
  private readonly consumedPointers = new Set<number>();

  constructor(scene: Phaser.Scene, private readonly playerId: EntityId) {
    if (!scene.input.keyboard) {
      throw new Error("Keyboard input is not available.");
    }

    this.cursors = scene.input.keyboard.createCursorKeys();
    this.keys = scene.input.keyboard.addKeys({
      w: Phaser.Input.Keyboard.KeyCodes.W,
      a: Phaser.Input.Keyboard.KeyCodes.A,
      s: Phaser.Input.Keyboard.KeyCodes.S,
      d: Phaser.Input.Keyboard.KeyCodes.D,
    }) as Record<"w" | "a" | "s" | "d", Phaser.Input.Keyboard.Key>;
    this.dashKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    EventBus.on("player:dash-request", this.handleDashRequest, this);
    EventBus.on("player:pointer-consume", this.consumePointerGesture, this);
    scene.input.on(Phaser.Input.Events.POINTER_UP, this.releasePointerGesture, this);
    scene.input.on(Phaser.Input.Events.POINTER_UP_OUTSIDE, this.releasePointerGesture, this);
    scene.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      EventBus.off("player:dash-request", this.handleDashRequest, this);
      EventBus.off("player:pointer-consume", this.consumePointerGesture, this);
      scene.input.off(Phaser.Input.Events.POINTER_UP, this.releasePointerGesture, this);
      scene.input.off(Phaser.Input.Events.POINTER_UP_OUTSIDE, this.releasePointerGesture, this);
      this.consumedPointers.clear();
    });
  }

  update(deltaMs: number, runtime: GameRuntime): void {
    const velocity = runtime.world.components.velocities.get(this.playerId);
    const player = runtime.world.components.players.get(this.playerId);

    if (!velocity || !player) {
      return;
    }

    const tickedDash = tickDashState({
      remainingMs: player.dashRemainingMs,
      cooldownMs: player.dashCooldownMs,
      directionX: player.dashDirectionX,
      directionY: player.dashDirectionY,
    }, deltaMs);
    player.dashRemainingMs = tickedDash.remainingMs;
    player.dashCooldownMs = tickedDash.cooldownMs;

    const horizontal =
      Number(this.cursors.right.isDown || this.keys.d.isDown) -
      Number(this.cursors.left.isDown || this.keys.a.isDown);
    const vertical =
      Number(this.cursors.down.isDown || this.keys.s.isDown) -
      Number(this.cursors.up.isDown || this.keys.w.isDown);
    let direction = normalize(horizontal, vertical);
    const pointer = runtime.scene.input.activePointer;
    if (!pointer.isDown) this.consumedPointers.delete(pointer.id);

    if (direction.x === 0 && direction.y === 0 && runtime.scene.input.activePointer.isDown && !this.consumedPointers.has(pointer.id) && !this.dashRequested) {
      const transform = runtime.world.components.transforms.get(this.playerId);
      if (transform) {
        const target = runtime.scene.cameras.main.getWorldPoint(pointer.x, pointer.y);
        direction = normalize(target.x - transform.x, target.y - transform.y);
      }
    }

    if (direction.x !== 0 || direction.y !== 0) {
      this.lastMoveDirection = direction;
    }

    const wantsDash = this.dashRequested || Phaser.Input.Keyboard.JustDown(this.dashKey);
    this.dashRequested = false;
    if (wantsDash && player.dashCooldownMs <= 0) {
      const dash = createDashState(direction.x, direction.y, this.lastMoveDirection.x, this.lastMoveDirection.y);
      player.dashRemainingMs = dash.remainingMs;
      player.dashCooldownMs = dash.cooldownMs;
      player.dashDirectionX = dash.directionX;
      player.dashDirectionY = dash.directionY;
      const transform = runtime.world.components.transforms.get(this.playerId);
      const render = runtime.world.components.renders.get(this.playerId);
      if (transform) {
        EventBus.emit("hero:dash", {
          x: transform.x,
          y: transform.y,
          directionX: dash.directionX,
          directionY: dash.directionY,
          assetId: render?.assetId,
          size: render?.size ?? transform.radius * 2,
        });
      }
    }

    const buffs = runtime.world.components.playerBuffs.get(this.playerId) ?? [];
    const buffMoveSpeedBonus = buffs.reduce((sum, buff) => sum + (buff.moveSpeedBonus ?? 0), 0);
    const buffPickupRadiusBonus = buffs.reduce((sum, buff) => sum + (buff.pickupRadiusBonus ?? 0), 0);
    player.moveSpeed = ConfigManager.player.moveSpeed + runtime.skillManager.getMoveSpeedBonus() + buffMoveSpeedBonus;
    player.pickupRadius = ConfigManager.player.pickupRadius + runtime.skillManager.getPickupRadiusBonus() + buffPickupRadiusBonus;
    if (player.dashRemainingMs > 0) {
      velocity.x = player.dashDirectionX * DASH_SPEED;
      velocity.y = player.dashDirectionY * DASH_SPEED;
      return;
    }
    velocity.x = direction.x * player.moveSpeed;
    velocity.y = direction.y * player.moveSpeed;
  }

  private handleDashRequest(): void {
    this.dashRequested = true;
  }

  private consumePointerGesture(payload: { pointerId: number }): void {
    this.consumedPointers.add(payload.pointerId);
  }

  private releasePointerGesture(pointer: Phaser.Input.Pointer): void {
    this.consumedPointers.delete(pointer.id);
  }
}
