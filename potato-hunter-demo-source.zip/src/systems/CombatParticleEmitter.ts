import Phaser from "phaser";
import { getCombatVfxPalette, type CombatVfxKind } from "./CombatVfxModel";
import { getCombatVfxTexture, type CombatParticleForm, type CombatTextureMotion } from "./CombatVfxTextures";

export type CombatParticlePhase = "muzzle" | "trail" | "impact" | "aura" | "reaction";

export interface CombatParticleEmission {
  x: number;
  y: number;
  kind: CombatVfxKind;
  phase: CombatParticlePhase;
  directionX?: number;
  directionY?: number;
  radius?: number;
  count?: number;
  critical?: boolean;
}

type ParticleForm = CombatParticleForm;

interface Particle {
  image: Phaser.GameObjects.Image;
  x: number;
  y: number;
  velocityX: number;
  velocityY: number;
  gravity: number;
  drag: number;
  rotation: number;
  spin: number;
  width: number;
  height: number;
  alpha: number;
  lifetimeMs: number;
  remainingMs: number;
  lowPriority: boolean;
  heavy: boolean;
  motion: CombatTextureMotion;
  frameCount: number;
}

interface TextureLease {
  users: number;
  owned: boolean;
}

const leases = new WeakMap<Phaser.Textures.TextureManager, Map<string, TextureLease>>();
const HEAVY_PARTICLE_RESERVE = 36; // Two complete critical/reaction bursts at the 18-particle event limit.
const IMPACT_COUNTS: Record<CombatVfxKind, number> = { kinetic: 4, peeler: 7, fire: 12, frost: 10, lightning: 9, poison: 10, explosion: 16, ketchup: 9 };
const rgba = (color: number, alpha: number): string => `rgba(${color >> 16 & 255},${color >> 8 & 255},${color & 255},${alpha})`;

export class CombatParticleEmitter {
  private readonly active: Particle[] = [];
  private readonly pool: Phaser.GameObjects.Image[] = [];
  private readonly images = new Set<Phaser.GameObjects.Image>();
  private readonly textureKeys = new Set<string>();
  private sequence = 0;
  private destroyed = false;
  private reducedEffects = false;

  setReducedEffects(value: boolean): void { this.reducedEffects = value; }

  constructor(private readonly scene: Phaser.Scene) {
    scene.events.once(Phaser.Scenes.Events.SHUTDOWN, this.destroy, this);
  }

  get activeCount(): number {
    return this.active.length;
  }

  emit(payload: Readonly<CombatParticleEmission>): number {
    if (this.destroyed || !Number.isFinite(payload.x) || !Number.isFinite(payload.y) || !this.onScreen(payload.x, payload.y)) return 0;
    const lowPriority = payload.phase === "trail" || payload.phase === "muzzle";
    const heavy = payload.critical || payload.phase === "reaction";
    const ordinaryCapacity = this.capacity - HEAVY_PARTICLE_RESERVE;
    const capacity = heavy ? this.capacity : lowPriority ? Math.min(Math.floor(this.capacity * 0.75), ordinaryCapacity) : ordinaryCapacity;
    const eventLimit = payload.phase === "trail" ? 2 : payload.phase === "muzzle" ? 3 : payload.phase === "aura" ? 6 : payload.critical || payload.phase === "reaction" ? 18 : 16;
    const preferredCount = payload.phase === "impact" ? IMPACT_COUNTS[payload.kind] + (payload.critical ? 3 : 0) : eventLimit;
    if (this.reducedEffects && payload.phase === "trail") return 0;
    const requestedCount = (payload.count === undefined ? preferredCount : Number.isFinite(payload.count) ? payload.count : 0) * (this.reducedEffects && !heavy ? 0.5 : 1);
    const count = Math.max(0, Math.min(eventLimit, Math.floor(requestedCount), capacity - this.active.length));
    const directionLength = Math.hypot(payload.directionX ?? 1, payload.directionY ?? 0);
    const validDirection = Number.isFinite(directionLength) && directionLength > 0.001;
    const directionX = validDirection ? (payload.directionX ?? 1) / directionLength : 1;
    const directionY = validDirection ? (payload.directionY ?? 0) / directionLength : 0;
    const heading = Math.atan2(directionY, directionX);
    const requestedRadius = payload.radius ?? 36;
    const radius = Math.max(16, Math.min(100, Number.isFinite(requestedRadius) ? requestedRadius : 36));
    let emitted = 0;
    for (let index = 0; index < count; index++) {
      const form: ParticleForm = index === 0 ? lowPriority ? "ribbon" : "glow" : index === 1 && !lowPriority && payload.phase !== "aura" ? "ribbon" : "debris";
      const artwork = getCombatVfxTexture(this.scene, payload.kind, payload.phase, form, index);
      const textureKey = artwork?.key ?? this.acquireTexture(payload.kind, form);
      if (!textureKey) continue;
      const variation = ((this.sequence + index * 7) % 13) / 12;
      const radial = payload.phase === "reaction" || payload.phase === "aura";
      const angle = form === "ribbon" ? heading : heading + (radial ? index * Math.PI * (3 - Math.sqrt(5)) : (index / Math.max(1, count - 1) - 0.5) * Math.PI * 1.8);
      const image = this.pool.pop() ?? this.scene.add.image(payload.x, payload.y, textureKey);
      this.images.add(image);
      const criticalScale = payload.critical ? 1.2 : 1;
      const motion = artwork?.motion ?? "shrink";
      const layered = motion !== "shrink";
      const baseWidth = motion === "burst" ? Math.max(84, Math.min(132, radius * 2.25))
        : motion === "ring" ? Math.max(72, Math.min(110, radius * 1.85))
        : motion === "smoke" ? Math.max(64, Math.min(104, radius * 1.7))
        : form === "ribbon" ? lowPriority ? 48 + variation * 20 : 62 + variation * 28
        : form === "glow" ? Math.min(72, radius * 1.05) : payload.kind === "poison" ? 15 + variation * 8 : 15 + variation * 12;
      const width = Math.min(160, baseWidth * criticalScale);
      const height = layered || form !== "ribbon" ? width : (payload.kind === "peeler" || payload.kind === "lightning" ? artwork ? 26 : 9 : artwork ? 34 : 13) * criticalScale;
      const speed = motion === "smoke" ? 12 + variation * 10 : layered || form === "glow" ? 0 : lowPriority ? payload.phase === "trail" ? -36 - variation * 24 : 92 + variation * 60 : 115 + variation * 150;
      const lifetimeMs = layered && artwork ? artwork.lifetimeMs : form === "glow" ? 220 : lowPriority ? 170 + variation * 80 : payload.kind === "poison" ? 480 + variation * 190 : 320 + variation * 230;
      const distance = layered ? 0 : payload.phase === "aura" ? radius * (0.45 + variation * 0.35) : form === "debris" ? radius * 0.08 : 0;
      const rotation = artwork ? artwork.directional ? heading : layered ? 0 : angle + Math.PI / 2 : form === "ribbon" ? heading : angle + Math.PI / 2;
      const alpha = artwork ? artwork.opacity * (payload.phase === "trail" ? 0.78 : 1) : form === "glow" ? 0.84 : payload.phase === "trail" ? 0.72 : 0.96;
      const particle: Particle = { image, x: payload.x + Math.cos(angle) * distance, y: payload.y + Math.sin(angle) * distance,
        velocityX: Math.cos(angle) * speed, velocityY: Math.sin(angle) * speed,
        gravity: motion === "smoke" ? -46 : layered ? 0 : payload.kind === "fire" || payload.kind === "poison" ? -90 : form === "debris" ? 80 : 0,
        drag: payload.kind === "poison" ? 3.2 : 1.6, rotation, spin: !layered && form === "debris" ? (variation - 0.5) * 4 : 0,
        width, height, alpha, lifetimeMs, remainingMs: lifetimeMs, lowPriority, heavy, motion, frameCount: artwork?.frameCount ?? 1 };
      image.setTexture(textureKey, artwork ? 0 : undefined).clearTint().setTint(artwork?.tint ?? 0xffffff).setOrigin(0.5).setPosition(particle.x, particle.y).setDisplaySize(width, height)
        .setRotation(rotation).setAlpha(alpha).setDepth(motion === "smoke" ? 2.7 : form === "ribbon" ? 2.8 : 3.4).setBlendMode(motion === "smoke" ? Phaser.BlendModes?.NORMAL ?? 0 : Phaser.BlendModes?.ADD ?? 1).setActive(true).setVisible(true);
      this.active.push(particle);
      emitted++;
    }
    this.sequence += 1;
    return emitted;
  }

  update(deltaMs: number): void {
    if (this.destroyed) return;
    const elapsed = Number.isFinite(deltaMs) ? Math.max(0, deltaMs) : 0;
    const capacity = this.capacity;
    const ordinaryLimit = capacity - HEAVY_PARTICLE_RESERVE;
    let ordinaryCount = this.active.reduce((count, particle) => count + (particle.heavy ? 0 : 1), 0);
    while (this.active.length > capacity || ordinaryCount > ordinaryLimit) {
      const lowPriorityIndex = this.active.findIndex(particle => particle.lowPriority && !particle.heavy);
      const ordinaryIndex = lowPriorityIndex >= 0 ? lowPriorityIndex : this.active.findIndex(particle => !particle.heavy);
      const retiredIndex = ordinaryIndex >= 0 ? ordinaryIndex : 0;
      if (!this.active[retiredIndex].heavy) ordinaryCount -= 1;
      this.retire(retiredIndex);
    }
    const seconds = elapsed / 1000;
    for (let index = this.active.length - 1; index >= 0; index--) {
      const particle = this.active[index];
      particle.remainingMs -= elapsed;
      if (particle.remainingMs <= 0 || !this.onScreen(particle.x, particle.y, 140)) { this.retire(index); continue; }
      const damping = Math.exp(-particle.drag * seconds);
      particle.velocityX *= damping;
      particle.velocityY = particle.velocityY * damping + particle.gravity * seconds;
      particle.x += particle.velocityX * seconds;
      particle.y += particle.velocityY * seconds;
      particle.rotation += particle.spin * seconds;
      const remaining = particle.remainingMs / particle.lifetimeMs;
      const progress = 1 - remaining;
      const scale = particle.motion === "ring" ? 1 + progress * 0.2 : particle.motion === "smoke" ? 1 + progress * 0.25 : particle.motion === "burst" ? 1 : 0.45 + remaining * 0.55;
      const opacity = particle.motion === "burst" ? progress < 0.75 ? 1 : remaining / 0.25 : particle.motion === "smoke" ? 1 - progress * 0.65 : remaining * remaining;
      if (particle.frameCount > 1) particle.image.setFrame(Math.min(particle.frameCount - 1, Math.floor(progress * particle.frameCount)));
      particle.image.setPosition(particle.x, particle.y).setRotation(particle.rotation).setAlpha(particle.alpha * opacity)
        .setDisplaySize(particle.width * scale, particle.height * scale);
    }
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.scene.events.off?.(Phaser.Scenes.Events.SHUTDOWN, this.destroy, this);
    for (const image of this.images) image.destroy();
    this.images.clear(); this.active.length = 0; this.pool.length = 0;
    const registry = leases.get(this.scene.textures);
    for (const key of this.textureKeys) {
      const lease = registry?.get(key);
      if (!lease) continue;
      lease.users -= 1;
      if (lease.users === 0) { if (lease.owned) this.scene.textures.remove(key); registry?.delete(key); }
    }
    this.textureKeys.clear();
  }

  private get capacity(): number {
    return (this.scene.scale?.width ?? this.scene.cameras.main.width ?? 1280) < 700 ? 100 : 180;
  }

  private retire(index: number): void {
    const [particle] = this.active.splice(index, 1);
    particle.image.setActive(false).setVisible(false).setAlpha(0);
    this.pool.push(particle.image);
  }

  private onScreen(x: number, y: number, margin = 100): boolean {
    const view = this.scene.cameras.main.worldView;
    return !view || x >= view.x - margin && x <= view.x + view.width + margin && y >= view.y - margin && y <= view.y + view.height + margin;
  }

  private acquireTexture(kind: CombatVfxKind, form: ParticleForm): string | undefined {
    const key = `combat-particle:${kind}:${form}`;
    if (this.textureKeys.has(key)) return key;
    let registry = leases.get(this.scene.textures);
    if (!registry) { registry = new Map(); leases.set(this.scene.textures, registry); }
    let lease = registry.get(key);
    if (!lease) {
      const exists = this.scene.textures.exists(key);
      if (!exists) {
        if (typeof this.scene.textures.createCanvas !== "function") return undefined;
        const texture = this.scene.textures.createCanvas(key, form === "ribbon" ? 128 : 64, 64);
        if (!texture) return undefined;
        this.drawTexture(texture.getContext(), kind, form);
        texture.refresh();
      }
      lease = { users: 0, owned: !exists }; registry.set(key, lease);
    }
    lease.users += 1; this.textureKeys.add(key);
    return key;
  }

  private drawTexture(context: CanvasRenderingContext2D, kind: CombatVfxKind, form: ParticleForm): void {
    const [, primary, accent] = getCombatVfxPalette(kind);
    if (form === "ribbon") { this.drawRibbon(context, kind, primary, accent); return; }
    const glow = context.createRadialGradient(32, 32, 0, 32, 32, 31);
    glow.addColorStop(0, rgba(0xffffff, 1)); glow.addColorStop(0.08, rgba(0xffffff, 0.95));
    glow.addColorStop(0.22, rgba(primary, 0.78)); glow.addColorStop(0.55, rgba(accent, 0.24)); glow.addColorStop(1, rgba(accent, 0));
    context.fillStyle = glow; context.fillRect(0, 0, 64, 64);
    if (form === "glow") return;
    context.shadowColor = rgba(primary, 0.9); context.shadowBlur = 8;
    const fill = context.createLinearGradient(18, 8, 45, 55);
    fill.addColorStop(0, rgba(0xffffff, 1)); fill.addColorStop(0.4, rgba(primary, 0.98)); fill.addColorStop(1, rgba(accent, 0.45));
    context.fillStyle = fill; context.lineCap = "round"; context.beginPath();
    if (kind === "frost") {
      context.moveTo(32, 4); context.lineTo(44, 29); context.lineTo(33, 59); context.lineTo(22, 34); context.closePath(); context.fill();
      this.drawCore(context, [[32, 9], [33, 49]], 2.3);
    } else if (kind === "lightning") {
      this.drawCore(context, [[25, 7], [40, 23], [27, 33], [39, 57]], 2.8, primary);
      this.drawCore(context, [[20, 30], [43, 30]], 1.4);
    } else if (kind === "peeler") {
      context.moveTo(7, 48); context.quadraticCurveTo(23, 9, 57, 13); context.quadraticCurveTo(29, 17, 17, 52); context.closePath(); context.fill();
      this.drawCore(context, [[14, 40], [27, 21], [48, 15]], 2);
    } else if (kind === "fire") {
      context.moveTo(33, 5); context.quadraticCurveTo(26, 28, 43, 32); context.quadraticCurveTo(48, 51, 30, 57);
      context.quadraticCurveTo(17, 44, 25, 26); context.closePath(); context.fill();
      this.drawCore(context, [[31, 26], [30, 44]], 2.8);
    } else if (kind === "poison") {
      for (const [x, y, radius] of [[32, 32, 9], [18, 23, 4], [44, 42, 3]]) { context.beginPath(); context.arc(x, y, radius, 0, Math.PI * 2); context.fill(); }
      context.fillStyle = rgba(0xffffff, 0.94); context.beginPath(); context.arc(29, 29, 3, 0, Math.PI * 2); context.fill();
    } else if (kind === "explosion") {
      context.moveTo(17, 18); context.lineTo(41, 10); context.lineTo(51, 37); context.lineTo(30, 55); context.lineTo(19, 38); context.closePath(); context.fill();
      this.drawCore(context, [[28, 21], [35, 40]], 3);
    } else if (kind === "ketchup") {
      context.moveTo(29, 10); context.quadraticCurveTo(49, 35, 40, 51); context.quadraticCurveTo(20, 60, 18, 37); context.closePath(); context.fill();
      this.drawCore(context, [[29, 27], [26, 39]], 3);
    } else {
      this.drawCore(context, [[31, 9], [33, 54]], 2.2, primary);
      this.drawCore(context, [[19, 31], [45, 31]], 1.4);
    }
  }

  private drawRibbon(context: CanvasRenderingContext2D, kind: CombatVfxKind, primary: number, accent: number): void {
    const points = kind === "lightning" ? [[5, 37], [34, 25], [52, 38], [81, 24], [115, 30]] : kind === "peeler" ? [[6, 47], [33, 31], [63, 23], [115, 30]] : [[5, 35], [40, 31], [78, 28], [115, 30]];
    const tail = context.createLinearGradient(5, 32, 119, 32);
    tail.addColorStop(0, rgba(accent, 0)); tail.addColorStop(0.35, rgba(accent, 0.24)); tail.addColorStop(0.8, rgba(primary, 0.95)); tail.addColorStop(1, rgba(0xffffff, 1));
    context.lineCap = "round"; context.shadowColor = rgba(primary, 1); context.shadowBlur = 12;
    context.strokeStyle = tail; context.lineWidth = kind === "poison" || kind === "fire" ? 11 : 8;
    context.beginPath(); points.forEach(([x, y], index) => index === 0 ? context.moveTo(x, y) : context.lineTo(x, y)); context.stroke();
    context.shadowBlur = 3; context.lineWidth = 2.2; context.strokeStyle = tail; context.stroke();
    context.fillStyle = rgba(0xffffff, 0.98); context.beginPath(); context.arc(115, 30, 2.8, 0, Math.PI * 2); context.fill();
  }

  private drawCore(context: CanvasRenderingContext2D, points: number[][], width: number, glowColor?: number): void {
    if (glowColor !== undefined) {
      context.strokeStyle = rgba(glowColor, 0.9); context.lineWidth = width + 5; context.beginPath();
      points.forEach(([x, y], index) => index === 0 ? context.moveTo(x, y) : context.lineTo(x, y)); context.stroke();
    }
    context.shadowBlur = 2; context.strokeStyle = rgba(0xffffff, 0.98); context.lineWidth = width; context.beginPath();
    points.forEach(([x, y], index) => index === 0 ? context.moveTo(x, y) : context.lineTo(x, y)); context.stroke();
  }
}
