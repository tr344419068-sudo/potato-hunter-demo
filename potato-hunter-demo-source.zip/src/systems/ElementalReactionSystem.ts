import type { EntityId } from "../components/ComponentTypes";
import { EventBus } from "../managers/EventBus";
import { distanceSquared, normalize } from "../utils/math";
import type { CombatVfxKind } from "./CombatVfxModel";
import { resolveElementalReaction, type ElementalReactionProfile } from "./ElementalReactionModel";
import type { GameRuntime } from "./SystemTypes";

function toHexColor(color: number): string {
  return `#${color.toString(16).padStart(6, "0")}`;
}

function applyReactionDamage(
  runtime: GameRuntime,
  entityId: EntityId,
  damage: number,
  color: number,
): void {
  const health = runtime.world.components.health.get(entityId);
  const transform = runtime.world.components.transforms.get(entityId);
  if (!health || !transform || damage <= 0) {
    return;
  }

  const roundedDamage = Math.max(1, Math.ceil(damage));
  const monster = runtime.world.components.monsters.get(entityId);
  let remainingDamage = roundedDamage;
  if (monster?.shieldHp && monster.shieldHp > 0) {
    const absorbed = Math.min(monster.shieldHp, remainingDamage);
    monster.shieldHp -= absorbed;
    remainingDamage -= absorbed;
    EventBus.emit("combat:damage", {
      x: transform.x, y: transform.y, value: absorbed, targetId: entityId,
      category: "shield", color: "#89cfff", isReaction: true,
    });
  }
  health.current -= remainingDamage;
  runtime.world.components.hitFlashes.set(entityId, { remainingMs: 125, totalMs: 125 });
  if (remainingDamage > 0) EventBus.emit("combat:damage", {
    x: transform.x,
    y: transform.y,
    value: remainingDamage,
    targetId: entityId,
    category: "outgoing",
    color: toHexColor(color),
    isReaction: true,
  });
}

function applyReactionKnockback(
  runtime: GameRuntime,
  entityId: EntityId,
  originX: number,
  originY: number,
  force: number,
): void {
  const transform = runtime.world.components.transforms.get(entityId);
  if (!transform) {
    return;
  }
  const direction = normalize(transform.x - originX, transform.y - originY);
  runtime.world.components.knockbacks.set(entityId, {
    x: direction.x * force,
    y: direction.y * force,
    remainingMs: 170,
  });
}

export function triggerElementalReaction(
  runtime: GameRuntime,
  targetId: EntityId,
  incomingKind: CombatVfxKind,
  sourceDamage: number,
): Readonly<ElementalReactionProfile> | undefined {
  const statuses = runtime.world.components.statuses.get(targetId) ?? [];
  const reaction = resolveElementalReaction(incomingKind, statuses.map((status) => status.type));
  const targetTransform = runtime.world.components.transforms.get(targetId);
  if (!reaction || !targetTransform) {
    return undefined;
  }

  const remainingStatuses = statuses.filter((status) => status.type !== reaction.consumeStatus);
  if (remainingStatuses.length > 0) {
    runtime.world.components.statuses.set(targetId, remainingStatuses);
  } else {
    runtime.world.components.statuses.delete(targetId);
  }

  applyReactionDamage(runtime, targetId, sourceDamage * reaction.bonusDamageMultiplier, reaction.primaryColor);
  const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
  applyReactionKnockback(
    runtime,
    targetId,
    playerTransform?.x ?? targetTransform.x - 1,
    playerTransform?.y ?? targetTransform.y,
    reaction.knockbackForce,
  );

  const radiusSquared = reaction.radius * reaction.radius;
  const nearbyTargets = [...runtime.world.components.monsters.keys()]
    .filter((entityId) => entityId !== targetId)
    .map((entityId) => ({
      entityId,
      transform: runtime.world.components.transforms.get(entityId),
    }))
    .filter((candidate): candidate is { entityId: EntityId; transform: NonNullable<typeof candidate.transform> } => (
      candidate.transform !== undefined
      && distanceSquared(targetTransform.x, targetTransform.y, candidate.transform.x, candidate.transform.y) <= radiusSquared
    ))
    .sort((left, right) => (
      distanceSquared(targetTransform.x, targetTransform.y, left.transform.x, left.transform.y)
      - distanceSquared(targetTransform.x, targetTransform.y, right.transform.x, right.transform.y)
    ))
    .slice(0, reaction.maxSplashTargets);

  for (const candidate of nearbyTargets) {
    applyReactionDamage(runtime, candidate.entityId, sourceDamage * reaction.splashDamageMultiplier, reaction.secondaryColor);
    applyReactionKnockback(runtime, candidate.entityId, targetTransform.x, targetTransform.y, reaction.knockbackForce * 0.72);
  }

  EventBus.emit("combat:reaction", {
    ...reaction,
    x: targetTransform.x,
    y: targetTransform.y,
    affectedTargets: nearbyTargets.length + 1,
  });
  return reaction;
}
