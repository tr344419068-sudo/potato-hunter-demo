import type Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import { getSpatialSkillVisuals } from "./SpatialSkillSystem";
import type { GameRuntime } from "./SystemTypes";

const SPIKE_ART = "icon_skill_starch_spikes";
const TURRET_ART = "icon_skill_roast_turret";
const OIL_BOTTLE = "projectile_hot_oil_flask";
const OIL_FIRE = "vfx_boss_fire_flipbook";
const OIL_EMBER = "vfx_boss_ember_ring";

/** Scene-owned images are reused for live placements and destroyed by Phaser on shutdown. */
export class SpatialSkillView {
  private readonly spikeSprites: Phaser.GameObjects.Image[] = [];
  private turretSprite?: Phaser.GameObjects.Image;
  private oilBottle?: Phaser.GameObjects.Image;
  private oilRim?: Phaser.GameObjects.Image;
  private readonly oilFlames: Phaser.GameObjects.Image[] = [];

  constructor(private readonly scene: Phaser.Scene) {}

  draw(g: Phaser.GameObjects.Graphics, world: GameRuntime["world"], shots = g): void {
    const { now, trail, trailRadius, turret, oilFlight, oilField } = getSpatialSkillVisuals(world);
    this.oilBottle?.setVisible(false);
    this.oilRim?.setVisible(false);
    for (const flame of this.oilFlames) flame.setVisible(false);
    if (oilFlight) {
      const { origin, x, y, startedAt, landsAt, angle } = oilFlight;
      const t = Math.max(0, Math.min(1, (now - startedAt) / (landsAt - startedAt)));
      const groundX = origin.x + (x - origin.x) * t, groundY = origin.y + (y - origin.y) * t;
      const height = 26 * (1 - t) + Math.sin(Math.PI * t) * 79;
      g.fillStyle(0x261b14, .34).fillEllipse(groundX, groundY, 16, 7);
      if (AssetManager.hasTexture(this.scene, OIL_BOTTLE)) {
        const bottle = this.oilBottle ?? (this.oilBottle = this.createSprite(OIL_BOTTLE));
        bottle.setOrigin(.5).setDepth(3.15).setPosition(groundX, groundY - height)
          .setDisplaySize(42, 42).setRotation(angle + t * Math.PI * 2).setVisible(true);
      } else shots.fillStyle(0xffb452, .9).fillCircle(groundX, groundY - height, 6);
    }
    if (oilField) {
      const { x, y, radius, startedAt, expiresAt, evolved } = oilField;
      const age = now - startedAt, alpha = Math.max(0, Math.min(1, (expiresAt - now) / 550));
      g.fillStyle(0x442616, .25 * alpha).fillCircle(x, y, radius);
      g.lineStyle(1.5, 0xffbc61, .49 * alpha).strokeCircle(x, y, radius);
      if (AssetManager.hasTexture(this.scene, OIL_EMBER)) {
        const rim = this.oilRim ?? (this.oilRim = this.createSprite(OIL_EMBER));
        const frames = AssetManager.getAsset(OIL_EMBER)?.frameCount ?? 1;
        rim.setOrigin(.5).setDepth(1.22).setPosition(x, y).setDisplaySize(radius * 2.14, radius * 2.14)
          .setFrame(Math.min(frames - 1, 1 + Math.floor(age / 90) % 4)).setTint(0xffbd68).setAlpha(.46 * alpha).setVisible(true);
      }
      if (AssetManager.hasTexture(this.scene, OIL_FIRE)) {
        const frames = AssetManager.getAsset(OIL_FIRE)?.frameCount ?? 1;
        const count = evolved ? 7 : 5;
        for (let i = 0; i < count; i++) {
          const cycle = (age + i * 132) % 880, frame = Math.min(frames - 1, Math.floor(cycle / 880 * frames));
          const a = i * Math.PI * 2 / count + .42, d = radius * (i % 2 === 0 ? .61 : .34);
          const fire = this.oilFlames[i] ?? (this.oilFlames[i] = this.createSprite(OIL_FIRE));
          fire.setOrigin(.5, .72).setDepth(1.58).setFrame(frame)
            .setPosition(x + Math.cos(a) * d, y + Math.sin(a) * d)
            .setDisplaySize(radius * .85, radius * .85).setAlpha(.82 * alpha).setVisible(true);
        }
      }
    }
    const useSpikeArt = trail.length > 0 && AssetManager.hasTexture(this.scene, SPIKE_ART);
    let usedSpikes = 0;
    for (const { x, y, link, armedAt, expiresAt } of trail) {
      const alpha = Math.min(1, Math.max(0, (expiresAt - now) / 760)) * (armedAt <= now ? 1 : .5);
      if (link) {
        g.lineStyle(trailRadius * 2, 0x242f21, .39 * alpha).lineBetween(link.x, link.y, x, y);
        g.lineStyle(trailRadius * .92, 0x91aa52, .17 * alpha).lineBetween(link.x, link.y, x, y);
        g.lineStyle(1.4, 0xd3e1a2, .49 * alpha).lineBetween(link.x, link.y, x, y);
      }
      g.fillStyle(0x182719, .6 * alpha).fillEllipse(x, y + 2, 30, 11);
      if (useSpikeArt) {
        const i = usedSpikes++;
        const sprite = this.spikeSprites[i] ?? (this.spikeSprites[i] = this.createSprite(SPIKE_ART));
        sprite.setPosition(x, y).setDisplaySize(35, 35).setAlpha(alpha).setVisible(true);
      } else {
        // A small positional cue remains if a client cannot load the texture.
        g.lineStyle(2, 0xd4b86a, alpha).strokeEllipse(x, y + 2, 29, 10);
      }
    }
    for (let i = usedSpikes; i < this.spikeSprites.length; i++) this.spikeSprites[i].setVisible(false);

    if (!turret) {
      this.turretSprite?.setVisible(false);
      return;
    }
    const { x, y, angle, evolved, shot } = turret;
    const alpha = Math.min(1, Math.max(0, (turret.expiresAt - now) / 430));
    const size = evolved ? 59 : 52;
    const direction = Math.cos(angle) < 0 ? -1 : 1;
    const shotAge = shot ? now - shot.at : Infinity;
    const recoil = 3.5 * Math.max(0, 1 - shotAge / 115);
    const mx = x + direction * (size - recoil) * .335;
    const my = y - size * .335;
    g.fillStyle(0x162320, .68 * alpha).fillEllipse(x, y + 3, size * .77, 15);
    if (evolved) g.lineStyle(1.5, 0xffc264, .64 * alpha).strokeEllipse(x, y + 1, size * 1.03, 19);
    if (AssetManager.hasTexture(this.scene, TURRET_ART)) {
      const sprite = this.turretSprite ?? (this.turretSprite = this.createSprite(TURRET_ART));
      sprite.setPosition(x, y).setDisplaySize(size - recoil, size).setAlpha(alpha).setFlipX(direction < 0).setVisible(true);
    } else {
      this.turretSprite?.setVisible(false);
      g.lineStyle(2, 0xffca6d, alpha).strokeEllipse(x, y - 3, 38, 22);
    }

    if (!shot || shotAge >= 270) return;
    if (shotAge < 138) {
      const flash = (1 - shotAge / 138) * alpha;
      const travel = Math.min(1, .30 + shotAge / 50), tail = Math.max(0, travel - .46);
      const vx = shot.x - mx, vy = shot.y - my;
      shots.lineStyle(6, 0xf29442, .48 * flash).lineBetween(mx + vx * tail, my + vy * tail, mx + vx * travel, my + vy * travel);
      shots.lineStyle(2.2, 0xffe8b0, flash).lineBetween(mx + vx * tail, my + vy * tail, mx + vx * travel, my + vy * travel);
      shots.fillStyle(0xffc465, flash).fillCircle(mx, my, 8 * flash);
    }
    if (shot.splashRadius > 0) {
      const phase = shotAge / 270, radius = shot.splashRadius * (.25 + .75 * phase);
      g.lineStyle(5, 0xd48135, .47 * (1 - phase)).strokeCircle(shot.x, shot.y, radius);
      g.lineStyle(1.8, 0xffdfa2, .88 * (1 - phase)).strokeCircle(shot.x, shot.y, radius);
    }
  }

  private createSprite(assetId: string): Phaser.GameObjects.Image {
    return this.scene.add.image(0, 0, AssetManager.getTextureKey(assetId)).setOrigin(.5, .89).setDepth(1.5);
  }
}
