import type Phaser from 'phaser';
import { AssetManager } from '../managers/AssetManager';
import { getIceCover, getIceCoverShatters, ICE_SHATTER_MS, sweepIceCover } from './IceTerrain';
import { getSnowEnemies, SNOW_ELITE_ROLL_RANGE, SNOW_GUARD_ANGLE, SNOW_NEEDLE_RANGE, SNOW_ROLL_RANGE } from './SnowEnemySystem';
import type { GameRuntime } from './SystemTypes';

const COVER = 'snow_ice_cover';
const SHATTER = 'vfx_snow_ice_shatter';
const ALERT = 0xffcc88;
const WARNING_FILL = 0xab3c25;
const FROST = 0x9bf1ff;

/** Raster terrain and fragments; graphics are reserved for live combat tells. */
export class IceTerrainView {
  private readonly marks: Phaser.GameObjects.Graphics;
  private readonly images: Phaser.GameObjects.Image[] = [];
  private usedImages = 0;

  constructor(private readonly scene: Phaser.Scene) {
    this.marks = scene.add.graphics().setDepth(1.41);
  }

  draw({ world, playerId }: Pick<GameRuntime, 'world' | 'playerId'>): void {
    this.usedImages = 0;
    const gfx = this.marks;
    gfx.clear();
    for (const { x, y, radius } of getIceCover(world)) {
      this.bitmap(COVER, x, y, radius * 2.37, undefined, 1, 1.72);
    }
    for (const { cover, remainingMs } of getIceCoverShatters(world)) {
      const p = 1 - remainingMs / ICE_SHATTER_MS;
      const frames = AssetManager.getAsset(SHATTER)?.frameCount ?? 1;
      const frame = frames > 1 ? Math.min(frames - 1, Math.floor(p * frames)) : undefined;
      this.bitmap(SHATTER, cover.x, cover.y, cover.radius * (3.3 + p * 1.1), frame, 1 - p * p, 2.4);
    }
    const heroRadius = world.components.transforms.get(playerId)?.radius ?? 16;
    for (const [id, state] of getSnowEnemies(world)) {
      const actor = world.components.transforms.get(id);
      if (!actor || (world.components.health.get(id)?.current ?? 0) <= 0) continue;
      const { x, y, radius } = actor;
      const p = 1 - state.remainingMs / state.durationMs;
      if (state.phase === 'guard' && state.guardHp > 0) {
        const r = radius + 10;
        gfx.lineStyle(7, 0x174362, .83).beginPath().arc(x, y, r, state.angle - SNOW_GUARD_ANGLE, state.angle + SNOW_GUARD_ANGLE).strokePath();
        gfx.lineStyle(3, FROST, .86).beginPath().arc(x, y, r, state.angle - SNOW_GUARD_ANGLE, state.angle + SNOW_GUARD_ANGLE).strokePath();
      } else if (state.phase === 'tell') {
        const rolling = state.role === 'roller' || state.role === 'elite';
        const range = state.role === 'elite' ? SNOW_ELITE_ROLL_RANGE : rolling ? SNOW_ROLL_RANGE : SNOW_NEEDLE_RANGE;
        const vx = Math.cos(state.angle), vy = Math.sin(state.angle);
        const target = { x: x + vx * range, y: y + vy * range };
        const along = (sweepIceCover(world, actor, target, rolling ? radius : 7)?.time ?? 1) * range;
        const width = (rolling ? radius : 7) + heroRadius;
        this.lane(actor, vx, vy, along, width, p, rolling);
      } else if (state.phase === 'stagger') {
        gfx.lineStyle(3, FROST, .86 - p * .38).strokeCircle(x, y, radius + 10 + 3 * p);
      }
    }
    for (let i = this.usedImages; i < this.images.length; i++) this.images[i].setVisible(false);
  }

  destroy(): void {
    this.marks.destroy();
    for (const image of this.images) image.destroy();
    this.images.length = 0;
  }

  private bitmap(id: string, x: number, y: number, width: number, frame: number | undefined, alpha: number, depth: number): void {
    if (!AssetManager.hasTexture(this.scene, id)) return;
    const texture = AssetManager.getTextureKey(id);
    const asset = AssetManager.getAsset(id);
    const origin = asset?.footPoint ?? { x: .5, y: .83 };
    const height = width * (asset?.frameHeight ?? asset?.height ?? 1) / (asset?.frameWidth ?? asset?.width ?? 1);
    const index = this.usedImages++;
    const image = this.images[index] ?? (this.images[index] = this.scene.add.image(x, y, texture, frame));
    image.setVisible(true).setTexture(texture, frame).setPosition(x, y).setOrigin(origin.x, origin.y)
      .setDisplaySize(width, height).setDepth(depth).setAlpha(alpha);
  }

  private lane(from: { x: number; y: number }, vx: number, vy: number, length: number, radius: number, p: number, rolling: boolean): void {
    const gfx = this.marks;
    const end = { x: from.x + vx * length, y: from.y + vy * length };
    const angle = Math.atan2(vy, vx);
    const corners = [end, from].flatMap((point, cap) => Array.from({ length: 11 }, (_, i) => {
      const heading = angle + (i / 10 - .5 + cap) * Math.PI;
      return { x: point.x + Math.cos(heading) * radius, y: point.y + Math.sin(heading) * radius };
    }));
    gfx.fillStyle(WARNING_FILL, (rolling ? .13 : .07) + p * .15).fillPoints(corners, true);
    gfx.lineStyle(rolling ? 3 : 2, ALERT, .65 + p * .3).strokePoints(corners, true);
    const flank = rolling ? Math.min(17, radius - 2) : 7;
    for (let d = rolling ? 31 : 44; d < length - 8; d += rolling ? 45 : 58) {
      const x = from.x + vx * d, y = from.y + vy * d;
      gfx.beginPath().moveTo(x - vx * 6 - vy * flank, y - vy * 6 + vx * flank)
        .lineTo(x + vx * 6, y + vy * 6).lineTo(x - vx * 6 + vy * flank, y - vy * 6 - vx * flank).strokePath();
    }
  }
}
