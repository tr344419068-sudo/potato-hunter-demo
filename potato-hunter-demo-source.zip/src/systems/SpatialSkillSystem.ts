import type { EntityId } from "../components/ComponentTypes";
import { EventBus } from "../managers/EventBus";
import { absorbMonsterShield } from "./MonsterShield";
import { applyHealthDamage } from "./HealthDamage";
import type { SpatialSkillProfile } from "../managers/SkillTypes";
import { distanceSquared } from "../utils/math";
import type { GameRuntime, System } from "./SystemTypes";

type Point = { x: number; y: number };
interface Spike extends Point { armedAt: number; expiresAt: number; link?: Point }
interface Shot extends Point { at: number; splashRadius: number }
interface Turret extends Point { evolved: boolean; expiresAt: number; shotAt: number; angle: number; shot?: Shot }
interface OilFlight extends Point { origin: Point; startedAt: number; landsAt: number; angle: number }
interface OilField extends Point { startedAt: number; expiresAt: number; nextTick: number; radius: number; evolved: boolean }
interface SpatialVisuals {
  now: number; trail: readonly Readonly<Spike>[]; trailRadius: number;
  turret?: Readonly<Turret>;
  oilFlight?: Readonly<OilFlight>; oilField?: Readonly<OilField>;
}
const EMPTY_FIELD: SpatialVisuals = { now: 0, trail: [], trailRadius: 0 };
const fields = new WeakMap<GameRuntime["world"], SpatialVisuals>();
const SPIKE_SPACING = 44;
const SPIKE_ARM_MS = 260;
const TURRET_ARM_MS = 220;
const TURRET_SPLASH_RADIUS = 54;
const OIL_FLIGHT_MS = 410;

export function getSpatialSkillVisuals(world: GameRuntime["world"]): Readonly<SpatialVisuals> {
  return fields.get(world) ?? EMPTY_FIELD;
}

export class SpatialSkillSystem implements System {
  private ownerWorld?: GameRuntime["world"];
  private ownerPlayer?: EntityId;
  private now = 0;
  private spikes: Spike[] = [];
  private trailOrigin?: Point;
  private distanceRemainder = 0;
  private trailId?: string;
  private readonly nextTrailHit = new Map<EntityId, number>();
  private turret?: Turret;
  private turretId?: string;
  private deployAt = 0;
  private oilFlight?: OilFlight;
  private oilField?: OilField;
  private oilCastAt = 0;
  private oilId?: string;

  update(deltaMs: number, runtime: GameRuntime): void {
    if (this.ownerWorld !== runtime.world || this.ownerPlayer !== runtime.playerId) {
      if (this.ownerWorld) fields.delete(this.ownerWorld);
      this.reset(); this.now = 0;
      this.ownerWorld = runtime.world; this.ownerPlayer = runtime.playerId;
    }
    this.now += Number.isFinite(deltaMs) ? Math.max(0, deltaMs) : 0;
    const { world, playerId } = runtime;
    const hero = world.components.transforms.get(playerId);
    if (!hero || (world.components.health.get(playerId)?.current ?? 0) <= 0) {
      this.reset(); fields.delete(world); return;
    }
    const profiles = runtime.skillManager.getSpatialProfiles(world.components.players.get(playerId)?.level);
    const trail = profiles.find(p => p.kind === "trail");
    const turret = profiles.find(p => p.kind === "turret");
    const oil = profiles.find(p => p.kind === "oil");
    if (trail?.skillId !== this.trailId) {
      this.resetTrail(); this.trailId = trail?.skillId;
    }
    if (turret?.skillId !== this.turretId) {
      this.turret = undefined; this.deployAt = this.now; this.turretId = turret?.skillId;
    }
    if (trail) this.updateTrail(runtime, hero, trail);
    if (turret) this.updateTurret(runtime, hero, turret);
    if (!oil) { this.oilFlight = this.oilField = undefined; this.oilCastAt = 0; }
    if (oil) this.updateOil(runtime, hero, oil);
    if (trail || turret || oil) fields.set(world, { now: this.now, trail: this.spikes, trailRadius: trail?.radius ?? 0,
      turret: this.turret, oilFlight: this.oilFlight, oilField: this.oilField });
    else fields.delete(world);
  }

  private reset(): void {
    this.resetTrail(); this.trailId = undefined;
    this.turret = undefined; this.turretId = undefined; this.deployAt = 0;
    this.oilFlight = undefined; this.oilField = undefined; this.oilCastAt = 0; this.oilId = undefined;
  }

  private updateOil(runtime: GameRuntime, hero: Point, profile: SpatialSkillProfile): void {
    if (this.oilId !== profile.skillId) {
      this.oilId = profile.skillId;
      this.oilFlight = this.oilField = undefined;
      this.oilCastAt = this.now;
    }
    const lob = this.oilFlight;
    if (lob && this.now >= lob.landsAt) {
      this.oilFlight = undefined;
      this.oilField = { x: lob.x, y: lob.y, startedAt: lob.landsAt, expiresAt: lob.landsAt + profile.lifeMs,
        nextTick: lob.landsAt, radius: profile.radius, evolved: profile.evolved };
      if (this.now < this.oilField.expiresAt) EventBus.emit("oil:impact", { x: lob.x, y: lob.y, radius: profile.radius, evolved: profile.evolved, world: runtime.world });
    }
    const field = this.oilField;
    if (field && field.nextTick < field.expiresAt && this.now >= field.nextTick
      && (this.now < field.expiresAt || this.now - field.nextTick <= 40)) {
      const fresh = field.nextTick === field.startedAt;
      field.nextTick += (1 + Math.floor((this.now - field.nextTick) / profile.shotMs)) * profile.shotMs;
      for (const [id] of runtime.world.components.monsters) {
        const target = runtime.world.components.transforms.get(id);
        if (!target || distanceSquared(target.x, target.y, field.x, field.y) > (field.radius + target.radius * .5) ** 2) continue;
        const crit = fresh && (runtime.random ?? Math.random)() < profile.critChance;
        this.hit(runtime, id, Math.ceil(profile.damage * (fresh ? (profile.evolved ? 2.4 : 1.8) * (crit ? profile.critMultiplier : 1) : 1)), crit);
      }
    }
    if (field && this.now >= field.expiresAt) this.oilField = undefined;
    if (this.oilFlight || this.oilField || this.now < this.oilCastAt) return;
    const velocity = runtime.world.components.velocities.get(runtime.playerId);
    const speed = velocity ? Math.hypot(velocity.x, velocity.y) : 0;
    const moving = velocity && speed > 12;
    const range = profile.evolved ? 425 : 360;
    let target: Point | undefined, best = (range + profile.radius * .4) ** 2;
    for (const id of runtime.world.components.monsters.keys()) {
      const transform = runtime.world.components.transforms.get(id);
      if (!transform || (runtime.world.components.health.get(id)?.current ?? 0) <= 0) continue;
      const dx = transform.x - hero.x, dy = transform.y - hero.y, distance = dx * dx + dy * dy;
      if (distance >= best || (moving && (dx * velocity.x + dy * velocity.y) < Math.sqrt(distance) * speed * .62)) continue;
      target = transform; best = distance;
    }
    if (!target) return;
    const dx = target.x - hero.x, dy = target.y - hero.y;
    const aimDistance = Math.hypot(dx, dy);
    const face = runtime.world.components.spriteJuices.get(runtime.playerId)?.facingX ?? 1;
    const ux = aimDistance > 1 ? dx / aimDistance : moving ? velocity.x / speed : face;
    const uy = aimDistance > 1 ? dy / aimDistance : moving ? velocity.y / speed : 0;
    const distance = Math.min(range, Math.max(76, aimDistance));
    this.oilFlight = { x: hero.x + ux * distance, y: hero.y + uy * distance, origin: { x: hero.x, y: hero.y },
      startedAt: this.now, landsAt: this.now + OIL_FLIGHT_MS, angle: Math.atan2(uy, ux) };
    this.oilCastAt = this.now + profile.rechargeMs;
    EventBus.emit("weapon:fired", { world: runtime.world, playerId: runtime.playerId, skillId: profile.skillId,
      x: hero.x, y: hero.y, directionX: ux, directionY: uy, color: 0xffad54, size: 9, projectileCount: 1, vfxKind: "fire" });
  }

  private resetTrail(): void {
    this.spikes = []; this.trailOrigin = undefined; this.distanceRemainder = 0; this.nextTrailHit.clear();
  }

  private updateTrail(runtime: GameRuntime, hero: Point, profile: SpatialSkillProfile): void {
    this.spikes = this.spikes.filter(spike => spike.expiresAt > this.now);
    for (const [id, next] of this.nextTrailHit) if (next <= this.now || !runtime.world.components.monsters.has(id)) this.nextTrailHit.delete(id);
    const from = this.trailOrigin;
    this.trailOrigin = { x: hero.x, y: hero.y };
    if (from) {
      const dx = hero.x - from.x, dy = hero.y - from.y, length = Math.hypot(dx, dy);
      // A real dash fits within a frame's movement budget; never join a debug teleport.
      if (length > 360) { this.distanceRemainder = 0; this.spikes = []; }
      else if (length > 0) {
        const cap = profile.evolved ? 14 : 11;
        for (let along = SPIKE_SPACING - this.distanceRemainder; along <= length + 1e-7; along += SPIKE_SPACING) {
          const x = from.x + dx * along / length, y = from.y + dy * along / length;
          const previous = this.spikes[this.spikes.length - 1];
          const link = profile.evolved && previous && distanceSquared(x, y, previous.x, previous.y) <= (SPIKE_SPACING + 1) ** 2 ? previous : undefined;
          this.spikes.push({ x, y, armedAt: this.now + SPIKE_ARM_MS, expiresAt: this.now + profile.lifeMs, link: link && { x: link.x, y: link.y } });
          if (this.spikes.length > cap) this.spikes.shift();
        }
        this.distanceRemainder = (this.distanceRemainder + length + 1e-7) % SPIKE_SPACING;
      }
    }

    const { world } = runtime;
    for (let i = 0; i < this.spikes.length; i++) {
      const spike = this.spikes[i];
      if (spike.armedAt > this.now) continue;
      for (const [id, monster] of world.components.monsters) {
        if (this.nextTrailHit.has(id)) continue;
        const target = world.components.transforms.get(id);
        if (!target || (world.components.health.get(id)?.current ?? 0) <= 0) continue;
        const distance = spike.link ? segmentDistanceSquared(target, spike.link, spike) : distanceSquared(target.x, target.y, spike.x, spike.y);
        if (distance > (profile.radius + target.radius) ** 2) continue;
        this.hit(runtime, id, profile.damage, false);
        this.nextTrailHit.set(id, this.now + (profile.evolved ? 600 : 240));
        if (profile.evolved && !monster.isBoss) {
          const statuses = world.components.statuses.get(id) ?? [];
          if (!statuses.some(s => s.type === "slow" && s.slowMultiplier < .69 && s.remainingMs > 0)) {
            world.components.statuses.set(id, [...statuses.filter(s => s.type !== "slow"), { type: "slow", remainingMs: 540, totalMs: 540, slowMultiplier: .69, damagePerSecond: 0 }]);
          }
        }
        if (!profile.evolved) {
          EventBus.emit("fx:sparks", { x: spike.x, y: spike.y, color: 0xe1cf82, count: 4, size: 4 });
          this.spikes.splice(i--, 1);
          break;
        }
      }
    }
  }

  private updateTurret(runtime: GameRuntime, hero: Point, profile: SpatialSkillProfile): void {
    if (this.turret && this.turret.expiresAt <= this.now) this.turret = undefined;
    if (!this.turret && this.now >= this.deployAt && this.nearest(runtime, hero, profile.radius) !== undefined) {
      this.turret = { x: hero.x, y: hero.y, angle: -.65, evolved: profile.evolved, expiresAt: this.now + profile.lifeMs, shotAt: this.now + TURRET_ARM_MS };
      this.deployAt = this.now + profile.rechargeMs;
    }
    const turret = this.turret;
    if (!turret || turret.shotAt > this.now) return;
    const id = this.nearest(runtime, turret, profile.radius);
    if (id === undefined) return;
    const target = runtime.world.components.transforms.get(id)!;
    const crit = (runtime.random ?? Math.random)() < profile.critChance;
    const damage = Math.ceil(profile.damage * (crit ? profile.critMultiplier : 1));
    const splashRadius = profile.evolved && crit ? TURRET_SPLASH_RADIUS : 0;
    turret.angle = Math.atan2(target.y - turret.y, target.x - turret.x);
    turret.shotAt = this.now + profile.shotMs;
    turret.shot = { x: target.x, y: target.y, at: this.now, splashRadius };
    this.hit(runtime, id, damage, crit);
    EventBus.emit("fx:sparks", { x: target.x, y: target.y, color: 0xffc365, count: crit ? 7 : 4, size: 5 });
    if (splashRadius <= 0) return;
    for (const other of runtime.world.components.monsters.keys()) {
      if (other === id) continue;
      const t = runtime.world.components.transforms.get(other);
      if (t && distanceSquared(target.x, target.y, t.x, t.y) <= splashRadius ** 2) this.hit(runtime, other, Math.ceil(damage * .54), false);
    }
  }

  private nearest(runtime: GameRuntime, origin: Point, radius: number): EntityId | undefined {
    let nearest: EntityId | undefined, best = radius ** 2;
    for (const id of runtime.world.components.monsters.keys()) {
      const t = runtime.world.components.transforms.get(id);
      if (!t || (runtime.world.components.health.get(id)?.current ?? 0) <= 0) continue;
      const d = distanceSquared(t.x, t.y, origin.x, origin.y);
      if (d < best || (d === best && nearest === undefined)) { nearest = id; best = d; }
    }
    return nearest;
  }

  private hit(runtime: GameRuntime, id: EntityId, damage: number, crit: boolean): void {
    const { world } = runtime;
    const target = world.components.transforms.get(id), health = world.components.health.get(id), monster = world.components.monsters.get(id);
    if (!target || !health || !monster || health.current <= 0) return;
    const { x, y } = target;
    const shielded = absorbMonsterShield(monster, target, damage);
    if (shielded) {
      EventBus.emit("combat:damage", { x, y, value: shielded, targetId: id, color: "#89cfff", category: "shield" });
    }
    const hpDamage = applyHealthDamage(health, damage - shielded);
    if (hpDamage <= 0 && shielded <= 0) return;
    const flash = crit ? 135 : 90;
    world.components.hitFlashes.set(id, { remainingMs: flash, totalMs: flash });
    if (hpDamage > 0) EventBus.emit("combat:damage", { x, y, value: hpDamage, targetId: id, category: "outgoing", color: crit ? "#ffca3a" : "#fff0b0", isCrit: crit });
  }
}

function segmentDistanceSquared(point: Point, a: Point, b: Point): number {
  const dx = b.x - a.x, dy = b.y - a.y;
  const t = Math.max(0, Math.min(1, ((point.x - a.x) * dx + (point.y - a.y) * dy) / Math.max(1e-6, dx * dx + dy * dy)));
  return distanceSquared(point.x, point.y, a.x + dx * t, a.y + dy * t);
}
