import { distanceSquared } from "../utils/math";
import { canReceiveHostileDamage, getHostileHitGraceMs } from "./PlayerDamageModel";
import type { GameRuntime, System } from "./SystemTypes";

export class MonsterContactSystem implements System {
  readonly telemetrySource = "MonsterContactSystem";
  update(_deltaMs: number, runtime: GameRuntime): void {
    const player = runtime.world.components.players.get(runtime.playerId);
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const playerHealth = runtime.world.components.health.get(runtime.playerId);
    if (!player || !playerTransform || !playerHealth) {
      return;
    }

    for (const [monsterId, monster] of runtime.world.components.monsters) {
      if (monster.behavior === "jumper" && monster.controlledMotion) {
        continue;
      }
      const monsterTransform = runtime.world.components.transforms.get(monsterId);
      if (!monsterTransform) {
        continue;
      }

      const hitRadius = playerTransform.radius + monsterTransform.radius;
      const isTouching = distanceSquared(playerTransform.x, playerTransform.y, monsterTransform.x, monsterTransform.y) <= hitRadius * hitRadius;

      if (isTouching && canReceiveHostileDamage(player)) {
        playerHealth.current -= monster.damage;
        player.damageCooldownMs = getHostileHitGraceMs("contact");
      }
    }

    if (playerHealth.current <= 0) {
      playerHealth.current = 0;
      runtime.endRun();
    }
  }
}
