import type { CombatVfxKind } from './CombatVfxModel';
export const MAX_AREA_LAYERS = 3;
export const AREA_WAVE_PERIOD_MS = 900;
export const AREA_MOTE_PERIOD_MS = 720;
export const AREA_ART_DIAMETER_COVERAGE = 1;
export function getAreaVfxSpec(kind: CombatVfxKind) {
    if (kind === 'poison')
        return { primaryColor: 0x93f2b4, accentColor: 0x80eee3, edgeColor: 0xf1f9bd };
    if (kind === 'ketchup')
        return { primaryColor: 0xff5646, accentColor: 0xff9273, edgeColor: 0xfff0b3 };
    return { primaryColor: 0x98e7f1, accentColor: 0xe5fbff, edgeColor: 0xc8d9ff };
}
const clamp = (value: number) => Math.max(0, Math.min(1, value));
export function getAreaWaveFrame(radius: number, ageMs: number, reducedEffects: boolean) {
    const progress = clamp(ageMs / AREA_WAVE_PERIOD_MS);
    const scale = .32 + .68 * (1 - (1 - progress) ** 1.4);
    const attack = clamp(progress / .12);
    const release = clamp((progress - .3) / .7);
    const alpha = .6 * attack * (1 - release) ** 1.4 * (reducedEffects ? .6 : 1);
    return { radius: Math.max(0, radius), scale, alpha, lineWidth: 3.2, rotation: progress * .32 };
}
export function getAreaGlowFrame(radius: number, ageMs: number, reducedEffects: boolean) {
    const wave = getAreaWaveFrame(radius, ageMs, reducedEffects);
    const progress = clamp(ageMs / AREA_WAVE_PERIOD_MS);
    const attack = clamp(progress / .15);
    const release = clamp((progress - .15) / .75);
    const alpha = reducedEffects ? 0 : .9 * attack * (1 - release) ** 1.8;
    return { displaySize: wave.radius * 2 * wave.scale * .98, scale: wave.scale, rotation: wave.rotation, alpha };
}
export function getAreaMoteFrame(radius: number, ageMs: number, index: number, reducedEffects: boolean) {
    const progress = clamp(ageMs / AREA_MOTE_PERIOD_MS);
    const size = Math.min(9, Math.max(4, radius * .043)) * (.7 + .3 * Math.sin(progress * Math.PI));
    const distance = radius * (.4 + .53 * progress);
    const angle = index * Math.PI * 2 / 6 + .13 * Math.sin(index * 2.1);
    return { distance, x: Math.cos(angle) * distance, y: Math.sin(angle) * distance, size,
        alpha: progress === 0 || progress === 1 ? 0 : Math.sin(progress * Math.PI) * .43 * (reducedEffects ? .6 : 1), rotation: angle, visible: !reducedEffects || index % 3 === 0 };
}
/** Diagnostic frame; real view centers every wave and mote on the current hero. */
export function getAreaVfxFrame(kind: CombatVfxKind, radius: number, elapsedMs: number, reducedEffects: boolean) {
    const time = Math.max(0, Number.isFinite(elapsedMs) ? elapsedMs : 0);
    return { diameter: radius * 2, waves: [0, 1].map(i => getAreaWaveFrame(radius, (time + i * 450) % 900, reducedEffects)),
        puffs: Array.from({ length: 6 }, (_, i) => getAreaMoteFrame(radius, (time + i * 120) % 720, i, reducedEffects)), ...getAreaVfxSpec(kind) };
}
