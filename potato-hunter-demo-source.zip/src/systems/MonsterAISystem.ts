import { ConfigManager } from "../managers/ConfigManager";
import { normalize } from "../utils/math";
import { getRoleVelocity } from "./MonsterRoleModel";
import type { GameRuntime, System } from "./SystemTypes";
import { getBossDuel } from "./BossDuelArena";
import { FINAL_DUEL_STANDOFF, getFinalDuelPressure } from "./FinalBossPatternModel";

export class MonsterAISystem implements System {
  update(deltaMs: number, runtime: GameRuntime): void {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    if (!playerTransform) {
      return;
    }

    const duel = getBossDuel(runtime.world);
    for (const [entityId, monster] of runtime.world.components.monsters) {
      const transform = runtime.world.components.transforms.get(entityId);
      const velocity = runtime.world.components.velocities.get(entityId);
      if (!transform || !velocity || (runtime.world.components.health.get(entityId)?.current ?? 0) <= 0) {
        continue;
      }
      if (duel && entityId !== duel.bossId) {
        const dx = transform.x - duel.x, dy = transform.y - duel.y;
        const distance = Math.hypot(dx, dy), limit = duel.radius + transform.radius + 28;
        const angle = distance > 0 ? Math.atan2(dy, dx) : entityId * 2.39996;
        const speed = Math.min(475, Math.max(0, limit - distance) * 1000 / Math.max(1, deltaMs));
        velocity.x = Math.cos(angle) * speed; velocity.y = Math.sin(angle) * speed;
        continue;
      }

      if (monster.controlledMotion || monster.stateTimerMs > 0) {
        continue;
      }

      const config = ConfigManager.getMonster(monster.monsterId);
      const direction = normalize(playerTransform.x - transform.x, playerTransform.y - transform.y);
      const bossMultiplier = monster.isBoss ? 0.82 : 1;
      const statuses = runtime.world.components.statuses.get(entityId) ?? [];
      const statusSpeedMultiplier = statuses.reduce((multiplier, status) => Math.min(multiplier, status.slowMultiplier), 1);
      const distance = Math.hypot(playerTransform.x - transform.x, playerTransform.y - transform.y);
      if (duel?.bossId === entityId) {
        const pressure = getFinalDuelPressure(monster.finalBossEncounter?.phase ?? 1);
        const speed = Math.min(pressure.chaseSpeed * statusSpeedMultiplier, Math.max(0, distance - FINAL_DUEL_STANDOFF) * 1000 / Math.max(1, deltaMs));
        velocity.x = direction.x * speed; velocity.y = direction.y * speed;
        continue;
      }
      // The camera is open-world: old flankers can be left thousands of units
      // behind. Once the boss falls, bring offscreen survivors back instead of
      // forcing players to search the empty map. No teleport or contact damage.
      if (runtime.campaign?.finalBossDefeated && distance > 1100) {
        const catchupSpeed = ConfigManager.player.moveSpeed * 2.2;
        velocity.x = direction.x * catchupSpeed;
        velocity.y = direction.y * catchupSpeed;
        continue;
      }
      const speed = config.speed * monster.speedMultiplier * bossMultiplier * statusSpeedMultiplier;
      const standoff = !monster.isBoss && monster.behavior === "hexer" ? [220, 340] : !monster.isBoss && monster.behavior === "scatter" ? [180, 300] : !monster.isBoss && monster.behavior === "sniper" ? [260, 400] : undefined;
      const advance = standoff ? distance > standoff[1] ? 1 : distance < standoff[0] ? -0.65 : 0 : undefined;
      const roleVelocity = advance === undefined ? getRoleVelocity(monster.isBoss ? "chaser" : monster.behavior, direction.x, direction.y, distance, speed) : { x: direction.x * speed * advance, y: direction.y * speed * advance };
      velocity.x = roleVelocity.x;
      velocity.y = roleVelocity.y;
    }
  }
}
