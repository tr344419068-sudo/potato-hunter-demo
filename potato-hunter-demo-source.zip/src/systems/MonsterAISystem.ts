import { ConfigManager } from "../managers/ConfigManager";
import { normalize } from "../utils/math";
import { getRoleVelocity } from "./MonsterRoleModel";
import type { GameRuntime, System } from "./SystemTypes";

export class MonsterAISystem implements System {
  update(_deltaMs: number, runtime: GameRuntime): void {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    if (!playerTransform) {
      return;
    }

    for (const [entityId, monster] of runtime.world.components.monsters) {
      const transform = runtime.world.components.transforms.get(entityId);
      const velocity = runtime.world.components.velocities.get(entityId);
      if (!transform || !velocity || (runtime.world.components.health.get(entityId)?.current ?? 0) <= 0) {
        continue;
      }

      if (monster.controlledMotion || monster.stateTimerMs > 0) {
        continue;
      }

      const config = ConfigManager.getMonster(monster.monsterId);
      const direction = normalize(playerTransform.x - transform.x, playerTransform.y - transform.y);
      const bossMultiplier = monster.isBoss ? 0.82 : 1;
      const statuses = runtime.world.components.statuses.get(entityId) ?? [];
      const statusSpeedMultiplier = statuses.reduce((multiplier, status) => Math.min(multiplier, status.slowMultiplier), 1);
      const distance = Math.hypot(playerTransform.x - transform.x, playerTransform.y - transform.y);
      const speed = config.speed * monster.speedMultiplier * bossMultiplier * statusSpeedMultiplier;
      const standoff = !monster.isBoss && monster.behavior === "hexer" ? [220, 340] : !monster.isBoss && monster.behavior === "scatter" ? [180, 300] : !monster.isBoss && monster.behavior === "sniper" ? [260, 400] : undefined;
      const advance = standoff ? distance > standoff[1] ? 1 : distance < standoff[0] ? -0.65 : 0 : undefined;
      const roleVelocity = advance === undefined ? getRoleVelocity(monster.isBoss ? "chaser" : monster.behavior, direction.x, direction.y, distance, speed) : { x: direction.x * speed * advance, y: direction.y * speed * advance };
      velocity.x = roleVelocity.x;
      velocity.y = roleVelocity.y;
    }
  }
}
