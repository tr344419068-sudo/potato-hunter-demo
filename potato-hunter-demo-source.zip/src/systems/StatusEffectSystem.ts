import { EventBus } from "../managers/EventBus";
import { applyHealthDamage } from "./HealthDamage";
import { getBossDuel } from "./BossDuelArena";
import type { GameRuntime, System } from "./SystemTypes";

export class StatusEffectSystem implements System {
  readonly telemetrySource = "StatusEffectSystem";
  private damageTextTimerMs = 0;

  update(deltaMs: number, runtime: GameRuntime): void {
    this.damageTextTimerMs -= deltaMs;
    const duel = getBossDuel(runtime.world);

    for (const [entityId, statuses] of runtime.world.components.statuses) {
      const health = runtime.world.components.health.get(entityId);
      const transform = runtime.world.components.transforms.get(entityId);
      if (!health || !transform) {
        runtime.world.components.statuses.delete(entityId);
        continue;
      }

      let totalDamage = 0;
      for (const status of statuses) {
        status.remainingMs -= deltaMs;
        if (status.damagePerSecond > 0 && (!duel || entityId === duel.bossId || !runtime.world.components.monsters.has(entityId))) {
          const damage = status.damagePerSecond * (deltaMs / 1000);
          totalDamage += applyHealthDamage(health, damage);
        }
      }

      if (totalDamage > 0) {
        runtime.world.components.hitFlashes.set(entityId, { remainingMs: 38, totalMs: 38 });
        if (this.damageTextTimerMs <= 0) {
          EventBus.emit("combat:damage", {
            x: transform.x,
            y: transform.y,
            value: Math.ceil(totalDamage),
            targetId: entityId,
            isDot: true,
            category: "outgoing",
            color: statuses.some((status) => status.type === "burn") ? "#ff6b35" : "#80b918",
          });
        }
      }

      const activeStatuses = statuses.filter((status) => status.remainingMs > 0);
      if (activeStatuses.length > 0) {
        runtime.world.components.statuses.set(entityId, activeStatuses);
      } else {
        runtime.world.components.statuses.delete(entityId);
      }
    }

    if (this.damageTextTimerMs <= 0) {
      this.damageTextTimerMs = 240;
    }
  }
}
