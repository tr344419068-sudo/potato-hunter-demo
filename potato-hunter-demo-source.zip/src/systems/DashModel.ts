export const DASH_DURATION_MS = 170;
export const DASH_COOLDOWN_MS = 2200;
export const DASH_SPEED = 720;

export interface DashState {
  remainingMs: number;
  cooldownMs: number;
  directionX: number;
  directionY: number;
}

function normalizeDirection(x: number, y: number, fallbackX: number, fallbackY: number): { x: number; y: number } {
  const magnitude = Math.hypot(x, y);
  if (magnitude > 0.0001) {
    return { x: x / magnitude, y: y / magnitude };
  }
  const fallbackMagnitude = Math.hypot(fallbackX, fallbackY);
  if (fallbackMagnitude > 0.0001) {
    return { x: fallbackX / fallbackMagnitude, y: fallbackY / fallbackMagnitude };
  }
  return { x: 1, y: 0 };
}

export function createDashState(inputX: number, inputY: number, lastX: number, lastY: number): DashState {
  const direction = normalizeDirection(inputX, inputY, lastX, lastY);
  return {
    remainingMs: DASH_DURATION_MS,
    cooldownMs: DASH_COOLDOWN_MS,
    directionX: direction.x,
    directionY: direction.y,
  };
}

export function tickDashState(state: Readonly<DashState>, deltaMs: number): DashState {
  const elapsed = Math.max(0, deltaMs);
  return {
    ...state,
    remainingMs: Math.max(0, state.remainingMs - elapsed),
    cooldownMs: Math.max(0, state.cooldownMs - elapsed),
  };
}

export function getDashCooldownRatio(cooldownMs: number): number {
  return Math.min(1, Math.max(0, cooldownMs / DASH_COOLDOWN_MS));
}
