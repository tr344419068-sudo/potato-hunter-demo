import type Phaser from "phaser";
import { advanceWalkPhase, deformCharacterPoint, getCharacterWalkPose, getCharacterWalkRig, type CharacterWalkPose } from "./CharacterWalkModel";

interface CharacterMeshInput {
  entityId: number;
  assetId: string;
  textureKey: string;
  x: number;
  y: number;
  worldX: number;
  worldY: number;
  visualSize: number;
  pivot: { x: number; y: number };
  scaleX: number;
  scaleY: number;
  rotation: number;
  tint?: number;
  alpha: number;
  deltaMs: number;
  attack?: number;
}

interface MeshActor {
  mesh: Phaser.GameObjects.Mesh;
  assetId: string;
  phase: number;
  lastX: number;
  lastY: number;
  bindings: Array<{ u: number; v: number; vertices: Phaser.Geom.Mesh.Vertex[] }>;
  lastPose?: CharacterWalkPose;
  pivotX: number;
  pivotY: number;
}

// Phaser's factory returns Mesh while its declaration keeps the lifecycle hook
// protected. This view exclusively owns that hook's scheduling (the regression
// executes the installed implementation), so expose only this narrow adapter.
interface OwnedMeshProjection {
  preUpdate(time: number, delta: number): void;
}

export class CharacterMeshView {
  private readonly actors = new Map<number, MeshActor>();

  constructor(private readonly scene: Phaser.Scene) {
    scene.events?.once("shutdown", () => this.destroy());
  }

  draw(input: CharacterMeshInput): boolean {
    const rig = getCharacterWalkRig(input.assetId);
    // Mesh is WebGL-only: keep the existing Image renderer as the Canvas fallback.
    const renderer = this.scene.sys?.renderer;
    if (!rig || !renderer || !("gl" in renderer) || !renderer.gl || typeof this.scene.add.mesh !== "function") return false;
    let actor = this.actors.get(input.entityId);
    if (actor && actor.assetId !== input.assetId) {
      actor.mesh.destroy(); this.actors.delete(input.entityId); actor = undefined;
    }
    if (!actor) {
      const gridX = input.assetId === "char_potato_hunter" ? 20 : 12;
      const gridY = input.assetId === "char_potato_hunter" ? 20 : 14;
      const vertices: number[] = [], uvs: number[] = [];
      const add = (col: number, row: number): void => {
        const u = col / gridX, v = row / gridY;
        vertices.push(u - input.pivot.x, input.pivot.y - v);
        uvs.push(u, v);
      };
      for (let row = 0; row < gridY; row++) for (let col = 0; col < gridX; col++) {
        add(col, row); add(col, row + 1); add(col + 1, row);
        add(col, row + 1); add(col + 1, row + 1); add(col + 1, row);
      }
      const mesh = this.scene.add.mesh(input.x, input.y, input.textureKey, undefined, vertices, uvs);
      mesh.setSize(input.visualSize, input.visualSize).setDepth(2);
      mesh.setOrtho(1, 1);
      mesh.hideCCW = false;
      mesh.ignoreDirtyCache = true;
      // We own projection after Scene.update's geometry edits. Automatic preUpdate
      // runs before them and would otherwise display the previous pose for a frame.
      this.scene.sys.updateList?.remove(mesh);
      const unique = new Map<string, { u: number; v: number; vertices: Phaser.Geom.Mesh.Vertex[] }>();
      for (const vertex of mesh.vertices) {
        const key = `${vertex.u}:${vertex.v}`;
        let binding = unique.get(key);
        if (!binding) { binding = { u: vertex.u, v: vertex.v, vertices: [] }; unique.set(key, binding); }
        binding.vertices.push(vertex);
      }
      actor = { mesh, assetId: input.assetId, phase: input.entityId * 2.39996, lastX: input.worldX, lastY: input.worldY, bindings: [...unique.values()], pivotX: input.pivot.x, pivotY: input.pivot.y };
      this.actors.set(input.entityId, actor);
    }
    const dx = input.worldX - actor.lastX, dy = input.worldY - actor.lastY;
    const distance = Math.hypot(dx, dy);
    // Displacement, not stale velocity or wall-clock time, makes a paused chooser truly idle.
    const traveled = Math.min(distance, 14);
    actor.phase = advanceWalkPhase(actor.phase, traveled, input.visualSize);
    const speed = input.deltaMs > 0 ? traveled * 1000 / input.deltaMs : 0;
    const pose = getCharacterWalkPose(actor.phase, speed, distance > 0 ? dx / distance : 0, distance > 0 ? dy / distance : 0, input.attack ?? 0);
    const previous = actor.lastPose;
    const geometryChanged = !previous || pose.stride !== previous.stride || pose.strength !== previous.strength || pose.directionX !== previous.directionX || pose.directionY !== previous.directionY || pose.bodyY !== previous.bodyY || pose.attack !== previous.attack || actor.pivotX !== input.pivot.x || actor.pivotY !== input.pivot.y;
    for (const binding of actor.bindings) {
      // Phaser stores duplicated triangle corners even with indexed input. Skin
      // each unique UV once, then copy to those corners; idle poses reuse geometry.
      const point = geometryChanged ? deformCharacterPoint(binding.u, binding.v, rig, pose) : undefined;
      for (const vertex of binding.vertices) {
        if (point) { vertex.x = point.x - input.pivot.x; vertex.y = input.pivot.y - point.y; }
        vertex.color = input.tint ?? 0xffffff;
      }
    }
    actor.mesh.setSize(input.visualSize, input.visualSize).setPosition(input.x, input.y).setScale(input.scaleX, input.scaleY).setRotation(input.rotation).setAlpha(input.alpha).setVisible(true);
    (actor.mesh as unknown as OwnedMeshProjection).preUpdate(0, input.deltaMs);
    actor.lastPose = pose; actor.pivotX = input.pivot.x; actor.pivotY = input.pivot.y;
    actor.lastX = input.worldX; actor.lastY = input.worldY;
    return true;
  }

  prune(active: ReadonlySet<number>): void {
    for (const [entityId, actor] of this.actors) if (!active.has(entityId)) {
      actor.mesh.destroy(); this.actors.delete(entityId);
    }
  }

  destroy(): void { this.prune(new Set()); }
}
