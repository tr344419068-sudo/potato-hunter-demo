import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import { EntityPools } from "../managers/EntityPools";
import { EventBus } from "../managers/EventBus";
import { getCombatImpactProfile, getCombatVfxEnvelope, getCombatVfxPalette, getCombatVfxRecipe, type CombatVfxKind } from "./CombatVfxModel";
import { CombatParticleEmitter } from "./CombatParticleEmitter";
import { AreaVfxView } from "./AreaVfxView";
import { UI_BODY_FONT } from "../ui/UITheme";
import { getProjectileMotion } from "./CombatJuiceModel";
import type { ElementalReactionKind } from "./ElementalReactionModel";
import type { GameRuntime, System } from "./SystemTypes";

interface WeaponFiredPayload {
  x: number;
  y: number;
  directionX: number;
  directionY: number;
  color: number;
  size: number;
  projectileCount: number;
  vfxKind: CombatVfxKind;
}

interface WeaponImpactPayload {
  x: number;
  y: number;
  color: number;
  radius: number;
  vfxKind: CombatVfxKind;
  directionX?: number;
  directionY?: number;
  critical?: boolean;
}

interface AuraPulsePayload {
  x: number;
  y: number;
  color: number;
  radius: number;
  vfxKind: CombatVfxKind;
}

interface ElementalReactionPayload {
  kind: ElementalReactionKind;
  label: string;
  x: number;
  y: number;
  radius: number;
  primaryColor: number;
  secondaryColor: number;
  affectedTargets: number;
}

interface HeroDashPayload {
  x: number;
  y: number;
  directionX: number;
  directionY: number;
  assetId?: string;
  size: number;
}

const MAX_ACCENTS = 36;
const ORDINARY_ACCENT_LIMIT = 28;
const MAX_REACTION_LABELS = 4;

export class CombatVfxSystem implements System {
  private trailTimerMs = 0;
  private activeParticles = 0;
  private activeAccents = 0;
  private trailCursor = 0;
  private readonly particles: CombatParticleEmitter;
  private readonly areas: AreaVfxView;
  private readonly ownedGraphics = new Set<Phaser.GameObjects.Graphics>();
  private readonly transients = new Set<Phaser.GameObjects.GameObject>();
  private readonly reactionLabels = new Set<Phaser.GameObjects.GameObject>();
  private destroyed = false;
  private reducedEffects = false;

  constructor(private readonly scene: Phaser.Scene) {
    this.particles = new CombatParticleEmitter(scene);
    this.areas = new AreaVfxView(scene);
    EventBus.on("weapon:fired", this.showMuzzle, this);
    EventBus.on("weapon:impact", this.showImpact, this);
    EventBus.on("aura:pulse", this.showAuraPulse, this);
    EventBus.on("combat:reaction", this.showElementalReaction, this);
    EventBus.on("hero:dash", this.showHeroDash, this);
    EventBus.on("presentation:preferences", this.applyPreferences, this);
    EventBus.on("game:over", this.destroy, this);
    scene.events.once(Phaser.Scenes.Events.SHUTDOWN, this.destroy, this);
  }

  update(deltaMs: number, runtime: GameRuntime): void {
    if (this.destroyed) return;
    this.particles.update(deltaMs);
    this.areas.update(deltaMs, runtime);
    if (this.reducedEffects) return;
    this.trailTimerMs -= deltaMs;
    if (this.trailTimerMs > 0) {
      return;
    }
    let nextTrailIntervalMs = 46;

    const projectiles = [...runtime.world.components.projectiles];
    const start = this.trailCursor % Math.max(1, projectiles.length);
    const maximumBursts = (this.scene.scale?.width ?? 1280) < 700 ? 12 : 24;
    let bursts = 0;
    for (let offset = 0; offset < projectiles.length && bursts < maximumBursts; offset++) {
      const projectileIndex = (start + offset) % projectiles.length;
      const [entityId, projectile] = projectiles[projectileIndex];
      const transform = runtime.world.components.transforms.get(entityId);
      const velocity = runtime.world.components.velocities.get(entityId);
      if (!transform || !velocity || !this.onScreen(transform.x, transform.y)) {
        this.trailCursor = (projectileIndex + 1) % projectiles.length;
        continue;
      }
      const kind = projectile.vfxKind ?? "kinetic";
      const speed = Math.max(1, Math.hypot(velocity.x, velocity.y));
      const motion = getProjectileMotion(kind, runtime.stats.elapsedMs, entityId, speed);
      nextTrailIntervalMs = Math.min(nextTrailIntervalMs, motion.trailIntervalMs);
      const backX = transform.x - (velocity.x / speed) * 8;
      const backY = transform.y - (velocity.y / speed) * 8;
      const emitted = this.particles.emit({ x: backX, y: backY, kind, phase: "trail", directionX: velocity.x, directionY: velocity.y });
      if (emitted === 0) break;
      this.spawnTrailStreak(backX, backY, velocity.x / speed, velocity.y / speed, kind);
      this.trailCursor = (projectileIndex + 1) % projectiles.length;
      bursts++;
    }
    this.trailTimerMs = nextTrailIntervalMs;
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.scene.events.off(Phaser.Scenes.Events.SHUTDOWN, this.destroy, this);
    this.particles.destroy();
    this.areas.destroy();
    for (const graphics of this.ownedGraphics) {
      this.scene.tweens.killTweensOf(graphics);
      this.releaseGraphics(graphics);
    }
    for (const transient of this.transients) {
      this.scene.tweens.killTweensOf(transient);
      this.destroyTransient(transient);
    }
    this.activeParticles = 0;
    this.activeAccents = 0;
    EventBus.off("weapon:fired", this.showMuzzle, this);
    EventBus.off("weapon:impact", this.showImpact, this);
    EventBus.off("aura:pulse", this.showAuraPulse, this);
    EventBus.off("combat:reaction", this.showElementalReaction, this);
    EventBus.off("hero:dash", this.showHeroDash, this);
    EventBus.off("presentation:preferences", this.applyPreferences, this);
    EventBus.off("game:over", this.destroy, this);
  }

  private applyPreferences(preferences: { reducedEffects?: boolean }): void {
    if (typeof preferences?.reducedEffects !== "boolean") return;
    this.reducedEffects = preferences.reducedEffects;
    this.particles.setReducedEffects(this.reducedEffects);
    this.areas.setReducedEffects(this.reducedEffects);
  }

  private showHeroDash(payload: HeroDashPayload): void {
    if (this.destroyed) return;
    const visualSize = AssetManager.getDisplaySize(payload.assetId, payload.size);
    const burst = this.acquireGraphics();
    const directionAngle = Math.atan2(payload.directionY, payload.directionX);
    burst.setPosition(payload.x, payload.y).setDepth(8).setRotation(directionAngle);
    burst.lineStyle(5, 0x69e8ff, 0.9);
    burst.strokeEllipse(0, 0, Math.max(44, visualSize * 0.9), Math.max(22, visualSize * 0.44));
    burst.lineStyle(3, 0xffffff, 0.82);
    for (const offsetY of [-18, -8, 7, 17]) {
      const length = Phaser.Math.Between(44, 82);
      burst.beginPath();
      burst.moveTo(-length * 0.2, offsetY);
      burst.lineTo(-length, offsetY * 1.35);
      burst.strokePath();
    }
    this.fadeGraphics(burst, 260, 1.55, 0.74);

    for (let index = 1; index <= 3; index += 1) {
      const distance = index * Math.max(16, visualSize * 0.4);
      const afterimageX = payload.x - payload.directionX * distance;
      const afterimageY = payload.y - payload.directionY * distance;
      const alpha = 0.48 - index * 0.09;
      if (AssetManager.hasTexture(this.scene, payload.assetId)) {
        const image = this.scene.add.image(afterimageX, afterimageY, AssetManager.getTextureKey(payload.assetId!));
        this.transients.add(image);
        const pivot = AssetManager.getPivot(payload.assetId);
        image.setOrigin(pivot.x, pivot.y);
        image.setDepth(6).setDisplaySize(visualSize * (payload.directionX < 0 ? -1 : 1), visualSize).setTint(0x69e8ff).setAlpha(alpha);
        this.scene.tweens.add({
          targets: image,
          x: afterimageX - payload.directionX * 22,
          y: afterimageY - payload.directionY * 22,
          alpha: 0,
          scaleX: image.scaleX * 0.82,
          scaleY: image.scaleY * 1.08,
          duration: 170 + index * 35,
          ease: "Quad.easeOut",
          onComplete: () => this.destroyTransient(image),
        });
      } else {
        const silhouette = this.scene.add.circle(afterimageX, afterimageY, payload.size * 0.42, 0x69e8ff, alpha).setDepth(6);
        this.transients.add(silhouette);
        this.scene.tweens.add({
          targets: silhouette,
          alpha: 0,
          scaleX: 0.72,
          scaleY: 1.14,
          duration: 170 + index * 35,
          ease: "Quad.easeOut",
          onComplete: () => this.destroyTransient(silhouette),
        });
      }
    }
  }

  private showElementalReaction(payload: ElementalReactionPayload): void {
    if (this.destroyed || !this.onScreen(payload.x, payload.y)) return;
    const particleKind: CombatVfxKind = payload.kind === "shatter" ? "frost" : payload.kind === "superconduct" ? "lightning" : "explosion";
    this.particles.emit({ x: payload.x, y: payload.y, kind: particleKind, phase: "reaction", radius: payload.radius, count: Math.min(18, 12 + payload.affectedTargets * 2) });
    if (this.activeAccents >= MAX_ACCENTS) return;
    const ring = this.acquireGraphics();
    const radius = Math.max(42, Math.min(92, payload.radius * 0.62));
    ring.setPosition(payload.x, payload.y);
    ring.setDepth(10);
    ring.fillStyle(payload.primaryColor, 0.18);
    ring.fillCircle(0, 0, radius * 0.7);
    ring.lineStyle(7, payload.primaryColor, 0.94);
    ring.strokeCircle(0, 0, radius * 0.96);
    ring.lineStyle(3, payload.secondaryColor, 0.98);
    ring.strokeCircle(0, 0, radius * 0.58);

    const rayCount = payload.kind === "shatter" ? 8 : 6;
    for (let index = 0; index < rayCount; index += 1) {
      const angle = (index / rayCount) * Math.PI * 2 + (payload.kind === "superconduct" ? index * 0.13 : 0);
      const inner = radius * (index % 2 === 0 ? 0.14 : 0.25);
      const outer = radius * (index % 2 === 0 ? 0.92 : 0.72);
      ring.lineStyle(index % 2 === 0 ? 5 : 3, index % 2 === 0 ? payload.secondaryColor : payload.primaryColor, 0.9);
      ring.beginPath();
      ring.moveTo(Math.cos(angle) * inner, Math.sin(angle) * inner);
      ring.lineTo(Math.cos(angle) * outer, Math.sin(angle) * outer);
      ring.strokePath();
    }
    this.fadeGraphics(ring, 360, 1.72, 0.48);

    if (this.reactionLabels.size >= MAX_REACTION_LABELS) return;
    const label = this.scene.add.text(payload.x, payload.y - radius * 0.55, payload.label, {
      color: `#${payload.primaryColor.toString(16).padStart(6, "0")}`,
      fontFamily: UI_BODY_FONT,
      fontSize: "16px",
      fontStyle: "bold",
      stroke: "#10233f",
      strokeThickness: 3,
    }).setOrigin(0.5).setDepth(12).setScale(0.7);
    this.transients.add(label);
    this.reactionLabels.add(label);
    this.scene.tweens.add({
      targets: label,
      y: label.y - 34,
      scale: 1.08,
      alpha: 0,
      duration: 620,
      ease: "Back.easeOut",
      onComplete: () => this.destroyTransient(label),
    });
  }

  private showMuzzle(payload: WeaponFiredPayload): void {
    if (this.destroyed || !this.onScreen(payload.x, payload.y)) return;
    this.particles.emit({ x: payload.x, y: payload.y, kind: payload.vfxKind, phase: "muzzle", directionX: payload.directionX, directionY: payload.directionY });
    if (this.activeAccents >= ORDINARY_ACCENT_LIMIT) return;
    const [core, primary, accent] = getCombatVfxPalette(payload.vfxKind);
    const recipe = getCombatVfxRecipe(payload.vfxKind);
    const envelope = getCombatVfxEnvelope(payload.vfxKind);
    const flash = this.acquireGraphics();
    const spread = Math.min(44, Math.max(13, payload.size * 1.1 + payload.projectileCount * 2) * recipe.coreScale * envelope.muzzleScale);
    const angle = Math.atan2(payload.directionY, payload.directionX);
    flash.setPosition(payload.x, payload.y);
    flash.setDepth(7);
    flash.fillStyle(core, 0.92);
    flash.fillTriangle(
      Math.cos(angle) * spread,
      Math.sin(angle) * spread,
      Math.cos(angle + 2.35) * spread * 0.7,
      Math.sin(angle + 2.35) * spread * 0.7,
      Math.cos(angle - 2.35) * spread * 0.7,
      Math.sin(angle - 2.35) * spread * 0.7,
    );
    flash.lineStyle(3, primary, 0.8);
    flash.strokeCircle(0, 0, spread * 0.58);
    this.drawMuzzleArc(flash, angle, spread, primary, accent);
    this.drawElementalSilhouette(flash, payload.vfxKind, spread * 0.84, angle);
    this.fadeGraphics(flash, 165, 1.55, 0.6);

  }

  private showImpact(payload: WeaponImpactPayload): void {
    if (this.destroyed || !this.onScreen(payload.x, payload.y)) return;
    const recipe = getCombatVfxRecipe(payload.vfxKind);
    this.particles.emit({ x: payload.x, y: payload.y, kind: payload.vfxKind, phase: "impact", directionX: payload.directionX, directionY: payload.directionY,
      radius: payload.radius, critical: payload.critical, count: recipe.debrisCount + (payload.critical ? 3 : 0) });
    if (this.activeAccents >= (payload.critical ? MAX_ACCENTS : ORDINARY_ACCENT_LIMIT)) return;
    const [core, primary, accent] = getCombatVfxPalette(payload.vfxKind);
    const ring = this.acquireGraphics();
    const profile = getCombatImpactProfile(payload.vfxKind, payload.critical ?? false);
    const envelope = getCombatVfxEnvelope(payload.vfxKind, payload.critical ?? false);
    const radius = Math.min(payload.vfxKind === "explosion" ? 112 : 58, Math.max(16, payload.radius) * envelope.impactScale);
    const angle = Math.atan2(payload.directionY ?? 0, payload.directionX ?? 1);
    ring.setPosition(payload.x, payload.y);
    ring.setDepth(8);
    ring.fillStyle(primary, payload.vfxKind === "poison" ? 0.18 : 0.28);
    ring.fillCircle(0, 0, radius * 0.72);
    this.drawElementalSilhouette(ring, payload.vfxKind, radius, angle);
    ring.fillStyle(core, 0.96);
    ring.fillCircle(0, 0, Math.max(4, radius * 0.2 * recipe.coreScale));
    ring.lineStyle(payload.vfxKind === "explosion" ? 5 : 2, core, 0.66);
    ring.strokeCircle(0, 0, radius);
    ring.lineStyle(2, accent, 0.62);
    ring.strokeCircle(0, 0, radius * 0.55);
    this.drawImpactSlashes(ring, angle, radius, accent, recipe.impactRays);
    this.fadeGraphics(ring, envelope.durationMs, Math.min(1.72, profile.ringScale), 0.5);
    if (this.reducedEffects && !payload.critical) return;
    this.showSecondaryImpact(payload, radius, angle);

    this.spawnResidueMark(payload.x, payload.y, payload.vfxKind, radius, recipe.residueDurationMs);
  }

  private showAuraPulse(payload: AuraPulsePayload): void {
    if (this.destroyed || this.areas.hasKind(payload.vfxKind) || !this.onScreen(payload.x, payload.y)) return;
    this.particles.emit({ x: payload.x, y: payload.y, kind: payload.vfxKind, phase: "aura", radius: payload.radius, count: 2 });
  }

  private showSecondaryImpact(payload: WeaponImpactPayload, radius: number, angle: number): void {
    if (this.activeParticles >= 160) return;
    const envelope = getCombatVfxEnvelope(payload.vfxKind, payload.critical ?? false);
    const echo = this.acquireGraphics();
    this.activeParticles += 1;
    echo.setPosition(payload.x, payload.y).setDepth(7).setVisible(false).setAlpha(0.72).setScale(0.66);
    this.drawElementalSilhouette(echo, payload.vfxKind, radius * 0.82, angle + 0.22);
    this.scene.tweens.add({
      targets: echo,
      alpha: 0,
      scale: 1.5,
      delay: envelope.secondaryDelayMs,
      duration: Math.round(envelope.durationMs * 0.7),
      ease: "Cubic.easeOut",
      onStart: () => { if (this.ownedGraphics.has(echo)) echo.setVisible(true); },
      onComplete: () => this.releaseParticle(echo),
    });
  }

  private drawElementalSilhouette(graphics: Phaser.GameObjects.Graphics, kind: CombatVfxKind, radius: number, angle: number): void {
    const [core, primary, accent] = getCombatVfxPalette(kind);
    if (kind === "peeler" || kind === "kinetic") {
      // A thick crescent reads as a blade sweep, rather than a generic circular flash.
      graphics.fillStyle(primary, 0.88);
      graphics.beginPath();
      for (let step = 0; step <= 12; step += 1) {
        const arc = angle - 1.48 + step / 12 * 2.96;
        const x = Math.cos(arc) * radius;
        const y = Math.sin(arc) * radius;
        if (step === 0) graphics.moveTo(x, y); else graphics.lineTo(x, y);
      }
      for (let step = 12; step >= 0; step -= 1) {
        const arc = angle - 1.48 + step / 12 * 2.96;
        graphics.lineTo(Math.cos(arc) * radius * 0.58, Math.sin(arc) * radius * 0.58);
      }
      graphics.closePath();
      graphics.fillPath();
      graphics.lineStyle(2, core, 0.96);
      graphics.lineBetween(Math.cos(angle - 1) * radius * 0.76, Math.sin(angle - 1) * radius * 0.76, Math.cos(angle + 0.4) * radius, Math.sin(angle + 0.4) * radius);
      return;
    }
    if (kind === "lightning") {
      for (let ray = 0; ray < 5; ray += 1) {
        const heading = angle + ray * Math.PI * 2 / 5;
        for (const glow of [true, false]) {
          graphics.lineStyle(glow ? 8 : 2.8, glow ? primary : core, glow ? 0.32 : 0.94);
          graphics.beginPath();
          graphics.moveTo(0, 0);
          for (let step = 1; step <= 4; step += 1) {
            const kink = heading + (step % 2 ? 0.26 : -0.18);
            graphics.lineTo(Math.cos(kink) * radius * step / 4, Math.sin(kink) * radius * step / 4);
          }
          graphics.strokePath();
        }
      }
      return;
    }
    if (kind === "frost") {
      for (let shard = 0; shard < 6; shard += 1) {
        const heading = angle + shard * Math.PI / 3;
        const startX = Math.cos(heading) * radius * 0.18;
        const startY = Math.sin(heading) * radius * 0.18;
        graphics.fillStyle(shard % 2 ? primary : core, 0.88);
        graphics.fillTriangle(
          Math.cos(heading) * radius, Math.sin(heading) * radius,
          startX + Math.cos(heading + Math.PI / 2) * radius * 0.13, startY + Math.sin(heading + Math.PI / 2) * radius * 0.13,
          startX - Math.cos(heading + Math.PI / 2) * radius * 0.13, startY - Math.sin(heading + Math.PI / 2) * radius * 0.13,
        );
        graphics.lineStyle(1.6, accent, 0.84);
        graphics.lineBetween(startX, startY, Math.cos(heading) * radius * 0.92, Math.sin(heading) * radius * 0.92);
      }
      return;
    }
    if (kind === "fire" || kind === "explosion") {
      const lobes = kind === "explosion" ? 8 : 5;
      for (let lobe = 0; lobe < lobes; lobe += 1) {
        const heading = angle + lobe * Math.PI * 2 / lobes;
        const reach = radius * (lobe % 2 ? 0.5 : 0.64);
        graphics.fillStyle(accent, 0.58);
        graphics.fillCircle(Math.cos(heading) * reach, Math.sin(heading) * reach, radius * 0.3);
        graphics.fillStyle(primary, 0.9);
        graphics.fillCircle(Math.cos(heading) * reach * 0.84, Math.sin(heading) * reach * 0.84, radius * 0.23);
        graphics.fillStyle(core, 0.86);
        graphics.fillTriangle(0, 0, Math.cos(heading - 0.17) * radius * 0.56, Math.sin(heading - 0.17) * radius * 0.56, Math.cos(heading + 0.1) * radius * 0.88, Math.sin(heading + 0.1) * radius * 0.88);
      }
      return;
    }
    if (kind === "poison") {
      for (let bubble = 0; bubble < 5; bubble += 1) {
        const heading = angle + bubble * Math.PI * 2 / 5;
        const x = Math.cos(heading) * radius * 0.63;
        const y = Math.sin(heading) * radius * 0.5;
        const size = radius * (bubble % 2 ? 0.24 : 0.31);
        graphics.fillStyle(accent, 0.7);
        graphics.fillCircle(x, y, size);
        graphics.fillStyle(primary, 0.8);
        graphics.fillCircle(x - 1, y - 2, size * 0.78);
        graphics.fillStyle(core, 0.86);
        graphics.fillEllipse(x - size * 0.25, y - size * 0.3, size * 0.36, size * 0.2);
      }
      return;
    }
    // Sauce splashes remain food-cartoon red, with asymmetric lobes and cream highlights.
    for (let drop = 0; drop < 6; drop += 1) {
      const heading = angle + drop * Math.PI / 3;
      const reach = radius * (drop % 2 ? 0.68 : 0.48);
      graphics.fillStyle(accent, 0.7);
      graphics.fillEllipse(Math.cos(heading) * reach, Math.sin(heading) * reach, radius * 0.5, radius * 0.3);
      graphics.fillStyle(primary, 0.9);
      graphics.fillCircle(Math.cos(heading) * reach, Math.sin(heading) * reach - 2, radius * 0.17);
      graphics.fillStyle(core, 0.72);
      graphics.fillCircle(Math.cos(heading) * reach - 2, Math.sin(heading) * reach - 4, radius * 0.045);
    }
  }

  private spawnTrailStreak(x: number, y: number, directionX: number, directionY: number, kind: CombatVfxKind): void {
    if (this.activeParticles >= ((this.scene.scale?.width ?? 1280) < 700 ? 24 : 48)) {
      return;
    }
    const recipe = getCombatVfxRecipe(kind);
    const envelope = getCombatVfxEnvelope(kind);
    const length = recipe.trailLength * envelope.trailScale;
    const [core, primary, accent] = getCombatVfxPalette(kind);
    const streak = this.acquireGraphics();
    const angle = Math.atan2(directionY, directionX);
    this.activeParticles += 1;
    streak.setPosition(x, y).setRotation(angle).setDepth(2.7);
    streak.lineStyle(recipe.trailWidth * 1.4 + 5, accent, 0.2);
    streak.lineBetween(-length, 0, 2, 0);
    streak.lineStyle(recipe.trailWidth * 1.3, primary, 0.8);
    streak.lineBetween(-length * 0.84, 0, 4, 0);
    streak.lineStyle(Math.max(1, recipe.trailWidth * 0.34), core, 0.94);
    streak.lineBetween(-length * 0.58, 0, 6, 0);
    if (kind === "lightning") {
      streak.lineStyle(2, core, 0.86);
      streak.beginPath();
      streak.moveTo(-length * 0.86, -6);
      streak.lineTo(-length * 0.5, 7);
      streak.lineTo(-length * 0.26, -5);
      streak.lineTo(4, 0);
      streak.strokePath();
    } else if (kind === "peeler") {
      streak.lineStyle(2, core, 0.72);
      for (const side of [-1, 1]) {
        streak.lineBetween(-length * 0.65, side * 8, 4, side * 2);
      }
    } else if (kind === "fire") {
      streak.fillStyle(primary, 0.54);
      streak.fillTriangle(-length, 0, -length * 0.5, -9, -length * 0.24, 5);
    }
    this.scene.tweens.add({
      targets: streak,
      alpha: 0,
      scaleX: 0.42,
      scaleY: 1.3,
      duration: kind === "poison" ? 210 : 160,
      ease: "Quad.easeOut",
      onComplete: () => this.releaseParticle(streak),
    });
  }

  private spawnResidueMark(x: number, y: number, kind: CombatVfxKind, radius: number, durationMs: number): void {
    if (this.activeParticles >= 158) {
      return;
    }
    const [core, primary, accent] = getCombatVfxPalette(kind);
    const residue = this.acquireGraphics();
    const size = Math.max(8, Math.min(34, radius * 0.72));
    this.activeParticles += 1;
    residue.setPosition(x, y + radius * 0.18).setDepth(0.8).setAlpha(0.58);

    if (kind === "fire" || kind === "explosion") {
      residue.fillStyle(accent, 0.34);
      residue.fillEllipse(0, 0, size * 1.7, size * 0.58);
      residue.fillStyle(primary, 0.68);
      for (const offset of [-0.52, 0, 0.48]) {
        residue.fillTriangle(offset * size, 2, offset * size - 4, -size * 0.7, offset * size + 5, -size * 0.16);
      }
    } else if (kind === "frost") {
      residue.lineStyle(3, primary, 0.72);
      for (let index = 0; index < 6; index += 1) {
        const angle = index * Math.PI / 3;
        residue.lineBetween(0, 0, Math.cos(angle) * size, Math.sin(angle) * size * 0.55);
      }
      residue.fillStyle(core, 0.72);
      residue.fillCircle(0, 0, 4);
    } else if (kind === "lightning") {
      residue.lineStyle(4, primary, 0.72);
      residue.beginPath();
      residue.moveTo(-size, size * 0.2);
      residue.lineTo(-size * 0.25, -size * 0.28);
      residue.lineTo(size * 0.08, size * 0.2);
      residue.lineTo(size, -size * 0.28);
      residue.strokePath();
      residue.lineStyle(1, core, 0.92);
      residue.strokeCircle(0, 0, size * 0.72);
    } else if (kind === "poison") {
      residue.fillStyle(accent, 0.22);
      residue.fillEllipse(0, 0, size * 1.9, size * 0.7);
      residue.fillStyle(primary, 0.5);
      residue.fillCircle(-size * 0.48, -2, size * 0.2);
      residue.fillCircle(size * 0.42, 1, size * 0.14);
    } else if (kind === "ketchup") {
      residue.fillStyle(primary, 0.42);
      residue.fillEllipse(0, 0, size * 1.8, size * 0.62);
      residue.fillCircle(-size * 0.8, -size * 0.12, size * 0.18);
      residue.fillCircle(size * 0.72, size * 0.08, size * 0.14);
    } else {
      residue.lineStyle(kind === "peeler" ? 3 : 2, primary, 0.52);
      for (const offset of [-0.42, 0, 0.42]) {
        residue.lineBetween(-size, offset * size * 0.5, size, offset * size * 0.5 - size * 0.22);
      }
    }

    this.scene.tweens.add({
      targets: residue,
      alpha: 0,
      scale: kind === "poison" ? 1.45 : 1.2,
      delay: Math.round(durationMs * 0.42),
      duration: Math.max(80, Math.round(durationMs * 0.58)),
      ease: "Sine.easeOut",
      onComplete: () => this.releaseParticle(residue),
    });
  }

  private drawMuzzleArc(
    graphics: Phaser.GameObjects.Graphics,
    angle: number,
    radius: number,
    primary: number,
    accent: number,
  ): void {
    for (const side of [-1, 1]) {
      graphics.lineStyle(side < 0 ? 5 : 3, side < 0 ? accent : primary, 0.78);
      graphics.beginPath();
      for (let step = 0; step <= 4; step += 1) {
        const progress = step / 4;
        const arcAngle = angle + side * (0.34 + progress * 0.72);
        const distance = radius * (0.48 + progress * 0.72);
        const pointX = Math.cos(arcAngle) * distance;
        const pointY = Math.sin(arcAngle) * distance;
        if (step === 0) {
          graphics.moveTo(pointX, pointY);
        } else {
          graphics.lineTo(pointX, pointY);
        }
      }
      graphics.strokePath();
    }
  }

  private drawImpactSlashes(graphics: Phaser.GameObjects.Graphics, angle: number, radius: number, color: number, rayCount: number): void {
    graphics.lineStyle(Math.max(2, radius * 0.09), color, 0.82);
    for (let index = 0; index < rayCount; index += 1) {
      const spread = rayCount <= 1 ? 0 : index / (rayCount - 1) - 0.5;
      const slashAngle = angle + spread * 1.7 + (index % 2 === 0 ? -0.05 : 0.05);
      const reach = index % 2 === 0 ? 0.92 : 0.72;
      graphics.beginPath();
      graphics.moveTo(Math.cos(slashAngle) * radius * 0.15, Math.sin(slashAngle) * radius * 0.15);
      graphics.lineTo(Math.cos(slashAngle) * radius * reach, Math.sin(slashAngle) * radius * reach);
      graphics.strokePath();
    }
  }

  private fadeGraphics(graphics: Phaser.GameObjects.Graphics, duration: number, scale: number, startScale = 1): void {
    this.activeAccents += 1;
    graphics.setScale(startScale);
    this.scene.tweens.add({
      targets: graphics,
      alpha: 0,
      scale,
      duration,
      ease: "Quad.easeOut",
      onComplete: () => {
        if (!this.ownedGraphics.has(graphics)) return;
        this.activeAccents = Math.max(0, this.activeAccents - 1);
        this.releaseGraphics(graphics);
      },
    });
  }

  private releaseParticle(particle: Phaser.GameObjects.Graphics): void {
    if (!this.ownedGraphics.has(particle)) return;
    this.activeParticles = Math.max(0, this.activeParticles - 1);
    this.releaseGraphics(particle);
  }

  private acquireGraphics(): Phaser.GameObjects.Graphics {
    const graphics = EntityPools.acquireGraphics(this.scene);
    this.ownedGraphics.add(graphics);
    return graphics;
  }

  private releaseGraphics(graphics: Phaser.GameObjects.Graphics): void {
    if (!this.ownedGraphics.delete(graphics)) return;
    // DisplayList shutdown may already have destroyed this object before our listener runs.
    if (graphics.scene === this.scene) EntityPools.releaseGraphics(this.scene, graphics);
  }

  private destroyTransient(transient: Phaser.GameObjects.GameObject): void {
    this.reactionLabels.delete(transient);
    if (this.transients.delete(transient)) transient.destroy();
  }

  private onScreen(x: number, y: number): boolean {
    const view = this.scene.cameras.main.worldView;
    return !view || x >= view.x - 100 && x <= view.x + view.width + 100 && y >= view.y - 100 && y <= view.y + view.height + 100;
  }
}
