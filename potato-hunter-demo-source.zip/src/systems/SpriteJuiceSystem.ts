import Phaser from "phaser";
import type { RenderComponent, SpriteJuiceComponent, TransformComponent, VelocityComponent } from "../components/ComponentTypes";
import { AssetManager } from "../managers/AssetManager";
import { EntityPools } from "../managers/EntityPools";
import { EventBus } from "../managers/EventBus";
import { distanceSquared } from "../utils/math";
import { getHeroLocomotionPose, getHitSquashPose, getMonsterJumpPose, getPlayerAttackPose, getProjectileMotion } from "./CombatJuiceModel";
import { getCharacterGroundPoint } from "./ShadowProfileModel";
import { getCharacterWalkRig } from "./CharacterWalkModel";
import type { GameRuntime, System } from "./SystemTypes";
import { HERO_ACTIONS, HERO_ATTACK_CONTACT } from "./AuthoredHeroModel";

interface DeathJuicePayload {
  x: number;
  y: number;
  render: RenderComponent;
}

interface WeaponFiredPayload {
  directionX: number;
  directionY: number;
  skillId?: string;
  remainingMs?: number;
  playerId?: number;
  world?: GameRuntime["world"];
}

const JUICE = {
  monsterBobPixels: 3,
  chargerStretch: 0.16,
  heavyBobPixels: 1.6,
  rangedChargeScale: 0.08,
  bossJitterPixels: 1.4,
  bossAoeScale: 0.08,
};

export class SpriteJuiceSystem implements System {
  private elapsedMs = 0;
  private activeDeathFx = 0;
  private playerFacingX: -1 | 1 = 1;
  private attackSequence = 0;
  private weaponReleaseSequence = 0;
  private ownerHasRelease = false;
  private playerAttack = { remainingMs: 0, totalMs: 230, directionX: 1, directionY: 0 };
  private attackUpdatedByEvent = false;
  private awaitingRelease = false;
  private windupWaitMs = 0;
  private attackSkillId?: string;
  private ownerId?: number;
  private ownerWorld?: GameRuntime["world"];

  constructor(private readonly scene: Phaser.Scene) {
    EventBus.on("juice:death", this.showDeathJuice, this);
    EventBus.on("weapon:fired", this.capturePlayerAttack, this);
    EventBus.on("weapon:windup", this.capturePlayerWindup, this);
    scene.events.once(Phaser.Scenes.Events.SHUTDOWN, () => this.destroy());
  }

  update(deltaMs: number, runtime: GameRuntime): void {
    this.setAttackOwner(runtime.playerId, runtime.world);
    this.elapsedMs += deltaMs;
    if (!this.attackUpdatedByEvent) {
      this.playerAttack.remainingMs = Math.max(0, this.playerAttack.remainingMs - deltaMs);
      if (this.awaitingRelease) {
        const heldRemaining = HERO_ACTIONS.attack.durationMs * (1 - HERO_ATTACK_CONTACT + .08);
        if (this.playerAttack.remainingMs < heldRemaining) {
          this.windupWaitMs += deltaMs;
          this.playerAttack.remainingMs = heldRemaining;
          if (this.windupWaitMs > 140) { this.awaitingRelease = false; this.playerAttack.remainingMs = 0; }
        }
      }
    }
    this.attackUpdatedByEvent = false;

    for (const entityId of runtime.world.components.renders.keys()) {
      const transform = runtime.world.components.transforms.get(entityId);
      const velocity = runtime.world.components.velocities.get(entityId);
      if (!transform) {
        runtime.world.components.spriteJuices.delete(entityId);
        continue;
      }

      const juice = this.createBaseJuice();

      if (runtime.world.components.players.has(entityId)) {
        this.applyPlayerJuice(juice, velocity);
      }

      const projectile = runtime.world.components.projectiles.get(entityId);
      if (projectile) {
        this.applyProjectileJuice(juice, entityId, projectile.vfxKind ?? "kinetic", velocity);
      }

      const monster = runtime.world.components.monsters.get(entityId);
      if (monster) {
        this.applyMonsterJuice(runtime, entityId, juice, transform, velocity);
      }

      const flash = runtime.world.components.hitFlashes.get(entityId);
      if (flash) {
        const flashRatio = Math.max(0, flash.remainingMs / flash.totalMs);
        const hit = getHitSquashPose(flashRatio, entityId);
        juice.scaleX *= hit.scaleX;
        juice.scaleY *= hit.scaleY;
        juice.rotation += hit.rotation;
        juice.offsetX += Math.sin(this.elapsedMs * 0.11 + entityId) * flashRatio * 2.2;
      }

      runtime.world.components.spriteJuices.set(entityId, juice);
    }
  }

  destroy(): void {
    EventBus.off("juice:death", this.showDeathJuice, this);
    EventBus.off("weapon:fired", this.capturePlayerAttack, this);
    EventBus.off("weapon:windup", this.capturePlayerWindup, this);
  }

  private createBaseJuice(): SpriteJuiceComponent {
    return {
      offsetX: 0,
      offsetY: 0,
      scaleX: 1,
      scaleY: 1,
      rotation: 0,
      facingX: 1,
      shadowScaleX: 1,
      shadowScaleY: 1,
      shadowAlpha: 0.22,
    };
  }

  private applyPlayerJuice(juice: SpriteJuiceComponent, velocity?: VelocityComponent): void {
    juice.attackSequence = this.attackSequence;
    juice.attackProgress = 1 - this.playerAttack.remainingMs / this.playerAttack.totalMs;
    juice.weaponReleaseSequence = this.ownerHasRelease ? this.weaponReleaseSequence : undefined;
    const locomotion = getHeroLocomotionPose(
      this.elapsedMs,
      velocity?.x ?? 0,
      velocity?.y ?? 0,
      this.playerFacingX,
    );
    this.playerFacingX = locomotion.facingX;
    juice.offsetX += locomotion.offsetX;
    juice.offsetY += locomotion.offsetY;
    juice.scaleX *= locomotion.scaleX;
    juice.scaleY *= locomotion.scaleY;
    juice.rotation += locomotion.rotation;
    juice.facingX = locomotion.facingX;
    juice.shadowScaleX = locomotion.shadowScaleX;
    juice.shadowScaleY = locomotion.shadowScaleY;
    juice.shadowAlpha = locomotion.shadowAlpha;

    if (this.playerAttack.remainingMs > 0) {
      const progress = 1 - this.playerAttack.remainingMs / this.playerAttack.totalMs;
      const attack = getPlayerAttackPose(progress, this.playerAttack.directionX, this.playerAttack.directionY);
      juice.limbAttack = attack.smear;
      juice.offsetX += attack.offsetX * 0.16;
      juice.offsetY += attack.offsetY * 0.1;
      juice.scaleX *= 1 + (attack.scaleX - 1) * 0.12;
      juice.scaleY *= 1 + (attack.scaleY - 1) * 0.12;
      juice.rotation += attack.rotation * 0.16;
      if (attack.phase === "strike") {
        juice.offsetY -= attack.smear * 0.2;
      }
    }

  }

  private applyProjectileJuice(juice: SpriteJuiceComponent, entityId: number, kind: "kinetic" | "peeler" | "fire" | "frost" | "lightning" | "poison" | "explosion" | "ketchup", velocity?: VelocityComponent): void {
    const speed = velocity ? Math.hypot(velocity.x, velocity.y) : 0;
    const motion = getProjectileMotion(kind, this.elapsedMs, entityId, speed);
    juice.scaleX *= motion.scaleX;
    juice.scaleY *= motion.scaleY;
    juice.rotation += motion.rotation;
  }

  private capturePlayerAttack(payload: WeaponFiredPayload): void {
    if (payload.world && payload.playerId !== undefined) this.setAttackOwner(payload.playerId, payload.world);
    this.weaponReleaseSequence += 1;
    this.ownerHasRelease = true;
    if (Math.abs(payload.directionX) > 0.18) {
      this.playerFacingX = payload.directionX < 0 ? -1 : 1;
    }
    if (this.playerAttack.remainingMs > 0 && (!this.awaitingRelease || this.attackSkillId !== payload.skillId)) return;
    if (!this.awaitingRelease) this.attackSequence += 1;
    this.awaitingRelease = false;
    this.windupWaitMs = 0;
    this.attackSkillId = payload.skillId;
    this.attackUpdatedByEvent = true;
    this.playerAttack = {
      remainingMs: HERO_ACTIONS.attack.durationMs * (1 - HERO_ATTACK_CONTACT),
      totalMs: HERO_ACTIONS.attack.durationMs,
      directionX: payload.directionX,
      directionY: payload.directionY,
    };
  }

  private capturePlayerWindup(payload: WeaponFiredPayload): void {
    if (payload.world && payload.playerId !== undefined) this.setAttackOwner(payload.playerId, payload.world);
    if (this.playerAttack.remainingMs > 0) return;
    this.attackSequence += 1;
    this.awaitingRelease = true;
    this.windupWaitMs = 0;
    this.attackSkillId = payload.skillId;
    this.attackUpdatedByEvent = true;
    this.playerAttack = {
      remainingMs: HERO_ACTIONS.attack.durationMs * (1 - HERO_ATTACK_CONTACT) + Math.max(HERO_ACTIONS.attack.durationMs * .08, Math.min(HERO_ACTIONS.attack.durationMs * HERO_ATTACK_CONTACT, payload.remainingMs ?? 0)),
      totalMs: HERO_ACTIONS.attack.durationMs,
      directionX: payload.directionX,
      directionY: payload.directionY,
    };
  }

  private setAttackOwner(playerId: number, world: GameRuntime["world"]): void {
    if (this.ownerWorld && (this.ownerWorld !== world || this.ownerId !== playerId)) {
      this.playerAttack.remainingMs = 0;
      this.ownerHasRelease = false;
      this.awaitingRelease = false;
      this.windupWaitMs = 0;
      this.attackUpdatedByEvent = false;
      this.attackSkillId = undefined;
      this.playerFacingX = 1;
    }
    this.ownerId = playerId;
    this.ownerWorld = world;
  }

  private applyMonsterJuice(
    runtime: GameRuntime,
    entityId: number,
    juice: SpriteJuiceComponent,
    transform: TransformComponent,
    velocity?: VelocityComponent,
  ): void {
    const monster = runtime.world.components.monsters.get(entityId);
    if (!monster) {
      return;
    }

    if (monster.isBoss) {
      this.applyBossJuice(runtime, entityId, juice, transform);
      return;
    }

    if (monster.behavior === "jumper" && monster.jumpProgress !== undefined) {
      const jump = getMonsterJumpPose(monster.jumpProgress);
      juice.offsetY += jump.offsetY;
      juice.shadowScaleX *= jump.shadowScaleX;
      juice.shadowScaleY *= jump.shadowScaleY;
      juice.shadowAlpha = jump.shadowAlpha;
      return;
    }

    const moving = this.getSpeedSquared(velocity) > 8;
    const phase = this.elapsedMs * 0.012 + entityId * 0.7;
    const articulated = Boolean(getCharacterWalkRig(runtime.world.components.renders.get(entityId)?.assetId ?? ""));
    if (articulated) {
      juice.facingX = runtime.world.components.spriteJuices.get(entityId)?.facingX ?? 1;
      if (velocity && Math.abs(velocity.x) > 8) juice.facingX = velocity.x < 0 ? -1 : 1;
      juice.offsetY += moving ? Math.sin(phase * 2) * 0.3 : Math.sin(phase * 0.35) * 0.25;
      // Limb motion is rendered independently; keep attack telegraph anticipation subtle.
      if (monster.behavior === "ranged" && monster.behaviorTimerMs < 320) {
        juice.limbAttack = Phaser.Math.Clamp(1 - monster.behaviorTimerMs / 320, 0, 1);
      }
      return;
    }

    if (monster.behavior === "summoner") {
      juice.offsetY += Math.abs(Math.sin(phase * 0.45)) * JUICE.heavyBobPixels;
      juice.scaleY *= moving ? 0.99 : 1;
      return;
    }

    if (moving) {
      juice.offsetY += -Math.abs(Math.sin(phase)) * JUICE.monsterBobPixels;
    }

    if (monster.behavior === "charger" && monster.stateTimerMs > 0) {
      const ratio = Phaser.Math.Clamp(monster.stateTimerMs / 360, 0, 1);
      juice.scaleX *= 1 + ratio * JUICE.chargerStretch;
      juice.scaleY *= 1 - ratio * 0.08;
      juice.rotation += Math.sin(this.elapsedMs * 0.05) * ratio * 0.035;
    }

    if (monster.behavior === "ranged" && monster.behaviorTimerMs < 320) {
      const ratio = Phaser.Math.Clamp(1 - monster.behaviorTimerMs / 320, 0, 1);
      juice.scaleX *= 1 - ratio * 0.04;
      juice.scaleY *= 1 + ratio * JUICE.rangedChargeScale;
      juice.offsetY += ratio * 2;
    }
  }

  private applyBossJuice(runtime: GameRuntime, entityId: number, juice: SpriteJuiceComponent, transform: TransformComponent): void {
    const lowFreq = Math.sin(this.elapsedMs * 0.004 + entityId);
    const chatter = Math.sin(this.elapsedMs * 0.055 + entityId * 2);

    juice.offsetX += chatter * JUICE.bossJitterPixels + lowFreq * 0.8;
    juice.rotation += Math.sin(this.elapsedMs * 0.018) * 0.018;

    const warningNearBoss = [...runtime.world.components.aoeWarnings.keys()].some((warningId) => {
      const warningTransform = runtime.world.components.transforms.get(warningId);
      return Boolean(warningTransform && distanceSquared(transform.x, transform.y, warningTransform.x, warningTransform.y) < 260 * 260);
    });

    if (warningNearBoss) {
      const charge = (Math.sin(this.elapsedMs * 0.018) + 1) * 0.5;
      const scale = 1 + charge * JUICE.bossAoeScale;
      juice.scaleX *= scale;
      juice.scaleY *= scale;
    }
  }

  private getSpeedSquared(velocity?: VelocityComponent): number {
    if (!velocity) {
      return 0;
    }

    return velocity.x * velocity.x + velocity.y * velocity.y;
  }

  private showDeathJuice(payload: DeathJuicePayload): void {
    this.showDeathDustRing(payload);
    if (AssetManager.hasTexture(this.scene, payload.render.assetId)) {
      this.showSpriteDeathJuice(payload);
      return;
    }

    this.showShapeDeathJuice(payload);
  }

  private showSpriteDeathJuice(payload: DeathJuicePayload): void {
    const image = this.scene.add.image(payload.x, payload.y, AssetManager.getTextureKey(payload.render.assetId!));
    const displaySize = AssetManager.getDisplaySize(payload.render.assetId, payload.render.size);
    const pivot = AssetManager.getPivot(payload.render.assetId);

    image.setOrigin(pivot.x, pivot.y);
    image.setDisplaySize(displaySize, displaySize);
    image.setDepth(6);
    image.setAlpha(payload.render.alpha ?? 1);

    const fallDirection = Math.sin(payload.x * 0.017 + payload.y * 0.013) < 0 ? -1 : 1;

    this.scene.tweens.add({
      targets: image,
      scaleX: image.scaleX * 1.18,
      scaleY: image.scaleY * 0.72,
      y: payload.y + 5,
      duration: 65,
      ease: "Quad.easeIn",
      onComplete: () => {
        this.scene.tweens.add({
          targets: image,
          y: payload.y - 28,
          rotation: fallDirection * 0.28,
          scaleX: image.scaleX * 0.74,
          scaleY: image.scaleY * 0.72,
          alpha: 0,
          duration: 190,
          ease: "Cubic.easeOut",
          onComplete: () => image.destroy(),
        });
      },
    });
  }

  private showShapeDeathJuice(payload: DeathJuicePayload): void {
    const ghost = this.scene.add.graphics();
    const halfSize = payload.render.size / 2;
    ghost.setPosition(payload.x, payload.y);
    ghost.setDepth(6);
    ghost.fillStyle(payload.render.color, payload.render.alpha ?? 1);
    if (payload.render.shape === "square") {
      ghost.fillRect(-halfSize, -halfSize, payload.render.size, payload.render.size);
    } else {
      ghost.fillCircle(0, 0, halfSize);
    }

    this.scene.tweens.add({
      targets: ghost,
      y: payload.y - 22,
      rotation: 0.24,
      scaleX: 1.2,
      scaleY: 0.64,
      alpha: 0,
      duration: 220,
      ease: "Cubic.easeOut",
      onComplete: () => ghost.destroy(),
    });
  }

  private showDeathDustRing(payload: DeathJuicePayload): void {
    if (this.activeDeathFx >= 24) {
      return;
    }
    this.activeDeathFx += 1;
    const dust = EntityPools.acquireGraphics(this.scene);
    const radius = Math.max(12, payload.render.size * 0.32);
    const hasTexture = AssetManager.hasTexture(this.scene, payload.render.assetId);
    const ground = getCharacterGroundPoint({
      x: payload.x, y: payload.y,
      visualSize: hasTexture ? AssetManager.getDisplaySize(payload.render.assetId, payload.render.size) : payload.render.size,
      pivot: hasTexture ? AssetManager.getPivot(payload.render.assetId) : { x: 0.5, y: 0.5 },
      footPoint: hasTexture ? AssetManager.getFootPoint(payload.render.assetId) : { x: 0.5, y: 1 },
      scaleX: 1, scaleY: 1, rotation: 0,
    });
    dust.setPosition(ground.x, ground.y).setDepth(4).setScale(0.45);
    dust.lineStyle(Math.max(3, radius * 0.16), 0xe7d5a2, 0.54);
    dust.strokeEllipse(0, 0, radius * 2.1, radius * 0.62);
    dust.lineStyle(2, 0x4c3c2a, 0.32);
    dust.strokeEllipse(0, 0, radius * 1.42, radius * 0.38);
    this.scene.tweens.add({
      targets: dust,
      alpha: 0,
      scaleX: 1.65,
      scaleY: 1.1,
      duration: 250,
      ease: "Cubic.easeOut",
      onComplete: () => {
        this.activeDeathFx = Math.max(0, this.activeDeathFx - 1);
        EntityPools.releaseGraphics(this.scene, dust);
      },
    });
  }
}
