import { createExperienceOrb, createMonster } from "../entities/factories";
import { ConfigManager } from "../managers/ConfigManager";
import type { EntityId } from "../components/ComponentTypes";
import { EventBus } from "../managers/EventBus";
import { distanceSquared } from "../utils/math";
import { canReceiveHostileDamage, getHostileHitGraceMs } from "./PlayerDamageModel";
import { ELITE_DEATH_BOMB_RADIUS } from "./EliteHazardModel";
import { applyHealthDamage } from "./HealthDamage";
import type { GameRuntime, System } from "./SystemTypes";

export class DeathSystem implements System {
  readonly telemetrySource = "DeathSystem";
  private toxicBurstCooldownMs = 0;

  update(deltaMs: number, runtime: GameRuntime): void {
    this.toxicBurstCooldownMs = Math.max(0, this.toxicBurstCooldownMs - deltaMs);
    const deadMonsters: EntityId[] = [];
    const defeated: Array<{ id: EntityId; isBoss: boolean }> = [];

    for (const [entityId, monster] of runtime.world.components.monsters) {
      const health = runtime.world.components.health.get(entityId);
      if (!health || health.current > 0) {
        continue;
      }

      const transform = runtime.world.components.transforms.get(entityId);
      if (transform) {
        createExperienceOrb(runtime.world, transform.x, transform.y, monster.experienceValue);
        const sparkCount = monster.isBoss ? 28 : 7;
        const sparkColor = monster.isBoss ? 0xef476f : 0xf4d35e;
        EventBus.emit("fx:sparks", { x: transform.x, y: transform.y, color: sparkColor, count: sparkCount, size: monster.isBoss ? 10 : 7 });
        const render = runtime.world.components.renders.get(entityId);
        if (render) {
          EventBus.emit("juice:death", { x: transform.x, y: transform.y, render: { ...render } });
        }
        if (!monster.isBoss) {
          this.triggerToxicBurst(runtime, entityId, transform.x, transform.y);
          this.triggerEliteDeathAffix(runtime, entityId, transform.x, transform.y);
        }
      }

      runtime.stats.kills += 1;
      if (monster.isBoss) {
        runtime.stats.bossKills += 1;
        EventBus.emit("boss:defeated");
        if (transform) {
          for (let index = 0; index < 10; index += 1) {
            createExperienceOrb(runtime.world, transform.x + Math.cos(index) * 32, transform.y + Math.sin(index) * 32, monster.experienceValue);
          }
        }
      }
      deadMonsters.push(entityId);
      defeated.push({ id: entityId, isBoss: monster.isBoss });
    }

    for (const entityId of deadMonsters) {
      runtime.world.destroyEntity(entityId);
    }
    // All simultaneous death affixes and kill counters must resolve before a win.
    if (defeated.length && (runtime.world.components.health.get(runtime.playerId)?.current ?? 0) <= 0) runtime.endRun("defeat");
    else for (const monster of defeated) runtime.onMonsterDefeated?.(monster.id, monster.isBoss);
  }

  private triggerToxicBurst(runtime: GameRuntime, sourceId: EntityId, x: number, y: number): void {
    if (this.toxicBurstCooldownMs > 0 || !runtime.skillManager.hasSkill("toxic_burst_cloud")) {
      return;
    }

    const radius = 170;
    const radiusSquared = radius * radius;
    let hitCount = 0;

    for (const entityId of runtime.world.components.monsters.keys()) {
      if (entityId === sourceId) {
        continue;
      }

      const transform = runtime.world.components.transforms.get(entityId);
      const health = runtime.world.components.health.get(entityId);
      if (!transform || !health || health.current <= 0 || distanceSquared(x, y, transform.x, transform.y) > radiusSquared) {
        continue;
      }

      hitCount += 1;
      const dealt = applyHealthDamage(health, 7);
      runtime.world.components.hitFlashes.set(entityId, { remainingMs: 70, totalMs: 70 });
      const currentStatuses = runtime.world.components.statuses.get(entityId) ?? [];
      if (!currentStatuses.some(status => status.type === "poison" && status.damagePerSecond > 4)) {
        runtime.world.components.statuses.set(entityId, [
          ...currentStatuses.filter(status => status.type !== "poison"),
          { type: "poison", remainingMs: 1400, totalMs: 1400, damagePerSecond: 4, slowMultiplier: 1 },
        ]);
      }
      if (dealt > 0) EventBus.emit("combat:damage", { x: transform.x, y: transform.y, value: dealt, color: "#70e000", targetId: entityId, category: "outgoing" });
    }

    if (hitCount <= 0) {
      return;
    }

    this.toxicBurstCooldownMs = 900;
    EventBus.emit("combat:vfx", { kind: "poison", x, y, color: 0x70e000, radius });
    EventBus.emit("fx:sparks", { x, y, color: 0x70e000, count: Math.min(22, 8 + hitCount), size: 8 });
  }

  private triggerEliteDeathAffix(runtime: GameRuntime, sourceId: EntityId, x: number, y: number): void {
    const monster = runtime.world.components.monsters.get(sourceId);
    if (!monster?.isElite || !monster.eliteAffix) {
      return;
    }

    if (monster.eliteAffix === "split") {
      const config = ConfigManager.getMonster("fries_cultist");
      for (let index = 0; index < 3; index += 1) {
        const angle = (Math.PI * 2 * index) / 3 + (runtime.random ?? Math.random)() * 0.35;
        const childId = createMonster(runtime.world, config, x + Math.cos(angle) * 34, y + Math.sin(angle) * 34);
        const childHealth = runtime.world.components.health.get(childId);
        const childMonster = runtime.world.components.monsters.get(childId);
        const childRender = runtime.world.components.renders.get(childId);
        const childTransform = runtime.world.components.transforms.get(childId);
        if (childHealth) {
          childHealth.max = Math.ceil(childHealth.max * 0.55);
          childHealth.current = childHealth.max;
        }
        if (childMonster) {
          childMonster.experienceValue = Math.max(1, Math.floor(childMonster.experienceValue * 0.35));
          childMonster.speedMultiplier *= 1.18;
        }
        if (childRender) {
          childRender.size *= 0.82;
          childRender.color = 0x4cc9f0;
        }
        if (childTransform) {
          childTransform.radius *= 0.82;
        }
      }
      EventBus.emit("boss:phase", { text: "精英分裂！" });
      EventBus.emit("fx:sparks", { x, y, color: 0x4cc9f0, count: 18, size: 7 });
    }

    if (monster.eliteAffix === "death_bomb") {
      const radius = ELITE_DEATH_BOMB_RADIUS;
      const radiusSquared = radius * radius;
      const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
      const playerHealth = runtime.world.components.health.get(runtime.playerId);
      const player = runtime.world.components.players.get(runtime.playerId);
      EventBus.emit("hostile:impact", { x, y, radius, style: "oil" });
      if (playerTransform && playerHealth && player && canReceiveHostileDamage(player) && distanceSquared(x, y, playerTransform.x, playerTransform.y) <= radiusSquared) {
        const damage = Math.ceil(monster.damage * 1.6);
        playerHealth.current -= damage;
        player.damageCooldownMs = getHostileHitGraceMs("explosion");
        EventBus.emit("combat:damage", { x: playerTransform.x, y: playerTransform.y, value: damage, color: "#ff4800", isCrit: true, targetId: runtime.playerId, category: "incoming" });
      }
    }
  }
}
