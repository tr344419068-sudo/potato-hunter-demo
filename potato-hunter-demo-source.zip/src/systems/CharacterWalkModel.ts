interface Point { x: number; y: number }

export interface CharacterWalkRig {
  leftShoulder: Point;
  rightShoulder: Point;
  leftHand: Point;
  rightHand: Point;
  leftFoot: Point;
  rightFoot: Point;
  hipY: number;
  legStart: number;
  legSplit: number;
  leftEdge: number;
  rightEdge: number;
  armEnd: number;
}

export interface CharacterWalkPose {
  stride: number;
  strength: number;
  directionX: number;
  directionY: number;
  bodyY: number;
  attack: number;
}

const RIGS: Record<string, CharacterWalkRig> = {
  enemy_desert_cactus: { leftShoulder: { x: .30, y: .48 }, rightShoulder: { x: .7, y: .48 }, leftHand: { x: .19, y: .62 }, rightHand: { x: .83, y: .62 }, leftFoot: { x: .32, y: .94 }, rightFoot: { x: .72, y: .95 }, hipY: .75, legStart: .78, legSplit: .52, leftEdge: .29, rightEdge: .72, armEnd: .76 },
  enemy_desert_scorpion: { leftShoulder: { x: .3, y: .52 }, rightShoulder: { x: .7, y: .52 }, leftHand: { x: .16, y: .62 }, rightHand: { x: .84, y: .62 }, leftFoot: { x: .36, y: .88 }, rightFoot: { x: .66, y: .88 }, hipY: .74, legStart: .70, legSplit: .5, leftEdge: .28, rightEdge: .72, armEnd: .75 },
  char_potato_hunter: { leftShoulder: { x: .36, y: .47 }, rightShoulder: { x: .8, y: .55 }, leftHand: { x: .28, y: .55 }, rightHand: { x: .94, y: .68 }, leftFoot: { x: .39, y: .9 }, rightFoot: { x: .75, y: .9 }, hipY: .76, legStart: .74, legSplit: .57, leftEdge: .36, rightEdge: .81, armEnd: .72 },
  enemy_fries_soldier: { leftShoulder: { x: .31, y: .56 }, rightShoulder: { x: .69, y: .58 }, leftHand: { x: .22, y: .64 }, rightHand: { x: .85, y: .67 }, leftFoot: { x: .36, y: .87 }, rightFoot: { x: .66, y: .91 }, hipY: .75, legStart: .73, legSplit: .51, leftEdge: .32, rightEdge: .69, armEnd: .77 },
  enemy_tomato_angry: { leftShoulder: { x: .26, y: .54 }, rightShoulder: { x: .76, y: .56 }, leftHand: { x: .17, y: .66 }, rightHand: { x: .88, y: .68 }, leftFoot: { x: .36, y: .86 }, rightFoot: { x: .66, y: .89 }, hipY: .76, legStart: .75, legSplit: .52, leftEdge: .24, rightEdge: .78, armEnd: .77 },
  enemy_onion_cry: { leftShoulder: { x: .27, y: .56 }, rightShoulder: { x: .74, y: .57 }, leftHand: { x: .14, y: .67 }, rightHand: { x: .87, y: .67 }, leftFoot: { x: .35, y: .89 }, rightFoot: { x: .66, y: .89 }, hipY: .78, legStart: .75, legSplit: .5, leftEdge: .28, rightEdge: .73, armEnd: .77 },
  enemy_corn_mold: { leftShoulder: { x: .3, y: .56 }, rightShoulder: { x: .71, y: .56 }, leftHand: { x: .17, y: .65 }, rightHand: { x: .85, y: .65 }, leftFoot: { x: .34, y: .9 }, rightFoot: { x: .66, y: .9 }, hipY: .77, legStart: .74, legSplit: .5, leftEdge: .3, rightEdge: .72, armEnd: .76 },
};

export const getCharacterWalkRig = (assetId: string): CharacterWalkRig | undefined => RIGS[assetId];

export function advanceWalkPhase(phase: number, distance: number, visualSize: number): number {
  return (phase + Math.max(0, distance) / Math.max(24, visualSize * .94) * Math.PI * 2) % (Math.PI * 2);
}

export function getCharacterWalkPose(phase: number, speed: number, directionX: number, directionY: number, attack: number): CharacterWalkPose {
  const strength = speed > 5 ? Math.min(1, speed / 150) : 0;
  return { stride: Math.sin(phase), strength, directionX, directionY, bodyY: Math.sin(phase * 2) * .0014 * strength, attack: Math.min(1, Math.max(0, attack)) };
}

function smooth(from: number, to: number, value: number): number {
  const t = Math.min(1, Math.max(0, (value - from) / (to - from)));
  return t * t * (3 - 2 * t);
}

function rotateOffset(u: number, v: number, joint: Point, angle: number): Point {
  const x = u - joint.x, y = v - joint.y;
  return { x: Math.cos(angle) * x - Math.sin(angle) * y - x, y: Math.sin(angle) * x + Math.cos(angle) * y - y };
}

export function deformCharacterPoint(u: number, v: number, rig: CharacterWalkRig, pose: CharacterWalkPose): Point {
  const stride = pose.stride * pose.strength;
  const legWeight = smooth(rig.legStart, rig.legStart + .1, v);
  const rightWeight = smooth(rig.legSplit - .09, rig.legSplit + .09, u);
  const side = 1 - rightWeight * 2;
  const step = stride * side;
  // One boot swings forward while the opposite boot remains planted. The torso does not jump.
  const lift = Math.max(0, step) * .019;
  let x = u + legWeight * (step * .043 * Math.max(.48, Math.abs(pose.directionX)));
  let y = v + legWeight * (step * pose.directionY * .026 - lift);
  y += pose.bodyY * (1 - legWeight);

  // A broad shoulder-to-hip blend avoids folding the triangulated UVs at the cuff.
  const armEnd = 1 - smooth(rig.armEnd - .12, rig.armEnd + .12, v);
  const leftArm = (1 - smooth(rig.leftEdge - .1, rig.leftEdge + .07, u)) * armEnd;
  const rightArm = smooth(rig.rightEdge - .07, rig.rightEdge + .1, u) * armEnd;
  const left = rotateOffset(u, v, rig.leftShoulder, stride * .13 - pose.attack * .15);
  const right = rotateOffset(u, v, rig.rightShoulder, -stride * .13 + pose.attack * .05);
  x += left.x * leftArm + right.x * rightArm;
  y += left.y * leftArm + right.y * rightArm;
  return { x, y };
}
