import type { MapEventComponent } from "../components/ComponentTypes";

export interface PickupPresentation {
  assetId: string;
  label: string;
  color: number;
}

const PICKUP_ART: Record<MapEventComponent["kind"], PickupPresentation> = {
  supply: { assetId: "ui_v2_icon_coin", label: "随机补给", color: 0xffd166 },
  heal: { assetId: "ui_v2_icon_heart", label: "生命补给", color: 0xff7788 },
  magnet: { assetId: "icon_skill_magnet_salt", label: "磁吸补给", color: 0x69e8ff },
  haste: { assetId: "icon_skill_starch_boots", label: "疾速补给", color: 0xb4f46d },
  xp_burst: { assetId: "ui_v2_icon_xp_crystal", label: "经验补给", color: 0x8ee8ff },
};

export const EXPERIENCE_ORB_ASSET_ID = "ui_v2_icon_xp_crystal";

export function getPickupPresentation(kind: MapEventComponent["kind"]): Readonly<PickupPresentation> {
  return PICKUP_ART[kind];
}
