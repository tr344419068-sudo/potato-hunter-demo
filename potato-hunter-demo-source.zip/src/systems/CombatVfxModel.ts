export type CombatVfxKind = "kinetic" | "peeler" | "fire" | "frost" | "lightning" | "poison" | "explosion" | "ketchup";
export type CombatVfxPhase = "muzzle" | "trail" | "impact";

export interface CombatImpactProfile {
  shakeDurationMs: number;
  shakeIntensity: number;
  ringScale: number;
}

export interface CombatVfxRecipe {
  trailLength: number;
  trailWidth: number;
  coreScale: number;
  impactRays: number;
  debrisCount: number;
  residueDurationMs: number;
}

export interface CombatVfxEnvelope {
  muzzleScale: number;
  trailScale: number;
  impactScale: number;
  secondaryDelayMs: number;
  durationMs: number;
}

const VFX_ENVELOPES: Readonly<Record<CombatVfxKind, Readonly<CombatVfxEnvelope>>> = {
  kinetic: { muzzleScale: 1.2, trailScale: 1.35, impactScale: 1.3, secondaryDelayMs: 55, durationMs: 250 },
  peeler: { muzzleScale: 1.3, trailScale: 1.5, impactScale: 1.65, secondaryDelayMs: 60, durationMs: 280 },
  fire: { muzzleScale: 1.32, trailScale: 1.6, impactScale: 1.65, secondaryDelayMs: 90, durationMs: 360 },
  frost: { muzzleScale: 1.22, trailScale: 1.4, impactScale: 1.55, secondaryDelayMs: 75, durationMs: 330 },
  lightning: { muzzleScale: 1.28, trailScale: 1.55, impactScale: 1.6, secondaryDelayMs: 45, durationMs: 240 },
  poison: { muzzleScale: 1.25, trailScale: 1.45, impactScale: 1.45, secondaryDelayMs: 100, durationMs: 420 },
  explosion: { muzzleScale: 1.35, trailScale: 1.35, impactScale: 1.75, secondaryDelayMs: 90, durationMs: 440 },
  ketchup: { muzzleScale: 1.28, trailScale: 1.45, impactScale: 1.5, secondaryDelayMs: 80, durationMs: 360 },
};

export function getCombatVfxEnvelope(kind: CombatVfxKind, critical = false): Readonly<CombatVfxEnvelope> {
  const envelope = VFX_ENVELOPES[kind];
  return critical ? { ...envelope, impactScale: envelope.impactScale * 1.22 } : envelope;
}

const COMBAT_VFX_RECIPES: Readonly<Record<CombatVfxKind, Readonly<CombatVfxRecipe>>> = Object.freeze({
  kinetic: Object.freeze({ trailLength: 22, trailWidth: 3, coreScale: 0.76, impactRays: 4, debrisCount: 6, residueDurationMs: 90 }),
  peeler: Object.freeze({ trailLength: 32, trailWidth: 3, coreScale: 0.7, impactRays: 6, debrisCount: 9, residueDurationMs: 120 }),
  fire: Object.freeze({ trailLength: 38, trailWidth: 5, coreScale: 1.06, impactRays: 8, debrisCount: 14, residueDurationMs: 340 }),
  frost: Object.freeze({ trailLength: 30, trailWidth: 4, coreScale: 0.92, impactRays: 9, debrisCount: 13, residueDurationMs: 420 }),
  lightning: Object.freeze({ trailLength: 46, trailWidth: 3, coreScale: 0.82, impactRays: 10, debrisCount: 12, residueDurationMs: 180 }),
  poison: Object.freeze({ trailLength: 26, trailWidth: 6, coreScale: 1, impactRays: 5, debrisCount: 14, residueDurationMs: 520 }),
  explosion: Object.freeze({ trailLength: 24, trailWidth: 7, coreScale: 1.36, impactRays: 12, debrisCount: 20, residueDurationMs: 480 }),
  ketchup: Object.freeze({ trailLength: 30, trailWidth: 5, coreScale: 1.05, impactRays: 7, debrisCount: 13, residueDurationMs: 380 }),
});

export function getCombatVfxRecipe(kind: CombatVfxKind): Readonly<CombatVfxRecipe> {
  return COMBAT_VFX_RECIPES[kind];
}

interface EffectLike {
  type: string;
}

export function resolveCombatVfxKind(tags: readonly string[], effects: readonly EffectLike[], explicit?: CombatVfxKind): CombatVfxKind {
  if (explicit) {
    return explicit;
  }
  if (effects.some((effect) => effect.type === "explosion")) {
    return "explosion";
  }
  if (tags.includes("poison")) {
    return "poison";
  }
  if (tags.includes("lightning")) {
    return "lightning";
  }
  if (tags.includes("ice")) {
    return "frost";
  }
  if (tags.includes("fire")) {
    return "fire";
  }
  if (tags.includes("pierce")) {
    return "peeler";
  }
  return "kinetic";
}

export function getCombatVfxBudget(kind: CombatVfxKind, phase: CombatVfxPhase): number {
  const trailBudgets: Record<CombatVfxKind, number> = {
    kinetic: 2,
    peeler: 3,
    fire: 5,
    frost: 4,
    lightning: 3,
    poison: 5,
    explosion: 4,
    ketchup: 4,
  };
  if (phase === "trail") {
    return trailBudgets[kind];
  }
  if (phase === "muzzle") {
    return Math.min(10, trailBudgets[kind] + 3);
  }
  return Math.min(24, trailBudgets[kind] * 3 + 3);
}

export function getCombatImpactProfile(kind: CombatVfxKind, critical: boolean): CombatImpactProfile {
  const baseProfiles: Record<CombatVfxKind, CombatImpactProfile> = {
    kinetic: { shakeDurationMs: 58, shakeIntensity: 0.0017, ringScale: 1.32 },
    peeler: { shakeDurationMs: 68, shakeIntensity: 0.0022, ringScale: 1.42 },
    fire: { shakeDurationMs: 82, shakeIntensity: 0.0027, ringScale: 1.52 },
    frost: { shakeDurationMs: 70, shakeIntensity: 0.0021, ringScale: 1.4 },
    lightning: { shakeDurationMs: 72, shakeIntensity: 0.0031, ringScale: 1.48 },
    poison: { shakeDurationMs: 54, shakeIntensity: 0.0015, ringScale: 1.3 },
    explosion: { shakeDurationMs: 160, shakeIntensity: 0.0072, ringScale: 2.05 },
    ketchup: { shakeDurationMs: 72, shakeIntensity: 0.0025, ringScale: 1.46 },
  };
  const base = baseProfiles[kind];

  if (!critical) {
    return base;
  }

  return {
    shakeDurationMs: Math.round(base.shakeDurationMs * 1.2),
    shakeIntensity: base.shakeIntensity * 1.55,
    ringScale: base.ringScale * 1.16,
  };
}

export function getCombatVfxPalette(kind: CombatVfxKind): readonly [number, number, number] {
  switch (kind) {
    case "fire":
    case "explosion":
      return [0xfff1a8, 0xff9f1c, 0xe63946];
    case "frost":
      return [0xffffff, 0x8ee8ff, 0x3a86ff];
    case "lightning":
      return [0xffffff, 0x69e8ff, 0xffd166];
    case "poison":
      return [0xd9ff70, 0x70e000, 0x5a189a];
    case "ketchup":
      return [0xffd6a5, 0xef233c, 0x8d0801];
    case "peeler":
      return [0xffffff, 0xdff8eb, 0x748cab];
    default:
      return [0xffffff, 0xffd166, 0xf4a261];
  }
}
