/** Shared world-level caps. Producers admit complete casts, never partial attacks. */
export const HOSTILE_PROJECTILE_CAP = 72;
export const HOSTILE_WARNING_CAP = 18;
