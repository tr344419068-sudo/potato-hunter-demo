import Phaser from "phaser";
import { createMonster } from "../entities/factories";
import { ConfigManager, type WaveConfig } from "../managers/ConfigManager";
import { DifficultyManager } from "../managers/DifficultyManager";
import { EventBus } from "../managers/EventBus";
import { getLevelChapter, getSpawnAngle } from "../managers/LevelChapterModel";
import type { GameRuntime, System } from "./SystemTypes";

export class SpawnSystem implements System {
  private spawnTimerMs = 0;
  private readonly difficultyManager = new DifficultyManager();

  update(deltaMs: number, runtime: GameRuntime): void {
    this.spawnTimerMs -= deltaMs;

    const wave = runtime.waveManager.getCurrentWave(runtime.stats.elapsedMs);
    const aliveMonsters = runtime.world.components.monsters.size;
    const difficulty = this.difficultyManager.getState(runtime.stats.elapsedMs);
    const effectiveMaxAlive = wave.maxAlive + difficulty.extraMaxAlive;

    if (this.spawnTimerMs <= 0 && aliveMonsters < effectiveMaxAlive) {
      const count = Math.min(wave.spawnCount, effectiveMaxAlive - aliveMonsters);

      for (let index = 0; index < count; index += 1) {
        const monsterConfig = ConfigManager.getMonster(this.pickMonsterId(wave, runtime.random));
        const spawnPoint = this.getSpawnPoint(runtime, 520, index, count);
        const monsterId = createMonster(runtime.world, monsterConfig, spawnPoint.x, spawnPoint.y);
        this.difficultyManager.applyToMonster(runtime.world, monsterId, runtime.stats.elapsedMs, runtime.random);
      }

      this.spawnTimerMs = wave.spawnIntervalMs * wave.spawnCount / (wave.spawnCount + difficulty.extraSpawnCount) / (runtime.campaign?.spawnMultiplier ?? 1);
    }

    if (!runtime.campaign?.ownBossCadence && runtime.waveManager.shouldSpawnBoss(runtime.stats.elapsedMs)) {
      const bossConfig = ConfigManager.getMonster(wave.monsterId);
      const spawnPoint = this.getSpawnPoint(runtime, 650, 0, 1);
      const bossId = createMonster(runtime.world, bossConfig, spawnPoint.x, spawnPoint.y, true, ConfigManager.boss.assetId);
      this.difficultyManager.applyToMonster(runtime.world, bossId, runtime.stats.elapsedMs);
      EventBus.emit("boss:spawned");
    }
  }

  private pickMonsterId(wave: WaveConfig, random = Math.random): string {
    if (!wave.monsterMix || wave.monsterMix.length === 0) {
      return wave.monsterId;
    }

    const totalWeight = wave.monsterMix.reduce((sum, entry) => sum + entry.weight, 0);
    let roll = random() * totalWeight;
    for (const entry of wave.monsterMix) {
      roll -= entry.weight;
      if (roll <= 0) {
        return entry.monsterId;
      }
    }
    return wave.monsterMix[wave.monsterMix.length - 1].monsterId;
  }

  private getSpawnPoint(runtime: GameRuntime, distance = 520, index = 0, count = 1): { x: number; y: number } {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const chapter = getLevelChapter(runtime.stats.elapsedMs);
    const angle = getSpawnAngle(chapter, index, count, runtime.random?.() ?? Math.random());
    const jitter = runtime.random ? Math.floor(runtime.random() * 161) - 80 : Phaser.Math.Between(-80, 80);
    const radius = distance + jitter;

    return {
      x: (playerTransform?.x ?? 0) + Math.cos(angle) * radius,
      y: (playerTransform?.y ?? 0) + Math.sin(angle) * radius,
    };
  }
}
