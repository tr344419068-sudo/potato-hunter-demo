import type { GameRuntime, System } from "./SystemTypes";
import { EntityPools } from "../managers/EntityPools";
import { isLongSkewer } from "./WeaponPresentationModel";
import { confineDuelActor, getBossDuel } from "./BossDuelArena";
import { getDesertMovementScale } from "./DesertBossEncounter";
import { movePlayerAroundIce } from "./IceTerrain";
import type { EntityId } from "../components/ComponentTypes";
import { CRESCENT_SKILL_ID } from "./CrescentModel";

const beforeMovement = new WeakMap<GameRuntime["world"], Map<EntityId, { x: number; y: number }>>();

export function getMovementSweepOrigins(world: GameRuntime["world"]): ReadonlyMap<EntityId, { x: number; y: number }> | undefined {
  return beforeMovement.get(world);
}

export class MovementSystem implements System {
  update(deltaMs: number, runtime: GameRuntime): void {
    const { world } = runtime;
    const origins = beforeMovement.get(world) ?? new Map();
    origins.clear();
    if (world.components.enemyProjectiles.size > 0) {
      const player = world.components.transforms.get(runtime.playerId);
      if (player) origins.set(runtime.playerId, { x: player.x, y: player.y });
    }
    // Capture targets before movement and knockbacks only while a swept projectile is active.
    for (const shot of world.components.projectiles.values()) {
      if (!isLongSkewer(shot.skillId) && shot.skillId !== CRESCENT_SKILL_ID) continue;
      for (const id of world.components.monsters.keys()) {
        const transform = world.components.transforms.get(id);
        if (transform) origins.set(id, { x: transform.x, y: transform.y });
      }
      break;
    }
    beforeMovement.set(world, origins);
    const duel = getBossDuel(world);
    for (const [entityId, velocity] of runtime.world.components.velocities) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform) {
        continue;
      }

      const monster = runtime.world.components.monsters.get(entityId);
      const movementMs = monster?.controlledMotionRemainingMs === undefined ? deltaMs : Math.min(deltaMs, Math.max(0, monster.controlledMotionRemainingMs));
      const deltaSeconds = movementMs / 1000;
      const hostile = world.components.enemyProjectiles.get(entityId);
      if (hostile) {
        const slide = Math.max(0, Math.min(movementMs, world.components.lifetimes.get(entityId)?.remainingMs ?? movementMs));
        hostile.sweepOrigin = { x: transform.x, y: transform.y, stepFraction: movementMs > 0 ? slide / movementMs : 0 };
        transform.x += velocity.x * slide / 1000;
        transform.y += velocity.y * slide / 1000;
        continue;
      }
      const projectile = runtime.world.components.projectiles.get(entityId);
      if (projectile && (isLongSkewer(projectile.skillId) || projectile.skillId === CRESCENT_SKILL_ID)) {
        const slide = Math.max(0, Math.min(movementMs, runtime.world.components.lifetimes.get(entityId)?.remainingMs ?? movementMs));
        projectile.sweepOrigin = { x: transform.x, y: transform.y, stepFraction: movementMs > 0 ? slide / movementMs : 0 };
        transform.x += velocity.x * slide / 1000;
        transform.y += velocity.y * slide / 1000;
        continue;
      }
      const flight = projectile?.returnFlight;
      if (flight && projectile) {
        if (flight.remainingOutboundMs > 0) {
          const outgoingMs = Math.min(flight.remainingOutboundMs, movementMs);
          transform.x += velocity.x * outgoingMs / 1000;
          transform.y += velocity.y * outgoingMs / 1000;
          flight.remainingOutboundMs -= outgoingMs;
          // Let collision sample the apex with the outgoing hit set this step.
          continue;
        }
        if (movementMs <= 0) continue;
        const hero = runtime.world.components.transforms.get(runtime.playerId);
        if (!hero) { EntityPools.releaseProjectile(runtime.world, entityId); continue; }
        const dx = hero.x - transform.x, dy = hero.y - transform.y;
        const distance = Math.hypot(dx, dy), travel = flight.speed * deltaSeconds;
        if (distance <= Math.max(12, travel)) { EntityPools.releaseProjectile(runtime.world, entityId); continue; }
        if (!flight.returning) {
          projectile.hitEntities.clear();
          flight.returning = true;
        }
        velocity.x = dx / distance * flight.speed;
        velocity.y = dy / distance * flight.speed;
        transform.x += dx / distance * travel;
        transform.y += dy / distance * travel;
        continue;
      }

      const player = world.components.players.get(entityId);
      const scale = player && duel?.stage === "desert" ? getDesertMovementScale(world, transform, player.dashRemainingMs > 0) : 1;
      const dx = velocity.x * deltaSeconds * scale, dy = velocity.y * deltaSeconds * scale;
      if (entityId === runtime.playerId) movePlayerAroundIce(world, transform, dx, dy);
      else { transform.x += dx; transform.y += dy; }
      confineDuelActor(duel, entityId, runtime.playerId, transform);
      if (monster?.controlledMotionRemainingMs !== undefined) {
        monster.controlledMotionRemainingMs = Math.max(0, monster.controlledMotionRemainingMs - movementMs);
        if (monster.controlledMotionRemainingMs <= 0) { velocity.x = 0; velocity.y = 0; }
      }
    }
  }
}
