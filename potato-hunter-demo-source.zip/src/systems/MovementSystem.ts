import type { GameRuntime, System } from "./SystemTypes";

export class MovementSystem implements System {
  update(deltaMs: number, runtime: GameRuntime): void {
    for (const [entityId, velocity] of runtime.world.components.velocities) {
      const transform = runtime.world.components.transforms.get(entityId);
      if (!transform) {
        continue;
      }

      const monster = runtime.world.components.monsters.get(entityId);
      const movementMs = monster?.controlledMotionRemainingMs === undefined ? deltaMs : Math.min(deltaMs, Math.max(0, monster.controlledMotionRemainingMs));
      const deltaSeconds = movementMs / 1000;

      transform.x += velocity.x * deltaSeconds;
      transform.y += velocity.y * deltaSeconds;
      if (monster?.controlledMotionRemainingMs !== undefined) {
        monster.controlledMotionRemainingMs = Math.max(0, monster.controlledMotionRemainingMs - movementMs);
        if (monster.controlledMotionRemainingMs <= 0) { velocity.x = 0; velocity.y = 0; }
      }
    }
  }
}
