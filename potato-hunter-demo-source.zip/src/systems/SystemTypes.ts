import Phaser from "phaser";
import type { EntityId, PlayerComponent } from "../components/ComponentTypes";
import type { SkillConfig } from "../managers/ConfigManager";
import type { SkillChoiceHint, SkillManager } from "../managers/SkillManager";
import type { WaveManager } from "../managers/WaveManager";
import type { World } from "../entities/World";
import type { DesertPattern } from "./DesertBossEncounter";
import type { SnowPattern } from "./SnowBossEncounter";
import type { StageId } from "../progression/CampaignGrowth";

export interface RunStats {
  elapsedMs: number;
  kills: number;
  bossKills: number;
  gold: number;
}

export interface GameRuntime {
  scene: Phaser.Scene;
  world: World;
  playerId: EntityId;
  skillManager: SkillManager;
  waveManager: WaveManager;
  stats: RunStats;
  hostileProtectionAtStepStart?: Pick<PlayerComponent, "dashRemainingMs" | "damageCooldownMs">;
  canShowDesertAttack?(pattern: DesertPattern): boolean;
  canShowSnowAttack?(pattern: SnowPattern): boolean;
  requestSkillChoice(choices: SkillConfig[], hints?: SkillChoiceHint[]): void;
  endRun(outcome?: "victory" | "defeat"): void;
  campaign?: { stage?: StageId; spawnMultiplier: number; ownBossCadence: boolean; finalBossDefeated?: boolean; training?: { maxHp: number; pickupRadius: number } };
  random?: () => number;
  onMonsterDefeated?(entityId: EntityId, isBoss: boolean): void;
  spawnBossNow(): void;
  addDebugTime(milliseconds: number): void;
  clearMonsters(): void;
}

export interface System {
  /** Stable identity for health telemetry; never depend on minified class names. */
  readonly telemetrySource?: string;
  update(deltaMs: number, runtime: GameRuntime): void;
}
