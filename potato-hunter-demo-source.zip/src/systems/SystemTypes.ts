import Phaser from "phaser";
import type { EntityId } from "../components/ComponentTypes";
import type { SkillConfig } from "../managers/ConfigManager";
import type { SkillChoiceHint, SkillManager } from "../managers/SkillManager";
import type { WaveManager } from "../managers/WaveManager";
import type { World } from "../entities/World";

export interface RunStats {
  elapsedMs: number;
  kills: number;
  bossKills: number;
  gold: number;
}

export interface GameRuntime {
  scene: Phaser.Scene;
  world: World;
  playerId: EntityId;
  skillManager: SkillManager;
  waveManager: WaveManager;
  stats: RunStats;
  requestSkillChoice(choices: SkillConfig[], hints?: SkillChoiceHint[]): void;
  endRun(outcome?: "victory" | "defeat"): void;
  campaign?: { spawnMultiplier: number; ownBossCadence: boolean };
  random?: () => number;
  onMonsterDefeated?(entityId: EntityId, isBoss: boolean): void;
  spawnBossNow(): void;
  addDebugTime(milliseconds: number): void;
  clearMonsters(): void;
}

export interface System {
  /** Stable identity for health telemetry; never depend on minified class names. */
  readonly telemetrySource?: string;
  update(deltaMs: number, runtime: GameRuntime): void;
}
