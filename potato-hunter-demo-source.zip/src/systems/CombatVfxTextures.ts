import type Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import { getCombatVfxPalette, type CombatVfxKind } from "./CombatVfxModel";
import type { CombatParticlePhase } from "./CombatParticleEmitter";

export type CombatParticleForm = "ribbon" | "glow" | "debris";
export type CombatTextureMotion = "shrink" | "burst" | "ring" | "smoke";

export interface CombatVfxTexture {
  key: string;
  frameCount: number;
  motion: CombatTextureMotion;
  tint: number;
  opacity: number;
  lifetimeMs: number;
  directional: boolean;
}

const SPELLS: Record<CombatVfxKind, string> = {
  kinetic: "vfx_glow", peeler: "vfx_peeler_spell", fire: "vfx_fire_spell", frost: "vfx_energy_spell",
  lightning: "vfx_lightning_spell", poison: "vfx_energy_spell", explosion: "vfx_energy_spell", ketchup: "vfx_motes",
};
const RIBBONS: Record<CombatVfxKind, string> = {
  kinetic: "vfx_trace", peeler: "vfx_slash", fire: "vfx_flame", frost: "vfx_trace",
  lightning: "vfx_arc", poison: "vfx_trace", explosion: "vfx_trace", ketchup: "vfx_trace",
};
const DEBRIS: Record<CombatVfxKind, string> = {
  kinetic: "vfx_chip", peeler: "vfx_slash", fire: "vfx_flame", frost: "vfx_crystal",
  lightning: "vfx_arc", poison: "vfx_motes", explosion: "vfx_chip", ketchup: "vfx_chip",
};
const SMOKE_TINTS: Partial<Record<CombatVfxKind, number>> = { fire: 0x796455, poison: 0x587846, explosion: 0x796b5e, ketchup: 0x704d43 };
const BURST_DURATION: Record<CombatVfxKind, number> = { kinetic: 230, peeler: 340, fire: 430, frost: 420, lightning: 320, poison: 520, explosion: 460, ketchup: 360 };

export function getCombatVfxTexture(scene: Phaser.Scene, kind: CombatVfxKind, phase: CombatParticlePhase, form: CombatParticleForm, index: number): CombatVfxTexture | undefined {
  if (typeof scene.textures.get !== "function") return undefined;
  const lowPriority = phase === "trail" || phase === "muzzle";
  let assetId = form === "ribbon" ? RIBBONS[kind] : form === "glow" ? "vfx_glow" : DEBRIS[kind];
  let motion: CombatTextureMotion = "shrink";
  if (!lowPriority && index === 0) {
    assetId = SPELLS[kind]; motion = "burst";
  }
  if (!lowPriority && index === 1 && ["frost", "poison", "explosion"].includes(kind)) {
    assetId = "vfx_ring"; motion = "ring";
  }
  if ((!lowPriority && index === 2 && SMOKE_TINTS[kind] !== undefined) || (phase === "aura" && kind === "poison" && index === 0)) {
    assetId = "vfx_smoke_spell"; motion = "smoke";
  }
  if (!AssetManager.hasTexture(scene, assetId)) return undefined;
  const asset = AssetManager.getAsset(assetId);
  const frameCount = asset?.frameCount ?? 1;
  if (!Number.isInteger(frameCount) || frameCount < 1 || frameCount > 8) return undefined;
  const { frameWidth, frameHeight } = asset ?? {};
  const requiresSheet = assetId.endsWith("_spell") || [frameWidth, frameHeight, asset?.frameCount].some(value => value !== undefined);
  if (requiresSheet && (!asset || ![frameWidth, frameHeight, asset.frameCount].every(value => Number.isInteger(value) && Number.isFinite(value) && (value ?? 0) > 0)
    || frameWidth! > asset.width || frameHeight! > asset.height
    || frameCount > Math.floor(asset.width / frameWidth!) * Math.floor(asset.height / frameHeight!))) return undefined;
  const key = AssetManager.getTextureKey(assetId);
  if (frameCount > 1) {
    const texture = scene.textures.get(key);
    if (!texture || typeof texture.has !== "function" || !Array.from({ length: frameCount }, (_, frame) => frame).every(frame => texture.has(String(frame)))) return undefined;
  }
  const [, primary, accent] = getCombatVfxPalette(kind);
  return {
    key, frameCount, motion,
    tint: motion === "smoke" ? SMOKE_TINTS[kind] ?? 0x697060 : index === 0 ? primary : index % 2 ? accent : primary,
    opacity: motion === "smoke" ? 0.38 : motion === "ring" ? 0.6 : motion === "burst" ? 0.94 : 0.92,
    lifetimeMs: motion === "smoke" ? 720 : motion === "ring" ? 350 : BURST_DURATION[kind],
    directional: lowPriority && form === "ribbon" || motion === "burst" && (kind === "peeler" || kind === "fire") || !lowPriority && form === "ribbon" && motion === "shrink",
  };
}
