export type CharacterShadowKind = "hero" | "monster" | "elite" | "boss";

export interface CharacterShadowProfile {
  ambientWidth: number;
  ambientHeight: number;
  ambientAlpha: number;
  contactWidth: number;
  contactHeight: number;
  contactAlpha: number;
  groundOffsetY: number;
}

const ROLE_SCALE: Record<CharacterShadowKind, { ambient: number; contact: number; alpha: number }> = {
  hero: { ambient: 0.68, contact: 0.5, alpha: 1 },
  monster: { ambient: 0.72, contact: 0.46, alpha: 0.92 },
  elite: { ambient: 0.82, contact: 0.52, alpha: 1.08 },
  boss: { ambient: 0.96, contact: 0.62, alpha: 1.18 },
};

export interface CharacterGroundTransform {
  x: number;
  y: number;
  visualSize: number;
  pivot: { x: number; y: number };
  footPoint: { x: number; y: number };
  scaleX: number;
  scaleY: number;
  rotation: number;
}

export function getCharacterGroundPoint(transform: CharacterGroundTransform): { x: number; y: number } {
  const localX = (transform.footPoint.x - transform.pivot.x) * transform.visualSize * transform.scaleX;
  const localY = (transform.footPoint.y - transform.pivot.y) * transform.visualSize * transform.scaleY;
  const cosine = Math.cos(transform.rotation);
  const sine = Math.sin(transform.rotation);
  return {
    x: transform.x + localX * cosine - localY * sine,
    y: transform.y + localX * sine + localY * cosine,
  };
}

export function getCharacterShadowProfile(
  kind: CharacterShadowKind,
  visualSize: number,
  liftRatio: number,
): CharacterShadowProfile {
  const role = ROLE_SCALE[kind];
  const size = Math.max(1, visualSize);
  const lift = Math.max(0, Math.min(1, liftRatio));
  const liftScale = 1 - lift * 0.24;
  const liftAlpha = 1 - lift * 0.46;

  return {
    ambientWidth: size * role.ambient * liftScale,
    ambientHeight: size * 0.2 * liftScale,
    ambientAlpha: Math.min(0.3, 0.17 * role.alpha * liftAlpha),
    contactWidth: size * role.contact * liftScale,
    contactHeight: size * 0.085 * liftScale,
    contactAlpha: Math.min(0.55, 0.4 * role.alpha * liftAlpha),
    groundOffsetY: 0,
  };
}
