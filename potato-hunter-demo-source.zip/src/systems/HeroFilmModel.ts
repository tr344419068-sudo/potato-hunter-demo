import { DASH_DURATION_MS } from "./DashModel";

export const HERO_FILM = {
  idle: { frameMs: [190, 190, 190, 190, 190, 190, 130, 75, 60, 100, 190, 190, 190, 190, 190, 190] },
  walk: { frameMs: Array<number>(17).fill(72) },
  run: { frameMs: Array<number>(16).fill(40) },
  dash: { frameMs: [40, 35, 32, 30, 30, 30, 34, 36, 39, 39, 34, 37, 38, 40, 45], cue: 5, brake: 12 },
  shoot: { frameMs: Array<number>(13).fill(34), cue: 6 },
  slash: { frameMs: [40, 37, 35, 35, 37, 44, 33, 24, 25, 30, 41, 37, 43, 41, 40, 40], cue: 9 },
  hit: { frameMs: [26, 26, 26, 31, 31, 31, 31, 31, 31, 31, 31, 36], cue: 2 },
  down: { frameMs: Array<number>(14).fill(65) },
} as const;

export type HeroFilmAction = keyof typeof HERO_FILM;
type AttackAction = "shoot" | "slash";
export interface HeroFilmAim { sequence: number; action: AttackAction; directionX: number; remainingMs: number; priority?: boolean }
interface MotionInput {
  deltaMs: number; speed: number; facingX: -1 | 1; dashRemainingMs: number; dashDirectionX: number;
  hit: boolean; dead: boolean; windup?: HeroFilmAim; release?: HeroFilmAim;
}
interface MotionPose { action: HeroFilmAction; frame: number; facingX: -1 | 1 }
interface Attack { cue: HeroFilmAim; elapsed: number; released: boolean }

const projectiles = new Set([
  "pepper_gatling", "pepper_overdrive", "corn_burst", "corn_crossfire", "fire_potato", "inferno_pierce",
  "frost_chips", "frost_explosion", "thunder_potato", "thunder_storm", "starch_bomb", "starch_nuke",
  "skewer_javelin", "thunder_skewer",
]);
export function getHeroWeaponAction(id?: string): AttackAction | undefined {
  if (id === "peeler_blade" || id === "peeler_returning" || id === "moon_draw") return "slash";
  return id !== undefined && projectiles.has(id) ? "shoot" : undefined;
}

export const heroFilmAsset = (action: HeroFilmAction): string => `hero_k1_${action}`;
export const K1_FOOT = { x: 128 / 256, y: 205 / 256 };
export const K1_DISPLAY_SCALE = 1.23;
export const K1_DEFEAT_REVEAL_MS = 610;
const duration = (action: HeroFilmAction) => HERO_FILM[action].frameMs.reduce((sum, ms) => sum + ms, 0);
const beginsAt = (action: HeroFilmAction, frame: number) => HERO_FILM[action].frameMs.slice(0, frame).reduce((sum, ms) => sum + ms, 0);
const GAIT = {
  walk: { span: 80, soleCorrection: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -7, -5, -4, -3, -2, 0] },
  run: { span: 112, soleCorrection: [0, 0, -5, -3, 0, 0, -3, -3, 0, 0, -5, -3, 0, 0, -3, -3] },
} as const;
// Corrections are measured from the support boot in the 160px atlas. Airborne cells are left alone.
export function getHeroFilmGroundOffset(action: HeroFilmAction, frame: number): number {
  return action === "walk" || action === "run" ? (GAIT[action].soleCorrection[frame] ?? 0) / 160 : 0;
}
const ATTACK_BEATS = {
  shoot: { contact: beginsAt("shoot", HERO_FILM.shoot.cue), recoil: beginsAt("shoot", 8), motionEnd: beginsAt("shoot", 11), stillContact: 23, stillRecovery: 117, driveContact: 16, driveRecovery: 36 },
  slash: { contact: beginsAt("slash", HERO_FILM.slash.cue), recoil: beginsAt("slash", 10), motionEnd: beginsAt("slash", 13), stillContact: 37, stillRecovery: 172, driveContact: 24, driveRecovery: 54 },
} as const;
export const resolveHeroFilmFacing = (dx: number, fallback: -1 | 1): -1 | 1 => Math.abs(dx) >= .18 ? (dx < 0 ? -1 : 1) : fallback;

/** The crossbow tip in shoot's release cell. Offsets are only used by the projectile drawing path. */
export function getHeroFilmMuzzle(x: number, footY: number, size: number, dx: number, fallbackFacing: -1 | 1) {
  const displaySize = size * K1_DISPLAY_SCALE;
  return { x: x + (K1_FOOT.x - .24) * displaySize * resolveHeroFilmFacing(dx, fallbackFacing), y: footY + (.44 - K1_FOOT.y) * displaySize };
}

function frameAt(action: HeroFilmAction, ms: number): number {
  const frames = HERO_FILM[action].frameMs;
  for (let frame = 0; frame < frames.length - 1; frame += 1) {
    if (ms < frames[frame]) return frame;
    ms -= frames[frame];
  }
  return frames.length - 1;
}

/** Consumes visual cues only: never modifies hitboxes, cooldowns, or the player's position. */
export class HeroFilmMotion {
  private locomotion: "idle" | "walk" | "run" = "idle";
  private phase = 0;
  private lastWindup = 0;
  private lastRelease = 0;
  private attack?: Attack;
  private reactionMs = Infinity;
  private defeatMs = 0;
  private dashRecoveryMs = Infinity;
  private dashFacing: -1 | 1 = 1;
  private pose?: MotionPose;

  update(input: MotionInput): MotionPose {
    const renderMs = Math.max(0, Math.min(250, input.deltaMs));
    const dt = Math.min(100, renderMs);
    if (dt === 0 && this.pose) return this.pose;
    const windup = input.windup && input.windup.sequence > this.lastWindup ? input.windup : undefined;
    const release = input.release && input.release.sequence > this.lastRelease ? input.release : undefined;
    if (windup) this.lastWindup = windup.sequence;
    if (release) this.lastRelease = release.sequence;
    const locomotion = input.speed < 10 ? "idle" : input.speed < (this.locomotion === "run" ? 142 : 156) ? "walk" : "run";
    if (locomotion !== this.locomotion && (locomotion === "idle" || this.locomotion === "idle")) this.phase = 0;
    this.locomotion = locomotion;
    const cycleMs = duration(locomotion);
    // Travel is derived from actual post-collision positions, not from commanded speed.
    // A dash must not move the walk/run phase by several strides before the landing.
    if (input.dashRemainingMs <= 0) {
      this.phase = (this.phase + (locomotion === "idle" ? dt / cycleMs : input.speed * renderMs / (GAIT[locomotion].span * 1000))) % 1;
    }

    if (input.dead) {
      const pose = this.setPose("down", this.defeatMs * 1.7, this.pose?.facingX ?? input.facingX);
      this.defeatMs += dt;
      return pose;
    }
    this.defeatMs = 0;
    if (input.hit) this.reactionMs = 0;
    else this.reactionMs += dt;

    if (input.dashRemainingMs > 0) {
      this.attack = undefined;
      this.dashRecoveryMs = 0;
      this.dashFacing = resolveHeroFilmFacing(input.dashDirectionX, input.facingX);
      const t = Math.max(0, Math.min(1, 1 - input.dashRemainingMs / DASH_DURATION_MS));
      const start = beginsAt("dash", HERO_FILM.dash.cue);
      const stop = beginsAt("dash", HERO_FILM.dash.brake);
      return this.setPose("dash", start + (stop - start - 1) * t + .0001, this.dashFacing);
    }
    this.dashRecoveryMs += dt;
    if (this.reactionMs < 205) {
      this.attack = undefined;
      return this.setPose("hit", 26 + this.reactionMs * 1.65, input.facingX);
    }

    if (release) this.attack = { cue: release, elapsed: 0, released: true };
    else if (windup && (windup.priority || !this.attack?.released)) this.attack = { cue: windup, elapsed: 0, released: false };
    else if (this.attack) this.attack.elapsed += dt;

    const attack = this.attack;
    if (attack) {
      const { action, directionX, remainingMs } = attack.cue;
      const beats = ATTACK_BEATS[action];
      const direction = resolveHeroFilmFacing(directionX, input.facingX);
      const moving = locomotion !== "idle";
      if (attack.released) {
        const contactMs = moving ? beats.driveContact : beats.stillContact;
        const recoveryMs = moving ? beats.driveRecovery : beats.stillRecovery;
        if (attack.elapsed < contactMs) return this.setPose(action, beats.contact, direction);
        const followThrough = (attack.elapsed - contactMs) / recoveryMs;
        if (followThrough < 1) {
          const end = moving ? beats.motionEnd : duration(action);
          return this.setPose(action, beats.recoil + (end - beats.recoil) * followThrough, direction);
        }
      } else if (attack.elapsed < remainingMs + 44) {
        const left = remainingMs - attack.elapsed;
        if (!moving) {
          const progress = Math.min(1, attack.elapsed / Math.max(1, remainingMs));
          // Raise the weapon early, then read the drawn-back pose before the actual release cue.
          return this.setPose(action, Math.min(beats.contact - 1, beats.contact * (1 - (1 - progress) ** 1.45)), direction);
        }
        if (action === "slash" && left <= 34 && left >= 0) {
          const load = beginsAt("slash", 7);
          return this.setPose(action, Math.min(beats.contact - 1, load + (beats.contact - load) * (1 - left / 34)), direction);
        }
        return this.setPose(locomotion, this.phase * cycleMs, input.facingX);
      }
      this.attack = undefined;
    }

    if (locomotion === "idle" && this.dashRecoveryMs < 64) {
      const brake = beginsAt("dash", HERO_FILM.dash.brake);
      return this.setPose("dash", brake + this.dashRecoveryMs * 2, this.dashFacing);
    }
    return this.setPose(locomotion, this.phase * cycleMs, input.facingX);
  }

  private setPose(action: HeroFilmAction, ms: number, facingX: -1 | 1): MotionPose {
    return this.pose = { action, frame: frameAt(action, ms), facingX };
  }
}
