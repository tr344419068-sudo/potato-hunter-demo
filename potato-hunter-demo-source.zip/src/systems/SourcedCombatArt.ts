import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import type { HostileStrike } from "./HostileStrikePresentation";
import type { EnemyProjectileAccent } from "./EnemyProjectileModel";

const FIRE = "vfx_boss_fire_flipbook";
const DUST = "vfx_boss_dust_flipbook";
const IMPACT = "vfx_boss_impact";
const EMBER_RING = "vfx_boss_ember_ring";
const STATIC_RING = "vfx_boss_static_ring";
const MUZZLE = "vfx_boss_muzzle";
const MAX_LAYERS = 40;
const MAX_VOLLEY_LAYERS = 24;

type Image = Phaser.GameObjects.Image;
type Clip = {
  image: Image;
  frames: number;
  size: number;
  opacity: number;
  duration: number;
  grow: number;
  age: number;
  x: number;
  y: number;
  driftX: number;
  driftY: number;
  aspect: number;
};

/** Displays imported bitmap art. The combat clock governs playback and pause. */
export class SourcedCombatArt {
  private readonly active: Clip[] = [];
  private readonly pool: Image[] = [];

  constructor(private readonly scene: Phaser.Scene) {}

  strike({ x, y, radius, safeRadius, style, art }: HostileStrike): void {
    if (art?.kind === "contact") return;
    if (art?.kind === "sweep") {
      this.play("vfx_enemy_sweep", art.x, art.y, art.length * 1.13, 390, .98,
        0xffffff, 1.84, true, art.angle, .08, 0, 0, .48);
      this.play(DUST, art.x, art.y, art.length * .83, 610, .44,
        style === "sand" ? 0xffd098 : 0xffb482, 1.63, false, art.angle, .19, 0, 0, .42);
      return;
    }
    if (style === "bomb") {
      this.play(DUST, x, y, radius * 2.06, 650, .57, 0xe5ad65, 1.65, false, 0, .22, -8);
      this.play(FIRE, x, y, radius * 1.48, 410, .96, 0xffffff, 1.77);
      this.play("vfx_enemy_bomb_debris", x, y, radius * 2.31, 485, 1, 0xffffff, 1.89, false, 0, .17);
      return;
    }
    const sand = style === "sand";
    const metal = style === "slam" || style === "sweep";
    const haze = sand ? 0xffd597 : style === "sauce" ? 0xdf7e74 : 0xaf8b76;
    const light = sand ? 0xc3ffff : style === "sauce" ? 0xff745b : 0xffedbb;
    const width = radius * 2.02;
    if (safeRadius !== undefined) {
      const band = radius - safeRadius;
      // The Ember Ring's authored frames have clear alpha within 30% of the sheet width.
      if (safeRadius < width * .30) {
        this.play(EMBER_RING, x, y, width, 470, .82, light, 1.82, true);
      }
      const size = Math.min(96, band * .60);
      const distance = safeRadius + band * .53;
      for (let i = 0; i < 6; i++) {
        const angle = (i + .15) * Math.PI / 3;
        this.play(i % 2 === 0 ? FIRE : DUST, x + Math.cos(angle) * distance, y + Math.sin(angle) * distance,
          size, i % 2 === 0 ? 550 : 650, i % 2 === 0 ? .88 : .63, i % 2 === 0 ? light : haze, 1.74);
      }
      return;
    }

    this.play(sand ? STATIC_RING : EMBER_RING, x, y, width, sand ? 510 : 490, .82, light, 1.79, !sand);
    this.play(DUST, x, y, radius * 1.76, 730, sand ? .68 : .47, haze, 1.63, false, 0, .15, -12);
    if (!sand) this.play(FIRE, x, y, radius * (metal ? 1.27 : 1.70), 575, metal ? .86 : 1, 0xffffff, 1.74, false, 0, .12);
    this.play(IMPACT, x, y, radius * (metal || sand ? 1.55 : 1.20), 230, .94, light, 1.91, true, style === "sweep" ? -.25 : 0);
  }

  lunge(x: number, y: number, angle: number): void {
    const dx = Math.cos(angle), dy = Math.sin(angle);
    this.play("vfx_enemy_lunge", x + dx * 25, y + dy * 25, 104, 250, .94,
      0xffffff, 1.86, true, angle + Math.PI / 4, .12, dy * 61, dx * 61);
  }

  oilSplash(x: number, y: number, radius: number, evolved: boolean): void {
    this.play(EMBER_RING, x, y, radius * 2.0, 410, .95, 0xffb75b, 1.41, true, 0, .09);
    this.play(FIRE, x, y, radius * (evolved ? 1.65 : 1.35), 490, .96, 0xffffff, 1.58, false, 0, .12, -18);
    this.play(DUST, x, y, radius * 1.59, 560, .38, 0xe5a167, 1.51, false, 0, .20, -18);
  }

  shieldBreak(x: number, y: number, radius: number): void {
    const width = Math.min(126, Math.max(62, radius * 4.6));
    this.play(IMPACT, x, y, width * .64, 180, .62, 0x9ad7ff, 2.45, true);
    this.play("vfx_enemy_shield_break", x, y, width, 420, 1, 0xffffff, 2.45, false, 0, .25);
  }

  volley({ x, y, angles, style }: { x: number; y: number; angles: readonly number[]; style: HostileStrike["style"] }): void {
    if (this.active.length + angles.length > MAX_VOLLEY_LAYERS) return;
    for (const angle of angles) {
      this.play(MUZZLE, x + Math.cos(angle) * 32, y + Math.sin(angle) * 32, 61, 140, .95,
        style === "sand" ? 0x89f2ff : 0xffbd60, 3.6, true, angle, .28);
    }
  }

  enemyShot({ x, y, angle, color, phase }: EnemyProjectileAccent): void {
    if (this.active.length >= MAX_VOLLEY_LAYERS) return;
    if (phase === "muzzle") this.play(MUZZLE, x, y, 37, 128, .85, color, 3.6, false, angle, .22);
    else this.play(IMPACT, x, y, 37, 154, .9, color, 3.8, false, angle, .3);
  }

  playerCritical(x: number, y: number, size: number, angle: number, tint: number): void {
    if (this.active.length >= 14) return; // Keep authored layers available for hostile strikes.
    this.play(IMPACT, x, y, size, 225, .96, tint, 8.2, true, angle, .18);
  }

  update(deltaMs: number): void {
    for (let i = this.active.length - 1; i >= 0; i--) {
      const clip = this.active[i];
      clip.age += deltaMs;
      if (clip.age >= clip.duration) { this.retire(i); continue; }
      const progress = clip.age / clip.duration;
      if (clip.frames > 1) clip.image.setFrame(Math.floor(progress * clip.frames));
      const size = clip.size * (1 + clip.grow * progress);
      const fadeStart = clip.frames > 1 ? .52 : .17;
      const alpha = clip.opacity * (1 - Math.max(0, progress - fadeStart) / (1 - fadeStart));
      clip.image.setPosition(clip.x + clip.driftX * progress, clip.y + clip.driftY * progress).setDisplaySize(size, size * clip.aspect).setAlpha(alpha);
    }
  }

  clear(): void {
    while (this.active.length) this.retire(this.active.length - 1);
  }

  destroy(): void {
    this.clear();
    while (this.pool.length) this.pool.pop()!.destroy();
  }

  private play(id: string, x: number, y: number, size: number, duration: number, opacity: number, tint: number,
    depth: number, add = false, rotation = 0, grow = 0, driftY = 0, driftX = 0, aspect = 1): void {
    if (this.active.length >= MAX_LAYERS || !AssetManager.hasTexture(this.scene, id)) return;
    const key = AssetManager.getTextureKey(id);
    const frames = AssetManager.getAsset(id)?.frameCount ?? 1;
    if (frames > 1) {
      const texture = this.scene.textures.get(key);
      if (!texture?.has(String(frames - 1))) return;
    }
    const frame = frames > 1 ? 0 : undefined;
    const image = this.pool.pop() ?? this.scene.add.image(x, y, key, frame);
    image.setTexture(key, frame).setPosition(x, y).setOrigin(.5).setRotation(rotation)
      .setDisplaySize(size, size * aspect).setDepth(depth).setTint(tint).setAlpha(opacity)
      .setBlendMode(add ? Phaser.BlendModes.ADD : Phaser.BlendModes.NORMAL).setActive(true).setVisible(true);
    this.active.push({ image, frames, size, opacity, duration, grow, age: 0, x, y, driftY, driftX, aspect });
  }

  private retire(index: number): void {
    const [clip] = this.active.splice(index, 1);
    clip.image.setActive(false).setVisible(false);
    this.pool.push(clip.image);
  }
}
