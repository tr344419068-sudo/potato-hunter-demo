import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import type { HostileStrike } from "./HostileStrikePresentation";
import type { EnemyProjectileAccent } from "./EnemyProjectileModel";
import type { CombatVfxKind } from "./CombatVfxModel";

const FIRE = "vfx_boss_fire_flipbook";
const DUST = "vfx_boss_dust_flipbook";
const IMPACT = "vfx_boss_impact";
const EMBER_RING = "vfx_boss_ember_ring";
const STATIC_RING = "vfx_boss_static_ring";
const MUZZLE = "vfx_boss_muzzle";
const CHARGE = "vfx_duel_charge";
const VORTEX = "vfx_duel_vortex";
const WAVE = "vfx_duel_wave";
const HARD_HIT = "vfx_duel_hard_hit";
const FIRE_WRATH = "vfx_duel_fire_wrath";
const ENERGY_SHOT = "vfx_duel_energy_shot";
const MAX_LAYERS = 40;
const MAX_VOLLEY_LAYERS = 24;

type Image = Phaser.GameObjects.Image;
export type PlayerShotArt = "pepper" | "overdrive" | "skewer" | "thunder" | "blade";
const SHOT_TINT: Record<PlayerShotArt, number> = {
  pepper: 0xffd48a, overdrive: 0xff9251, skewer: 0xffefac, thunder: 0xb8e9ff, blade: 0xffe2a0,
};
export interface DuelRushArt { x: number; y: number; angle: number; distance: number; duration: number; phase: number; desert?: boolean }
export interface DuelTellArt { duel?: boolean; x?: number; y?: number; phase: number; pattern: string; windupMs: number; desert?: boolean }
type Clip = {
  image: Image;
  frames: number;
  firstFrame: number;
  size: number;
  opacity: number;
  duration: number;
  grow: number;
  age: number;
  x: number;
  y: number;
  driftX: number;
  driftY: number;
  aspect: number;
};

/** Displays imported bitmap art. The combat clock governs playback and pause. */
export class SourcedCombatArt {
  private readonly active: Clip[] = [];
  private readonly pool: Image[] = [];
  private readonly playerCadence = new Map<string, number>();
  private presentationMs = 0;

  constructor(private readonly scene: Phaser.Scene) {}

  strike({ x, y, radius, safeRadius, style, art, bossPhase, bossFinisher }: HostileStrike, reduced = false): void {
    if (art?.kind === "contact") return;
    if (style === "lightning") {
      const power = bossPhase === 3 ? 1.40 : bossPhase === 2 ? 1.19 : 1;
      this.play("vfx_lightning_spell", x, y - radius * .84, radius * 1.38 * power, 420, .98, 0xb8dcff, 2.15, true, 0, .09, 0, 0, 1.58);
      this.play(STATIC_RING, x, y, radius * 2.02, 510, .92, 0xa6e1ff, 1.80, true);
      this.play(IMPACT, x, y, radius * .81, 240, .84, 0xa0cbff, 1.91, true);
      if (bossPhase && bossPhase >= 2) this.play(WAVE, x, y, radius * 1.98, 460, .88, 0xd2edff, 1.95, true, Math.PI / 2, .16, -14, 0, .74);
      return;
    }
    if (style === "shockwave" && safeRadius !== undefined) {
      this.play(STATIC_RING, x, y, radius * 2, 535, .90, 0xeb9cff, 1.83, true, 0, .03);
      if (bossPhase === 3) {
        // Energy rides the dangerous band; there is no flash inside the safe core.
        for (let index = 0; index < 8; index++) {
          const angle = (index / 8 + .0625) * Math.PI * 2;
          const dx = Math.cos(angle), dy = Math.sin(angle), ringDistance = radius * .73;
          const wave = index % 2 === 0;
          this.play(wave ? WAVE : VORTEX, x + dx * ringDistance, y + dy * ringDistance,
            radius * (wave ? .62 : .48), wave ? 730 : 590, wave ? .98 : .89,
            wave ? 0xc0caff : 0xfb9cff, wave ? 1.92 : 1.90, true, angle + Math.PI / 2,
            .19, dy * radius * .13, dx * radius * .13, .65);
        }
      } else this.play("vfx_energy_spell", x, y, radius * 1.74, 500, .67, 0xc08afa, 1.71, true, .33, .14);
      return;
    }
    if (art?.kind === "sweep") {
      this.play("vfx_enemy_sweep", art.x, art.y, art.length * 1.13, 390, reduced ? .68 : .98,
        style === "sand" ? 0xffd18a : 0xffffff, 1.84, !reduced, art.angle, .08, 0, 0, .48);
      if (!reduced) this.play(DUST, art.x, art.y, art.length * .83, 610, .44,
        style === "sand" ? 0xffd098 : 0xffb482, 1.63, false, art.angle, .19, 0, 0, .42);
      if (!reduced && bossPhase) {
        const late = bossPhase === 3;
        const dx = Math.cos(art.angle), dy = Math.sin(art.angle);
        this.play("vfx_boss_strike_sparks", art.x + dx * art.length * .28, art.y + dy * art.length * .28,
          Math.min(230, radius * (late ? 2.38 : 1.94)), 365, .89, 0xffffff, 2.08, true, art.angle, .28);
        this.play(HARD_HIT, art.x + dx * art.length * .20, art.y + dy * art.length * .20,
          Math.min(185, radius * (late ? 1.88 : 1.3)), late ? 450 : 330, .96, style === "sand" ? 0xffdfa6 : 0xffc98a, 1.98, true, art.angle, .22);
        if (late) this.play(WAVE, art.x, art.y, art.length * .87, 475, .84, style === "sand" ? 0xffe0a5 : 0xffa9f4, 1.94, true, art.angle, .12, 0, 0, .33);
      }
      return;
    }
    if (style === "bomb") {
      this.play(DUST, x, y, radius * 2.06, 650, .57, 0xe5ad65, 1.65, false, 0, .22, -8);
      this.play(FIRE, x, y, radius * 1.48, 410, .96, 0xffffff, 1.77);
      this.play("vfx_enemy_bomb_debris", x, y, radius * 2.31, 485, 1, 0xffffff, 1.89, false, 0, .17);
      return;
    }
    const sand = style === "sand";
    const metal = style === "slam" || style === "sweep";
    const haze = sand ? 0xffd597 : style === "sauce" ? 0xdf7e74 : 0xaf8b76;
    const light = sand ? 0xc3ffff : style === "sauce" ? 0xff745b : 0xffedbb;
    const width = radius * 2.02;
    if (sand && bossFinisher) {
      this.play(DUST, x, y, width, 760, .83, 0xffda83, 1.63, false, 0, .24);
      this.play(VORTEX, x, y, width * .79, 670, .92, 0xffdbad, 1.80, true, .18, .22);
      this.play(FIRE_WRATH, x, y, width, 620, .93, 0xffd99c, 1.85, false, -.4, .12);
      this.play(HARD_HIT, x, y, radius, 310, .96, 0xffefaa, 1.97, true);
      for (let index = 0; index < 4; index++) {
        const angle = (.125 + index * .25) * Math.PI * 2, dx = Math.cos(angle), dy = Math.sin(angle);
        this.play(DUST, x + dx * radius * .66, y + dy * radius * .66, radius * .76, 600, .77, 0xffd27b, 1.71, false, angle, .2, dy * 28, dx * 28);
      }
      return;
    }
    if (safeRadius !== undefined) {
      const band = radius - safeRadius;
      // The Ember Ring's authored frames have clear alpha within 30% of the sheet width.
      if (safeRadius < width * .30) {
        this.play(EMBER_RING, x, y, width, 470, .82, light, 1.82, true);
      }
      const size = Math.min(96, band * .60);
      const distance = safeRadius + band * .53;
      for (let i = 0; i < 6; i++) {
        const angle = (i + .15) * Math.PI / 3;
        this.play(i % 2 === 0 ? FIRE : DUST, x + Math.cos(angle) * distance, y + Math.sin(angle) * distance,
          size, i % 2 === 0 ? 550 : 650, i % 2 === 0 ? .88 : .63, i % 2 === 0 ? light : haze, 1.74);
      }
      return;
    }

    this.play(sand ? STATIC_RING : EMBER_RING, x, y, width, sand ? 510 : 490, .82, light, 1.79, !sand);
    this.play(DUST, x, y, radius * 1.76, 730, sand ? .68 : .47, haze, 1.63, false, 0, .15, -12);
    if (!sand) this.play(FIRE, x, y, radius * (metal ? 1.27 : 1.70), 575, metal ? .86 : 1, 0xffffff, 1.74, false, 0, .12);
    this.play(IMPACT, x, y, radius * (metal || sand ? 1.55 : 1.20), 230, .94, light, 1.91, true, style === "sweep" ? -.25 : 0);
  }

  bossTell({ duel, x, y, phase, pattern, windupMs, desert }: DuelTellArt): void {
    if (!duel || x === undefined || y === undefined || (pattern !== "sesame_fan" && pattern !== "sauce_ring" && pattern !== "spatula_sweep")) return;
    const finisher = pattern === "sauce_ring";
    this.play(CHARGE, x, y, finisher ? 230 : 113 + phase * 13, Math.min(windupMs, 770), .91,
      desert ? 0xffca7a : finisher ? 0xf7a3ff : 0xffd5aa, 1.24, true, 0, finisher ? .24 : .14);
  }

  bossRush({ x, y, angle, distance, duration, phase, desert }: DuelRushArt): void {
    const dx = Math.cos(angle), dy = Math.sin(angle), tint = desert ? 0xffdaa2 : 0xffba79;
    this.play("vfx_boss_rush_streaks", x + dx * distance * .20, y + dy * distance * .20,
      Math.max(92, distance * .70), duration, .83, 0xffffff, 1.70, true, angle, .18,
      dy * distance * .70, dx * distance * .70, .44);
    this.play(ENERGY_SHOT, x, y, 176 + phase * 24, duration, .99, tint, 1.82, true, angle, .25,
      dy * distance, dx * distance, .64);
    this.play(DUST, x, y, 155, duration + 310, .70, tint, 1.58, false, angle, .21, dy * distance * .62, dx * distance * .62, .6);
  }

  lunge(x: number, y: number, angle: number): void {
    const dx = Math.cos(angle), dy = Math.sin(angle);
    this.play("vfx_enemy_lunge", x + dx * 25, y + dy * 25, 104, 250, .94,
      0xffffff, 1.86, true, angle + Math.PI / 4, .12, dy * 61, dx * 61);
  }

  oilSplash(x: number, y: number, radius: number, evolved: boolean): void {
    this.play(EMBER_RING, x, y, radius * 2.0, 410, .95, 0xffb75b, 1.41, true, 0, .09);
    this.play(FIRE, x, y, radius * (evolved ? 1.65 : 1.35), 490, .96, 0xffffff, 1.58, false, 0, .12, -18);
    this.play(DUST, x, y, radius * 1.59, 560, .38, 0xe5a167, 1.51, false, 0, .20, -18);
    this.play(FIRE_WRATH, x, y, radius * (evolved ? 2.21 : 1.68), evolved ? 630 : 410, .90, 0xffffff, 1.53, false, 0, .23);
  }

  shieldBreak(x: number, y: number, radius: number): void {
    const width = Math.min(126, Math.max(62, radius * 4.6));
    this.play(IMPACT, x, y, width * .64, 180, .62, 0x9ad7ff, 2.45, true);
    this.play("vfx_enemy_shield_break", x, y, width, 420, 1, 0xffffff, 2.45, false, 0, .25);
  }

  volley({ x, y, angles, style, bossPhase }: { x: number; y: number; angles: readonly number[]; style: HostileStrike["style"]; bossPhase?: number }): void {
    if (this.active.length + angles.length > MAX_VOLLEY_LAYERS) return;
    for (const [index, angle] of angles.entries()) {
      this.play(MUZZLE, x + Math.cos(angle) * 32, y + Math.sin(angle) * 32, bossPhase ? 61 + bossPhase * 12 : 61, 140, .95,
        style === "sand" ? 0x89f2ff : 0xffbd60, 3.6, true, angle, .28);
      if (bossPhase === 3 && index % 2 === 0) this.play(ENERGY_SHOT, x + Math.cos(angle) * 31, y + Math.sin(angle) * 31,
        116, 235, .93, style === "sand" ? 0x8beeff : 0xffae5e, 3.4, true, angle, .20, Math.sin(angle) * 75, Math.cos(angle) * 75, .63);
    }
  }

  enemyShot({ x, y, angle, color, phase }: EnemyProjectileAccent): void {
    if (this.active.length >= MAX_VOLLEY_LAYERS) return;
    if (phase === "muzzle") this.play(MUZZLE, x, y, 37, 128, .85, color, 3.6, false, angle, .22);
    else this.play(IMPACT, x, y, 37, 154, .9, color, 3.8, false, angle, .3);
  }

  playerCritical(x: number, y: number, size: number, angle: number, tint: number): void {
    if (this.active.length >= 14) return; // Keep authored layers available for hostile strikes.
    this.play(AssetManager.hasTexture(this.scene, HARD_HIT) ? HARD_HIT : IMPACT, x, y, Math.max(50, size * 1.27), 270, .96, tint, 8.2, true, angle, .18);
  }

  playerCrescentContact(x: number, y: number, angle: number, color: number, critical: boolean, shield: boolean): void {
    if (!this.admitShot(`crescent:${shield ? "shield" : critical ? "crit" : "body"}`, 42)) return;
    this.play(IMPACT, x, y, critical ? 45 : 34, 142, .94, shield ? 0xbdedff : color, 7.1,
      true, angle, .15, 0, 0, .86, { firstFrame: 1 });
  }

  /** A dry, short release; the flight sprite continues the motion after this clip retires. */
  playerShotMuzzle(style: PlayerShotArt, x: number, y: number, angle: number, close: boolean): boolean {
    const spear = style === "skewer" || style === "thunder";
    const evolved = style === "overdrive" || style === "thunder";
    const asset = style === "blade" ? "vfx_peeler_spell" : spear && !close ? ENERGY_SHOT : MUZZLE;
    if (!AssetManager.hasTexture(this.scene, asset)) return false;
    if (!this.admitShot(`muzzle:${style}`, evolved ? 57 : 72)) return true;
    const size = close ? 32 : style === "blade" ? 63 : spear ? (evolved ? 94 : 75) : evolved ? 71 : 60;
    const drift = !close && spear ? (evolved ? 29 : 19) : 0;
    const shown = this.play(asset, x, y, size, close ? 78 : style === "blade" ? 152 : spear ? 132 : 108,
      .99, SHOT_TINT[style], 6.4, true, angle, -0.18, Math.sin(angle) * drift, Math.cos(angle) * drift,
      spear && !close ? .48 : style === "blade" ? .82 : .72,
      // The imported burst is painted off-center, with its plume extending right.
      asset === MUZZLE ? { originX: .33 } : undefined);
    if (shown && evolved && !close && this.active.length < 12) {
      this.play("vfx_glow", x, y, spear ? 48 : 51, 83, .56, SHOT_TINT[style], 6.3, true, angle, .20);
    }
    return shown;
  }

  playerShotContact(style: PlayerShotArt, x: number, y: number, radius: number, angle: number, critical: boolean, shield: boolean): boolean {
    if (!AssetManager.hasTexture(this.scene, IMPACT)) return false;
    const spear = style === "skewer" || style === "thunder";
    const evolved = style === "overdrive" || style === "thunder";
    if (!this.admitShot(`contact:${style}:${shield ? 'shield' : critical ? 'crit' : 'body'}`, critical ? 76 : 48)) return true;
    const size = Math.min(76, Math.max(evolved ? 57 : spear || style === "blade" ? 49 : 47, radius * 2.35) * (critical ? 1.22 : 1));
    const tint = shield ? 0x96e0ff : SHOT_TINT[style];
    const shown = this.play(IMPACT, x, y, size, shield ? 169 : critical ? 191 : 137, .98, tint, 7.1,
      true, angle, .27, 0, 0, spear && !shield ? .69 : .92, { firstFrame: 1 });
    if (shown && !shield && (critical || evolved) && this.active.length < 12) {
      this.play(HARD_HIT, x, y, size * 1.34, critical ? 215 : 168, critical ? .94 : .66, tint, 7, true, angle, .22);
    }
    return shown;
  }

  private admitShot(key: string, interval: number): boolean {
    // Shot art cannot consume all the layers reserved for telegraphs and break effects.
    if (this.active.length >= 12 || this.presentationMs - (this.playerCadence.get(key) ?? -Infinity) < interval) return false;
    this.playerCadence.set(key, this.presentationMs);
    return true;
  }

  playerSignature(x: number, y: number, radius: number, angle: number, tint: number, kind: CombatVfxKind, signature: boolean): void {
    if (this.active.length >= 14) return;
    const key = `player:${kind}`;
    if (this.presentationMs - (this.playerCadence.get(key) ?? -Infinity) < (signature ? 130 : 220)) return;
    this.playerCadence.set(key, this.presentationMs);
    const id = kind === "fire" || kind === "explosion" ? FIRE_WRATH : kind === "lightning" ? WAVE
      : kind === "frost" ? STATIC_RING : kind === "poison" || kind === "ketchup" ? EMBER_RING : ENERGY_SHOT;
    const width = Math.min(signature ? 205 : 105, Math.max(signature ? 105 : 46, radius * (signature ? 3.1 : 2.1)));
    this.play(id, x, y, width, signature ? 465 : 235, signature ? .92 : .70, tint, 2.33, true, angle, signature ? .24 : .12);
    if (signature) this.play(HARD_HIT, x, y, width * .66, 280, .90, tint, 2.45, true, angle, .22);
  }

  update(deltaMs: number): void {
    this.presentationMs += deltaMs;
    for (let i = this.active.length - 1; i >= 0; i--) {
      const clip = this.active[i];
      clip.age += deltaMs;
      if (clip.age >= clip.duration) { this.retire(i); continue; }
      const progress = clip.age / clip.duration;
      if (clip.frames > 1) clip.image.setFrame(clip.firstFrame + Math.floor(progress * (clip.frames - clip.firstFrame)));
      const size = clip.size * (1 + clip.grow * progress);
      const fadeStart = clip.frames > 1 ? .52 : .17;
      const alpha = clip.opacity * (1 - Math.max(0, progress - fadeStart) / (1 - fadeStart));
      clip.image.setPosition(clip.x + clip.driftX * progress, clip.y + clip.driftY * progress).setDisplaySize(size, size * clip.aspect).setAlpha(alpha);
    }
  }

  clear(): void {
    while (this.active.length) this.retire(this.active.length - 1);
    this.playerCadence.clear();
  }

  destroy(): void {
    this.clear();
    while (this.pool.length) this.pool.pop()!.destroy();
  }

  private play(id: string, x: number, y: number, size: number, duration: number, opacity: number, tint: number,
    depth: number, add = false, rotation = 0, grow = 0, driftY = 0, driftX = 0, aspect = 1,
    { originX = .5, firstFrame = 0 }: { originX?: number; firstFrame?: number } = {}): boolean {
    if (this.active.length >= MAX_LAYERS || !AssetManager.hasTexture(this.scene, id)) return false;
    const key = AssetManager.getTextureKey(id);
    const frames = AssetManager.getAsset(id)?.frameCount ?? 1;
    if (frames > 1) {
      const texture = this.scene.textures.get(key);
      if (!texture?.has(String(frames - 1))) return false;
    }
    const start = Math.min(firstFrame, frames - 1);
    const frame = frames > 1 ? start : undefined;
    const image = this.pool.pop() ?? this.scene.add.image(x, y, key, frame);
    image.setTexture(key, frame).setPosition(x, y).setOrigin(originX, .5).setRotation(rotation)
      .setDisplaySize(size, size * aspect).setDepth(depth).setTint(tint).setAlpha(opacity)
      .setBlendMode(add ? Phaser.BlendModes.ADD : Phaser.BlendModes.NORMAL).setActive(true).setVisible(true);
    this.active.push({ image, frames, firstFrame: start, size, opacity, duration, grow, age: 0, x, y, driftY, driftX, aspect });
    return true;
  }

  private retire(index: number): void {
    const [clip] = this.active.splice(index, 1);
    clip.image.setActive(false).setVisible(false);
    this.pool.push(clip.image);
  }
}
