import type { EntityId, MonsterComponent } from "../components/ComponentTypes";
import { createAoeWarning, createEnemyProjectile } from "../entities/factories";
import { distanceSquared, normalize } from "../utils/math";
import type { GameRuntime, System } from "./SystemTypes";
import { HOSTILE_PROJECTILE_CAP as MAX_ENEMY_PROJECTILES, HOSTILE_WARNING_CAP as MAX_AOE_WARNINGS } from "./HostileHazardBudget";
import { emitEnemyMuzzle } from "./EnemyProjectileModel";

type NewEnemyRole = "hexer" | "scatter" | "sniper" | "jumper";
type CastStage = "windup" | "flight" | "recovery";

interface RoleCast {
  role: NewEnemyRole;
  stage: CastStage;
  remainingMs: number;
  warningId: EntityId;
  startX: number;
  startY: number;
  targetX: number;
  targetY: number;
  directionX: number;
  directionY: number;
}

const CAST_RANGES: Record<NewEnemyRole, number> = { hexer: 420, scatter: 380, sniper: 560, jumper: 240 };
const CAST_COOLDOWNS: Record<NewEnemyRole, number> = { hexer: 3400, scatter: 3000, sniper: 3400, jumper: 3200 };
const MAX_ROLE_CASTS = 4;
const MAX_CASTS_PER_UPDATE = 4;
const JUMP_DURATION_MS = 400;

export function isNewEnemyRole(behavior: MonsterComponent["behavior"]): behavior is NewEnemyRole {
  return behavior === "hexer" || behavior === "scatter" || behavior === "sniper" || behavior === "jumper";
}

export class NewEnemyRoleSystem implements System {
  private readonly casts = new Map<EntityId, RoleCast>();

  update(deltaMs: number, runtime: GameRuntime): void {
    const elapsedMs = Math.max(0, deltaMs);
    for (const [entityId, cast] of this.casts) {
      const monster = runtime.world.components.monsters.get(entityId);
      if (!monster || monster.isBoss || monster.behavior !== cast.role || !runtime.world.components.transforms.has(entityId) || !runtime.world.components.velocities.has(entityId) || (runtime.world.components.health.get(entityId)?.current ?? 0) <= 0) {
        this.cancelCast(runtime, entityId, cast);
      }
    }

    const player = runtime.world.components.transforms.get(runtime.playerId);
    if (!player || (runtime.world.components.health.get(runtime.playerId)?.current ?? 0) <= 0) {
      for (const [entityId, cast] of this.casts) this.cancelCast(runtime, entityId, cast);
      return;
    }

    let castsStarted = 0;
    for (const [entityId, monster] of runtime.world.components.monsters) {
      if (!isNewEnemyRole(monster.behavior) || monster.isBoss || (runtime.world.components.health.get(entityId)?.current ?? 0) <= 0) continue;
      const transform = runtime.world.components.transforms.get(entityId);
      const velocity = runtime.world.components.velocities.get(entityId);
      if (!transform || !velocity) continue;

      const cast = this.casts.get(entityId);
      if (cast) {
        this.updateCast(elapsedMs, runtime, entityId, cast);
        continue;
      }

      monster.behaviorTimerMs = Math.max(0, monster.behaviorTimerMs - elapsedMs);
      if (monster.behaviorTimerMs > 0 || castsStarted >= MAX_CASTS_PER_UPDATE || distanceSquared(transform.x, transform.y, player.x, player.y) > CAST_RANGES[monster.behavior] ** 2) continue;
      if (monster.behavior === "scatter") {
        if (runtime.world.components.enemyProjectiles.size + 3 > MAX_ENEMY_PROJECTILES) continue;
        const direction = Math.atan2(player.y - transform.y, player.x - transform.x);
        const style = monster.monsterId === "desert_cactus" ? "cactus" : "ember";
        for (const angleOffset of [-0.28, 0, 0.28]) {
          const angle = direction + angleOffset;
          createEnemyProjectile(runtime.world, transform.x, transform.y, Math.cos(angle) * 180, Math.sin(angle) * 180, monster.damage, 2400, style);
        }
        emitEnemyMuzzle(transform.x, transform.y, direction, style);
        monster.behaviorTimerMs = CAST_COOLDOWNS.scatter;
        castsStarted += 1;
        continue;
      }

      const armedZones = [...runtime.world.components.aoeWarnings.values()].filter(warning => warning.zone && warning.sourceId !== undefined && !this.casts.has(warning.sourceId) && runtime.world.components.monsters.get(warning.sourceId)?.behavior === monster.behavior).length;
      const roleCasts = [...this.casts.values()].filter(active => active.role === monster.behavior).length + armedZones;
      if (roleCasts >= MAX_ROLE_CASTS || runtime.world.components.aoeWarnings.size >= MAX_AOE_WARNINGS) continue;
      this.beginCast(runtime, entityId, monster.behavior, player.x, player.y);
      castsStarted += 1;
    }
  }

  private beginCast(runtime: GameRuntime, entityId: EntityId, role: Exclude<NewEnemyRole, "scatter">, targetX: number, targetY: number): void {
    const transform = runtime.world.components.transforms.get(entityId)!;
    const monster = runtime.world.components.monsters.get(entityId)!;
    const velocity = runtime.world.components.velocities.get(entityId)!;
    const direction = normalize(targetX - transform.x, targetY - transform.y);
    const delayMs = role === "jumper" ? 900 : 1000;
    const damage = role === "sniper" ? 0 : role === "hexer" ? Math.max(1, Math.round(monster.damage * 0.6)) : monster.damage;
    const warningId = createAoeWarning(runtime.world, role === "sniper" ? transform.x : targetX, role === "sniper" ? transform.y : targetY, role === "sniper" ? 16 : 62, damage, delayMs);
    const warning = runtime.world.components.aoeWarnings.get(warningId)!;
    Object.assign(warning, { sourceId: entityId, armed: false, skipNextTick: true, label: role === "hexer" ? "毒菇毒域 · 离开毒圈" : role === "sniper" ? "豌豆狙击 · 横移避开弹道" : "甜甜圈跃击 · 离开落点" });
    if (role === "hexer") {
      warning.color = 0x9b5de5;
      warning.zone = { remainingMs: 2400, tickIntervalMs: 750, tickRemainingMs: 750, tickDamage: Math.max(1, Math.round(monster.damage * 0.2)), ticksRemaining: 3, color: 0x57cc99 };
    }
    if (role === "sniper") {
      const contactPadding = 7 + (runtime.world.components.transforms.get(runtime.playerId)?.radius ?? 0);
      Object.assign(warning, { shape: "rectangle", angle: Math.atan2(direction.y, direction.x), length: 660, width: contactPadding * 2, contactPadding });
    }
    this.casts.set(entityId, { role, stage: "windup", remainingMs: delayMs, warningId, startX: transform.x, startY: transform.y, targetX, targetY, directionX: direction.x, directionY: direction.y });
    monster.controlledMotion = true;
    if (role === "jumper") monster.jumpProgress = undefined;
    velocity.x = 0;
    velocity.y = 0;
  }

  private updateCast(deltaMs: number, runtime: GameRuntime, entityId: EntityId, cast: RoleCast): void {
    const velocity = runtime.world.components.velocities.get(entityId)!;
    velocity.x = 0;
    velocity.y = 0;
    if (cast.stage !== "recovery" && !runtime.world.components.aoeWarnings.has(cast.warningId)) {
      this.cancelCast(runtime, entityId, cast);
      return;
    }

    cast.remainingMs = Math.max(0, cast.remainingMs - deltaMs);
    if (cast.stage === "flight") {
      const transform = runtime.world.components.transforms.get(entityId)!;
      const progress = 1 - cast.remainingMs / JUMP_DURATION_MS;
      runtime.world.components.monsters.get(entityId)!.jumpProgress = progress;
      transform.x = cast.startX + (cast.targetX - cast.startX) * progress;
      transform.y = cast.startY + (cast.targetY - cast.startY) * progress;
    }
    if (cast.remainingMs > 0) return;

    if (cast.stage === "recovery") {
      this.finishCast(runtime, entityId, cast.role);
    } else if (cast.stage === "flight") {
      runtime.world.components.monsters.get(entityId)!.jumpProgress = undefined;
      this.armWarning(runtime, cast.warningId);
      cast.stage = "recovery";
      cast.remainingMs = 700;
    } else if (cast.role === "jumper") {
      cast.stage = "flight";
      cast.remainingMs = JUMP_DURATION_MS;
      runtime.world.components.monsters.get(entityId)!.jumpProgress = 0;
    } else if (cast.role === "hexer") {
      this.armWarning(runtime, cast.warningId);
      this.finishCast(runtime, entityId, cast.role);
    } else {
      runtime.world.destroyEntity(cast.warningId);
      if (runtime.world.components.enemyProjectiles.size < MAX_ENEMY_PROJECTILES) {
        const transform = runtime.world.components.transforms.get(entityId)!;
        const damage = runtime.world.components.monsters.get(entityId)!.damage;
        const angle = Math.atan2(cast.directionY, cast.directionX);
        createEnemyProjectile(runtime.world, transform.x, transform.y, Math.cos(angle) * 300, Math.sin(angle) * 300, damage, 2200, "sniper");
        emitEnemyMuzzle(transform.x, transform.y, angle, "sniper");
      }
      this.finishCast(runtime, entityId, cast.role);
    }
  }

  private armWarning(runtime: GameRuntime, warningId: EntityId): void {
    const warning = runtime.world.components.aoeWarnings.get(warningId);
    if (warning) { warning.armed = true; warning.remainingMs = 0; warning.skipNextTick = false; }
  }

  private finishCast(runtime: GameRuntime, entityId: EntityId, role: NewEnemyRole): void {
    this.casts.delete(entityId);
    const monster = runtime.world.components.monsters.get(entityId);
    if (monster) {
      monster.controlledMotion = false;
      monster.controlledMotionRemainingMs = undefined;
      monster.jumpProgress = undefined;
      monster.behaviorTimerMs = CAST_COOLDOWNS[role];
    }
  }

  private cancelCast(runtime: GameRuntime, entityId: EntityId, cast: RoleCast): void {
    runtime.world.destroyEntity(cast.warningId);
    this.finishCast(runtime, entityId, cast.role);
    const velocity = runtime.world.components.velocities.get(entityId);
    if (velocity) { velocity.x = 0; velocity.y = 0; }
  }
}
