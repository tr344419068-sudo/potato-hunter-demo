export type HostileDamageKind = "contact" | "projectile" | "explosion" | "aoe";

const HIT_GRACE_MS: Readonly<Record<HostileDamageKind, number>> = {
  contact: 900,
  projectile: 520,
  explosion: 700,
  aoe: 700,
};

export function canReceiveHostileDamage(state: { dashRemainingMs: number; damageCooldownMs: number }): boolean {
  return state.dashRemainingMs <= 0 && state.damageCooldownMs <= 0;
}

export function getHostileHitGraceMs(kind: HostileDamageKind): number {
  return HIT_GRACE_MS[kind];
}
