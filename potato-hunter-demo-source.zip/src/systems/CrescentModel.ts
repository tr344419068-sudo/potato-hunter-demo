import { sweepTime } from "../utils/math";

export const CRESCENT_SKILL_ID = "moon_draw";
export const CRESCENT_WINDUP_MS = 190;
export const CRESCENT_FRAMES = 12;

const widths = [94, 111, 128, 147, 170, 176, 182, 187, 192, 197, 201, 205];
const palettes = [
  { color: 0x79ddff, label: "冰蓝", asset: "vfx_moon_draw_blue" },
  { color: 0xc482ff, label: "雷紫", asset: "vfx_moon_draw_violet" },
  { color: 0xffd168, label: "曜金", asset: "vfx_moon_draw_gold" },
] as const;

export function getCrescentRank(rank: number) {
  const index = Math.max(0, Math.min(widths.length - 1, rank - 1));
  const palette = index >= 4 ? 2 : index >= 2 ? 1 : 0;
  return { ...palettes[palette], width: widths[index], count: palette + 1 };
}

export function getCrescentFrame(remainingMs: number, lifetimeMs: number): number {
  return Math.max(0, Math.min(CRESCENT_FRAMES - 1, Math.floor((1 - remainingMs / lifetimeMs) * CRESCENT_FRAMES)));
}

export const getCrescentDepth = (width: number): number => width * .67;

type Point = { x: number; y: number };

/** A wide travelling edge, not a large circular bullet. Sweep in the target's moving frame. */
export function sweepCrescent(from: Point, to: Point, target: Point, velocity: Point, width: number, targetRadius: number): number | undefined {
  const speed = Math.hypot(velocity.x, velocity.y) || 1;
  const x = velocity.x / speed, y = velocity.y / speed;
  const depth = getCrescentDepth(width) * .34 + targetRadius;
  const span = width * .45 + targetRadius;
  const local = (p: Point) => {
    const dx = p.x - target.x, dy = p.y - target.y;
    return { x: (dx * x + dy * y) / depth, y: (-dx * y + dy * x) / span };
  };
  return sweepTime(local(from), local(to), { x: 0, y: 0 }, 1);
}
