import Phaser from "phaser";
import { createMonster } from "../entities/factories";
import { ConfigManager } from "../managers/ConfigManager";
import { DifficultyManager } from "../managers/DifficultyManager";
import { EventBus } from "../managers/EventBus";
import { getLevelChapter, type LevelChapterId } from "../managers/LevelChapterModel";
import type { GameRuntime, System } from "./SystemTypes";

export class ChapterDirectorSystem implements System {
  private currentChapterId?: LevelChapterId;
  private readonly difficultyManager = new DifficultyManager();

  update(_deltaMs: number, runtime: GameRuntime): void {
    const chapter = getLevelChapter(runtime.stats.elapsedMs);
    if (chapter.id === this.currentChapterId) {
      return;
    }

    this.currentChapterId = chapter.id;
    EventBus.emit("level:chapter", {
      id: chapter.id,
      act: chapter.act,
      title: chapter.title,
      subtitle: chapter.subtitle,
      primaryColor: chapter.primaryColor,
      secondaryColor: chapter.secondaryColor,
    });

    if (chapter.captain) {
      this.spawnCaptain(runtime, chapter.captain.monsterId, chapter.captain.affix, chapter.primaryColor);
    }
  }

  private spawnCaptain(
    runtime: GameRuntime,
    monsterId: string,
    affix: "haste" | "shield" | "split" | "death_bomb",
    color: number,
  ): void {
    const playerTransform = runtime.world.components.transforms.get(runtime.playerId);
    const angle = runtime.random ? runtime.random() * Math.PI * 2 : Phaser.Math.FloatBetween(0, Math.PI * 2);
    const distance = 430;
    const entityId = createMonster(
      runtime.world,
      ConfigManager.getMonster(monsterId),
      (playerTransform?.x ?? 0) + Math.cos(angle) * distance,
      (playerTransform?.y ?? 0) + Math.sin(angle) * distance,
    );
    this.difficultyManager.applyToMonster(runtime.world, entityId, runtime.stats.elapsedMs, runtime.random);

    const monster = runtime.world.components.monsters.get(entityId);
    const health = runtime.world.components.health.get(entityId);
    const render = runtime.world.components.renders.get(entityId);
    const transform = runtime.world.components.transforms.get(entityId);
    if (!monster || !health) {
      return;
    }

    monster.isElite = true;
    monster.eliteAffix = affix;
    monster.damage = Math.ceil(monster.damage * 1.2);
    monster.experienceValue = Math.ceil(monster.experienceValue * 2);
    health.max = Math.ceil(health.max * 2.2);
    health.current = health.max;
    if (affix === "shield") {
      monster.shieldHp = Math.ceil(health.max * 0.42);
    }
    if (affix === "haste") {
      monster.speedMultiplier *= 1.3;
    }
    if (render) {
      render.color = color;
      render.size *= 1.32;
    }
    if (transform) {
      transform.radius *= 1.16;
      EventBus.emit("fx:sparks", { x: transform.x, y: transform.y, color, count: 24, size: 9 });
    }
    EventBus.emit("boss:phase", { text: affix === "shield" ? "护盾队长入场！" : "疾速队长入场！" });
  }
}
