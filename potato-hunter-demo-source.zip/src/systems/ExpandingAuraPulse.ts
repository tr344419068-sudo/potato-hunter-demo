import type { AuraProfile } from "../managers/SkillTypes";
import type { GameRuntime } from "./SystemTypes";

type PulseClock = { index: number; ageMs: number; periodMs: number };
type PulseSample = { index: number; radius: number; fade: number; sweeping: boolean; periodMs: number };
const samples = new WeakMap<GameRuntime["world"], Map<string, PulseSample>>();

/** Cooldown changes take effect at the next sweep, never during an active one. */
export function advanceExpandingAuraPulse(aura: AuraProfile, previous: PulseClock | undefined, deltaMs: number) {
  const travelMs = aura.pulseExpansionMs;
  if (!travelMs || aura.tickMs <= travelMs) return undefined;
  const clock: PulseClock = previous ? { ...previous, ageMs: previous.ageMs + deltaMs } : { index: 0, ageMs: 0, periodMs: aura.tickMs };
  if (clock.ageMs >= clock.periodMs) {
    clock.ageMs -= clock.periodMs;
    clock.periodMs = aura.tickMs;
    clock.index += 1 + Math.floor(clock.ageMs / clock.periodMs);
    clock.ageMs %= clock.periodMs;
  }
  const progress = Math.min(1, clock.ageMs / travelMs);
  const radius = aura.radius * (.1 + .9 * progress);
  const fade = Math.max(0, 1 - Math.max(0, clock.ageMs - travelMs) / 170);
  return { clock, sample: { index: clock.index, radius, fade, sweeping: clock.ageMs <= travelMs + 54, periodMs: clock.periodMs } };
}

/** Presentation reads the exact sample already used to apply damage. */
export function getExpandingAuraSamples(world: GameRuntime["world"]): Map<string, PulseSample> {
  let active = samples.get(world);
  if (!active) { active = new Map(); samples.set(world, active); }
  return active;
}

export type { PulseClock };
