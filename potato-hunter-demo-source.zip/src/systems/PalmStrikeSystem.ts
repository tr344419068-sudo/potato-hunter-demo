import type { EntityId } from "../components/ComponentTypes";
import { EventBus } from "../managers/EventBus";
import { absorbMonsterShield } from "./MonsterShield";
import { applyHealthDamage } from "./HealthDamage";
import { getPlayerLevelGrowth } from "../managers/PlayerLevelGrowthModel";
import { distanceSquared, normalize } from "../utils/math";
import type { GameRuntime, System } from "./SystemTypes";

export interface PalmProfile { radius: number; damage: number; cooldownMs: number; evolved: boolean }
export interface PalmVisual { x: number; y: number; radius: number; angle: number; evolved: boolean }
interface Strike extends PalmVisual { startMs: number; announced: boolean; impacted: boolean }
interface Volley { elapsedMs: number; skillId: string; profile: PalmProfile; strikes: Strike[]; hit: Set<EntityId> }

/** Local balancing for this game, not the original game's numeric values. */
export function getPalmProfile(rank: number, evolved: boolean, playerDamage: number, permanentDamage: number, area: number, cooldown: number): PalmProfile {
  const level = Math.max(1, rank);
  return {
    radius: Math.min(260, 138 * (1 + (level - 1) * 0.02) * Math.max(0.5, area) * (evolved ? 1.25 : 1)),
    damage: Math.ceil(46 * (1 + (level - 1) * 0.2) * (evolved ? 1.8 : 1) * playerDamage * permanentDamage),
    cooldownMs: Math.max(1500, 3600 * (1 - Math.min(level - 1, 12) * 0.018) * Math.max(0.35, cooldown)),
    evolved,
  };
}

export class PalmStrikeSystem implements System {
  private cooldownMs = 0;
  private volley?: Volley;
  private ownerWorld?: GameRuntime["world"];
  private ownerPlayer?: EntityId;

  update(deltaMs: number, runtime: GameRuntime): void {
    if (this.ownerWorld !== runtime.world || this.ownerPlayer !== runtime.playerId) {
      this.ownerWorld = runtime.world; this.ownerPlayer = runtime.playerId;
      this.cooldownMs = 0; this.volley = undefined;
    }
    const dt = Number.isFinite(deltaMs) ? Math.max(0, deltaMs) : 0;
    const player = runtime.world.components.transforms.get(runtime.playerId);
    if (!player || (runtime.world.components.health.get(runtime.playerId)?.current ?? 0) <= 0) {
      this.volley = undefined; this.cooldownMs = 0; return;
    }
    const evolved = runtime.skillManager.hasSkill("potato_palm_ascended");
    const skillId = evolved ? "potato_palm_ascended" : "potato_palm";
    const ownRank = runtime.skillManager.getLevel(skillId);
    if (ownRank <= 0) { this.volley = undefined; this.cooldownMs = 0; return; }
    if (this.volley && this.volley.skillId !== skillId) this.volley = undefined;
    this.cooldownMs -= dt;
    if (!this.volley && this.cooldownMs <= 0) {
      const stats = runtime.skillManager.getCombatStats();
      const rank = evolved ? ownRank + Math.max(0, runtime.skillManager.getLevel("potato_palm") - 2) : ownRank;
      const profile = getPalmProfile(rank, evolved, getPlayerLevelGrowth(runtime.world.components.players.get(runtime.playerId)?.level ?? 1).damageMultiplier,
        runtime.skillManager.getPermanentDamageMultiplier(), stats.areaMultiplier, stats.cooldownMultiplier / (1 + stats.attackSpeedBonus));
      let nearest: { x: number; y: number; distance: number } | undefined;
      for (const id of runtime.world.components.monsters.keys()) {
        const transform = runtime.world.components.transforms.get(id), health = runtime.world.components.health.get(id);
        if (!transform || !health || health.current <= 0) continue;
        const distance = distanceSquared(player.x, player.y, transform.x, transform.y);
        if (distance <= (130 + profile.radius) ** 2 && (!nearest || distance < nearest.distance)) nearest = { x: transform.x, y: transform.y, distance };
      }
      if (!nearest) return;
      const baseAngle = Math.atan2(nearest.y - player.y, nearest.x - player.x);
      const strikes: Strike[] = Array.from({ length: 4 }, (_, i) => {
        const angle = baseAngle + i * Math.PI / 2;
        return { x: player.x + Math.cos(angle) * 130, y: player.y + Math.sin(angle) * 130, radius: profile.radius, angle, evolved, startMs: i * 220, announced: false, impacted: false };
      });
      this.volley = { elapsedMs: 0, skillId, profile, strikes, hit: new Set() };
      this.cooldownMs = profile.cooldownMs;
    }
    const volley = this.volley;
    if (!volley) return;
    volley.elapsedMs += dt;
    for (const strike of volley.strikes) {
      if (!strike.announced && volley.elapsedMs >= strike.startMs) {
        strike.announced = true; EventBus.emit("palm:telegraph", strike);
      }
      if (!strike.impacted && volley.elapsedMs >= strike.startMs + 280) {
        strike.impacted = true; this.impact(runtime, volley, strike); EventBus.emit("palm:impact", strike);
      }
    }
    if (volley.strikes.every(strike => strike.impacted)) this.volley = undefined;
  }

  private impact(runtime: GameRuntime, volley: Volley, strike: Strike): void {
    for (const id of runtime.world.components.monsters.keys()) {
      const transform = runtime.world.components.transforms.get(id), health = runtime.world.components.health.get(id);
      if (!transform || !health || health.current <= 0 || volley.hit.has(id) || distanceSquared(strike.x, strike.y, transform.x, transform.y) > strike.radius * strike.radius) continue;
      volley.hit.add(id);
      const monster = runtime.world.components.monsters.get(id);
      const absorbed = absorbMonsterShield(monster, transform, volley.profile.damage);
      const dealt = applyHealthDamage(health, volley.profile.damage - absorbed);
      runtime.world.components.hitFlashes.set(id, { remainingMs: 120, totalMs: 120 });
      if (monster && !monster.isBoss) {
        const direction = normalize(transform.x - strike.x, transform.y - strike.y);
        runtime.world.components.knockbacks.set(id, { x: direction.x * 180, y: direction.y * 180, remainingMs: 150 });
      }
      if (absorbed > 0) EventBus.emit("combat:damage", { x: transform.x, y: transform.y, value: absorbed, targetId: id, category: "shield", color: "#89cfff" });
      if (dealt > 0) EventBus.emit("combat:damage", { x: transform.x, y: transform.y, value: dealt, targetId: id, category: "outgoing", color: "#ffe398" });
    }
  }
}
