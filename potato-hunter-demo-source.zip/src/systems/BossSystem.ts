import { createAoeWarning, createEnemyProjectile, createMonster } from "../entities/factories";
import { ConfigManager } from "../managers/ConfigManager";
import { EventBus } from "../managers/EventBus";
import { normalize } from "../utils/math";
import { BOSS_CHARGE_MS, BOSS_CHARGE_SPEED, BOSS_FIRST_CAST_MS, BOSS_RECOVERY_MS, getBossPatterns, getBossPhase, getBossWindupMs, type BossPattern } from "./BossPatternModel";
import { getSummonAllowance } from "./MonsterRoleModel";
import { FINAL_BOSS_FIRST_CAST_MS, FINAL_BOSS_PATTERNS, FINAL_BOSS_PATTERN_LABELS, FINAL_BOSS_SLAM_DELAYS, getFinalBossCastRequirements, getFinalBossPhase, getFinalBossRecoveryMs, getFinalBossWindupMs, type FinalBossPattern } from "./FinalBossPatternModel";
import { HOSTILE_PROJECTILE_CAP, HOSTILE_WARNING_CAP } from "./HostileHazardBudget";
import type { GameRuntime, System } from "./SystemTypes";

interface BossState {
  phase: number;
  cycleIndex: number;
  stage: "waiting" | "windup" | "charge" | "recovery";
  remainingMs: number;
  pattern?: BossPattern | FinalBossPattern;
  castPhase?: number;
  reservedProjectiles?: number;
  targetX: number;
  targetY: number;
  originX: number;
  originY: number;
  warningId?: number;
}

const PATTERN_LABELS: Record<BossPattern, string> = {
  oil_fan: "油弹扇射 · 留意空隙", bombardment: "定点轰炸 · 离开标记", charge: "炸锅冲锋 · 横向闪避", summon: "薯兵增援 · 最多三只", heat_ring: "环形热浪 · 绿色中心安全",
};

export class BossSystem implements System {
  private readonly states = new Map<number, BossState>();

  update(deltaMs: number, runtime: GameRuntime): void {
    const player = runtime.world.components.transforms.get(runtime.playerId);
    if (!player) return;
    for (const [id] of this.states) {
      const monster = runtime.world.components.monsters.get(id);
      if (!monster?.isBoss || (runtime.world.components.health.get(id)?.current ?? 0) <= 0) {
        this.cancelWarnings(runtime, id);
        this.states.delete(id);
        const velocity = runtime.world.components.velocities.get(id);
        if (velocity) { velocity.x = 0; velocity.y = 0; }
      }
    }
    for (const [id, monster] of runtime.world.components.monsters) {
      const health = runtime.world.components.health.get(id);
      const transform = runtime.world.components.transforms.get(id);
      const velocity = runtime.world.components.velocities.get(id);
      if (!monster.isBoss || !health || health.current <= 0 || !transform || !velocity) continue;
      const final = monster.bossKind === "final";
      let state = this.states.get(id);
      if (!state) {
        state = { phase: final ? getFinalBossPhase(health.current / health.max) : getBossPhase(health.current / health.max), cycleIndex: 0, stage: "waiting", remainingMs: final ? FINAL_BOSS_FIRST_CAST_MS : BOSS_FIRST_CAST_MS, targetX: 0, targetY: 0, originX: 0, originY: 0 };
        this.states.set(id, state);
      }
      const phase = final ? getFinalBossPhase(health.current / health.max) : getBossPhase(health.current / health.max);
      if (phase !== state.phase) {
        state.phase = phase;
        runtime.world.components.hitFlashes.set(id, { remainingMs: 420, totalMs: 420 });
        EventBus.emit("boss:phase", { text: final ? phase === 2 ? "堡垒暴君二阶段 · 横扫加压" : "堡垒暴君三阶段 · 酱汁围城" : phase === 2 ? "炸锅二阶段 · 冲锋与增援" : "炸锅三阶段 · 环形热浪", phase, entityId: id, danger: true, ...(final ? { bossKind: "final" } : {}) });
      }
      if (final) {
        this.updateFinal(deltaMs, runtime, id, state);
        continue;
      }
      state.remainingMs -= deltaMs;
      if (state.stage === "windup") { monster.controlledMotion = true; velocity.x = 0; velocity.y = 0; }
      if (state.remainingMs > 0) continue;
      if (state.stage === "waiting" || state.stage === "recovery") {
        const patterns = getBossPatterns(state.phase);
        const pattern = patterns[state.cycleIndex % patterns.length];
        const projectiles = pattern === "oil_fan" ? 5 : 0;
        if (!this.canAdmitCast(runtime, projectiles, 1)) continue;
        state.pattern = pattern;
        state.reservedProjectiles = projectiles;
        state.cycleIndex += 1;
        state.stage = "windup";
        state.remainingMs = getBossWindupMs(state.pattern);
        state.targetX = player.x; state.targetY = player.y;
        state.originX = transform.x; state.originY = transform.y;
        monster.controlledMotion = true; velocity.x = 0; velocity.y = 0;
        this.warn(runtime, id, state);
      } else if (state.stage === "windup") {
        this.execute(runtime, id, state);
      } else {
        velocity.x = 0; velocity.y = 0;
        monster.controlledMotion = false;
        monster.controlledMotionRemainingMs = undefined;
        state.stage = "recovery"; state.remainingMs = BOSS_RECOVERY_MS;
      }
    }
  }

  private warn(runtime: GameRuntime, id: number, state: BossState): void {
    const pattern = state.pattern as BossPattern;
    const targeted = pattern === "bombardment";
    const radius = pattern === "heat_ring" ? 300 : targeted ? 95 : 48;
    const damage = pattern === "heat_ring" ? 24 : targeted ? 15 : 0;
    state.warningId = createAoeWarning(runtime.world, targeted ? state.targetX : state.originX, targeted ? state.targetY : state.originY, radius, damage, state.remainingMs, pattern === "heat_ring" ? 96 : undefined);
    const warning = runtime.world.components.aoeWarnings.get(state.warningId)!;
    warning.sourceId = id; warning.label = PATTERN_LABELS[pattern]; warning.armed = false;
    if (pattern === "charge") {
      warning.shape = "rectangle";
      warning.angle = Math.atan2(state.targetY - state.originY, state.targetX - state.originX);
      warning.length = BOSS_CHARGE_SPEED * BOSS_CHARGE_MS / 1000;
      warning.contactPadding = runtime.world.components.transforms.get(id)!.radius + runtime.world.components.transforms.get(runtime.playerId)!.radius;
      warning.width = warning.contactPadding * 2;
    }
    EventBus.emit("boss:phase", { text: PATTERN_LABELS[pattern], pattern, entityId: id, danger: true });
  }

  private execute(runtime: GameRuntime, id: number, state: BossState): void {
    const monster = runtime.world.components.monsters.get(id)!;
    const velocity = runtime.world.components.velocities.get(id)!;
    if (state.pattern === "oil_fan" && runtime.world.components.enemyProjectiles.size + 5 > HOSTILE_PROJECTILE_CAP) return;
    state.reservedProjectiles = undefined;
    const warning = state.warningId === undefined ? undefined : runtime.world.components.aoeWarnings.get(state.warningId);
    if (warning) warning.armed = true;
    if (warning?.damage === 0 && state.warningId !== undefined) runtime.world.destroyEntity(state.warningId);
    const direction = normalize(state.targetX - state.originX, state.targetY - state.originY);
    if (state.pattern === "charge") {
      velocity.x = direction.x * BOSS_CHARGE_SPEED; velocity.y = direction.y * BOSS_CHARGE_SPEED;
      monster.controlledMotion = true;
      monster.controlledMotionRemainingMs = BOSS_CHARGE_MS;
      state.stage = "charge"; state.remainingMs = BOSS_CHARGE_MS;
      return;
    }
    if (state.pattern === "oil_fan") {
      const aim = Math.atan2(direction.y, direction.x);
      for (let index = 0; index < 5; index++) {
        const angle = aim + (index - 2) * 0.31;
        const projectile = createEnemyProjectile(runtime.world, state.originX, state.originY, Math.cos(angle) * 205, Math.sin(angle) * 205, 10, 1900);
        runtime.world.components.renders.get(projectile)!.color = 0xffb347;
      }
    }
    if (state.pattern === "summon") {
      const count = getSummonAllowance(runtime, 3);
      for (let index = 0; index < count; index++) {
        const angle = index * Math.PI * 2 / Math.max(1, count);
        createMonster(runtime.world, ConfigManager.getMonster("fries_cultist"), state.originX + Math.cos(angle) * 96, state.originY + Math.sin(angle) * 96);
      }
    }
    monster.controlledMotion = false;
    state.stage = "recovery"; state.remainingMs = BOSS_RECOVERY_MS;
  }

  private updateFinal(deltaMs: number, runtime: GameRuntime, id: number, state: BossState): void {
    const monster = runtime.world.components.monsters.get(id)!;
    const velocity = runtime.world.components.velocities.get(id)!;
    state.remainingMs -= deltaMs;
    if (state.stage === "windup") {
      monster.controlledMotion = true; velocity.x = 0; velocity.y = 0;
      const elapsedMs = getFinalBossWindupMs(state.pattern as FinalBossPattern) - Math.max(0, state.remainingMs);
      for (const warning of runtime.world.components.aoeWarnings.values()) {
        if (warning.sourceId === id && warning.damage > 0 && elapsedMs >= warning.totalMs) warning.armed = true;
      }
    }
    if (state.remainingMs > 0) return;
    if (state.stage === "waiting" || state.stage === "recovery") {
      const pattern = FINAL_BOSS_PATTERNS[state.cycleIndex % FINAL_BOSS_PATTERNS.length];
      const requirements = getFinalBossCastRequirements(pattern, state.phase);
      if (!this.canAdmitCast(runtime, requirements.projectiles, requirements.warnings)) return;
      const player = runtime.world.components.transforms.get(runtime.playerId)!;
      const transform = runtime.world.components.transforms.get(id)!;
      state.pattern = pattern;
      state.cycleIndex += 1;
      state.castPhase = state.phase;
      state.reservedProjectiles = requirements.projectiles;
      state.stage = "windup";
      state.remainingMs = getFinalBossWindupMs(state.pattern);
      state.targetX = player.x; state.targetY = player.y;
      state.originX = transform.x; state.originY = transform.y;
      state.warningId = undefined;
      monster.controlledMotion = true;
      monster.controlledMotionRemainingMs = undefined;
      velocity.x = 0; velocity.y = 0;
      this.warnFinal(runtime, id, state);
      return;
    }
    if (state.stage !== "windup") return;
    if (state.pattern === "sesame_fan") {
      const count = state.reservedProjectiles ?? getFinalBossCastRequirements(state.pattern, state.castPhase ?? 1).projectiles;
      if (runtime.world.components.enemyProjectiles.size + count > HOSTILE_PROJECTILE_CAP) return;
      if (state.warningId !== undefined) runtime.world.destroyEntity(state.warningId);
      const aim = Math.atan2(state.targetY - state.originY, state.targetX - state.originX);
      const speed = 200 + ((state.castPhase ?? 1) - 1) * 8;
      for (let index = 0; index < count; index++) {
        const angle = aim + (index - (count - 1) / 2) * .24;
        const projectile = createEnemyProjectile(runtime.world, state.originX, state.originY, Math.cos(angle) * speed, Math.sin(angle) * speed, 12, 2000);
        runtime.world.components.renders.get(projectile)!.color = 0xffe4a1;
      }
    }
    velocity.x = 0; velocity.y = 0;
    monster.controlledMotion = false;
    monster.controlledMotionRemainingMs = undefined;
    state.reservedProjectiles = undefined;
    state.stage = "recovery";
    state.remainingMs = getFinalBossRecoveryMs(state.phase);
  }

  private warnFinal(runtime: GameRuntime, id: number, state: BossState): void {
    const pattern = state.pattern as FinalBossPattern;
    const phase = state.castPhase ?? 1;
    const label = FINAL_BOSS_PATTERN_LABELS[pattern];
    const addWarning = (x: number, y: number, radius: number, damage: number, delayMs: number, safeRadius?: number): number => {
      const warningId = createAoeWarning(runtime.world, x, y, radius, damage, delayMs, safeRadius);
      Object.assign(runtime.world.components.aoeWarnings.get(warningId)!, { sourceId: id, label, armed: false, skipNextTick: true });
      return warningId;
    };
    if (pattern === "sesame_fan") {
      state.warningId = addWarning(state.originX, state.originY, 60, 0, state.remainingMs);
    } else if (pattern === "triple_slam") {
      const offsets = [[0, 0], [-160, 120], [160, 120]];
      offsets.forEach(([offsetX, offsetY], index) => addWarning(state.targetX + offsetX, state.targetY + offsetY, 75 + (phase - 1) * 5, 16, FINAL_BOSS_SLAM_DELAYS[index]));
    } else if (pattern === "spatula_sweep") {
      const angle = Math.atan2(state.targetY - state.originY, state.targetX - state.originX);
      for (let index = 0; index < 4; index++) {
        const distance = 100 + index * 85;
        const warningId = addWarning(state.originX + Math.cos(angle) * distance, state.originY + Math.sin(angle) * distance, 58 + (phase - 1) * 4, 18, state.remainingMs);
        if (index !== 1) runtime.world.components.aoeWarnings.get(warningId)!.label = undefined;
      }
    } else {
      addWarning(state.originX, state.originY, 260 + (phase - 1) * 10, 20, state.remainingMs, 110);
    }
    const metadata = { text: label, pattern, phase: state.phase, entityId: id, bossKind: "final", windupMs: state.remainingMs, danger: true };
    EventBus.emit("boss:phase", metadata);
    EventBus.emit("boss:windup", metadata);
  }

  private cancelWarnings(runtime: GameRuntime, sourceId: number): void {
    for (const [warningId, warning] of runtime.world.components.aoeWarnings) {
      if (warning.sourceId === sourceId) runtime.world.destroyEntity(warningId);
    }
  }

  private canAdmitCast(runtime: GameRuntime, projectiles: number, warnings: number): boolean {
    const reservedProjectiles = [...this.states.values()].reduce((sum, active) => sum + (active.reservedProjectiles ?? 0), 0);
    return runtime.world.components.aoeWarnings.size + warnings <= HOSTILE_WARNING_CAP && runtime.world.components.enemyProjectiles.size + reservedProjectiles + projectiles <= HOSTILE_PROJECTILE_CAP;
  }
}
