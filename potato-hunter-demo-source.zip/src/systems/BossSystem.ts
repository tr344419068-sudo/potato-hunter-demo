import { createAoeWarning, createEnemyProjectile, createMonster } from "../entities/factories";
import type { AoeWarningComponent, FinalBossEncounter, FinalBossPhase } from "../components/ComponentTypes";
import { ConfigManager } from "../managers/ConfigManager";
import { EventBus } from "../managers/EventBus";
import { normalize } from "../utils/math";
import { BOSS_CHARGE_MS, BOSS_CHARGE_SPEED, BOSS_FIRST_CAST_MS, BOSS_RECOVERY_MS, getBossPatterns, getBossPhase, getBossWindupMs, type BossPattern } from "./BossPatternModel";
import { getSummonAllowance } from "./MonsterRoleModel";
import { DESERT_BOSS_PATTERN_LABELS, FINAL_BOSS_FIRST_CAST_MS, FINAL_BOSS_PATTERNS, FINAL_BOSS_PATTERN_LABELS, FINAL_BOSS_SLAM_DELAYS, FINAL_BOSS_TRANSITION_MS, FINAL_DUEL_FIRST_CAST_MS, FINAL_DUEL_RUSH_MS, getCampaignFinalBossPhase, getDuelHitDamage, getFinalBossCastRequirements, getFinalBossPhase, getFinalBossPhaseFloor, getFinalBossRecoveryMs, getFinalBossWindupMs, getFinalDuelPressure, getFinalDuelTellMs, type FinalBossPattern } from "./FinalBossPatternModel";
import { HOSTILE_PROJECTILE_CAP, HOSTILE_WARNING_CAP } from "./HostileHazardBudget";
import { getBossDuel, getBossDuelRushDistance } from "./BossDuelArena";
import { advanceDesertCast, clearDesertCast, DESERT_BURROW_SINK_MS, DESERT_CAST_LABELS, DESERT_CLEAVE_REACH, DESERT_ROTATIONS, startDesertCast, type DesertCast, type DesertPattern } from "./DesertBossEncounter";
import { updateSnowBoss } from "./SnowBossEncounter";
import type { GameRuntime, System } from "./SystemTypes";

interface BossState {
  phase: number;
  cycleIndex: number;
  stage: "waiting" | "windup" | "charge" | "recovery" | "transition";
  remainingMs: number;
  pattern?: BossPattern | FinalBossPattern;
  castPhase?: number;
  reservedProjectiles?: number;
  targetX: number;
  targetY: number;
  originX: number;
  originY: number;
  warningId?: number;
  rushDistance?: number;
  sand?: DesertCast;
  sandRecoveryMs?: number;
  desertBasicUsed?: boolean;
}

const PATTERN_LABELS: Record<BossPattern, string> = {
  oil_fan: "油弹扇射 · 留意空隙", bombardment: "定点轰炸 · 离开标记", charge: "炸锅冲锋 · 横向闪避", summon: "薯兵增援 · 最多三只", heat_ring: "环形热浪 · 绿色中心安全",
};

export class BossSystem implements System {
  readonly telemetrySource = "BossSystem";
  private readonly states = new Map<number, BossState>();

  update(deltaMs: number, runtime: GameRuntime): void {
    const player = runtime.world.components.transforms.get(runtime.playerId);
    if (!player) return;
    const duel = getBossDuel(runtime.world);
    for (const [id] of this.states) {
      const monster = runtime.world.components.monsters.get(id);
      if (duel && id !== duel.bossId) { this.states.delete(id); continue; }
      if (!monster?.isBoss || (runtime.world.components.health.get(id)?.current ?? 0) <= 0) {
        if (this.states.get(id)?.sand) clearDesertCast(runtime.world);
        this.cancelWarnings(runtime, id);
        this.states.delete(id);
        const velocity = runtime.world.components.velocities.get(id);
        if (velocity) { velocity.x = 0; velocity.y = 0; }
      }
    }
    for (const [id, monster] of runtime.world.components.monsters) {
      if (duel && id !== duel.bossId) continue;
      const health = runtime.world.components.health.get(id);
      const transform = runtime.world.components.transforms.get(id);
      const velocity = runtime.world.components.velocities.get(id);
      if (!monster.isBoss || !health || health.current <= 0 || !transform || !velocity) continue;
      if (runtime.campaign?.stage === "snow" && monster.monsterId === "snow_elite") continue;
      const final = monster.bossKind === "final";
      const encounter = final ? monster.finalBossEncounter : undefined;
      const inDuel = duel?.bossId === id;
      if (inDuel && duel.stage === "snow" && encounter) {
        updateSnowBoss(deltaMs, runtime, duel, encounter);
        continue;
      }
      const phase = encounter?.phase ?? (final ? getFinalBossPhase(health.current / health.max) : getBossPhase(health.current / health.max));
      let state = this.states.get(id);
      if (!state) {
        const firstCastMs = final ? (inDuel ? FINAL_DUEL_FIRST_CAST_MS : FINAL_BOSS_FIRST_CAST_MS) : BOSS_FIRST_CAST_MS;
        state = { phase, cycleIndex: 0, stage: "waiting", remainingMs: firstCastMs, targetX: 0, targetY: 0, originX: 0, originY: 0 };
        this.states.set(id, state);
      }
      if (encounter) {
        const stage = duel?.stage ?? runtime.campaign?.stage ?? "meadow";
        const phaseSpec = getCampaignFinalBossPhase(stage, encounter.phase);
        if (!state.sand && state.stage !== "charge" && !encounter.transitioning && encounter.phase < 3 && encounter.completedCasts >= phaseSpec.requiredCasts && health.current <= getFinalBossPhaseFloor(health.max, encounter.phase, stage)) {
          this.beginFinalTransition(runtime, id, state, encounter, encounter.phase === 1 ? 2 : 3);
          continue;
        }
      }
      if (phase !== state.phase) {
        state.phase = phase;
        runtime.world.components.hitFlashes.set(id, { remainingMs: 420, totalMs: 420 });
        const finalText = runtime.campaign?.stage === "desert" ? (phase === 2 ? "沙海之王二阶段 · 沙刃加压" : "沙海之王三阶段 · 沙暴围城") : (phase === 2 ? "堡垒暴君二阶段 · 横扫加压" : "堡垒暴君三阶段 · 震荡围城");
        EventBus.emit("boss:phase", { text: final ? finalText : phase === 2 ? "炸锅二阶段 · 冲锋与增援" : "炸锅三阶段 · 环形热浪", phase, entityId: id, danger: true, ...(final ? { bossKind: "final" } : {}) });
      }
      if (final) {
        if (inDuel && duel.stage === "desert" && encounter) this.updateDesert(deltaMs, runtime, id, state, duel, encounter);
        else this.updateFinal(deltaMs, runtime, id, state, inDuel);
        continue;
      }
      state.remainingMs -= deltaMs;
      if (state.stage === "windup") { monster.controlledMotion = true; velocity.x = 0; velocity.y = 0; }
      if (state.remainingMs > 0) continue;
      if (state.stage === "waiting" || state.stage === "recovery") {
        const patterns = getBossPatterns(state.phase);
        const pattern = patterns[state.cycleIndex % patterns.length];
        const projectiles = pattern === "oil_fan" ? 5 : 0;
        if (!this.canAdmitCast(runtime, projectiles, 1)) continue;
        state.pattern = pattern;
        state.reservedProjectiles = projectiles;
        state.cycleIndex += 1;
        state.stage = "windup";
        state.remainingMs = getBossWindupMs(state.pattern);
        state.targetX = player.x; state.targetY = player.y;
        state.originX = transform.x; state.originY = transform.y;
        monster.controlledMotion = true; velocity.x = 0; velocity.y = 0;
        this.warn(runtime, id, state);
      } else if (state.stage === "windup") {
        this.execute(runtime, id, state);
      } else {
        velocity.x = 0; velocity.y = 0;
        monster.controlledMotion = false;
        monster.controlledMotionRemainingMs = undefined;
        state.stage = "recovery"; state.remainingMs = BOSS_RECOVERY_MS;
      }
    }
  }

  private warn(runtime: GameRuntime, id: number, state: BossState): void {
    const pattern = state.pattern as BossPattern;
    const targeted = pattern === "bombardment";
    const radius = pattern === "heat_ring" ? 300 : targeted ? 118 : 48;
    const damage = pattern === "heat_ring" ? 24 : targeted ? 15 : 0;
    state.warningId = createAoeWarning(runtime.world, targeted ? state.targetX : state.originX, targeted ? state.targetY : state.originY, radius, damage, state.remainingMs, pattern === "heat_ring" ? 96 : undefined);
    const warning = runtime.world.components.aoeWarnings.get(state.warningId)!;
    warning.sourceId = id; warning.label = PATTERN_LABELS[pattern]; warning.armed = false;
    if (damage > 0) warning.impactStyle = "oil";
    if (pattern === "charge") {
      warning.shape = "rectangle";
      warning.angle = Math.atan2(state.targetY - state.originY, state.targetX - state.originX);
      warning.length = BOSS_CHARGE_SPEED * BOSS_CHARGE_MS / 1000;
      warning.contactPadding = runtime.world.components.transforms.get(id)!.radius + runtime.world.components.transforms.get(runtime.playerId)!.radius;
      warning.width = warning.contactPadding * 2;
    }
    EventBus.emit("boss:phase", { text: PATTERN_LABELS[pattern], pattern, entityId: id, danger: true });
  }

  private execute(runtime: GameRuntime, id: number, state: BossState): void {
    const monster = runtime.world.components.monsters.get(id)!;
    const velocity = runtime.world.components.velocities.get(id)!;
    if (state.pattern === "oil_fan" && runtime.world.components.enemyProjectiles.size + 5 > HOSTILE_PROJECTILE_CAP) return;
    state.reservedProjectiles = undefined;
    const warning = state.warningId === undefined ? undefined : runtime.world.components.aoeWarnings.get(state.warningId);
    if (warning) warning.armed = true;
    if (warning?.damage === 0 && state.warningId !== undefined) runtime.world.destroyEntity(state.warningId);
    const direction = normalize(state.targetX - state.originX, state.targetY - state.originY);
    if (state.pattern === "charge") {
      velocity.x = direction.x * BOSS_CHARGE_SPEED; velocity.y = direction.y * BOSS_CHARGE_SPEED;
      monster.controlledMotion = true;
      monster.controlledMotionRemainingMs = BOSS_CHARGE_MS;
      state.stage = "charge"; state.remainingMs = BOSS_CHARGE_MS;
      return;
    }
    if (state.pattern === "oil_fan") {
      const aim = Math.atan2(direction.y, direction.x);
      const angles: number[] = [];
      for (let index = 0; index < 5; index++) {
        const angle = aim + (index - 2) * 0.31;
        angles.push(angle);
        createEnemyProjectile(runtime.world, state.originX, state.originY, Math.cos(angle) * 205, Math.sin(angle) * 205, 10, 1900, "oil");
      }
      EventBus.emit("hostile:volley", { x: state.originX, y: state.originY, angles, style: "oil" });
    }
    if (state.pattern === "summon") {
      const count = getSummonAllowance(runtime, 3);
      for (let index = 0; index < count; index++) {
        const angle = index * Math.PI * 2 / Math.max(1, count);
        createMonster(runtime.world, ConfigManager.getMonster("fries_cultist"), state.originX + Math.cos(angle) * 96, state.originY + Math.sin(angle) * 96);
      }
    }
    monster.controlledMotion = false;
    state.stage = "recovery"; state.remainingMs = BOSS_RECOVERY_MS;
  }

  private beginFinalTransition(runtime: GameRuntime, id: number, state: BossState, encounter: FinalBossEncounter, nextPhase: FinalBossPhase): void {
    this.cancelWarnings(runtime, id);
    const monster = runtime.world.components.monsters.get(id)!;
    const velocity = runtime.world.components.velocities.get(id)!;
    monster.controlledMotion = true;
    monster.controlledMotionRemainingMs = undefined;
    velocity.x = 0; velocity.y = 0;
    encounter.phase = nextPhase;
    encounter.completedCasts = 0;
    encounter.transitioning = true;
    encounter.swingFrame = undefined;
    encounter.sandArmor = undefined;
    Object.assign(state, {
      phase: nextPhase, stage: "transition", remainingMs: FINAL_BOSS_TRANSITION_MS,
      cycleIndex: 0, pattern: undefined, warningId: undefined, reservedProjectiles: undefined, sandRecoveryMs: undefined,
    });
    runtime.world.components.hitFlashes.set(id, { remainingMs: 420, totalMs: 420 });
    const label = getCampaignFinalBossPhase(runtime.campaign?.stage ?? "meadow", nextPhase).label;
    EventBus.emit("boss:phase", { text: `阶段 ${nextPhase}/3 · ${label}`, phase: nextPhase, entityId: id, bossKind: "final", danger: true });
  }

  private updateDesert(deltaMs: number, runtime: GameRuntime, id: number, state: BossState, duel: NonNullable<ReturnType<typeof getBossDuel>>, encounter: FinalBossEncounter): void {
    const { world, playerId } = runtime;
    const monster = world.components.monsters.get(id)!;
    const velocity = world.components.velocities.get(id)!;
    const player = world.components.transforms.get(playerId)!;
    const boss = world.components.transforms.get(id)!;
    if (encounter.sandArmor) {
      encounter.sandArmor.remainingMs -= deltaMs;
      if (encounter.sandArmor.remainingMs <= 0 || encounter.sandArmor.hp <= 0) encounter.sandArmor = undefined;
    }
    if (state.sand) {
      const cast = state.sand;
      if (cast.shape.kind === "sand_burrow") {
        const next = cast.elapsedMs + deltaMs;
        encounter.burrowed = next >= DESERT_BURROW_SINK_MS && next < cast.tellMs;
        if (cast.elapsedMs < cast.tellMs && next >= cast.tellMs) {
          boss.x = cast.shape.center.x; boss.y = cast.shape.center.y;
          encounter.swingFacing = player.x >= boss.x ? -1 : 1;
        }
      }
      const done = advanceDesertCast(cast, deltaMs, runtime);
      const progress = cast.elapsedMs / cast.tellMs;
      encounter.swingFrame = progress < .33 ? 0 : progress < .68 ? 1 : progress < 1 ? 2
        : cast.elapsedMs < cast.tellMs + 100 ? 3 : cast.elapsedMs < cast.tellMs + 190 ? 4 : undefined;
      if (!done) return;
      clearDesertCast(world);
      state.sand = undefined;
      state.stage = "recovery";
      state.remainingMs = state.sandRecoveryMs = cast.recoveryMs;
      if (cast.shape.kind !== "sand_cleave") {
        encounter.completedCasts += 1;
        state.desertBasicUsed = false;
      }
      encounter.swingFrame = 5;
      // Keep the boss planted for a punish window, particularly after the storm.
      return;
    }
    state.remainingMs -= deltaMs;
    if (state.stage === "recovery" && state.sandRecoveryMs !== undefined) {
      const since = state.sandRecoveryMs - state.remainingMs;
      encounter.swingFrame = since < 120 ? 5 : since < 265 ? 6 : undefined;
    }
    if (state.remainingMs > 0) {
      const activeRecovery = state.stage === "recovery" && (state.sandRecoveryMs ?? Infinity) < 1000;
      const distance = Math.hypot(player.x - boss.x, player.y - boss.y);
      if (activeRecovery && !state.desertBasicUsed && distance <= DESERT_CLEAVE_REACH - 12) {
        state.desertBasicUsed = true;
        this.startDesertAttack(runtime, id, state, duel, encounter, "sand_cleave", 0);
      } else if (state.stage === "waiting" || (activeRecovery && !state.desertBasicUsed)) {
        const heading = normalize(player.x - boss.x, player.y - boss.y);
        const speed = Math.min(242 + encounter.phase * 32, Math.max(0, distance - 128) * 1000 / Math.max(1, deltaMs));
        monster.controlledMotion = true; // BossSystem owns this approach; only the warned swing damages.
        velocity.x = heading.x * speed; velocity.y = heading.y * speed;
        if (Math.abs(player.x - boss.x) > 24) encounter.swingFacing = player.x > boss.x ? -1 : 1;
      }
      return;
    }
    if (state.stage === "transition") {
      encounter.transitioning = false;
      const max = Math.ceil(world.components.health.get(id)!.max * (encounter.phase === 3 ? .13 : .09));
      encounter.sandArmor = { hp: max, max, remainingMs: 6500 };
    }
    const rotation = DESERT_ROTATIONS[encounter.phase];
    const turn = state.cycleIndex++;
    this.startDesertAttack(runtime, id, state, duel, encounter, rotation[turn % rotation.length], turn);
  }

  private startDesertAttack(runtime: GameRuntime, id: number, state: BossState, duel: NonNullable<ReturnType<typeof getBossDuel>>, encounter: FinalBossEncounter, pattern: DesertPattern, turn: number): void {
    const { world, playerId } = runtime;
    const player = world.components.transforms.get(playerId)!;
    const boss = world.components.transforms.get(id)!;
    const monster = world.components.monsters.get(id)!;
    const velocity = world.components.velocities.get(id)!;
    const readable = runtime.canShowDesertAttack?.(pattern) ?? true;
    const cast = startDesertCast(world, id, duel, pattern, encounter.phase, player, boss, turn, readable);
    state.sand = cast;
    state.stage = "windup";
    monster.controlledMotion = true;
    monster.controlledMotionRemainingMs = undefined;
    velocity.x = velocity.y = 0;
    encounter.swingFrame = 0;
    if (Math.abs(player.x - boss.x) > 24) encounter.swingFacing = player.x > boss.x ? -1 : 1;
    if (pattern !== "sand_cleave") EventBus.emit("boss:phase", { text: readable ? DESERT_CAST_LABELS[pattern] : "沙海之王 · 无伤演示", pattern, phase: encounter.phase, entityId: id, bossKind: "final", windupMs: cast.tellMs, danger: readable, duel: true, x: boss.x, y: boss.y, desert: true });
  }

  private updateFinal(deltaMs: number, runtime: GameRuntime, id: number, state: BossState, inDuel: boolean): void {
    const monster = runtime.world.components.monsters.get(id)!;
    const velocity = runtime.world.components.velocities.get(id)!;
    const encounter = monster.finalBossEncounter;
    const pressure = inDuel ? getFinalDuelPressure(state.castPhase ?? state.phase) : undefined;
    state.remainingMs -= deltaMs;
    if (state.stage === "windup") {
      monster.controlledMotion = true; velocity.x = 0; velocity.y = 0;
      const pattern = state.pattern as FinalBossPattern;
      const elapsedMs = (pressure ? getFinalDuelTellMs(pattern, state.castPhase ?? state.phase) : getFinalBossWindupMs(pattern)) - Math.max(0, state.remainingMs);
      if (encounter && pressure && pattern === "spatula_sweep") {
        const progress = elapsedMs / pressure.sweepTellMs;
        encounter.swingFrame = progress < .32 ? 0 : progress < .64 ? 1 : 2;
      }
      if (!(pressure && pattern === "spatula_sweep")) {
        for (const warning of runtime.world.components.aoeWarnings.values()) {
          if (warning.sourceId === id && warning.damage > 0 && elapsedMs >= warning.totalMs) warning.armed = true;
        }
      }
    }
    if (encounter && pressure && state.stage === "charge") encounter.swingFrame = state.remainingMs > 100 ? 3 : 4;
    if (encounter && pressure && state.stage === "recovery" && encounter.swingFrame !== undefined) {
      const sinceImpact = pressure.recoveryMs - state.remainingMs;
      encounter.swingFrame = sinceImpact < 70 ? 5 : sinceImpact < 150 ? 6 : undefined;
    }
    if (state.remainingMs > 0) return;
    if (state.stage === "transition") {
      if (encounter) encounter.transitioning = false;
      monster.controlledMotion = false;
      state.stage = "waiting";
    }
    if (state.stage === "waiting" || state.stage === "recovery") {
      const rotation = encounter
        ? getCampaignFinalBossPhase(runtime.campaign?.stage === "desert" ? "desert" : "meadow", encounter.phase).rotation
        : FINAL_BOSS_PATTERNS;
      const pattern = rotation[state.cycleIndex % rotation.length];
      const requirements = getFinalBossCastRequirements(pattern, state.phase);
      if (!this.canAdmitCast(runtime, requirements.projectiles, requirements.warnings)) return;
      const player = runtime.world.components.transforms.get(runtime.playerId)!;
      const transform = runtime.world.components.transforms.get(id)!;
      state.pattern = pattern;
      state.cycleIndex += 1;
      state.castPhase = state.phase;
      state.reservedProjectiles = requirements.projectiles;
      state.stage = "windup";
      state.remainingMs = inDuel ? getFinalDuelTellMs(pattern, state.phase) : getFinalBossWindupMs(pattern);
      state.targetX = player.x; state.targetY = player.y;
      state.originX = transform.x; state.originY = transform.y;
      if (encounter && pressure && pattern === "spatula_sweep") {
        encounter.swingFrame = 0;
        const dx = player.x - transform.x;
        if (Math.abs(dx) > 24) encounter.swingFacing = dx > 0 ? -1 : 1;
      }
      state.warningId = undefined;
      monster.controlledMotion = true;
      monster.controlledMotionRemainingMs = undefined;
      velocity.x = 0; velocity.y = 0;
      this.warnFinal(runtime, id, state, inDuel);
      return;
    }
    if (state.stage === "windup" && pressure && state.pattern === "spatula_sweep") {
      const angle = Math.atan2(state.targetY - state.originY, state.targetX - state.originX);
      const distance = state.rushDistance ?? pressure.rushDistance;
      const speed = distance * 1000 / FINAL_DUEL_RUSH_MS;
      velocity.x = Math.cos(angle) * speed; velocity.y = Math.sin(angle) * speed;
      monster.controlledMotionRemainingMs = FINAL_DUEL_RUSH_MS;
      state.stage = "charge"; state.remainingMs = FINAL_DUEL_RUSH_MS;
      if (encounter) encounter.swingFrame = 3;
      EventBus.emit("boss:rush", { x: state.originX, y: state.originY, angle, distance, duration: FINAL_DUEL_RUSH_MS, phase: state.phase, desert: runtime.campaign?.stage === "desert" });
      return;
    }
    if (state.stage !== "windup" && state.stage !== "charge") return;
    if (state.stage === "charge" && state.warningId !== undefined) {
      const warning = runtime.world.components.aoeWarnings.get(state.warningId);
      if (warning) warning.armed = true;
      if (encounter) encounter.swingFrame = 5;
    } else if (state.pattern === "sesame_fan") {
      const count = state.reservedProjectiles ?? getFinalBossCastRequirements(state.pattern, state.castPhase ?? 1).projectiles;
      if (runtime.world.components.enemyProjectiles.size + count > HOSTILE_PROJECTILE_CAP) return;
      if (state.warningId !== undefined) runtime.world.destroyEntity(state.warningId);
      const aim = Math.atan2(state.targetY - state.originY, state.targetX - state.originX);
      const speed = pressure?.shotSpeed ?? 200 + ((state.castPhase ?? 1) - 1) * 8;
      const desert = runtime.campaign?.stage === "desert";
      const damage = pressure ? getDuelHitDamage(runtime.world.components.health.get(runtime.playerId)?.max ?? 100, pressure.shotHpRatio) : 12;
      const angles: number[] = [];
      for (let index = 0; index < count; index++) {
        const leftCount = Math.floor(count / 2);
        // The desert fan splits into two wings around its snapshot aim, leaving
        // a deliberately navigable center instead of firing a center pellet.
        const offset = desert
          ? index < leftCount ? -.38 - (leftCount - 1 - index) * .24 : .38 + (index - leftCount) * .24
          : (index - (count - 1) / 2) * .24;
        const angle = aim + offset;
        angles.push(angle);
        createEnemyProjectile(runtime.world, state.originX, state.originY, Math.cos(angle) * speed, Math.sin(angle) * speed, damage, pressure ? 3000 : 2000, desert ? "sand" : "sauce");
      }
      EventBus.emit("hostile:volley", { x: state.originX, y: state.originY, angles, style: desert ? "sand" : "sauce", bossPhase: inDuel ? state.phase : undefined });
    }
    velocity.x = 0; velocity.y = 0;
    monster.controlledMotion = false;
    monster.controlledMotionRemainingMs = undefined;
    state.reservedProjectiles = undefined;
    state.stage = "recovery";
    state.remainingMs = pressure?.recoveryMs ?? getFinalBossRecoveryMs(state.phase);
    if (encounter) encounter.completedCasts += 1;
  }

  private warnFinal(runtime: GameRuntime, id: number, state: BossState, inDuel: boolean): void {
    const pattern = state.pattern as FinalBossPattern;
    const phase = state.castPhase ?? 1;
    const pressure = inDuel ? getFinalDuelPressure(phase) : undefined;
    const maxHp = runtime.world.components.health.get(runtime.playerId)?.max ?? 100;
    const desert = runtime.campaign?.stage === "desert";
    const arenaKit = !desert && Boolean(runtime.world.components.monsters.get(id)?.finalBossEncounter);
    const label = pressure && pattern === "spatula_sweep" ? (desert ? "沙刃冲斩 · 横向闪避" : "锅铲冲斩 · 横向闪避")
      : arenaKit && pattern === "triple_slam" ? "三连落雷 · 依次避开标记"
      : arenaKit && pattern === "sauce_ring" ? "震荡音波 · 内圈安全"
      : arenaKit && pattern === "sesame_fan" ? "烈焰扇射 · 穿过弹隙"
      : (desert ? DESERT_BOSS_PATTERN_LABELS : FINAL_BOSS_PATTERN_LABELS)[pattern];
    const addWarning = (x: number, y: number, radius: number, damage: number, delayMs: number, safeRadius?: number): number => {
      const warningId = createAoeWarning(runtime.world, x, y, radius, damage, delayMs, safeRadius);
      const warning = runtime.world.components.aoeWarnings.get(warningId)!;
      Object.assign(warning, { sourceId: id, label, armed: false, skipNextTick: true });
      if (inDuel) { warning.bossPhase = phase; warning.bossFinisher = pattern === "sauce_ring"; }
      if (damage > 0) warning.impactStyle = desert ? "sand"
        : pattern === "triple_slam" ? (arenaKit ? "lightning" : "slam")
        : pattern === "spatula_sweep" ? "sweep" : arenaKit ? "shockwave" : "sauce";
      return warningId;
    };
    if (pattern === "sesame_fan") {
      state.warningId = addWarning(state.originX, state.originY, 60, 0, state.remainingMs);
      runtime.world.components.aoeWarnings.get(state.warningId)!.impactStyle = desert ? "sand" : "oil";
    } else if (pattern === "triple_slam") {
      const aim = Math.atan2(state.targetY - state.originY, state.targetX - state.originX);
      const offsets = desert
        ? [0, -150, 150].map(distance => [Math.cos(aim) * distance, Math.sin(aim) * distance])
        : [[0, 0], [-160, 120], [160, 120]];
      offsets.forEach(([offsetX, offsetY], index) => {
        const warningId = addWarning(state.targetX + offsetX, state.targetY + offsetY, pressure?.slamRadius ?? 88 + (phase - 1) * 5, pressure ? getDuelHitDamage(maxHp, pressure.slamHpRatio) : 16, (pressure?.slamDelays ?? FINAL_BOSS_SLAM_DELAYS)[index]);
        if (index > 0) runtime.world.components.aoeWarnings.get(warningId)!.label = undefined;
      });
    } else if (pattern === "spatula_sweep") {
      const angle = Math.atan2(state.targetY - state.originY, state.targetX - state.originX);
      const duel = pressure ? getBossDuel(runtime.world) : undefined;
      const transform = runtime.world.components.transforms.get(id)!;
      state.rushDistance = duel && pressure ? getBossDuelRushDistance(duel, transform, angle, pressure.rushDistance) : undefined;
      const length = state.rushDistance !== undefined ? state.rushDistance + 60 : desert ? 240 : 255;
      const offset = length / 2 + (pressure ? 0 : 100);
      const x = desert && !pressure ? state.targetX : state.originX + Math.cos(angle) * offset;
      const y = desert && !pressure ? state.targetY : state.originY + Math.sin(angle) * offset;
      const radius = pressure?.sweepRadius ?? 68 + (phase - 1) * 4;
      const rotation = desert && !pressure ? angle + Math.PI / 2 : angle;
      const warningId = addWarning(x, y, radius, pressure ? getDuelHitDamage(maxHp, pressure.sweepHpRatio) : 18, state.remainingMs + (pressure ? FINAL_DUEL_RUSH_MS : 0));
      state.warningId = warningId;
      Object.assign(runtime.world.components.aoeWarnings.get(warningId)!, {
        shape: "capsule", angle: rotation, length,
        impactArt: { kind: "sweep", x, y, angle: rotation, length: length + 2 * radius },
      } satisfies Partial<AoeWarningComponent>);
    } else {
      const damage = pressure ? getDuelHitDamage(maxHp, pressure.finisherHpRatio) : 20;
      if (desert) addWarning(state.targetX, state.targetY, pressure?.sandRadius ?? 150 + (phase - 1) * 5, damage, state.remainingMs);
      else addWarning(state.originX, state.originY, pressure?.shockRadius ?? 260 + (phase - 1) * 10, damage, state.remainingMs, pressure ? 120 : 110);
    }
    const metadata = { text: label, pattern, phase: state.phase, entityId: id, bossKind: "final", windupMs: state.remainingMs, danger: true,
      ...(inDuel ? { duel: true, x: state.originX, y: state.originY, desert } : {}) };
    EventBus.emit("boss:phase", metadata);
    EventBus.emit("boss:windup", metadata);
  }

  private cancelWarnings(runtime: GameRuntime, sourceId: number): void {
    for (const [warningId, warning] of runtime.world.components.aoeWarnings) {
      if (warning.sourceId === sourceId) runtime.world.destroyEntity(warningId);
    }
  }

  private canAdmitCast(runtime: GameRuntime, projectiles: number, warnings: number): boolean {
    const reservedProjectiles = [...this.states.values()].reduce((sum, active) => sum + (active.reservedProjectiles ?? 0), 0);
    return runtime.world.components.aoeWarnings.size + warnings <= HOSTILE_WARNING_CAP && runtime.world.components.enemyProjectiles.size + reservedProjectiles + projectiles <= HOSTILE_PROJECTILE_CAP;
  }
}
