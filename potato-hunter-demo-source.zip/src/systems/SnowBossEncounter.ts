import type { FinalBossEncounter, FinalBossPhase, TransformComponent } from "../components/ComponentTypes";
import type { World } from "../entities/World";
import { EventBus } from "../managers/EventBus";
import { sweepTime } from "../utils/math";
import { confineDuelActor, getBossDuel, getBossDuelRushDistance } from "./BossDuelArena";
import { FINAL_BOSS_TRANSITION_MS, getCampaignFinalBossPhase, getFinalBossPhaseFloor, type SnowPattern } from "./FinalBossPatternModel";
import { breakIceCover, sweepIceCover, type IceCover } from "./IceTerrain";
import { canReceiveHostileDamage, getHostileHitGraceMs } from "./PlayerDamageModel";
import type { GameRuntime } from "./SystemTypes";

export type { SnowPattern } from "./FinalBossPatternModel";

type Point = Readonly<{ x: number; y: number }>;
type Arena = NonNullable<ReturnType<typeof getBossDuel>>;
type Hammer = { kind: "hammer_swing"; origin: Point; angle: number; halfAngle: number; radius: number };
type Lane = { origin: Point; end: Point; angle: number; radius: number };
type Spikes = Lane & { kind: "ice_spikes" };
type Charge = Lane & { kind: "glacier_charge"; cover?: IceCover; travelMs: number };
type Avalanche = { kind: "avalanche"; pulses: readonly SnowPulse[] };
export type SnowPulse = Readonly<{ minX: number; maxX: number; impactMs: number }>;
export type SnowShape = Hammer | Spikes | Charge | Avalanche;

export interface SnowCast {
  readonly arena: Arena;
  readonly shape: SnowShape;
  readonly tellMs: number;
  readonly durationMs: number;
  readonly readable: boolean;
  readonly damageRatio: number;
  elapsedMs: number;
  hit: boolean;
}

interface SnowBossState {
  bossId: number;
  mode: "pursuit" | "cast" | "recovery" | "transition";
  cast?: SnowCast;
  remainingMs: number;
  recoveryMs: number;
  cycle: number;
  basicUsed: boolean;
  priorityCast: boolean;
  punish?: "pillar" | "avalanche";
}

export const SNOW_CAST_LABELS: Record<SnowPattern, string> = {
  hammer_swing: "霜锤横劈 · 绕到锤后",
  ice_spikes: "冰刺 · 横移离开裂隙",
  glacier_charge: "冰甲冲锋 · 引首领撞冰岩破盾",
  avalanche: "裂谷雪崩 · 沿青色路线闪避",
};
export const SNOW_PULSE_INTERVAL_MS = 1030;
export const SNOW_PULSE_EFFECT_MS = 430;

const states = new WeakMap<World, SnowBossState>();
const HAMMER_REACH = 156;
const MAX_PURSUIT_MS = 1240;
const clamp = (value: number, hi = 1): number => Math.min(hi, Math.max(0, value));
const lerp = (a: Point, b: Point, t: number): Point => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });
const offset = (origin: Point, angle: number, distance: number): Point => ({ x: origin.x + Math.cos(angle) * distance, y: origin.y + Math.sin(angle) * distance });

export function getSnowCast(world: World): SnowCast | undefined {
  const duel = getBossDuel(world);
  const state = states.get(world);
  return duel?.stage === "snow" && state?.bossId === duel.bossId ? state.cast : undefined;
}

export function getSnowHammerFilmFrame(cast: SnowCast | undefined): number | undefined {
  if (cast?.shape.kind !== "hammer_swing") return undefined;
  const { elapsedMs, tellMs, durationMs } = cast;
  // Atlas frames 0–9 telegraph, 10 is the first ground contact, 15 is neutral.
  // Sample both halves with the combat clock so the first contact cannot lead damage.
  return elapsedMs < tellMs
    ? Math.min(9, Math.floor(10 * clamp(elapsedMs / tellMs)))
    : 10 + Math.min(5, Math.floor(6 * clamp((elapsedMs - tellMs) / (durationMs - tellMs))));
}

export function getSnowPunishWindow(world: World): SnowBossState["punish"] {
  const duel = getBossDuel(world);
  const state = states.get(world);
  if (duel?.stage === "snow" && state?.bossId === duel.bossId && state.mode === "recovery") return state.punish;
  return undefined;
}

export function isInsideSnowHammer(shape: Hammer, point: Point): boolean {
  const dx = point.x - shape.origin.x, dy = point.y - shape.origin.y;
  const distance = Math.hypot(dx, dy);
  return distance <= shape.radius && (distance < 1 || dx * Math.cos(shape.angle) + dy * Math.sin(shape.angle) >= distance * Math.cos(shape.halfAngle));
}

export function isInsideSnowLane(shape: Lane, point: Point): boolean {
  const dx = shape.end.x - shape.origin.x, dy = shape.end.y - shape.origin.y;
  const lengthSquared = dx * dx + dy * dy;
  const projection = lengthSquared > 0 ? clamp(((point.x - shape.origin.x) * dx + (point.y - shape.origin.y) * dy) / lengthSquared) : 0;
  const closest = lerp(shape.origin, shape.end, projection);
  return Math.hypot(point.x - closest.x, point.y - closest.y) <= shape.radius;
}

export function getSnowSafePaths(arena: Arena, pulse: SnowPulse): readonly { minX: number; maxX: number }[] {
  const left = arena.x - arena.radius, right = arena.x + arena.radius;
  return [
    ...(pulse.minX > left ? [{ minX: Math.max(left, pulse.minX - 132), maxX: pulse.minX - 8 }] : []),
    ...(pulse.maxX < right ? [{ minX: pulse.maxX + 8, maxX: Math.min(right, pulse.maxX + 132) }] : []),
  ];
}

function createCast(world: World, arena: Arena, pattern: SnowPattern, phase: FinalBossPhase, hero: Point, boss: TransformComponent, readable: boolean): SnowCast {
  const origin = { x: boss.x, y: boss.y };
  const angle = Math.atan2(hero.y - boss.y, hero.x - boss.x);
  let shape: SnowShape, tellMs: number, activeMs: number, damageRatio: number;
  switch (pattern) {
    case "hammer_swing":
      shape = { kind: pattern, origin, angle, halfAngle: Math.PI * .34, radius: HAMMER_REACH };
      tellMs = 700 - phase * 45;
      activeMs = 270;
      damageRatio = .30 + phase * .045;
      break;
    case "ice_spikes": {
      const maxLength = getBossDuelRushDistance(arena, { ...boss, radius: 0 }, angle, 580);
      shape = { kind: pattern, origin, angle, end: offset(origin, angle, maxLength), radius: 44 + phase * 3 };
      tellMs = 955 - phase * 45;
      activeMs = 565;
      damageRatio = .37 + phase * .025;
      break;
    }
    case "glacier_charge": {
      const maxLength = getBossDuelRushDistance(arena, boss, angle, 565);
      const requested = offset(origin, angle, maxLength);
      // End the warned lane exactly where the body will impact the first pillar.
      const intercept = sweepIceCover(world, origin, requested, boss.radius);
      const distance = maxLength * (intercept?.time ?? 1);
      shape = { kind: pattern, origin, angle, end: offset(origin, angle, distance), radius: Math.max(49, boss.radius), cover: intercept?.cover, travelMs: distance / .99 };
      tellMs = 850;
      activeMs = shape.travelMs;
      damageRatio = .47 + phase * .015;
      break;
    }
    case "avalanche": {
      const { x, radius } = arena;
      // A slab is narrow enough to leave from its middle at walking speed.
      const edge = Math.min(radius, 286);
      const left = { minX: x - edge, maxX: x - 62 }, right = { minX: x + 62, maxX: x + edge };
      tellMs = 1100;
      const slabs = hero.x >= x ? [right, left] : [left, right];
      const pulses = [...slabs, { minX: x - 97, maxX: x + 97 }].map((slab, index) => ({ ...slab, impactMs: tellMs + index * SNOW_PULSE_INTERVAL_MS }));
      shape = { kind: pattern, pulses };
      activeMs = 2 * SNOW_PULSE_INTERVAL_MS + SNOW_PULSE_EFFECT_MS;
      damageRatio = .43;
      break;
    }
  }
  return { arena, shape, tellMs, durationMs: tellMs + activeMs, damageRatio, elapsedMs: 0, readable, hit: false };
}

function performCastStep(cast: SnowCast, deltaMs: number, runtime: GameRuntime, boss: TransformComponent): boolean {
  const { world, playerId } = runtime;
  const previous = cast.elapsedMs;
  const current = cast.elapsedMs = previous + deltaMs;
  const { shape, tellMs, arena } = cast;
  if (shape.kind === "glacier_charge" && current >= tellMs) {
    Object.assign(boss, lerp(shape.origin, shape.end, shape.travelMs > 0 ? clamp((current - tellMs) / shape.travelMs) : 1));
  }
  if (!cast.readable || current < tellMs) return current >= cast.durationMs;
  const player = world.components.players.get(playerId);
  const health = world.components.health.get(playerId);
  const hero = world.components.transforms.get(playerId);
  if (!hero || !player || !health) return current >= cast.durationMs;
  const velocity = world.components.velocities.get(playerId);
  const heroAt = (at: number): Point => {
    const seconds = (at - previous) / 1000;
    const projected = { ...hero, x: hero.x + (velocity?.x ?? 0) * seconds, y: hero.y + (velocity?.y ?? 0) * seconds };
    confineDuelActor(arena, playerId, playerId, projected);
    return projected;
  };
  const prior = runtime.hostileProtectionAtStepStart;
  const protectionUntil = (before: number, now: number): number => now <= Math.max(0, before - deltaMs) ? before : now > 0 ? deltaMs + now : 0;
  const dashUntil = prior ? protectionUntil(prior.dashRemainingMs, player.dashRemainingMs) : 0;
  const graceUntil = prior ? protectionUntil(prior.damageCooldownMs, player.damageCooldownMs) : 0;
  let newlyProtectedUntil = 0;
  const strike = (point: Point, at: number): boolean => {
    const vulnerable = prior ? canReceiveHostileDamage({ dashRemainingMs: dashUntil - (at - previous), damageCooldownMs: Math.max(graceUntil, newlyProtectedUntil) - (at - previous) }) : canReceiveHostileDamage(player);
    if (!vulnerable || health.current <= 0) return false;
    const damage = Math.ceil(health.max * cast.damageRatio - 1e-6);
    health.current -= damage;
    player.damageCooldownMs = getHostileHitGraceMs("aoe");
    newlyProtectedUntil = at - previous + player.damageCooldownMs;
    EventBus.emit("combat:damage", { ...point, targetId: playerId, value: damage, color: "#bdefff", isCrit: true, category: "incoming" });
    return true;
  };
  if (shape.kind === "avalanche") {
    for (const { minX, maxX, impactMs } of shape.pulses) {
      if (previous >= impactMs || current < impactMs) continue;
      const point = heroAt(impactMs);
      if (point.x >= minX && point.x <= maxX) strike(point, impactMs);
    }
  } else if (!cast.hit && shape.kind === "glacier_charge") {
    const start = Math.max(previous, tellMs), end = Math.min(current, cast.durationMs);
    if (end >= start) {
      const a = heroAt(start), b = heroAt(end);
      const bodyAt = (at: number): Point => lerp(shape.origin, shape.end, shape.travelMs > 0 ? clamp((at - tellMs) / shape.travelMs) : 1);
      const c = bodyAt(start), d = bodyAt(end);
      const time = sweepTime({ x: a.x - c.x, y: a.y - c.y }, { x: b.x - d.x, y: b.y - d.y }, { x: 0, y: 0 }, shape.radius);
      if (time !== undefined) {
        const at = start + (end - start) * time;
        cast.hit = strike(heroAt(at), at);
      }
    }
  } else if (!cast.hit && previous < tellMs && current >= tellMs) {
    const point = heroAt(tellMs);
    const inside = shape.kind === "hammer_swing" ? isInsideSnowHammer(shape, point) : isInsideSnowLane(shape, point);
    if (inside) cast.hit = strike(point, tellMs);
  }
  return current >= cast.durationMs;
}

function getFrame(cast: SnowCast): number | undefined {
  const { elapsedMs, tellMs, shape } = cast;
  if (shape.kind === "glacier_charge") return elapsedMs < tellMs * .55 ? 1 : elapsedMs < tellMs ? 2 : 3;
  const age = elapsedMs - tellMs;
  // Art contract: 0 neutral, 1–4 anticipation/acceleration, 5 contact, 6 rebound, 7 settled.
  if (age < 0) return Math.min(4, Math.floor(elapsedMs / tellMs * 5));
  if (shape.kind === "avalanche") {
    const index = Math.min(shape.pulses.length - 1, Math.floor(age / SNOW_PULSE_INTERVAL_MS));
    const beat = elapsedMs - shape.pulses[index].impactMs;
    return beat < 100 ? 5 : beat < 230 ? 6 : beat < 440 ? 7 : beat >= SNOW_PULSE_INTERVAL_MS - 130 ? 4 : 2;
  }
  return age < 90 ? 5 : age < 185 ? 6 : 7;
}

type SnowRuntime = GameRuntime & { canShowSnowAttack?(pattern: SnowPattern): boolean };

export function updateSnowBoss(deltaMs: number, runtime: SnowRuntime, duel: Arena, encounter: FinalBossEncounter): void {
  const { world, playerId } = runtime;
  const id = duel.bossId;
  const hero = world.components.transforms.get(playerId)!;
  const boss = world.components.transforms.get(id)!;
  const monster = world.components.monsters.get(id)!;
  const health = world.components.health.get(id)!;
  const velocity = world.components.velocities.get(id)!;
  let state = states.get(world);
  if (!state || state.bossId !== id) {
    state = { bossId: id, mode: "pursuit", remainingMs: MAX_PURSUIT_MS, recoveryMs: 0, cycle: 0, basicUsed: false, priorityCast: encounter.phase > 1 };
    states.set(world, state);
  }
  monster.controlledMotion = true; // Pursuit is intentional; only a visible tell can damage the hero.
  monster.controlledMotionRemainingMs = undefined;
  velocity.x = velocity.y = 0;
  const phase = encounter.phase;
  const phaseSpec = getCampaignFinalBossPhase("snow", phase);
  if (encounter.sandArmor) {
    encounter.sandArmor.remainingMs -= deltaMs;
    if (encounter.sandArmor.hp <= 0 || encounter.sandArmor.remainingMs <= 0) encounter.sandArmor = undefined;
  }
  const announce = (text: string, danger: boolean, cast?: SnowCast): void => {
    EventBus.emit("boss:phase", {
      text, danger, phase: encounter.phase, entityId: id, bossKind: "final", duel: true, snow: true,
      ...(cast ? { pattern: cast.shape.kind, windupMs: cast.tellMs, x: boss.x, y: boss.y } : {}),
    });
  };
  if (state.cast) {
    const cast = state.cast;
    const done = performCastStep(cast, deltaMs, runtime, boss);
    encounter.swingFrame = getFrame(cast);
    if (!done) return;
    const { shape } = cast;
    let crashed = false;
    if (shape.kind === "glacier_charge" && shape.cover && breakIceCover(world, shape.cover.id)) {
      encounter.sandArmor = undefined;
      world.components.hitFlashes.set(id, { remainingMs: 300, totalMs: 300 });
      crashed = true;
      announce("冰岩碎裂 · 破盾反击", false);
    }
    if (shape.kind === "avalanche") {
      encounter.sandArmor = undefined;
      announce("雪崩已停 · 趁势反击", false);
    }
    if (shape.kind !== "hammer_swing") {
      encounter.completedCasts += 1;
      state.basicUsed = false;
    }
    state.mode = "recovery";
    state.punish = crashed ? "pillar" : shape.kind === "avalanche" ? "avalanche" : undefined;
    state.remainingMs = state.recoveryMs = crashed ? 2180 : shape.kind === "avalanche" ? 2160 : shape.kind === "hammer_swing" ? 580 : 900;
    state.cast = undefined;
    encounter.swingFrame = crashed ? 6 : 7;
    return;
  }
  state.remainingMs -= deltaMs;
  if (state.mode === "transition") {
    if (state.remainingMs > 0) return;
    encounter.transitioning = false;
    state.mode = "pursuit";
  }
  if (state.mode === "recovery") {
    const elapsed = state.recoveryMs - state.remainingMs;
    encounter.swingFrame = state.punish === "pillar" && elapsed < 155 ? 6 : elapsed < 300 ? 7 : undefined;
    if (state.remainingMs > 0) return;
    state.mode = "pursuit";
    state.remainingMs = state.basicUsed ? 0 : MAX_PURSUIT_MS;
  }
  if (phase < 3 && encounter.completedCasts >= phaseSpec.requiredCasts && health.current <= getFinalBossPhaseFloor(health.max, phase, "snow")) {
    encounter.phase = phase === 1 ? 2 : 3;
    encounter.completedCasts = 0;
    encounter.transitioning = true;
    encounter.sandArmor = undefined;
    encounter.swingFrame = undefined;
    state.cycle = 0;
    state.basicUsed = false;
    state.priorityCast = true;
    state.mode = "transition";
    state.remainingMs = FINAL_BOSS_TRANSITION_MS;
    world.components.hitFlashes.set(id, { remainingMs: 420, totalMs: 420 });
    announce(`阶段 ${encounter.phase}/3 · ${getCampaignFinalBossPhase("snow", encounter.phase).label}`, true);
    return;
  }
  const dx = hero.x - boss.x, dy = hero.y - boss.y;
  const distance = Math.hypot(dx, dy);
  if (Math.abs(dx) > 13) encounter.swingFacing = dx > 0 ? -1 : 1;
  let pattern: SnowPattern | undefined;
  if (state.priorityCast || state.remainingMs <= 0) {
    state.priorityCast = false;
    pattern = phaseSpec.rotation[state.cycle++ % phaseSpec.rotation.length];
  } else if (!state.basicUsed && distance <= HAMMER_REACH - 14) {
    pattern = "hammer_swing";
    state.basicUsed = true;
  }
  if (!pattern) {
    const slow = (world.components.statuses.get(id) ?? []).reduce((multiplier, status) => Math.min(multiplier, status.slowMultiplier), 1);
    const speed = Math.min((235 + phase * 23) * slow, Math.max(0, distance - 112) * 1000 / Math.max(1, deltaMs));
    if (distance > 0) {
      velocity.x = dx / distance * speed;
      velocity.y = dy / distance * speed;
    }
    return;
  }
  const readable = runtime.canShowSnowAttack?.(pattern) ?? true;
  const cast = state.cast = createCast(world, duel, pattern, phase, hero, boss, readable);
  state.mode = "cast";
  encounter.swingFrame = 0;
  if (readable && pattern === "glacier_charge") {
    const max = Math.ceil(health.max * .105);
    encounter.sandArmor = { hp: max, max, remainingMs: cast.durationMs + 1350 };
  }
  if (pattern !== "hammer_swing") announce(readable ? SNOW_CAST_LABELS[pattern] : "霜炉重锤王 · 无伤演示", readable, cast);
}
