export interface UIOverlay<TLayout = unknown> {
  destroy(): void;
  layout?(layout: TLayout): void;
}

export class UIOverlayController<TLayout = unknown> {
  private active?: UIOverlay<TLayout>;

  get current(): UIOverlay<TLayout> | undefined {
    return this.active;
  }

  replace(overlay: UIOverlay<TLayout>): void {
    if (overlay === this.active) {
      return;
    }
    this.clear();
    this.active = overlay;
  }

  layout(layout: TLayout): void {
    this.active?.layout?.(layout);
  }

  clear(): void {
    const overlay = this.active;
    this.active = undefined;
    overlay?.destroy();
  }
}
