export interface UIElementLayout {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface UISkillTrayLayout {
  x: number;
  y: number;
  slotSize: number;
  gap: number;
  maxVisible: number;
}

export interface UILayout {
  width: number;
  height: number;
  compact: boolean;
  hudPanel: UIElementLayout;
  timer: UIElementLayout;
  health: UIElementLayout;
  experience: UIElementLayout;
  statuses: {
    difficulty: UIElementLayout;
    attackSpeed: UIElementLayout;
  };
  counters: {
    kills: UIElementLayout;
    gold: UIElementLayout;
    wave: UIElementLayout;
  };
  skillTray: UISkillTrayLayout;
  dash: UIElementLayout;
  upgrade: UIElementLayout;
  campaignToolbar: UIElementLayout;
  boss: UIElementLayout;
  notification: UIElementLayout;
  results: UIElementLayout;
}

const clampViewport = (value: number, minimum: number): number => (
  Number.isFinite(value) && value > 0 ? Math.max(value, minimum) : minimum
);

export function getUILayout(viewportWidth: number, viewportHeight: number): UILayout {
  const width = clampViewport(viewportWidth, 320);
  const height = clampViewport(viewportHeight, 480);
  const compact = width < 1000 || height > width * 1.12;

  if (compact) {
    const margin = 8;
    const hudWidth = Math.min(220, width * 0.56);
    const hudHeight = hudWidth / 3;
    const hudPanel = {
      x: margin + hudWidth / 2,
      y: margin + hudHeight / 2,
      width: hudWidth,
      height: hudHeight,
    };
    const timerWidth = Math.min(124, width * 0.31);
    const timer = {
      x: width - margin - timerWidth / 2,
      y: margin + timerWidth / 6,
      width: timerWidth,
      height: timerWidth / 3,
    };
    const counterGap = 6;
    const counterWidth = (width - margin * 2 - counterGap * 2) / 3;
    const counterHeight = counterWidth / 3;
    const statusWidth = (width - margin * 2 - 8) / 2;
    const statusY = hudPanel.y + hudPanel.height / 2 + 14;
    const counterY = statusY + 10 + 8 + counterHeight / 2;
    const counter = (index: number): UIElementLayout => ({
      x: margin + counterWidth / 2 + index * (counterWidth + counterGap),
      y: counterY,
      width: counterWidth,
      height: counterHeight,
    });
    const slotSize = Math.min(64, Math.max(48, (width - 32) / 5 - 6));
    const bossWidth = Math.min(width - 24, 430);
    const bossHeight = Math.min(72, bossWidth / 4 + 8);
    const toolbarTop = counterY + counterHeight / 2 + 8;
    const bossY = toolbarTop + 40 + 8 + bossHeight / 2;
    const notificationHeight = 104;
    const resultsWidth = Math.min(width - 24, 350);
    const resultsHeight = Math.min(height - 24, resultsWidth * 1.25);

    return {
      width,
      height,
      compact,
      hudPanel,
      timer,
      statuses: {
        difficulty: { x: margin + statusWidth / 2, y: statusY, width: statusWidth, height: 20 },
        attackSpeed: { x: width - margin - statusWidth / 2, y: statusY, width: statusWidth, height: 20 },
      },
      health: {
        x: hudPanel.x + hudPanel.width * 0.04,
        y: hudPanel.y - hudPanel.height * 0.13,
        width: hudPanel.width * 0.76,
        height: Math.max(21, hudPanel.height * 0.34),
      },
      experience: {
        x: hudPanel.x + hudPanel.width * 0.04,
        y: hudPanel.y + hudPanel.height * 0.25,
        width: hudPanel.width * 0.76,
        height: Math.max(18, hudPanel.height * 0.27),
      },
      counters: {
        kills: counter(0),
        gold: counter(1),
        wave: counter(2),
      },
      skillTray: {
        x: width / 2,
        y: height - slotSize / 2 - 10,
        slotSize,
        gap: 6,
        maxVisible: 5,
      },
      dash: {
        x: width - margin - 31,
        y: height - slotSize - 76,
        width: 62,
        height: 62,
      },
      upgrade: { x: margin + 49, y: height - slotSize - 76, width: 98, height: 38 },
      campaignToolbar: { x: width / 2, y: toolbarTop + 20, width: Math.min(width - 24, 430), height: 40 },
      boss: {
        x: width / 2,
        y: bossY,
        width: bossWidth,
        height: bossHeight,
      },
      notification: {
        x: width / 2,
        y: bossY + bossHeight / 2 + 8 + notificationHeight / 2,
        width: Math.min(width - 24, 420),
        height: notificationHeight,
      },
      results: {
        x: width / 2,
        y: height / 2,
        width: resultsWidth,
        height: resultsHeight,
      },
    };
  }

  const hudPanel = { x: 204, y: 76, width: 360, height: 120 };
  const counterWidth = 156;
  const counterHeight = 52;
  const counterX = width - counterWidth / 2 - 20;
  const slotSize = 76;
  const bossWidth = Math.min(520, width * 0.46);
  const bossY = 128 + bossWidth / 8;
  const resultsWidth = Math.min(480, width - 48);
  const resultsHeight = Math.min(600, height - 32, resultsWidth * 1.25);

  return {
    width,
    height,
    compact,
    hudPanel,
    timer: { x: width / 2, y: 44, width: 190, height: 64 },
    health: { x: 211, y: 55, width: 276, height: 36 },
    experience: { x: 211, y: 94, width: 276, height: 28 },
    statuses: {
      difficulty: { x: 104, y: 148, width: 168, height: 20 },
      attackSpeed: { x: 288, y: 148, width: 168, height: 20 },
    },
    counters: {
      kills: { x: counterX, y: 42, width: counterWidth, height: counterHeight },
      gold: { x: counterX, y: 98, width: counterWidth, height: counterHeight },
      wave: { x: counterX, y: 154, width: counterWidth, height: counterHeight },
    },
    skillTray: {
      x: width / 2,
      y: height - slotSize / 2 - 10,
      slotSize,
      gap: 10,
      maxVisible: 6,
    },
    dash: { x: width - 58, y: height - 122, width: 76, height: 76 },
    upgrade: { x: 80, y: height - 114, width: 112, height: 42 },
    campaignToolbar: { x: width / 2, y: 100, width: Math.min(440, width - 800), height: 40 },
    boss: { x: width / 2, y: bossY, width: bossWidth, height: bossWidth / 4 },
    notification: {
      x: width / 2,
      y: bossY + bossWidth / 8 + 8 + 56,
      width: Math.min(560, width - 48),
      height: 112,
    },
    results: { x: width / 2, y: height / 2, width: resultsWidth, height: resultsHeight },
  };
}
