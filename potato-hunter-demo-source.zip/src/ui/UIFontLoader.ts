import { UI_FONT } from "./UITheme";

export async function loadUIFonts(
  fontSet: Pick<FontFaceSet, "load"> | undefined = typeof document === "undefined" ? undefined : document.fonts,
  timeoutMs = 2500,
): Promise<boolean> {
  if (!fontSet) return false;
  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    const loaded = fontSet.load(`400 24px ${UI_FONT}`, "选择升级薯条技能").then(faces => faces.length > 0);
    const expired = new Promise<boolean>(resolve => { timeout = setTimeout(() => resolve(false), timeoutMs); });
    return await Promise.race([loaded, expired]);
  } catch {
    return false;
  } finally {
    if (timeout !== undefined) clearTimeout(timeout);
  }
}
