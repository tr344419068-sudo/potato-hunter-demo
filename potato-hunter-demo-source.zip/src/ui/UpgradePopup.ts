import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import { EventBus } from "../managers/EventBus";
import type { SkillConfig } from "../managers/ConfigManager";
import type { SkillChoiceHint } from "../managers/SkillManager";
import type { UILayout } from "./UILayout";
import { fitNotificationText } from "./NotificationModel";
import { getSkillUpgradeBenefit } from "./UIModel";
import { UI_ASSET_IDS, UI_COLORS, UI_DEPTHS, UI_FONT, UI_BODY_FONT } from "./UITheme";

export interface UpgradePopupPayload {
  choices: SkillConfig[];
  hints: SkillChoiceHint[];
  levels: Record<string, number>;
  sessionId?: number;
}

interface SkillCardView {
  choice: SkillConfig;
  container: Phaser.GameObjects.Container;
  hitZone: Phaser.GameObjects.Zone;
  cardSurface: Phaser.GameObjects.Graphics;
  hoverFrame: Phaser.GameObjects.Graphics;
  icon: Phaser.GameObjects.Image | Phaser.GameObjects.Arc;
  width: number;
  height: number;
}

interface CardInterior {
  left: number;
  right: number;
  top: number;
  bottom: number;
}

const TAG_LABELS: Record<string, string> = {
  projectile: "弹道", fire: "火焰", dot: "持续", ice: "冰冻", control: "控制", freeze: "冻结", slow: "减速",
  poison: "毒伤", toxic: "毒伤", aoe: "范围", explosion: "爆炸", pierce: "穿透", knockback: "击退",
  lightning: "雷电", chain: "连锁", attack_speed: "攻速", burst: "连发", tempo: "连击", growth: "成长",
  move_speed: "移速", defense: "防御", crit: "暴击", evolution: "进化", reward: "补给", heal: "回复", magnet: "磁吸", gold: "金币",
};

export class UpgradePopup {
  private readonly root: Phaser.GameObjects.Container;
  private readonly cards: SkillCardView[] = [];
  private selected = false;
  private destroyed = false;
  private suspended = false;

  constructor(private readonly scene: Phaser.Scene, private readonly payload: UpgradePopupPayload) {
    this.root = scene.add.container(0, 0).setDepth(UI_DEPTHS.overlay).setScrollFactor(0);
    this.build();
    scene.input.keyboard?.on("keydown", this.handleKeyDown);
    EventBus.on("campaign:paused", this.setSuspended);
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.scene.input.keyboard?.off("keydown", this.handleKeyDown);
    EventBus.off("campaign:paused", this.setSuspended);
    this.root.destroy(true);
  }

  layout(_layout: UILayout): void {
    if (this.destroyed || this.selected) return;
    this.cards.length = 0;
    this.root.removeAll(true);
    this.build();
  }

  getContainer(): Phaser.GameObjects.Container {
    return this.root;
  }

  private build(): void {
    const { width, height } = this.scene.scale;
    const portraitCardWidth = Math.min(320, (width - 100) / 3, (height - 176) * 320 / 420);
    const compact = width < 800 || height < 600 || portraitCardWidth < 312;
    const shade = this.scene.add.rectangle(0, 0, width, height, 0x050b15, 0.43).setOrigin(0).setInteractive();
    const cardWidth = compact ? Math.min(650, width - 24) : portraitCardWidth;
    const gap = compact ? 8 : 20;
    const cardHeight = compact ? Math.min(190, (height - 86 - gap * 2) / 3) : cardWidth * 420 / 320;
    const totalHeight = compact ? cardHeight * this.payload.choices.length + gap * (this.payload.choices.length - 1) : cardHeight;
    const top = compact ? Math.max(74, (height - totalHeight) / 2 + 12) : (height - totalHeight) / 2 + 26;
    const headerY = top - (compact ? 48 : 58);
    const headerWidth = compact ? cardWidth : cardWidth * this.payload.choices.length + gap * (this.payload.choices.length - 1);
    const title = this.scene.add.text(width / 2, headerY, "选择一项升级", { fontFamily: UI_FONT, fontSize: compact ? "22px" : "28px", fontStyle: "500", color: UI_COLORS.cream }).setOrigin(0.5);
    const instruction = this.scene.add.text(width / 2, headerY + 26, "选择时暂停 · 可稍后升级", { fontFamily: UI_BODY_FONT, fontSize: compact ? "12px" : "15px", color: "#e5eaf0" }).setOrigin(0.5);
    const closeX = (width + headerWidth) / 2 - (compact ? 28 : 36);
    const cancel = this.scene.add.text(closeX, headerY, "稍后 ×", { fontFamily: UI_BODY_FONT, fontSize: compact ? "12px" : "16px", color: UI_COLORS.gold }).setOrigin(0.5);
    const cancelZone = this.scene.add.zone(closeX, headerY, compact ? 58 : 82, 42).setInteractive({ useHandCursor: true });
    cancelZone.on("pointerdown", (pointer: Phaser.Input.Pointer) => this.cancel(pointer));
    this.root.add([shade, title, instruction, cancel, cancelZone]);
    this.payload.choices.forEach((choice, index) => {
      const x = compact ? width / 2 : width / 2 + (index - (this.payload.choices.length - 1) / 2) * (cardWidth + gap);
      const y = compact ? top + cardHeight / 2 + index * (cardHeight + gap) : top + cardHeight / 2;
      const card = this.createCard(choice, cardWidth, cardHeight, x, y, compact);
      this.cards.push(card);
      this.root.add([card.container, card.hitZone]);
    });
  }

  private createCard(choice: SkillConfig, width: number, height: number, x: number, y: number, compact: boolean): SkillCardView {
    const container = this.scene.add.container(x, y).setSize(width, height);
    const border = choice.category === "evolution" ? 0xffb703 : choice.rarity === "epic" ? 0xc9a4ed : choice.rarity === "rare" ? 0x78d6ee : 0xd4c7a5;
    const frameScale = compact ? Math.min(0.5, height / (height < 160 ? 600 : 420)) : width / 320;
    const interior = {
      left: -width / 2 + frameScale * (compact ? 90 : 60) + 3,
      right: width / 2 - frameScale * (compact ? 90 : 60) - 3,
      top: -height / 2 + frameScale * (compact ? 60 : 74) + 3,
      bottom: height / 2 - frameScale * (compact ? 60 : 81) - 3,
    };
    const interiorHeight = interior.bottom - interior.top;
    const iconSize = compact ? Math.min(96, interiorHeight - 6, width * 0.24) : width * 0.405;
    const textLeft = compact ? interior.left + iconSize + 14 : interior.left;
    const textWidth = interior.right - textLeft;
    const textX = textLeft + textWidth / 2;
    const nameHeight = compact ? Math.min(32, interiorHeight * 0.28) : 32;
    const levelHeight = compact ? 16 : 22;
    const benefitHeight = compact ? Math.min(46, interiorHeight * 0.42) : 46;
    const tagHeight = compact ? 12 : 14;
    const textGap = compact ? (interiorHeight - nameHeight - levelHeight - benefitHeight - tagHeight) / 3 : (interiorHeight - iconSize - nameHeight - levelHeight - benefitHeight - tagHeight) / 4;
    const nameTop = compact ? interior.top : interior.top + iconSize + textGap;
    const nameY = nameTop + nameHeight / 2;
    const levelY = nameTop + nameHeight + textGap + levelHeight / 2;
    const benefitY = levelY + levelHeight / 2 + textGap + benefitHeight / 2;
    const tagsY = benefitY + benefitHeight / 2 + textGap + tagHeight / 2;
    const cardSurface = this.createCardSurface(width, height, compact, frameScale, interior, textLeft, nameTop, border);
    const cardFrame = this.createCardFrame(choice, width, height, compact, frameScale, border);
    const hoverFrame = this.scene.add.graphics();
    const iconX = compact ? interior.left + iconSize / 2 : 0;
    const iconY = compact ? 0 : interior.top + iconSize / 2;
    const icon = choice.iconAssetId && AssetManager.hasTexture(this.scene, choice.iconAssetId)
      ? this.scene.add.image(iconX, iconY, AssetManager.getTextureKey(choice.iconAssetId))
      : this.scene.add.circle(iconX, iconY, iconSize / 2, parseInt(choice.color.slice(1), 16), 0.95).setStrokeStyle(2, 0xfff5d6, 0.7);
    icon.setDisplaySize(iconSize, iconSize);
    const wideCompact = compact && width >= 500;
    const name = this.fittedText(choice.name, textX, nameY, textWidth, nameHeight, wideCompact ? 23 : compact ? 20 : 24, 12, true, "#213348");
    const storedLevel = this.payload.levels[choice.id] ?? 0;
    const level = Math.max(choice.id === "peeler_blade" ? 1 : 0, storedLevel);
    const levelLabel = choice.category === "reward" ? "补给" : level > 0 ? `Lv ${level} → ${Math.min(choice.maxLevel, level + 1)}` : "新技能 · Lv 0 → 1";
    const levelChip = this.scene.add.graphics();
    const chipWidth = Math.min(textWidth, compact ? 154 : 162);
    levelChip.fillStyle(0xe3e8e5, 1).fillRoundedRect(textX - chipWidth / 2, levelY - levelHeight / 2, chipWidth, levelHeight, 6);
    const levelText = this.fittedText(levelLabel, textX, levelY, chipWidth - 8, levelHeight, wideCompact ? 14 : compact ? 13 : 16, 12, false, "#30465b");
    const auraPreview = this.payload.hints.find(hint => hint.skillId === choice.id)?.auraPreview;
    const benefit = this.fittedText(getSkillUpgradeBenefit(choice, level, auraPreview), textX, benefitY, textWidth, benefitHeight, wideCompact ? 16 : compact ? 14 : 16, 12, false, "#35465a");
    const tags = [...new Set(choice.tags.map(tag => TAG_LABELS[tag]).filter(Boolean))].slice(0, 3).join(" · ");
    const tagText = this.fittedText(tags, textX, tagsY, textWidth, tagHeight, compact ? 11 : 12, 10, false, "#586878");
    container.add([cardSurface, cardFrame, hoverFrame, icon, levelChip, name, levelText, benefit, tagText]);
    const hitZone = this.scene.add.zone(x, y, width, height).setInteractive({ useHandCursor: true });
    const card = { choice, container, hitZone, cardSurface, hoverFrame, icon, width, height };
    hitZone.on("pointerover", () => { if (!this.selected) hoverFrame.lineStyle(3, 0xffd166, 0.9).strokeRoundedRect(-width / 2 + 2, -height / 2 + 2, width - 4, height - 4, 12); });
    hitZone.on("pointerout", () => hoverFrame.clear());
    hitZone.on("pointerdown", (pointer: Phaser.Input.Pointer) => this.selectCard(card, pointer));
    return card;
  }

  private fittedText(value: string, x: number, y: number, width: number, height: number, maximum: number, minimum: number, display: boolean, color: string = UI_COLORS.cream): Phaser.GameObjects.Text {
    const text = this.scene.add.text(x, y, value, { fontFamily: display ? UI_FONT : UI_BODY_FONT, fontSize: `${maximum}px`, fontStyle: display ? "500" : "400", color, align: "center", lineSpacing: 1 }).setOrigin(0.5);
    const measure = (line: string, fontSize: number): number => { text.setFontSize(fontSize); return text.context.measureText(line).width; };
    for (let fontSize = maximum; fontSize >= minimum; fontSize--) {
      let fitted = fitNotificationText(value, width, fontSize, fontSize, measure);
      const lines = fitted.text.split("\n");
      if (lines.length > 1 && Array.from(lines[lines.length - 1]).length <= 2 && !value.includes("\n")) {
        const balanced = fitNotificationText(value, Math.min(width, measure(value, fontSize) / lines.length + fontSize), fontSize, fontSize, measure);
        if (balanced.lineCount <= fitted.lineCount) fitted = balanced;
      }
      text.setFontSize(fontSize).setText(fitted.text);
      if (text.height <= height) return text;
    }
    const lines = text.text.split("\n");
    while (text.height > height && lines.length > 1) { lines.pop(); text.setText(lines.join("\n")); }
    const lastLine = Array.from(lines[lines.length - 1]);
    while (lastLine.length && measure(lastLine.join("") + "…", minimum) > width) lastLine.pop();
    lines[lines.length - 1] = lastLine.join("").replace(/…$/, "") + "…";
    text.setText(lines.join("\n"));
    return text;
  }

  private createCardSurface(width: number, height: number, compact: boolean, frameScale: number, interior: CardInterior, textLeft: number, nameTop: number, border: number): Phaser.GameObjects.Graphics {
    const surface = this.scene.add.graphics();
    const surfaceInsetX = frameScale * (compact ? 42 : 30);
    const surfaceInsetY = frameScale * (compact ? 30 : 43);
    surface.fillStyle(0xe8eef1, 1).fillRoundedRect(-width / 2 + surfaceInsetX, -height / 2 + surfaceInsetY, width - surfaceInsetX * 2, height - surfaceInsetY * 2, 14 * frameScale);
    surface.fillGradientStyle(0xeaf1f4, 0xf2f4ee, 0xc7dce6, border, 1, 1, 1, 0.25).fillRect(interior.left - 8, interior.top - 8, interior.right - interior.left + 16, interior.bottom - interior.top + 16);
    const plateLeft = compact ? textLeft - 8 : interior.left - 8;
    const plateTop = compact ? interior.top - 8 : nameTop - 5;
    surface.fillStyle(0xf7f1e3, 1).fillRoundedRect(plateLeft, plateTop, interior.right - plateLeft + 8, interior.bottom - plateTop + 8, compact ? 8 : 10);
    surface.lineStyle(1, 0xffffff, 0.6).lineBetween(plateLeft + 8, plateTop + 1, interior.right, plateTop + 1);
    return surface;
  }

  private createCardFrame(choice: SkillConfig, width: number, height: number, compact: boolean, frameScale: number, border: number): Phaser.GameObjects.Image | Phaser.GameObjects.NineSlice | Phaser.GameObjects.Graphics {
    const frameId = UI_ASSET_IDS.cards[choice.category === "evolution" ? "evolution" : choice.rarity ?? "common"];
    if (AssetManager.hasTexture(this.scene, frameId) && (!compact || this.scene.game?.renderer?.type !== Phaser.CANVAS)) {
      const texture = AssetManager.getTextureKey(frameId);
      return compact
        ? this.scene.add.nineslice(0, 0, texture, undefined, height / frameScale, width / frameScale, 60, 60, 90, 90).setScale(frameScale).setRotation(Math.PI / 2)
        : this.scene.add.image(0, 0, texture).setDisplaySize(width, height);
    }
    const frame = this.scene.add.graphics();
    frame.lineStyle(2, border, 0.9).strokeRoundedRect(-width / 2 + 8, -height / 2 + 8, width - 16, height - 16, 12);
    return frame;
  }

  private selectCard(card: SkillCardView, pointer?: Phaser.Input.Pointer): void {
    if (this.selected || this.destroyed || this.suspended) return;
    this.consumePointer(pointer);
    this.selected = true;
    this.cards.forEach(view => view.hitZone.disableInteractive());
    EventBus.emit("skill:selected", { skillId: card.choice.id, sessionId: this.payload.sessionId ?? 0 });
    this.destroy();
  }

  private cancel(pointer?: Phaser.Input.Pointer): void {
    if (this.selected || this.destroyed || this.suspended) return;
    this.consumePointer(pointer);
    EventBus.emit("upgrade:cancel");
    this.destroy();
  }

  private consumePointer(pointer?: Phaser.Input.Pointer): void {
    if (pointer?.isDown) EventBus.emit("player:pointer-consume", { pointerId: pointer.id });
  }

  private readonly handleKeyDown = (event: KeyboardEvent): void => {
    if (this.selected || this.destroyed || this.suspended) return;
    if (event.repeat) return;
    if (event.key === "Escape") { event.preventDefault(); this.cancel(); return; }
    const index = ["1", "2", "3"].indexOf(event.key);
    if (index >= 0 && this.cards[index]) { event.preventDefault(); this.selectCard(this.cards[index]); }
  };
  private readonly setSuspended = (paused: boolean): void => {
    this.suspended = Boolean(paused);
    this.root.setVisible(!this.suspended);
  };
}
