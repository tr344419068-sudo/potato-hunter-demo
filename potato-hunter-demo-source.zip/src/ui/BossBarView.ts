import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import type { UIElementLayout } from "./UILayout";
import { getProgressRatio } from "./UIModel";
import { UI_ASSET_IDS, UI_COLORS, UI_DEPTHS, UI_FONT } from "./UITheme";

type ScalableObject = Phaser.GameObjects.Image | Phaser.GameObjects.Rectangle;

export class BossBarView {
  private readonly root: Phaser.GameObjects.Container;
  private readonly fill: Phaser.GameObjects.Rectangle;
  private readonly frame: ScalableObject;
  private readonly crown: ScalableObject;
  private readonly label: Phaser.GameObjects.Text;
  private currentLayout: UIElementLayout;
  private boss?: { hp: number; maxHp: number; name?: string };
  private suppressed = false;

  constructor(private readonly scene: Phaser.Scene, layout: UIElementLayout) {
    this.currentLayout = layout;
    this.root = scene.add.container(0, 0).setDepth(UI_DEPTHS.hud + 20).setScrollFactor(0).setVisible(false);
    this.fill = scene.add.rectangle(0, 0, 10, 10, UI_COLORS.boss).setOrigin(0, 0.5);
    this.frame = this.createAsset(UI_ASSET_IDS.bossBarFrame, 0x481d32);
    this.crown = this.createAsset(UI_ASSET_IDS.icons.boss, 0xffd166);
    this.label = scene.add.text(0, 0, "首领", {
      color: UI_COLORS.cream,
      fontFamily: UI_FONT,
      fontStyle: "700",
      fontSize: "14px",
      stroke: UI_COLORS.navy,
      strokeThickness: 4,
    }).setOrigin(0.5);
    this.root.add([this.fill, this.frame, this.crown, this.label]);
    this.layout(layout);
  }

  update(boss?: { hp: number; maxHp: number; name?: string }): void {
    this.boss = boss;
    this.updateVisibility();
    if (!boss || boss.hp <= 0 || boss.maxHp <= 0) {
      return;
    }
    this.label.setText(`${boss.name ?? "巨型炸薯机"}  ${Math.ceil(boss.hp)} / ${Math.ceil(boss.maxHp)}`);
    this.updateFill();
  }

  setSuppressed(suppressed: boolean): void {
    this.suppressed = suppressed;
    this.updateVisibility();
  }

  layout(layout: UIElementLayout): void {
    this.currentLayout = layout;
    this.frame.setPosition(layout.x, layout.y).setDisplaySize(layout.width, layout.height);
    const crownSize = layout.height * 0.72;
    this.crown.setPosition(layout.x - layout.width * 0.43, layout.y).setDisplaySize(crownSize, crownSize);
    this.label.setPosition(layout.x + layout.width * 0.03, layout.y - layout.height * 0.02);
    this.label.setFontSize(Math.max(11, Math.round(layout.height * 0.15)));
    this.updateFill();
  }

  destroy(): void {
    this.root.destroy(true);
  }

  private updateVisibility(): void {
    this.root.setVisible(!this.suppressed && Boolean(this.boss && this.boss.hp > 0 && this.boss.maxHp > 0));
  }

  private updateFill(): void {
    if (!this.boss) {
      return;
    }
    const layout = this.currentLayout;
    const innerWidth = layout.width * 0.72;
    const innerHeight = layout.height * 0.18;
    const ratio = getProgressRatio(this.boss.hp, this.boss.maxHp);
    this.fill.setPosition(layout.x - layout.width * 0.34, layout.y + layout.height * 0.12);
    this.fill.setSize(Math.max(1, innerWidth * ratio), innerHeight);
    this.fill.setStrokeStyle(Math.max(1, innerHeight * 0.12), UI_COLORS.bossShadow, 0.9);
  }

  private createAsset(assetId: string, fallbackColor: number): ScalableObject {
    if (AssetManager.hasTexture(this.scene, assetId)) {
      return this.scene.add.image(0, 0, AssetManager.getTextureKey(assetId));
    }
    return this.scene.add.rectangle(0, 0, 32, 32, fallbackColor, 0.95).setStrokeStyle(2, 0xffd166, 0.9);
  }
}
