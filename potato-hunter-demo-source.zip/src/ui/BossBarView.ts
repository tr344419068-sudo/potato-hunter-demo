import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import { FINAL_BOSS_HEALTH_BANDS } from "../systems/FinalBossPatternModel";
import type { BossHudData } from "./HUDView";
import type { UIElementLayout } from "./UILayout";
import { getProgressRatio } from "./UIModel";
import { UI_ASSET_IDS, UI_COLORS, UI_DEPTHS, UI_FONT } from "./UITheme";

type ScalableObject = Phaser.GameObjects.Image | Phaser.GameObjects.Rectangle;
const PHASE_COLORS = [0xff6059, 0xffc461, 0x6cddf0] as const;

export class BossBarView {
  private readonly root: Phaser.GameObjects.Container;
  private readonly fill: Phaser.GameObjects.Rectangle;
  private readonly frame: ScalableObject;
  private readonly crown: ScalableObject;
  private readonly label: Phaser.GameObjects.Text;
  private readonly phaseLabel: Phaser.GameObjects.Text;
  private readonly phasePlate: Phaser.GameObjects.Rectangle;
  private readonly shieldMeter: Phaser.GameObjects.Rectangle;
  private readonly segments: Array<{ track: Phaser.GameObjects.Rectangle; fill: Phaser.GameObjects.Rectangle }>;
  private currentLayout: UIElementLayout;
  private boss?: BossHudData;
  private suppressed = false;

  constructor(private readonly scene: Phaser.Scene, layout: UIElementLayout) {
    this.currentLayout = layout;
    this.root = scene.add.container(0, 0).setDepth(UI_DEPTHS.hud + 20).setScrollFactor(0).setVisible(false);
    this.fill = scene.add.rectangle(0, 0, 10, 10, UI_COLORS.boss).setOrigin(0, 0.5);
    this.frame = this.createAsset(UI_ASSET_IDS.bossBarFrame, 0x481d32);
    this.crown = this.createAsset(UI_ASSET_IDS.icons.boss, 0xffd166);
    this.phasePlate = scene.add.rectangle(0, 0, 10, 10, 0x121d2a, 0.94).setVisible(false);
    this.shieldMeter = scene.add.rectangle(0, 0, 10, 3, 0xffec9f, .98).setOrigin(0, .5).setVisible(false);
    this.segments = Array.from({ length: 6 }, () => ({
      track: scene.add.rectangle(0, 0, 10, 10, 0, 0.3).setOrigin(0, 0.5).setVisible(false),
      fill: scene.add.rectangle(0, 0, 10, 10, 0).setOrigin(0, 0.5).setVisible(false),
    }));
    this.label = scene.add.text(0, 0, "首领", {
      color: UI_COLORS.cream,
      fontFamily: UI_FONT,
      fontStyle: "700",
      fontSize: "14px",
      stroke: UI_COLORS.navy,
      strokeThickness: 4,
    }).setOrigin(0.5);
    this.phaseLabel = scene.add.text(0, 0, "", {
      color: UI_COLORS.cream,
      fontFamily: UI_FONT,
      fontStyle: "700",
      fontSize: "14px",
      stroke: UI_COLORS.navy,
      strokeThickness: 2,
    }).setOrigin(1, 0.5).setVisible(false);
    this.root.add([this.fill, this.frame, this.phasePlate, ...this.segments.flatMap(({ track, fill }) => [track, fill]), this.shieldMeter, this.crown, this.label, this.phaseLabel]);
    this.layout(layout);
  }

  update(boss?: BossHudData): void {
    this.boss = boss;
    this.updateVisibility();
    if (!boss || boss.hp <= 0 || boss.maxHp <= 0) {
      return;
    }
    this.updateContents();
  }

  setSuppressed(suppressed: boolean): void {
    this.suppressed = suppressed;
    this.updateVisibility();
  }

  layout(layout: UIElementLayout): void {
    this.currentLayout = layout;
    this.frame.setPosition(layout.x, layout.y).setDisplaySize(layout.width, layout.height);
    const crownSize = layout.height * 0.72;
    this.crown.setPosition(layout.x - layout.width * 0.43, layout.y).setDisplaySize(crownSize, crownSize);
    this.updateContents();
  }

  destroy(): void {
    this.root.destroy(true);
  }

  private updateVisibility(): void {
    this.root.setVisible(!this.suppressed && Boolean(this.boss && this.boss.hp > 0 && this.boss.maxHp > 0));
  }

  private updateContents(): void {
    if (!this.boss) {
      return;
    }
    const layout = this.currentLayout;
    const { hp, maxHp, name, phase, shield } = this.boss;
    const ratio = getProgressRatio(hp, maxHp);
    this.fill.setVisible(!phase);
    this.phaseLabel.setVisible(Boolean(phase));
    this.phasePlate.setVisible(Boolean(phase));
    this.shieldMeter.setVisible(Boolean(phase && shield));
    if (phase) {
      const textY = layout.y + layout.height * 0.011;
      const fontSize = Math.max(11, Math.min(17, Math.round(layout.height * 0.15)));
      this.phasePlate.setPosition(layout.x, layout.y + layout.height * .067).setSize(layout.width * .64, layout.height * .42);
      this.label.setOrigin(0, 0.5).setPosition(layout.x - layout.width * 0.30, textY).setFontSize(fontSize).setText(name ?? "首领");
      const suffix = phase.transitioning ? " · 转阶段" : shield ? " · 沙甲" : layout.width >= 330 ? ` · ${phase.label}` : "";
      this.phaseLabel.setPosition(layout.x + layout.width * 0.30, textY).setFontSize(fontSize)
        .setText(`阶段 ${phase.current}/3${suffix}`);
      const meterWidth = layout.width * 0.60, meterHeight = layout.height * 0.124;
      const bands = phase.bands ?? FINAL_BOSS_HEALTH_BANDS;
      const count = bands.length - 1;
      const gap = Math.max(count > 3 ? 2 : 3, meterHeight * (count > 3 ? .35 : .48));
      const usableWidth = meterWidth - gap * (count - 1);
      const y = layout.y + layout.height * 0.194;
      if (shield) this.shieldMeter.setPosition(layout.x - meterWidth / 2, y - meterHeight * .80)
        .setSize(meterWidth * getProgressRatio(shield.current, shield.max), Math.max(2, meterHeight * .25));
      this.segments.forEach(({ track, fill }, index) => {
        if (index >= count) { track.setVisible(false); fill.setVisible(false); return; }
        const lower = bands[index];
        const upper = bands[index + 1];
        const width = usableWidth * (upper - lower);
        const x = layout.x - meterWidth / 2 + usableWidth * lower + gap * index;
        const filled = getProgressRatio(ratio - lower, upper - lower);
        const color = PHASE_COLORS[Math.floor(index * 3 / count)];
        track.setFillStyle(color, .30).setPosition(x, y).setSize(width, meterHeight).setVisible(true);
        fill.setFillStyle(color).setPosition(x, y).setSize(width * filled, meterHeight).setVisible(filled > 0);
      });
      return;
    }
    for (const { track, fill } of this.segments) { track.setVisible(false); fill.setVisible(false); }
    this.label.setOrigin(0.5).setPosition(layout.x + layout.width * 0.03, layout.y - layout.height * 0.02)
      .setFontSize(Math.max(11, Math.round(layout.height * 0.15)))
      .setText(`${name ?? "巨型炸薯机"}  ${Math.ceil(hp)} / ${Math.ceil(maxHp)}`);
    const innerWidth = layout.width * 0.72;
    const innerHeight = layout.height * 0.18;
    this.fill.setPosition(layout.x - layout.width * 0.34, layout.y + layout.height * 0.12);
    this.fill.setSize(Math.max(1, innerWidth * ratio), innerHeight);
    this.fill.setStrokeStyle(Math.max(1, innerHeight * 0.12), UI_COLORS.bossShadow, 0.9);
  }

  private createAsset(assetId: string, fallbackColor: number): ScalableObject {
    if (AssetManager.hasTexture(this.scene, assetId)) {
      return this.scene.add.image(0, 0, AssetManager.getTextureKey(assetId));
    }
    return this.scene.add.rectangle(0, 0, 32, 32, fallbackColor, 0.95).setStrokeStyle(2, 0xffd166, 0.9);
  }
}
