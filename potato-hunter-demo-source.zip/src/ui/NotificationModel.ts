export interface FittedNotificationText {
  text: string;
  fontSize: number;
  lineCount: number;
}

type MeasureWidth = (text: string, fontSize: number) => number;
const MAX_LINES = 3;

function wrapLines(message: string, maxWidth: number, fontSize: number, measureWidth: MeasureWidth): string[] {
  const lines: string[] = [];
  for (const paragraph of message.split("\n")) {
    let line = "";
    for (const character of Array.from(paragraph.trim())) {
      const candidate = line + character;
      if (line && measureWidth(candidate, fontSize) > maxWidth) {
        lines.push(line.trimEnd());
        line = character.trimStart();
      } else {
        line = candidate;
      }
    }
    lines.push(line.trimEnd());
  }
  return lines;
}

export function fitNotificationText(
  message: string,
  maxWidth: number,
  baseFontSize: number,
  minimumFontSize: number,
  measureWidth: MeasureWidth,
): FittedNotificationText {
  let fontSize = Math.max(minimumFontSize, baseFontSize);
  let lines = wrapLines(message, maxWidth, fontSize, measureWidth);
  const preferOneLine = !message.includes("\n") && measureWidth(message, minimumFontSize) <= maxWidth;
  while ((lines.length > MAX_LINES || (preferOneLine && lines.length > 1)) && fontSize > minimumFontSize) {
    fontSize -= 1;
    lines = wrapLines(message, maxWidth, fontSize, measureWidth);
  }
  if (lines.length > MAX_LINES) {
    lines = lines.slice(0, MAX_LINES);
    let lastLine = Array.from(lines[MAX_LINES - 1]);
    while (lastLine.length && measureWidth(lastLine.join("") + "…", fontSize) > maxWidth) lastLine.pop();
    lines[MAX_LINES - 1] = lastLine.join("").trimEnd() + "…";
  }
  return { text: lines.join("\n"), fontSize, lineCount: lines.length };
}
