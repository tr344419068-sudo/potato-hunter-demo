import monsterConfig from "../configs/monsters.json";
import { assetUrl } from "../utils/assetUrl";

export const BESTIARY_IDS = Object.freeze([
  "fries_cultist",
  "ketchup_slug",
  "delivery_box",
  "cola_spitter",
  "shield_guard",
  "onion_flanker",
  "corn_bombardier",
  "drone_summoner",
  "mushroom_hexer",
  "chili_scatter",
  "pea_sniper",
  "donut_jumper",
  "desert_cactus",
  "desert_scorpion",
] as const);

export type BestiaryId = typeof BESTIARY_IDS[number];
export type BestiaryBehavior = "chaser" | "exploder" | "charger" | "ranged" | "guard" | "flanker" | "bombardier" | "summoner" | "hexer" | "scatter" | "sniper" | "jumper";

export interface BestiaryEntry {
  readonly id: BestiaryId;
  readonly name: string;
  readonly behavior: BestiaryBehavior;
  readonly imagePath: string;
  readonly role: string;
  readonly attack: string;
  readonly counterplay: string;
}

const behaviorCopy: Record<BestiaryBehavior, Pick<BestiaryEntry, "role" | "attack" | "counterplay">> = {
  chaser: {
    role: "近身追击",
    attack: "持续追向猎人，靠近后造成接触伤害。",
    counterplay: "保持移动，留出退路，避免被怪群包围。",
  },
  exploder: {
    role: "近身自爆",
    attack: "缓慢靠近，进入近身范围后自爆。",
    counterplay: "拉开距离，尽量在它贴身前击败它。",
  },
  charger: {
    role: "直线冲锋",
    attack: "朝猎人所在方向发起短促的直线冲刺。",
    counterplay: "向侧面移动躲开冲刺，别沿着冲锋方向后退。",
  },
  ranged: {
    role: "远程喷射",
    attack: "靠近猎人，并定期向猎人发射直线弹丸。",
    counterplay: "横向移动避开弹道，留意怪群之间的射击空隙。",
  },
  guard: {
    role: "护盾前卫",
    attack: "携带吸收伤害的冰盾，缓慢追击并造成接触伤害。",
    counterplay: "持续攻击消耗护盾，破盾后继续输出，别被堵住退路。",
  },
  flanker: {
    role: "绕侧突进",
    attack: "绕向侧面，短暂蓄力后沿预警方向突进。",
    counterplay: "离开条形预警，趁它突进后的恢复时间反击。",
  },
  bombardier: {
    role: "范围投弹",
    attack: "保持投弹距离，在猎人所在位置留下延迟爆炸的范围预警。",
    counterplay: "看到橙圈就离开，不要在同一位置停留。",
  },
  summoner: {
    role: "召唤增援",
    attack: "缓慢追击，并定期在身边召唤炸薯教徒。",
    counterplay: "优先击败召唤箱，减少增援持续加入战场。",
  },
  hexer: {
    role: "短时毒域",
    attack: "锁定猎人位置，蓄力一秒后造成初击并留下2.4秒毒域；停留其中最多受到三次间隔750毫秒的毒伤。",
    counterplay: "离开紫色预警，避开随后绿色毒域；移出圆圈便不会继续受到毒伤。",
  },
  scatter: {
    role: "扇形火力",
    attack: "保持中距离，每三秒向猎人方向发射三枚扇形弹丸。",
    counterplay: "穿过扇形弹道间隙，避免迎着火力直线靠近。",
  },
  sniper: {
    role: "锁线狙击",
    attack: "停步蓄力并锁定预警方向，一秒后发射一枚快速直线弹丸。",
    counterplay: "看到条形预警就横向移动，蓄力后的瞄准方向不会追踪。",
  },
  jumper: {
    role: "定点跃击",
    attack: "锁定近距离落点，蓄力后跃向圆圈并在落地时造成一次范围伤害。",
    counterplay: "离开落点圆圈，趁它落地后的恢复时间反击。",
  },
};

export const BESTIARY_ENTRIES: readonly BestiaryEntry[] = Object.freeze(BESTIARY_IDS.map(id => {
  const monster = monsterConfig.monsters.find(candidate => candidate.id === id);
  if (!monster) throw new Error(`Missing configured bestiary monster: ${id}`);
  const behavior = monster.behavior as BestiaryBehavior;
  const copy = behaviorCopy[behavior];
  if (!copy) throw new Error(`Unsupported bestiary behavior: ${monster.behavior}`);
  const desertPortraits: Partial<Record<BestiaryId, string>> = { desert_cactus: "assets/enemies/desert-v1/cactus.png", desert_scorpion: "assets/enemies/desert-v1/scorpion.png" };
  const imagePath = assetUrl(desertPortraits[id] ?? (["hexer", "scatter", "sniper", "jumper"].includes(behavior) ? `assets/bestiary/v4/${id}.png` : `assets/bestiary/v3/${id}.png`));
  return Object.freeze({ id, name: monster.name, behavior, imagePath, ...copy });
}));
