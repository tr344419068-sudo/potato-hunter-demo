export const UI_ASSET_IDS = {
  hudPanel: "ui_v2_hud_panel",
  timerPlaque: "ui_v2_timer_plaque",
  resourcePill: "ui_v2_resource_pill",
  progressFrame: "ui_v2_progress_frame",
  bossBarFrame: "ui_v2_boss_bar_frame",
  skillSlot: "ui_v2_skill_slot",
  notificationRibbon: "ui_v2_notification_ribbon",
  resultsPanel: "ui_v2_results_panel",
  buttonPrimary: "ui_v2_button_primary",
  buttonSecondary: "ui_v2_button_secondary",
  icons: {
    dash: "icon_skill_starch_boots",
    heart: "ui_v2_icon_heart",
    experience: "ui_v2_icon_xp_crystal",
    coin: "ui_v2_icon_coin",
    skull: "ui_v2_icon_skull",
    boss: "ui_v2_icon_boss_crown",
    clock: "ui_v2_icon_clock",
    wave: "ui_v2_icon_wave",
    level: "ui_v2_icon_level_star",
    pause: "ui_v2_icon_pause",
    settings: "ui_v2_icon_settings",
  },
  cards: {
    common: "ui_v2_card_common",
    rare: "ui_v2_card_rare",
    epic: "ui_v2_card_epic",
    evolution: "ui_v2_card_evolution",
  },
  badges: {
    new: "ui_v2_badge_new",
    levelUp: "ui_v2_badge_level_up",
    evolution: "ui_v2_badge_evolution",
  },
} as const;

export const UI_COLORS = {
  cream: "#fff5d6",
  white: "#ffffff",
  navy: "#10233f",
  gold: "#ffd166",
  health: 0xef476f,
  healthShadow: 0x6e1f3b,
  experience: 0x58d5ff,
  experienceShadow: 0x174a85,
  boss: 0xff5b4d,
  bossShadow: 0x7a1625,
  shade: 0x05070a,
} as const;

export const UI_FONT = '"PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans CJK SC", system-ui, sans-serif';
export const UI_BODY_FONT = UI_FONT;

export const UI_DEPTHS = {
  hud: 500,
  notification: 700,
  overlay: 1000,
} as const;
