import { getAuraRadius, getSkillMilestone } from "../managers/SkillProgressionModel.ts";

export interface HUDSkill {
  id: string;
  name: string;
  level: number;
}

export function getSkillUpgradeBenefit(skill: { id?: string; description: string; maxLevel: number; aura?: { radius: number } }, currentLevel: number, auraPreview?: { currentRadius: number; nextRadius: number }): string {
  const description = skill.description.split(/[。；]/)[0];
  const level = Number.isFinite(currentLevel) ? Math.max(0, Math.floor(currentLevel)) : 0;
  const nextLevel = Math.min(skill.maxLevel, level + 1);
  const milestone = getSkillMilestone(skill.id, nextLevel);
  if (skill.id === "potato_palm" || skill.id === "potato_palm_ascended") {
    return level === 0 ? "四掌轮番落地 · 击退怪群" : "伤害提升 · 范围扩大";
  }
  if (!skill.aura) return milestone ? `${milestone} · ${description.split(/[，,]/)[0]}` : description;
  const currentRadius = auraPreview?.currentRadius ?? getAuraRadius(skill.aura.radius, level);
  const nextRadius = auraPreview?.nextRadius ?? getAuraRadius(skill.aura.radius, nextLevel);
  const radiusLabel = level > 0 && level < skill.maxLevel
    ? `半径 ${Math.round(currentRadius)} → ${Math.round(nextRadius)}`
    : `半径 ${Math.round(nextRadius)}`;
  return `${radiusLabel} · ${milestone ?? description.split(/[，,]/)[0]}`;
}

export function formatElapsedTime(milliseconds: number): string {
  const safeMilliseconds = Number.isFinite(milliseconds) ? Math.max(0, milliseconds) : 0;
  const totalSeconds = Math.floor(safeMilliseconds / 1000);
  const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const seconds = (totalSeconds % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

export function getProgressRatio(value: number, maximum: number): number {
  if (!Number.isFinite(value) || !Number.isFinite(maximum) || maximum <= 0) {
    return 0;
  }
  return Math.min(1, Math.max(0, value / maximum));
}

export function getVisibleSkills<T extends HUDSkill>(skills: readonly T[], capacity: number): T[] {
  return skills.slice(0, Math.max(0, Math.floor(capacity)));
}

export function getWaveCounterLabel(_waveId: string, localizedName?: string): string {
  const name = localizedName?.trim();
  return name ? name.slice(0, 4) : "怪潮";
}

export function shouldShowUpgradeSticker(viewportWidth: number): boolean {
  return viewportWidth >= 520;
}
