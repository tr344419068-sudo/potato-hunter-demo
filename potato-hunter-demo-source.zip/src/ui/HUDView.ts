import Phaser from "phaser";
import type { DifficultyState } from "../managers/DifficultyManager";
import { AssetManager } from "../managers/AssetManager";
import { ConfigManager } from "../managers/ConfigManager";
import { EventBus } from "../managers/EventBus";
import type { UILayout, UIElementLayout } from "./UILayout";
import { formatElapsedTime, getProgressRatio, getVisibleSkills, getWaveCounterLabel, type HUDSkill } from "./UIModel";
import { UI_ASSET_IDS, UI_COLORS, UI_DEPTHS, UI_FONT } from "./UITheme";
import type { FinalBossPhase } from "../components/ComponentTypes";

export interface BossHudData {
  hp: number;
  maxHp: number;
  name?: string;
  phase?: { current: FinalBossPhase; label: string; transitioning: boolean; bands?: readonly number[] };
  shield?: { current: number; max: number };
}

export interface HudPayload {
  elapsedMs: number;
  kills: number;
  bossKills: number;
  gold: number;
  level: number;
  pendingUpgrades?: number;
  choosingUpgrade?: boolean;
  experience: number;
  experienceToNext: number;
  hp: number;
  maxHp: number;
  healthAtFeet?: boolean;
  aliveMonsters: number;
  waveMonsterId: string;
  waveLabel?: string;
  skills: HUDSkill[];
  builds: string[];
  boss?: BossHudData;
  difficulty: DifficultyState;
  dashCooldownRatio: number;
  attackSpeedBonus?: number;
  tempoStacks?: number;
  debug?: { entities: number; sparks: number };
}

type ScalableObject = Phaser.GameObjects.Image | Phaser.GameObjects.Rectangle | Phaser.GameObjects.Arc;

interface CounterView {
  frame: ScalableObject;
  icon: ScalableObject;
  text: Phaser.GameObjects.Text;
}

export class HUDView {
  private readonly root: Phaser.GameObjects.Container;
  private readonly hudPanel: ScalableObject;
  private readonly timerFrame: ScalableObject;
  private readonly timerIcon: ScalableObject;
  private readonly timerText: Phaser.GameObjects.Text;
  private readonly healthFill: Phaser.GameObjects.Rectangle;
  private readonly healthFrame: ScalableObject;
  private readonly healthIcon: ScalableObject;
  private readonly healthText: Phaser.GameObjects.Text;
  private readonly experienceFill: Phaser.GameObjects.Rectangle;
  private readonly experienceFrame: ScalableObject;
  private readonly experienceIcon: ScalableObject;
  private readonly experienceText: Phaser.GameObjects.Text;
  private readonly counters: Record<"kills" | "gold" | "wave", CounterView>;
  private readonly skillsRoot: Phaser.GameObjects.Container;
  private readonly buildText: Phaser.GameObjects.Text;
  private readonly difficultyText: Phaser.GameObjects.Text;
  private readonly attackSpeedText: Phaser.GameObjects.Text;
  private readonly dashButton: Phaser.GameObjects.Arc;
  private readonly dashCooldownArc: Phaser.GameObjects.Arc;
  private readonly dashIcon: ScalableObject;
  private readonly dashText: Phaser.GameObjects.Text;
  private readonly dashHint: Phaser.GameObjects.Text;
  private readonly upgradeButton: Phaser.GameObjects.Rectangle;
  private readonly upgradeText: Phaser.GameObjects.Text;
  private readonly debugText?: Phaser.GameObjects.Text;
  private currentLayout: UILayout;
  private payload?: HudPayload;
  private skillSignature = "";

  constructor(private readonly scene: Phaser.Scene, layout: UILayout) {
    this.currentLayout = layout;
    this.root = scene.add.container(0, 0).setDepth(UI_DEPTHS.hud).setScrollFactor(0);

    this.hudPanel = this.createAsset(UI_ASSET_IDS.hudPanel, 0x12345f, 0.94);
    this.timerFrame = this.createAsset(UI_ASSET_IDS.timerPlaque, 0x17345e, 0.98);
    this.timerIcon = this.createAsset(UI_ASSET_IDS.icons.clock, 0xffd166);
    this.timerText = this.createText("00:00", 23);

    this.healthFill = scene.add.rectangle(0, 0, 10, 10, UI_COLORS.health).setOrigin(0, 0.5);
    this.healthFrame = this.createAsset(UI_ASSET_IDS.progressFrame, 0x17345e, 0.98);
    this.healthIcon = this.createAsset(UI_ASSET_IDS.icons.heart, UI_COLORS.health);
    this.healthText = this.createText("100 / 100", 13);

    this.experienceFill = scene.add.rectangle(0, 0, 10, 10, UI_COLORS.experience).setOrigin(0, 0.5);
    this.experienceFrame = this.createAsset(UI_ASSET_IDS.progressFrame, 0x17345e, 0.98);
    this.experienceIcon = this.createAsset(UI_ASSET_IDS.icons.experience, UI_COLORS.experience);
    this.experienceText = this.createText("LV.1", 12);

    this.counters = {
      kills: this.createCounter(UI_ASSET_IDS.icons.skull),
      gold: this.createCounter(UI_ASSET_IDS.icons.coin),
      wave: this.createCounter(UI_ASSET_IDS.icons.wave),
    };

    this.skillsRoot = scene.add.container(0, 0);
    this.buildText = this.createText("", 13).setOrigin(0.5, 1);
    this.difficultyText = this.createText("", 11).setOrigin(0, 0);
    this.attackSpeedText = this.createText("", 11).setOrigin(0, 0);
    this.dashButton = scene.add.circle(0, 0, 34, 0x17345e, 0.96).setStrokeStyle(4, 0xffd166, 0.94);
    this.dashCooldownArc = scene.add.arc(0, 0, 30, -90, 270, false, 0x10233f, 0.72).setStrokeStyle(3, 0x69e8ff, 0.95);
    this.dashIcon = this.createAsset(UI_ASSET_IDS.icons.dash, 0xb4f46d);
    this.dashText = this.createText("", 24);
    this.dashHint = this.createText("冲刺", 10);
    this.dashButton.setInteractive({ useHandCursor: true }).on("pointerdown", () => EventBus.emit("player:dash-request"));
    this.upgradeButton = scene.add.rectangle(0, 0, 92, 36, 0x183852, 0.98).setStrokeStyle(2, 0xffd166, 0.9).setInteractive({ useHandCursor: true });
    this.upgradeButton.on("pointerdown", () => { if (!this.payload?.choosingUpgrade && (this.payload?.pendingUpgrades ?? 0) > 0) EventBus.emit("upgrade:open"); });
    this.upgradeText = this.createText("", 14);
    this.upgradeButton.setVisible(false);
    this.upgradeText.setVisible(false);

    const environment = (import.meta as ImportMeta & { env?: { DEV?: boolean } }).env;
    if (environment?.DEV) {
      this.debugText = this.createText("", 11).setOrigin(0, 1).setAlpha(0.72);
    }

    this.root.add([
      this.hudPanel,
      this.healthFill,
      this.experienceFill,
      this.healthFrame,
      this.experienceFrame,
      this.healthIcon,
      this.experienceIcon,
      this.healthText,
      this.experienceText,
      this.timerFrame,
      this.timerIcon,
      this.timerText,
      ...Object.values(this.counters).flatMap((counter) => [counter.frame, counter.icon, counter.text]),
      this.skillsRoot,
      this.buildText,
      this.difficultyText,
      this.attackSpeedText,
      this.dashButton,
      this.dashIcon,
      this.dashCooldownArc,
      this.dashText,
      this.dashHint,
      this.upgradeButton,
      this.upgradeText,
      ...(this.debugText ? [this.debugText] : []),
    ]);

    this.layout(layout);
  }

  update(payload: HudPayload): void {
    this.payload = payload;
    this.timerText.setText(formatElapsedTime(payload.elapsedMs));
    this.healthText.setText(`${Math.ceil(payload.hp)} / ${Math.ceil(payload.maxHp)}`);
    this.experienceText.setText(`LV.${payload.level}  ${payload.experience}/${payload.experienceToNext}`);
    this.counters.kills.text.setText(`${payload.kills}`);
    this.counters.gold.text.setText(`${payload.gold}`);
    this.counters.wave.text.setText(payload.waveLabel ?? this.getWaveLabel(payload.waveMonsterId));
    this.difficultyText.setText(`难度 ${payload.difficulty.level} · 场上 ${payload.aliveMonsters}`);
    this.attackSpeedText.setText(`攻速 +${Math.round((payload.attackSpeedBonus ?? 0) * 100)}% · 连击 ${payload.tempoStacks ?? 0}/8`);
    this.buildText.setText(payload.builds.length > 0 ? payload.builds.join(" · ") : "");
    this.debugText?.setVisible(Boolean(payload.debug));
    if (payload.debug) this.debugText?.setText(`实体 ${payload.debug.entities} · FX ${payload.debug.sparks}`);
    this.updateProgress();
    this.updateDash();
    this.updateSkills();
    this.updatePendingUpgrades(payload.pendingUpgrades ?? 0);
    this.updateSecondaryVisibility();
  }

  updatePendingUpgrades(pending: number): void {
    const visible = pending > 0 && !this.payload?.choosingUpgrade;
    this.upgradeButton.setVisible(visible);
    this.upgradeText.setVisible(visible).setText(`升级 x${pending}`);
  }

  layout(layout: UILayout): void {
    this.currentLayout = layout;
    this.place(this.hudPanel, layout.hudPanel);
    this.place(this.timerFrame, layout.timer);

    const timerIconSize = layout.timer.height * 0.55;
    this.timerIcon.setPosition(layout.timer.x - layout.timer.width * 0.29, layout.timer.y - 1).setDisplaySize(timerIconSize, timerIconSize);
    this.timerText.setPosition(layout.timer.x + layout.timer.width * 0.08, layout.timer.y - 1);
    this.timerText.setFontSize(Math.round(layout.timer.height * (layout.compact ? 0.38 : 0.35)));

    this.placeProgress(this.healthFrame, this.healthIcon, this.healthText, layout.health);
    this.placeProgress(this.experienceFrame, this.experienceIcon, this.experienceText, layout.experience);

    this.placeCounter(this.counters.kills, layout.counters.kills);
    this.placeCounter(this.counters.gold, layout.counters.gold);
    this.placeCounter(this.counters.wave, layout.counters.wave);

    this.buildText.setPosition(layout.skillTray.x, layout.skillTray.y - layout.skillTray.slotSize / 2 - 7);
    this.buildText.setFontSize(layout.compact ? 11 : 13);
    const difficultyRow = layout.statuses.difficulty;
    const attackSpeedRow = layout.statuses.attackSpeed;
    this.difficultyText.setPosition(difficultyRow.x - difficultyRow.width / 2, difficultyRow.y - difficultyRow.height / 2).setFontSize(layout.compact ? 10 : 11);
    this.attackSpeedText.setPosition(attackSpeedRow.x - attackSpeedRow.width / 2, attackSpeedRow.y - attackSpeedRow.height / 2).setFontSize(layout.compact ? 10 : 11);
    const dashRadius = Math.min(layout.dash.width, layout.dash.height) / 2;
    this.dashButton.setPosition(layout.dash.x, layout.dash.y).setRadius(dashRadius).setDisplaySize(layout.dash.width, layout.dash.height);
    this.dashCooldownArc.setPosition(layout.dash.x, layout.dash.y).setRadius(dashRadius * 0.84);
    this.dashIcon.setPosition(layout.dash.x, layout.dash.y - dashRadius * 0.14).setDisplaySize(dashRadius * 1.58, dashRadius * 1.58);
    this.dashText.setPosition(layout.dash.x, layout.dash.y - dashRadius * 0.08).setFontSize(Math.round(dashRadius * 0.72));
    this.dashHint.setPosition(layout.dash.x, layout.dash.y + dashRadius * 0.58).setFontSize(Math.max(9, Math.round(dashRadius * 0.25)));
    this.debugText?.setPosition(12, layout.height - 12);
    this.upgradeButton.setPosition(layout.upgrade.x, layout.upgrade.y).setDisplaySize(layout.upgrade.width, layout.upgrade.height);
    this.upgradeText.setPosition(layout.upgrade.x, layout.upgrade.y).setFontSize(layout.compact ? 14 : 16);
    this.updateProgress();
    this.updateDash();
    this.skillSignature = "";
    this.updateSkills();
    this.updateSecondaryVisibility();
  }

  private updateSecondaryVisibility(): void {
    const visible = !this.payload?.choosingUpgrade;
    this.root.setVisible(visible);
    for (const counter of Object.values(this.counters)) {
      for (const view of Object.values(counter)) view.setVisible(visible);
    }
    for (const view of [this.difficultyText, this.attackSpeedText, this.buildText, this.skillsRoot,
      this.dashButton, this.dashIcon, this.dashText, this.dashHint]) view.setVisible(visible);
    this.dashCooldownArc.setVisible(visible && (this.payload?.dashCooldownRatio ?? 0) > 0.001);
  }

  destroy(): void {
    this.root.destroy(true);
  }

  private createAsset(assetId: string, fallbackColor: number, fallbackAlpha = 1): ScalableObject {
    if (AssetManager.hasTexture(this.scene, assetId)) {
      return this.scene.add.image(0, 0, AssetManager.getTextureKey(assetId));
    }
    return this.scene.add.rectangle(0, 0, 32, 32, fallbackColor, fallbackAlpha).setStrokeStyle(2, 0xffd166, 0.8);
  }

  private createText(value: string, fontSize: number): Phaser.GameObjects.Text {
    return this.scene.add.text(0, 0, value, {
      color: UI_COLORS.cream,
      fontFamily: UI_FONT,
      fontStyle: "700",
      fontSize: `${fontSize}px`,
      stroke: UI_COLORS.navy,
      strokeThickness: 3,
      align: "center",
    }).setOrigin(0.5);
  }

  private createCounter(iconAssetId: string): CounterView {
    return {
      frame: this.createAsset(UI_ASSET_IDS.resourcePill, 0x17345e, 0.98),
      icon: this.createAsset(iconAssetId, 0xffd166),
      text: this.createText("0", 15),
    };
  }

  private place(object: ScalableObject, layout: UIElementLayout): void {
    object.setPosition(layout.x, layout.y).setDisplaySize(layout.width, layout.height);
  }

  private placeProgress(frame: ScalableObject, icon: ScalableObject, text: Phaser.GameObjects.Text, layout: UIElementLayout): void {
    this.place(frame, layout);
    const iconSize = layout.height * 1.22;
    icon.setPosition(layout.x - layout.width * 0.43, layout.y).setDisplaySize(iconSize, iconSize);
    text.setPosition(layout.x + layout.width * 0.06, layout.y - 1);
    text.setFontSize(Math.max(10, Math.round(layout.height * 0.38)));
  }

  private placeCounter(counter: CounterView, layout: UIElementLayout): void {
    this.place(counter.frame, layout);
    const iconSize = layout.height * 0.8;
    counter.icon.setPosition(layout.x - layout.width * 0.29, layout.y).setDisplaySize(iconSize, iconSize);
    counter.text.setPosition(layout.x + layout.width * 0.09, layout.y - 1);
    counter.text.setFontSize(Math.max(11, Math.round(layout.height * 0.32)));
  }

  private updateProgress(): void {
    if (!this.payload) {
      return;
    }
    this.placeFill(this.healthFill, this.currentLayout.health, getProgressRatio(this.payload.hp, this.payload.maxHp), UI_COLORS.healthShadow);
    if (this.payload.healthAtFeet) this.healthFill.setVisible(false);
    this.placeFill(
      this.experienceFill,
      this.currentLayout.experience,
      getProgressRatio(this.payload.experience, this.payload.experienceToNext),
      UI_COLORS.experienceShadow,
    );
  }

  private updateDash(): void {
    if (!this.payload) {
      return;
    }
    const ratio = Math.min(1, Math.max(0, this.payload.dashCooldownRatio));
    this.dashCooldownArc.setVisible(ratio > 0.001).setStartAngle(-90).setEndAngle(-90 + ratio * 360);
    this.dashButton.setAlpha(ratio > 0 ? 0.68 : 1);
    this.dashIcon.setAlpha(ratio > 0 ? 0.38 : 1);
    this.dashText.setAlpha(1).setText(ratio > 0 ? `${Math.max(1, Math.ceil(ratio * 2.2))}` : "");
    this.dashHint.setAlpha(ratio > 0 ? 0.54 : 0.92);
  }

  private placeFill(fill: Phaser.GameObjects.Rectangle, layout: UIElementLayout, ratio: number, shadowColor: number): void {
    // The authored frame's opening is x=129..511 on a 640px canvas, not the whole plaque.
    const insetX = layout.width * 0.21;
    const innerWidth = layout.width - insetX * 2;
    const innerHeight = layout.height * 0.3;
    fill.setPosition(layout.x - layout.width / 2 + insetX, layout.y + layout.height * 0.04);
    fill.setVisible(ratio > 0);
    fill.setSize(Math.max(1, innerWidth * ratio), innerHeight);
    fill.setStrokeStyle(Math.max(1, innerHeight * 0.12), shadowColor, 0.8);
  }

  private updateSkills(): void {
    if (!this.payload) {
      return;
    }
    const tray = this.currentLayout.skillTray;
    const skills = getVisibleSkills(this.payload.skills, tray.maxVisible);
    const signature = `${tray.slotSize}:${tray.maxVisible}:${skills.map((skill) => `${skill.id}:${skill.level}`).join("|")}`;
    if (signature === this.skillSignature) {
      return;
    }

    this.skillSignature = signature;
    this.skillsRoot.removeAll(true);
    const slotCount = Math.max(1, skills.length);
    const totalWidth = slotCount * tray.slotSize + (slotCount - 1) * tray.gap;
    const firstX = tray.x - totalWidth / 2 + tray.slotSize / 2;

    if (skills.length === 0) {
      this.skillsRoot.add(this.createSkillSlot(firstX, tray.y, tray.slotSize));
      return;
    }

    skills.forEach((skill, index) => {
      const slotX = firstX + index * (tray.slotSize + tray.gap);
      const slot = this.createSkillSlot(slotX, tray.y, tray.slotSize);
      const config = ConfigManager.skills.find((candidate) => candidate.id === skill.id);
      const icon = config?.iconAssetId && AssetManager.hasTexture(this.scene, config.iconAssetId)
        ? this.scene.add.image(slotX, tray.y, AssetManager.getTextureKey(config.iconAssetId))
        : this.scene.add.circle(slotX, tray.y, tray.slotSize * 0.28, 0xf4a261, 0.92);
      icon.setDisplaySize(tray.slotSize * 0.84, tray.slotSize * 0.84);
      const level = this.createText(`${skill.level}`, Math.max(10, Math.round(tray.slotSize * 0.21)))
        .setPosition(slotX + tray.slotSize * 0.29, tray.y + tray.slotSize * 0.3)
        .setOrigin(0.5);
      this.skillsRoot.add([slot, icon, level]);
    });
  }

  private createSkillSlot(x: number, y: number, size: number): ScalableObject {
    const slot = this.createAsset(UI_ASSET_IDS.skillSlot, 0x17345e, 0.96);
    slot.setPosition(x, y).setDisplaySize(size, size);
    return slot;
  }

  private getWaveLabel(waveMonsterId: string): string {
    const monsterName = ConfigManager.monsters.find((monster) => monster.id === waveMonsterId)?.name;
    return getWaveCounterLabel(waveMonsterId, monsterName);
  }
}
