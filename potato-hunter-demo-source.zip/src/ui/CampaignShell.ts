import { LOADOUTS, type LoadoutId, type Preferences, type ProgressionStore } from "../progression/ProgressionStore";
import type { RunReport } from "../campaign/RunTelemetry";
import { FINAL_BOSS_AT_MS } from "../campaign/CampaignModel";
import { getUILayout } from "./UILayout";
import { BESTIARY_ENTRIES } from "./BestiaryModel";
import { assetUrl } from "../utils/assetUrl";
import { STAGES, TRAINING_COSTS, isStageId, isTrainingId, stageUnlocked, type StageId, type TrainingId } from "../progression/CampaignGrowth";

interface EventsPort { on(event: string, fn: (...args: any[]) => void): unknown; off(event: string, fn: (...args: any[]) => void): unknown; emit(event: string, ...args: any[]): unknown }
interface ShellOptions { document?: Document; onUnlockAudio?: () => void; onPreferences?: (preferences: Preferences) => void; bossTestStage?: StageId }
const icon = (name: string) => `<img src="${assetUrl(`assets/ui/v2/icons/${name}.png`)}" alt="" draggable="false">`;
const escape = (value: unknown) => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]!));
const time = (ms: number) => `${Math.floor(ms / 60000).toString().padStart(2,"0")}:${Math.floor(ms / 1000 % 60).toString().padStart(2,"0")}`;
const TRAINING_TRACKS: ReadonlyArray<{ id: TrainingId; name: string; detail: string; icon: string }> = [
  { id: "attack", name: "磨刀", detail: "每级基础伤害 +4%", icon: "level-star" },
  { id: "health", name: "强健体魄", detail: "每级生命上限 +8", icon: "heart" },
  { id: "pickup", name: "探索技巧", detail: "每级拾取范围 +12", icon: "coin" },
];
const PEPPER_STARTER = LOADOUTS.find(loadout => loadout.id === "pepper")!;

/** Owns the DOM shell; gameplay/upgrade cards remain in Phaser. */
export class CampaignShell {
  private readonly document: Document;
  private readonly root: HTMLElement;
  private readonly panel: HTMLElement;
  private readonly toolbar: HTMLElement;
  private readonly objective: HTMLElement;
  private readonly reroll: HTMLButtonElement;
  private readonly subscriptions: Array<[string, (...args: any[]) => void]> = [];
  private atHome = true;
  private ended = false;
  private paused = false;
  private choosing = false;
  private preferencesOpen = false;
  private bestiaryOpen = false;
  private trainingOpen = false;
  private resultDestination: "training" | "loadout" | undefined;
  private lastObjective = "";
  private gameReady = false;
  private loadProgress = 0;
  private failedAssets = 0;
  private slowLoading = false;
  private loadFailed = false;
  private slowTimer: ReturnType<typeof setTimeout> | undefined;

  constructor(private readonly events: EventsPort, private readonly store: ProgressionStore, private readonly options: ShellOptions = {}) {
    this.document = options.document ?? document;
    this.root = this.document.createElement("div");
    this.root.className = "campaign-shell";
    this.root.innerHTML = `<div class="campaign-overlay"><div class="campaign-panel-host"></div></div><div class="campaign-toolbar" hidden><span class="campaign-objective"></span><button class="campaign-small-button" data-action="pause" aria-label="暂停远征">${icon("pause")}<span>暂停</span></button></div><button class="campaign-reroll campaign-small-button" data-action="reroll" hidden>换一批 · 2 次</button>`;
    this.document.body.append(this.root);
    this.panel = this.root.querySelector(".campaign-panel-host")!;
    this.toolbar = this.root.querySelector(".campaign-toolbar")!;
    this.objective = this.root.querySelector(".campaign-objective")!;
    this.reroll = this.root.querySelector(".campaign-reroll")!;
    this.renderHome();
    this.slowTimer = setTimeout(() => { this.slowLoading = true; this.updateLoadStatus(); }, 12000);
    this.root.addEventListener("click", this.onClick);
    this.root.addEventListener("input", this.onInput);
    this.document.addEventListener("visibilitychange", this.onVisibility);
    this.document.addEventListener("keydown", this.onKey, true);
    this.document.defaultView?.addEventListener("resize", this.layoutToolbar);
    this.layoutToolbar();
    this.subscribe("campaign:loading", ({ progress, failed }: { progress: number; failed: number }) => {
      this.loadProgress = progress; this.failedAssets = failed; this.updateLoadStatus();
    });
    this.subscribe("campaign:load-failed", () => { this.loadFailed = true; this.updateLoadStatus(); });
    this.subscribe("campaign:ready", ({ atHome }: { atHome: boolean }) => {
      const keepDialog = !this.gameReady && atHome && (this.preferencesOpen || this.bestiaryOpen || this.trainingOpen);
      this.gameReady = true;
      if (this.slowTimer) clearTimeout(this.slowTimer);
      this.atHome = atHome; this.ended = false; this.paused = false; this.choosing = false;
      this.toolbar.hidden = atHome; this.reroll.hidden = true;
      if (keepDialog) return;
      this.preferencesOpen = false; this.bestiaryOpen = false; this.trainingOpen = false;
      const destination = this.resultDestination;
      this.resultDestination = undefined;
      if (!atHome) this.hideOverlay();
      else if (destination === "training") this.renderTraining();
      else {
        this.renderHome();
        if (destination === "loadout") {
          this.feedback(`${PEPPER_STARTER.name} · ${PEPPER_STARTER.description}`);
          this.panel.querySelector<HTMLButtonElement>('[data-loadout="pepper"]')?.focus();
        }
      }
    });
    this.subscribe("campaign:status", (status: { phase: string; title?: string; objective: string; elapsedMs: number; choosing: boolean; finalBossDefeated?: boolean; rerollsRemaining: number }) => {
      this.choosing = status.choosing;
      this.updateToolbarVisibility();
      const label = status.phase === "respite" ? (status.title === "精英击破" ? "精英击破" : "补给休整") : status.phase === "pressure" ? "迎接挑战" : "积累经验";
      const remainingMs = Math.ceil(Math.max(0, FINAL_BOSS_AT_MS - status.elapsedMs) / 1000) * 1000;
      const text = this.options.bossTestStage ? "Boss 测试 · 击败首领" : status.phase === "finale" ? (status.finalBossDefeated ? "最终战 · 清除剩余怪物" : "最终战 · 击败首领并清场") : `${label} · 终战 ${time(remainingMs)}`;
      if (text !== this.lastObjective) { this.objective.textContent = text; this.lastObjective = text; }
      this.reroll.hidden = !status.choosing || this.paused || this.ended;
      this.reroll.disabled = status.rerollsRemaining <= 0;
      this.reroll.textContent = `换一批 · ${status.rerollsRemaining} 次`;
    });
    this.subscribe("level:choices", (payload: { rerollsRemaining?: number }) => {
      this.choosing = true; this.updateToolbarVisibility();
      this.reroll.hidden = this.atHome || this.paused;
      this.reroll.disabled = (payload.rerollsRemaining ?? 0) <= 0;
      this.reroll.textContent = `换一批 · ${payload.rerollsRemaining ?? 0} 次`;
    });
    this.subscribe("upgrade:closed", () => { this.choosing = false; this.reroll.hidden = true; this.updateToolbarVisibility(); });
    this.subscribe("campaign:paused", (paused: boolean) => {
      if (this.atHome || this.ended || this.paused === paused) return;
      this.paused = paused; this.updateToolbarVisibility(); this.reroll.hidden = paused || !this.choosing;
      if (paused) this.renderSettings(); else { this.preferencesOpen = false; this.hideOverlay(); }
    });
    this.subscribe("game:over", (result) => { if (!result.campaign) return; this.ended = true; this.paused = false; this.preferencesOpen = false; this.bestiaryOpen = false; this.toolbar.hidden = true; this.reroll.hidden = true; this.renderResults(result); });
  }

  destroy(): void {
    if (this.slowTimer) clearTimeout(this.slowTimer);
    for (const [event, fn] of this.subscriptions) this.events.off(event, fn);
    this.root.removeEventListener("click", this.onClick);
    this.root.removeEventListener("input", this.onInput);
    this.document.removeEventListener("visibilitychange", this.onVisibility);
    this.document.removeEventListener("keydown", this.onKey, true);
    this.document.defaultView?.removeEventListener("resize", this.layoutToolbar);
    this.root.remove();
  }
  private subscribe(event: string, fn: (...args: any[]) => void): void { this.events.on(event, fn); this.subscriptions.push([event, fn]); }
  private updateToolbarVisibility(): void { this.toolbar.hidden = this.atHome || this.ended || this.paused || this.choosing; }
  private readonly layoutToolbar = (): void => {
    const view = this.document.defaultView;
    const lane = getUILayout(view?.innerWidth ?? 1280, view?.innerHeight ?? 720).campaignToolbar;
    this.toolbar.style.top = `${lane.y - lane.height / 2}px`;
    this.toolbar.style.width = `${lane.width}px`;
  };
  private showOverlay(): void { this.root.querySelector<HTMLElement>(".campaign-overlay")!.hidden = false; }
  private hideOverlay(): void { this.bestiaryOpen = false; this.root.querySelector<HTMLElement>(".campaign-overlay")!.hidden = true; this.panel.innerHTML = ""; }
  private focusFirst(): void { this.panel.querySelector<HTMLElement>("button:not([disabled]),input")?.focus(); }
  private button(action: string, label: string, primary = false): string { return `<button data-action="${action}" class="campaign-button ${primary ? "primary" : "secondary"}">${label}</button>`; }

  private updateLoadStatus(): void {
    const start = this.panel.querySelector<HTMLButtonElement>('[data-action="start"]');
    const status = this.panel.querySelector<HTMLElement>(".campaign-load-status");
    if (start) start.disabled = !this.gameReady;
    if (!status) return;
    status.textContent = this.loadFailed ? "游戏加载失败，请刷新页面重试。" : this.gameReady
      ? (this.failedAssets ? "部分素材加载失败，如显示异常请刷新重试。" : "")
      : `战斗资源加载中 ${Math.round(Math.max(0, Math.min(1, this.loadProgress)) * 100)}%${this.slowLoading ? " · 网络较慢，请稍候或刷新重试" : ""}${this.failedAssets ? " · 部分素材加载失败" : ""}`;
  }

  private renderHome(): void {
    this.bestiaryOpen = false; this.trainingOpen = false;
    this.showOverlay();
    if (this.options.bossTestStage) {
      const desert = this.options.bossTestStage === "desert";
      this.panel.innerHTML = `<section class="campaign-dialog" aria-labelledby="boss-test-title"><span class="campaign-eyebrow">Boss 测试 · ${desert ? "香料沙海" : "青酱草甸"}</span><h1 id="boss-test-title">${desert ? "沙海堡垒之王" : "堡垒暴君"}</h1><p>从第一阶段直接开打。已配好胡椒加特林、热油瓶和飞掠长签。</p><div class="campaign-dialog-actions">${this.button("start", "开始 Boss 测试", true)}</div><p class="campaign-load-status" role="status"></p><small>移动：WASD / 方向键 / 拖动　冲刺：空格或触屏按钮</small></section>`;
      this.updateLoadStatus(); this.focusFirst();
      return;
    }
    const p = this.store.getProfile();
    const campaign = this.store.getCampaignProgress();
    const selectedStage = STAGES.find(stage => stage.id === campaign.selectedStage) ?? STAGES[0];
    this.panel.innerHTML = `<main class="campaign-home" aria-label="土豆远征主菜单">
      <header class="campaign-home-header"><span class="campaign-brand">POTATO HUNTER <span>／ 第一章</span></span><div class="campaign-home-tools"><span class="campaign-wallet">${icon("coin")}<b>${p.gold}</b></span><button data-action="settings" class="campaign-small-button" aria-label="声音与显示设置">${icon("settings")}</button></div></header>
      <div class="campaign-home-body"><div class="campaign-home-visual"><figure class="campaign-camp-art"><img src="${assetUrl("assets/ui/campaign-v3/camp.png")}" alt="" draggable="false"></figure><span class="campaign-hero-caption">小小土豆，大大远征。</span></div>
      <section class="campaign-brief"><span class="campaign-eyebrow">${selectedStage.name} · 3 分钟进入终战</span><h1>土豆远征</h1><p class="campaign-intro">穿过怪物潮，打造你的技能组合。<br>击败${selectedStage.id === "desert" ? "沙海堡垒之王" : "堡垒暴君"}，把战利品带回家。</p><div class="campaign-chapter-track"><span>整装出发</span><i></i><span>精英挑战</span><i></i><span>最终决战</span></div>
      <div class="campaign-loadout-heading"><h2>选择关卡</h2><span>首通解锁下一站</span></div><div class="campaign-stage-list" aria-label="选择关卡">${STAGES.map((stage, index) => { const unlocked = stageUnlocked(campaign, stage.id); const selected = campaign.selectedStage === stage.id; const cleared = campaign.clearedStages.includes(stage.id); const label = !unlocked ? '通关草甸解锁' : cleared ? (selected ? '已通关 · 已选择' : '已通关') : selected ? '已选择' : '选择'; return `<button type="button" data-stage="${stage.id}" aria-pressed="${selected}" class="campaign-stage ${selected ? 'selected' : ''}" ${unlocked ? '' : 'disabled'}><span>${String(index + 1).padStart(2,'0')}</span><strong>${stage.name}</strong><small>${label}</small></button>`; }).join('')}</div>
      <div class="campaign-loadout-heading"><h2>选择起手武器</h2><span>解锁玩法，不购买数值</span></div><div class="campaign-loadouts">${LOADOUTS.map(l => {
        const unlocked = p.unlockedLoadouts.includes(l.id), selected = p.selectedLoadout === l.id;
        return `<button data-loadout="${l.id}" aria-pressed="${selected}" class="campaign-loadout ${selected ? "selected" : ""} ${unlocked ? "" : "locked"}"><img src="${assetUrl(l.iconPath)}" alt="" draggable="false"><strong>${l.name}</strong><small>${l.id === "peeler" ? "均衡 · 穿透" : l.id === "pepper" ? "攻速 · 连击" : "连锁 · 控场"}</small><span>${selected ? "✓ 已选择" : unlocked ? "选择武器" : `${l.price} 金币解锁`}</span></button>`;
      }).join("")}</div><div class="campaign-home-footer"><div class="campaign-camp-actions">${this.button("start","开始远征",true)}${this.button("training","营地训练")}${this.button("bestiary","怪物图鉴")}</div><p class="campaign-load-status" role="status"></p><p>移动：WASD / 方向键 / 拖动　冲刺：空格<br>自动攻击 · 经验升级 · 每局 2 次换牌</p></div><p class="campaign-feedback" role="status"></p></section></div>
      <footer class="campaign-meta"><span>远征 ${p.totalRuns} 次 · 胜利 ${p.victories} 次</span><span>先活下来，再变得更强。</span></footer></main>`;
    this.updateLoadStatus();
  }

  private renderTraining(): void {
    if (!this.atHome) return;
    this.trainingOpen = true; this.preferencesOpen = false; this.bestiaryOpen = false; this.showOverlay();
    const p = this.store.getProfile();
    const training = this.store.getCampaignProgress().training;
    this.panel.innerHTML = `<section class="campaign-dialog campaign-training" role="dialog" aria-modal="true" aria-labelledby="training-title"><header class="training-header"><div><span class="campaign-eyebrow">CAMP TRAINING · 永久成长</span><h1 id="training-title">营地训练</h1><p>每次远征带回金币，为下一场冒险做准备。</p></div><span class="campaign-wallet">${icon('coin')}<b>${p.gold}</b></span></header><div class="training-list">${TRAINING_TRACKS.map(track => {
      const level = training[track.id], cost = TRAINING_COSTS[level];
      return `<article class="training-row"><span class="training-icon">${icon(track.icon)}</span><div class="training-copy"><strong>${track.name} <small>Lv.${level} / ${TRAINING_COSTS.length}</small></strong><span>${track.detail}</span><div class="training-pips" aria-hidden="true">${TRAINING_COSTS.map((_, i) => `<i class="${i < level ? 'filled' : ''}"></i>`).join('')}</div></div><button class="campaign-button secondary" data-training="${track.id}" ${cost === undefined ? 'disabled' : ''}>${cost === undefined ? '已满级' : `${cost} 金币升级`}</button></article>`;
    }).join('')}</div><p class="campaign-feedback" role="status"></p><div class="campaign-dialog-actions">${this.button('close-training','返回营地',true)}</div></section>`;
    this.focusFirst();
  }

  private renderBestiary(): void {
    if (!this.atHome || this.ended || this.paused || this.choosing || this.preferencesOpen) return;
    this.bestiaryOpen = true;
    this.showOverlay();
    this.panel.innerHTML = `<section class="campaign-bestiary campaign-dialog" role="dialog" aria-modal="true" aria-labelledby="campaign-bestiary-title" aria-describedby="campaign-bestiary-intro">
      <header class="campaign-bestiary-header"><div><span class="campaign-eyebrow">营地手册 · ${BESTIARY_ENTRIES.length} 种怪物</span><h1 id="campaign-bestiary-title">怪物图鉴</h1></div>${this.button("close-bestiary", "返回营地")}</header>
      <p id="campaign-bestiary-intro" class="campaign-bestiary-intro">出发前认识对手。记住攻击方式，给自己留出退路。</p>
      <div class="campaign-bestiary-scroll" role="region" aria-label="怪物介绍，可滚动" tabindex="0"><div class="campaign-bestiary-grid">${BESTIARY_ENTRIES.map(entry => `<article class="campaign-bestiary-card" data-monster-id="${entry.id}" aria-labelledby="bestiary-${entry.id}">
        <div class="campaign-bestiary-portrait"><img src="${entry.imagePath}" alt="${escape(entry.name)}" width="320" height="320" draggable="false" decoding="async"></div>
        <div class="campaign-bestiary-copy"><span class="campaign-bestiary-role">${escape(entry.role)}</span><h2 id="bestiary-${entry.id}">${escape(entry.name)}</h2><dl><dt>攻击方式</dt><dd>${escape(entry.attack)}</dd><dt>应对方法</dt><dd>${escape(entry.counterplay)}</dd></dl></div>
      </article>`).join("")}</div></div>
      <footer class="campaign-bestiary-footer"><span>仅在营地查看 · 战斗中不会弹出</span>${this.button("close-bestiary", "返回营地", true)}</footer>
    </section>`;
    this.focusFirst();
  }

  private closeBestiary(): void {
    if (!this.atHome || !this.bestiaryOpen) return;
    this.renderHome();
    this.panel.querySelector<HTMLElement>('[data-action="bestiary"]')?.focus();
  }

  private renderSettings(): void {
    this.bestiaryOpen = false; this.showOverlay(); this.preferencesOpen = true;
    const p = this.store.getProfile().preferences;
    this.panel.innerHTML = `<section class="campaign-dialog" role="dialog" aria-modal="true" aria-labelledby="campaign-settings-title"><span class="campaign-eyebrow">${this.atHome ? "远征设置" : "战斗已暂停"}</span><h1 id="campaign-settings-title">${this.atHome ? "声音与显示" : "歇一口气"}</h1><p>${this.options.bossTestStage ? "设置仅在当前测试页面生效。" : "声音与显示偏好会自动保存。"}</p><label class="campaign-setting">背景音乐 <output>${Math.round(p.musicVolume * 100)}%</output><input name="musicVolume" type="range" min="0" max="1" step=".01" value="${p.musicVolume}" aria-label="背景音乐音量"></label><label class="campaign-setting">战斗音效 <output>${Math.round(p.sfxVolume * 100)}%</output><input name="sfxVolume" type="range" min="0" max="1" step=".01" value="${p.sfxVolume}" aria-label="战斗音效音量"></label><label class="campaign-check"><input name="reducedEffects" type="checkbox" ${p.reducedEffects ? "checked" : ""}>减少装饰性粒子 <span>保留危险预警和命中提示</span></label><p class="campaign-feedback" role="status"></p><div class="campaign-dialog-actions">${this.button(this.atHome ? "close-settings" : "resume",this.atHome ? "返回营地" : "继续远征",true)}${this.atHome ? "" : this.button("abandon",this.options.bossTestStage ? "结束测试" : "结束本次远征")}</div>${this.atHome ? "" : "<small>切换到其他页面会暂停；回来后点击继续。</small>"}</section>`;
    this.focusFirst();
  }

  private renderResults(r: { outcome: string; stage?: StageId; elapsedMs: number; kills: number; bossKills: number; level: number; gold: number; build?: string[]; settlement?: {awarded: number; firstClearBonus?: number; unlockedStage?: StageId; persisted: boolean; profile: {gold: number}}; telemetry?: RunReport }): void {
    this.showOverlay();
    const won = r.outcome === "victory";
    if (this.options.bossTestStage) {
      this.panel.innerHTML = `<section class="campaign-dialog" role="dialog" aria-modal="true" aria-labelledby="boss-test-result"><span class="campaign-eyebrow">Boss 测试 · ${time(r.elapsedMs)}</span><h1 id="boss-test-result">${won ? "首领已击败" : "本次测试结束"}</h1><p>测试不发放奖励，也不影响正式存档。</p><div class="campaign-dialog-actions">${this.button("retry", "再打一局", true)}</div></section>`;
      this.focusFirst();
      return;
    }
    const sources: Record<string, string> = { MonsterContactSystem: "近身接触", MonsterBehaviorSystem: "敌方技能", AoeWarningSystem: "范围危险", EnemyProjectileSystem: "敌方弹道", DeathSystem: "敌人死亡爆炸", StatusEffectSystem: "持续伤害" };
    const damage = Object.entries(r.telemetry?.damageBySource ?? {}).sort((a,b)=>b[1]-a[1]);
    const stageName = STAGES.find(stage => stage.id === r.stage)?.name ?? STAGES[0].name;
    const progress = this.store.getCampaignProgress();
    const profile = this.store.getProfile();
    const gold = profile.gold;
    const unlocked = STAGES.find(stage => stage.id === r.settlement?.unlockedStage && stageUnlocked(progress, stage.id));
    const train = TRAINING_TRACKS.map(track => ({ ...track, cost: TRAINING_COSTS[progress.training[track.id]] as number | undefined }))
      .filter((track): track is typeof track & { cost: number } => track.cost !== undefined)
      .sort((a, b) => a.cost - b.cost || Number(b.id === "health") - Number(a.id === "health"))[0];
    const canTrain = train !== undefined && gold >= train.cost;
    const recommendPepper = r.stage !== "desert" && (r.settlement?.awarded ?? 0) > 0 && !profile.unlockedLoadouts.includes(PEPPER_STARTER.id);
    const pepperGap = PEPPER_STARTER.price - gold;
    const canChangeStarter = recommendPepper && pepperGap <= 0;
    const starterNotice = recommendPepper ? (canChangeStarter ? `${PEPPER_STARTER.name} · ${PEPPER_STARTER.price} 金币解锁攻速起手` : `${PEPPER_STARTER.name} · 还差 ${pepperGap} 金币解锁`) : "";
    const next = unlocked ? `已解锁新关卡：${unlocked.name}${canTrain ? " · 也可回营地训练" : ""}` : canChangeStarter ? "下一局试试高速连射，优先压制单体。" : canTrain ? `${train.cost} 金币可训练「${train.name}」 · ${train.detail}`
      : train ? `距「${train.name}」训练还差 ${train.cost - gold} 金币` : "营地训练已满级";
    const primary = unlocked ? this.button("next-stage", `前往${unlocked.name}`, true)
      : canChangeStarter ? this.button("result-loadout", "看看新起手", true)
      : canTrain ? this.button("result-training", "去营地训练", true) : this.button("retry", "再来一局", true);
    const secondary = unlocked && canChangeStarter ? this.button("result-loadout", "看看新起手")
      : !unlocked && (canTrain || canChangeStarter) ? this.button("retry", "再来一局") : this.button("home", "返回营地");
    this.panel.innerHTML = `<section class="campaign-results campaign-dialog" role="dialog" aria-modal="true" aria-labelledby="campaign-result-title">
      <figure class="campaign-result-art"><img src="${assetUrl(`assets/ui/campaign-v3/${won ? "victory" : "retry"}.png`)}" alt="" draggable="false"></figure>
      <div class="campaign-result-content"><div class="campaign-result-emblem">${icon(won ? "boss-crown" : "level-star")}</div><span class="campaign-eyebrow">${escape(stageName)} · ${won ? "已通关" : "远征结束"}</span><h1 id="campaign-result-title">${won ? "远征胜利" : "整装，再战"}</h1><p>${won ? "首领倒下了。战利品归你！" : "保留战利品，调整构筑，再试一次。"}</p><div class="campaign-result-stats"><div><b>${time(r.elapsedMs)}</b><span>生存时间</span></div><div><b>${r.kills}</b><span>击败怪物</span></div><div><b>${r.bossKills}</b><span>击败首领</span></div><div><b>Lv ${r.level}</b><span>本局等级</span></div></div><div class="campaign-reward">${icon("coin")}<div><span>本次带回</span><b>+${r.settlement?.awarded ?? 0}</b></div><small>营地金币 ${r.settlement?.profile.gold ?? gold}${r.settlement?.firstClearBonus ? `<br>首通奖励 +${r.settlement.firstClearBonus}` : ""}</small></div><p class="campaign-save-status ${r.settlement?.persisted ? "" : "warning"}">${r.settlement?.persisted ? "✓ 战利品已保存" : "未能保存 · 仅在当前页面保留，请勿关闭页面"}</p><div class="campaign-run-insight"><span>构筑</span><p>${escape(r.build?.length ? r.build.join(" · ") : "基础武器成长")}</p>${damage.length ? `<span>主要承伤来源</span><p>${escape(sources[damage[0][0]] ?? "战斗伤害")} · ${Math.round(damage[0][1])}　恢复 ${Math.round(r.telemetry?.healing ?? 0)}</p>` : ""}</div>
      <p class="campaign-unlock-notice">${escape(next)}${starterNotice ? `<br>${escape(starterNotice)}` : ""}</p><div class="campaign-dialog-actions">${primary}${secondary}</div></div></section>`;
    if (unlocked) this.panel.querySelector<HTMLButtonElement>('[data-action="next-stage"]')?.setAttribute("data-next-stage", unlocked.id);
    this.focusFirst();
  }

  private feedback(text: string): void { const node = this.panel.querySelector(".campaign-feedback"); if (node) node.textContent = text; }
  private readonly onClick = (event: Event): void => {
    const target = (event.target as HTMLElement).closest<HTMLButtonElement>("button");
    if (!target || target.disabled) return;
    const stage = target.dataset.stage;
    if (stage && this.atHome && isStageId(stage)) {
      const result = this.store.selectStage(stage);
      this.renderHome();
      if (result.ok && !result.persisted) this.feedback("关卡选择未能保存 · 当前页面仍可使用。");
      return;
    }
    const trainingId = target.dataset.training;
    if (trainingId && this.atHome && this.trainingOpen && isTrainingId(trainingId)) {
      const result = this.store.upgradeTraining(trainingId);
      this.renderTraining();
      this.feedback(result.ok ? (result.persisted ? '训练完成，下一次远征生效。' : '训练已生效，但本次无法保存。') : '金币不足，完成远征可获得金币。');
      return;
    }
    const id = target.dataset.loadout as LoadoutId | undefined;
    if (id) {
      const profile = this.store.getProfile();
      if (!profile.unlockedLoadouts.includes(id)) {
        const purchased = this.store.purchaseLoadout(id);
        if (!purchased.ok) { this.feedback("金币不足。完成远征就能带回战利品。"); return; }
      }
      const selected = this.store.selectLoadout(id); this.renderHome();
      if (!selected.persisted) this.feedback("未能保存选择 · 当前页面仍可使用。");
      return;
    }
    switch (target.dataset.action) {
      case "next-stage": {
        const next = target.dataset.nextStage;
        if (this.gameReady && this.ended && isStageId(next) && this.store.selectStage(next).ok) this.startFromShell();
        break;
      }
      case "result-training": case "result-loadout":
        if (this.ended) { this.resultDestination = target.dataset.action === "result-training" ? "training" : "loadout"; this.events.emit("campaign:home"); }
        break;
      case "start": case "retry": if (this.gameReady) this.startFromShell(); break;
      case "home": this.bestiaryOpen = false; this.events.emit("campaign:home"); break;
      case "bestiary": this.renderBestiary(); break;
      case "training": this.renderTraining(); break;
      case "close-training": if (this.atHome && this.trainingOpen) this.renderHome(); break;
      case "close-bestiary": this.closeBestiary(); break;
      case "settings": this.options.onUnlockAudio?.(); this.renderSettings(); break;
      case "close-settings": this.preferencesOpen = false; this.renderHome(); break;
      case "pause": this.pause(); break;
      case "resume": this.paused = false; this.preferencesOpen = false; this.updateToolbarVisibility(); this.reroll.hidden = !this.choosing; this.options.onUnlockAudio?.(); this.events.emit("campaign:pause", false); this.hideOverlay(); if (!this.toolbar.hidden) this.toolbar.querySelector<HTMLElement>("button")?.focus(); break;
      case "abandon": this.preferencesOpen = false; this.events.emit("campaign:abandon"); break;
      case "reroll": this.events.emit("upgrade:reroll"); break;
    }
  };
  private startFromShell(): void {
    this.atHome = false; this.ended = false; this.preferencesOpen = false; this.bestiaryOpen = false;
    this.options.onUnlockAudio?.(); this.events.emit("campaign:start"); this.hideOverlay();
  }
  private readonly onInput = (event: Event): void => {
    const input = event.target as HTMLInputElement;
    if (!["musicVolume", "sfxVolume", "reducedEffects"].includes(input.name)) return;
    const patch = input.name === "reducedEffects" ? { reducedEffects: input.checked } : { [input.name]: Number(input.value) };
    const saved = this.store.setPreferences(patch);
    const output = input.parentElement?.querySelector("output"); if (output) output.textContent = `${Math.round(Number(input.value) * 100)}%`;
    this.options.onPreferences?.(this.store.getProfile().preferences);
    if (!saved.persisted) this.feedback("设置未能保存 · 当前页面仍然生效。");
  };
  private pause(): void { if (this.atHome || this.ended || this.paused) return; this.paused = true; this.toolbar.hidden = true; this.reroll.hidden = true; this.events.emit("campaign:pause", true); this.renderSettings(); }
  private readonly onVisibility = (): void => { if (this.document.hidden) this.pause(); };
  private readonly onKey = (event: KeyboardEvent): void => {
    if (event.key === "Escape") {
      event.preventDefault(); event.stopImmediatePropagation();
      if (event.repeat) return;
    }
    if (event.key === "Escape") { if (this.atHome && this.bestiaryOpen) this.closeBestiary(); else if (this.atHome && this.trainingOpen) this.renderHome(); else if (this.atHome && this.preferencesOpen) { this.preferencesOpen = false; this.renderHome(); } else if (!this.atHome && !this.ended) { if (!this.paused) this.pause(); else this.root.querySelector<HTMLButtonElement>('[data-action="resume"]')?.click(); } }
    if (!this.root.querySelector<HTMLElement>(".campaign-overlay")!.hidden) event.stopPropagation();
    if (event.key === "Tab" && !this.root.querySelector<HTMLElement>(".campaign-overlay")!.hidden) {
      const nodes = [...this.panel.querySelectorAll<HTMLElement>('button:not([disabled]),input')];
      const first=nodes[0], last=nodes[nodes.length - 1];
      if (event.shiftKey && this.document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && this.document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  };
}
