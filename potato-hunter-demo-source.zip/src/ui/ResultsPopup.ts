import Phaser from "phaser";
import { AssetManager } from "../managers/AssetManager";
import type { UILayout, UIElementLayout } from "./UILayout";
import { formatElapsedTime } from "./UIModel";
import { UI_ASSET_IDS, UI_COLORS, UI_DEPTHS, UI_FONT } from "./UITheme";

export interface GameOverPayload {
  elapsedMs: number;
  kills: number;
  bossKills: number;
  gold: number;
  level: number;
}

type ScalableObject = Phaser.GameObjects.Image | Phaser.GameObjects.Rectangle | Phaser.GameObjects.Arc;

interface StatRow {
  icon: ScalableObject;
  label: Phaser.GameObjects.Text;
  value: Phaser.GameObjects.Text;
}

export class ResultsPopup {
  private readonly root: Phaser.GameObjects.Container;
  private readonly shade: Phaser.GameObjects.Rectangle;
  private readonly panel: ScalableObject;
  private readonly title: Phaser.GameObjects.Text;
  private readonly rows: StatRow[];
  private readonly restartButton: ScalableObject;
  private readonly restartText: Phaser.GameObjects.Text;
  private destroyed = false;

  constructor(
    private readonly scene: Phaser.Scene,
    payload: GameOverPayload,
    private readonly onRestart: () => void,
    layout: UILayout,
  ) {
    this.root = scene.add.container(0, 0).setDepth(UI_DEPTHS.overlay).setScrollFactor(0);
    this.shade = scene.add.rectangle(0, 0, layout.width, layout.height, UI_COLORS.shade, 0.82).setOrigin(0);
    this.panel = this.createAsset(UI_ASSET_IDS.resultsPanel, 0x17345e, 0.98);
    this.title = this.createText("本局战绩", 34, UI_COLORS.gold);
    this.rows = [
      this.createStatRow(UI_ASSET_IDS.icons.clock, "生存时间", formatElapsedTime(payload.elapsedMs)),
      this.createStatRow(UI_ASSET_IDS.icons.level, "最终等级", `${payload.level}`),
      this.createStatRow(UI_ASSET_IDS.icons.skull, "消灭怪物", `${payload.kills}`),
      this.createStatRow(UI_ASSET_IDS.icons.boss, "击败首领", `${payload.bossKills}`),
      this.createStatRow(UI_ASSET_IDS.icons.coin, "获得金币", `${payload.gold}`),
    ];
    this.restartButton = this.createAsset(UI_ASSET_IDS.buttonPrimary, 0xf4a261, 1);
    this.restartText = this.createText("再来一局", 20, UI_COLORS.cream);
    this.restartButton.setInteractive({ useHandCursor: true });
    this.restartButton.on(Phaser.Input.Events.POINTER_OVER, this.handleButtonOver);
    this.restartButton.on(Phaser.Input.Events.POINTER_OUT, this.handleButtonOut);
    this.restartButton.on(Phaser.Input.Events.POINTER_DOWN, this.handleRestart);

    this.root.add([
      this.shade,
      this.panel,
      this.title,
      ...this.rows.flatMap((row) => [row.icon, row.label, row.value]),
      this.restartButton,
      this.restartText,
    ]);
    this.layout(layout);
    this.playIntro();
  }

  layout(layout: UILayout): void {
    this.shade.setSize(layout.width, layout.height);
    this.place(this.panel, layout.results);
    const panel = layout.results;
    this.title.setPosition(panel.x, panel.y - panel.height * 0.33);
    this.title.setFontSize(Math.round(panel.width * 0.075));

    const firstRowY = panel.y - panel.height * 0.18;
    const rowGap = panel.height * 0.105;
    const iconSize = Math.min(42, panel.width * 0.095);
    this.rows.forEach((row, index) => {
      const y = firstRowY + index * rowGap;
      row.icon.setPosition(panel.x - panel.width * 0.28, y).setDisplaySize(iconSize, iconSize);
      row.label.setPosition(panel.x - panel.width * 0.12, y).setOrigin(0, 0.5);
      row.value.setPosition(panel.x + panel.width * 0.28, y).setOrigin(1, 0.5);
      row.label.setFontSize(Math.max(13, Math.round(panel.width * 0.038)));
      row.value.setFontSize(Math.max(14, Math.round(panel.width * 0.043)));
    });

    const buttonWidth = panel.width * 0.58;
    const buttonHeight = buttonWidth / 3;
    const buttonY = panel.y + panel.height * 0.36;
    this.restartButton.setPosition(panel.x, buttonY).setDisplaySize(buttonWidth, buttonHeight);
    this.restartText.setPosition(panel.x, buttonY - buttonHeight * 0.03);
    this.restartText.setFontSize(Math.max(16, Math.round(buttonHeight * 0.3)));
  }

  destroy(): void {
    if (this.destroyed) {
      return;
    }
    this.destroyed = true;
    this.restartButton.off(Phaser.Input.Events.POINTER_OVER, this.handleButtonOver);
    this.restartButton.off(Phaser.Input.Events.POINTER_OUT, this.handleButtonOut);
    this.restartButton.off(Phaser.Input.Events.POINTER_DOWN, this.handleRestart);
    this.root.destroy(true);
  }

  private readonly handleButtonOver = (): void => {
    this.scene.tweens.add({ targets: [this.restartButton, this.restartText], scale: 1.05, duration: 90, ease: "Quad.easeOut" });
  };

  private readonly handleButtonOut = (): void => {
    this.scene.tweens.add({ targets: [this.restartButton, this.restartText], scale: 1, duration: 90, ease: "Quad.easeOut" });
  };

  private readonly handleRestart = (): void => {
    if (this.destroyed) {
      return;
    }
    this.onRestart();
  };

  private createStatRow(iconAssetId: string, label: string, value: string): StatRow {
    return {
      icon: this.createAsset(iconAssetId, 0xffd166, 1),
      label: this.createText(label, 16),
      value: this.createText(value, 17, UI_COLORS.gold),
    };
  }

  private createText(value: string, fontSize: number, color: string = UI_COLORS.cream): Phaser.GameObjects.Text {
    return this.scene.add.text(0, 0, value, {
      color,
      fontFamily: UI_FONT,
      fontStyle: "700",
      fontSize: `${fontSize}px`,
      stroke: UI_COLORS.navy,
      strokeThickness: 4,
    }).setOrigin(0.5);
  }

  private createAsset(assetId: string, fallbackColor: number, fallbackAlpha: number): ScalableObject {
    if (AssetManager.hasTexture(this.scene, assetId)) {
      return this.scene.add.image(0, 0, AssetManager.getTextureKey(assetId));
    }
    return this.scene.add.rectangle(0, 0, 32, 32, fallbackColor, fallbackAlpha).setStrokeStyle(3, 0xffd166, 0.9);
  }

  private place(object: ScalableObject, layout: UIElementLayout): void {
    object.setPosition(layout.x, layout.y).setDisplaySize(layout.width, layout.height);
  }

  private playIntro(): void {
    this.panel.setScale(0.86).setAlpha(0);
    this.title.setAlpha(0).setY(this.title.y - 18);
    this.scene.tweens.add({ targets: this.panel, scale: 1, alpha: 1, duration: 260, ease: "Back.easeOut" });
    this.scene.tweens.add({ targets: this.title, y: this.title.y + 18, alpha: 1, delay: 90, duration: 230, ease: "Back.easeOut" });
  }
}
