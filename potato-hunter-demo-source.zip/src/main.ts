import type Phaser from "phaser";
import { loadUIFonts } from "./ui/UIFontLoader";
import { CampaignShell } from "./ui/CampaignShell";
import { EventBus } from "./managers/EventBus";
import { bossTestStage, progression } from "./campaign/AppState";
import { CampaignPresentation } from "./campaign/CampaignPresentation";
import { assetUrl } from "./utils/assetUrl";
import "./styles.css";

document.documentElement.style.setProperty(
  "--campaign-grass-texture",
  `url("${assetUrl("assets/backgrounds/grassland_tile-v2.png")}")`,
);

const presentation = new CampaignPresentation(EventBus, progression.getProfile().preferences);
const shell = new CampaignShell(EventBus, progression, {
  bossTestStage,
  onUnlockAudio: () => { void presentation.unlockAudio(); },
  onPreferences: presentation.setPreferences,
});
let game: Phaser.Game | undefined;
let disposed = false;
void Promise.all([loadUIFonts(), import("./game")]).then(([, module]) => {
  if (!disposed) game = module.createGame();
}).catch((error: unknown) => {
  if (!disposed) { console.error("Failed to initialize game", error); EventBus.emit("campaign:load-failed"); }
});
function dispose(): void {
  if (disposed) return;
  disposed = true;
  window.removeEventListener("pagehide", onPageHide);
  shell.destroy(); presentation.destroy(); game?.destroy(true);
}
function onPageHide(event: PageTransitionEvent): void {
  if (event.persisted) EventBus.emit("campaign:pause", true); else dispose();
}
window.addEventListener("pagehide", onPageHide);
import.meta.hot?.dispose(dispose);
