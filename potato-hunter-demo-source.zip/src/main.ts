import Phaser from "phaser";
import { BootScene } from "./scenes/BootScene";
import { GameScene } from "./scenes/GameScene";
import { UIScene } from "./scenes/UIScene";
import gameConfig from "./configs/gameConfig.json";
import { loadUIFonts } from "./ui/UIFontLoader";
import { CampaignShell } from "./ui/CampaignShell";
import { EventBus } from "./managers/EventBus";
import { progression } from "./campaign/AppState";
import { CampaignPresentation } from "./campaign/CampaignPresentation";
import { assetUrl } from "./utils/assetUrl";
import "./styles.css";

document.documentElement.style.setProperty(
  "--campaign-grass-texture",
  `url("${assetUrl("assets/backgrounds/grassland_tile-v2.png")}")`,
);

const config: Phaser.Types.Core.GameConfig = {
  type: Phaser.AUTO,
  parent: "game",
  backgroundColor: gameConfig.backgroundColor,
  scale: {
    mode: Phaser.Scale.RESIZE,
    autoCenter: Phaser.Scale.CENTER_BOTH,
    width: gameConfig.width,
    height: gameConfig.height,
  },
  physics: {
    default: "arcade",
    arcade: {
      debug: gameConfig.debugPhysics,
    },
  },
  scene: [BootScene, GameScene, UIScene],
};

const presentation = new CampaignPresentation(EventBus, progression.getProfile().preferences);
const shell = new CampaignShell(EventBus, progression, {
  onUnlockAudio: () => { void presentation.unlockAudio(); },
  onPreferences: presentation.setPreferences,
});
let game: Phaser.Game | undefined;
let disposed = false;
void loadUIFonts().then(() => { if (!disposed) game = new Phaser.Game(config); });
function dispose(): void {
  if (disposed) return;
  disposed = true;
  window.removeEventListener("pagehide", onPageHide);
  shell.destroy(); presentation.destroy(); game?.destroy(true);
}
function onPageHide(event: PageTransitionEvent): void {
  if (event.persisted) EventBus.emit("campaign:pause", true); else dispose();
}
window.addEventListener("pagehide", onPageHide);
import.meta.hot?.dispose(dispose);
