import { AUDIO_ASSETS, AUDIO_EVENTS, CombatAudioModel, mapAudioEvent } from "./CombatAudioModel";
import type { AudioAsset, AudioCueId, AudioPreferences, AudioState, ScheduledAudioCue } from "./CombatAudioModel";

export interface AudioEventPort {
  on(event: string, listener: (payload?: unknown) => void): unknown;
  off(event: string, listener: (payload?: unknown) => void): unknown;
}

export interface AudioVoice { stop(): void; }
export interface AudioSink {
  load(asset: AudioAsset): Promise<boolean>;
  playSfx(cue: ScheduledAudioCue, ended: () => void): AudioVoice | undefined;
  playMusic(asset: AudioAsset, gain: number, ended: () => void): AudioVoice | undefined;
  setMusicGain(gain: number, duck?: boolean): void;
  setSfxGain(gain: number): void;
  destroy(): void;
}

export type AudioContextPort = Pick<AudioContext, "state" | "currentTime" | "resume" | "close">;
export interface GameAudioOptions {
  createContext?: () => AudioContextPort | null;
  sink?: AudioSink;
  fetchAudio?: (url: string, signal: AbortSignal) => Promise<ArrayBuffer>;
  loadTimeoutMs?: number;
  now?: () => number;
}

type AudioStatus = "locked" | "loading" | "ready" | "unavailable" | "destroyed";
class AudioLoadTimeoutError extends Error {}

function createBrowserContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const Context = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  return Context ? new Context() : null;
}

class BrowserAudioSink implements AudioSink {
  private readonly buffers = new Map<string, AudioBuffer>();
  private readonly voices = new Set<AudioVoice>();
  private readonly controllers = new Set<AbortController>();
  private readonly musicBus: GainNode;
  private readonly sfxBus: GainNode;
  private readonly compressor: DynamicsCompressorNode;
  private destroyed = false;

  constructor(private readonly context: AudioContext, private readonly fetchAudio?: GameAudioOptions["fetchAudio"], private readonly loadTimeoutMs = 8000) {
    const nodes: AudioNode[] = [];
    try {
      this.musicBus = context.createGain();
      nodes.push(this.musicBus);
      this.sfxBus = context.createGain();
      nodes.push(this.sfxBus);
      this.compressor = context.createDynamicsCompressor();
      nodes.push(this.compressor);
      this.compressor.threshold.value = -14;
      this.compressor.knee.value = 16;
      this.compressor.ratio.value = 5;
      this.compressor.attack.value = 0.004;
      this.compressor.release.value = 0.18;
      this.musicBus.connect(this.compressor);
      this.sfxBus.connect(this.compressor);
      this.compressor.connect(context.destination);
    } catch (error) {
      for (const node of nodes) { try { node.disconnect(); } catch {} }
      throw error;
    }
  }

  async load(asset: AudioAsset): Promise<boolean> {
    if (this.destroyed) return false;
    const controller = new AbortController();
    this.controllers.add(controller);
    let rejectLoad: ((reason: unknown) => void) | undefined;
    const cancelled = new Promise<never>((_resolve, reject) => { rejectLoad = reject; });
    const cancelLoad = (): void => { rejectLoad?.(controller.signal.reason); };
    controller.signal.addEventListener("abort", cancelLoad, { once: true });
    const timeout = setTimeout(() => controller.abort(new AudioLoadTimeoutError("Audio load timed out")), Number.isFinite(this.loadTimeoutMs) && this.loadTimeoutMs > 0 ? this.loadTimeoutMs : 8000);
    try {
      const decoding = (async () => {
        const data = this.fetchAudio ? await this.fetchAudio(asset.url, controller.signal) : await fetch(asset.url, { signal: controller.signal }).then(response => {
          if (!response.ok) throw new Error("Audio unavailable");
          return response.arrayBuffer();
        });
        if (controller.signal.aborted) throw controller.signal.reason;
        return this.context.decodeAudioData(data);
      })();
      const buffer = await Promise.race([decoding, cancelled]);
      if (this.destroyed || controller.signal.aborted) return false;
      this.buffers.set(asset.id, buffer);
      return true;
    } catch (error) {
      if (error instanceof AudioLoadTimeoutError) throw error;
      return false;
    } finally {
      clearTimeout(timeout);
      controller.signal.removeEventListener("abort", cancelLoad);
      this.controllers.delete(controller);
    }
  }

  playSfx(cue: ScheduledAudioCue, ended: () => void): AudioVoice | undefined {
    return this.play(cue.asset, cue.gain, this.sfxBus, ended);
  }

  playMusic(asset: AudioAsset, gain: number, ended: () => void): AudioVoice | undefined {
    this.setMusicGain(gain);
    return this.play(asset, 1, this.musicBus, ended);
  }

  setMusicGain(gain: number, duck = false): void {
    if (this.destroyed || !Number.isFinite(gain)) return;
    const now = this.context.currentTime;
    const parameter = this.musicBus.gain;
    const level = Math.max(0, Math.min(0.3, gain));
    parameter.cancelScheduledValues(now);
    parameter.setValueAtTime(parameter.value, now);
    if (duck && level > 0) {
      parameter.linearRampToValueAtTime(level * 0.28, now + 0.04);
      parameter.setValueAtTime(level * 0.28, now + 1.2);
      parameter.linearRampToValueAtTime(level, now + 1.85);
    } else {
      parameter.linearRampToValueAtTime(level, now + 0.08);
    }
  }

  setSfxGain(gain: number): void {
    if (this.destroyed || !Number.isFinite(gain)) return;
    const now = this.context.currentTime;
    this.sfxBus.gain.cancelScheduledValues(now);
    this.sfxBus.gain.setValueAtTime(this.sfxBus.gain.value, now);
    this.sfxBus.gain.linearRampToValueAtTime(Math.max(0, Math.min(1, gain)), now + 0.025);
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    for (const controller of this.controllers) controller.abort();
    for (const voice of [...this.voices]) voice.stop();
    this.musicBus.disconnect();
    this.sfxBus.disconnect();
    this.compressor.disconnect();
    this.buffers.clear();
  }

  private play(asset: AudioAsset, level: number, bus: GainNode, ended: () => void): AudioVoice | undefined {
    const buffer = this.buffers.get(asset.id);
    if (this.destroyed || !buffer || this.context.state !== "running") return undefined;
    let source: AudioBufferSourceNode | undefined;
    let gain: GainNode | undefined;
    let voice: AudioVoice | undefined;
    let finished = false;
    const cleanup = (): void => {
      if (finished) return;
      finished = true;
      if (source) source.onended = null;
      try { source?.disconnect(); } catch {}
      try { gain?.disconnect(); } catch {}
      if (voice) this.voices.delete(voice);
      ended();
    };
    voice = { stop: () => {
      if (finished) return;
      try { source?.stop(); } catch {}
      cleanup();
    } };
    try {
      source = this.context.createBufferSource();
      gain = this.context.createGain();
      source.buffer = buffer;
      source.loop = asset.loop;
      if (asset.loop) { source.loopStart = 0; source.loopEnd = buffer.duration; }
      gain.gain.setValueAtTime(asset.loop ? 0 : level, this.context.currentTime);
      if (asset.loop) gain.gain.linearRampToValueAtTime(level, this.context.currentTime + 0.3);
      source.connect(gain);
      gain.connect(bus);
      source.onended = cleanup;
      this.voices.add(voice);
      source.start();
    } catch { voice.stop(); return undefined; }
    return voice;
  }
}

export class GameAudio {
  private readonly model: CombatAudioModel;
  private readonly listeners = new Map<string, (payload?: unknown) => void>();
  private readonly voices = new Map<number, { voice: AudioVoice; expires: number }>();
  private readonly loaded = new Set<string>();
  private readonly queued: { cue: AudioCueId; time: number }[] = [];
  private context?: AudioContextPort;
  private sink?: AudioSink;
  private music?: { id: string; voice: AudioVoice };
  private status: AudioStatus = "locked";
  private unlockPending?: Promise<void>;
  private loadPending?: Promise<void>;

  constructor(private readonly events: AudioEventPort, preferences: Partial<AudioPreferences> = {}, private readonly options: GameAudioOptions = {}) {
    this.model = new CombatAudioModel(preferences);
    for (const event of AUDIO_EVENTS) {
      const listener = (payload?: unknown): void => this.handleEvent(event, payload);
      this.listeners.set(event, listener);
      events.on(event, listener);
    }
  }

  unlock(): Promise<void> {
    if (this.status === "destroyed" || (this.status === "unavailable" && (!this.context || this.options.sink))) return Promise.resolve();
    if (this.unlockPending) return this.unlockPending;
    if (this.context?.state === "running" && (this.status === "loading" || this.status === "ready")) return Promise.resolve();
    this.unlockPending = this.resumeOnGesture().finally(() => { this.unlockPending = undefined; });
    return this.unlockPending;
  }

  setPreferences(preferences: Partial<AudioPreferences>): void {
    if (this.status === "destroyed") return;
    this.model.setPreferences(preferences);
    this.safe(() => this.sink?.setSfxGain(this.model.preferences.sfxVolume));
    if (this.model.preferences.sfxVolume === 0 || this.model.preferences.reducedEffects) this.stopSfx();
    this.updateMusic();
  }

  setState(state: AudioState): void {
    if (this.status === "destroyed" || this.model.state === state) return;
    this.model.setState(state);
    if (state === "home" || state === "paused" || state === "victory" || state === "defeat") this.stopSfx();
    this.updateMusic();
    if (state === "victory" || state === "defeat") this.playCue(state);
  }

  destroy(): void {
    if (this.status === "destroyed") return;
    this.status = "destroyed";
    for (const [event, listener] of this.listeners) this.events.off(event, listener);
    this.listeners.clear();
    this.stopSfx();
    this.safe(() => this.music?.voice.stop());
    this.music = undefined;
    this.safe(() => this.sink?.destroy());
    this.loaded.clear();
    if (this.context) {
      try { void this.context.close().catch(() => undefined); } catch {}
    }
  }

  getSnapshot(): { status: AudioStatus; state: AudioState; queued: number; activeVoices: number; loaded: number; musicGain: number } {
    return { status: this.status, queued: this.queued.length, loaded: this.loaded.size, ...this.model.snapshot(this.now()) };
  }

  private async resumeOnGesture(): Promise<void> {
    let initializingSink: AudioSink | undefined;
    try {
      this.context ??= (this.options.createContext ?? createBrowserContext)() ?? undefined;
      if (!this.context) { this.status = "unavailable"; return; }
      await this.context.resume();
      if (this.status === "destroyed" || this.context.state !== "running") return;
      if (!this.sink) {
        initializingSink = this.options.sink ?? new BrowserAudioSink(this.context as AudioContext, this.options.fetchAudio, this.options.loadTimeoutMs);
        initializingSink.setSfxGain(this.model.preferences.sfxVolume);
        this.sink = initializingSink;
        initializingSink = undefined;
        this.status = "loading";
        this.loadPending = this.loadAssets().finally(() => { this.loadPending = undefined; });
      } else {
        this.status = this.loadPending ? "loading" : "ready";
        this.updateMusic();
      }
    } catch {
      this.safe(() => initializingSink?.destroy());
      if (this.status !== "destroyed") this.status = initializingSink === this.options.sink && initializingSink ? "unavailable" : "locked";
    }
  }

  private async loadAssets(): Promise<void> {
    const sink = this.sink;
    if (!sink) return;
    let expired = false;
    await Promise.all(Object.values(AUDIO_ASSETS).map(async sound => {
      try {
        if (await sink.load(sound) && this.status !== "destroyed") this.loaded.add(sound.id);
      } catch (error) { if (error instanceof AudioLoadTimeoutError) expired = true; }
    }));
    if (this.status === "destroyed" || this.sink !== sink) return;
    if (!this.loaded.size) {
      this.safe(() => sink.destroy());
      this.sink = undefined;
      this.queued.length = 0;
      this.status = sink === this.options.sink || expired ? "unavailable" : "locked";
      return;
    }
    this.status = "ready";
    this.updateMusic();
    const pending = this.queued.splice(0);
    for (const queued of pending) if (this.now() - queued.time <= 0.6) this.playCue(queued.cue);
  }

  private handleEvent(event: string, payload?: unknown): void {
    if (this.status === "destroyed") return;
    if (event === "game:over") {
      const outcome = (payload as { outcome?: string } | undefined)?.outcome;
      this.setState(outcome === "victory" ? "victory" : "defeat");
      return;
    }
    if (event === "boss:spawned" && (this.model.state === "combat" || this.model.state === "boss")) this.setState("boss");
    for (const cue of mapAudioEvent(event, payload)) this.playCue(cue);
  }

  private playCue(cueId: AudioCueId): void {
    if (!this.model.canPlay(cueId)) return;
    if (this.status === "loading" && AUDIO_ASSETS[cueId].priority >= 3) {
      const duplicateIndex = this.queued.findIndex(pending => pending.cue === cueId);
      if (duplicateIndex >= 0) this.queued.splice(duplicateIndex, 1);
      if (this.queued.length >= 8) this.queued.shift();
      this.queued.push({ cue: cueId, time: this.now() });
      return;
    }
    if (this.status !== "ready" || this.context?.state !== "running" || !this.loaded.has(cueId) || !this.sink) return;
    const now = this.now();
    for (const [id, active] of this.voices) {
      if (active.expires <= now) { this.safe(() => active.voice.stop()); this.voices.delete(id); }
    }
    const scheduled = this.model.admit(cueId, now);
    if (!scheduled) return;
    if (scheduled.preemptId !== undefined) { this.safe(() => this.voices.get(scheduled.preemptId!)?.voice.stop()); this.voices.delete(scheduled.preemptId); }
    let voice: AudioVoice | undefined;
    this.safe(() => { voice = this.sink?.playSfx(scheduled, () => { this.model.release(scheduled.id); this.voices.delete(scheduled.id); }); });
    if (voice) this.voices.set(scheduled.id, { voice, expires: scheduled.expires });
    else this.model.release(scheduled.id);
    if (voice && cueId === "boss-danger") this.safe(() => this.sink?.setMusicGain(this.model.preferences.musicVolume * 0.25, true));
  }

  private updateMusic(): void {
    if (this.status !== "ready" || !this.sink || this.context?.state !== "running") return;
    const sound = this.model.musicAsset();
    const gain = this.model.musicGain(this.now());
    if (!sound || gain === 0 || !this.loaded.has(sound.id)) {
      this.safe(() => this.sink?.setMusicGain(0));
      this.safe(() => this.music?.voice.stop());
      this.music = undefined;
      return;
    }
    const baseGain = this.model.preferences.musicVolume * 0.25;
    if (this.music?.id !== sound.id) {
      this.safe(() => this.music?.voice.stop());
      this.music = undefined;
      this.safe(() => {
        const voice = this.sink?.playMusic(sound, baseGain, () => { if (this.music?.id === sound.id) this.music = undefined; });
        if (voice) this.music = { id: sound.id, voice };
      });
    }
    this.safe(() => this.sink?.setMusicGain(baseGain, gain < baseGain));
  }

  private stopSfx(): void {
    for (const active of [...this.voices.values()]) this.safe(() => active.voice.stop());
    this.voices.clear();
    this.queued.length = 0;
    this.model.clear();
  }

  private now(): number {
    const now = this.options.now?.() ?? this.context?.currentTime ?? 0;
    return Number.isFinite(now) ? now : 0;
  }

  private safe(action: () => void): void { try { action(); } catch {} }
}
