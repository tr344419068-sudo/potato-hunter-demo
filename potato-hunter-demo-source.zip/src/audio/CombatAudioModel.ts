import { assetUrl } from "../utils/assetUrl";

export interface AudioPreferences {
  musicVolume: number;
  sfxVolume: number;
  reducedEffects: boolean;
}

export type AudioState = "home" | "combat" | "boss" | "paused" | "victory" | "defeat";
export type AudioCueId = "launch-peeler" | "launch-fire" | "launch-ice" | "launch-lightning" | "launch-poison" | "launch-explosion" | "launch-rapid" | "impact-organic" | "impact-metal" | "impact-fire" | "impact-ice" | "impact-electric" | "impact-toxic" | "impact-explosive" | "critical" | "shield" | "dash" | "pickup" | "upgrade" | "boss-danger" | "player-hurt" | "victory" | "defeat";
export type MusicId = "music-calm" | "music-combat" | "music-boss";

export interface AudioAsset {
  id: AudioCueId | MusicId;
  url: string;
  duration: number;
  gain: number;
  priority: number;
  cooldown: number;
  loop: boolean;
}

function asset(id: AudioCueId | MusicId, duration: number, gain: number, priority: number, cooldown: number, loop = false): AudioAsset {
  return Object.freeze({ id, url: assetUrl(`assets/audio/${id}.wav`), duration, gain, priority, cooldown, loop });
}

export const AUDIO_ASSETS: Readonly<Record<AudioCueId | MusicId, AudioAsset>> = Object.freeze({
  "launch-peeler": asset("launch-peeler", 0.24, 0.13, 1, 0.09),
  "launch-fire": asset("launch-fire", 0.31, 0.12, 1, 0.12),
  "launch-ice": asset("launch-ice", 0.28, 0.11, 1, 0.12),
  "launch-lightning": asset("launch-lightning", 0.22, 0.10, 1, 0.12),
  "launch-poison": asset("launch-poison", 0.34, 0.12, 1, 0.14),
  "launch-explosion": asset("launch-explosion", 0.35, 0.14, 1, 0.16),
  "launch-rapid": asset("launch-rapid", 0.14, 0.118, 1, 0.09),
  "impact-organic": asset("impact-organic", 0.22, 0.12, 1, 0.07),
  "impact-metal": asset("impact-metal", 0.29, 0.12, 1, 0.08),
  "impact-fire": asset("impact-fire", 0.36, 0.13, 1, 0.10),
  "impact-ice": asset("impact-ice", 0.38, 0.12, 1, 0.10),
  "impact-electric": asset("impact-electric", 0.27, 0.11, 1, 0.10),
  "impact-toxic": asset("impact-toxic", 0.40, 0.12, 1, 0.12),
  "impact-explosive": asset("impact-explosive", 0.62, 0.18, 2, 0.16),
  critical: asset("critical", 0.40, 0.16, 3, 0.15),
  shield: asset("shield", 0.38, 0.16, 3, 0.15),
  dash: asset("dash", 0.28, 0.17, 3, 0.24),
  pickup: asset("pickup", 0.24, 0.12, 2, 0.09),
  upgrade: asset("upgrade", 0.95, 0.22, 4, 0.35),
  "boss-danger": asset("boss-danger", 1.10, 0.27, 5, 0.70),
  "player-hurt": asset("player-hurt", 0.32, 0.20, 4, 0.20),
  victory: asset("victory", 2.10, 0.27, 5, 2.10),
  defeat: asset("defeat", 1.65, 0.23, 5, 1.65),
  "music-calm": asset("music-calm", 20, 0.25, 0, 0, true),
  "music-combat": asset("music-combat", 16, 0.25, 0, 0, true),
  "music-boss": asset("music-boss", 160 / 11, 0.25, 0, 0, true),
});

export const AUDIO_EVENTS = Object.freeze(["weapon:fired", "weapon:impact", "combat:projectile", "combat:impact", "combat:damage", "combat:vfx", "hostile:impact", "palm:impact", "hero:dash", "player:dash", "player:damaged", "reward:collected", "level:choices", "skill:selected", "boss:spawned", "boss:phase", "boss:danger", "game:over"]);

const FAMILY_BY_SKILL: Readonly<Record<string, string>> = Object.freeze({ peeler_blade: "peeler", fire_potato: "fire", inferno_pierce: "fire", frost_chips: "ice", frost_explosion: "ice", thunder_potato: "lightning", thunder_storm: "lightning", toxic_tomato: "poison", toxic_burst_cloud: "poison", starch_bomb: "explosion", starch_nuke: "explosion", pepper_gatling: "rapid", pepper_overdrive: "rapid", corn_burst: "rapid" });
const IMPACT_BY_FAMILY: Readonly<Record<string, AudioCueId>> = Object.freeze({ peeler: "impact-metal", fire: "impact-fire", ice: "impact-ice", lightning: "impact-electric", poison: "impact-toxic", explosion: "impact-explosive", rapid: "impact-organic" });

function payloadRecord(payload: unknown): Record<string, unknown> {
  return payload && typeof payload === "object" ? payload as Record<string, unknown> : {};
}

function familyFor(payload: Record<string, unknown>): string {
  const projectile = payloadRecord(payload.projectile);
  const skillId = String(payload.skillId ?? projectile.skillId ?? "");
  if (FAMILY_BY_SKILL[skillId]) return FAMILY_BY_SKILL[skillId];
  const kind = String(payload.family ?? payload.vfxKind ?? projectile.vfxKind ?? payload.kind ?? "kinetic");
  if (kind === "frost" || kind === "freeze") return "ice";
  if (kind === "burn") return "fire";
  if (kind === "chain" || kind === "electric") return "lightning";
  return IMPACT_BY_FAMILY[kind] ? kind : "rapid";
}

export function mapAudioEvent(event: string, payload?: unknown): AudioCueId[] {
  const data = payloadRecord(payload);
  switch (event) {
    case "weapon:fired":
    case "combat:projectile": {
      const skill = data.skillId ?? payloadRecord(data.projectile).skillId;
      if (skill === "skewer_javelin" || skill === "moon_draw") return ["launch-peeler"];
      if (skill === "thunder_skewer") return ["launch-lightning"];
      return [`launch-${familyFor(data)}` as AudioCueId];
    }
    case "weapon:impact":
    case "combat:impact": {
      const material = data.material;
      const cue = material === "metal" || material === "armored" ? "impact-metal" : material === "shield" ? "shield" : IMPACT_BY_FAMILY[familyFor(data)];
      return data.critical === true || data.isCrit === true ? [cue, "critical"] : [cue];
    }
    case "combat:damage": return data.shield === true || data.color === "#89cfff" || data.color === "#c77dff" ? ["shield"] : data.isCrit === true ? ["critical"] : [];
    case "combat:vfx": return data.kind === "explosion" ? ["impact-explosive"] : [];
    case "hostile:impact": return [data.style === "lightning" ? "impact-electric" : "impact-explosive"];
    case "palm:impact": return ["impact-explosive"];
    case "hero:dash":
    case "player:dash": return ["dash"];
    case "player:damaged": return ["player-hurt"];
    case "reward:collected": return ["pickup"];
    case "level:choices":
    case "skill:selected": return ["upgrade"];
    case "boss:spawned":
    case "boss:danger": return ["boss-danger"];
    case "boss:phase": return data.danger === true || typeof data.phase === "number" || typeof data.pattern === "string" ? ["boss-danger"] : [];
    case "game:over": return [data.outcome === "victory" ? "victory" : "defeat"];
    default: return [];
  }
}

export function normalizeAudioPreferences(input: Partial<AudioPreferences>, previous: AudioPreferences = { musicVolume: 0.55, sfxVolume: 0.7, reducedEffects: false }): AudioPreferences {
  const volume = (value: unknown, fallback: number): number => typeof value === "number" && Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : fallback;
  return { musicVolume: volume(input.musicVolume, previous.musicVolume), sfxVolume: volume(input.sfxVolume, previous.sfxVolume), reducedEffects: typeof input.reducedEffects === "boolean" ? input.reducedEffects : previous.reducedEffects };
}

export interface ScheduledAudioCue {
  id: number;
  asset: AudioAsset;
  gain: number;
  expires: number;
  preemptId?: number;
  playbackRate?: number;
}

export class CombatAudioModel {
  preferences: AudioPreferences;
  state: AudioState = "home";
  private sequence = 0;
  private duckUntil = -Infinity;
  private readonly active = new Map<number, ScheduledAudioCue>();
  private readonly lastPlayed = new Map<AudioCueId, number>();

  constructor(preferences: Partial<AudioPreferences> = {}) {
    this.preferences = normalizeAudioPreferences(preferences);
  }
  setPreferences(preferences: Partial<AudioPreferences>): void {
    this.preferences = normalizeAudioPreferences(preferences, this.preferences);
  }

  setState(state: AudioState): void {
    this.state = state;
    if (state === "home" || state === "paused" || state === "victory" || state === "defeat") this.clear();
  }

  admit(cueId: AudioCueId, now: number, playbackRate?: number): ScheduledAudioCue | undefined {
    if (!Number.isFinite(now) || !this.canPlay(cueId)) return undefined;
    const sound = AUDIO_ASSETS[cueId];
    this.expire(now);
    if (now - (this.lastPlayed.get(cueId) ?? -Infinity) < sound.cooldown) return undefined;
    const limit = sound.priority >= 3 ? 10 : 8;
    let preemptId: number | undefined;
    if (this.active.size >= limit) {
      if (sound.priority < 3) return undefined;
      const victim = [...this.active.values()].filter(voice => voice.asset.priority < sound.priority).sort((first, second) => first.asset.priority - second.asset.priority || first.id - second.id)[0];
      if (!victim) return undefined;
      preemptId = victim.id;
      this.active.delete(victim.id);
    }
    const gain = sound.gain * (this.preferences.reducedEffects ? 0.8 : 1) / Math.sqrt(1 + this.active.size * 0.22);
    const rate = Number.isFinite(playbackRate) ? Math.max(.75, Math.min(1.25, playbackRate!)) : 1;
    const scheduled = { id: ++this.sequence, asset: sound, gain, expires: now + sound.duration / rate + 0.03, preemptId, playbackRate: rate === 1 ? undefined : rate };
    this.active.set(scheduled.id, scheduled);
    this.lastPlayed.set(cueId, now);
    if (cueId === "boss-danger") this.duckUntil = now + 1.2;
    return scheduled;
  }

  canPlay(cueId: AudioCueId): boolean {
    const sound = AUDIO_ASSETS[cueId];
    if (!sound || sound.loop || this.preferences.sfxVolume === 0) return false;
    if (this.state !== "combat" && this.state !== "boss" && cueId !== "upgrade" && cueId !== "victory" && cueId !== "defeat") return false;
    return !this.preferences.reducedEffects || sound.priority >= 3 || cueId === "pickup";
  }

  release(id: number): void { this.active.delete(id); }

  clear(): void {
    this.active.clear();
    this.lastPlayed.clear();
    this.duckUntil = -Infinity;
  }

  musicGain(now: number): number {
    if (!Number.isFinite(now) || this.state === "paused" || this.state === "victory" || this.state === "defeat") return 0;
    const recovery = Math.max(0, Math.min(1, (now - this.duckUntil) / 0.65));
    return this.preferences.musicVolume * 0.25 * (0.28 + 0.72 * recovery);
  }

  musicAsset(): AudioAsset | undefined {
    if (this.state === "paused" || this.state === "victory" || this.state === "defeat") return undefined;
    return AUDIO_ASSETS[this.state === "boss" ? "music-boss" : this.state === "combat" ? "music-combat" : "music-calm"];
  }

  snapshot(now: number): { activeVoices: number; state: AudioState; musicGain: number } {
    this.expire(now);
    return { activeVoices: this.active.size, state: this.state, musicGain: this.musicGain(now) };
  }

  private expire(now: number): void {
    for (const voice of this.active.values()) if (voice.expires <= now) this.active.delete(voice.id);
  }
}
