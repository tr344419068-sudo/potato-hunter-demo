import type { EntityId, SkillEffect } from "../components/ComponentTypes";
import { EntityPools } from "../managers/EntityPools";
import type { MapEventConfig, MonsterConfig } from "../managers/ConfigManager";
import { INITIAL_EXPERIENCE_REQUIREMENT } from "../managers/PacingModel";
import { World } from "./World";
import type { CombatVfxKind } from "../systems/CombatVfxModel";
import { EXPERIENCE_ORB_ASSET_ID, getPickupPresentation } from "../systems/PickupPresentationModel";
import type { WeaponLaunchVisual } from "../systems/WeaponPresentationModel";
import { ENEMY_PROJECTILE_ART, type EnemyProjectileStyle } from "../systems/EnemyProjectileModel";

export function createPlayer(
  world: World,
  x: number,
  y: number,
  moveSpeed: number,
  maxHp: number,
  pickupRadius: number,
  assetId?: string,
): EntityId {
  const entityId = world.createEntity();

  world.components.transforms.set(entityId, { x, y, radius: 16 });
  world.components.velocities.set(entityId, { x: 0, y: 0 });
  world.components.renders.set(entityId, { shape: "circle", color: 0xf4d35e, size: 32, assetId });
  world.components.health.set(entityId, { current: maxHp, max: maxHp });
  world.components.players.set(entityId, {
    moveSpeed,
    pickupRadius,
    level: 1,
    experience: 0,
    experienceToNext: INITIAL_EXPERIENCE_REQUIREMENT,
    damageCooldownMs: 0,
    dashRemainingMs: 0,
    dashCooldownMs: 0,
    dashDirectionX: 1,
    dashDirectionY: 0,
  });

  return entityId;
}

export function createMonster(world: World, monsterConfig: MonsterConfig, x: number, y: number, isBoss = false, bossAssetId?: string): EntityId {
  const entityId = world.createEntity();
  const hp = isBoss ? monsterConfig.hp * 8 : monsterConfig.hp;
  const radius = isBoss ? monsterConfig.radius * 1.9 : monsterConfig.radius;

  world.components.transforms.set(entityId, { x, y, radius });
  world.components.velocities.set(entityId, { x: 0, y: 0 });
  world.components.renders.set(entityId, {
    shape: isBoss ? "square" : monsterConfig.shape,
    color: isBoss ? 0x8e44ad : monsterConfig.color,
    size: radius * 2,
    assetId: isBoss ? bossAssetId ?? monsterConfig.assetId : monsterConfig.assetId,
  });
  world.components.health.set(entityId, { current: hp, max: hp });
  world.components.monsters.set(entityId, {
    monsterId: monsterConfig.id,
    damage: isBoss ? monsterConfig.damage * 2 : monsterConfig.damage,
    experienceValue: isBoss ? monsterConfig.experienceValue * 12 : monsterConfig.experienceValue,
    isBoss,
    isElite: false,
    shieldHp: isBoss ? 0 : monsterConfig.shieldHp ?? 0,
    speedMultiplier: 1,
    touchCooldownMs: 0,
    behavior: isBoss ? "chaser" : monsterConfig.behavior ?? "chaser",
    behaviorTimerMs: 1200,
    stateTimerMs: 0,
  });

  return entityId;
}

export function createMapEvent(world: World, eventConfig: MapEventConfig, x: number, y: number): EntityId {
  const entityId = world.createEntity();

  world.components.transforms.set(entityId, { x, y, radius: eventConfig.radius });
  world.components.renders.set(entityId, {
    shape: "square",
    color: eventConfig.color,
    size: eventConfig.radius * 2,
    alpha: 0.92,
    assetId: getPickupPresentation(eventConfig.kind).assetId,
  });
  world.components.mapEvents.set(entityId, {
    eventId: eventConfig.id,
    kind: eventConfig.kind,
    value: eventConfig.value,
    durationMs: eventConfig.durationMs,
  });
  world.components.lifetimes.set(entityId, {
    remainingMs: eventConfig.lifetimeMs,
    totalMs: eventConfig.lifetimeMs,
  });

  return entityId;
}

export function createProjectile(
  world: World,
  x: number,
  y: number,
  velocityX: number,
  velocityY: number,
  skillId: string,
  damage: number,
  pierce: number,
  lifetimeMs: number,
  color = 0xdff8eb,
  size = 12,
  effects: SkillEffect[] = [],
  critChance = 0,
  critMultiplier = 1.6,
  projectileAssetId?: string,
  vfxKind?: CombatVfxKind,
  launchVisual?: WeaponLaunchVisual,
  returnAfterMs?: number,
): EntityId {
  const entityId = EntityPools.acquireProjectile(world);

  world.components.transforms.set(entityId, { x, y, radius: 6 });
  world.components.velocities.set(entityId, { x: velocityX, y: velocityY });
  world.components.renders.set(entityId, { shape: "square", color, size, assetId: projectileAssetId });
  world.components.projectiles.set(entityId, {
    skillId,
    damage,
    pierce,
    critChance,
    critMultiplier,
    lifetimeMs,
    hitEntities: new Set(),
    effects,
    chainJumpsRemaining: effects.find((effect) => effect.type === "chain")?.jumps ?? 0,
    vfxKind,
    launchVisual,
    ...(returnAfterMs && { returnFlight: { remainingOutboundMs: returnAfterMs, speed: Math.hypot(velocityX, velocityY) } }),
  });
  world.components.lifetimes.set(entityId, { remainingMs: lifetimeMs, totalMs: lifetimeMs });

  return entityId;
}

export function createEnemyProjectile(
  world: World,
  x: number,
  y: number,
  velocityX: number,
  velocityY: number,
  damage: number,
  lifetimeMs = 1800,
  style: EnemyProjectileStyle = "cola",
): EntityId {
  const entityId = world.createEntity();

  world.components.transforms.set(entityId, { x, y, radius: 7 });
  world.components.velocities.set(entityId, { x: velocityX, y: velocityY });
  world.components.renders.set(entityId, { shape: "circle", ...ENEMY_PROJECTILE_ART[style], size: 14 });
  world.components.enemyProjectiles.set(entityId, { damage });
  world.components.lifetimes.set(entityId, { remainingMs: lifetimeMs, totalMs: lifetimeMs });

  return entityId;
}

export function createAoeWarning(world: World, x: number, y: number, radius: number, damage: number, delayMs: number, safeRadius?: number): EntityId {
  const entityId = world.createEntity();

  world.components.transforms.set(entityId, { x, y, radius });
  world.components.aoeWarnings.set(entityId, {
    remainingMs: delayMs,
    totalMs: delayMs,
    damage,
    triggered: false,
    safeRadius,
  });

  return entityId;
}

export function createExperienceOrb(world: World, x: number, y: number, value: number): EntityId {
  const entityId = EntityPools.acquireExpOrb(world);

  world.components.transforms.set(entityId, { x, y, radius: 5 });
  world.components.velocities.set(entityId, { x: 0, y: 0 });
  world.components.renders.set(entityId, { shape: "circle", color: 0x4cc9f0, size: 18, assetId: EXPERIENCE_ORB_ASSET_ID });
  world.components.experienceOrbs.set(entityId, { value });

  return entityId;
}
