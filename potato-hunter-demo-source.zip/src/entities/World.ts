import type { ComponentStores, EntityId } from "../components/ComponentTypes";

export class World {
  private nextEntityId = 1;
  private readonly aliveEntities = new Set<EntityId>();

  readonly components: ComponentStores = {
    transforms: new Map(),
    velocities: new Map(),
    renders: new Map(),
    health: new Map(),
    players: new Map(),
    monsters: new Map(),
    projectiles: new Map(),
    enemyProjectiles: new Map(),
    experienceOrbs: new Map(),
    mapEvents: new Map(),
    playerBuffs: new Map(),
    lifetimes: new Map(),
    knockbacks: new Map(),
    hitFlashes: new Map(),
    statuses: new Map(),
    aoeWarnings: new Map(),
    spriteJuices: new Map(),
  };

  clearComponents(entityId: EntityId): void {
    for (const store of Object.values(this.components)) {
      store.delete(entityId);
    }
    this.aliveEntities.add(entityId);
  }

  createEntity(): EntityId {
    const entityId = this.nextEntityId;
    this.nextEntityId += 1;
    this.aliveEntities.add(entityId);
    return entityId;
  }

  destroyEntity(entityId: EntityId): void {
    this.aliveEntities.delete(entityId);

    for (const store of Object.values(this.components)) {
      store.delete(entityId);
    }
  }

  isAlive(entityId: EntityId): boolean {
    return this.aliveEntities.has(entityId);
  }

  get entityCount(): number {
    return this.aliveEntities.size;
  }
}
