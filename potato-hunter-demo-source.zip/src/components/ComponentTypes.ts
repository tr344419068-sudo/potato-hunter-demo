export type EntityId = number;
import type { CombatVfxKind } from "../systems/CombatVfxModel";

export interface TransformComponent {
  x: number;
  y: number;
  radius: number;
}

export interface VelocityComponent {
  x: number;
  y: number;
}

export interface RenderComponent {
  shape: "circle" | "square";
  color: number;
  size: number;
  alpha?: number;
  assetId?: string;
}

export interface SpriteJuiceComponent {
  offsetX: number;
  offsetY: number;
  scaleX: number;
  scaleY: number;
  rotation: number;
  facingX: -1 | 1;
  shadowScaleX: number;
  shadowScaleY: number;
  shadowAlpha: number;
  limbAttack?: number;
  attackSequence?: number;
  attackProgress?: number;
  weaponReleaseSequence?: number;
}

export type SkillEffect =
  | { type: "damage"; value: number }
  | { type: "burn"; durationMs: number; damagePerSecond: number }
  | { type: "freeze"; durationMs: number; slowMultiplier: number }
  | { type: "slow"; durationMs: number; slowMultiplier: number }
  | { type: "poison"; durationMs: number; damagePerSecond: number }
  | { type: "chain"; jumps: number; radius: number; damageMultiplier: number }
  | { type: "pierce"; value: number }
  | { type: "explosion"; radius: number; damageMultiplier: number }
  | { type: "knockback"; force: number }
  | { type: "heal"; value: number }
  | { type: "stat_modifier"; stat: string; value: number; mode: "add" | "multiply" };

export interface HealthComponent {
  current: number;
  max: number;
}

export interface PlayerComponent {
  moveSpeed: number;
  pickupRadius: number;
  level: number;
  experience: number;
  experienceToNext: number;
  damageCooldownMs: number;
  dashRemainingMs: number;
  dashCooldownMs: number;
  dashDirectionX: number;
  dashDirectionY: number;
  tempo?: { stacks: number; holdRemainingMs: number; decayElapsedMs: number };
}

export type FinalBossPhase = 1 | 2 | 3;

export interface FinalBossEncounter {
  phase: FinalBossPhase;
  completedCasts: number;
  transitioning: boolean;
  swingFrame?: number;
  swingFacing?: -1 | 1;
  burrowed?: boolean;
  sandArmor?: { hp: number; max: number; remainingMs: number };
}

export interface MonsterComponent {
  monsterId: string;
  damage: number;
  experienceValue: number;
  isBoss: boolean;
  bossKind?: "intermediate" | "final";
  finalBossEncounter?: FinalBossEncounter;
  isElite: boolean;
  eliteAffix?: "haste" | "split" | "shield" | "death_bomb";
  shieldHp?: number;
  speedMultiplier: number;
  touchCooldownMs: number;
  behavior: "chaser" | "charger" | "exploder" | "ranged" | "summoner" | "guard" | "flanker" | "bombardier" | "hexer" | "scatter" | "sniper" | "jumper";
  behaviorTimerMs: number;
  stateTimerMs: number;
  controlledMotion?: boolean;
  controlledMotionRemainingMs?: number;
  jumpProgress?: number;
  roleState?: { stage: "windup" | "lunge" | "recovery"; remainingMs: number; directionX: number; directionY: number; warningId?: EntityId };
}

export interface ProjectileComponent {
  skillId: string;
  damage: number;
  pierce: number;
  critChance: number;
  critMultiplier: number;
  lifetimeMs: number;
  hitEntities: Set<EntityId>;
  effects: SkillEffect[];
  chainJumpsRemaining: number;
  vfxKind?: CombatVfxKind;
  launchVisual?: import("../systems/WeaponPresentationModel").WeaponLaunchVisual;
  sweepOrigin?: { x: number; y: number; stepFraction: number };
  returnFlight?: { remainingOutboundMs: number; speed: number; returning?: boolean };
}

export interface EnemyProjectileComponent {
  damage: number;
  sweepOrigin?: { x: number; y: number; stepFraction: number };
}

export interface ExperienceOrbComponent {
  value: number;
}

export interface MapEventComponent {
  eventId: string;
  kind: "heal" | "xp_burst" | "haste" | "magnet" | "supply";
  value: number;
  durationMs?: number;
}

export interface PlayerBuffComponent {
  id: string;
  remainingMs: number;
  moveSpeedBonus?: number;
  pickupRadiusBonus?: number;
  cooldownMultiplier?: number;
}

export interface LifetimeComponent {
  remainingMs: number;
  totalMs: number;
}

export interface KnockbackComponent {
  x: number;
  y: number;
  remainingMs: number;
}

export interface HitFlashComponent {
  remainingMs: number;
  totalMs: number;
}

export interface StatusEffectComponent {
  type: "burn" | "freeze" | "slow" | "poison";
  remainingMs: number;
  totalMs: number;
  damagePerSecond: number;
  slowMultiplier: number;
}

export interface AoeWarningComponent {
  remainingMs: number;
  totalMs: number;
  damage: number;
  triggered: boolean;
  safeRadius?: number;
  sourceId?: EntityId;
  shape?: "circle" | "rectangle" | "capsule";
  angle?: number;
  length?: number;
  width?: number;
  contactPadding?: number;
  label?: string;
  impactStyle?: "oil" | "slam" | "sweep" | "sauce" | "sand" | "bomb" | "lightning" | "shockwave";
  impactArt?: { kind: "contact" } | { kind: "sweep"; x: number; y: number; angle: number; length: number };
  bossPhase?: number;
  bossFinisher?: boolean;
  color?: number;
  zone?: { remainingMs: number; tickIntervalMs: number; tickRemainingMs: number; tickDamage: number; ticksRemaining: number; color: number };
  armed?: boolean;
  skipNextTick?: boolean;
}

export interface ComponentStores {
  transforms: Map<EntityId, TransformComponent>;
  velocities: Map<EntityId, VelocityComponent>;
  renders: Map<EntityId, RenderComponent>;
  health: Map<EntityId, HealthComponent>;
  players: Map<EntityId, PlayerComponent>;
  monsters: Map<EntityId, MonsterComponent>;
  projectiles: Map<EntityId, ProjectileComponent>;
  enemyProjectiles: Map<EntityId, EnemyProjectileComponent>;
  experienceOrbs: Map<EntityId, ExperienceOrbComponent>;
  mapEvents: Map<EntityId, MapEventComponent>;
  playerBuffs: Map<EntityId, PlayerBuffComponent[]>;
  lifetimes: Map<EntityId, LifetimeComponent>;
  knockbacks: Map<EntityId, KnockbackComponent>;
  hitFlashes: Map<EntityId, HitFlashComponent>;
  statuses: Map<EntityId, StatusEffectComponent[]>;
  aoeWarnings: Map<EntityId, AoeWarningComponent>;
  spriteJuices: Map<EntityId, SpriteJuiceComponent>;
}
