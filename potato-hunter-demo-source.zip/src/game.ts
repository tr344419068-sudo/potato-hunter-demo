import Phaser from "phaser";
import { BootScene } from "./scenes/BootScene";
import { GameScene } from "./scenes/GameScene";
import { UIScene } from "./scenes/UIScene";
import gameConfig from "./configs/gameConfig.json";

export function createGame(): Phaser.Game {
  return new Phaser.Game({
    type: Phaser.AUTO,
    parent: "game",
    backgroundColor: gameConfig.backgroundColor,
    loader: { timeout: 15000 },
    scale: {
      mode: Phaser.Scale.RESIZE,
      autoCenter: Phaser.Scale.CENTER_BOTH,
      width: gameConfig.width,
      height: gameConfig.height,
    },
    physics: { default: "arcade", arcade: { debug: gameConfig.debugPhysics } },
    scene: [BootScene, GameScene, UIScene],
  });
}
